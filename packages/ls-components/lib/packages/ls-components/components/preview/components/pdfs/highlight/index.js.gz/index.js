var b = Object.defineProperty;
var p = (r, l) => b(r, "name", { value: l, configurable: !0 });
function v(r, l, h) {
  const t = [];
  for (const a of r.items)
    if (a.hasEOL)
      if (a.str.endsWith("-")) {
        const g = a.str.lastIndexOf("-");
        t.push(a.str.substring(0, g));
      } else
        t.push(a.str, `
`);
    else
      t.push(a.str);
  const n = t.join("").replace(/\n/g, " "), e = ["g"];
  h.ignoreCase && e.push("i");
  let o = l.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  h.completeWords && (o = `\\b${o}\\b`);
  const u = new RegExp(o, e.join("")), s = [];
  let i;
  for (; (i = u.exec(n)) !== null; ) s.push([i.index, i[0].length, i[0]]);
  return s;
}
p(v, "searchQuery");
function y(r, l) {
  function h(s) {
    return s.hasEOL ? s.str.endsWith("-") ? -1 : 1 : 0;
  }
  p(h, "endOfLineOffset");
  let t = 0, n = 0;
  const e = l.items, o = e.length - 1, u = [];
  for (let s = 0; s < r.length; s++) {
    let i = r[s][0];
    for (; t !== o && i >= n + e[t].str.length; ) {
      const c = e[t];
      n += c.str.length + h(c), t++;
    }
    const a = {
      idx: t,
      offset: i - n
    };
    for (i += r[s][1]; t !== o && i > n + e[t].str.length; ) {
      const c = e[t];
      n += c.str.length + h(c), t++;
    }
    const g = {
      idx: t,
      offset: i - n
    };
    u.push({
      start: a,
      end: g,
      str: r[s][2],
      oindex: r[s][0]
    });
  }
  return u;
}
p(y, "convertMatches");
function I(r, l, h) {
  function t(n, e = -1, o = -1) {
    const u = l.items[n], s = [];
    let i = "", a = "", g = "", c = h[n];
    if (!c) return;
    if (c.nodeType === Node.TEXT_NODE) {
      const d = document.createElement("span");
      c.before(d), d.append(c), h[n] = d, c = d;
    }
    e >= 0 && o >= 0 ? i = u.str.substring(e, o) : e < 0 && o < 0 ? i = u.str : e >= 0 ? i = u.str.substring(e) : o >= 0 && (i = u.str.substring(0, o));
    const T = document.createTextNode(i), m = document.createElement("span");
    if (m.className = "highlight appended", m.append(T), s.push(m), e > 0)
      if (c.childNodes.length === 1 && c.childNodes[0].nodeType === Node.TEXT_NODE) {
        a = u.str.substring(0, e);
        const d = document.createTextNode(a);
        s.unshift(d);
      } else {
        let d = 0;
        const N = [], E = c.childNodes || [];
        for (const f of E) {
          const x = f.nodeType === Node.TEXT_NODE ? f.nodeValue : f.firstChild.nodeValue;
          d += x.length, d <= e ? N.push(f) : e >= d - x.length && o <= d && N.push(document.createTextNode(x.substring(0, e - (d - x.length))));
        }
        s.unshift(...N);
      }
    if (o > 0) {
      g = u.str.substring(o);
      const d = document.createTextNode(g);
      s.push(d);
    }
    c.replaceChildren(...s);
  }
  p(t, "appendHighlightDiv");
  for (const n of r)
    if (n.start.idx === n.end.idx)
      t(n.start.idx, n.start.offset, n.end.offset);
    else
      for (let e = n.start.idx, o = n.end.idx; e <= o; e++)
        e === n.start.idx ? t(e, n.start.offset) : e === n.end.idx ? t(e, -1, n.end.offset) : t(e);
}
p(I, "highlightMatches");
function M(r, l) {
  const h = r.items.map((t) => t.str);
  for (let t = 0; t < l.length; t++) {
    const n = l[t];
    if (n && n.nodeType !== Node.TEXT_NODE) {
      const e = document.createTextNode(h[t]);
      n.replaceChildren(e);
    }
  }
}
p(M, "resetDivs");
function w(r, l, h) {
  const t = [];
  for (const n of r) {
    const e = v(l, n, h);
    t.push(...y(e, l));
  }
  return t;
}
p(w, "findMatches");
export {
  w as findMatches,
  I as highlightMatches,
  M as resetDivs
};
