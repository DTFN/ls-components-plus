import { commonjsGlobal as c, getDefaultExportFromCjs as k } from "../../../../../../../_virtual/_commonjsHelpers/index.js";
import { __module as n } from "../../../../../../../_virtual/weekOfYear/index.js";
(function(f, p) {
  (function(r, e) {
    f.exports = e();
  })(c, function() {
    var r = "week", e = "year";
    return function(w, u, a) {
      var o = u.prototype;
      o.week = function(t) {
        if (t === void 0 && (t = null), t !== null) return this.add(7 * (t - this.week()), "day");
        var s = this.$locale().yearStart || 1;
        if (this.month() === 11 && this.date() > 25) {
          var l = a(this).startOf(e).add(1, e).date(s), d = a(this).endOf(r);
          if (l.isBefore(d)) return 1;
        }
        var h = a(this).startOf(e).date(s).startOf(r).subtract(1, "millisecond"), i = this.diff(h, r, !0);
        return i < 0 ? a(this).startOf("week").week() : Math.ceil(i);
      }, o.weeks = function(t) {
        return t === void 0 && (t = null), this.week(t);
      };
    };
  });
})(n);
var m = n.exports;
const x = /* @__PURE__ */ k(m);
export {
  x as default
};
