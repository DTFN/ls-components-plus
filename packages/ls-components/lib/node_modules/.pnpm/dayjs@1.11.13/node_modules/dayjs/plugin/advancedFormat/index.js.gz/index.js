import { commonjsGlobal as d, getDefaultExportFromCjs as l } from "../../../../../../../_virtual/_commonjsHelpers/index.js";
import { __module as i } from "../../../../../../../_virtual/advancedFormat/index.js";
(function(u, w) {
  (function(f, t) {
    u.exports = t();
  })(d, function() {
    return function(f, t) {
      var o = t.prototype, s = o.format;
      o.format = function(n) {
        var e = this, c = this.$locale();
        if (!this.isValid()) return s.bind(this)(n);
        var a = this.$utils(), m = (n || "YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g, function(r) {
          switch (r) {
            case "Q":
              return Math.ceil((e.$M + 1) / 3);
            case "Do":
              return c.ordinal(e.$D);
            case "gggg":
              return e.weekYear();
            case "GGGG":
              return e.isoWeekYear();
            case "wo":
              return c.ordinal(e.week(), "W");
            case "w":
            case "ww":
              return a.s(e.week(), r === "w" ? 1 : 2, "0");
            case "W":
            case "WW":
              return a.s(e.isoWeek(), r === "W" ? 1 : 2, "0");
            case "k":
            case "kk":
              return a.s(String(e.$H === 0 ? 24 : e.$H), r === "k" ? 1 : 2, "0");
            case "X":
              return Math.floor(e.$d.getTime() / 1e3);
            case "x":
              return e.$d.getTime();
            case "z":
              return "[" + e.offsetName() + "]";
            case "zzz":
              return "[" + e.offsetName("long") + "]";
            default:
              return r;
          }
        });
        return s.bind(this)(m);
      };
    };
  });
})(i);
var g = i.exports;
const W = /* @__PURE__ */ l(g);
export {
  W as default
};
