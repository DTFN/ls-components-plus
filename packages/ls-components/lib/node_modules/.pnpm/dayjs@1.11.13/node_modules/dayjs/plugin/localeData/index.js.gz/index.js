var g = Object.defineProperty;
var r = (i, m) => g(i, "name", { value: m, configurable: !0 });
import { commonjsGlobal as F, getDefaultExportFromCjs as O } from "../../../../../../../_virtual/_commonjsHelpers/index.js";
import { __module as y } from "../../../../../../../_virtual/localeData/index.js";
(function(i, m) {
  (function(M, s) {
    i.exports = s();
  })(F, function() {
    return function(M, s, e) {
      var p = s.prototype, l = /* @__PURE__ */ r(function(n) {
        return n && (n.indexOf ? n : n.s);
      }, "o"), o = /* @__PURE__ */ r(function(n, t, f, k, c) {
        var u = n.name ? n : n.$locale(), D = l(u[t]), x = l(u[f]), d = D || x.map(function(w) {
          return w.slice(0, k);
        });
        if (!c) return d;
        var v = u.weekStart;
        return d.map(function(w, $) {
          return d[($ + (v || 0)) % 7];
        });
      }, "u"), a = /* @__PURE__ */ r(function() {
        return e.Ls[e.locale()];
      }, "i"), h = /* @__PURE__ */ r(function(n, t) {
        return n.formats[t] || function(f) {
          return f.replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, function(k, c, u) {
            return c || u.slice(1);
          });
        }(n.formats[t.toUpperCase()]);
      }, "a"), S = /* @__PURE__ */ r(function() {
        var n = this;
        return { months: /* @__PURE__ */ r(function(t) {
          return t ? t.format("MMMM") : o(n, "months");
        }, "months"), monthsShort: /* @__PURE__ */ r(function(t) {
          return t ? t.format("MMM") : o(n, "monthsShort", "months", 3);
        }, "monthsShort"), firstDayOfWeek: /* @__PURE__ */ r(function() {
          return n.$locale().weekStart || 0;
        }, "firstDayOfWeek"), weekdays: /* @__PURE__ */ r(function(t) {
          return t ? t.format("dddd") : o(n, "weekdays");
        }, "weekdays"), weekdaysMin: /* @__PURE__ */ r(function(t) {
          return t ? t.format("dd") : o(n, "weekdaysMin", "weekdays", 2);
        }, "weekdaysMin"), weekdaysShort: /* @__PURE__ */ r(function(t) {
          return t ? t.format("ddd") : o(n, "weekdaysShort", "weekdays", 3);
        }, "weekdaysShort"), longDateFormat: /* @__PURE__ */ r(function(t) {
          return h(n.$locale(), t);
        }, "longDateFormat"), meridiem: this.$locale().meridiem, ordinal: this.$locale().ordinal };
      }, "s");
      p.localeData = function() {
        return S.bind(this)();
      }, e.localeData = function() {
        var n = a();
        return { firstDayOfWeek: /* @__PURE__ */ r(function() {
          return n.weekStart || 0;
        }, "firstDayOfWeek"), weekdays: /* @__PURE__ */ r(function() {
          return e.weekdays();
        }, "weekdays"), weekdaysShort: /* @__PURE__ */ r(function() {
          return e.weekdaysShort();
        }, "weekdaysShort"), weekdaysMin: /* @__PURE__ */ r(function() {
          return e.weekdaysMin();
        }, "weekdaysMin"), months: /* @__PURE__ */ r(function() {
          return e.months();
        }, "months"), monthsShort: /* @__PURE__ */ r(function() {
          return e.monthsShort();
        }, "monthsShort"), longDateFormat: /* @__PURE__ */ r(function(t) {
          return h(n, t);
        }, "longDateFormat"), meridiem: n.meridiem, ordinal: n.ordinal };
      }, e.months = function() {
        return o(a(), "months");
      }, e.monthsShort = function() {
        return o(a(), "monthsShort", "months", 3);
      }, e.weekdays = function(n) {
        return o(a(), "weekdays", null, null, n);
      }, e.weekdaysShort = function(n) {
        return o(a(), "weekdaysShort", "weekdays", 3, n);
      }, e.weekdaysMin = function(n) {
        return o(a(), "weekdaysMin", "weekdays", 2, n);
      };
    };
  });
})(y);
var b = y.exports;
const W = /* @__PURE__ */ O(b);
export {
  W as default
};
