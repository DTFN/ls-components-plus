var I = Object.defineProperty;
var o = (u, n) => I(u, "name", { value: n, configurable: !0 });
import { noop as x, toValue as k, isObject as j, tryOnScopeDispose as F, toRef as B, useIntervalFn as H, isClient as A, isWorker as U } from "../../../../../@vueuse_shared@12.0.0_typescript@5.5.4/node_modules/@vueuse/shared/index/index.js";
import { watch as G, ref as L } from "vue";
const V = A ? window : void 0;
function $(u) {
  var n;
  const s = k(u);
  return (n = s == null ? void 0 : s.$el) != null ? n : s;
}
o($, "unrefElement");
function q(...u) {
  let n, s, a, v;
  if (typeof u[0] == "string" || Array.isArray(u[0]) ? ([s, a, v] = u, n = V) : [n, s, a, v] = u, !n)
    return x;
  Array.isArray(s) || (s = [s]), Array.isArray(a) || (a = [a]);
  const d = [], y = /* @__PURE__ */ o(() => {
    d.forEach((r) => r()), d.length = 0;
  }, "cleanup"), N = /* @__PURE__ */ o((r, t, f, c) => (r.addEventListener(t, f, c), () => r.removeEventListener(t, f, c)), "register"), T = G(
    () => [$(n), k(v)],
    ([r, t]) => {
      if (y(), !r)
        return;
      const f = j(t) ? { ...t } : t;
      d.push(
        ...s.flatMap((c) => a.map((E) => N(r, c, E, f)))
      );
    },
    { immediate: !0, flush: "post" }
  ), p = /* @__PURE__ */ o(() => {
    T(), y();
  }, "stop");
  return F(p), p;
}
o(q, "useEventListener");
const M = "ping";
function R(u) {
  return u === !0 ? {} : u;
}
o(R, "resolveNestedOptions");
function Q(u, n = {}) {
  const {
    onConnected: s,
    onDisconnected: a,
    onError: v,
    onMessage: d,
    immediate: y = !0,
    autoClose: N = !0,
    protocols: T = []
  } = n, p = L(null), r = L("CLOSED"), t = L(), f = B(u);
  let c, E, b = !1, g = 0, C = [], O;
  const W = /* @__PURE__ */ o(() => {
    if (C.length && t.value && r.value === "OPEN") {
      for (const e of C)
        t.value.send(e);
      C = [];
    }
  }, "_sendBuffer"), P = /* @__PURE__ */ o(() => {
    clearTimeout(O), O = void 0;
  }, "resetHeartbeat"), h = /* @__PURE__ */ o((e = 1e3, l) => {
    !A || !t.value || (b = !0, P(), c == null || c(), t.value.close(e, l), t.value = void 0);
  }, "close"), _ = /* @__PURE__ */ o((e, l = !0) => !t.value || r.value !== "OPEN" ? (l && C.push(e), !1) : (W(), t.value.send(e), !0), "send"), S = /* @__PURE__ */ o(() => {
    if (b || typeof f.value > "u")
      return;
    const e = new WebSocket(f.value, T);
    t.value = e, r.value = "CONNECTING", e.onopen = () => {
      r.value = "OPEN", g = 0, s == null || s(e), E == null || E(), W();
    }, e.onclose = (l) => {
      if (r.value = "CLOSED", a == null || a(e, l), !b && n.autoReconnect && (t.value == null || e === t.value)) {
        const {
          retries: i = -1,
          delay: m = 1e3,
          onFailed: w
        } = R(n.autoReconnect);
        typeof i == "number" && (i < 0 || g < i) ? (g += 1, setTimeout(S, m)) : typeof i == "function" && i() ? setTimeout(S, m) : w == null || w();
      }
    }, e.onerror = (l) => {
      v == null || v(e, l);
    }, e.onmessage = (l) => {
      if (n.heartbeat) {
        P();
        const {
          message: i = M,
          responseMessage: m = i
        } = R(n.heartbeat);
        if (l.data === m)
          return;
      }
      p.value = l.data, d == null || d(e, l);
    };
  }, "_init");
  if (n.heartbeat) {
    const {
      message: e = M,
      interval: l = 1e3,
      pongTimeout: i = 1e3
    } = R(n.heartbeat), { pause: m, resume: w } = H(
      () => {
        _(e, !1), O == null && (O = setTimeout(() => {
          h(), b = !1;
        }, i));
      },
      l,
      { immediate: !1 }
    );
    c = m, E = w;
  }
  N && (A && q("beforeunload", () => h()), F(h));
  const D = /* @__PURE__ */ o(() => {
    !A && !U || (h(), b = !1, g = 0, S());
  }, "open");
  return y && D(), G(f, D), {
    data: p,
    status: r,
    close: h,
    send: _,
    open: D,
    ws: t
  };
}
o(Q, "useWebSocket");
export {
  V as defaultWindow,
  A as isClient,
  j as isObject,
  U as isWorker,
  x as noop,
  B as toRef,
  k as toValue,
  F as tryOnScopeDispose,
  $ as unrefElement,
  q as useEventListener,
  H as useIntervalFn,
  Q as useWebSocket
};
