var i = Object.defineProperty;
var e = (t, c) => i(t, "name", { value: c, configurable: !0 });
/**
* @vue/shared v3.5.13
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
process.env.NODE_ENV !== "production" && Object.freeze({});
process.env.NODE_ENV !== "production" && Object.freeze([]);
const j = /* @__PURE__ */ e(() => {
}, "NOOP"), p = Object.prototype.hasOwnProperty, l = /* @__PURE__ */ e((t, c) => p.call(t, c), "hasOwn"), g = Array.isArray, f = /* @__PURE__ */ e((t) => r(t) === "[object Date]", "isDate"), n = /* @__PURE__ */ e((t) => typeof t == "function", "isFunction"), w = /* @__PURE__ */ e((t) => typeof t == "string", "isString"), a = /* @__PURE__ */ e((t) => t !== null && typeof t == "object", "isObject"), E = /* @__PURE__ */ e((t) => (a(t) || n(t)) && n(t.then) && n(t.catch), "isPromise"), O = Object.prototype.toString, r = /* @__PURE__ */ e((t) => O.call(t), "toTypeString"), z = /* @__PURE__ */ e((t) => r(t).slice(8, -1), "toRawType"), A = /* @__PURE__ */ e((t) => r(t) === "[object Object]", "isPlainObject"), s = /* @__PURE__ */ e((t) => {
  const c = /* @__PURE__ */ Object.create(null);
  return (o) => c[o] || (c[o] = t(o));
}, "cacheStringFunction"), h = /-(\w)/g, N = s(
  (t) => t.replace(h, (c, o) => o ? o.toUpperCase() : "")
), y = /\B([A-Z])/g, P = s(
  (t) => t.replace(y, "-$1").toLowerCase()
), S = s((t) => t.charAt(0).toUpperCase() + t.slice(1));
export {
  j as NOOP,
  N as camelize,
  S as capitalize,
  l as hasOwn,
  P as hyphenate,
  g as isArray,
  f as isDate,
  n as isFunction,
  a as isObject,
  A as isPlainObject,
  E as isPromise,
  w as isString,
  O as objectToString,
  z as toRawType,
  r as toTypeString
};
