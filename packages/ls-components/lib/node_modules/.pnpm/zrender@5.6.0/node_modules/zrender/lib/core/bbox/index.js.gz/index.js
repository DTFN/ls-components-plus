var J = Object.defineProperty;
var C = (a, c) => J(a, "name", { value: c, configurable: !0 });
import { create as z, min as K, max as N } from "../vector/index.js";
import { cubicExtrema as O, cubicAt as R, quadraticAt as T, quadraticExtremum as U } from "../curve/index.js";
var b = Math.min, I = Math.max, S = Math.sin, j = Math.cos, p = Math.PI * 2, D = z(), L = z(), Q = z();
function Y(a, c, u) {
  if (a.length !== 0) {
    for (var t = a[0], r = t[0], v = t[0], M = t[1], i = t[1], f = 1; f < a.length; f++)
      t = a[f], r = b(r, t[0]), v = I(v, t[0]), M = b(M, t[1]), i = I(i, t[1]);
    c[0] = r, c[1] = M, u[0] = v, u[1] = i;
  }
}
C(Y, "fromPoints");
function Z(a, c, u, t, r, v) {
  r[0] = b(a, u), r[1] = b(c, t), v[0] = I(a, u), v[1] = I(c, t);
}
C(Z, "fromLine");
var G = [], H = [];
function _(a, c, u, t, r, v, M, i, f, o) {
  var E = O, P = R, q = E(a, u, r, M, G);
  f[0] = 1 / 0, f[1] = 1 / 0, o[0] = -1 / 0, o[1] = -1 / 0;
  for (var h = 0; h < q; h++) {
    var B = P(a, u, r, M, G[h]);
    f[0] = b(B, f[0]), o[0] = I(B, o[0]);
  }
  q = E(c, t, v, i, H);
  for (var h = 0; h < q; h++) {
    var F = P(c, t, v, i, H[h]);
    f[1] = b(F, f[1]), o[1] = I(F, o[1]);
  }
  f[0] = b(a, f[0]), o[0] = I(a, o[0]), f[0] = b(M, f[0]), o[0] = I(M, o[0]), f[1] = b(c, f[1]), o[1] = I(c, o[1]), f[1] = b(i, f[1]), o[1] = I(i, o[1]);
}
C(_, "fromCubic");
function k(a, c, u, t, r, v, M, i) {
  var f = U, o = T, E = I(b(f(a, u, r), 1), 0), P = I(b(f(c, t, v), 1), 0), q = o(a, u, r, E), h = o(c, t, v, P);
  M[0] = b(a, r, q), M[1] = b(c, v, h), i[0] = I(a, r, q), i[1] = I(c, v, h);
}
C(k, "fromQuadratic");
function w(a, c, u, t, r, v, M, i, f) {
  var o = K, E = N, P = Math.abs(r - v);
  if (P % p < 1e-4 && P > 1e-4) {
    i[0] = a - u, i[1] = c - t, f[0] = a + u, f[1] = c + t;
    return;
  }
  if (D[0] = j(r) * u + a, D[1] = S(r) * t + c, L[0] = j(v) * u + a, L[1] = S(v) * t + c, o(i, D, L), E(f, D, L), r = r % p, r < 0 && (r = r + p), v = v % p, v < 0 && (v = v + p), r > v && !M ? v += p : r < v && M && (r += p), M) {
    var q = v;
    v = r, r = q;
  }
  for (var h = 0; h < v; h += Math.PI / 2)
    h > r && (Q[0] = j(h) * u + a, Q[1] = S(h) * t + c, o(i, Q, i), E(f, Q, f));
}
C(w, "fromArc");
export {
  w as fromArc,
  _ as fromCubic,
  Z as fromLine,
  Y as fromPoints,
  k as fromQuadratic
};
