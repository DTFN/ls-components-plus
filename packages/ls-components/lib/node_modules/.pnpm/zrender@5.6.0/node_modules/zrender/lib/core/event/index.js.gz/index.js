var d = Object.defineProperty;
var i = (t, r) => d(t, "name", { value: r, configurable: !0 });
import s from "../env/index.js";
import { isCanvasEl as p, transformCoordWithViewport as h } from "../dom/index.js";
var X = /^(?:mouse|pointer|contextmenu|drag|drop)|click/, f = [], z = s.browser.firefox && +s.browser.version.split(".")[0] < 39;
function c(t, r, n, e) {
  return n = n || {}, e ? u(t, r, n) : z && r.layerX != null && r.layerX !== r.offsetX ? (n.zrX = r.layerX, n.zrY = r.layerY) : r.offsetX != null ? (n.zrX = r.offsetX, n.zrY = r.offsetY) : u(t, r, n), n;
}
i(c, "clientToLocal");
function u(t, r, n) {
  if (s.domSupported && t.getBoundingClientRect) {
    var e = r.clientX, l = r.clientY;
    if (p(t)) {
      var a = t.getBoundingClientRect();
      n.zrX = e - a.left, n.zrY = l - a.top;
      return;
    } else if (h(f, t, e, l)) {
      n.zrX = f[0], n.zrY = f[1];
      return;
    }
  }
  n.zrX = n.zrY = 0;
}
i(u, "calculateZrXY");
function g(t) {
  return t || window.event;
}
i(g, "getNativeEvent");
function y(t, r, n) {
  if (r = g(r), r.zrX != null)
    return r;
  var e = r.type, l = e && e.indexOf("touch") >= 0;
  if (l) {
    var v = e !== "touchend" ? r.targetTouches[0] : r.changedTouches[0];
    v && c(t, v, r, n);
  } else {
    c(t, r, r, n);
    var a = Y(r);
    r.zrDelta = a ? a / 120 : -(r.detail || 0) / 3;
  }
  var o = r.button;
  return r.which == null && o !== void 0 && X.test(r.type) && (r.which = o & 1 ? 1 : o & 2 ? 3 : o & 4 ? 2 : 0), r;
}
i(y, "normalizeEvent");
function Y(t) {
  var r = t.wheelDelta;
  if (r)
    return r;
  var n = t.deltaX, e = t.deltaY;
  if (n == null || e == null)
    return r;
  var l = Math.abs(e !== 0 ? e : n), a = e > 0 ? -1 : e < 0 ? 1 : n > 0 ? -1 : 1;
  return 3 * l * a;
}
i(Y, "getWheelDeltaMayPolyfill");
function b(t, r, n, e) {
  t.addEventListener(r, n, e);
}
i(b, "addEventListener");
function M(t, r, n, e) {
  t.removeEventListener(r, n, e);
}
i(M, "removeEventListener");
var O = /* @__PURE__ */ i(function(t) {
  t.preventDefault(), t.stopPropagation(), t.cancelBubble = !0;
}, "stop");
function T(t) {
  return t.which === 2 || t.which === 3;
}
i(T, "isMiddleOrRightButtonOnMouseUpDown");
export {
  b as addEventListener,
  c as clientToLocal,
  g as getNativeEvent,
  T as isMiddleOrRightButtonOnMouseUpDown,
  y as normalizeEvent,
  M as removeEventListener,
  O as stop
};
