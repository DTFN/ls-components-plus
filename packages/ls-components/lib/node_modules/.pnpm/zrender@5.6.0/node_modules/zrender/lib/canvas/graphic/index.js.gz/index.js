var x = Object.defineProperty;
var l = (a, r) => x(a, "name", { value: r, configurable: !0 });
import { DEFAULT_COMMON_STYLE as E } from "../../graphic/Displayable/index.js";
import c from "../../core/PathProxy/index.js";
import { createOrUpdateImage as j, isImageReady as q } from "../../graphic/helper/image/index.js";
import { isClipPathChanged as rr, getCanvasGradient as I } from "../helper/index.js";
import L from "../../graphic/Path/index.js";
import ar from "../../graphic/Image/index.js";
import ir from "../../graphic/TSpan/index.js";
import { RADIAN_TO_DEGREE as er } from "../../core/util/index.js";
import { getLineDash as z } from "../dashStyle/index.js";
import { REDRAW_BIT as nr, SHAPE_CHANGED_BIT as fr } from "../../graphic/constants/index.js";
import { DEFAULT_FONT as tr } from "../../core/platform/index.js";
var or = new c(!0);
function D(a) {
  var r = a.stroke;
  return !(r == null || r === "none" || !(a.lineWidth > 0));
}
l(D, "styleHasStroke");
function M(a) {
  return typeof a == "string" && a !== "none";
}
l(M, "isValidStrokeFillStyle");
function P(a) {
  var r = a.fill;
  return r != null && r !== "none";
}
l(P, "styleHasFill");
function Y(a, r) {
  if (r.fillOpacity != null && r.fillOpacity !== 1) {
    var i = a.globalAlpha;
    a.globalAlpha = r.fillOpacity * r.opacity, a.fill(), a.globalAlpha = i;
  } else
    a.fill();
}
l(Y, "doFillPath");
function U(a, r) {
  if (r.strokeOpacity != null && r.strokeOpacity !== 1) {
    var i = a.globalAlpha;
    a.globalAlpha = r.strokeOpacity * r.opacity, a.stroke(), a.globalAlpha = i;
  } else
    a.stroke();
}
l(U, "doStrokePath");
function N(a, r, i) {
  var n = j(r.image, r.__image, i);
  if (q(n)) {
    var f = a.createPattern(n, r.repeat || "repeat");
    if (typeof DOMMatrix == "function" && f && f.setTransform) {
      var e = new DOMMatrix();
      e.translateSelf(r.x || 0, r.y || 0), e.rotateSelf(0, 0, (r.rotation || 0) * er), e.scaleSelf(r.scaleX || 1, r.scaleY || 1), f.setTransform(e);
    }
    return f;
  }
}
l(N, "createCanvasPattern");
function hr(a, r, i, n) {
  var f, e = D(i), o = P(i), h = i.strokePercent, t = h < 1, u = !r.path;
  (!r.silent || t) && u && r.createPathProxy();
  var v = r.path || or, s = r.__dirty;
  if (!n) {
    var g = i.fill, m = i.stroke, C = o && !!g.colorStops, w = e && !!m.colorStops, A = o && !!g.image, H = e && !!m.image, S = void 0, k = void 0, _ = void 0, B = void 0, p = void 0;
    (C || w) && (p = r.getBoundingRect()), C && (S = s ? I(a, g, p) : r.__canvasFillGradient, r.__canvasFillGradient = S), w && (k = s ? I(a, m, p) : r.__canvasStrokeGradient, r.__canvasStrokeGradient = k), A && (_ = s || !r.__canvasFillPattern ? N(a, g, r) : r.__canvasFillPattern, r.__canvasFillPattern = _), H && (B = s || !r.__canvasStrokePattern ? N(a, m, r) : r.__canvasStrokePattern, r.__canvasStrokePattern = _), C ? a.fillStyle = S : A && (_ ? a.fillStyle = _ : o = !1), w ? a.strokeStyle = k : H && (B ? a.strokeStyle = B : e = !1);
  }
  var R = r.getGlobalScale();
  v.setScale(R[0], R[1], r.segmentIgnoreThreshold);
  var T, F;
  a.setLineDash && i.lineDash && (f = z(r), T = f[0], F = f[1]);
  var W = !0;
  (u || s & fr) && (v.setDPR(a.dpr), t ? v.setContext(null) : (v.setContext(a), W = !1), v.reset(), r.buildPath(v, r.shape, n), v.toStatic(), r.pathUpdated()), W && v.rebuildPath(a, t ? h : 1), T && (a.setLineDash(T), a.lineDashOffset = F), n || (i.strokeFirst ? (e && U(a, i), o && Y(a, i)) : (o && Y(a, i), e && U(a, i))), T && a.setLineDash([]);
}
l(hr, "brushPath");
function vr(a, r, i) {
  var n = r.__image = j(i.image, r.__image, r, r.onload);
  if (!(!n || !q(n))) {
    var f = i.x || 0, e = i.y || 0, o = r.getWidth(), h = r.getHeight(), t = n.width / n.height;
    if (o == null && h != null ? o = h * t : h == null && o != null ? h = o / t : o == null && h == null && (o = n.width, h = n.height), i.sWidth && i.sHeight) {
      var u = i.sx || 0, v = i.sy || 0;
      a.drawImage(n, u, v, i.sWidth, i.sHeight, f, e, o, h);
    } else if (i.sx && i.sy) {
      var u = i.sx, v = i.sy, s = o - u, g = h - v;
      a.drawImage(n, u, v, s, g, f, e, o, h);
    } else
      a.drawImage(n, f, e, o, h);
  }
}
l(vr, "brushImage");
function lr(a, r, i) {
  var n, f = i.text;
  if (f != null && (f += ""), f) {
    a.font = i.font || tr, a.textAlign = i.textAlign, a.textBaseline = i.textBaseline;
    var e = void 0, o = void 0;
    a.setLineDash && i.lineDash && (n = z(r), e = n[0], o = n[1]), e && (a.setLineDash(e), a.lineDashOffset = o), i.strokeFirst ? (D(i) && a.strokeText(f, i.x, i.y), P(i) && a.fillText(f, i.x, i.y)) : (P(i) && a.fillText(f, i.x, i.y), D(i) && a.strokeText(f, i.x, i.y)), e && a.setLineDash([]);
  }
}
l(lr, "brushText");
var y = ["shadowBlur", "shadowOffsetX", "shadowOffsetY"], X = [
  ["lineCap", "butt"],
  ["lineJoin", "miter"],
  ["miterLimit", 10]
];
function Q(a, r, i, n, f) {
  var e = !1;
  if (!n && (i = i || {}, r === i))
    return !1;
  if (n || r.opacity !== i.opacity) {
    d(a, f), e = !0;
    var o = Math.max(Math.min(r.opacity, 1), 0);
    a.globalAlpha = isNaN(o) ? E.opacity : o;
  }
  (n || r.blend !== i.blend) && (e || (d(a, f), e = !0), a.globalCompositeOperation = r.blend || E.blend);
  for (var h = 0; h < y.length; h++) {
    var t = y[h];
    (n || r[t] !== i[t]) && (e || (d(a, f), e = !0), a[t] = a.dpr * (r[t] || 0));
  }
  return (n || r.shadowColor !== i.shadowColor) && (e || (d(a, f), e = !0), a.shadowColor = r.shadowColor || E.shadowColor), e;
}
l(Q, "bindCommonProps");
function Z(a, r, i, n, f) {
  var e = b(r, f.inHover), o = n ? null : i && b(i, f.inHover) || {};
  if (e === o)
    return !1;
  var h = Q(a, e, o, n, f);
  if ((n || e.fill !== o.fill) && (h || (d(a, f), h = !0), M(e.fill) && (a.fillStyle = e.fill)), (n || e.stroke !== o.stroke) && (h || (d(a, f), h = !0), M(e.stroke) && (a.strokeStyle = e.stroke)), (n || e.opacity !== o.opacity) && (h || (d(a, f), h = !0), a.globalAlpha = e.opacity == null ? 1 : e.opacity), r.hasStroke()) {
    var t = e.lineWidth, u = t / (e.strokeNoScale && r.getLineScale ? r.getLineScale() : 1);
    a.lineWidth !== u && (h || (d(a, f), h = !0), a.lineWidth = u);
  }
  for (var v = 0; v < X.length; v++) {
    var s = X[v], g = s[0];
    (n || e[g] !== o[g]) && (h || (d(a, f), h = !0), a[g] = e[g] || s[1]);
  }
  return h;
}
l(Z, "bindPathAndTextCommonStyle");
function ur(a, r, i, n, f) {
  return Q(a, b(r, f.inHover), i && b(i, f.inHover), n, f);
}
l(ur, "bindImageStyle");
function $(a, r) {
  var i = r.transform, n = a.dpr || 1;
  i ? a.setTransform(n * i[0], n * i[1], n * i[2], n * i[3], n * i[4], n * i[5]) : a.setTransform(n, 0, 0, n, 0, 0);
}
l($, "setContextTransform");
function sr(a, r, i) {
  for (var n = !1, f = 0; f < a.length; f++) {
    var e = a[f];
    n = n || e.isZeroArea(), $(r, e), r.beginPath(), e.buildPath(r, e.shape), r.clip();
  }
  i.allClipped = n;
}
l(sr, "updateClipStatus");
function dr(a, r) {
  return a && r ? a[0] !== r[0] || a[1] !== r[1] || a[2] !== r[2] || a[3] !== r[3] || a[4] !== r[4] || a[5] !== r[5] : !(!a && !r);
}
l(dr, "isTransformChanged");
var G = 1, J = 2, K = 3, V = 4;
function gr(a) {
  var r = P(a), i = D(a);
  return !(a.lineDash || !(+r ^ +i) || r && typeof a.fill != "string" || i && typeof a.stroke != "string" || a.strokePercent < 1 || a.strokeOpacity < 1 || a.fillOpacity < 1);
}
l(gr, "canPathBatch");
function d(a, r) {
  r.batchFill && a.fill(), r.batchStroke && a.stroke(), r.batchFill = "", r.batchStroke = "";
}
l(d, "flushPathDrawn");
function b(a, r) {
  return r && a.__hoverStyle || a.style;
}
l(b, "getStyle");
function Or(a, r) {
  O(a, r, { inHover: !1, viewWidth: 0, viewHeight: 0 }, !0);
}
l(Or, "brushSingle");
function O(a, r, i, n) {
  var f = r.transform;
  if (!r.shouldBePainted(i.viewWidth, i.viewHeight, !1, !1)) {
    r.__dirty &= ~nr, r.__isRendered = !1;
    return;
  }
  var e = r.__clipPaths, o = i.prevElClipPaths, h = !1, t = !1;
  if ((!o || rr(e, o)) && (o && o.length && (d(a, i), a.restore(), t = h = !0, i.prevElClipPaths = null, i.allClipped = !1, i.prevEl = null), e && e.length && (d(a, i), a.save(), sr(e, a, i), h = !0), i.prevElClipPaths = e), i.allClipped) {
    r.__isRendered = !1;
    return;
  }
  r.beforeBrush && r.beforeBrush(), r.innerBeforeBrush();
  var u = i.prevEl;
  u || (t = h = !0);
  var v = r instanceof L && r.autoBatch && gr(r.style);
  h || dr(f, u.transform) ? (d(a, i), $(a, r)) : v || d(a, i);
  var s = b(r, i.inHover);
  r instanceof L ? (i.lastDrawType !== G && (t = !0, i.lastDrawType = G), Z(a, r, u, t, i), (!v || !i.batchFill && !i.batchStroke) && a.beginPath(), hr(a, r, s, v), v && (i.batchFill = s.fill || "", i.batchStroke = s.stroke || "")) : r instanceof ir ? (i.lastDrawType !== K && (t = !0, i.lastDrawType = K), Z(a, r, u, t, i), lr(a, r, s)) : r instanceof ar ? (i.lastDrawType !== J && (t = !0, i.lastDrawType = J), ur(a, r, u, t, i), vr(a, r, s)) : r.getTemporalDisplayables && (i.lastDrawType !== V && (t = !0, i.lastDrawType = V), _r(a, r, i)), v && n && d(a, i), r.innerAfterBrush(), r.afterBrush && r.afterBrush(), i.prevEl = r, r.__dirty = 0, r.__isRendered = !0;
}
l(O, "brush");
function _r(a, r, i) {
  var n = r.getDisplayables(), f = r.getTemporalDisplayables();
  a.save();
  var e = {
    prevElClipPaths: null,
    prevEl: null,
    allClipped: !1,
    viewWidth: i.viewWidth,
    viewHeight: i.viewHeight,
    inHover: i.inHover
  }, o, h;
  for (o = r.getCursor(), h = n.length; o < h; o++) {
    var t = n[o];
    t.beforeBrush && t.beforeBrush(), t.innerBeforeBrush(), O(a, t, e, o === h - 1), t.innerAfterBrush(), t.afterBrush && t.afterBrush(), e.prevEl = t;
  }
  for (var u = 0, v = f.length; u < v; u++) {
    var t = f[u];
    t.beforeBrush && t.beforeBrush(), t.innerBeforeBrush(), O(a, t, e, u === v - 1), t.innerAfterBrush(), t.afterBrush && t.afterBrush(), e.prevEl = t;
  }
  r.clearTemporalDisplayables(), r.notClear = !0, a.restore();
}
l(_r, "brushIncremental");
export {
  O as brush,
  Or as brushSingle,
  N as createCanvasPattern
};
