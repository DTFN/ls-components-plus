var U = Object.defineProperty;
var y = (n, t) => U(n, "name", { value: t, configurable: !0 });
import { devicePixelRatio as z } from "../../config/index.js";
import { each as O, merge as I, logError as D, indexOf as j, extend as q, disableUserSelect as Y } from "../../core/util/index.js";
import M from "../Layer/index.js";
import G from "../../animation/requestAnimationFrame/index.js";
import J from "../../core/env/index.js";
import { brush as R, brushSingle as K } from "../graphic/index.js";
import { REDRAW_BIT as Q } from "../../graphic/constants/index.js";
import { getSize as b } from "../helper/index.js";
var W = 1e5, g = 314159, E = 0.01, X = 1e-3;
function $(n) {
  return n ? n.__builtin__ ? !0 : !(typeof n.resize != "function" || typeof n.refresh != "function") : !1;
}
y($, "isLayerValid");
function tt(n, t) {
  var i = document.createElement("div");
  return i.style.cssText = [
    "position:relative",
    "width:" + n + "px",
    "height:" + t + "px",
    "padding:0",
    "margin:0",
    "border-width:0"
  ].join(";") + ";", i;
}
y(tt, "createRoot");
var ft = function() {
  function n(t, i, e, r) {
    this.type = "canvas", this._zlevelList = [], this._prevDisplayList = [], this._layers = {}, this._layerConfig = {}, this._needsManuallyCompositing = !1, this.type = "canvas";
    var s = !t.nodeName || t.nodeName.toUpperCase() === "CANVAS";
    this._opts = e = q({}, e || {}), this.dpr = e.devicePixelRatio || z, this._singleCanvas = s, this.root = t;
    var a = t.style;
    a && (Y(t), t.innerHTML = ""), this.storage = i;
    var f = this._zlevelList;
    this._prevDisplayList = [];
    var o = this._layers;
    if (s) {
      var h = t, _ = h.width, p = h.height;
      e.width != null && (_ = e.width), e.height != null && (p = e.height), this.dpr = e.devicePixelRatio || 1, h.width = _ * this.dpr, h.height = p * this.dpr, this._width = _, this._height = p;
      var u = new M(h, this, this.dpr);
      u.__builtin__ = !0, u.initContext(), o[g] = u, u.zlevel = g, f.push(g), this._domRoot = t;
    } else {
      this._width = b(t, 0, e), this._height = b(t, 1, e);
      var d = this._domRoot = tt(this._width, this._height);
      t.appendChild(d);
    }
  }
  return y(n, "CanvasPainter"), n.prototype.getType = function() {
    return "canvas";
  }, n.prototype.isSingleCanvas = function() {
    return this._singleCanvas;
  }, n.prototype.getViewportRoot = function() {
    return this._domRoot;
  }, n.prototype.getViewportRootOffset = function() {
    var t = this.getViewportRoot();
    if (t)
      return {
        offsetLeft: t.offsetLeft || 0,
        offsetTop: t.offsetTop || 0
      };
  }, n.prototype.refresh = function(t) {
    var i = this.storage.getDisplayList(!0), e = this._prevDisplayList, r = this._zlevelList;
    this._redrawId = Math.random(), this._paintList(i, e, t, this._redrawId);
    for (var s = 0; s < r.length; s++) {
      var a = r[s], f = this._layers[a];
      if (!f.__builtin__ && f.refresh) {
        var o = s === 0 ? this._backgroundColor : null;
        f.refresh(o);
      }
    }
    return this._opts.useDirtyRect && (this._prevDisplayList = i.slice()), this;
  }, n.prototype.refreshHover = function() {
    this._paintHoverList(this.storage.getDisplayList(!1));
  }, n.prototype._paintHoverList = function(t) {
    var i = t.length, e = this._hoverlayer;
    if (e && e.clear(), !!i) {
      for (var r = {
        inHover: !0,
        viewWidth: this._width,
        viewHeight: this._height
      }, s, a = 0; a < i; a++) {
        var f = t[a];
        f.__inHover && (e || (e = this._hoverlayer = this.getLayer(W)), s || (s = e.ctx, s.save()), R(s, f, r, a === i - 1));
      }
      s && s.restore();
    }
  }, n.prototype.getHoverLayer = function() {
    return this.getLayer(W);
  }, n.prototype.paintOne = function(t, i) {
    K(t, i);
  }, n.prototype._paintList = function(t, i, e, r) {
    if (this._redrawId === r) {
      e = e || !1, this._updateLayerStatus(t);
      var s = this._doPaintList(t, i, e), a = s.finished, f = s.needsRefreshHover;
      if (this._needsManuallyCompositing && this._compositeManually(), f && this._paintHoverList(t), a)
        this.eachLayer(function(d) {
          d.afterBrush && d.afterBrush();
        });
      else {
        var o = this;
        G(function() {
          o._paintList(t, i, e, r);
        });
      }
    }
  }, n.prototype._compositeManually = function() {
    var t = this.getLayer(g).ctx, i = this._domRoot.width, e = this._domRoot.height;
    t.clearRect(0, 0, i, e), this.eachBuiltinLayer(function(r) {
      r.virtual && t.drawImage(r.dom, 0, 0, i, e);
    });
  }, n.prototype._doPaintList = function(t, i, e) {
    for (var r = this, s = [], a = this._opts.useDirtyRect, f = 0; f < this._zlevelList.length; f++) {
      var o = this._zlevelList[f], d = this._layers[o];
      d.__builtin__ && d !== this._hoverlayer && (d.__dirty || e) && s.push(d);
    }
    for (var h = !0, _ = !1, p = /* @__PURE__ */ y(function(L) {
      var v = s[L], l = v.ctx, m = a && v.createRepaintRects(t, i, u._width, u._height), x = e ? v.__startIndex : v.__drawIndex, N = !e && v.incremental && Date.now, Z = N && Date.now(), T = v.zlevel === u._zlevelList[0] ? u._backgroundColor : null;
      if (v.__startIndex === v.__endIndex)
        v.clear(!1, T, m);
      else if (x === v.__startIndex) {
        var B = t[x];
        (!B.incremental || !B.notClear || e) && v.clear(!1, T, m);
      }
      x === -1 && (console.error("For some unknown reason. drawIndex is -1"), x = v.__startIndex);
      var c, S = /* @__PURE__ */ y(function(A) {
        var V = {
          inHover: !1,
          allClipped: !1,
          prevEl: null,
          viewWidth: r._width,
          viewHeight: r._height
        };
        for (c = x; c < v.__endIndex; c++) {
          var k = t[c];
          if (k.__inHover && (_ = !0), r._doPaintEl(k, v, a, A, V, c === v.__endIndex - 1), N) {
            var F = Date.now() - Z;
            if (F > 15)
              break;
          }
        }
        V.prevElClipPaths && l.restore();
      }, "repaint");
      if (m)
        if (m.length === 0)
          c = v.__endIndex;
        else
          for (var C = u.dpr, P = 0; P < m.length; ++P) {
            var w = m[P];
            l.save(), l.beginPath(), l.rect(w.x * C, w.y * C, w.width * C, w.height * C), l.clip(), S(w), l.restore();
          }
      else
        l.save(), S(), l.restore();
      v.__drawIndex = c, v.__drawIndex < v.__endIndex && (h = !1);
    }, "_loop_1"), u = this, H = 0; H < s.length; H++)
      p(H);
    return J.wxa && O(this._layers, function(L) {
      L && L.ctx && L.ctx.draw && L.ctx.draw();
    }), {
      finished: h,
      needsRefreshHover: _
    };
  }, n.prototype._doPaintEl = function(t, i, e, r, s, a) {
    var f = i.ctx;
    if (e) {
      var o = t.getPaintRect();
      (!r || o && o.intersect(r)) && (R(f, t, s, a), t.setPrevPaintRect(o));
    } else
      R(f, t, s, a);
  }, n.prototype.getLayer = function(t, i) {
    this._singleCanvas && !this._needsManuallyCompositing && (t = g);
    var e = this._layers[t];
    return e || (e = new M("zr_" + t, this, this.dpr), e.zlevel = t, e.__builtin__ = !0, this._layerConfig[t] ? I(e, this._layerConfig[t], !0) : this._layerConfig[t - E] && I(e, this._layerConfig[t - E], !0), i && (e.virtual = i), this.insertLayer(t, e), e.initContext()), e;
  }, n.prototype.insertLayer = function(t, i) {
    var e = this._layers, r = this._zlevelList, s = r.length, a = this._domRoot, f = null, o = -1;
    if (e[t]) {
      process.env.NODE_ENV !== "production" && D("ZLevel " + t + " has been used already");
      return;
    }
    if (!$(i)) {
      process.env.NODE_ENV !== "production" && D("Layer of zlevel " + t + " is not valid");
      return;
    }
    if (s > 0 && t > r[0]) {
      for (o = 0; o < s - 1 && !(r[o] < t && r[o + 1] > t); o++)
        ;
      f = e[r[o]];
    }
    if (r.splice(o + 1, 0, t), e[t] = i, !i.virtual)
      if (f) {
        var d = f.dom;
        d.nextSibling ? a.insertBefore(i.dom, d.nextSibling) : a.appendChild(i.dom);
      } else
        a.firstChild ? a.insertBefore(i.dom, a.firstChild) : a.appendChild(i.dom);
    i.painter || (i.painter = this);
  }, n.prototype.eachLayer = function(t, i) {
    for (var e = this._zlevelList, r = 0; r < e.length; r++) {
      var s = e[r];
      t.call(i, this._layers[s], s);
    }
  }, n.prototype.eachBuiltinLayer = function(t, i) {
    for (var e = this._zlevelList, r = 0; r < e.length; r++) {
      var s = e[r], a = this._layers[s];
      a.__builtin__ && t.call(i, a, s);
    }
  }, n.prototype.eachOtherLayer = function(t, i) {
    for (var e = this._zlevelList, r = 0; r < e.length; r++) {
      var s = e[r], a = this._layers[s];
      a.__builtin__ || t.call(i, a, s);
    }
  }, n.prototype.getLayers = function() {
    return this._layers;
  }, n.prototype._updateLayerStatus = function(t) {
    this.eachBuiltinLayer(function(_, p) {
      _.__dirty = _.__used = !1;
    });
    function i(_) {
      s && (s.__endIndex !== _ && (s.__dirty = !0), s.__endIndex = _);
    }
    if (y(i, "updatePrevLayer"), this._singleCanvas)
      for (var e = 1; e < t.length; e++) {
        var r = t[e];
        if (r.zlevel !== t[e - 1].zlevel || r.incremental) {
          this._needsManuallyCompositing = !0;
          break;
        }
      }
    var s = null, a = 0, f, o;
    for (o = 0; o < t.length; o++) {
      var r = t[o], d = r.zlevel, h = void 0;
      f !== d && (f = d, a = 0), r.incremental ? (h = this.getLayer(d + X, this._needsManuallyCompositing), h.incremental = !0, a = 1) : h = this.getLayer(d + (a > 0 ? E : 0), this._needsManuallyCompositing), h.__builtin__ || D("ZLevel " + d + " has been used by unkown layer " + h.id), h !== s && (h.__used = !0, h.__startIndex !== o && (h.__dirty = !0), h.__startIndex = o, h.incremental ? h.__drawIndex = -1 : h.__drawIndex = o, i(o), s = h), r.__dirty & Q && !r.__inHover && (h.__dirty = !0, h.incremental && h.__drawIndex < 0 && (h.__drawIndex = o));
    }
    i(o), this.eachBuiltinLayer(function(_, p) {
      !_.__used && _.getElementCount() > 0 && (_.__dirty = !0, _.__startIndex = _.__endIndex = _.__drawIndex = 0), _.__dirty && _.__drawIndex < 0 && (_.__drawIndex = _.__startIndex);
    });
  }, n.prototype.clear = function() {
    return this.eachBuiltinLayer(this._clearLayer), this;
  }, n.prototype._clearLayer = function(t) {
    t.clear();
  }, n.prototype.setBackgroundColor = function(t) {
    this._backgroundColor = t, O(this._layers, function(i) {
      i.setUnpainted();
    });
  }, n.prototype.configLayer = function(t, i) {
    if (i) {
      var e = this._layerConfig;
      e[t] ? I(e[t], i, !0) : e[t] = i;
      for (var r = 0; r < this._zlevelList.length; r++) {
        var s = this._zlevelList[r];
        if (s === t || s === t + E) {
          var a = this._layers[s];
          I(a, e[t], !0);
        }
      }
    }
  }, n.prototype.delLayer = function(t) {
    var i = this._layers, e = this._zlevelList, r = i[t];
    r && (r.dom.parentNode.removeChild(r.dom), delete i[t], e.splice(j(e, t), 1));
  }, n.prototype.resize = function(t, i) {
    if (this._domRoot.style) {
      var e = this._domRoot;
      e.style.display = "none";
      var r = this._opts, s = this.root;
      if (t != null && (r.width = t), i != null && (r.height = i), t = b(s, 0, r), i = b(s, 1, r), e.style.display = "", this._width !== t || i !== this._height) {
        e.style.width = t + "px", e.style.height = i + "px";
        for (var a in this._layers)
          this._layers.hasOwnProperty(a) && this._layers[a].resize(t, i);
        this.refresh(!0);
      }
      this._width = t, this._height = i;
    } else {
      if (t == null || i == null)
        return;
      this._width = t, this._height = i, this.getLayer(g).resize(t, i);
    }
    return this;
  }, n.prototype.clearLayer = function(t) {
    var i = this._layers[t];
    i && i.clear();
  }, n.prototype.dispose = function() {
    this.root.innerHTML = "", this.root = this.storage = this._domRoot = this._layers = null;
  }, n.prototype.getRenderedCanvas = function(t) {
    if (t = t || {}, this._singleCanvas && !this._compositeManually)
      return this._layers[g].dom;
    var i = new M("image", this, t.pixelRatio || this.dpr);
    i.initContext(), i.clear(!1, t.backgroundColor || this._backgroundColor);
    var e = i.ctx;
    if (t.pixelRatio <= this.dpr) {
      this.refresh();
      var r = i.dom.width, s = i.dom.height;
      this.eachLayer(function(_) {
        _.__builtin__ ? e.drawImage(_.dom, 0, 0, r, s) : _.renderToCanvas && (e.save(), _.renderToCanvas(e), e.restore());
      });
    } else
      for (var a = {
        inHover: !1,
        viewWidth: this._width,
        viewHeight: this._height
      }, f = this.storage.getDisplayList(!0), o = 0, d = f.length; o < d; o++) {
        var h = f[o];
        R(e, h, a, o === d - 1);
      }
    return i.dom;
  }, n.prototype.getWidth = function() {
    return this._width;
  }, n.prototype.getHeight = function() {
    return this._height;
  }, n;
}();
export {
  ft as default
};
