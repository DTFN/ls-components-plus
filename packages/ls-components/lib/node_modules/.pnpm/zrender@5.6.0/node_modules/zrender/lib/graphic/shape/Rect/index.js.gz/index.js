var l = Object.defineProperty;
var c = (i, r) => l(i, "name", { value: r, configurable: !0 });
import { __extends as s } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import y from "../../Path/index.js";
import { buildPath as a } from "../../helper/roundRect/index.js";
import { subPixelOptimizeRect as v } from "../../helper/subPixelOptimize/index.js";
var x = function() {
  function i() {
    this.x = 0, this.y = 0, this.width = 0, this.height = 0;
  }
  return c(i, "RectShape"), i;
}(), g = {}, m = function(i) {
  s(r, i);
  function r(h) {
    return i.call(this, h) || this;
  }
  return c(r, "Rect"), r.prototype.getDefaultShape = function() {
    return new x();
  }, r.prototype.buildPath = function(h, t) {
    var n, o, u, f;
    if (this.subPixelOptimize) {
      var e = v(g, t, this.style);
      n = e.x, o = e.y, u = e.width, f = e.height, e.r = t.r, t = e;
    } else
      n = t.x, o = t.y, u = t.width, f = t.height;
    t.r ? a(h, t) : h.rect(n, o, u, f);
  }, r.prototype.isZeroArea = function() {
    return !this.shape.width || !this.shape.height;
  }, r;
}(y);
m.prototype.type = "rect";
export {
  x as RectShape,
  m as default
};
