var N = Object.defineProperty;
var C = (s, t) => N(s, "name", { value: t, configurable: !0 });
import { __extends as Y } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import m from "../../graphic/Path/index.js";
import B from "../../core/PathProxy/index.js";
import j from "../transformPath/index.js";
import { extend as W } from "../../core/util/index.js";
var I = Math.sqrt, V = Math.sin, G = Math.cos, O = Math.PI;
function H(s) {
  return Math.sqrt(s[0] * s[0] + s[1] * s[1]);
}
C(H, "vMag");
function Z(s, t) {
  return (s[0] * t[0] + s[1] * t[1]) / (H(s) * H(t));
}
C(Z, "vRatio");
function U(s, t) {
  return (s[0] * t[1] < s[1] * t[0] ? -1 : 1) * Math.acos(Z(s, t));
}
C(U, "vAngle");
function X(s, t, a, n, h, d, u, v, L, F, R) {
  var g = L * (O / 180), i = G(g) * (s - a) / 2 + V(g) * (t - n) / 2, r = -1 * V(g) * (s - a) / 2 + G(g) * (t - n) / 2, q = i * i / (u * u) + r * r / (v * v);
  q > 1 && (u *= I(q), v *= I(q));
  var Q = (h === d ? -1 : 1) * I((u * u * (v * v) - u * u * (r * r) - v * v * (i * i)) / (u * u * (r * r) + v * v * (i * i))) || 0, e = Q * u * r / v, b = Q * -v * i / u, k = (s + a) / 2 + G(g) * e - V(g) * b, w = (t + n) / 2 + V(g) * e + G(g) * b, A = U([1, 0], [(i - e) / u, (r - b) / v]), S = [(i - e) / u, (r - b) / v], z = [(-1 * i - e) / u, (-1 * r - b) / v], D = U(S, z);
  if (Z(S, z) <= -1 && (D = O), Z(S, z) >= 1 && (D = 0), D < 0) {
    var l = Math.round(D / O * 1e6) / 1e6;
    D = O * 2 + l % 2 * O;
  }
  R.addData(F, k, w, u, v, A, D, g, d);
}
C(X, "processArc");
var _ = /([mlvhzcqtsa])([^mlvhzcqtsa]*)/ig, $ = /-?([0-9]*\.)?[0-9]+([eE]-?[0-9]+)?/g;
function P(s) {
  var t = new B();
  if (!s)
    return t;
  var a = 0, n = 0, h = a, d = n, u, v = B.CMD, L = s.match(_);
  if (!L)
    return t;
  for (var F = 0; F < L.length; F++) {
    for (var R = L[F], g = R.charAt(0), i = void 0, r = R.match($) || [], q = r.length, Q = 0; Q < q; Q++)
      r[Q] = parseFloat(r[Q]);
    for (var e = 0; e < q; ) {
      var b = void 0, k = void 0, w = void 0, A = void 0, S = void 0, z = void 0, D = void 0, l = a, M = n, T = void 0, o = void 0;
      switch (g) {
        case "l":
          a += r[e++], n += r[e++], i = v.L, t.addData(i, a, n);
          break;
        case "L":
          a = r[e++], n = r[e++], i = v.L, t.addData(i, a, n);
          break;
        case "m":
          a += r[e++], n += r[e++], i = v.M, t.addData(i, a, n), h = a, d = n, g = "l";
          break;
        case "M":
          a = r[e++], n = r[e++], i = v.M, t.addData(i, a, n), h = a, d = n, g = "L";
          break;
        case "h":
          a += r[e++], i = v.L, t.addData(i, a, n);
          break;
        case "H":
          a = r[e++], i = v.L, t.addData(i, a, n);
          break;
        case "v":
          n += r[e++], i = v.L, t.addData(i, a, n);
          break;
        case "V":
          n = r[e++], i = v.L, t.addData(i, a, n);
          break;
        case "C":
          i = v.C, t.addData(i, r[e++], r[e++], r[e++], r[e++], r[e++], r[e++]), a = r[e - 2], n = r[e - 1];
          break;
        case "c":
          i = v.C, t.addData(i, r[e++] + a, r[e++] + n, r[e++] + a, r[e++] + n, r[e++] + a, r[e++] + n), a += r[e - 2], n += r[e - 1];
          break;
        case "S":
          b = a, k = n, T = t.len(), o = t.data, u === v.C && (b += a - o[T - 4], k += n - o[T - 3]), i = v.C, l = r[e++], M = r[e++], a = r[e++], n = r[e++], t.addData(i, b, k, l, M, a, n);
          break;
        case "s":
          b = a, k = n, T = t.len(), o = t.data, u === v.C && (b += a - o[T - 4], k += n - o[T - 3]), i = v.C, l = a + r[e++], M = n + r[e++], a += r[e++], n += r[e++], t.addData(i, b, k, l, M, a, n);
          break;
        case "Q":
          l = r[e++], M = r[e++], a = r[e++], n = r[e++], i = v.Q, t.addData(i, l, M, a, n);
          break;
        case "q":
          l = r[e++] + a, M = r[e++] + n, a += r[e++], n += r[e++], i = v.Q, t.addData(i, l, M, a, n);
          break;
        case "T":
          b = a, k = n, T = t.len(), o = t.data, u === v.Q && (b += a - o[T - 4], k += n - o[T - 3]), a = r[e++], n = r[e++], i = v.Q, t.addData(i, b, k, a, n);
          break;
        case "t":
          b = a, k = n, T = t.len(), o = t.data, u === v.Q && (b += a - o[T - 4], k += n - o[T - 3]), a += r[e++], n += r[e++], i = v.Q, t.addData(i, b, k, a, n);
          break;
        case "A":
          w = r[e++], A = r[e++], S = r[e++], z = r[e++], D = r[e++], l = a, M = n, a = r[e++], n = r[e++], i = v.A, X(l, M, a, n, z, D, w, A, S, i, t);
          break;
        case "a":
          w = r[e++], A = r[e++], S = r[e++], z = r[e++], D = r[e++], l = a, M = n, a += r[e++], n += r[e++], i = v.A, X(l, M, a, n, z, D, w, A, S, i, t);
          break;
      }
    }
    (g === "z" || g === "Z") && (i = v.Z, t.addData(i), a = h, n = d), u = i;
  }
  return t.toStatic(), t;
}
C(P, "createPathProxyFromString");
var E = function(s) {
  Y(t, s);
  function t() {
    return s !== null && s.apply(this, arguments) || this;
  }
  return C(t, "SVGPath"), t.prototype.applyTransform = function(a) {
  }, t;
}(m);
function J(s) {
  return s.setData != null;
}
C(J, "isPathProxy");
function K(s, t) {
  var a = P(s), n = W({}, t);
  return n.buildPath = function(h) {
    if (J(h)) {
      h.setData(a.data);
      var d = h.getContext();
      d && h.rebuildPath(d, 1);
    } else {
      var d = h;
      a.rebuildPath(d, 1);
    }
  }, n.applyTransform = function(h) {
    j(a, h), this.dirtyShape();
  }, n;
}
C(K, "createPathOptions");
function ra(s, t) {
  return new E(K(s, t));
}
C(ra, "createFromString");
function ea(s, t) {
  var a = K(s, t), n = function(h) {
    Y(d, h);
    function d(u) {
      var v = h.call(this, u) || this;
      return v.applyTransform = a.applyTransform, v.buildPath = a.buildPath, v;
    }
    return C(d, "Sub"), d;
  }(E);
  return n;
}
C(ea, "extendFromString");
function na(s, t) {
  for (var a = [], n = s.length, h = 0; h < n; h++) {
    var d = s[h];
    a.push(d.getUpdatedPathProxy(!0));
  }
  var u = new m(t);
  return u.createPathProxy(), u.buildPath = function(v) {
    if (J(v)) {
      v.appendPath(a);
      var L = v.getContext();
      L && v.rebuildPath(L, 1);
    }
  }, u;
}
C(na, "mergePath");
function ta(s, t) {
  t = t || {};
  var a = new m();
  return s.shape && a.setShape(s.shape), a.setStyle(s.style), t.bakeTransform ? j(a.path, s.getComputedTransform()) : t.toLocal ? a.setLocalTransform(s.getComputedTransform()) : a.copyTransform(s), a.buildPath = s.buildPath, a.applyTransform = a.applyTransform, a.z = s.z, a.z2 = s.z2, a.zlevel = s.zlevel, a;
}
C(ta, "clonePath");
export {
  ta as clonePath,
  ra as createFromString,
  ea as extendFromString,
  na as mergePath
};
