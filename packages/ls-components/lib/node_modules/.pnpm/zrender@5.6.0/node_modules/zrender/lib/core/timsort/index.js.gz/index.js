var K = Object.defineProperty;
var S = (f, w) => K(f, "name", { value: w, configurable: !0 });
var q = 32, U = 7;
function Q(f) {
  for (var w = 0; f >= q; )
    w |= f & 1, f >>= 1;
  return f + w;
}
S(Q, "minRunLength");
function P(f, w, s, E) {
  var u = w + 1;
  if (u === s)
    return 1;
  if (E(f[u++], f[w]) < 0) {
    for (; u < s && E(f[u], f[u - 1]) < 0; )
      u++;
    V(f, w, u);
  } else
    for (; u < s && E(f[u], f[u - 1]) >= 0; )
      u++;
  return u - w;
}
S(P, "makeAscendingRun");
function V(f, w, s) {
  for (s--; w < s; ) {
    var E = f[w];
    f[w++] = f[s], f[s--] = E;
  }
}
S(V, "reverseRun");
function j(f, w, s, E, u) {
  for (E === w && E++; E < s; E++) {
    for (var d = f[E], v = w, G = E, e; v < G; )
      e = v + G >>> 1, u(d, f[e]) < 0 ? G = e : v = e + 1;
    var N = E - v;
    switch (N) {
      case 3:
        f[v + 3] = f[v + 2];
      case 2:
        f[v + 2] = f[v + 1];
      case 1:
        f[v + 1] = f[v];
        break;
      default:
        for (; N > 0; )
          f[v + N] = f[v + N - 1], N--;
    }
    f[v] = d;
  }
}
S(j, "binaryInsertionSort");
function z(f, w, s, E, u, d) {
  var v = 0, G = 0, e = 1;
  if (d(f, w[s + u]) > 0) {
    for (G = E - u; e < G && d(f, w[s + u + e]) > 0; )
      v = e, e = (e << 1) + 1, e <= 0 && (e = G);
    e > G && (e = G), v += u, e += u;
  } else {
    for (G = u + 1; e < G && d(f, w[s + u - e]) <= 0; )
      v = e, e = (e << 1) + 1, e <= 0 && (e = G);
    e > G && (e = G);
    var N = v;
    v = u - e, e = u - N;
  }
  for (v++; v < e; ) {
    var T = v + (e - v >>> 1);
    d(f, w[s + T]) > 0 ? v = T + 1 : e = T;
  }
  return e;
}
S(z, "gallopLeft");
function C(f, w, s, E, u, d) {
  var v = 0, G = 0, e = 1;
  if (d(f, w[s + u]) < 0) {
    for (G = u + 1; e < G && d(f, w[s + u - e]) < 0; )
      v = e, e = (e << 1) + 1, e <= 0 && (e = G);
    e > G && (e = G);
    var N = v;
    v = u - e, e = u - N;
  } else {
    for (G = E - u; e < G && d(f, w[s + u + e]) >= 0; )
      v = e, e = (e << 1) + 1, e <= 0 && (e = G);
    e > G && (e = G), v += u, e += u;
  }
  for (v++; v < e; ) {
    var T = v + (e - v >>> 1);
    d(f, w[s + T]) < 0 ? e = T : v = T + 1;
  }
  return e;
}
S(C, "gallopRight");
function W(f, w) {
  var s = U, E, u, d = 0, v = [];
  E = [], u = [];
  function G(k, b) {
    E[d] = k, u[d] = b, d += 1;
  }
  S(G, "pushRun");
  function e() {
    for (; d > 1; ) {
      var k = d - 2;
      if (k >= 1 && u[k - 1] <= u[k] + u[k + 1] || k >= 2 && u[k - 2] <= u[k] + u[k - 1])
        u[k - 1] < u[k + 1] && k--;
      else if (u[k] > u[k + 1])
        break;
      T(k);
    }
  }
  S(e, "mergeRuns");
  function N() {
    for (; d > 1; ) {
      var k = d - 2;
      k > 0 && u[k - 1] < u[k + 1] && k--, T(k);
    }
  }
  S(N, "forceMergeRuns");
  function T(k) {
    var b = E[k], D = u[k], R = E[k + 1], i = u[k + 1];
    u[k] = D + i, k === d - 3 && (E[k + 1] = E[k + 2], u[k + 1] = u[k + 2]), d--;
    var M = C(f[R], f, b, D, 0, w);
    b += M, D -= M, D !== 0 && (i = z(f[b + D - 1], f, R, i, i - 1, w), i !== 0 && (D <= i ? B(b, D, R, i) : J(b, D, R, i)));
  }
  S(T, "mergeAt");
  function B(k, b, D, R) {
    var i = 0;
    for (i = 0; i < b; i++)
      v[i] = f[k + i];
    var M = 0, A = D, L = k;
    if (f[L++] = f[A++], --R === 0) {
      for (i = 0; i < b; i++)
        f[L + i] = v[M + i];
      return;
    }
    if (b === 1) {
      for (i = 0; i < R; i++)
        f[L + i] = f[A + i];
      f[L + R] = v[M];
      return;
    }
    for (var O = s, _, I, o; ; ) {
      _ = 0, I = 0, o = !1;
      do
        if (w(f[A], v[M]) < 0) {
          if (f[L++] = f[A++], I++, _ = 0, --R === 0) {
            o = !0;
            break;
          }
        } else if (f[L++] = v[M++], _++, I = 0, --b === 1) {
          o = !0;
          break;
        }
      while ((_ | I) < O);
      if (o)
        break;
      do {
        if (_ = C(f[A], v, M, b, 0, w), _ !== 0) {
          for (i = 0; i < _; i++)
            f[L + i] = v[M + i];
          if (L += _, M += _, b -= _, b <= 1) {
            o = !0;
            break;
          }
        }
        if (f[L++] = f[A++], --R === 0) {
          o = !0;
          break;
        }
        if (I = z(v[M], f, A, R, 0, w), I !== 0) {
          for (i = 0; i < I; i++)
            f[L + i] = f[A + i];
          if (L += I, A += I, R -= I, R === 0) {
            o = !0;
            break;
          }
        }
        if (f[L++] = v[M++], --b === 1) {
          o = !0;
          break;
        }
        O--;
      } while (_ >= U || I >= U);
      if (o)
        break;
      O < 0 && (O = 0), O += 2;
    }
    if (s = O, s < 1 && (s = 1), b === 1) {
      for (i = 0; i < R; i++)
        f[L + i] = f[A + i];
      f[L + R] = v[M];
    } else {
      if (b === 0)
        throw new Error();
      for (i = 0; i < b; i++)
        f[L + i] = v[M + i];
    }
  }
  S(B, "mergeLow");
  function J(k, b, D, R) {
    var i = 0;
    for (i = 0; i < R; i++)
      v[i] = f[D + i];
    var M = k + b - 1, A = R - 1, L = D + R - 1, O = 0, _ = 0;
    if (f[L--] = f[M--], --b === 0) {
      for (O = L - (R - 1), i = 0; i < R; i++)
        f[O + i] = v[i];
      return;
    }
    if (R === 1) {
      for (L -= b, M -= b, _ = L + 1, O = M + 1, i = b - 1; i >= 0; i--)
        f[_ + i] = f[O + i];
      f[L] = v[A];
      return;
    }
    for (var I = s; ; ) {
      var o = 0, F = 0, H = !1;
      do
        if (w(v[A], f[M]) < 0) {
          if (f[L--] = f[M--], o++, F = 0, --b === 0) {
            H = !0;
            break;
          }
        } else if (f[L--] = v[A--], F++, o = 0, --R === 1) {
          H = !0;
          break;
        }
      while ((o | F) < I);
      if (H)
        break;
      do {
        if (o = b - C(v[A], f, k, b, b - 1, w), o !== 0) {
          for (L -= o, M -= o, b -= o, _ = L + 1, O = M + 1, i = o - 1; i >= 0; i--)
            f[_ + i] = f[O + i];
          if (b === 0) {
            H = !0;
            break;
          }
        }
        if (f[L--] = v[A--], --R === 1) {
          H = !0;
          break;
        }
        if (F = R - z(f[M], v, 0, R, R - 1, w), F !== 0) {
          for (L -= F, A -= F, R -= F, _ = L + 1, O = A + 1, i = 0; i < F; i++)
            f[_ + i] = v[O + i];
          if (R <= 1) {
            H = !0;
            break;
          }
        }
        if (f[L--] = f[M--], --b === 0) {
          H = !0;
          break;
        }
        I--;
      } while (o >= U || F >= U);
      if (H)
        break;
      I < 0 && (I = 0), I += 2;
    }
    if (s = I, s < 1 && (s = 1), R === 1) {
      for (L -= b, M -= b, _ = L + 1, O = M + 1, i = b - 1; i >= 0; i--)
        f[_ + i] = f[O + i];
      f[L] = v[A];
    } else {
      if (R === 0)
        throw new Error();
      for (O = L - (R - 1), i = 0; i < R; i++)
        f[O + i] = v[i];
    }
  }
  return S(J, "mergeHigh"), {
    mergeRuns: e,
    forceMergeRuns: N,
    pushRun: G
  };
}
S(W, "TimSort");
function Y(f, w, s, E) {
  s || (s = 0), E || (E = f.length);
  var u = E - s;
  if (!(u < 2)) {
    var d = 0;
    if (u < q) {
      d = P(f, s, E, w), j(f, s, E, s + d, w);
      return;
    }
    var v = W(f, w), G = Q(u);
    do {
      if (d = P(f, s, E, w), d < G) {
        var e = u;
        e > G && (e = G), j(f, s, s + e, s + d, w), d = e;
      }
      v.pushRun(s, d), v.mergeRuns(), u -= d, s += d;
    } while (u !== 0);
    v.forceMergeRuns();
  }
}
S(Y, "sort");
export {
  Y as default
};
