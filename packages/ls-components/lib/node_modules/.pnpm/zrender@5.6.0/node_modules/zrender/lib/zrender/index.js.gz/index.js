var S = Object.defineProperty;
var n = (t, e) => S(t, "name", { value: e, configurable: !0 });
import u from "../core/env/index.js";
import { guid as H, keys as A, retrieve2 as w } from "../core/util/index.js";
import D from "../Handler/index.js";
import k from "../Storage/index.js";
import M, { getTime as c } from "../animation/Animation/index.js";
import z from "../dom/HandlerProxy/index.js";
import { lum as m } from "../tool/color/index.js";
import { DARK_MODE_THRESHOLD as _ } from "../config/index.js";
import P from "../graphic/Group/index.js";
/*!
* ZRender, a high performance 2d drawing library.
*
* Copyright (c) 2013, Baidu Inc.
* All rights reserved.
*
* LICENSE
* https://github.com/ecomfe/zrender/blob/master/LICENSE.txt
*/
var f = {}, y = {};
function F(t) {
  delete y[t];
}
n(F, "delInstance");
function E(t) {
  if (!t)
    return !1;
  if (typeof t == "string")
    return m(t, 1) < _;
  if (t.colorStops) {
    for (var e = t.colorStops, r = 0, i = e.length, s = 0; s < i; s++)
      r += m(e[s].color, 1);
    return r /= i, r < _;
  }
  return !1;
}
n(E, "isDarkMode");
var T = function() {
  function t(e, r, i) {
    var s = this;
    this._sleepAfterStill = 10, this._stillFrameAccum = 0, this._needsRefresh = !0, this._needsRefreshHover = !0, this._darkMode = !1, i = i || {}, this.dom = r, this.id = e;
    var a = new k(), h = i.renderer || "canvas";
    if (f[h] || (h = A(f)[0]), process.env.NODE_ENV !== "production" && !f[h])
      throw new Error("Renderer '" + h + "' is not imported. Please import it first.");
    i.useDirtyRect = i.useDirtyRect == null ? !1 : i.useDirtyRect;
    var o = new f[h](r, a, i, e), d = i.ssr || o.ssrOnly;
    this.storage = a, this.painter = o;
    var v = !u.node && !u.worker && !d ? new z(o.getViewportRoot(), o.root) : null, p = i.useCoarsePointer, g = p == null || p === "auto" ? u.touchEventsSupported : !!p, R = 44, l;
    g && (l = w(i.pointerSize, R)), this.handler = new D(a, o, v, o.root, l), this.animation = new M({
      stage: {
        update: d ? null : function() {
          return s._flush(!0);
        }
      }
    }), d || this.animation.start();
  }
  return n(t, "ZRender"), t.prototype.add = function(e) {
    this._disposed || !e || (this.storage.addRoot(e), e.addSelfToZr(this), this.refresh());
  }, t.prototype.remove = function(e) {
    this._disposed || !e || (this.storage.delRoot(e), e.removeSelfFromZr(this), this.refresh());
  }, t.prototype.configLayer = function(e, r) {
    this._disposed || (this.painter.configLayer && this.painter.configLayer(e, r), this.refresh());
  }, t.prototype.setBackgroundColor = function(e) {
    this._disposed || (this.painter.setBackgroundColor && this.painter.setBackgroundColor(e), this.refresh(), this._backgroundColor = e, this._darkMode = E(e));
  }, t.prototype.getBackgroundColor = function() {
    return this._backgroundColor;
  }, t.prototype.setDarkMode = function(e) {
    this._darkMode = e;
  }, t.prototype.isDarkMode = function() {
    return this._darkMode;
  }, t.prototype.refreshImmediately = function(e) {
    this._disposed || (e || this.animation.update(!0), this._needsRefresh = !1, this.painter.refresh(), this._needsRefresh = !1);
  }, t.prototype.refresh = function() {
    this._disposed || (this._needsRefresh = !0, this.animation.start());
  }, t.prototype.flush = function() {
    this._disposed || this._flush(!1);
  }, t.prototype._flush = function(e) {
    var r, i = c();
    this._needsRefresh && (r = !0, this.refreshImmediately(e)), this._needsRefreshHover && (r = !0, this.refreshHoverImmediately());
    var s = c();
    r ? (this._stillFrameAccum = 0, this.trigger("rendered", {
      elapsedTime: s - i
    })) : this._sleepAfterStill > 0 && (this._stillFrameAccum++, this._stillFrameAccum > this._sleepAfterStill && this.animation.stop());
  }, t.prototype.setSleepAfterStill = function(e) {
    this._sleepAfterStill = e;
  }, t.prototype.wakeUp = function() {
    this._disposed || (this.animation.start(), this._stillFrameAccum = 0);
  }, t.prototype.refreshHover = function() {
    this._needsRefreshHover = !0;
  }, t.prototype.refreshHoverImmediately = function() {
    this._disposed || (this._needsRefreshHover = !1, this.painter.refreshHover && this.painter.getType() === "canvas" && this.painter.refreshHover());
  }, t.prototype.resize = function(e) {
    this._disposed || (e = e || {}, this.painter.resize(e.width, e.height), this.handler.resize());
  }, t.prototype.clearAnimation = function() {
    this._disposed || this.animation.clear();
  }, t.prototype.getWidth = function() {
    if (!this._disposed)
      return this.painter.getWidth();
  }, t.prototype.getHeight = function() {
    if (!this._disposed)
      return this.painter.getHeight();
  }, t.prototype.setCursorStyle = function(e) {
    this._disposed || this.handler.setCursorStyle(e);
  }, t.prototype.findHover = function(e, r) {
    if (!this._disposed)
      return this.handler.findHover(e, r);
  }, t.prototype.on = function(e, r, i) {
    return this._disposed || this.handler.on(e, r, i), this;
  }, t.prototype.off = function(e, r) {
    this._disposed || this.handler.off(e, r);
  }, t.prototype.trigger = function(e, r) {
    this._disposed || this.handler.trigger(e, r);
  }, t.prototype.clear = function() {
    if (!this._disposed) {
      for (var e = this.storage.getRoots(), r = 0; r < e.length; r++)
        e[r] instanceof P && e[r].removeSelfFromZr(this);
      this.storage.delAllRoots(), this.painter.clear();
    }
  }, t.prototype.dispose = function() {
    this._disposed || (this.animation.stop(), this.clear(), this.storage.dispose(), this.painter.dispose(), this.handler.dispose(), this.animation = this.storage = this.painter = this.handler = null, this._disposed = !0, F(this.id));
  }, t;
}();
function G(t, e) {
  var r = new T(H(), t, e);
  return y[r.id] = r, r;
}
n(G, "init");
function K(t, e) {
  f[t] = e;
}
n(K, "registerPainter");
export {
  G as init,
  K as registerPainter
};
