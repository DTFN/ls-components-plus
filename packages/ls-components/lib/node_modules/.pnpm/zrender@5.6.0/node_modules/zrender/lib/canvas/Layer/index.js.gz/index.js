var D = Object.defineProperty;
var g = (l, h) => D(l, "name", { value: h, configurable: !0 });
import { __extends as L } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { isObject as U, disableUserSelect as G, each as W, isGradientObject as X, isImagePatternObject as Y } from "../../core/util/index.js";
import { devicePixelRatio as Z } from "../../config/index.js";
import O from "../../core/Eventful/index.js";
import { getCanvasGradient as q } from "../helper/index.js";
import { createCanvasPattern as H } from "../graphic/index.js";
import k from "../../core/BoundingRect/index.js";
import { REDRAW_BIT as E } from "../../graphic/constants/index.js";
import { platformApi as J } from "../../core/platform/index.js";
function A(l, h, a) {
  var i = J.createCanvas(), r = h.getWidth(), e = h.getHeight(), t = i.style;
  return t && (t.position = "absolute", t.left = "0", t.top = "0", t.width = r + "px", t.height = e + "px", i.setAttribute("data-zr-dom-id", l)), i.width = r * a, i.height = e * a, i;
}
g(A, "createDom");
var et = function(l) {
  L(h, l);
  function h(a, i, r) {
    var e = l.call(this) || this;
    e.motionBlur = !1, e.lastFrameAlpha = 0.7, e.dpr = 1, e.virtual = !1, e.config = {}, e.incremental = !1, e.zlevel = 0, e.maxRepaintRectCount = 5, e.__dirty = !0, e.__firstTimePaint = !0, e.__used = !1, e.__drawIndex = 0, e.__startIndex = 0, e.__endIndex = 0, e.__prevStartIndex = null, e.__prevEndIndex = null;
    var t;
    r = r || Z, typeof a == "string" ? t = A(a, i, r) : U(a) && (t = a, a = t.id), e.id = a, e.dom = t;
    var o = t.style;
    return o && (G(t), t.onselectstart = function() {
      return !1;
    }, o.padding = "0", o.margin = "0", o.borderWidth = "0"), e.painter = i, e.dpr = r, e;
  }
  return g(h, "Layer"), h.prototype.getElementCount = function() {
    return this.__endIndex - this.__startIndex;
  }, h.prototype.afterBrush = function() {
    this.__prevStartIndex = this.__startIndex, this.__prevEndIndex = this.__endIndex;
  }, h.prototype.initContext = function() {
    this.ctx = this.dom.getContext("2d"), this.ctx.dpr = this.dpr;
  }, h.prototype.setUnpainted = function() {
    this.__firstTimePaint = !0;
  }, h.prototype.createBackBuffer = function() {
    var a = this.dpr;
    this.domBack = A("back-" + this.id, this.painter, a), this.ctxBack = this.domBack.getContext("2d"), a !== 1 && this.ctxBack.scale(a, a);
  }, h.prototype.createRepaintRects = function(a, i, r, e) {
    if (this.__firstTimePaint)
      return this.__firstTimePaint = !1, null;
    var t = [], o = this.maxRepaintRectCount, m = !1, _ = new k(0, 0, 0, 0);
    function y(f) {
      if (!(!f.isFinite() || f.isZero()))
        if (t.length === 0) {
          var v = new k(0, 0, 0, 0);
          v.copy(f), t.push(v);
        } else {
          for (var B = !1, P = 1 / 0, b = 0, I = 0; I < t.length; ++I) {
            var R = t[I];
            if (R.intersect(f)) {
              var w = new k(0, 0, 0, 0);
              w.copy(R), w.union(f), t[I] = w, B = !0;
              break;
            } else if (m) {
              _.copy(f), _.union(R);
              var T = f.width * f.height, z = R.width * R.height, F = _.width * _.height, S = F - T - z;
              S < P && (P = S, b = I);
            }
          }
          if (m && (t[b].union(f), B = !0), !B) {
            var v = new k(0, 0, 0, 0);
            v.copy(f), t.push(v);
          }
          m || (m = t.length >= o);
        }
    }
    g(y, "addRectToMergePool");
    for (var n = this.__startIndex; n < this.__endIndex; ++n) {
      var s = a[n];
      if (s) {
        var x = s.shouldBePainted(r, e, !0, !0), u = s.__isRendered && (s.__dirty & E || !x) ? s.getPrevPaintRect() : null;
        u && y(u);
        var p = x && (s.__dirty & E || !s.__isRendered) ? s.getPaintRect() : null;
        p && y(p);
      }
    }
    for (var n = this.__prevStartIndex; n < this.__prevEndIndex; ++n) {
      var s = i[n], x = s && s.shouldBePainted(r, e, !0, !0);
      if (s && (!x || !s.__zr) && s.__isRendered) {
        var u = s.getPrevPaintRect();
        u && y(u);
      }
    }
    var c;
    do {
      c = !1;
      for (var n = 0; n < t.length; ) {
        if (t[n].isZero()) {
          t.splice(n, 1);
          continue;
        }
        for (var d = n + 1; d < t.length; )
          t[n].intersect(t[d]) ? (c = !0, t[n].union(t[d]), t.splice(d, 1)) : d++;
        n++;
      }
    } while (c);
    return this._paintRects = t, t;
  }, h.prototype.debugGetPaintRects = function() {
    return (this._paintRects || []).slice();
  }, h.prototype.resize = function(a, i) {
    var r = this.dpr, e = this.dom, t = e.style, o = this.domBack;
    t && (t.width = a + "px", t.height = i + "px"), e.width = a * r, e.height = i * r, o && (o.width = a * r, o.height = i * r, r !== 1 && this.ctxBack.scale(r, r));
  }, h.prototype.clear = function(a, i, r) {
    var e = this.dom, t = this.ctx, o = e.width, m = e.height;
    i = i || this.clearColor;
    var _ = this.motionBlur && !a, y = this.lastFrameAlpha, n = this.dpr, s = this;
    _ && (this.domBack || this.createBackBuffer(), this.ctxBack.globalCompositeOperation = "copy", this.ctxBack.drawImage(e, 0, 0, o / n, m / n));
    var x = this.domBack;
    function u(p, c, d, f) {
      if (t.clearRect(p, c, d, f), i && i !== "transparent") {
        var v = void 0;
        if (X(i)) {
          var B = i.global || i.__width === d && i.__height === f;
          v = B && i.__canvasGradient || q(t, i, {
            x: 0,
            y: 0,
            width: d,
            height: f
          }), i.__canvasGradient = v, i.__width = d, i.__height = f;
        } else Y(i) && (i.scaleX = i.scaleX || n, i.scaleY = i.scaleY || n, v = H(t, i, {
          dirty: /* @__PURE__ */ g(function() {
            s.setUnpainted(), s.painter.refresh();
          }, "dirty")
        }));
        t.save(), t.fillStyle = v || i, t.fillRect(p, c, d, f), t.restore();
      }
      _ && (t.save(), t.globalAlpha = y, t.drawImage(x, p, c, d, f), t.restore());
    }
    g(u, "doClear"), !r || _ ? u(0, 0, o, m) : r.length && W(r, function(p) {
      u(p.x * n, p.y * n, p.width * n, p.height * n);
    });
  }, h;
}(O);
export {
  et as default
};
