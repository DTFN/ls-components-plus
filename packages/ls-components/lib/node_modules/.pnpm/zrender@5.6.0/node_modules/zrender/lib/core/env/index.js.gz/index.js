var u = Object.defineProperty;
var i = (t, r) => u(t, "name", { value: r, configurable: !0 });
var p = function() {
  function t() {
    this.firefox = !1, this.ie = !1, this.edge = !1, this.newEdge = !1, this.weChat = !1;
  }
  return i(t, "Browser"), t;
}(), w = function() {
  function t() {
    this.browser = new p(), this.node = !1, this.wxa = !1, this.worker = !1, this.svgSupported = !1, this.touchEventsSupported = !1, this.pointerEventsSupported = !1, this.domSupported = !1, this.transformSupported = !1, this.transform3dSupported = !1, this.hasGlobalWindow = typeof window < "u";
  }
  return i(t, "Env"), t;
}(), o = new w();
typeof wx == "object" && typeof wx.getSystemInfoSync == "function" ? (o.wxa = !0, o.touchEventsSupported = !0) : typeof document > "u" && typeof self < "u" ? o.worker = !0 : typeof navigator > "u" || navigator.userAgent.indexOf("Node.js") === 0 ? (o.node = !0, o.svgSupported = !0) : h(navigator.userAgent, o);
function h(t, r) {
  var e = r.browser, d = t.match(/Firefox\/([\d.]+)/), f = t.match(/MSIE\s([\d.]+)/) || t.match(/Trident\/.+?rv:(([\d.]+))/), n = t.match(/Edge?\/([\d.]+)/), a = /micromessenger/i.test(t);
  d && (e.firefox = !0, e.version = d[1]), f && (e.ie = !0, e.version = f[1]), n && (e.edge = !0, e.version = n[1], e.newEdge = +n[1].split(".")[0] > 18), a && (e.weChat = !0), r.svgSupported = typeof SVGRect < "u", r.touchEventsSupported = "ontouchstart" in window && !e.ie && !e.edge, r.pointerEventsSupported = "onpointerdown" in window && (e.edge || e.ie && +e.version >= 11), r.domSupported = typeof document < "u";
  var s = document.documentElement.style;
  r.transform3dSupported = (e.ie && "transition" in s || e.edge || "WebKitCSSMatrix" in window && "m11" in new WebKitCSSMatrix() || "MozPerspective" in s) && !("OTransition" in s), r.transformSupported = r.transform3dSupported || e.ie && +e.version >= 9;
}
i(h, "detect");
export {
  o as default
};
