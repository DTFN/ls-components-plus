var $ = Object.defineProperty;
var o = (i, r) => $(i, "name", { value: r, configurable: !0 });
import { findExistImage as I, isImageReady as P } from "../image/index.js";
import { retrieve2 as A, retrieve3 as j, reduce as S, extend as y } from "../../../core/util/index.js";
import { getLineHeight as N, getWidth as H, parsePercent as k } from "../../../contain/text/index.js";
var D = /\{([a-zA-Z0-9_]+)\|([^}]*)\}/g;
function rr(i, r, h, e, n) {
  if (!r)
    return "";
  var t = (i + "").split(`
`);
  n = Q(r, h, e, n);
  for (var l = 0, a = t.length; l < a; l++)
    t[l] = U(t[l], n);
  return t.join(`
`);
}
o(rr, "truncateText");
function Q(i, r, h, e) {
  e = e || {};
  var n = y({}, e);
  n.font = r, h = A(h, "..."), n.maxIterations = A(e.maxIterations, 2);
  var t = n.minChar = A(e.minChar, 0);
  n.cnCharWidth = H("国", r);
  var l = n.ascCharWidth = H("a", r);
  n.placeholder = A(e.placeholder, "");
  for (var a = i = Math.max(0, i - 1), c = 0; c < t && a >= l; c++)
    a -= l;
  var f = H(h, r);
  return f > a && (h = "", f = 0), a = i - f, n.ellipsis = h, n.ellipsisWidth = f, n.contentWidth = a, n.containerWidth = i, n;
}
o(Q, "prepareTruncateOptions");
function U(i, r) {
  var h = r.containerWidth, e = r.font, n = r.contentWidth;
  if (!h)
    return "";
  var t = H(i, e);
  if (t <= h)
    return i;
  for (var l = 0; ; l++) {
    if (t <= n || l >= r.maxIterations) {
      i += r.ellipsis;
      break;
    }
    var a = l === 0 ? ir(i, n, r.ascCharWidth, r.cnCharWidth) : t > 0 ? Math.floor(i.length * n / t) : 0;
    i = i.substr(0, a), t = H(i, e);
  }
  return i === "" && (i = r.placeholder), i;
}
o(U, "truncateSingleLine");
function ir(i, r, h, e) {
  for (var n = 0, t = 0, l = i.length; t < l && n < r; t++) {
    var a = i.charCodeAt(t);
    n += 0 <= a && a <= 127 ? h : e;
  }
  return t;
}
o(ir, "estimateLength");
function fr(i, r) {
  i != null && (i += "");
  var h = r.overflow, e = r.padding, n = r.font, t = h === "truncate", l = N(n), a = A(r.lineHeight, l), c = !!r.backgroundColor, f = r.lineOverflow === "truncate", u = r.width, s;
  u != null && (h === "break" || h === "breakAll") ? s = i ? V(i, r.font, u, h === "breakAll", 0).lines : [] : s = i ? i.split(`
`) : [];
  var d = s.length * a, g = A(r.height, d);
  if (d > g && f) {
    var b = Math.floor(g / a);
    s = s.slice(0, b);
  }
  if (i && t && u != null)
    for (var M = Q(u, n, r.ellipsis, {
      minChar: r.truncateMinChar,
      placeholder: r.placeholder
    }), p = 0; p < s.length; p++)
      s[p] = U(s[p], M);
  for (var m = g, w = 0, p = 0; p < s.length; p++)
    w = Math.max(H(s[p], n), w);
  u == null && (u = w);
  var W = w;
  return e && (m += e[0] + e[2], W += e[1] + e[3], u += e[1] + e[3]), c && (W = u), {
    lines: s,
    height: g,
    outerWidth: W,
    outerHeight: m,
    lineHeight: a,
    calculatedLineHeight: l,
    contentWidth: w,
    contentHeight: d,
    width: u
  };
}
o(fr, "parsePlainText");
var ar = function() {
  function i() {
  }
  return o(i, "RichTextToken"), i;
}(), K = function() {
  function i(r) {
    this.tokens = [], r && (this.tokens = r);
  }
  return o(i, "RichTextLine"), i;
}(), hr = function() {
  function i() {
    this.width = 0, this.height = 0, this.contentWidth = 0, this.contentHeight = 0, this.outerWidth = 0, this.outerHeight = 0, this.lines = [];
  }
  return o(i, "RichTextContentBlock"), i;
}();
function sr(i, r) {
  var h = new hr();
  if (i != null && (i += ""), !i)
    return h;
  for (var e = r.width, n = r.height, t = r.overflow, l = (t === "break" || t === "breakAll") && e != null ? { width: e, accumWidth: 0, breakAll: t === "breakAll" } : null, a = D.lastIndex = 0, c; (c = D.exec(i)) != null; ) {
    var f = c.index;
    f > a && G(h, i.substring(a, f), r, l), G(h, c[2], r, l, c[1]), a = D.lastIndex;
  }
  a < i.length && G(h, i.substring(a, i.length), r, l);
  var u = [], s = 0, d = 0, g = r.padding, b = t === "truncate", M = r.lineOverflow === "truncate";
  function p(_, q, J) {
    _.width = q, _.lineHeight = J, s += J, d = Math.max(d, q);
  }
  o(p, "finishLine");
  r: for (var m = 0; m < h.lines.length; m++) {
    for (var w = h.lines[m], W = 0, R = 0, F = 0; F < w.tokens.length; F++) {
      var v = w.tokens[F], C = v.styleName && r.rich[v.styleName] || {}, x = v.textPadding = C.padding, z = x ? x[1] + x[3] : 0, E = v.font = C.font || r.font;
      v.contentHeight = N(E);
      var O = A(C.height, v.contentHeight);
      if (v.innerHeight = O, x && (O += x[0] + x[2]), v.height = O, v.lineHeight = j(C.lineHeight, r.lineHeight, O), v.align = C && C.align || r.align, v.verticalAlign = C && C.verticalAlign || "middle", M && n != null && s + v.lineHeight > n) {
        F > 0 ? (w.tokens = w.tokens.slice(0, F), p(w, R, W), h.lines = h.lines.slice(0, m + 1)) : h.lines = h.lines.slice(0, m);
        break r;
      }
      var L = C.width, Y = L == null || L === "auto";
      if (typeof L == "string" && L.charAt(L.length - 1) === "%")
        v.percentWidth = L, u.push(v), v.contentWidth = H(v.text, E);
      else {
        if (Y) {
          var Z = C.backgroundColor, T = Z && Z.image;
          T && (T = I(T), P(T) && (v.width = Math.max(v.width, T.width * O / T.height)));
        }
        var B = b && e != null ? e - R : null;
        B != null && B < v.width ? !Y || B < z ? (v.text = "", v.width = v.contentWidth = 0) : (v.text = rr(v.text, B - z, E, r.ellipsis, { minChar: r.truncateMinChar }), v.width = v.contentWidth = H(v.text, E)) : v.contentWidth = H(v.text, E);
      }
      v.width += z, R += v.width, C && (W = Math.max(W, v.lineHeight));
    }
    p(w, R, W);
  }
  h.outerWidth = h.width = A(e, d), h.outerHeight = h.height = A(n, s), h.contentHeight = s, h.contentWidth = d, g && (h.outerWidth += g[1] + g[3], h.outerHeight += g[0] + g[2]);
  for (var m = 0; m < u.length; m++) {
    var v = u[m], X = v.percentWidth;
    v.width = parseInt(X, 10) / 100 * h.width;
  }
  return h;
}
o(sr, "parseRichText");
function G(i, r, h, e, n) {
  var t = r === "", l = n && h.rich[n] || {}, a = i.lines, c = l.font || h.font, f = !1, u, s;
  if (e) {
    var d = l.padding, g = d ? d[1] + d[3] : 0;
    if (l.width != null && l.width !== "auto") {
      var b = k(l.width, e.width) + g;
      a.length > 0 && b + e.accumWidth > e.width && (u = r.split(`
`), f = !0), e.accumWidth = b;
    } else {
      var M = V(r, c, e.width, e.breakAll, e.accumWidth);
      e.accumWidth = M.accumWidth + g, s = M.linesWidths, u = M.lines;
    }
  } else
    u = r.split(`
`);
  for (var p = 0; p < u.length; p++) {
    var m = u[p], w = new ar();
    if (w.styleName = n, w.text = m, w.isLineHolder = !m && !t, typeof l.width == "number" ? w.width = l.width : w.width = s ? s[p] : H(m, c), !p && !f) {
      var W = (a[a.length - 1] || (a[0] = new K())).tokens, R = W.length;
      R === 1 && W[0].isLineHolder ? W[0] = w : (m || !R || t) && W.push(w);
    } else
      a.push(new K([w]));
  }
}
o(G, "pushTokens");
function er(i) {
  var r = i.charCodeAt(0);
  return r >= 32 && r <= 591 || r >= 880 && r <= 4351 || r >= 4608 && r <= 5119 || r >= 7680 && r <= 8303;
}
o(er, "isAlphabeticLetter");
var tr = S(",&?/;] ".split(""), function(i, r) {
  return i[r] = !0, i;
}, {});
function nr(i) {
  return er(i) ? !!tr[i] : !0;
}
o(nr, "isWordBreakChar");
function V(i, r, h, e, n) {
  for (var t = [], l = [], a = "", c = "", f = 0, u = 0, s = 0; s < i.length; s++) {
    var d = i.charAt(s);
    if (d === `
`) {
      c && (a += c, u += f), t.push(a), l.push(u), a = "", c = "", f = 0, u = 0;
      continue;
    }
    var g = H(d, r), b = e ? !1 : !nr(d);
    if (t.length ? u + g > h : n + u + g > h) {
      u ? (a || c) && (b ? (a || (a = c, c = "", f = 0, u = f), t.push(a), l.push(u - f), c += d, f += g, a = "", u = f) : (c && (a += c, c = "", f = 0), t.push(a), l.push(u), a = d, u = g)) : b ? (t.push(c), l.push(f), c = d, f = g) : (t.push(d), l.push(g));
      continue;
    }
    u += g, b ? (c += d, f += g) : (c && (a += c, c = "", f = 0), a += d);
  }
  return !t.length && !a && (a = i, c = "", f = 0), c && (a += c), a && (t.push(a), l.push(u)), t.length === 1 && (u += n), {
    accumWidth: u,
    lines: t,
    linesWidths: l
  };
}
o(V, "wrapText");
export {
  hr as RichTextContentBlock,
  fr as parsePlainText,
  sr as parseRichText,
  rr as truncateText
};
