var p = Object.defineProperty;
var h = (i, t) => p(i, "name", { value: t, configurable: !0 });
import d from "../easing/index.js";
import { noop as s, isFunction as _ } from "../../core/util/index.js";
import { createCubicEasingFunc as m } from "../cubicEasing/index.js";
var T = function() {
  function i(t) {
    this._inited = !1, this._startTime = 0, this._pausedTime = 0, this._paused = !1, this._life = t.life || 1e3, this._delay = t.delay || 0, this.loop = t.loop || !1, this.onframe = t.onframe || s, this.ondestroy = t.ondestroy || s, this.onrestart = t.onrestart || s, t.easing && this.setEasing(t.easing);
  }
  return h(i, "Clip"), i.prototype.step = function(t, u) {
    if (this._inited || (this._startTime = t + this._delay, this._inited = !0), this._paused) {
      this._pausedTime += u;
      return;
    }
    var r = this._life, a = t - this._startTime - this._pausedTime, e = a / r;
    e < 0 && (e = 0), e = Math.min(e, 1);
    var n = this.easingFunc, o = n ? n(e) : e;
    if (this.onframe(o), e === 1)
      if (this.loop) {
        var f = a % r;
        this._startTime = t - f, this._pausedTime = 0, this.onrestart();
      } else
        return !0;
    return !1;
  }, i.prototype.pause = function() {
    this._paused = !0;
  }, i.prototype.resume = function() {
    this._paused = !1;
  }, i.prototype.setEasing = function(t) {
    this.easing = t, this.easingFunc = _(t) ? t : d[t] || m(t);
  }, i;
}();
export {
  T as default
};
