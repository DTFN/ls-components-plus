var p = Object.defineProperty;
var f = (e, t) => p(e, "name", { value: t, configurable: !0 });
import b from "../../core/BoundingRect/index.js";
import k from "../../core/LRU/index.js";
import { platformApi as w, DEFAULT_FONT as T } from "../../core/platform/index.js";
var g = {};
function v(e, t) {
  t = t || T;
  var r = g[t];
  r || (r = g[t] = new k(500));
  var o = r.get(e);
  return o == null && (o = w.measureText(e, t).width, r.put(e, o)), o;
}
f(v, "getWidth");
function m(e, t, r, o) {
  var i = v(e, t), l = y(t), a = x(0, i, r), c = L(0, l, o), n = new b(a, c, i, l);
  return n;
}
f(m, "innerGetBoundingRect");
function O(e, t, r, o) {
  var i = ((e || "") + "").split(`
`), l = i.length;
  if (l === 1)
    return m(i[0], t, r, o);
  for (var a = new b(0, 0, 0, 0), c = 0; c < i.length; c++) {
    var n = m(i[c], t, r, o);
    c === 0 ? a.copy(n) : a.union(n);
  }
  return a;
}
f(O, "getBoundingRect");
function x(e, t, r) {
  return r === "right" ? e -= t : r === "center" && (e -= t / 2), e;
}
f(x, "adjustTextX");
function L(e, t, r) {
  return r === "middle" ? e -= t / 2 : r === "bottom" && (e -= t), e;
}
f(L, "adjustTextY");
function y(e) {
  return v("国", e);
}
f(y, "getLineHeight");
function u(e, t) {
  return typeof e == "string" ? e.lastIndexOf("%") >= 0 ? parseFloat(e) / 100 * t : parseFloat(e) : e;
}
f(u, "parsePercent");
function P(e, t, r) {
  var o = t.position || "inside", i = t.distance != null ? t.distance : 5, l = r.height, a = r.width, c = l / 2, n = r.x, s = r.y, d = "left", h = "top";
  if (o instanceof Array)
    n += u(o[0], r.width), s += u(o[1], r.height), d = null, h = null;
  else
    switch (o) {
      case "left":
        n -= i, s += c, d = "right", h = "middle";
        break;
      case "right":
        n += i + a, s += c, h = "middle";
        break;
      case "top":
        n += a / 2, s -= i, d = "center", h = "bottom";
        break;
      case "bottom":
        n += a / 2, s += l + i, d = "center";
        break;
      case "inside":
        n += a / 2, s += c, d = "center", h = "middle";
        break;
      case "insideLeft":
        n += i, s += c, h = "middle";
        break;
      case "insideRight":
        n += a - i, s += c, d = "right", h = "middle";
        break;
      case "insideTop":
        n += a / 2, s += i, d = "center";
        break;
      case "insideBottom":
        n += a / 2, s += l - i, d = "center", h = "bottom";
        break;
      case "insideTopLeft":
        n += i, s += i;
        break;
      case "insideTopRight":
        n += a - i, s += i, d = "right";
        break;
      case "insideBottomLeft":
        n += i, s += l - i, h = "bottom";
        break;
      case "insideBottomRight":
        n += a - i, s += l - i, d = "right", h = "bottom";
        break;
    }
  return e = e || {}, e.x = n, e.y = s, e.align = d, e.verticalAlign = h, e;
}
f(P, "calculateTextPosition");
export {
  x as adjustTextX,
  L as adjustTextY,
  P as calculateTextPosition,
  O as getBoundingRect,
  y as getLineHeight,
  v as getWidth,
  m as innerGetBoundingRect,
  u as parsePercent
};
