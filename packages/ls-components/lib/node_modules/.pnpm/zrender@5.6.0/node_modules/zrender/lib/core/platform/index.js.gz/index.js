var T = Object.defineProperty;
var v = (a, n) => T(a, "name", { value: n, configurable: !0 });
var f = 12, m = "sans-serif", c = f + "px " + m, W = 20, g = 100, l = "007LLmW'55;N0500LLLLLLLLLL00NNNLzWW\\\\WQb\\0FWLg\\bWb\\WQ\\WrWWQ000CL5LLFLL0LL**F*gLLLL5F0LF\\FFF5.5N";
function i(a) {
  var n = {};
  if (typeof JSON > "u")
    return n;
  for (var r = 0; r < a.length; r++) {
    var e = String.fromCharCode(r + 32), L = (a.charCodeAt(r) - W) / g;
    n[e] = L;
  }
  return n;
}
v(i, "getTextWidthMap");
var _ = i(l), s = {
  createCanvas: /* @__PURE__ */ v(function() {
    return typeof document < "u" && document.createElement("canvas");
  }, "createCanvas"),
  measureText: /* @__PURE__ */ function() {
    var a, n;
    return function(r, e) {
      if (!a) {
        var L = s.createCanvas();
        a = L && L.getContext("2d");
      }
      if (a)
        return n !== e && (n = a.font = e || c), a.measureText(r);
      r = r || "", e = e || c;
      var F = /((?:\d+)?\.?\d*)px/.exec(e), t = F && +F[1] || f, u = 0;
      if (e.indexOf("mono") >= 0)
        u = t * r.length;
      else
        for (var o = 0; o < r.length; o++) {
          var d = _[r[o]];
          u += d == null ? t : d * t;
        }
      return { width: u };
    };
  }(),
  loadImage: /* @__PURE__ */ v(function(a, n, r) {
    var e = new Image();
    return e.onload = n, e.onerror = r, e.src = a, e;
  }, "loadImage")
};
export {
  c as DEFAULT_FONT,
  m as DEFAULT_FONT_FAMILY,
  f as DEFAULT_FONT_SIZE,
  _ as DEFAULT_TEXT_WIDTH_MAP,
  s as platformApi
};
