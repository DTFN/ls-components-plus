var G = Object.defineProperty;
var q = (a, i) => G(a, "name", { value: i, configurable: !0 });
import { distSquare as g, create as B } from "../vector/index.js";
var k = Math.pow, O = Math.sqrt, w = 1e-8, U = 1e-4, Q = O(3), m = 1 / 3, N = B(), t = B(), j = B();
function D(a) {
  return a > -w && a < w;
}
q(D, "isAroundZero");
function z(a) {
  return a > w || a < -w;
}
q(z, "isNotAroundZero");
function P(a, i, u, e, v) {
  var r = 1 - v;
  return r * r * (r * a + 3 * v * i) + v * v * (v * e + 3 * r * u);
}
q(P, "cubicAt");
function W(a, i, u, e, v) {
  var r = 1 - v;
  return 3 * (((i - a) * r + 2 * (u - i) * v) * r + (e - u) * v * v);
}
q(W, "cubicDerivativeAt");
function X(a, i, u, e, v, r) {
  var n = e + 3 * (i - u) - a, l = 3 * (u - i * 2 + a), h = 3 * (i - a), f = a - v, b = l * l - 3 * n * h, c = l * h - 9 * n * f, s = h * h - 3 * l * f, d = 0;
  if (D(b) && D(c))
    if (D(l))
      r[0] = 0;
    else {
      var M = -h / l;
      M >= 0 && M <= 1 && (r[d++] = M);
    }
  else {
    var E = c * c - 4 * b * s;
    if (D(E)) {
      var I = c / b, M = -l / n + I, o = -I / 2;
      M >= 0 && M <= 1 && (r[d++] = M), o >= 0 && o <= 1 && (r[d++] = o);
    } else if (E > 0) {
      var A = O(E), L = b * l + 1.5 * n * (-c + A), T = b * l + 1.5 * n * (-c - A);
      L < 0 ? L = -k(-L, m) : L = k(L, m), T < 0 ? T = -k(-T, m) : T = k(T, m);
      var M = (-l - (L + T)) / (3 * n);
      M >= 0 && M <= 1 && (r[d++] = M);
    } else {
      var F = (2 * b * l - 3 * n * c) / (2 * O(b * b * b)), C = Math.acos(F) / 3, H = O(b), S = Math.cos(C), M = (-l - 2 * H * S) / (3 * n), o = (-l + H * (S + Q * Math.sin(C))) / (3 * n), Z = (-l + H * (S - Q * Math.sin(C))) / (3 * n);
      M >= 0 && M <= 1 && (r[d++] = M), o >= 0 && o <= 1 && (r[d++] = o), Z >= 0 && Z <= 1 && (r[d++] = Z);
    }
  }
  return d;
}
q(X, "cubicRootAt");
function $(a, i, u, e, v) {
  var r = 6 * u - 12 * i + 6 * a, n = 9 * i + 3 * e - 3 * a - 9 * u, l = 3 * i - 3 * a, h = 0;
  if (D(n)) {
    if (z(r)) {
      var f = -l / r;
      f >= 0 && f <= 1 && (v[h++] = f);
    }
  } else {
    var b = r * r - 4 * n * l;
    if (D(b))
      v[0] = -r / (2 * n);
    else if (b > 0) {
      var c = O(b), f = (-r + c) / (2 * n), s = (-r - c) / (2 * n);
      f >= 0 && f <= 1 && (v[h++] = f), s >= 0 && s <= 1 && (v[h++] = s);
    }
  }
  return h;
}
q($, "cubicExtrema");
function K(a, i, u, e, v, r) {
  var n = (i - a) * v + a, l = (u - i) * v + i, h = (e - u) * v + u, f = (l - n) * v + n, b = (h - l) * v + l, c = (b - f) * v + f;
  r[0] = a, r[1] = n, r[2] = f, r[3] = c, r[4] = c, r[5] = b, r[6] = h, r[7] = e;
}
q(K, "cubicSubdivide");
function _(a, i, u, e, v, r, n, l, h, f, b) {
  var c, s = 5e-3, d = 1 / 0, M, E, I, o;
  N[0] = h, N[1] = f;
  for (var A = 0; A < 1; A += 0.05)
    t[0] = P(a, u, v, n, A), t[1] = P(i, e, r, l, A), I = g(N, t), I < d && (c = A, d = I);
  d = 1 / 0;
  for (var L = 0; L < 32 && !(s < U); L++)
    M = c - s, E = c + s, t[0] = P(a, u, v, n, M), t[1] = P(i, e, r, l, M), I = g(t, N), M >= 0 && I < d ? (c = M, d = I) : (j[0] = P(a, u, v, n, E), j[1] = P(i, e, r, l, E), o = g(j, N), E <= 1 && o < d ? (c = E, d = o) : s *= 0.5);
  return b && (b[0] = P(a, u, v, n, c), b[1] = P(i, e, r, l, c)), O(d);
}
q(_, "cubicProjectPoint");
function Y(a, i, u, e, v, r, n, l, h) {
  for (var f = a, b = i, c = 0, s = 1 / h, d = 1; d <= h; d++) {
    var M = d * s, E = P(a, u, v, n, M), I = P(i, e, r, l, M), o = E - f, A = I - b;
    c += Math.sqrt(o * o + A * A), f = E, b = I;
  }
  return c;
}
q(Y, "cubicLength");
function R(a, i, u, e) {
  var v = 1 - e;
  return v * (v * a + 2 * e * i) + e * e * u;
}
q(R, "quadraticAt");
function p(a, i, u, e) {
  return 2 * ((1 - e) * (i - a) + e * (u - i));
}
q(p, "quadraticDerivativeAt");
function y(a, i, u, e, v) {
  var r = a - 2 * i + u, n = 2 * (i - a), l = a - e, h = 0;
  if (D(r)) {
    if (z(n)) {
      var f = -l / n;
      f >= 0 && f <= 1 && (v[h++] = f);
    }
  } else {
    var b = n * n - 4 * r * l;
    if (D(b)) {
      var f = -n / (2 * r);
      f >= 0 && f <= 1 && (v[h++] = f);
    } else if (b > 0) {
      var c = O(b), f = (-n + c) / (2 * r), s = (-n - c) / (2 * r);
      f >= 0 && f <= 1 && (v[h++] = f), s >= 0 && s <= 1 && (v[h++] = s);
    }
  }
  return h;
}
q(y, "quadraticRootAt");
function x(a, i, u) {
  var e = a + u - 2 * i;
  return e === 0 ? 0.5 : (a - i) / e;
}
q(x, "quadraticExtremum");
function rr(a, i, u, e, v) {
  var r = (i - a) * e + a, n = (u - i) * e + i, l = (n - r) * e + r;
  v[0] = a, v[1] = r, v[2] = l, v[3] = l, v[4] = n, v[5] = u;
}
q(rr, "quadraticSubdivide");
function ar(a, i, u, e, v, r, n, l, h) {
  var f, b = 5e-3, c = 1 / 0;
  N[0] = n, N[1] = l;
  for (var s = 0; s < 1; s += 0.05) {
    t[0] = R(a, u, v, s), t[1] = R(i, e, r, s);
    var d = g(N, t);
    d < c && (f = s, c = d);
  }
  c = 1 / 0;
  for (var M = 0; M < 32 && !(b < U); M++) {
    var E = f - b, I = f + b;
    t[0] = R(a, u, v, E), t[1] = R(i, e, r, E);
    var d = g(t, N);
    if (E >= 0 && d < c)
      f = E, c = d;
    else {
      j[0] = R(a, u, v, I), j[1] = R(i, e, r, I);
      var o = g(j, N);
      I <= 1 && o < c ? (f = I, c = o) : b *= 0.5;
    }
  }
  return h && (h[0] = R(a, u, v, f), h[1] = R(i, e, r, f)), O(c);
}
q(ar, "quadraticProjectPoint");
function vr(a, i, u, e, v, r, n) {
  for (var l = a, h = i, f = 0, b = 1 / n, c = 1; c <= n; c++) {
    var s = c * b, d = R(a, u, v, s), M = R(i, e, r, s), E = d - l, I = M - h;
    f += Math.sqrt(E * E + I * I), l = d, h = M;
  }
  return f;
}
q(vr, "quadraticLength");
export {
  P as cubicAt,
  W as cubicDerivativeAt,
  $ as cubicExtrema,
  Y as cubicLength,
  _ as cubicProjectPoint,
  X as cubicRootAt,
  K as cubicSubdivide,
  R as quadraticAt,
  p as quadraticDerivativeAt,
  x as quadraticExtremum,
  vr as quadraticLength,
  ar as quadraticProjectPoint,
  y as quadraticRootAt,
  rr as quadraticSubdivide
};
