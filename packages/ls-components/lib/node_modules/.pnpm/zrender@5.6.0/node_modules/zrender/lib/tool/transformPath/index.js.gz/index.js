var j = Object.defineProperty;
var d = (i, v) => j(i, "name", { value: v, configurable: !0 });
import w from "../../core/PathProxy/index.js";
import { applyTransform as M } from "../../core/vector/index.js";
var c = w.CMD, S = [[], [], []], C = Math.sqrt, T = Math.atan2;
function y(i, v) {
  if (v) {
    var a = i.data, P = i.len(), b, o, r, e, s, t, l = c.M, u = c.C, A = c.L, q = c.R, D = c.A, L = c.Q;
    for (r = 0, e = 0; r < P; ) {
      switch (b = a[r++], e = r, o = 0, b) {
        case l:
          o = 1;
          break;
        case A:
          o = 1;
          break;
        case u:
          o = 3;
          break;
        case L:
          o = 2;
          break;
        case D:
          var Q = v[4], R = v[5], f = C(v[0] * v[0] + v[1] * v[1]), k = C(v[2] * v[2] + v[3] * v[3]), h = T(-v[1] / k, v[0] / f);
          a[r] *= f, a[r++] += Q, a[r] *= k, a[r++] += R, a[r++] *= f, a[r++] *= k, a[r++] += h, a[r++] += h, r += 2, e = r;
          break;
        case q:
          t[0] = a[r++], t[1] = a[r++], M(t, t, v), a[e++] = t[0], a[e++] = t[1], t[0] += a[r++], t[1] += a[r++], M(t, t, v), a[e++] = t[0], a[e++] = t[1];
      }
      for (s = 0; s < o; s++) {
        var n = S[s];
        n[0] = a[r++], n[1] = a[r++], M(n, n, v), a[e++] = n[0], a[e++] = n[1];
      }
    }
    i.increaseVersion();
  }
}
d(y, "transformPath");
export {
  y as default
};
