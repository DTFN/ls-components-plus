var w = Object.defineProperty;
var _ = (a, i) => w(a, "name", { value: i, configurable: !0 });
import { __extends as B } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import E from "../../Element/index.js";
import p from "../../core/BoundingRect/index.js";
import { keys as v, extend as T, createObject as b } from "../../core/util/index.js";
import { STYLE_CHANGED_BIT as c, REDRAW_BIT as D } from "../constants/index.js";
var g = "__zr_style_" + Math.round(Math.random() * 10), M = {
  shadowBlur: 0,
  shadowOffsetX: 0,
  shadowOffsetY: 0,
  shadowColor: "#000",
  opacity: 1,
  blend: "source-over"
}, Y = {
  style: {
    shadowBlur: !0,
    shadowOffsetX: !0,
    shadowOffsetY: !0,
    shadowColor: !0,
    opacity: !0
  }
};
M[g] = !0;
var A = ["z", "z2", "invisible"], N = ["invisible"], O = function(a) {
  B(i, a);
  function i(t) {
    return a.call(this, t) || this;
  }
  return _(i, "Displayable"), i.prototype._init = function(t) {
    for (var e = v(t), r = 0; r < e.length; r++) {
      var o = e[r];
      o === "style" ? this.useStyle(t[o]) : a.prototype.attrKV.call(this, o, t[o]);
    }
    this.style || this.useStyle({});
  }, i.prototype.beforeBrush = function() {
  }, i.prototype.afterBrush = function() {
  }, i.prototype.innerBeforeBrush = function() {
  }, i.prototype.innerAfterBrush = function() {
  }, i.prototype.shouldBePainted = function(t, e, r, o) {
    var n = this.transform;
    if (this.ignore || this.invisible || this.style.opacity === 0 || this.culling && x(this, t, e) || n && !n[0] && !n[3])
      return !1;
    if (r && this.__clipPaths) {
      for (var f = 0; f < this.__clipPaths.length; ++f)
        if (this.__clipPaths[f].isZeroArea())
          return !1;
    }
    if (o && this.parent)
      for (var h = this.parent; h; ) {
        if (h.ignore)
          return !1;
        h = h.parent;
      }
    return !0;
  }, i.prototype.contain = function(t, e) {
    return this.rectContain(t, e);
  }, i.prototype.traverse = function(t, e) {
    t.call(e, this);
  }, i.prototype.rectContain = function(t, e) {
    var r = this.transformCoordToLocal(t, e), o = this.getBoundingRect();
    return o.contain(r[0], r[1]);
  }, i.prototype.getPaintRect = function() {
    var t = this._paintRect;
    if (!this._paintRect || this.__dirty) {
      var e = this.transform, r = this.getBoundingRect(), o = this.style, n = o.shadowBlur || 0, f = o.shadowOffsetX || 0, h = o.shadowOffsetY || 0;
      t = this._paintRect || (this._paintRect = new p(0, 0, 0, 0)), e ? p.applyTransform(t, r, e) : t.copy(r), (n || f || h) && (t.width += n * 2 + Math.abs(f), t.height += n * 2 + Math.abs(h), t.x = Math.min(t.x, t.x + f - n), t.y = Math.min(t.y, t.y + h - n));
      var s = this.dirtyRectTolerance;
      t.isZero() || (t.x = Math.floor(t.x - s), t.y = Math.floor(t.y - s), t.width = Math.ceil(t.width + 1 + s * 2), t.height = Math.ceil(t.height + 1 + s * 2));
    }
    return t;
  }, i.prototype.setPrevPaintRect = function(t) {
    t ? (this._prevPaintRect = this._prevPaintRect || new p(0, 0, 0, 0), this._prevPaintRect.copy(t)) : this._prevPaintRect = null;
  }, i.prototype.getPrevPaintRect = function() {
    return this._prevPaintRect;
  }, i.prototype.animateStyle = function(t) {
    return this.animate("style", t);
  }, i.prototype.updateDuringAnimation = function(t) {
    t === "style" ? this.dirtyStyle() : this.markRedraw();
  }, i.prototype.attrKV = function(t, e) {
    t !== "style" ? a.prototype.attrKV.call(this, t, e) : this.style ? this.setStyle(e) : this.useStyle(e);
  }, i.prototype.setStyle = function(t, e) {
    return typeof t == "string" ? this.style[t] = e : T(this.style, t), this.dirtyStyle(), this;
  }, i.prototype.dirtyStyle = function(t) {
    t || this.markRedraw(), this.__dirty |= c, this._rect && (this._rect = null);
  }, i.prototype.dirty = function() {
    this.dirtyStyle();
  }, i.prototype.styleChanged = function() {
    return !!(this.__dirty & c);
  }, i.prototype.styleUpdated = function() {
    this.__dirty &= ~c;
  }, i.prototype.createStyle = function(t) {
    return b(M, t);
  }, i.prototype.useStyle = function(t) {
    t[g] || (t = this.createStyle(t)), this.__inHover ? this.__hoverStyle = t : this.style = t, this.dirtyStyle();
  }, i.prototype.isStyleObject = function(t) {
    return t[g];
  }, i.prototype._innerSaveToNormal = function(t) {
    a.prototype._innerSaveToNormal.call(this, t);
    var e = this._normalState;
    t.style && !e.style && (e.style = this._mergeStyle(this.createStyle(), this.style)), this._savePrimaryToNormal(t, e, A);
  }, i.prototype._applyStateObj = function(t, e, r, o, n, f) {
    a.prototype._applyStateObj.call(this, t, e, r, o, n, f);
    var h = !(e && o), s;
    if (e && e.style ? n ? o ? s = e.style : (s = this._mergeStyle(this.createStyle(), r.style), this._mergeStyle(s, e.style)) : (s = this._mergeStyle(this.createStyle(), o ? this.style : r.style), this._mergeStyle(s, e.style)) : h && (s = r.style), s)
      if (n) {
        var u = this.style;
        if (this.style = this.createStyle(h ? {} : u), h)
          for (var S = v(u), y = 0; y < S.length; y++) {
            var l = S[y];
            l in s && (s[l] = s[l], this.style[l] = u[l]);
          }
        for (var R = v(s), y = 0; y < R.length; y++) {
          var l = R[y];
          this.style[l] = this.style[l];
        }
        this._transitionState(t, {
          style: s
        }, f, this.getAnimationStyleProps());
      } else
        this.useStyle(s);
    for (var P = this.__inHover ? N : A, y = 0; y < P.length; y++) {
      var l = P[y];
      e && e[l] != null ? this[l] = e[l] : h && r[l] != null && (this[l] = r[l]);
    }
  }, i.prototype._mergeStates = function(t) {
    for (var e = a.prototype._mergeStates.call(this, t), r, o = 0; o < t.length; o++) {
      var n = t[o];
      n.style && (r = r || {}, this._mergeStyle(r, n.style));
    }
    return r && (e.style = r), e;
  }, i.prototype._mergeStyle = function(t, e) {
    return T(t, e), t;
  }, i.prototype.getAnimationStyleProps = function() {
    return Y;
  }, i.initDefaultProps = function() {
    var t = i.prototype;
    t.type = "displayable", t.invisible = !1, t.z = 0, t.z2 = 0, t.zlevel = 0, t.culling = !1, t.cursor = "pointer", t.rectHover = !1, t.incremental = !1, t._rect = null, t.dirtyRectTolerance = 0, t.__dirty = D | c;
  }(), i;
}(E), d = new p(0, 0, 0, 0), m = new p(0, 0, 0, 0);
function x(a, i, t) {
  return d.copy(a.getBoundingRect()), a.transform && d.applyTransform(a.transform), m.width = i, m.height = t, !d.intersect(m);
}
_(x, "isDisplayableCulled");
const U = O;
export {
  Y as DEFAULT_COMMON_ANIMATION_PROPS,
  M as DEFAULT_COMMON_STYLE,
  U as default
};
