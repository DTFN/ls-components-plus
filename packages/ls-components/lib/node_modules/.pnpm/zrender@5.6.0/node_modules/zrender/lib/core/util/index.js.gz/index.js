var M = Object.defineProperty;
var i = (t, n) => M(t, "name", { value: n, configurable: !0 });
var w = b([
  "Function",
  "RegExp",
  "Date",
  "Error",
  "CanvasGradient",
  "CanvasPattern",
  "Image",
  "Canvas"
], function(t, n) {
  return t["[object " + n + "]"] = !0, t;
}, {}), A = b([
  "Int8",
  "Uint8",
  "Uint8Clamped",
  "Int16",
  "Uint16",
  "Int32",
  "Uint32",
  "Float32",
  "Float64"
], function(t, n) {
  return t["[object " + n + "Array]"] = !0, t;
}, {}), a = Object.prototype.toString, h = Array.prototype, P = h.forEach, I = h.filter, g = h.slice, x = h.map, d = (function() {
}).constructor, c = d ? d.prototype : null, m = "__proto__", N = 2311;
function Y() {
  return N++;
}
i(Y, "guid");
function q() {
  for (var t = [], n = 0; n < arguments.length; n++)
    t[n] = arguments[n];
  typeof console < "u" && console.error.apply(console, t);
}
i(q, "logError");
function s(t) {
  if (t == null || typeof t != "object")
    return t;
  var n = t, r = a.call(t);
  if (r === "[object Array]") {
    if (!l(t)) {
      n = [];
      for (var e = 0, o = t.length; e < o; e++)
        n[e] = s(t[e]);
    }
  } else if (A[r]) {
    if (!l(t)) {
      var f = t.constructor;
      if (f.from)
        n = f.from(t);
      else {
        n = new f(t.length);
        for (var e = 0, o = t.length; e < o; e++)
          n[e] = t[e];
      }
    }
  } else if (!w[r] && !l(t) && !v(t)) {
    n = {};
    for (var u in t)
      t.hasOwnProperty(u) && u !== m && (n[u] = s(t[u]));
  }
  return n;
}
i(s, "clone");
function T(t, n, r) {
  if (!p(n) || !p(t))
    return r ? s(n) : t;
  for (var e in n)
    if (n.hasOwnProperty(e) && e !== m) {
      var o = t[e], f = n[e];
      p(f) && p(o) && !y(f) && !y(o) && !v(f) && !v(o) && !O(f) && !O(o) && !l(f) && !l(o) ? T(o, f, r) : (r || !(e in t)) && (t[e] = s(n[e]));
    }
  return t;
}
i(T, "merge");
function R(t, n) {
  if (Object.assign)
    Object.assign(t, n);
  else
    for (var r in n)
      n.hasOwnProperty(r) && r !== m && (t[r] = n[r]);
  return t;
}
i(R, "extend");
function U(t, n, r) {
  for (var e = E(n), o = 0; o < e.length; o++) {
    var f = e[o];
    t[f] == null && (t[f] = n[f]);
  }
  return t;
}
i(U, "defaults");
function J(t, n) {
  if (t) {
    if (t.indexOf)
      return t.indexOf(n);
    for (var r = 0, e = t.length; r < e; r++)
      if (t[r] === n)
        return r;
  }
  return -1;
}
i(J, "indexOf");
function $(t, n) {
  var r = t.prototype;
  function e() {
  }
  i(e, "F"), e.prototype = n.prototype, t.prototype = new e();
  for (var o in r)
    r.hasOwnProperty(o) && (t.prototype[o] = r[o]);
  t.prototype.constructor = t, t.superClass = n;
}
i($, "inherits");
function Q(t, n, r) {
  if (t = "prototype" in t ? t.prototype : t, n = "prototype" in n ? n.prototype : n, Object.getOwnPropertyNames)
    for (var e = Object.getOwnPropertyNames(n), o = 0; o < e.length; o++) {
      var f = e[o];
      f !== "constructor" && t[f] == null && (t[f] = n[f]);
    }
  else
    U(t, n);
}
i(Q, "mixin");
function V(t) {
  return !t || typeof t == "string" ? !1 : typeof t.length == "number";
}
i(V, "isArrayLike");
function D(t, n, r) {
  if (t && n)
    if (t.forEach && t.forEach === P)
      t.forEach(n, r);
    else if (t.length === +t.length)
      for (var e = 0, o = t.length; e < o; e++)
        n.call(r, t[e], e, t);
    else
      for (var f in t)
        t.hasOwnProperty(f) && n.call(r, t[f], f, t);
}
i(D, "each");
function W(t, n, r) {
  if (!t)
    return [];
  if (!n)
    return j(t);
  if (t.map && t.map === x)
    return t.map(n, r);
  for (var e = [], o = 0, f = t.length; o < f; o++)
    e.push(n.call(r, t[o], o, t));
  return e;
}
i(W, "map");
function b(t, n, r, e) {
  if (t && n) {
    for (var o = 0, f = t.length; o < f; o++)
      r = n.call(e, r, t[o], o, t);
    return r;
  }
}
i(b, "reduce");
function X(t, n, r) {
  if (!t)
    return [];
  if (!n)
    return j(t);
  if (t.filter && t.filter === I)
    return t.filter(n, r);
  for (var e = [], o = 0, f = t.length; o < f; o++)
    n.call(r, t[o], o, t) && e.push(t[o]);
  return e;
}
i(X, "filter");
function E(t) {
  if (!t)
    return [];
  if (Object.keys)
    return Object.keys(t);
  var n = [];
  for (var r in t)
    t.hasOwnProperty(r) && n.push(r);
  return n;
}
i(E, "keys");
function C(t, n) {
  for (var r = [], e = 2; e < arguments.length; e++)
    r[e - 2] = arguments[e];
  return function() {
    return t.apply(n, r.concat(g.call(arguments)));
  };
}
i(C, "bindPolyfill");
var Z = c && H(c.bind) ? c.call.bind(c.bind) : C;
function _(t) {
  for (var n = [], r = 1; r < arguments.length; r++)
    n[r - 1] = arguments[r];
  return function() {
    return t.apply(this, n.concat(g.call(arguments)));
  };
}
i(_, "curry");
function y(t) {
  return Array.isArray ? Array.isArray(t) : a.call(t) === "[object Array]";
}
i(y, "isArray");
function H(t) {
  return typeof t == "function";
}
i(H, "isFunction");
function z(t) {
  return typeof t == "string";
}
i(z, "isString");
function k(t) {
  return a.call(t) === "[object String]";
}
i(k, "isStringSafe");
function tt(t) {
  return typeof t == "number";
}
i(tt, "isNumber");
function p(t) {
  var n = typeof t;
  return n === "function" || !!t && n === "object";
}
i(p, "isObject");
function O(t) {
  return !!w[a.call(t)];
}
i(O, "isBuiltInObject");
function nt(t) {
  return !!A[a.call(t)];
}
i(nt, "isTypedArray");
function v(t) {
  return typeof t == "object" && typeof t.nodeType == "number" && typeof t.ownerDocument == "object";
}
i(v, "isDom");
function rt(t) {
  return t.colorStops != null;
}
i(rt, "isGradientObject");
function et(t) {
  return t.image != null;
}
i(et, "isImagePatternObject");
function it(t) {
  return a.call(t) === "[object RegExp]";
}
i(it, "isRegExp");
function ot(t) {
  return t !== t;
}
i(ot, "eqNaN");
function ft() {
  for (var t = [], n = 0; n < arguments.length; n++)
    t[n] = arguments[n];
  for (var r = 0, e = t.length; r < e; r++)
    if (t[r] != null)
      return t[r];
}
i(ft, "retrieve");
function ut(t, n) {
  return t ?? n;
}
i(ut, "retrieve2");
function at(t, n, r) {
  return t ?? n ?? r;
}
i(at, "retrieve3");
function j(t) {
  for (var n = [], r = 1; r < arguments.length; r++)
    n[r - 1] = arguments[r];
  return g.apply(t, n);
}
i(j, "slice");
function lt(t) {
  if (typeof t == "number")
    return [t, t, t, t];
  var n = t.length;
  return n === 2 ? [t[0], t[1], t[0], t[1]] : n === 3 ? [t[0], t[1], t[2], t[1]] : t;
}
i(lt, "normalizeCssArray");
function ct(t, n) {
  if (!t)
    throw new Error(n);
}
i(ct, "assert");
function pt(t) {
  return t == null ? null : typeof t.trim == "function" ? t.trim() : t.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
}
i(pt, "trim");
var F = "__ec_primitive__";
function st(t) {
  t[F] = !0;
}
i(st, "setAsPrimitive");
function l(t) {
  return t[F];
}
i(l, "isPrimitive");
var K = function() {
  function t() {
    this.data = {};
  }
  return i(t, "MapPolyfill"), t.prototype.delete = function(n) {
    var r = this.has(n);
    return r && delete this.data[n], r;
  }, t.prototype.has = function(n) {
    return this.data.hasOwnProperty(n);
  }, t.prototype.get = function(n) {
    return this.data[n];
  }, t.prototype.set = function(n, r) {
    return this.data[n] = r, this;
  }, t.prototype.keys = function() {
    return E(this.data);
  }, t.prototype.forEach = function(n) {
    var r = this.data;
    for (var e in r)
      r.hasOwnProperty(e) && n(r[e], e);
  }, t;
}(), S = typeof Map == "function";
function B() {
  return S ? /* @__PURE__ */ new Map() : new K();
}
i(B, "maybeNativeMap");
var G = function() {
  function t(n) {
    var r = y(n);
    this.data = B();
    var e = this;
    n instanceof t ? n.each(o) : n && D(n, o);
    function o(f, u) {
      r ? e.set(f, u) : e.set(u, f);
    }
    i(o, "visit");
  }
  return i(t, "HashMap"), t.prototype.hasKey = function(n) {
    return this.data.has(n);
  }, t.prototype.get = function(n) {
    return this.data.get(n);
  }, t.prototype.set = function(n, r) {
    return this.data.set(n, r), r;
  }, t.prototype.each = function(n, r) {
    this.data.forEach(function(e, o) {
      n.call(r, e, o);
    });
  }, t.prototype.keys = function() {
    var n = this.data.keys();
    return S ? Array.from(n) : n;
  }, t.prototype.removeKey = function(n) {
    this.data.delete(n);
  }, t;
}();
function ht(t) {
  return new G(t);
}
i(ht, "createHashMap");
function yt(t, n) {
  for (var r = new t.constructor(t.length + n.length), e = 0; e < t.length; e++)
    r[e] = t[e];
  for (var o = t.length, e = 0; e < n.length; e++)
    r[e + o] = n[e];
  return r;
}
i(yt, "concatArray");
function vt(t, n) {
  var r;
  if (Object.create)
    r = Object.create(t);
  else {
    var e = /* @__PURE__ */ i(function() {
    }, "StyleCtor");
    e.prototype = t, r = new e();
  }
  return n && R(r, n), r;
}
i(vt, "createObject");
function gt(t) {
  var n = t.style;
  n.webkitUserSelect = "none", n.userSelect = "none", n.webkitTapHighlightColor = "rgba(0,0,0,0)", n["-webkit-touch-callout"] = "none";
}
i(gt, "disableUserSelect");
function mt(t, n) {
  return t.hasOwnProperty(n);
}
i(mt, "hasOwn");
function dt() {
}
i(dt, "noop");
var Ot = 180 / Math.PI;
export {
  G as HashMap,
  Ot as RADIAN_TO_DEGREE,
  ct as assert,
  Z as bind,
  s as clone,
  yt as concatArray,
  ht as createHashMap,
  vt as createObject,
  _ as curry,
  U as defaults,
  gt as disableUserSelect,
  D as each,
  ot as eqNaN,
  R as extend,
  X as filter,
  Y as guid,
  mt as hasOwn,
  J as indexOf,
  $ as inherits,
  y as isArray,
  V as isArrayLike,
  O as isBuiltInObject,
  v as isDom,
  H as isFunction,
  rt as isGradientObject,
  et as isImagePatternObject,
  tt as isNumber,
  p as isObject,
  l as isPrimitive,
  it as isRegExp,
  z as isString,
  k as isStringSafe,
  nt as isTypedArray,
  E as keys,
  q as logError,
  W as map,
  T as merge,
  Q as mixin,
  dt as noop,
  lt as normalizeCssArray,
  b as reduce,
  ft as retrieve,
  ut as retrieve2,
  at as retrieve3,
  st as setAsPrimitive,
  j as slice,
  pt as trim
};
