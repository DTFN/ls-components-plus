var b = Object.defineProperty;
var f = (r, n) => b(r, "name", { value: n, configurable: !0 });
function M() {
  return [1, 0, 0, 1, 0, 0];
}
f(M, "create");
function g(r) {
  return r[0] = 1, r[1] = 0, r[2] = 0, r[3] = 1, r[4] = 0, r[5] = 0, r;
}
f(g, "identity");
function j(r, n) {
  return r[0] = n[0], r[1] = n[1], r[2] = n[2], r[3] = n[3], r[4] = n[4], r[5] = n[5], r;
}
f(j, "copy");
function k(r, n, a) {
  var e = n[0] * a[0] + n[2] * a[1], c = n[1] * a[0] + n[3] * a[1], i = n[0] * a[2] + n[2] * a[3], l = n[1] * a[2] + n[3] * a[3], s = n[0] * a[4] + n[2] * a[5] + n[4], v = n[1] * a[4] + n[3] * a[5] + n[5];
  return r[0] = e, r[1] = c, r[2] = i, r[3] = l, r[4] = s, r[5] = v, r;
}
f(k, "mul");
function q(r, n, a) {
  return r[0] = n[0], r[1] = n[1], r[2] = n[2], r[3] = n[3], r[4] = n[4] + a[0], r[5] = n[5] + a[1], r;
}
f(q, "translate");
function w(r, n, a, e) {
  e === void 0 && (e = [0, 0]);
  var c = n[0], i = n[2], l = n[4], s = n[1], v = n[3], x = n[5], y = Math.sin(a), d = Math.cos(a);
  return r[0] = c * d + s * y, r[1] = -c * y + s * d, r[2] = i * d + v * y, r[3] = -i * y + d * v, r[4] = d * (l - e[0]) + y * (x - e[1]) + e[0], r[5] = d * (x - e[1]) - y * (l - e[0]) + e[1], r;
}
f(w, "rotate");
function z(r, n, a) {
  var e = a[0], c = a[1];
  return r[0] = n[0] * e, r[1] = n[1] * c, r[2] = n[2] * e, r[3] = n[3] * c, r[4] = n[4] * e, r[5] = n[5] * c, r;
}
f(z, "scale");
function A(r, n) {
  var a = n[0], e = n[2], c = n[4], i = n[1], l = n[3], s = n[5], v = a * l - i * e;
  return v ? (v = 1 / v, r[0] = l * v, r[1] = -i * v, r[2] = -e * v, r[3] = a * v, r[4] = (e * s - l * c) * v, r[5] = (i * c - a * s) * v, r) : null;
}
f(A, "invert");
export {
  j as copy,
  M as create,
  g as identity,
  A as invert,
  k as mul,
  w as rotate,
  z as scale,
  q as translate
};
