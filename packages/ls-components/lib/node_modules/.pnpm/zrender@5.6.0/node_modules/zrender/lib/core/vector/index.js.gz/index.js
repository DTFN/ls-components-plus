var c = Object.defineProperty;
var a = (n, r) => c(n, "name", { value: r, configurable: !0 });
function h(n, r) {
  return n == null && (n = 0), r == null && (r = 0), [n, r];
}
a(h, "create");
function M(n) {
  return [n[0], n[1]];
}
a(M, "clone");
function q(n, r, e) {
  return n[0] = r[0] + e[0], n[1] = r[1] + e[1], n;
}
a(q, "add");
function p(n, r, e) {
  return n[0] = r[0] - e[0], n[1] = r[1] - e[1], n;
}
a(p, "sub");
function f(n) {
  return Math.sqrt(u(n));
}
a(f, "len");
function u(n) {
  return n[0] * n[0] + n[1] * n[1];
}
a(u, "lenSquare");
function m(n, r, e) {
  return n[0] = r[0] * e, n[1] = r[1] * e, n;
}
a(m, "scale");
function x(n, r) {
  var e = f(r);
  return e === 0 ? (n[0] = 0, n[1] = 0) : (n[0] = r[0] / e, n[1] = r[1] / e), n;
}
a(x, "normalize");
function l(n, r) {
  return Math.sqrt((n[0] - r[0]) * (n[0] - r[0]) + (n[1] - r[1]) * (n[1] - r[1]));
}
a(l, "distance");
var S = l;
function s(n, r) {
  return (n[0] - r[0]) * (n[0] - r[0]) + (n[1] - r[1]) * (n[1] - r[1]);
}
a(s, "distanceSquare");
var b = s;
function z(n, r, e, i) {
  return n[0] = r[0] + i * (e[0] - r[0]), n[1] = r[1] + i * (e[1] - r[1]), n;
}
a(z, "lerp");
function T(n, r, e) {
  var i = r[0], t = r[1];
  return n[0] = e[0] * i + e[2] * t + e[4], n[1] = e[1] * i + e[3] * t + e[5], n;
}
a(T, "applyTransform");
function g(n, r, e) {
  return n[0] = Math.min(r[0], e[0]), n[1] = Math.min(r[1], e[1]), n;
}
a(g, "min");
function j(n, r, e) {
  return n[0] = Math.max(r[0], e[0]), n[1] = Math.max(r[1], e[1]), n;
}
a(j, "max");
export {
  q as add,
  T as applyTransform,
  M as clone,
  h as create,
  S as dist,
  b as distSquare,
  l as distance,
  s as distanceSquare,
  f as len,
  u as lenSquare,
  z as lerp,
  j as max,
  g as min,
  x as normalize,
  m as scale,
  p as sub
};
