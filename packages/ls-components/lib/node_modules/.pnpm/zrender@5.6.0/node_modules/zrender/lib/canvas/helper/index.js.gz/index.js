var y = Object.defineProperty;
var d = (r, n) => y(r, "name", { value: n, configurable: !0 });
function g(r) {
  return isFinite(r);
}
d(g, "isSafeNum");
function x(r, n, a) {
  var t = n.x == null ? 0 : n.x, i = n.x2 == null ? 1 : n.x2, l = n.y == null ? 0 : n.y, e = n.y2 == null ? 0 : n.y2;
  n.global || (t = t * a.width + a.x, i = i * a.width + a.x, l = l * a.height + a.y, e = e * a.height + a.y), t = g(t) ? t : 0, i = g(i) ? i : 1, l = g(l) ? l : 0, e = g(e) ? e : 0;
  var u = r.createLinearGradient(t, l, i, e);
  return u;
}
d(x, "createLinearGradient");
function o(r, n, a) {
  var t = a.width, i = a.height, l = Math.min(t, i), e = n.x == null ? 0.5 : n.x, u = n.y == null ? 0.5 : n.y, f = n.r == null ? 0.5 : n.r;
  n.global || (e = e * t + a.x, u = u * i + a.y, f = f * l), e = g(e) ? e : 0.5, u = g(u) ? u : 0.5, f = f >= 0 && g(f) ? f : 0.5;
  var h = r.createRadialGradient(e, u, 0, e, u, f);
  return h;
}
d(o, "createRadialGradient");
function m(r, n, a) {
  for (var t = n.type === "radial" ? o(r, n, a) : x(r, n, a), i = n.colorStops, l = 0; l < i.length; l++)
    t.addColorStop(i[l].offset, i[l].color);
  return t;
}
d(m, "getCanvasGradient");
function s(r, n) {
  if (r === n || !r && !n)
    return !1;
  if (!r || !n || r.length !== n.length)
    return !0;
  for (var a = 0; a < r.length; a++)
    if (r[a] !== n[a])
      return !0;
  return !1;
}
d(s, "isClipPathChanged");
function v(r) {
  return parseInt(r, 10);
}
d(v, "parseInt10");
function S(r, n, a) {
  var t = ["width", "height"][n], i = ["clientWidth", "clientHeight"][n], l = ["paddingLeft", "paddingTop"][n], e = ["paddingRight", "paddingBottom"][n];
  if (a[t] != null && a[t] !== "auto")
    return parseFloat(a[t]);
  var u = document.defaultView.getComputedStyle(r);
  return (r[i] || v(u[t]) || v(r.style[t])) - (v(u[l]) || 0) - (v(u[e]) || 0) | 0;
}
d(S, "getSize");
export {
  x as createLinearGradient,
  o as createRadialGradient,
  m as getCanvasGradient,
  S as getSize,
  s as isClipPathChanged
};
