var $ = Object.defineProperty;
var T = (e, a) => $(e, "name", { value: a, configurable: !0 });
import { __extends as E } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { parsePlainText as tt, parseRichText as rt } from "../helper/parseText/index.js";
import k from "../TSpan/index.js";
import { defaults as et, extend as I, keys as at, retrieve3 as Y, retrieve2 as z, trim as it, each as ot, normalizeCssArray as nt } from "../../core/util/index.js";
import { adjustTextX as H, adjustTextY as R } from "../../contain/text/index.js";
import ht from "../Image/index.js";
import lt from "../shape/Rect/index.js";
import P from "../../core/BoundingRect/index.js";
import ft, { DEFAULT_COMMON_ANIMATION_PROPS as dt } from "../Displayable/index.js";
import { DEFAULT_FONT as Z, DEFAULT_FONT_SIZE as st } from "../../core/platform/index.js";
var U = {
  fill: "#000"
}, M = 2, ut = {
  style: et({
    fill: !0,
    stroke: !0,
    fillOpacity: !0,
    strokeOpacity: !0,
    lineWidth: !0,
    fontSize: !0,
    lineHeight: !0,
    width: !0,
    height: !0,
    textShadowColor: !0,
    textShadowBlur: !0,
    textShadowOffsetX: !0,
    textShadowOffsetY: !0,
    backgroundColor: !0,
    padding: !0,
    borderColor: !0,
    borderWidth: !0,
    borderRadius: !0
  }, dt.style)
}, vt = function(e) {
  E(a, e);
  function a(t) {
    var r = e.call(this) || this;
    return r.type = "text", r._children = [], r._defaultStyle = U, r.attr(t), r;
  }
  return T(a, "ZRText"), a.prototype.childrenRef = function() {
    return this._children;
  }, a.prototype.update = function() {
    e.prototype.update.call(this), this.styleChanged() && this._updateSubTexts();
    for (var t = 0; t < this._children.length; t++) {
      var r = this._children[t];
      r.zlevel = this.zlevel, r.z = this.z, r.z2 = this.z2, r.culling = this.culling, r.cursor = this.cursor, r.invisible = this.invisible;
    }
  }, a.prototype.updateTransform = function() {
    var t = this.innerTransformable;
    t ? (t.updateTransform(), t.transform && (this.transform = t.transform)) : e.prototype.updateTransform.call(this);
  }, a.prototype.getLocalTransform = function(t) {
    var r = this.innerTransformable;
    return r ? r.getLocalTransform(t) : e.prototype.getLocalTransform.call(this, t);
  }, a.prototype.getComputedTransform = function() {
    return this.__hostTarget && (this.__hostTarget.getComputedTransform(), this.__hostTarget.updateInnerText(!0)), e.prototype.getComputedTransform.call(this);
  }, a.prototype._updateSubTexts = function() {
    this._childCursor = 0, xt(this.style), this.style.rich ? this._updateRichTexts() : this._updatePlainTexts(), this._children.length = this._childCursor, this.styleUpdated();
  }, a.prototype.addSelfToZr = function(t) {
    e.prototype.addSelfToZr.call(this, t);
    for (var r = 0; r < this._children.length; r++)
      this._children[r].__zr = t;
  }, a.prototype.removeSelfFromZr = function(t) {
    e.prototype.removeSelfFromZr.call(this, t);
    for (var r = 0; r < this._children.length; r++)
      this._children[r].__zr = null;
  }, a.prototype.getBoundingRect = function() {
    if (this.styleChanged() && this._updateSubTexts(), !this._rect) {
      for (var t = new P(0, 0, 0, 0), r = this._children, o = [], n = null, h = 0; h < r.length; h++) {
        var g = r[h], p = g.getBoundingRect(), l = g.getLocalTransform(o);
        l ? (t.copy(p), t.applyTransform(l), n = n || t.clone(), n.union(t)) : (n = n || p.clone(), n.union(p));
      }
      this._rect = n || t;
    }
    return this._rect;
  }, a.prototype.setDefaultTextStyle = function(t) {
    this._defaultStyle = t || U;
  }, a.prototype.setTextContent = function(t) {
    if (process.env.NODE_ENV !== "production")
      throw new Error("Can't attach text on another text");
  }, a.prototype._mergeStyle = function(t, r) {
    if (!r)
      return t;
    var o = r.rich, n = t.rich || o && {};
    return I(t, r), o && n ? (this._mergeRich(n, o), t.rich = n) : n && (t.rich = n), t;
  }, a.prototype._mergeRich = function(t, r) {
    for (var o = at(r), n = 0; n < o.length; n++) {
      var h = o[n];
      t[h] = t[h] || {}, I(t[h], r[h]);
    }
  }, a.prototype.getAnimationStyleProps = function() {
    return ut;
  }, a.prototype._getOrCreateChild = function(t) {
    var r = this._children[this._childCursor];
    return (!r || !(r instanceof t)) && (r = new t()), this._children[this._childCursor++] = r, r.__zr = this.__zr, r.parent = this, r;
  }, a.prototype._updatePlainTexts = function() {
    var t = this.style, r = t.font || Z, o = t.padding, n = Q(t), h = tt(n, t), g = X(t), p = !!t.backgroundColor, l = h.outerHeight, m = h.outerWidth, w = h.contentWidth, C = h.lines, D = h.lineHeight, x = this._defaultStyle, f = t.x || 0, i = t.y || 0, u = t.align || x.align || "left", s = t.verticalAlign || x.verticalAlign || "top", _ = f, c = R(i, h.contentHeight, s);
    if (g || o) {
      var S = H(f, m, u), F = R(i, l, s);
      g && this._renderBackground(t, t, S, F, m, l);
    }
    c += D / 2, o && (_ = J(f, u, o), s === "top" ? c += o[0] : s === "bottom" && (c -= o[2]));
    for (var W = 0, O = !1, b = q("fill" in t ? t.fill : (O = !0, x.fill)), B = K("stroke" in t ? t.stroke : !p && (!x.autoStroke || O) ? (W = M, x.stroke) : null), A = t.textShadowBlur > 0, L = t.width != null && (t.overflow === "truncate" || t.overflow === "break" || t.overflow === "breakAll"), y = h.calculatedLineHeight, v = 0; v < C.length; v++) {
      var N = this._getOrCreateChild(k), d = N.createStyle();
      N.useStyle(d), d.text = C[v], d.x = _, d.y = c, u && (d.textAlign = u), d.textBaseline = "middle", d.opacity = t.opacity, d.strokeFirst = !0, A && (d.shadowBlur = t.textShadowBlur || 0, d.shadowColor = t.textShadowColor || "transparent", d.shadowOffsetX = t.textShadowOffsetX || 0, d.shadowOffsetY = t.textShadowOffsetY || 0), d.stroke = B, d.fill = b, B && (d.lineWidth = t.lineWidth || W, d.lineDash = t.lineDash, d.lineDashOffset = t.lineDashOffset || 0), d.font = r, j(d, t), c += D, L && N.setBoundingRect(new P(H(d.x, t.width, d.textAlign), R(d.y, y, d.textBaseline), w, y));
    }
  }, a.prototype._updateRichTexts = function() {
    var t = this.style, r = Q(t), o = rt(r, t), n = o.width, h = o.outerWidth, g = o.outerHeight, p = t.padding, l = t.x || 0, m = t.y || 0, w = this._defaultStyle, C = t.align || w.align, D = t.verticalAlign || w.verticalAlign, x = H(l, h, C), f = R(m, g, D), i = x, u = f;
    p && (i += p[3], u += p[0]);
    var s = i + n;
    X(t) && this._renderBackground(t, t, x, f, h, g);
    for (var _ = !!t.backgroundColor, c = 0; c < o.lines.length; c++) {
      for (var S = o.lines[c], F = S.tokens, W = F.length, O = S.lineHeight, b = S.width, B = 0, A = i, L = s, y = W - 1, v = void 0; B < W && (v = F[B], !v.align || v.align === "left"); )
        this._placeToken(v, t, O, u, A, "left", _), b -= v.width, A += v.width, B++;
      for (; y >= 0 && (v = F[y], v.align === "right"); )
        this._placeToken(v, t, O, u, L, "right", _), b -= v.width, L -= v.width, y--;
      for (A += (n - (A - i) - (s - L) - b) / 2; B <= y; )
        v = F[B], this._placeToken(v, t, O, u, A + v.width / 2, "center", _), A += v.width, B++;
      u += O;
    }
  }, a.prototype._placeToken = function(t, r, o, n, h, g, p) {
    var l = r.rich[t.styleName] || {};
    l.text = t.text;
    var m = t.verticalAlign, w = n + o / 2;
    m === "top" ? w = n + t.height / 2 : m === "bottom" && (w = n + o - t.height / 2);
    var C = !t.isLineHolder && X(l);
    C && this._renderBackground(l, r, g === "right" ? h - t.width : g === "center" ? h - t.width / 2 : h, w - t.height / 2, t.width, t.height);
    var D = !!l.backgroundColor, x = t.textPadding;
    x && (h = J(h, g, x), w -= t.height / 2 - x[0] - t.innerHeight / 2);
    var f = this._getOrCreateChild(k), i = f.createStyle();
    f.useStyle(i);
    var u = this._defaultStyle, s = !1, _ = 0, c = q("fill" in l ? l.fill : "fill" in r ? r.fill : (s = !0, u.fill)), S = K("stroke" in l ? l.stroke : "stroke" in r ? r.stroke : !D && !p && (!u.autoStroke || s) ? (_ = M, u.stroke) : null), F = l.textShadowBlur > 0 || r.textShadowBlur > 0;
    i.text = t.text, i.x = h, i.y = w, F && (i.shadowBlur = l.textShadowBlur || r.textShadowBlur || 0, i.shadowColor = l.textShadowColor || r.textShadowColor || "transparent", i.shadowOffsetX = l.textShadowOffsetX || r.textShadowOffsetX || 0, i.shadowOffsetY = l.textShadowOffsetY || r.textShadowOffsetY || 0), i.textAlign = g, i.textBaseline = "middle", i.font = t.font || Z, i.opacity = Y(l.opacity, r.opacity, 1), j(i, l), S && (i.lineWidth = Y(l.lineWidth, r.lineWidth, _), i.lineDash = z(l.lineDash, r.lineDash), i.lineDashOffset = r.lineDashOffset || 0, i.stroke = S), c && (i.fill = c);
    var W = t.contentWidth, O = t.contentHeight;
    f.setBoundingRect(new P(H(i.x, W, i.textAlign), R(i.y, O, i.textBaseline), W, O));
  }, a.prototype._renderBackground = function(t, r, o, n, h, g) {
    var p = t.backgroundColor, l = t.borderWidth, m = t.borderColor, w = p && p.image, C = p && !w, D = t.borderRadius, x = this, f, i;
    if (C || t.lineHeight || l && m) {
      f = this._getOrCreateChild(lt), f.useStyle(f.createStyle()), f.style.fill = null;
      var u = f.shape;
      u.x = o, u.y = n, u.width = h, u.height = g, u.r = D, f.dirtyShape();
    }
    if (C) {
      var s = f.style;
      s.fill = p || null, s.fillOpacity = z(t.fillOpacity, 1);
    } else if (w) {
      i = this._getOrCreateChild(ht), i.onload = function() {
        x.dirtyStyle();
      };
      var _ = i.style;
      _.image = p.image, _.x = o, _.y = n, _.width = h, _.height = g;
    }
    if (l && m) {
      var s = f.style;
      s.lineWidth = l, s.stroke = m, s.strokeOpacity = z(t.strokeOpacity, 1), s.lineDash = t.borderDash, s.lineDashOffset = t.borderDashOffset || 0, f.strokeContainThreshold = 0, f.hasFill() && f.hasStroke() && (s.strokeFirst = !0, s.lineWidth *= 2);
    }
    var c = (f || i).style;
    c.shadowBlur = t.shadowBlur || 0, c.shadowColor = t.shadowColor || "transparent", c.shadowOffsetX = t.shadowOffsetX || 0, c.shadowOffsetY = t.shadowOffsetY || 0, c.opacity = Y(t.opacity, r.opacity, 1);
  }, a.makeFont = function(t) {
    var r = "";
    return _t(t) && (r = [
      t.fontStyle,
      t.fontWeight,
      gt(t.fontSize),
      t.fontFamily || "sans-serif"
    ].join(" ")), r && it(r) || t.textFont || t.font;
  }, a;
}(ft), ct = { left: !0, right: 1, center: 1 }, pt = { top: 1, bottom: 1, middle: 1 }, V = ["fontStyle", "fontWeight", "fontSize", "fontFamily"];
function gt(e) {
  return typeof e == "string" && (e.indexOf("px") !== -1 || e.indexOf("rem") !== -1 || e.indexOf("em") !== -1) ? e : isNaN(+e) ? st + "px" : e + "px";
}
T(gt, "parseFontSize");
function j(e, a) {
  for (var t = 0; t < V.length; t++) {
    var r = V[t], o = a[r];
    o != null && (e[r] = o);
  }
}
T(j, "setSeparateFont");
function _t(e) {
  return e.fontSize != null || e.fontFamily || e.fontWeight;
}
T(_t, "hasSeparateFont");
function xt(e) {
  return G(e), ot(e.rich, G), e;
}
T(xt, "normalizeTextStyle");
function G(e) {
  if (e) {
    e.font = vt.makeFont(e);
    var a = e.align;
    a === "middle" && (a = "center"), e.align = a == null || ct[a] ? a : "left";
    var t = e.verticalAlign;
    t === "center" && (t = "middle"), e.verticalAlign = t == null || pt[t] ? t : "top";
    var r = e.padding;
    r && (e.padding = nt(e.padding));
  }
}
T(G, "normalizeStyle");
function K(e, a) {
  return e == null || a <= 0 || e === "transparent" || e === "none" ? null : e.image || e.colorStops ? "#000" : e;
}
T(K, "getStroke");
function q(e) {
  return e == null || e === "none" ? null : e.image || e.colorStops ? "#000" : e;
}
T(q, "getFill");
function J(e, a, t) {
  return a === "right" ? e - t[1] : a === "center" ? e + t[3] / 2 - t[1] / 2 : e + t[3];
}
T(J, "getTextXForPadding");
function Q(e) {
  var a = e.text;
  return a != null && (a += ""), a;
}
T(Q, "getStyleText");
function X(e) {
  return !!(e.backgroundColor || e.lineHeight || e.borderWidth && e.borderColor);
}
T(X, "needDrawBackground");
export {
  ut as DEFAULT_TEXT_ANIMATION_PROPS,
  vt as default,
  _t as hasSeparateFont,
  xt as normalizeTextStyle,
  gt as parseFontSize
};
