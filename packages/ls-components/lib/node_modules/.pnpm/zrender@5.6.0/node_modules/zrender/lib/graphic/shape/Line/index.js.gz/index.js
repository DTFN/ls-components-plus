var p = Object.defineProperty;
var a = (i, r) => p(i, "name", { value: r, configurable: !0 });
import { __extends as s } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import x from "../../Path/index.js";
import { subPixelOptimizeLine as c } from "../../helper/subPixelOptimize/index.js";
var v = {}, h = function() {
  function i() {
    this.x1 = 0, this.y1 = 0, this.x2 = 0, this.y2 = 0, this.percent = 1;
  }
  return a(i, "LineShape"), i;
}(), m = function(i) {
  s(r, i);
  function r(e) {
    return i.call(this, e) || this;
  }
  return a(r, "Line"), r.prototype.getDefaultStyle = function() {
    return {
      stroke: "#000",
      fill: null
    };
  }, r.prototype.getDefaultShape = function() {
    return new h();
  }, r.prototype.buildPath = function(e, t) {
    var f, l, o, u;
    if (this.subPixelOptimize) {
      var y = c(v, t, this.style);
      f = y.x1, l = y.y1, o = y.x2, u = y.y2;
    } else
      f = t.x1, l = t.y1, o = t.x2, u = t.y2;
    var n = t.percent;
    n !== 0 && (e.moveTo(f, l), n < 1 && (o = f * (1 - n) + o * n, u = l * (1 - n) + u * n), e.lineTo(o, u));
  }, r.prototype.pointAt = function(e) {
    var t = this.shape;
    return [
      t.x1 * (1 - e) + t.x2 * e,
      t.y1 * (1 - e) + t.y2 * e
    ];
  }, r;
}(x);
m.prototype.type = "line";
export {
  h as LineShape,
  m as default
};
