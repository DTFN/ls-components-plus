var nr = Object.defineProperty;
var c = (v, r) => nr(v, "name", { value: r, configurable: !0 });
import { cubicSubdivide as w } from "../../core/curve/index.js";
import S from "../../graphic/Path/index.js";
import { defaults as W, map as O } from "../../core/util/index.js";
import { lerp as ar } from "../../core/vector/index.js";
import { clonePath as er } from "../path/index.js";
import fr from "../../core/Transformable/index.js";
import { split as or } from "../dividePath/index.js";
import { pathToBezierCurves as j } from "../convertPath/index.js";
function lr(v, r) {
  var a = v.length, n = r.length;
  if (a === n)
    return [v, r];
  for (var o = [], i = [], l = a < n ? v : r, e = Math.min(a, n), t = Math.abs(n - a) / 6, f = (e - 2) / 6, u = Math.ceil(t / f) + 1, d = [l[0], l[1]], g = t, T = 2; T < e; ) {
    var D = l[T - 2], _ = l[T - 1], Z = l[T++], s = l[T++], R = l[T++], M = l[T++], E = l[T++], p = l[T++];
    if (g <= 0) {
      d.push(Z, s, R, M, E, p);
      continue;
    }
    for (var h = Math.min(g, u - 1) + 1, C = 1; C <= h; C++) {
      var y = C / h;
      w(D, Z, R, E, y, o), w(_, s, M, p, y, i), D = o[3], _ = i[3], d.push(o[1], i[1], o[2], i[2], D, _), Z = o[5], s = i[5], R = o[6], M = i[6];
    }
    g -= h - 1;
  }
  return l === v ? [d, r] : [v, d];
}
c(lr, "alignSubpath");
function k(v, r) {
  for (var a = v.length, n = v[a - 2], o = v[a - 1], i = [], l = 0; l < r.length; )
    i[l++] = n, i[l++] = o;
  return i;
}
c(k, "createSubpath");
function dr(v, r) {
  for (var a, n, o, i = [], l = [], e = 0; e < Math.max(v.length, r.length); e++) {
    var t = v[e], f = r[e], u = void 0, d = void 0;
    t ? f ? (a = lr(t, f), u = a[0], d = a[1], n = u, o = d) : (d = k(o || t, t), u = t) : (u = k(n || f, f), d = f), i.push(u), l.push(d);
  }
  return [i, l];
}
c(dr, "alignBezierCurves");
function x(v) {
  for (var r = 0, a = 0, n = 0, o = v.length, i = 0, l = o - 2; i < o; l = i, i += 2) {
    var e = v[l], t = v[l + 1], f = v[i], u = v[i + 1], d = e * u - f * t;
    r += d, a += (e + f) * d, n += (t + u) * d;
  }
  return r === 0 ? [v[0] || 0, v[1] || 0] : [a / r / 3, n / r / 3, r];
}
c(x, "centroid");
function ir(v, r, a, n) {
  for (var o = (v.length - 2) / 6, i = 1 / 0, l = 0, e = v.length, t = e - 2, f = 0; f < o; f++) {
    for (var u = f * 6, d = 0, g = 0; g < e; g += 2) {
      var T = g === 0 ? u : (u + g - 2) % t + 2, D = v[T] - a[0], _ = v[T + 1] - a[1], Z = r[g] - n[0], s = r[g + 1] - n[1], R = Z - D, M = s - _;
      d += R * R + M * M;
    }
    d < i && (i = d, l = f);
  }
  return l;
}
c(ir, "findBestRingOffset");
function tr(v) {
  for (var r = [], a = v.length, n = 0; n < a; n += 2)
    r[n] = v[a - n - 2], r[n + 1] = v[a - n - 1];
  return r;
}
c(tr, "reverse");
function ur(v, r, a, n) {
  for (var o = [], i, l = 0; l < v.length; l++) {
    var e = v[l], t = r[l], f = x(e), u = x(t);
    i == null && (i = f[2] < 0 != u[2] < 0);
    var d = [], g = [], T = 0, D = 1 / 0, _ = [], Z = e.length;
    i && (e = tr(e));
    for (var s = ir(e, t, f, u) * 6, R = Z - 2, M = 0; M < R; M += 2) {
      var E = (s + M) % R + 2;
      d[M + 2] = e[E] - f[0], d[M + 3] = e[E + 1] - f[1];
    }
    d[0] = e[s] - f[0], d[1] = e[s + 1] - f[1];
    for (var p = n / a, h = -n / 2; h <= n / 2; h += p) {
      for (var C = Math.sin(h), y = Math.cos(h), I = 0, M = 0; M < e.length; M += 2) {
        var N = d[M], X = d[M + 1], U = t[M] - u[0], H = t[M + 1] - u[1], F = U * y - H * C, G = U * C + H * y;
        _[M] = F, _[M + 1] = G;
        var q = F - N, A = G - X;
        I += q * q + A * A;
      }
      if (I < D) {
        D = I, T = h;
        for (var V = 0; V < _.length; V++)
          g[V] = _[V];
      }
    }
    o.push({
      from: d,
      to: g,
      fromCp: f,
      toCp: u,
      rotation: -T
    });
  }
  return o;
}
c(ur, "findBestMorphingRotation");
function Y(v) {
  return v.__isCombineMorphing;
}
c(Y, "isCombineMorphing");
var B = "__mOriginal_";
function $(v, r, a) {
  var n = B + r, o = v[n] || v[r];
  v[n] || (v[n] = v[r]);
  var i = a.replace, l = a.after, e = a.before;
  v[r] = function() {
    var t = arguments, f;
    return e && e.apply(this, t), i ? f = i.apply(this, t) : f = o.apply(this, t), l && l.apply(this, t), f;
  };
}
c($, "saveAndModifyMethod");
function J(v, r) {
  var a = B + r;
  v[a] && (v[r] = v[a], v[a] = null);
}
c(J, "restoreMethod");
function z(v, r) {
  for (var a = 0; a < v.length; a++)
    for (var n = v[a], o = 0; o < n.length; ) {
      var i = n[o], l = n[o + 1];
      n[o++] = r[0] * i + r[2] * l + r[4], n[o++] = r[1] * i + r[3] * l + r[5];
    }
}
c(z, "applyTransformOnBeziers");
function b(v, r) {
  var a = v.getUpdatedPathProxy(), n = r.getUpdatedPathProxy(), o = dr(j(a), j(n)), i = o[0], l = o[1], e = v.getComputedTransform(), t = r.getComputedTransform();
  function f() {
    this.transform = null;
  }
  c(f, "updateIdentityTransform"), e && z(i, e), t && z(l, t), $(r, "updateTransform", { replace: f }), r.transform = null;
  var u = ur(i, l, 10, Math.PI), d = [];
  $(r, "buildPath", { replace: /* @__PURE__ */ c(function(g) {
    for (var T = r.__morphT, D = 1 - T, _ = [], Z = 0; Z < u.length; Z++) {
      var s = u[Z], R = s.from, M = s.to, E = s.rotation * T, p = s.fromCp, h = s.toCp, C = Math.sin(E), y = Math.cos(E);
      ar(_, p, h, T);
      for (var I = 0; I < R.length; I += 2) {
        var N = R[I], X = R[I + 1], U = M[I], H = M[I + 1], F = N * D + U * T, G = X * D + H * T;
        d[I] = F * y - G * C + _[0], d[I + 1] = F * C + G * y + _[1];
      }
      var q = d[0], A = d[1];
      g.moveTo(q, A);
      for (var I = 2; I < R.length; ) {
        var U = d[I++], H = d[I++], V = d[I++], P = d[I++], K = d[I++], Q = d[I++];
        q === U && A === H && V === K && P === Q ? g.lineTo(K, Q) : g.bezierCurveTo(U, H, V, P, K, Q), q = K, A = Q;
      }
    }
  }, "replace") });
}
c(b, "prepareMorphPath");
function rr(v, r, a) {
  if (!v || !r)
    return r;
  var n = a.done, o = a.during;
  b(v, r), r.__morphT = 0;
  function i() {
    J(r, "buildPath"), J(r, "updateTransform"), r.__morphT = -1, r.createPathProxy(), r.dirtyShape();
  }
  return c(i, "restoreToPath"), r.animateTo({
    __morphT: 1
  }, W({
    during: /* @__PURE__ */ c(function(l) {
      r.dirtyShape(), o && o(l);
    }, "during"),
    done: /* @__PURE__ */ c(function() {
      i(), n && n();
    }, "done")
  }, a)), r;
}
c(rr, "morphPath");
function cr(v, r, a, n, o, i) {
  var l = 16;
  v = o === a ? 0 : Math.round(32767 * (v - a) / (o - a)), r = i === n ? 0 : Math.round(32767 * (r - n) / (i - n));
  for (var e = 0, t, f = (1 << l) / 2; f > 0; f /= 2) {
    var u = 0, d = 0;
    (v & f) > 0 && (u = 1), (r & f) > 0 && (d = 1), e += f * f * (3 * u ^ d), d === 0 && (u === 1 && (v = f - 1 - v, r = f - 1 - r), t = v, v = r, r = t);
  }
  return e;
}
c(cr, "hilbert");
function m(v) {
  var r = 1 / 0, a = 1 / 0, n = -1 / 0, o = -1 / 0, i = O(v, function(e) {
    var t = e.getBoundingRect(), f = e.getComputedTransform(), u = t.x + t.width / 2 + (f ? f[4] : 0), d = t.y + t.height / 2 + (f ? f[5] : 0);
    return r = Math.min(u, r), a = Math.min(d, a), n = Math.max(u, n), o = Math.max(d, o), [u, d];
  }), l = O(i, function(e, t) {
    return {
      cp: e,
      z: cr(e[0], e[1], r, a, n, o),
      path: v[t]
    };
  });
  return l.sort(function(e, t) {
    return e.z - t.z;
  }).map(function(e) {
    return e.path;
  });
}
c(m, "sortPaths");
function vr(v) {
  return or(v.path, v.count);
}
c(vr, "defaultDividePath");
function L() {
  return {
    fromIndividuals: [],
    toIndividuals: [],
    count: 0
  };
}
c(L, "createEmptyReturn");
function Rr(v, r, a) {
  var n = [];
  function o(p) {
    for (var h = 0; h < p.length; h++) {
      var C = p[h];
      Y(C) ? o(C.childrenRef()) : C instanceof S && n.push(C);
    }
  }
  c(o, "addFromPath"), o(v);
  var i = n.length;
  if (!i)
    return L();
  var l = a.dividePath || vr, e = l({
    path: r,
    count: i
  });
  if (e.length !== i)
    return console.error("Invalid morphing: unmatched splitted path"), L();
  n = m(n), e = m(e);
  for (var t = a.done, f = a.during, u = a.individualDelay, d = new fr(), g = 0; g < i; g++) {
    var T = n[g], D = e[g];
    D.parent = r, D.copyTransform(d), u || b(T, D);
  }
  r.__isCombineMorphing = !0, r.childrenRef = function() {
    return e;
  };
  function _(p) {
    for (var h = 0; h < e.length; h++)
      e[h].addSelfToZr(p);
  }
  c(_, "addToSubPathListToZr"), $(r, "addSelfToZr", {
    after: /* @__PURE__ */ c(function(p) {
      _(p);
    }, "after")
  }), $(r, "removeSelfFromZr", {
    after: /* @__PURE__ */ c(function(p) {
      for (var h = 0; h < e.length; h++)
        e[h].removeSelfFromZr(p);
    }, "after")
  });
  function Z() {
    r.__isCombineMorphing = !1, r.__morphT = -1, r.childrenRef = null, J(r, "addSelfToZr"), J(r, "removeSelfFromZr");
  }
  c(Z, "restoreToPath");
  var s = e.length;
  if (u)
    for (var R = s, M = /* @__PURE__ */ c(function() {
      R--, R === 0 && (Z(), t && t());
    }, "eachDone"), g = 0; g < s; g++) {
      var E = u ? W({
        delay: (a.delay || 0) + u(g, s, n[g], e[g]),
        done: M
      }, a) : a;
      rr(n[g], e[g], E);
    }
  else
    r.__morphT = 0, r.animateTo({
      __morphT: 1
    }, W({
      during: /* @__PURE__ */ c(function(p) {
        for (var h = 0; h < s; h++) {
          var C = e[h];
          C.__morphT = r.__morphT, C.dirtyShape();
        }
        f && f(p);
      }, "during"),
      done: /* @__PURE__ */ c(function() {
        Z();
        for (var p = 0; p < v.length; p++)
          J(v[p], "updateTransform");
        t && t();
      }, "done")
    }, a));
  return r.__zr && _(r.__zr), {
    fromIndividuals: n,
    toIndividuals: e,
    count: s
  };
}
c(Rr, "combineMorph");
function Cr(v, r, a) {
  var n = r.length, o = [], i = a.dividePath || vr;
  function l(T) {
    for (var D = 0; D < T.length; D++) {
      var _ = T[D];
      Y(_) ? l(_.childrenRef()) : _ instanceof S && o.push(_);
    }
  }
  if (c(l, "addFromPath"), Y(v)) {
    l(v.childrenRef());
    var e = o.length;
    if (e < n)
      for (var t = 0, f = e; f < n; f++)
        o.push(er(o[t++ % e]));
    o.length = n;
  } else {
    o = i({ path: v, count: n });
    for (var u = v.getComputedTransform(), f = 0; f < o.length; f++)
      o[f].setLocalTransform(u);
    if (o.length !== n)
      return console.error("Invalid morphing: unmatched splitted path"), L();
  }
  o = m(o), r = m(r);
  for (var d = a.individualDelay, f = 0; f < n; f++) {
    var g = d ? W({
      delay: (a.delay || 0) + d(f, n, o[f], r[f])
    }, a) : a;
    rr(o[f], r[f], g);
  }
  return {
    fromIndividuals: o,
    toIndividuals: r,
    count: r.length
  };
}
c(Cr, "separateMorph");
export {
  dr as alignBezierCurves,
  x as centroid,
  Rr as combineMorph,
  or as defaultDividePath,
  Y as isCombineMorphing,
  rr as morphPath,
  Cr as separateMorph
};
