var p = Object.defineProperty;
var o = (s, r) => p(s, "name", { value: r, configurable: !0 });
import { __extends as y } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import h from "../Displayable/index.js";
import u from "../../core/BoundingRect/index.js";
var f = [], c = function(s) {
  y(r, s);
  function r() {
    var t = s !== null && s.apply(this, arguments) || this;
    return t.notClear = !0, t.incremental = !0, t._displayables = [], t._temporaryDisplayables = [], t._cursor = 0, t;
  }
  return o(r, "IncrementalDisplayable"), r.prototype.traverse = function(t, a) {
    t.call(a, this);
  }, r.prototype.useStyle = function() {
    this.style = {};
  }, r.prototype.getCursor = function() {
    return this._cursor;
  }, r.prototype.innerAfterBrush = function() {
    this._cursor = this._displayables.length;
  }, r.prototype.clearDisplaybles = function() {
    this._displayables = [], this._temporaryDisplayables = [], this._cursor = 0, this.markRedraw(), this.notClear = !1;
  }, r.prototype.clearTemporalDisplayables = function() {
    this._temporaryDisplayables = [];
  }, r.prototype.addDisplayable = function(t, a) {
    a ? this._temporaryDisplayables.push(t) : this._displayables.push(t), this.markRedraw();
  }, r.prototype.addDisplayables = function(t, a) {
    a = a || !1;
    for (var e = 0; e < t.length; e++)
      this.addDisplayable(t[e], a);
  }, r.prototype.getDisplayables = function() {
    return this._displayables;
  }, r.prototype.getTemporalDisplayables = function() {
    return this._temporaryDisplayables;
  }, r.prototype.eachPendingDisplayable = function(t) {
    for (var a = this._cursor; a < this._displayables.length; a++)
      t && t(this._displayables[a]);
    for (var a = 0; a < this._temporaryDisplayables.length; a++)
      t && t(this._temporaryDisplayables[a]);
  }, r.prototype.update = function() {
    this.updateTransform();
    for (var t = this._cursor; t < this._displayables.length; t++) {
      var a = this._displayables[t];
      a.parent = this, a.update(), a.parent = null;
    }
    for (var t = 0; t < this._temporaryDisplayables.length; t++) {
      var a = this._temporaryDisplayables[t];
      a.parent = this, a.update(), a.parent = null;
    }
  }, r.prototype.getBoundingRect = function() {
    if (!this._rect) {
      for (var t = new u(1 / 0, 1 / 0, -1 / 0, -1 / 0), a = 0; a < this._displayables.length; a++) {
        var e = this._displayables[a], i = e.getBoundingRect().clone();
        e.needLocalTransform() && i.applyTransform(e.getLocalTransform(f)), t.union(i);
      }
      this._rect = t;
    }
    return this._rect;
  }, r.prototype.contain = function(t, a) {
    var e = this.transformCoordToLocal(t, a), i = this.getBoundingRect();
    if (i.contain(e[0], e[1]))
      for (var n = 0; n < this._displayables.length; n++) {
        var l = this._displayables[n];
        if (l.contain(t, a))
          return !0;
      }
    return !1;
  }, r;
}(h);
const g = c;
export {
  g as default
};
