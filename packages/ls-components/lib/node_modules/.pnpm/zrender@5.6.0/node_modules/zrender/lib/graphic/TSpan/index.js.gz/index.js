var s = Object.defineProperty;
var l = (o, e) => s(o, "name", { value: e, configurable: !0 });
import { __extends as a } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import p from "../Displayable/index.js";
import { getBoundingRect as f } from "../../contain/text/index.js";
import { DEFAULT_PATH_STYLE as u } from "../Path/index.js";
import { defaults as y, createObject as h } from "../../core/util/index.js";
import { DEFAULT_FONT as m } from "../../core/platform/index.js";
var c = y({
  strokeFirst: !0,
  font: m,
  x: 0,
  y: 0,
  textAlign: "left",
  textBaseline: "top",
  miterLimit: 2
}, u), v = function(o) {
  a(e, o);
  function e() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return l(e, "TSpan"), e.prototype.hasStroke = function() {
    var t = this.style, r = t.stroke;
    return r != null && r !== "none" && t.lineWidth > 0;
  }, e.prototype.hasFill = function() {
    var t = this.style, r = t.fill;
    return r != null && r !== "none";
  }, e.prototype.createStyle = function(t) {
    return h(c, t);
  }, e.prototype.setBoundingRect = function(t) {
    this._rect = t;
  }, e.prototype.getBoundingRect = function() {
    var t = this.style;
    if (!this._rect) {
      var r = t.text;
      r != null ? r += "" : r = "";
      var n = f(r, t.font, t.textAlign, t.textBaseline);
      if (n.x += t.x || 0, n.y += t.y || 0, this.hasStroke()) {
        var i = t.lineWidth;
        n.x -= i / 2, n.y -= i / 2, n.width += i, n.height += i;
      }
      this._rect = n;
    }
    return this._rect;
  }, e.initDefaultProps = function() {
    var t = e.prototype;
    t.dirtyRectTolerance = 10;
  }(), e;
}(p);
v.prototype.type = "tspan";
export {
  c as DEFAULT_TSPAN_STYLE,
  v as default
};
