var ev = Object.defineProperty;
var p = (v, e) => ev(v, "name", { value: e, configurable: !0 });
import { isArray as uv } from "../../../core/util/index.js";
var yv = Math.PI, av = yv * 2, Q = Math.sin, Y = Math.cos, dv = Math.acos, h = Math.atan2, fv = Math.abs, E = Math.sqrt, S = Math.max, C = Math.min, s = 1e-4;
function Tv(v, e, i, u, r, N, Z, G) {
  var d = i - v, T = u - e, o = Z - r, n = G - N, f = n * d - o * T;
  if (!(f * f < s))
    return f = (o * (e - N) - n * (v - r)) / f, [v + f * d, e + f * T];
}
p(Tv, "intersect");
function M(v, e, i, u, r, N, Z) {
  var G = v - i, d = e - u, T = (Z ? N : -N) / E(G * G + d * d), o = T * d, n = -T * G, f = v + o, l = e + n, U = i + o, H = u + n, V = (f + U) / 2, W = (l + H) / 2, g = U - f, A = H - l, B = g * g + A * A, J = r - N, b = f * H - U * l, k = (A < 0 ? -1 : 1) * E(S(0, J * J * B - b * b)), q = (b * A - g * k) / B, m = (-b * g - A * k) / B, P = (b * A + g * k) / B, D = (-b * g + A * k) / B, F = q - V, K = m - W, L = P - V, w = D - W;
  return F * F + K * K > L * L + w * w && (q = P, m = D), {
    cx: q,
    cy: m,
    x0: -o,
    y0: -n,
    x1: q * (r / J - 1),
    y1: m * (r / J - 1)
  };
}
p(M, "computeCornerTangents");
function hv(v) {
  var e;
  if (uv(v)) {
    var i = v.length;
    if (!i)
      return v;
    i === 1 ? e = [v[0], v[0], 0, 0] : i === 2 ? e = [v[0], v[0], v[1], v[1]] : i === 3 ? e = v.concat(v[2]) : e = v;
  } else
    e = [v, v, v, v];
  return e;
}
p(hv, "normalizeCornerRadius");
function sv(v, e) {
  var i, u = S(e.r, 0), r = S(e.r0 || 0, 0), N = u > 0, Z = r > 0;
  if (!(!N && !Z)) {
    if (N || (u = r, r = 0), r > u) {
      var G = u;
      u = r, r = G;
    }
    var d = e.startAngle, T = e.endAngle;
    if (!(isNaN(d) || isNaN(T))) {
      var o = e.cx, n = e.cy, f = !!e.clockwise, l = fv(T - d), U = l > av && l % av;
      if (U > s && (l = U), !(u > s))
        v.moveTo(o, n);
      else if (l > av - s)
        v.moveTo(o + u * Y(d), n + u * Q(d)), v.arc(o, n, u, d, T, !f), r > s && (v.moveTo(o + r * Y(T), n + r * Q(T)), v.arc(o, n, r, T, d, f));
      else {
        var H = void 0, V = void 0, W = void 0, g = void 0, A = void 0, B = void 0, J = void 0, b = void 0, k = void 0, q = void 0, m = void 0, P = void 0, D = void 0, F = void 0, K = void 0, L = void 0, w = u * Y(d), X = u * Q(d), $ = r * Y(T), I = r * Q(T), _ = l > s;
        if (_) {
          var rv = e.cornerRadius;
          rv && (i = hv(rv), H = i[0], V = i[1], W = i[2], g = i[3]);
          var O = fv(u - r) / 2;
          if (A = C(O, W), B = C(O, g), J = C(O, H), b = C(O, V), m = k = S(A, B), P = q = S(J, b), (k > s || q > s) && (D = u * Y(T), F = u * Q(T), K = r * Y(d), L = r * Q(d), l < yv)) {
            var z = Tv(w, X, K, L, D, F, $, I);
            if (z) {
              var x = w - z[0], t = X - z[1], c = D - z[0], vv = F - z[1], ov = 1 / Q(dv((x * c + t * vv) / (E(x * x + t * t) * E(c * c + vv * vv))) / 2), nv = E(z[0] * z[0] + z[1] * z[1]);
              m = C(k, (u - nv) / (ov + 1)), P = C(q, (r - nv) / (ov - 1));
            }
          }
        }
        if (!_)
          v.moveTo(o + w, n + X);
        else if (m > s) {
          var R = C(W, m), j = C(g, m), a = M(K, L, w, X, u, R, f), y = M(D, F, $, I, u, j, f);
          v.moveTo(o + a.cx + a.x0, n + a.cy + a.y0), m < k && R === j ? v.arc(o + a.cx, n + a.cy, m, h(a.y0, a.x0), h(y.y0, y.x0), !f) : (R > 0 && v.arc(o + a.cx, n + a.cy, R, h(a.y0, a.x0), h(a.y1, a.x1), !f), v.arc(o, n, u, h(a.cy + a.y1, a.cx + a.x1), h(y.cy + y.y1, y.cx + y.x1), !f), j > 0 && v.arc(o + y.cx, n + y.cy, j, h(y.y1, y.x1), h(y.y0, y.x0), !f));
        } else
          v.moveTo(o + w, n + X), v.arc(o, n, u, d, T, !f);
        if (!(r > s) || !_)
          v.lineTo(o + $, n + I);
        else if (P > s) {
          var R = C(H, P), j = C(V, P), a = M($, I, D, F, r, -j, f), y = M(w, X, K, L, r, -R, f);
          v.lineTo(o + a.cx + a.x0, n + a.cy + a.y0), P < q && R === j ? v.arc(o + a.cx, n + a.cy, P, h(a.y0, a.x0), h(y.y0, y.x0), !f) : (j > 0 && v.arc(o + a.cx, n + a.cy, j, h(a.y0, a.x0), h(a.y1, a.x1), !f), v.arc(o, n, r, h(a.cy + a.y1, a.cx + a.x1), h(y.cy + y.y1, y.cx + y.x1), f), R > 0 && v.arc(o + y.cx, n + y.cy, R, h(y.y1, y.x1), h(y.y0, y.x0), !f));
        } else
          v.lineTo(o + $, n + I), v.arc(o, n, r, T, d, f);
      }
      v.closePath();
    }
  }
}
p(sv, "buildPath");
export {
  sv as buildPath
};
