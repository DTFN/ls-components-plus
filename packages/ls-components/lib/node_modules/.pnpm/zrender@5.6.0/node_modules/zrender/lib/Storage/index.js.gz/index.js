var z = Object.defineProperty;
var n = (i, t) => z(i, "name", { value: t, configurable: !0 });
import { indexOf as g } from "../core/util/index.js";
import A from "../core/timsort/index.js";
import { REDRAW_BIT as D } from "../graphic/constants/index.js";
var v = !1;
function l() {
  v || (v = !0, console.warn("z / z2 / zlevel of displayable is invalid, which may cause unexpected errors"));
}
n(l, "logInvalidZError");
function L(i, t) {
  return i.zlevel === t.zlevel ? i.z === t.z ? i.z2 - t.z2 : i.z - t.z : i.zlevel - t.zlevel;
}
n(L, "shapeCompareFunc");
var N = function() {
  function i() {
    this._roots = [], this._displayList = [], this._displayListLen = 0, this.displayableSortFunc = L;
  }
  return n(i, "Storage"), i.prototype.traverse = function(t, e) {
    for (var s = 0; s < this._roots.length; s++)
      this._roots[s].traverse(t, e);
  }, i.prototype.getDisplayList = function(t, e) {
    e = e || !1;
    var s = this._displayList;
    return (t || !s.length) && this.updateDisplayList(e), s;
  }, i.prototype.updateDisplayList = function(t) {
    this._displayListLen = 0;
    for (var e = this._roots, s = this._displayList, o = 0, a = e.length; o < a; o++)
      this._updateAndAddDisplayable(e[o], null, t);
    s.length = this._displayListLen, A(s, L);
  }, i.prototype._updateAndAddDisplayable = function(t, e, s) {
    if (!(t.ignore && !s)) {
      t.beforeUpdate(), t.update(), t.afterUpdate();
      var o = t.getClipPath();
      if (t.ignoreClip)
        e = null;
      else if (o) {
        e ? e = e.slice() : e = [];
        for (var a = o, d = t; a; )
          a.parent = d, a.updateTransform(), e.push(a), d = a, a = a.getClipPath();
      }
      if (t.childrenRef) {
        for (var _ = t.childrenRef(), f = 0; f < _.length; f++) {
          var p = _[f];
          t.__dirty && (p.__dirty |= D), this._updateAndAddDisplayable(p, e, s);
        }
        t.__dirty = 0;
      } else {
        var r = t;
        e && e.length ? r.__clipPaths = e : r.__clipPaths && r.__clipPaths.length > 0 && (r.__clipPaths = []), isNaN(r.z) && (l(), r.z = 0), isNaN(r.z2) && (l(), r.z2 = 0), isNaN(r.zlevel) && (l(), r.zlevel = 0), this._displayList[this._displayListLen++] = r;
      }
      var y = t.getDecalElement && t.getDecalElement();
      y && this._updateAndAddDisplayable(y, e, s);
      var u = t.getTextGuideLine();
      u && this._updateAndAddDisplayable(u, e, s);
      var h = t.getTextContent();
      h && this._updateAndAddDisplayable(h, e, s);
    }
  }, i.prototype.addRoot = function(t) {
    t.__zr && t.__zr.storage === this || this._roots.push(t);
  }, i.prototype.delRoot = function(t) {
    if (t instanceof Array) {
      for (var e = 0, s = t.length; e < s; e++)
        this.delRoot(t[e]);
      return;
    }
    var o = g(this._roots, t);
    o >= 0 && this._roots.splice(o, 1);
  }, i.prototype.delAllRoots = function() {
    this._roots = [], this._displayList = [], this._displayListLen = 0;
  }, i.prototype.getRoots = function() {
    return this._roots;
  }, i.prototype.dispose = function() {
    this._displayList = null, this._roots = null;
  }, i;
}();
export {
  N as default
};
