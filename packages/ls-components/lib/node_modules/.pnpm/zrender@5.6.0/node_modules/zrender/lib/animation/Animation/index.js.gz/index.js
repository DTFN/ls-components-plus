var f = Object.defineProperty;
var s = (r, e) => f(r, "name", { value: e, configurable: !0 });
import { __extends as m } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import _ from "../../core/Eventful/index.js";
import p from "../requestAnimationFrame/index.js";
import l from "../Animator/index.js";
function o() {
  return (/* @__PURE__ */ new Date()).getTime();
}
s(o, "getTime");
var x = function(r) {
  m(e, r);
  function e(t) {
    var i = r.call(this) || this;
    return i._running = !1, i._time = 0, i._pausedTime = 0, i._pauseStart = 0, i._paused = !1, t = t || {}, i.stage = t.stage || {}, i;
  }
  return s(e, "Animation"), e.prototype.addClip = function(t) {
    t.animation && this.removeClip(t), this._head ? (this._tail.next = t, t.prev = this._tail, t.next = null, this._tail = t) : this._head = this._tail = t, t.animation = this;
  }, e.prototype.addAnimator = function(t) {
    t.animation = this;
    var i = t.getClip();
    i && this.addClip(i);
  }, e.prototype.removeClip = function(t) {
    if (t.animation) {
      var i = t.prev, n = t.next;
      i ? i.next = n : this._head = n, n ? n.prev = i : this._tail = i, t.next = t.prev = t.animation = null;
    }
  }, e.prototype.removeAnimator = function(t) {
    var i = t.getClip();
    i && this.removeClip(i), t.animation = null;
  }, e.prototype.update = function(t) {
    for (var i = o() - this._pausedTime, n = i - this._time, a = this._head; a; ) {
      var u = a.next, h = a.step(i, n);
      h && (a.ondestroy(), this.removeClip(a)), a = u;
    }
    this._time = i, t || (this.trigger("frame", n), this.stage.update && this.stage.update());
  }, e.prototype._startLoop = function() {
    var t = this;
    this._running = !0;
    function i() {
      t._running && (p(i), !t._paused && t.update());
    }
    s(i, "step"), p(i);
  }, e.prototype.start = function() {
    this._running || (this._time = o(), this._pausedTime = 0, this._startLoop());
  }, e.prototype.stop = function() {
    this._running = !1;
  }, e.prototype.pause = function() {
    this._paused || (this._pauseStart = o(), this._paused = !0);
  }, e.prototype.resume = function() {
    this._paused && (this._pausedTime += o() - this._pauseStart, this._paused = !1);
  }, e.prototype.clear = function() {
    for (var t = this._head; t; ) {
      var i = t.next;
      t.prev = t.next = t.animation = null, t = i;
    }
    this._head = this._tail = null;
  }, e.prototype.isFinished = function() {
    return this._head == null;
  }, e.prototype.animate = function(t, i) {
    i = i || {}, this.start();
    var n = new l(t, i.loop);
    return this.addAnimator(n), n;
  }, e;
}(_);
export {
  x as default,
  o as getTime
};
