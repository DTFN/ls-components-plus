var x = Object.defineProperty;
var c = (a, r) => x(a, "name", { value: r, configurable: !0 });
import { create as l, mul as v, copy as R, invert as P, rotate as q, identity as G } from "../matrix/index.js";
import { applyTransform as g } from "../vector/index.js";
var L = G, M = 5e-5;
function e(a) {
  return a > M || a < -M;
}
c(e, "isNotAroundZero");
var f = [], h = [], p = l(), u = Math.abs, N = function() {
  function a() {
  }
  return c(a, "Transformable"), a.prototype.getLocalTransform = function(r) {
    return a.getLocalTransform(this, r);
  }, a.prototype.setPosition = function(r) {
    this.x = r[0], this.y = r[1];
  }, a.prototype.setScale = function(r) {
    this.scaleX = r[0], this.scaleY = r[1];
  }, a.prototype.setSkew = function(r) {
    this.skewX = r[0], this.skewY = r[1];
  }, a.prototype.setOrigin = function(r) {
    this.originX = r[0], this.originY = r[1];
  }, a.prototype.needLocalTransform = function() {
    return e(this.rotation) || e(this.x) || e(this.y) || e(this.scaleX - 1) || e(this.scaleY - 1) || e(this.skewX) || e(this.skewY);
  }, a.prototype.updateTransform = function() {
    var r = this.parent && this.parent.transform, t = this.needLocalTransform(), o = this.transform;
    if (!(t || r)) {
      o && (L(o), this.invTransform = null);
      return;
    }
    o = o || l(), t ? this.getLocalTransform(o) : L(o), r && (t ? v(o, r, o) : R(o, r)), this.transform = o, this._resolveGlobalScaleRatio(o);
  }, a.prototype._resolveGlobalScaleRatio = function(r) {
    var t = this.globalScaleRatio;
    if (t != null && t !== 1) {
      this.getGlobalScale(f);
      var o = f[0] < 0 ? -1 : 1, n = f[1] < 0 ? -1 : 1, s = ((f[0] - o) * t + o) / f[0] || 0, i = ((f[1] - n) * t + n) / f[1] || 0;
      r[0] *= s, r[1] *= s, r[2] *= i, r[3] *= i;
    }
    this.invTransform = this.invTransform || l(), P(this.invTransform, r);
  }, a.prototype.getComputedTransform = function() {
    for (var r = this, t = []; r; )
      t.push(r), r = r.parent;
    for (; r = t.pop(); )
      r.updateTransform();
    return this.transform;
  }, a.prototype.setLocalTransform = function(r) {
    if (r) {
      var t = r[0] * r[0] + r[1] * r[1], o = r[2] * r[2] + r[3] * r[3], n = Math.atan2(r[1], r[0]), s = Math.PI / 2 + n - Math.atan2(r[3], r[2]);
      o = Math.sqrt(o) * Math.cos(s), t = Math.sqrt(t), this.skewX = s, this.skewY = 0, this.rotation = -n, this.x = +r[4], this.y = +r[5], this.scaleX = t, this.scaleY = o, this.originX = 0, this.originY = 0;
    }
  }, a.prototype.decomposeTransform = function() {
    if (this.transform) {
      var r = this.parent, t = this.transform;
      r && r.transform && (r.invTransform = r.invTransform || l(), v(h, r.invTransform, t), t = h);
      var o = this.originX, n = this.originY;
      (o || n) && (p[4] = o, p[5] = n, v(h, t, p), h[4] -= o, h[5] -= n, t = h), this.setLocalTransform(t);
    }
  }, a.prototype.getGlobalScale = function(r) {
    var t = this.transform;
    return r = r || [], t ? (r[0] = Math.sqrt(t[0] * t[0] + t[1] * t[1]), r[1] = Math.sqrt(t[2] * t[2] + t[3] * t[3]), t[0] < 0 && (r[0] = -r[0]), t[3] < 0 && (r[1] = -r[1]), r) : (r[0] = 1, r[1] = 1, r);
  }, a.prototype.transformCoordToLocal = function(r, t) {
    var o = [r, t], n = this.invTransform;
    return n && g(o, o, n), o;
  }, a.prototype.transformCoordToGlobal = function(r, t) {
    var o = [r, t], n = this.transform;
    return n && g(o, o, n), o;
  }, a.prototype.getLineScale = function() {
    var r = this.transform;
    return r && u(r[0] - 1) > 1e-10 && u(r[3] - 1) > 1e-10 ? Math.sqrt(u(r[0] * r[3] - r[2] * r[1])) : 1;
  }, a.prototype.copyTransform = function(r) {
    O(this, r);
  }, a.getLocalTransform = function(r, t) {
    t = t || [];
    var o = r.originX || 0, n = r.originY || 0, s = r.scaleX, i = r.scaleY, T = r.anchorX, y = r.anchorY, m = r.rotation || 0, b = r.x, d = r.y, X = r.skewX ? Math.tan(r.skewX) : 0, Y = r.skewY ? Math.tan(-r.skewY) : 0;
    if (o || n || T || y) {
      var w = o + T, k = n + y;
      t[4] = -w * s - X * k * i, t[5] = -k * i - Y * w * s;
    } else
      t[4] = t[5] = 0;
    return t[0] = s, t[3] = i, t[1] = Y * s, t[2] = X * i, m && q(t, t, m), t[4] += o + b, t[5] += n + d, t;
  }, a.initDefaultProps = function() {
    var r = a.prototype;
    r.scaleX = r.scaleY = r.globalScaleRatio = 1, r.x = r.y = r.originX = r.originY = r.skewX = r.skewY = r.rotation = r.anchorX = r.anchorY = 0;
  }(), a;
}(), S = [
  "x",
  "y",
  "originX",
  "originY",
  "anchorX",
  "anchorY",
  "rotation",
  "scaleX",
  "scaleY",
  "skewX",
  "skewY"
];
function O(a, r) {
  for (var t = 0; t < S.length; t++) {
    var o = S[t];
    a[o] = r[o];
  }
}
c(O, "copyTransform");
export {
  S as TRANSFORMABLE_PROPS,
  O as copyTransform,
  N as default
};
