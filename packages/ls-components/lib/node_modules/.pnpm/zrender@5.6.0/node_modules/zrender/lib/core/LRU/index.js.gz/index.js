var p = Object.defineProperty;
var l = (i, t) => p(i, "name", { value: t, configurable: !0 });
var u = function() {
  function i(t) {
    this.value = t;
  }
  return l(i, "Entry"), i;
}(), v = function() {
  function i() {
    this._len = 0;
  }
  return l(i, "LinkedList"), i.prototype.insert = function(t) {
    var e = new u(t);
    return this.insertEntry(e), e;
  }, i.prototype.insertEntry = function(t) {
    this.head ? (this.tail.next = t, t.prev = this.tail, t.next = null, this.tail = t) : this.head = this.tail = t, this._len++;
  }, i.prototype.remove = function(t) {
    var e = t.prev, n = t.next;
    e ? e.next = n : this.head = n, n ? n.prev = e : this.tail = e, t.next = t.prev = null, this._len--;
  }, i.prototype.len = function() {
    return this._len;
  }, i.prototype.clear = function() {
    this.head = this.tail = null, this._len = 0;
  }, i;
}(), _ = function() {
  function i(t) {
    this._list = new v(), this._maxSize = 10, this._map = {}, this._maxSize = t;
  }
  return l(i, "LRU"), i.prototype.put = function(t, e) {
    var n = this._list, a = this._map, o = null;
    if (a[t] == null) {
      var h = n.len(), r = this._lastRemovedEntry;
      if (h >= this._maxSize && h > 0) {
        var s = n.head;
        n.remove(s), delete a[s.key], o = s.value, this._lastRemovedEntry = s;
      }
      r ? r.value = e : r = new u(e), r.key = t, n.insertEntry(r), a[t] = r;
    }
    return o;
  }, i.prototype.get = function(t) {
    var e = this._map[t], n = this._list;
    if (e != null)
      return e !== n.tail && (n.remove(e), n.insertEntry(e)), e.value;
  }, i.prototype.clear = function() {
    this._list.clear(), this._map = {};
  }, i.prototype.len = function() {
    return this._list.len();
  }, i;
}();
export {
  u as Entry,
  v as LinkedList,
  _ as default
};
