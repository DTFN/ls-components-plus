var k = Object.defineProperty;
var f = (s, o) => k(s, "name", { value: o, configurable: !0 });
import { __extends as _ } from "../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { each as w } from "../core/util/index.js";
import { dist as B } from "../core/vector/index.js";
import X from "../mixin/Draggable/index.js";
import T from "../core/Eventful/index.js";
import { stop as Y } from "../core/event/index.js";
import { GestureMgr as O } from "../core/GestureMgr/index.js";
import E from "../core/BoundingRect/index.js";
var z = "silent";
function R(s, o, t) {
  return {
    type: s,
    event: t,
    target: o.target,
    topTarget: o.topTarget,
    cancelBubble: !1,
    offsetX: t.zrX,
    offsetY: t.zrY,
    gestureEvent: t.gestureEvent,
    pinchX: t.pinchX,
    pinchY: t.pinchY,
    pinchScale: t.pinchScale,
    wheelDelta: t.zrDelta,
    zrByTouch: t.zrByTouch,
    which: t.which,
    stop: D
  };
}
f(R, "makeEventPacket");
function D() {
  Y(this.event);
}
f(D, "stopEvent");
var L = function(s) {
  _(o, s);
  function o() {
    var t = s !== null && s.apply(this, arguments) || this;
    return t.handler = null, t;
  }
  return f(o, "EmptyProxy"), o.prototype.dispose = function() {
  }, o.prototype.setCursor = function() {
  }, o;
}(T), c = function() {
  function s(o, t) {
    this.x = o, this.y = t;
  }
  return f(s, "HoveredResult"), s;
}(), G = [
  "click",
  "dblclick",
  "mousewheel",
  "mouseout",
  "mouseup",
  "mousedown",
  "mousemove",
  "contextmenu"
], m = new E(0, 0, 0, 0), S = function(s) {
  _(o, s);
  function o(t, r, a, n, e) {
    var i = s.call(this) || this;
    return i._hovered = new c(0, 0), i.storage = t, i.painter = r, i.painterRoot = n, i._pointerSize = e, a = a || new L(), i.proxy = null, i.setHandlerProxy(a), i._draggingMgr = new X(i), i;
  }
  return f(o, "Handler"), o.prototype.setHandlerProxy = function(t) {
    this.proxy && this.proxy.dispose(), t && (w(G, function(r) {
      t.on && t.on(r, this[r], this);
    }, this), t.handler = this), this.proxy = t;
  }, o.prototype.mousemove = function(t) {
    var r = t.zrX, a = t.zrY, n = b(this, r, a), e = this._hovered, i = e.target;
    i && !i.__zr && (e = this.findHover(e.x, e.y), i = e.target);
    var u = this._hovered = n ? new c(r, a) : this.findHover(r, a), h = u.target, l = this.proxy;
    l.setCursor && l.setCursor(h ? h.cursor : "default"), i && h !== i && this.dispatchToElement(e, "mouseout", t), this.dispatchToElement(u, "mousemove", t), h && h !== i && this.dispatchToElement(u, "mouseover", t);
  }, o.prototype.mouseout = function(t) {
    var r = t.zrEventControl;
    r !== "only_globalout" && this.dispatchToElement(this._hovered, "mouseout", t), r !== "no_globalout" && this.trigger("globalout", { type: "globalout", event: t });
  }, o.prototype.resize = function() {
    this._hovered = new c(0, 0);
  }, o.prototype.dispatch = function(t, r) {
    var a = this[t];
    a && a.call(this, r);
  }, o.prototype.dispose = function() {
    this.proxy.dispose(), this.storage = null, this.proxy = null, this.painter = null;
  }, o.prototype.setCursorStyle = function(t) {
    var r = this.proxy;
    r.setCursor && r.setCursor(t);
  }, o.prototype.dispatchToElement = function(t, r, a) {
    t = t || {};
    var n = t.target;
    if (!(n && n.silent)) {
      for (var e = "on" + r, i = R(r, t, a); n && (n[e] && (i.cancelBubble = !!n[e].call(n, i)), n.trigger(r, i), n = n.__hostTarget ? n.__hostTarget : n.parent, !i.cancelBubble); )
        ;
      i.cancelBubble || (this.trigger(r, i), this.painter && this.painter.eachOtherLayer && this.painter.eachOtherLayer(function(u) {
        typeof u[e] == "function" && u[e].call(u, i), u.trigger && u.trigger(r, i);
      }));
    }
  }, o.prototype.findHover = function(t, r, a) {
    var n = this.storage.getDisplayList(), e = new c(t, r);
    if (y(n, e, t, r, a), this._pointerSize && !e.target) {
      for (var i = [], u = this._pointerSize, h = u / 2, l = new E(t - h, r - h, u, u), d = n.length - 1; d >= 0; d--) {
        var p = n[d];
        p !== a && !p.ignore && !p.ignoreCoarsePointer && (!p.parent || !p.parent.ignoreCoarsePointer) && (m.copy(p.getBoundingRect()), p.transform && m.applyTransform(p.transform), m.intersect(l) && i.push(p));
      }
      if (i.length)
        for (var H = 4, P = Math.PI / 12, C = Math.PI * 2, g = 0; g < h; g += H)
          for (var v = 0; v < C; v += P) {
            var x = t + g * Math.cos(v), M = r + g * Math.sin(v);
            if (y(i, e, x, M, a), e.target)
              return e;
          }
    }
    return e;
  }, o.prototype.processGesture = function(t, r) {
    this._gestureMgr || (this._gestureMgr = new O());
    var a = this._gestureMgr;
    r === "start" && a.clear();
    var n = a.recognize(t, this.findHover(t.zrX, t.zrY, null).target, this.proxy.dom);
    if (r === "end" && a.clear(), n) {
      var e = n.type;
      t.gestureEvent = e;
      var i = new c();
      i.target = n.target, this.dispatchToElement(i, e, n.event);
    }
  }, o;
}(T);
w(["click", "mousedown", "mouseup", "mousewheel", "dblclick", "contextmenu"], function(s) {
  S.prototype[s] = function(o) {
    var t = o.zrX, r = o.zrY, a = b(this, t, r), n, e;
    if ((s !== "mouseup" || !a) && (n = this.findHover(t, r), e = n.target), s === "mousedown")
      this._downEl = e, this._downPoint = [o.zrX, o.zrY], this._upEl = e;
    else if (s === "mouseup")
      this._upEl = e;
    else if (s === "click") {
      if (this._downEl !== this._upEl || !this._downPoint || B(this._downPoint, [o.zrX, o.zrY]) > 4)
        return;
      this._downPoint = null;
    }
    this.dispatchToElement(n, s, o);
  };
});
function K(s, o, t) {
  if (s[s.rectHover ? "rectContain" : "contain"](o, t)) {
    for (var r = s, a = void 0, n = !1; r; ) {
      if (r.ignoreClip && (n = !0), !n) {
        var e = r.getClipPath();
        if (e && !e.contain(o, t))
          return !1;
      }
      r.silent && (a = !0);
      var i = r.__hostTarget;
      r = i || r.parent;
    }
    return a ? z : !0;
  }
  return !1;
}
f(K, "isHover");
function y(s, o, t, r, a) {
  for (var n = s.length - 1; n >= 0; n--) {
    var e = s[n], i = void 0;
    if (e !== a && !e.ignore && (i = K(e, t, r)) && (!o.topTarget && (o.topTarget = e), i !== z)) {
      o.target = e;
      break;
    }
  }
}
f(y, "setHoverTarget");
function b(s, o, t) {
  var r = s.painter;
  return o < 0 || o > r.getWidth() || t < 0 || t > r.getHeight();
}
f(b, "isOutsideBoundary");
export {
  S as default
};
