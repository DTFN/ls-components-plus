var T = Object.defineProperty;
var f = (o, r) => T(o, "name", { value: r, configurable: !0 });
import E from "../env/index.js";
import { buildTransformer as C } from "../fourPointsTransform/index.js";
var h = "___zrEVENTSAVED", v = [];
function L(o, r, t, a, u) {
  return g(v, r, a, u, !0) && g(o, t, v[0], v[1]);
}
f(L, "transformLocalCoord");
function g(o, r, t, a, u) {
  if (r.getBoundingClientRect && E.domSupported && !_(r)) {
    var e = r[h] || (r[h] = {}), n = S(r, e), s = V(n, e, u);
    if (s)
      return s(o, t, a), !0;
  }
  return !1;
}
f(g, "transformCoordWithViewport");
function S(o, r) {
  var t = r.markers;
  if (t)
    return t;
  t = r.markers = [];
  for (var a = ["left", "right"], u = ["top", "bottom"], e = 0; e < 4; e++) {
    var n = document.createElement("div"), s = n.style, i = e % 2, p = (e >> 1) % 2;
    s.cssText = [
      "position: absolute",
      "visibility: hidden",
      "padding: 0",
      "margin: 0",
      "border-width: 0",
      "user-select: none",
      "width:0",
      "height:0",
      a[i] + ":0",
      u[p] + ":0",
      a[1 - i] + ":auto",
      u[1 - p] + ":auto",
      ""
    ].join("!important;"), o.appendChild(n), t.push(n);
  }
  return t;
}
f(S, "prepareCoordMarkers");
function V(o, r, t) {
  for (var a = t ? "invTrans" : "trans", u = r[a], e = r.srcCoords, n = [], s = [], i = !0, p = 0; p < 4; p++) {
    var d = o[p].getBoundingClientRect(), c = 2 * p, l = d.left, m = d.top;
    n.push(l, m), i = i && e && l === e[c] && m === e[c + 1], s.push(o[p].offsetLeft, o[p].offsetTop);
  }
  return i && u ? u : (r.srcCoords = n, r[a] = t ? C(s, n) : C(n, s));
}
f(V, "preparePointerTransformer");
function _(o) {
  return o.nodeName.toUpperCase() === "CANVAS";
}
f(_, "isCanvasEl");
var b = /([&<>"'])/g, N = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};
function M(o) {
  return o == null ? "" : (o + "").replace(b, function(r, t) {
    return N[t];
  });
}
f(M, "encodeHTML");
export {
  M as encodeHTML,
  _ as isCanvasEl,
  g as transformCoordWithViewport,
  L as transformLocalCoord
};
