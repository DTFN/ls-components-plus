var $ = Object.defineProperty;
var c = (i, t) => $(i, "name", { value: t, configurable: !0 });
import w from "../Clip/index.js";
import { parse as D } from "../../tool/color/index.js";
import { isArrayLike as R, logError as H, keys as B, map as P, isNumber as N, eqNaN as V, isString as j, isGradientObject as tt, extend as et, isFunction as rt } from "../../core/util/index.js";
import it from "../easing/index.js";
import { createCubicEasingFunc as st } from "../cubicEasing/index.js";
import { isLinearGradient as nt, isRadialGradient as at } from "../../svg/helper/index.js";
var U = Array.prototype.slice;
function m(i, t, r) {
  return (t - i) * r + i;
}
c(m, "interpolateNumber");
function K(i, t, r, e) {
  for (var s = t.length, n = 0; n < s; n++)
    i[n] = m(t[n], r[n], e);
  return i;
}
c(K, "interpolate1DArray");
function ot(i, t, r, e) {
  for (var s = t.length, n = s && t[0].length, o = 0; o < s; o++) {
    i[o] || (i[o] = []);
    for (var a = 0; a < n; a++)
      i[o][a] = m(t[o][a], r[o][a], e);
  }
  return i;
}
c(ot, "interpolate2DArray");
function F(i, t, r, e) {
  for (var s = t.length, n = 0; n < s; n++)
    i[n] = t[n] + r[n] * e;
  return i;
}
c(F, "add1DArray");
function z(i, t, r, e) {
  for (var s = t.length, n = s && t[0].length, o = 0; o < s; o++) {
    i[o] || (i[o] = []);
    for (var a = 0; a < n; a++)
      i[o][a] = t[o][a] + r[o][a] * e;
  }
  return i;
}
c(z, "add2DArray");
function ft(i, t) {
  for (var r = i.length, e = t.length, s = r > e ? t : i, n = Math.min(r, e), o = s[n - 1] || { color: [0, 0, 0, 0], offset: 0 }, a = n; a < Math.max(r, e); a++)
    s.push({
      offset: o.offset,
      color: o.color.slice()
    });
}
c(ft, "fillColorStops");
function ht(i, t, r) {
  var e = i, s = t;
  if (!(!e.push || !s.push)) {
    var n = e.length, o = s.length;
    if (n !== o) {
      var a = n > o;
      if (a)
        e.length = o;
      else
        for (var h = n; h < o; h++)
          e.push(r === 1 ? s[h] : U.call(s[h]));
    }
    for (var l = e[0] && e[0].length, h = 0; h < e.length; h++)
      if (r === 1)
        isNaN(e[h]) && (e[h] = s[h]);
      else
        for (var f = 0; f < l; f++)
          isNaN(e[h][f]) && (e[h][f] = s[h][f]);
  }
}
c(ht, "fillArray");
function M(i) {
  if (R(i)) {
    var t = i.length;
    if (R(i[0])) {
      for (var r = [], e = 0; e < t; e++)
        r.push(U.call(i[e]));
      return r;
    }
    return U.call(i);
  }
  return i;
}
c(M, "cloneValue");
function x(i) {
  return i[0] = Math.floor(i[0]) || 0, i[1] = Math.floor(i[1]) || 0, i[2] = Math.floor(i[2]) || 0, i[3] = i[3] == null ? 1 : i[3], "rgba(" + i.join(",") + ")";
}
c(x, "rgba2String");
function lt(i) {
  return R(i && i[0]) ? 2 : 1;
}
c(lt, "guessArrayDim");
var E = 0, S = 1, X = 2, C = 3, Y = 4, G = 5, J = 6;
function Q(i) {
  return i === Y || i === G;
}
c(Q, "isGradientValueType");
function L(i) {
  return i === S || i === X;
}
c(L, "isArrayValueType");
var b = [0, 0, 0, 0], vt = function() {
  function i(t) {
    this.keyframes = [], this.discrete = !1, this._invalid = !1, this._needsSort = !1, this._lastFr = 0, this._lastFrP = 0, this.propName = t;
  }
  return c(i, "Track"), i.prototype.isFinished = function() {
    return this._finished;
  }, i.prototype.setFinished = function() {
    this._finished = !0, this._additiveTrack && this._additiveTrack.setFinished();
  }, i.prototype.needsAnimate = function() {
    return this.keyframes.length >= 1;
  }, i.prototype.getAdditiveTrack = function() {
    return this._additiveTrack;
  }, i.prototype.addKeyframe = function(t, r, e) {
    this._needsSort = !0;
    var s = this.keyframes, n = s.length, o = !1, a = J, h = r;
    if (R(r)) {
      var l = lt(r);
      a = l, (l === 1 && !N(r[0]) || l === 2 && !N(r[0][0])) && (o = !0);
    } else if (N(r) && !V(r))
      a = E;
    else if (j(r))
      if (!isNaN(+r))
        a = E;
      else {
        var f = D(r);
        f && (h = f, a = C);
      }
    else if (tt(r)) {
      var y = et({}, h);
      y.colorStops = P(r.colorStops, function(u) {
        return {
          offset: u.offset,
          color: D(u.color)
        };
      }), nt(r) ? a = Y : at(r) && (a = G), h = y;
    }
    n === 0 ? this.valType = a : (a !== this.valType || a === J) && (o = !0), this.discrete = this.discrete || o;
    var d = {
      time: t,
      value: h,
      rawValue: r,
      percent: 0
    };
    return e && (d.easing = e, d.easingFunc = rt(e) ? e : it[e] || st(e)), s.push(d), d;
  }, i.prototype.prepare = function(t, r) {
    var e = this.keyframes;
    this._needsSort && e.sort(function(T, p) {
      return T.time - p.time;
    });
    for (var s = this.valType, n = e.length, o = e[n - 1], a = this.discrete, h = L(s), l = Q(s), f = 0; f < n; f++) {
      var y = e[f], d = y.value, u = o.value;
      y.percent = y.time / t, a || (h && f !== n - 1 ? ht(d, u, s) : l && ft(d.colorStops, u.colorStops));
    }
    if (!a && s !== G && r && this.needsAnimate() && r.needsAnimate() && s === r.valType && !r._finished) {
      this._additiveTrack = r;
      for (var v = e[0].value, f = 0; f < n; f++)
        s === E ? e[f].additiveValue = e[f].value - v : s === C ? e[f].additiveValue = F([], e[f].value, v, -1) : L(s) && (e[f].additiveValue = s === S ? F([], e[f].value, v, -1) : z([], e[f].value, v, -1));
    }
  }, i.prototype.step = function(t, r) {
    if (!this._finished) {
      this._additiveTrack && this._additiveTrack._finished && (this._additiveTrack = null);
      var e = this._additiveTrack != null, s = e ? "additiveValue" : "value", n = this.valType, o = this.keyframes, a = o.length, h = this.propName, l = n === C, f, y = this._lastFr, d = Math.min, u, v;
      if (a === 1)
        u = v = o[0];
      else {
        if (r < 0)
          f = 0;
        else if (r < this._lastFrP) {
          var T = d(y + 1, a - 1);
          for (f = T; f >= 0 && !(o[f].percent <= r); f--)
            ;
          f = d(f, a - 2);
        } else {
          for (f = y; f < a && !(o[f].percent > r); f++)
            ;
          f = d(f - 1, a - 2);
        }
        v = o[f + 1], u = o[f];
      }
      if (u && v) {
        this._lastFr = f, this._lastFrP = r;
        var p = v.percent - u.percent, _ = p === 0 ? 1 : d((r - u.percent) / p, 1);
        v.easingFunc && (_ = v.easingFunc(_));
        var A = e ? this._additiveValue : l ? b : t[h];
        if ((L(n) || l) && !A && (A = this._additiveValue = []), this.discrete)
          t[h] = _ < 1 ? u.rawValue : v.rawValue;
        else if (L(n))
          n === S ? K(A, u[s], v[s], _) : ot(A, u[s], v[s], _);
        else if (Q(n)) {
          var k = u[s], g = v[s], I = n === Y;
          t[h] = {
            type: I ? "linear" : "radial",
            x: m(k.x, g.x, _),
            y: m(k.y, g.y, _),
            colorStops: P(k.colorStops, function(W, Z) {
              var q = g.colorStops[Z];
              return {
                offset: m(W.offset, q.offset, _),
                color: x(K([], W.color, q.color, _))
              };
            }),
            global: g.global
          }, I ? (t[h].x2 = m(k.x2, g.x2, _), t[h].y2 = m(k.y2, g.y2, _)) : t[h].r = m(k.r, g.r, _);
        } else if (l)
          K(A, u[s], v[s], _), e || (t[h] = x(A));
        else {
          var O = m(u[s], v[s], _);
          e ? this._additiveValue = O : t[h] = O;
        }
        e && this._addToTarget(t);
      }
    }
  }, i.prototype._addToTarget = function(t) {
    var r = this.valType, e = this.propName, s = this._additiveValue;
    r === E ? t[e] = t[e] + s : r === C ? (D(t[e], b), F(b, b, s, 1), t[e] = x(b)) : r === S ? F(t[e], t[e], s, 1) : r === X && z(t[e], t[e], s, 1);
  }, i;
}(), gt = function() {
  function i(t, r, e, s) {
    if (this._tracks = {}, this._trackKeys = [], this._maxTime = 0, this._started = 0, this._clip = null, this._target = t, this._loop = r, r && s) {
      H("Can' use additive animation on looped animation.");
      return;
    }
    this._additiveAnimators = s, this._allowDiscrete = e;
  }
  return c(i, "Animator"), i.prototype.getMaxTime = function() {
    return this._maxTime;
  }, i.prototype.getDelay = function() {
    return this._delay;
  }, i.prototype.getLoop = function() {
    return this._loop;
  }, i.prototype.getTarget = function() {
    return this._target;
  }, i.prototype.changeTarget = function(t) {
    this._target = t;
  }, i.prototype.when = function(t, r, e) {
    return this.whenWithKeys(t, r, B(r), e);
  }, i.prototype.whenWithKeys = function(t, r, e, s) {
    for (var n = this._tracks, o = 0; o < e.length; o++) {
      var a = e[o], h = n[a];
      if (!h) {
        h = n[a] = new vt(a);
        var l = void 0, f = this._getAdditiveTrack(a);
        if (f) {
          var y = f.keyframes, d = y[y.length - 1];
          l = d && d.value, f.valType === C && l && (l = x(l));
        } else
          l = this._target[a];
        if (l == null)
          continue;
        t > 0 && h.addKeyframe(0, M(l), s), this._trackKeys.push(a);
      }
      h.addKeyframe(t, M(r[a]), s);
    }
    return this._maxTime = Math.max(this._maxTime, t), this;
  }, i.prototype.pause = function() {
    this._clip.pause(), this._paused = !0;
  }, i.prototype.resume = function() {
    this._clip.resume(), this._paused = !1;
  }, i.prototype.isPaused = function() {
    return !!this._paused;
  }, i.prototype.duration = function(t) {
    return this._maxTime = t, this._force = !0, this;
  }, i.prototype._doneCallback = function() {
    this._setTracksFinished(), this._clip = null;
    var t = this._doneCbs;
    if (t)
      for (var r = t.length, e = 0; e < r; e++)
        t[e].call(this);
  }, i.prototype._abortedCallback = function() {
    this._setTracksFinished();
    var t = this.animation, r = this._abortedCbs;
    if (t && t.removeClip(this._clip), this._clip = null, r)
      for (var e = 0; e < r.length; e++)
        r[e].call(this);
  }, i.prototype._setTracksFinished = function() {
    for (var t = this._tracks, r = this._trackKeys, e = 0; e < r.length; e++)
      t[r[e]].setFinished();
  }, i.prototype._getAdditiveTrack = function(t) {
    var r, e = this._additiveAnimators;
    if (e)
      for (var s = 0; s < e.length; s++) {
        var n = e[s].getTrack(t);
        n && (r = n);
      }
    return r;
  }, i.prototype.start = function(t) {
    if (!(this._started > 0)) {
      this._started = 1;
      for (var r = this, e = [], s = this._maxTime || 0, n = 0; n < this._trackKeys.length; n++) {
        var o = this._trackKeys[n], a = this._tracks[o], h = this._getAdditiveTrack(o), l = a.keyframes, f = l.length;
        if (a.prepare(s, h), a.needsAnimate())
          if (!this._allowDiscrete && a.discrete) {
            var y = l[f - 1];
            y && (r._target[a.propName] = y.rawValue), a.setFinished();
          } else
            e.push(a);
      }
      if (e.length || this._force) {
        var d = new w({
          life: s,
          loop: this._loop,
          delay: this._delay || 0,
          onframe: /* @__PURE__ */ c(function(u) {
            r._started = 2;
            var v = r._additiveAnimators;
            if (v) {
              for (var T = !1, p = 0; p < v.length; p++)
                if (v[p]._clip) {
                  T = !0;
                  break;
                }
              T || (r._additiveAnimators = null);
            }
            for (var p = 0; p < e.length; p++)
              e[p].step(r._target, u);
            var _ = r._onframeCbs;
            if (_)
              for (var p = 0; p < _.length; p++)
                _[p](r._target, u);
          }, "onframe"),
          ondestroy: /* @__PURE__ */ c(function() {
            r._doneCallback();
          }, "ondestroy")
        });
        this._clip = d, this.animation && this.animation.addClip(d), t && d.setEasing(t);
      } else
        this._doneCallback();
      return this;
    }
  }, i.prototype.stop = function(t) {
    if (this._clip) {
      var r = this._clip;
      t && r.onframe(1), this._abortedCallback();
    }
  }, i.prototype.delay = function(t) {
    return this._delay = t, this;
  }, i.prototype.during = function(t) {
    return t && (this._onframeCbs || (this._onframeCbs = []), this._onframeCbs.push(t)), this;
  }, i.prototype.done = function(t) {
    return t && (this._doneCbs || (this._doneCbs = []), this._doneCbs.push(t)), this;
  }, i.prototype.aborted = function(t) {
    return t && (this._abortedCbs || (this._abortedCbs = []), this._abortedCbs.push(t)), this;
  }, i.prototype.getClip = function() {
    return this._clip;
  }, i.prototype.getTrack = function(t) {
    return this._tracks[t];
  }, i.prototype.getTracks = function() {
    var t = this;
    return P(this._trackKeys, function(r) {
      return t._tracks[r];
    });
  }, i.prototype.stopTracks = function(t, r) {
    if (!t.length || !this._clip)
      return !0;
    for (var e = this._tracks, s = this._trackKeys, n = 0; n < t.length; n++) {
      var o = e[t[n]];
      o && !o.isFinished() && (r ? o.step(this._target, 1) : this._started === 1 && o.step(this._target, 0), o.setFinished());
    }
    for (var a = !0, n = 0; n < s.length; n++)
      if (!e[s[n]].isFinished()) {
        a = !1;
        break;
      }
    return a && this._abortedCallback(), a;
  }, i.prototype.saveTo = function(t, r, e) {
    if (t) {
      r = r || this._trackKeys;
      for (var s = 0; s < r.length; s++) {
        var n = r[s], o = this._tracks[n];
        if (!(!o || o.isFinished())) {
          var a = o.keyframes, h = a[e ? 0 : a.length - 1];
          h && (t[n] = M(h.rawValue));
        }
      }
    }
  }, i.prototype.__changeFinalValue = function(t, r) {
    r = r || B(t);
    for (var e = 0; e < r.length; e++) {
      var s = r[e], n = this._tracks[s];
      if (n) {
        var o = n.keyframes;
        if (o.length > 1) {
          var a = o.pop();
          n.addKeyframe(a.time, t[s]), n.prepare(this._maxTime, n.getAdditiveTrack());
        }
      }
    }
  }, i;
}();
export {
  M as cloneValue,
  gt as default
};
