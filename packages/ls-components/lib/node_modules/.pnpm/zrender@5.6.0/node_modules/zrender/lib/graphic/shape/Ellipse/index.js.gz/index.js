var s = Object.defineProperty;
var v = (n, a) => s(n, "name", { value: a, configurable: !0 });
import { __extends as y } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import h from "../../Path/index.js";
var c = function() {
  function n() {
    this.cx = 0, this.cy = 0, this.rx = 0, this.ry = 0;
  }
  return v(n, "EllipseShape"), n;
}(), b = function(n) {
  y(a, n);
  function a(t) {
    return n.call(this, t) || this;
  }
  return v(a, "Ellipse"), a.prototype.getDefaultShape = function() {
    return new c();
  }, a.prototype.buildPath = function(t, l) {
    var f = 0.5522848, r = l.cx, e = l.cy, o = l.rx, i = l.ry, u = o * f, p = i * f;
    t.moveTo(r - o, e), t.bezierCurveTo(r - o, e - p, r - u, e - i, r, e - i), t.bezierCurveTo(r + u, e - i, r + o, e - p, r + o, e), t.bezierCurveTo(r + o, e + p, r + u, e + i, r, e + i), t.bezierCurveTo(r - u, e + i, r - o, e + p, r - o, e), t.closePath();
  }, a;
}(h);
b.prototype.type = "ellipse";
export {
  c as EllipseShape,
  b as default
};
