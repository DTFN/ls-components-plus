var g = Object.defineProperty;
var M = (c, e) => g(c, "name", { value: e, configurable: !0 });
import o from "../Point/index.js";
var l = [0, 0], _ = [0, 0], x = new o(), p = new o(), O = function() {
  function c(e, a) {
    this._corners = [], this._axes = [], this._origin = [0, 0];
    for (var t = 0; t < 4; t++)
      this._corners[t] = new o();
    for (var t = 0; t < 2; t++)
      this._axes[t] = new o();
    e && this.fromBoundingRect(e, a);
  }
  return M(c, "OrientedBoundingRect"), c.prototype.fromBoundingRect = function(e, a) {
    var t = this._corners, r = this._axes, v = e.x, s = e.y, f = v + e.width, i = s + e.height;
    if (t[0].set(v, s), t[1].set(f, s), t[2].set(f, i), t[3].set(v, i), a)
      for (var n = 0; n < 4; n++)
        t[n].transform(a);
    o.sub(r[0], t[1], t[0]), o.sub(r[1], t[3], t[0]), r[0].normalize(), r[1].normalize();
    for (var n = 0; n < 2; n++)
      this._origin[n] = r[n].dot(t[0]);
  }, c.prototype.intersect = function(e, a) {
    var t = !0, r = !a;
    return x.set(1 / 0, 1 / 0), p.set(0, 0), !this._intersectCheckOneSide(this, e, x, p, r, 1) && (t = !1, r) || !this._intersectCheckOneSide(e, this, x, p, r, -1) && (t = !1, r) || r || o.copy(a, t ? x : p), t;
  }, c.prototype._intersectCheckOneSide = function(e, a, t, r, v, s) {
    for (var f = !0, i = 0; i < 2; i++) {
      var n = this._axes[i];
      if (this._getProjMinMaxOnAxis(i, e._corners, l), this._getProjMinMaxOnAxis(i, a._corners, _), l[1] < _[0] || l[0] > _[1]) {
        if (f = !1, v)
          return f;
        var h = Math.abs(_[0] - l[1]), u = Math.abs(l[0] - _[1]);
        Math.min(h, u) > r.len() && (h < u ? o.scale(r, n, -h * s) : o.scale(r, n, u * s));
      } else if (t) {
        var h = Math.abs(_[0] - l[1]), u = Math.abs(l[0] - _[1]);
        Math.min(h, u) < t.len() && (h < u ? o.scale(t, n, h * s) : o.scale(t, n, -u * s));
      }
    }
    return f;
  }, c.prototype._getProjMinMaxOnAxis = function(e, a, t) {
    for (var r = this._axes[e], v = this._origin, s = a[0].dot(r) + v[e], f = s, i = s, n = 1; n < a.length; n++) {
      var h = a[n].dot(r) + v[e];
      f = Math.min(h, f), i = Math.max(h, i);
    }
    t[0] = f, t[1] = i;
  }, c;
}();
export {
  O as default
};
