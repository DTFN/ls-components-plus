var O = Object.defineProperty;
var d = (e, t) => O(e, "name", { value: t, configurable: !0 });
import V, { TRANSFORMABLE_PROPS as U } from "../core/Transformable/index.js";
import W, { cloneValue as j } from "../animation/Animator/index.js";
import K from "../core/BoundingRect/index.js";
import k from "../core/Eventful/index.js";
import { calculateTextPosition as tt, parsePercent as F } from "../contain/text/index.js";
import { reduce as it, extend as w, isObject as B, keys as Y, indexOf as R, logError as Z, mixin as X, isArrayLike as y, isGradientObject as rt, filter as M, guid as et, isTypedArray as ot } from "../core/util/index.js";
import { LIGHT_LABEL_COLOR as nt, DARK_LABEL_COLOR as st } from "../config/index.js";
import { parse as at, stringify as ht } from "../tool/color/index.js";
import { REDRAW_BIT as A } from "../graphic/constants/index.js";
var N = "__zr_normal__", D = U.concat(["ignore"]), ft = it(U, function(e, t) {
  return e[t] = !0, e;
}, { ignore: !1 }), P = {}, ut = new K(0, 0, 0, 0), q = function() {
  function e(t) {
    this.id = et(), this.animators = [], this.currentStates = [], this.states = {}, this._init(t);
  }
  return d(e, "Element"), e.prototype._init = function(t) {
    this.attr(t);
  }, e.prototype.drift = function(t, i, r) {
    switch (this.draggable) {
      case "horizontal":
        i = 0;
        break;
      case "vertical":
        t = 0;
        break;
    }
    var n = this.transform;
    n || (n = this.transform = [1, 0, 0, 1, 0, 0]), n[4] += t, n[5] += i, this.decomposeTransform(), this.markRedraw();
  }, e.prototype.beforeUpdate = function() {
  }, e.prototype.afterUpdate = function() {
  }, e.prototype.update = function() {
    this.updateTransform(), this.__dirty && this.updateInnerText();
  }, e.prototype.updateInnerText = function(t) {
    var i = this._textContent;
    if (i && (!i.ignore || t)) {
      this.textConfig || (this.textConfig = {});
      var r = this.textConfig, n = r.local, o = i.innerTransformable, s = void 0, f = void 0, h = !1;
      o.parent = n ? this : null;
      var v = !1;
      if (o.copyTransform(i), r.position != null) {
        var a = ut;
        r.layoutRect ? a.copy(r.layoutRect) : a.copy(this.getBoundingRect()), n || a.applyTransform(this.transform), this.calculateTextPosition ? this.calculateTextPosition(P, r, a) : tt(P, r, a), o.x = P.x, o.y = P.y, s = P.align, f = P.verticalAlign;
        var p = r.origin;
        if (p && r.rotation != null) {
          var _ = void 0, T = void 0;
          p === "center" ? (_ = a.width * 0.5, T = a.height * 0.5) : (_ = F(p[0], a.width), T = F(p[1], a.height)), v = !0, o.originX = -o.x + _ + (n ? 0 : a.x), o.originY = -o.y + T + (n ? 0 : a.y);
        }
      }
      r.rotation != null && (o.rotation = r.rotation);
      var l = r.offset;
      l && (o.x += l[0], o.y += l[1], v || (o.originX = -l[0], o.originY = -l[1]));
      var c = r.inside == null ? typeof r.position == "string" && r.position.indexOf("inside") >= 0 : r.inside, g = this._innerTextDefaultStyle || (this._innerTextDefaultStyle = {}), u = void 0, m = void 0, x = void 0;
      c && this.canBeInsideText() ? (u = r.insideFill, m = r.insideStroke, (u == null || u === "auto") && (u = this.getInsideTextFill()), (m == null || m === "auto") && (m = this.getInsideTextStroke(u), x = !0)) : (u = r.outsideFill, m = r.outsideStroke, (u == null || u === "auto") && (u = this.getOutsideFill()), (m == null || m === "auto") && (m = this.getOutsideStroke(u), x = !0)), u = u || "#000", (u !== g.fill || m !== g.stroke || x !== g.autoStroke || s !== g.align || f !== g.verticalAlign) && (h = !0, g.fill = u, g.stroke = m, g.autoStroke = x, g.align = s, g.verticalAlign = f, i.setDefaultTextStyle(g)), i.__dirty |= A, h && i.dirtyStyle(!0);
    }
  }, e.prototype.canBeInsideText = function() {
    return !0;
  }, e.prototype.getInsideTextFill = function() {
    return "#fff";
  }, e.prototype.getInsideTextStroke = function(t) {
    return "#000";
  }, e.prototype.getOutsideFill = function() {
    return this.__zr && this.__zr.isDarkMode() ? nt : st;
  }, e.prototype.getOutsideStroke = function(t) {
    var i = this.__zr && this.__zr.getBackgroundColor(), r = typeof i == "string" && at(i);
    r || (r = [255, 255, 255, 1]);
    for (var n = r[3], o = this.__zr.isDarkMode(), s = 0; s < 3; s++)
      r[s] = r[s] * n + (o ? 0 : 255) * (1 - n);
    return r[3] = 1, ht(r, "rgba");
  }, e.prototype.traverse = function(t, i) {
  }, e.prototype.attrKV = function(t, i) {
    t === "textConfig" ? this.setTextConfig(i) : t === "textContent" ? this.setTextContent(i) : t === "clipPath" ? this.setClipPath(i) : t === "extra" ? (this.extra = this.extra || {}, w(this.extra, i)) : this[t] = i;
  }, e.prototype.hide = function() {
    this.ignore = !0, this.markRedraw();
  }, e.prototype.show = function() {
    this.ignore = !1, this.markRedraw();
  }, e.prototype.attr = function(t, i) {
    if (typeof t == "string")
      this.attrKV(t, i);
    else if (B(t))
      for (var r = t, n = Y(r), o = 0; o < n.length; o++) {
        var s = n[o];
        this.attrKV(s, t[s]);
      }
    return this.markRedraw(), this;
  }, e.prototype.saveCurrentToNormalState = function(t) {
    this._innerSaveToNormal(t);
    for (var i = this._normalState, r = 0; r < this.animators.length; r++) {
      var n = this.animators[r], o = n.__fromStateTransition;
      if (!(n.getLoop() || o && o !== N)) {
        var s = n.targetName, f = s ? i[s] : i;
        n.saveTo(f);
      }
    }
  }, e.prototype._innerSaveToNormal = function(t) {
    var i = this._normalState;
    i || (i = this._normalState = {}), t.textConfig && !i.textConfig && (i.textConfig = this.textConfig), this._savePrimaryToNormal(t, i, D);
  }, e.prototype._savePrimaryToNormal = function(t, i, r) {
    for (var n = 0; n < r.length; n++) {
      var o = r[n];
      t[o] != null && !(o in i) && (i[o] = this[o]);
    }
  }, e.prototype.hasState = function() {
    return this.currentStates.length > 0;
  }, e.prototype.getState = function(t) {
    return this.states[t];
  }, e.prototype.ensureState = function(t) {
    var i = this.states;
    return i[t] || (i[t] = {}), i[t];
  }, e.prototype.clearStates = function(t) {
    this.useState(N, !1, t);
  }, e.prototype.useState = function(t, i, r, n) {
    var o = t === N, s = this.hasState();
    if (!(!s && o)) {
      var f = this.currentStates, h = this.stateTransition;
      if (!(R(f, t) >= 0 && (i || f.length === 1))) {
        var v;
        if (this.stateProxy && !o && (v = this.stateProxy(t)), v || (v = this.states && this.states[t]), !v && !o) {
          Z("State " + t + " not exists.");
          return;
        }
        o || this.saveCurrentToNormalState(v);
        var a = !!(v && v.hoverLayer || n);
        a && this._toggleHoverLayerFlag(!0), this._applyStateObj(t, v, this._normalState, i, !r && !this.__inHover && h && h.duration > 0, h);
        var p = this._textContent, _ = this._textGuide;
        return p && p.useState(t, i, r, a), _ && _.useState(t, i, r, a), o ? (this.currentStates = [], this._normalState = {}) : i ? this.currentStates.push(t) : this.currentStates = [t], this._updateAnimationTargets(), this.markRedraw(), !a && this.__inHover && (this._toggleHoverLayerFlag(!1), this.__dirty &= ~A), v;
      }
    }
  }, e.prototype.useStates = function(t, i, r) {
    if (!t.length)
      this.clearStates();
    else {
      var n = [], o = this.currentStates, s = t.length, f = s === o.length;
      if (f) {
        for (var h = 0; h < s; h++)
          if (t[h] !== o[h]) {
            f = !1;
            break;
          }
      }
      if (f)
        return;
      for (var h = 0; h < s; h++) {
        var v = t[h], a = void 0;
        this.stateProxy && (a = this.stateProxy(v, t)), a || (a = this.states[v]), a && n.push(a);
      }
      var p = n[s - 1], _ = !!(p && p.hoverLayer || r);
      _ && this._toggleHoverLayerFlag(!0);
      var T = this._mergeStates(n), l = this.stateTransition;
      this.saveCurrentToNormalState(T), this._applyStateObj(t.join(","), T, this._normalState, !1, !i && !this.__inHover && l && l.duration > 0, l);
      var c = this._textContent, g = this._textGuide;
      c && c.useStates(t, i, _), g && g.useStates(t, i, _), this._updateAnimationTargets(), this.currentStates = t.slice(), this.markRedraw(), !_ && this.__inHover && (this._toggleHoverLayerFlag(!1), this.__dirty &= ~A);
    }
  }, e.prototype.isSilent = function() {
    for (var t = this.silent, i = this.parent; !t && i; ) {
      if (i.silent) {
        t = !0;
        break;
      }
      i = i.parent;
    }
    return t;
  }, e.prototype._updateAnimationTargets = function() {
    for (var t = 0; t < this.animators.length; t++) {
      var i = this.animators[t];
      i.targetName && i.changeTarget(this[i.targetName]);
    }
  }, e.prototype.removeState = function(t) {
    var i = R(this.currentStates, t);
    if (i >= 0) {
      var r = this.currentStates.slice();
      r.splice(i, 1), this.useStates(r);
    }
  }, e.prototype.replaceState = function(t, i, r) {
    var n = this.currentStates.slice(), o = R(n, t), s = R(n, i) >= 0;
    o >= 0 ? s ? n.splice(o, 1) : n[o] = i : r && !s && n.push(i), this.useStates(n);
  }, e.prototype.toggleState = function(t, i) {
    i ? this.useState(t, !0) : this.removeState(t);
  }, e.prototype._mergeStates = function(t) {
    for (var i = {}, r, n = 0; n < t.length; n++) {
      var o = t[n];
      w(i, o), o.textConfig && (r = r || {}, w(r, o.textConfig));
    }
    return r && (i.textConfig = r), i;
  }, e.prototype._applyStateObj = function(t, i, r, n, o, s) {
    var f = !(i && n);
    i && i.textConfig ? (this.textConfig = w({}, n ? this.textConfig : r.textConfig), w(this.textConfig, i.textConfig)) : f && r.textConfig && (this.textConfig = r.textConfig);
    for (var h = {}, v = !1, a = 0; a < D.length; a++) {
      var p = D[a], _ = o && ft[p];
      i && i[p] != null ? _ ? (v = !0, h[p] = i[p]) : this[p] = i[p] : f && r[p] != null && (_ ? (v = !0, h[p] = r[p]) : this[p] = r[p]);
    }
    if (!o)
      for (var a = 0; a < this.animators.length; a++) {
        var T = this.animators[a], l = T.targetName;
        T.getLoop() || T.__changeFinalValue(l ? (i || r)[l] : i || r);
      }
    v && this._transitionState(t, h, s);
  }, e.prototype._attachComponent = function(t) {
    if (t.__zr && !t.__hostTarget) {
      if (process.env.NODE_ENV !== "production")
        throw new Error("Text element has been added to zrender.");
      return;
    }
    if (t === this) {
      if (process.env.NODE_ENV !== "production")
        throw new Error("Recursive component attachment.");
      return;
    }
    var i = this.__zr;
    i && t.addSelfToZr(i), t.__zr = i, t.__hostTarget = this;
  }, e.prototype._detachComponent = function(t) {
    t.__zr && t.removeSelfFromZr(t.__zr), t.__zr = null, t.__hostTarget = null;
  }, e.prototype.getClipPath = function() {
    return this._clipPath;
  }, e.prototype.setClipPath = function(t) {
    this._clipPath && this._clipPath !== t && this.removeClipPath(), this._attachComponent(t), this._clipPath = t, this.markRedraw();
  }, e.prototype.removeClipPath = function() {
    var t = this._clipPath;
    t && (this._detachComponent(t), this._clipPath = null, this.markRedraw());
  }, e.prototype.getTextContent = function() {
    return this._textContent;
  }, e.prototype.setTextContent = function(t) {
    var i = this._textContent;
    if (i !== t) {
      if (i && i !== t && this.removeTextContent(), process.env.NODE_ENV !== "production" && t.__zr && !t.__hostTarget)
        throw new Error("Text element has been added to zrender.");
      t.innerTransformable = new V(), this._attachComponent(t), this._textContent = t, this.markRedraw();
    }
  }, e.prototype.setTextConfig = function(t) {
    this.textConfig || (this.textConfig = {}), w(this.textConfig, t), this.markRedraw();
  }, e.prototype.removeTextConfig = function() {
    this.textConfig = null, this.markRedraw();
  }, e.prototype.removeTextContent = function() {
    var t = this._textContent;
    t && (t.innerTransformable = null, this._detachComponent(t), this._textContent = null, this._innerTextDefaultStyle = null, this.markRedraw());
  }, e.prototype.getTextGuideLine = function() {
    return this._textGuide;
  }, e.prototype.setTextGuideLine = function(t) {
    this._textGuide && this._textGuide !== t && this.removeTextGuideLine(), this._attachComponent(t), this._textGuide = t, this.markRedraw();
  }, e.prototype.removeTextGuideLine = function() {
    var t = this._textGuide;
    t && (this._detachComponent(t), this._textGuide = null, this.markRedraw());
  }, e.prototype.markRedraw = function() {
    this.__dirty |= A;
    var t = this.__zr;
    t && (this.__inHover ? t.refreshHover() : t.refresh()), this.__hostTarget && this.__hostTarget.markRedraw();
  }, e.prototype.dirty = function() {
    this.markRedraw();
  }, e.prototype._toggleHoverLayerFlag = function(t) {
    this.__inHover = t;
    var i = this._textContent, r = this._textGuide;
    i && (i.__inHover = t), r && (r.__inHover = t);
  }, e.prototype.addSelfToZr = function(t) {
    if (this.__zr !== t) {
      this.__zr = t;
      var i = this.animators;
      if (i)
        for (var r = 0; r < i.length; r++)
          t.animation.addAnimator(i[r]);
      this._clipPath && this._clipPath.addSelfToZr(t), this._textContent && this._textContent.addSelfToZr(t), this._textGuide && this._textGuide.addSelfToZr(t);
    }
  }, e.prototype.removeSelfFromZr = function(t) {
    if (this.__zr) {
      this.__zr = null;
      var i = this.animators;
      if (i)
        for (var r = 0; r < i.length; r++)
          t.animation.removeAnimator(i[r]);
      this._clipPath && this._clipPath.removeSelfFromZr(t), this._textContent && this._textContent.removeSelfFromZr(t), this._textGuide && this._textGuide.removeSelfFromZr(t);
    }
  }, e.prototype.animate = function(t, i, r) {
    var n = t ? this[t] : this;
    if (process.env.NODE_ENV !== "production" && !n) {
      Z('Property "' + t + '" is not existed in element ' + this.id);
      return;
    }
    var o = new W(n, i, r);
    return t && (o.targetName = t), this.addAnimator(o, t), o;
  }, e.prototype.addAnimator = function(t, i) {
    var r = this.__zr, n = this;
    t.during(function() {
      n.updateDuringAnimation(i);
    }).done(function() {
      var o = n.animators, s = R(o, t);
      s >= 0 && o.splice(s, 1);
    }), this.animators.push(t), r && r.animation.addAnimator(t), r && r.wakeUp();
  }, e.prototype.updateDuringAnimation = function(t) {
    this.markRedraw();
  }, e.prototype.stopAnimation = function(t, i) {
    for (var r = this.animators, n = r.length, o = [], s = 0; s < n; s++) {
      var f = r[s];
      !t || t === f.scope ? f.stop(i) : o.push(f);
    }
    return this.animators = o, this;
  }, e.prototype.animateTo = function(t, i, r) {
    z(this, t, i, r);
  }, e.prototype.animateFrom = function(t, i, r) {
    z(this, t, i, r, !0);
  }, e.prototype._transitionState = function(t, i, r, n) {
    for (var o = z(this, i, r, n), s = 0; s < o.length; s++)
      o[s].__fromStateTransition = t;
  }, e.prototype.getBoundingRect = function() {
    return null;
  }, e.prototype.getPaintRect = function() {
    return null;
  }, e.initDefaultProps = function() {
    var t = e.prototype;
    t.type = "element", t.name = "", t.ignore = t.silent = t.isGroup = t.draggable = t.dragging = t.ignoreClip = t.__inHover = !1, t.__dirty = A;
    var i = {};
    function r(o, s, f) {
      i[o + s + f] || (console.warn("DEPRECATED: '" + o + "' has been deprecated. use '" + s + "', '" + f + "' instead"), i[o + s + f] = !0);
    }
    d(r, "logDeprecatedError");
    function n(o, s, f, h) {
      Object.defineProperty(t, o, {
        get: /* @__PURE__ */ d(function() {
          if (process.env.NODE_ENV !== "production" && r(o, f, h), !this[s]) {
            var a = this[s] = [];
            v(this, a);
          }
          return this[s];
        }, "get"),
        set: /* @__PURE__ */ d(function(a) {
          process.env.NODE_ENV !== "production" && r(o, f, h), this[f] = a[0], this[h] = a[1], this[s] = a, v(this, a);
        }, "set")
      });
      function v(a, p) {
        Object.defineProperty(p, 0, {
          get: /* @__PURE__ */ d(function() {
            return a[f];
          }, "get"),
          set: /* @__PURE__ */ d(function(_) {
            a[f] = _;
          }, "set")
        }), Object.defineProperty(p, 1, {
          get: /* @__PURE__ */ d(function() {
            return a[h];
          }, "get"),
          set: /* @__PURE__ */ d(function(_) {
            a[h] = _;
          }, "set")
        });
      }
      d(v, "enhanceArray");
    }
    d(n, "createLegacyProperty"), Object.defineProperty && (n("position", "_legacyPos", "x", "y"), n("scale", "_legacyScale", "scaleX", "scaleY"), n("origin", "_legacyOrigin", "originX", "originY"));
  }(), e;
}();
X(q, k);
X(q, V);
function z(e, t, i, r, n) {
  i = i || {};
  var o = [];
  J(e, "", e, t, i, r, o, n);
  var s = o.length, f = !1, h = i.done, v = i.aborted, a = /* @__PURE__ */ d(function() {
    f = !0, s--, s <= 0 && (f ? h && h() : v && v());
  }, "doneCb"), p = /* @__PURE__ */ d(function() {
    s--, s <= 0 && (f ? h && h() : v && v());
  }, "abortedCb");
  s || h && h(), o.length > 0 && i.during && o[0].during(function(l, c) {
    i.during(c);
  });
  for (var _ = 0; _ < o.length; _++) {
    var T = o[_];
    a && T.done(a), p && T.aborted(p), i.force && T.duration(i.duration), T.start(i.easing);
  }
  return o;
}
d(z, "animateTo");
function H(e, t, i) {
  for (var r = 0; r < i; r++)
    e[r] = t[r];
}
d(H, "copyArrShallow");
function pt(e) {
  return y(e[0]);
}
d(pt, "is2DArray");
function vt(e, t, i) {
  if (y(t[i]))
    if (y(e[i]) || (e[i] = []), ot(t[i])) {
      var r = t[i].length;
      e[i].length !== r && (e[i] = new t[i].constructor(r), H(e[i], t[i], r));
    } else {
      var n = t[i], o = e[i], s = n.length;
      if (pt(n))
        for (var f = n[0].length, h = 0; h < s; h++)
          o[h] ? H(o[h], n[h], f) : o[h] = Array.prototype.slice.call(n[h]);
      else
        H(o, n, s);
      o.length = n.length;
    }
  else
    e[i] = t[i];
}
d(vt, "copyValue");
function _t(e, t) {
  return e === t || y(e) && y(t) && dt(e, t);
}
d(_t, "isValueSame");
function dt(e, t) {
  var i = e.length;
  if (i !== t.length)
    return !1;
  for (var r = 0; r < i; r++)
    if (e[r] !== t[r])
      return !1;
  return !0;
}
d(dt, "is1DArraySame");
function J(e, t, i, r, n, o, s, f) {
  for (var h = Y(r), v = n.duration, a = n.delay, p = n.additive, _ = n.setToFinal, T = !B(o), l = e.animators, c = [], g = 0; g < h.length; g++) {
    var u = h[g], m = r[u];
    if (m != null && i[u] != null && (T || o[u]))
      if (B(m) && !y(m) && !rt(m)) {
        if (t) {
          f || (i[u] = m, e.updateDuringAnimation(t));
          continue;
        }
        J(e, u, i[u], m, n, o && o[u], s, f);
      } else
        c.push(u);
    else f || (i[u] = m, e.updateDuringAnimation(t), c.push(u));
  }
  var x = c.length;
  if (!p && x)
    for (var S = 0; S < l.length; S++) {
      var C = l[S];
      if (C.targetName === t) {
        var Q = C.stopTracks(c);
        if (Q) {
          var $ = R(l, C);
          l.splice($, 1);
        }
      }
    }
  if (n.force || (c = M(c, function(I) {
    return !_t(r[I], i[I]);
  }), x = c.length), x > 0 || n.force && !s.length) {
    var E = void 0, L = void 0, G = void 0;
    if (f) {
      L = {}, _ && (E = {});
      for (var S = 0; S < x; S++) {
        var u = c[S];
        L[u] = i[u], _ ? E[u] = r[u] : i[u] = r[u];
      }
    } else if (_) {
      G = {};
      for (var S = 0; S < x; S++) {
        var u = c[S];
        G[u] = j(i[u]), vt(i, r, u);
      }
    }
    var C = new W(i, !1, !1, p ? M(l, function(b) {
      return b.targetName === t;
    }) : null);
    C.targetName = t, n.scope && (C.scope = n.scope), _ && E && C.whenWithKeys(0, E, c), G && C.whenWithKeys(0, G, c), C.whenWithKeys(v ?? 500, f ? L : r, c).delay(a || 0), e.addAnimator(C, t), s.push(C);
  }
}
d(J, "animateToShallow");
export {
  N as PRESERVED_NORMAL_STATE,
  q as default
};
