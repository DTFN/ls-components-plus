var mt = Object.defineProperty;
var at = (v, t) => mt(v, "name", { value: t, configurable: !0 });
import { min as yt, max as Lt } from "../vector/index.js";
import Dt from "../BoundingRect/index.js";
import { devicePixelRatio as pt } from "../../config/index.js";
import { fromLine as _t, fromArc as Tt, fromQuadratic as Ct, fromCubic as Mt } from "../bbox/index.js";
import { quadraticSubdivide as ct, cubicSubdivide as dt, quadraticLength as gt, cubicLength as kt } from "../curve/index.js";
var h = {
  M: 1,
  L: 2,
  C: 3,
  Q: 4,
  A: 5,
  Z: 6,
  R: 7
}, X = [], Z = [], M = [], q = [], g = [], k = [], et = Math.min, st = Math.max, V = Math.cos, Y = Math.sin, S = Math.abs, ot = Math.PI, w = ot * 2, nt = typeof Float32Array < "u", K = [];
function vt(v) {
  var t = Math.round(v / ot * 1e8) / 1e8;
  return t % 2 * ot;
}
at(vt, "modPI2");
function St(v, t) {
  var r = vt(v[0]);
  r < 0 && (r += w);
  var a = r - v[0], e = v[1];
  e += a, !t && e - r >= w ? e = r + w : t && r - e >= w ? e = r - w : !t && r > e ? e = r + (w - vt(r - e)) : t && r < e && (e = r - (w - vt(e - r))), v[0] = r, v[1] = e;
}
at(St, "normalizeArcAngles");
var Xt = function() {
  function v(t) {
    this.dpr = 1, this._xi = 0, this._yi = 0, this._x0 = 0, this._y0 = 0, this._len = 0, t && (this._saveData = !1), this._saveData && (this.data = []);
  }
  return at(v, "PathProxy"), v.prototype.increaseVersion = function() {
    this._version++;
  }, v.prototype.getVersion = function() {
    return this._version;
  }, v.prototype.setScale = function(t, r, a) {
    a = a || 0, a > 0 && (this._ux = S(a / pt / t) || 0, this._uy = S(a / pt / r) || 0);
  }, v.prototype.setDPR = function(t) {
    this.dpr = t;
  }, v.prototype.setContext = function(t) {
    this._ctx = t;
  }, v.prototype.getContext = function() {
    return this._ctx;
  }, v.prototype.beginPath = function() {
    return this._ctx && this._ctx.beginPath(), this.reset(), this;
  }, v.prototype.reset = function() {
    this._saveData && (this._len = 0), this._pathSegLen && (this._pathSegLen = null, this._pathLen = 0), this._version++;
  }, v.prototype.moveTo = function(t, r) {
    return this._drawPendingPt(), this.addData(h.M, t, r), this._ctx && this._ctx.moveTo(t, r), this._x0 = t, this._y0 = r, this._xi = t, this._yi = r, this;
  }, v.prototype.lineTo = function(t, r) {
    var a = S(t - this._xi), e = S(r - this._yi), s = a > this._ux || e > this._uy;
    if (this.addData(h.L, t, r), this._ctx && s && this._ctx.lineTo(t, r), s)
      this._xi = t, this._yi = r, this._pendingPtDist = 0;
    else {
      var i = a * a + e * e;
      i > this._pendingPtDist && (this._pendingPtX = t, this._pendingPtY = r, this._pendingPtDist = i);
    }
    return this;
  }, v.prototype.bezierCurveTo = function(t, r, a, e, s, i) {
    return this._drawPendingPt(), this.addData(h.C, t, r, a, e, s, i), this._ctx && this._ctx.bezierCurveTo(t, r, a, e, s, i), this._xi = s, this._yi = i, this;
  }, v.prototype.quadraticCurveTo = function(t, r, a, e) {
    return this._drawPendingPt(), this.addData(h.Q, t, r, a, e), this._ctx && this._ctx.quadraticCurveTo(t, r, a, e), this._xi = a, this._yi = e, this;
  }, v.prototype.arc = function(t, r, a, e, s, i) {
    this._drawPendingPt(), K[0] = e, K[1] = s, St(K, i), e = K[0], s = K[1];
    var c = s - e;
    return this.addData(h.A, t, r, a, a, e, c, 0, i ? 0 : 1), this._ctx && this._ctx.arc(t, r, a, e, s, i), this._xi = V(s) * a + t, this._yi = Y(s) * a + r, this;
  }, v.prototype.arcTo = function(t, r, a, e, s) {
    return this._drawPendingPt(), this._ctx && this._ctx.arcTo(t, r, a, e, s), this;
  }, v.prototype.rect = function(t, r, a, e) {
    return this._drawPendingPt(), this._ctx && this._ctx.rect(t, r, a, e), this.addData(h.R, t, r, a, e), this;
  }, v.prototype.closePath = function() {
    this._drawPendingPt(), this.addData(h.Z);
    var t = this._ctx, r = this._x0, a = this._y0;
    return t && t.closePath(), this._xi = r, this._yi = a, this;
  }, v.prototype.fill = function(t) {
    t && t.fill(), this.toStatic();
  }, v.prototype.stroke = function(t) {
    t && t.stroke(), this.toStatic();
  }, v.prototype.len = function() {
    return this._len;
  }, v.prototype.setData = function(t) {
    var r = t.length;
    !(this.data && this.data.length === r) && nt && (this.data = new Float32Array(r));
    for (var a = 0; a < r; a++)
      this.data[a] = t[a];
    this._len = r;
  }, v.prototype.appendPath = function(t) {
    t instanceof Array || (t = [t]);
    for (var r = t.length, a = 0, e = this._len, s = 0; s < r; s++)
      a += t[s].len();
    nt && this.data instanceof Float32Array && (this.data = new Float32Array(e + a));
    for (var s = 0; s < r; s++)
      for (var i = t[s].data, c = 0; c < i.length; c++)
        this.data[e++] = i[c];
    this._len = e;
  }, v.prototype.addData = function(t, r, a, e, s, i, c, b, d) {
    if (this._saveData) {
      var u = this.data;
      this._len + arguments.length > u.length && (this._expandData(), u = this.data);
      for (var _ = 0; _ < arguments.length; _++)
        u[this._len++] = arguments[_];
    }
  }, v.prototype._drawPendingPt = function() {
    this._pendingPtDist > 0 && (this._ctx && this._ctx.lineTo(this._pendingPtX, this._pendingPtY), this._pendingPtDist = 0);
  }, v.prototype._expandData = function() {
    if (!(this.data instanceof Array)) {
      for (var t = [], r = 0; r < this._len; r++)
        t[r] = this.data[r];
      this.data = t;
    }
  }, v.prototype.toStatic = function() {
    if (this._saveData) {
      this._drawPendingPt();
      var t = this.data;
      t instanceof Array && (t.length = this._len, nt && this._len > 11 && (this.data = new Float32Array(t)));
    }
  }, v.prototype.getBoundingRect = function() {
    M[0] = M[1] = g[0] = g[1] = Number.MAX_VALUE, q[0] = q[1] = k[0] = k[1] = -Number.MAX_VALUE;
    var t = this.data, r = 0, a = 0, e = 0, s = 0, i;
    for (i = 0; i < this._len; ) {
      var c = t[i++], b = i === 1;
      switch (b && (r = t[i], a = t[i + 1], e = r, s = a), c) {
        case h.M:
          r = e = t[i++], a = s = t[i++], g[0] = e, g[1] = s, k[0] = e, k[1] = s;
          break;
        case h.L:
          _t(r, a, t[i], t[i + 1], g, k), r = t[i++], a = t[i++];
          break;
        case h.C:
          Mt(r, a, t[i++], t[i++], t[i++], t[i++], t[i], t[i + 1], g, k), r = t[i++], a = t[i++];
          break;
        case h.Q:
          Ct(r, a, t[i++], t[i++], t[i], t[i + 1], g, k), r = t[i++], a = t[i++];
          break;
        case h.A:
          var d = t[i++], u = t[i++], _ = t[i++], n = t[i++], y = t[i++], L = t[i++] + y;
          i += 1;
          var D = !t[i++];
          b && (e = V(y) * _ + d, s = Y(y) * n + u), Tt(d, u, _, n, y, L, D, g, k), r = V(L) * _ + d, a = Y(L) * n + u;
          break;
        case h.R:
          e = r = t[i++], s = a = t[i++];
          var f = t[i++], m = t[i++];
          _t(e, s, e + f, s + m, g, k);
          break;
        case h.Z:
          r = e, a = s;
          break;
      }
      yt(M, M, g), Lt(q, q, k);
    }
    return i === 0 && (M[0] = M[1] = q[0] = q[1] = 0), new Dt(M[0], M[1], q[0] - M[0], q[1] - M[1]);
  }, v.prototype._calculateLength = function() {
    var t = this.data, r = this._len, a = this._ux, e = this._uy, s = 0, i = 0, c = 0, b = 0;
    this._pathSegLen || (this._pathSegLen = []);
    for (var d = this._pathSegLen, u = 0, _ = 0, n = 0; n < r; ) {
      var y = t[n++], L = n === 1;
      L && (s = t[n], i = t[n + 1], c = s, b = i);
      var D = -1;
      switch (y) {
        case h.M:
          s = c = t[n++], i = b = t[n++];
          break;
        case h.L: {
          var f = t[n++], m = t[n++], P = f - s, T = m - i;
          (S(P) > a || S(T) > e || n === r - 1) && (D = Math.sqrt(P * P + T * T), s = f, i = m);
          break;
        }
        case h.C: {
          var E = t[n++], U = t[n++], f = t[n++], m = t[n++], o = t[n++], A = t[n++];
          D = kt(s, i, E, U, f, m, o, A, 10), s = o, i = A;
          break;
        }
        case h.Q: {
          var E = t[n++], U = t[n++], f = t[n++], m = t[n++];
          D = gt(s, i, E, U, f, m, 10), s = f, i = m;
          break;
        }
        case h.A:
          var G = t[n++], F = t[n++], z = t[n++], p = t[n++], l = t[n++], H = t[n++], x = H + l;
          n += 1, L && (c = V(l) * z + G, b = Y(l) * p + F), D = st(z, p) * et(w, Math.abs(H)), s = V(x) * z + G, i = Y(x) * p + F;
          break;
        case h.R: {
          c = s = t[n++], b = i = t[n++];
          var Q = t[n++], R = t[n++];
          D = Q * 2 + R * 2;
          break;
        }
        case h.Z: {
          var P = c - s, T = b - i;
          D = Math.sqrt(P * P + T * T), s = c, i = b;
          break;
        }
      }
      D >= 0 && (d[_++] = D, u += D);
    }
    return this._pathLen = u, u;
  }, v.prototype.rebuildPath = function(t, r) {
    var a = this.data, e = this._ux, s = this._uy, i = this._len, c, b, d, u, _, n, y = r < 1, L, D, f = 0, m = 0, P, T = 0, E, U;
    if (!(y && (this._pathSegLen || this._calculateLength(), L = this._pathSegLen, D = this._pathLen, P = r * D, !P)))
      t: for (var o = 0; o < i; ) {
        var A = a[o++], G = o === 1;
        switch (G && (d = a[o], u = a[o + 1], c = d, b = u), A !== h.L && T > 0 && (t.lineTo(E, U), T = 0), A) {
          case h.M:
            c = d = a[o++], b = u = a[o++], t.moveTo(d, u);
            break;
          case h.L: {
            _ = a[o++], n = a[o++];
            var F = S(_ - d), z = S(n - u);
            if (F > e || z > s) {
              if (y) {
                var p = L[m++];
                if (f + p > P) {
                  var l = (P - f) / p;
                  t.lineTo(d * (1 - l) + _ * l, u * (1 - l) + n * l);
                  break t;
                }
                f += p;
              }
              t.lineTo(_, n), d = _, u = n, T = 0;
            } else {
              var H = F * F + z * z;
              H > T && (E = _, U = n, T = H);
            }
            break;
          }
          case h.C: {
            var x = a[o++], Q = a[o++], R = a[o++], N = a[o++], rt = a[o++], it = a[o++];
            if (y) {
              var p = L[m++];
              if (f + p > P) {
                var l = (P - f) / p;
                dt(d, x, R, rt, l, X), dt(u, Q, N, it, l, Z), t.bezierCurveTo(X[1], Z[1], X[2], Z[2], X[3], Z[3]);
                break t;
              }
              f += p;
            }
            t.bezierCurveTo(x, Q, R, N, rt, it), d = rt, u = it;
            break;
          }
          case h.Q: {
            var x = a[o++], Q = a[o++], R = a[o++], N = a[o++];
            if (y) {
              var p = L[m++];
              if (f + p > P) {
                var l = (P - f) / p;
                ct(d, x, R, l, X), ct(u, Q, N, l, Z), t.quadraticCurveTo(X[1], Z[1], X[2], Z[2]);
                break t;
              }
              f += p;
            }
            t.quadraticCurveTo(x, Q, R, N), d = R, u = N;
            break;
          }
          case h.A:
            var W = a[o++], tt = a[o++], O = a[o++], $ = a[o++], B = a[o++], ht = a[o++], Pt = a[o++], ft = !a[o++], lt = O > $ ? O : $, bt = S(O - $) > 1e-3, I = B + ht, ut = !1;
            if (y) {
              var p = L[m++];
              f + p > P && (I = B + ht * (P - f) / p, ut = !0), f += p;
            }
            if (bt && t.ellipse ? t.ellipse(W, tt, O, $, Pt, B, I, ft) : t.arc(W, tt, lt, B, I, ft), ut)
              break t;
            G && (c = V(B) * O + W, b = Y(B) * $ + tt), d = V(I) * O + W, u = Y(I) * $ + tt;
            break;
          case h.R:
            c = d = a[o], b = u = a[o + 1], _ = a[o++], n = a[o++];
            var j = a[o++], J = a[o++];
            if (y) {
              var p = L[m++];
              if (f + p > P) {
                var C = P - f;
                t.moveTo(_, n), t.lineTo(_ + et(C, j), n), C -= j, C > 0 && t.lineTo(_ + j, n + et(C, J)), C -= J, C > 0 && t.lineTo(_ + st(j - C, 0), n + J), C -= j, C > 0 && t.lineTo(_, n + st(J - C, 0));
                break t;
              }
              f += p;
            }
            t.rect(_, n, j, J);
            break;
          case h.Z:
            if (y) {
              var p = L[m++];
              if (f + p > P) {
                var l = (P - f) / p;
                t.lineTo(d * (1 - l) + c * l, u * (1 - l) + b * l);
                break t;
              }
              f += p;
            }
            t.closePath(), d = c, u = b;
        }
      }
  }, v.prototype.clone = function() {
    var t = new v(), r = this.data;
    return t.data = r.slice ? r.slice() : Array.prototype.slice.call(r), t._len = this._len, t;
  }, v.CMD = h, v.initDefaultProps = function() {
    var t = v.prototype;
    t._saveData = !0, t._ux = 0, t._uy = 0, t._pendingPtDist = 0, t._version = 0;
  }(), v;
}();
export {
  Xt as default,
  St as normalizeArcAngles
};
