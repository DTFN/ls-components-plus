var c = Object.defineProperty;
var l = (a, o) => c(a, "name", { value: o, configurable: !0 });
import { __extends as _ } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { indexOf as u } from "../../core/util/index.js";
import d from "../../Element/index.js";
import v from "../../core/BoundingRect/index.js";
var m = function(a) {
  _(o, a);
  function o(r) {
    var t = a.call(this) || this;
    return t.isGroup = !0, t._children = [], t.attr(r), t;
  }
  return l(o, "Group"), o.prototype.childrenRef = function() {
    return this._children;
  }, o.prototype.children = function() {
    return this._children.slice();
  }, o.prototype.childAt = function(r) {
    return this._children[r];
  }, o.prototype.childOfName = function(r) {
    for (var t = this._children, e = 0; e < t.length; e++)
      if (t[e].name === r)
        return t[e];
  }, o.prototype.childCount = function() {
    return this._children.length;
  }, o.prototype.add = function(r) {
    if (r && (r !== this && r.parent !== this && (this._children.push(r), this._doAdd(r)), process.env.NODE_ENV !== "production" && r.__hostTarget))
      throw "This elemenet has been used as an attachment";
    return this;
  }, o.prototype.addBefore = function(r, t) {
    if (r && r !== this && r.parent !== this && t && t.parent === this) {
      var e = this._children, n = e.indexOf(t);
      n >= 0 && (e.splice(n, 0, r), this._doAdd(r));
    }
    return this;
  }, o.prototype.replace = function(r, t) {
    var e = u(this._children, r);
    return e >= 0 && this.replaceAt(t, e), this;
  }, o.prototype.replaceAt = function(r, t) {
    var e = this._children, n = e[t];
    if (r && r !== this && r.parent !== this && r !== n) {
      e[t] = r, n.parent = null;
      var i = this.__zr;
      i && n.removeSelfFromZr(i), this._doAdd(r);
    }
    return this;
  }, o.prototype._doAdd = function(r) {
    r.parent && r.parent.remove(r), r.parent = this;
    var t = this.__zr;
    t && t !== r.__zr && r.addSelfToZr(t), t && t.refresh();
  }, o.prototype.remove = function(r) {
    var t = this.__zr, e = this._children, n = u(e, r);
    return n < 0 ? this : (e.splice(n, 1), r.parent = null, t && r.removeSelfFromZr(t), t && t.refresh(), this);
  }, o.prototype.removeAll = function() {
    for (var r = this._children, t = this.__zr, e = 0; e < r.length; e++) {
      var n = r[e];
      t && n.removeSelfFromZr(t), n.parent = null;
    }
    return r.length = 0, this;
  }, o.prototype.eachChild = function(r, t) {
    for (var e = this._children, n = 0; n < e.length; n++) {
      var i = e[n];
      r.call(t, i, n);
    }
    return this;
  }, o.prototype.traverse = function(r, t) {
    for (var e = 0; e < this._children.length; e++) {
      var n = this._children[e], i = r.call(t, n);
      n.isGroup && !i && n.traverse(r, t);
    }
    return this;
  }, o.prototype.addSelfToZr = function(r) {
    a.prototype.addSelfToZr.call(this, r);
    for (var t = 0; t < this._children.length; t++) {
      var e = this._children[t];
      e.addSelfToZr(r);
    }
  }, o.prototype.removeSelfFromZr = function(r) {
    a.prototype.removeSelfFromZr.call(this, r);
    for (var t = 0; t < this._children.length; t++) {
      var e = this._children[t];
      e.removeSelfFromZr(r);
    }
  }, o.prototype.getBoundingRect = function(r) {
    for (var t = new v(0, 0, 0, 0), e = r || this._children, n = [], i = null, h = 0; h < e.length; h++) {
      var p = e[h];
      if (!(p.ignore || p.invisible)) {
        var s = p.getBoundingRect(), f = p.getLocalTransform(n);
        f ? (v.applyTransform(t, s, f), i = i || t.clone(), i.union(t)) : (i = i || s.clone(), i.union(s));
      }
    }
    return i || t;
  }, o;
}(d);
m.prototype.type = "group";
export {
  m as default
};
