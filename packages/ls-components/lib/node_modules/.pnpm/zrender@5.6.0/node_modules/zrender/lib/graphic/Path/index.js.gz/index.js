var R = Object.defineProperty;
var _ = (l, i) => R(l, "name", { value: i, configurable: !0 });
import { __extends as m } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import b, { DEFAULT_COMMON_STYLE as E, DEFAULT_COMMON_ANIMATION_PROPS as F } from "../Displayable/index.js";
import N from "../../core/PathProxy/index.js";
import { containStroke as B, contain as x } from "../../contain/path/index.js";
import { defaults as O, keys as g, extend as p, isString as S, createObject as I, clone as P } from "../../core/util/index.js";
import { lum as T } from "../../tool/color/index.js";
import { DARK_LABEL_COLOR as A, LIGHTER_LABEL_COLOR as C, LIGHT_LABEL_COLOR as D, DARK_MODE_THRESHOLD as M } from "../../config/index.js";
import { REDRAW_BIT as L, SHAPE_CHANGED_BIT as c, STYLE_CHANGED_BIT as H } from "../constants/index.js";
import { TRANSFORMABLE_PROPS as U } from "../../core/Transformable/index.js";
var k = O({
  fill: "#000",
  stroke: null,
  strokePercent: 1,
  fillOpacity: 1,
  strokeOpacity: 1,
  lineDashOffset: 0,
  lineWidth: 1,
  lineCap: "butt",
  miterLimit: 10,
  strokeNoScale: !1,
  strokeFirst: !1
}, E), z = {
  style: O({
    fill: !0,
    stroke: !0,
    strokePercent: !0,
    fillOpacity: !0,
    strokeOpacity: !0,
    lineDashOffset: !0,
    lineWidth: !0,
    miterLimit: !0
  }, F.style)
}, d = U.concat([
  "invisible",
  "culling",
  "z",
  "z2",
  "zlevel",
  "parent"
]), Q = function(l) {
  m(i, l);
  function i(t) {
    return l.call(this, t) || this;
  }
  return _(i, "Path"), i.prototype.update = function() {
    var t = this;
    l.prototype.update.call(this);
    var e = this.style;
    if (e.decal) {
      var r = this._decalEl = this._decalEl || new i();
      r.buildPath === i.prototype.buildPath && (r.buildPath = function(n) {
        t.buildPath(n, t.shape);
      }), r.silent = !0;
      var s = r.style;
      for (var a in e)
        s[a] !== e[a] && (s[a] = e[a]);
      s.fill = e.fill ? e.decal : null, s.decal = null, s.shadowColor = null, e.strokeFirst && (s.stroke = null);
      for (var h = 0; h < d.length; ++h)
        r[d[h]] = this[d[h]];
      r.__dirty |= L;
    } else this._decalEl && (this._decalEl = null);
  }, i.prototype.getDecalElement = function() {
    return this._decalEl;
  }, i.prototype._init = function(t) {
    var e = g(t);
    this.shape = this.getDefaultShape();
    var r = this.getDefaultStyle();
    r && this.useStyle(r);
    for (var s = 0; s < e.length; s++) {
      var a = e[s], h = t[a];
      a === "style" ? this.style ? p(this.style, h) : this.useStyle(h) : a === "shape" ? p(this.shape, h) : l.prototype.attrKV.call(this, a, h);
    }
    this.style || this.useStyle({});
  }, i.prototype.getDefaultStyle = function() {
    return null;
  }, i.prototype.getDefaultShape = function() {
    return {};
  }, i.prototype.canBeInsideText = function() {
    return this.hasFill();
  }, i.prototype.getInsideTextFill = function() {
    var t = this.style.fill;
    if (t !== "none") {
      if (S(t)) {
        var e = T(t, 0);
        return e > 0.5 ? A : e > 0.2 ? C : D;
      } else if (t)
        return D;
    }
    return A;
  }, i.prototype.getInsideTextStroke = function(t) {
    var e = this.style.fill;
    if (S(e)) {
      var r = this.__zr, s = !!(r && r.isDarkMode()), a = T(t, 0) < M;
      if (s === a)
        return e;
    }
  }, i.prototype.buildPath = function(t, e, r) {
  }, i.prototype.pathUpdated = function() {
    this.__dirty &= ~c;
  }, i.prototype.getUpdatedPathProxy = function(t) {
    return !this.path && this.createPathProxy(), this.path.beginPath(), this.buildPath(this.path, this.shape, t), this.path;
  }, i.prototype.createPathProxy = function() {
    this.path = new N(!1);
  }, i.prototype.hasStroke = function() {
    var t = this.style, e = t.stroke;
    return !(e == null || e === "none" || !(t.lineWidth > 0));
  }, i.prototype.hasFill = function() {
    var t = this.style, e = t.fill;
    return e != null && e !== "none";
  }, i.prototype.getBoundingRect = function() {
    var t = this._rect, e = this.style, r = !t;
    if (r) {
      var s = !1;
      this.path || (s = !0, this.createPathProxy());
      var a = this.path;
      (s || this.__dirty & c) && (a.beginPath(), this.buildPath(a, this.shape, !1), this.pathUpdated()), t = a.getBoundingRect();
    }
    if (this._rect = t, this.hasStroke() && this.path && this.path.len() > 0) {
      var h = this._rectStroke || (this._rectStroke = t.clone());
      if (this.__dirty || r) {
        h.copy(t);
        var n = e.strokeNoScale ? this.getLineScale() : 1, o = e.lineWidth;
        if (!this.hasFill()) {
          var f = this.strokeContainThreshold;
          o = Math.max(o, f ?? 4);
        }
        n > 1e-10 && (h.width += o / n, h.height += o / n, h.x -= o / n / 2, h.y -= o / n / 2);
      }
      return h;
    }
    return t;
  }, i.prototype.contain = function(t, e) {
    var r = this.transformCoordToLocal(t, e), s = this.getBoundingRect(), a = this.style;
    if (t = r[0], e = r[1], s.contain(t, e)) {
      var h = this.path;
      if (this.hasStroke()) {
        var n = a.lineWidth, o = a.strokeNoScale ? this.getLineScale() : 1;
        if (o > 1e-10 && (this.hasFill() || (n = Math.max(n, this.strokeContainThreshold)), B(h, n / o, t, e)))
          return !0;
      }
      if (this.hasFill())
        return x(h, t, e);
    }
    return !1;
  }, i.prototype.dirtyShape = function() {
    this.__dirty |= c, this._rect && (this._rect = null), this._decalEl && this._decalEl.dirtyShape(), this.markRedraw();
  }, i.prototype.dirty = function() {
    this.dirtyStyle(), this.dirtyShape();
  }, i.prototype.animateShape = function(t) {
    return this.animate("shape", t);
  }, i.prototype.updateDuringAnimation = function(t) {
    t === "style" ? this.dirtyStyle() : t === "shape" ? this.dirtyShape() : this.markRedraw();
  }, i.prototype.attrKV = function(t, e) {
    t === "shape" ? this.setShape(e) : l.prototype.attrKV.call(this, t, e);
  }, i.prototype.setShape = function(t, e) {
    var r = this.shape;
    return r || (r = this.shape = {}), typeof t == "string" ? r[t] = e : p(r, t), this.dirtyShape(), this;
  }, i.prototype.shapeChanged = function() {
    return !!(this.__dirty & c);
  }, i.prototype.createStyle = function(t) {
    return I(k, t);
  }, i.prototype._innerSaveToNormal = function(t) {
    l.prototype._innerSaveToNormal.call(this, t);
    var e = this._normalState;
    t.shape && !e.shape && (e.shape = p({}, this.shape));
  }, i.prototype._applyStateObj = function(t, e, r, s, a, h) {
    l.prototype._applyStateObj.call(this, t, e, r, s, a, h);
    var n = !(e && s), o;
    if (e && e.shape ? a ? s ? o = e.shape : (o = p({}, r.shape), p(o, e.shape)) : (o = p({}, s ? this.shape : r.shape), p(o, e.shape)) : n && (o = r.shape), o)
      if (a) {
        this.shape = p({}, this.shape);
        for (var f = {}, v = g(o), y = 0; y < v.length; y++) {
          var u = v[y];
          typeof o[u] == "object" ? this.shape[u] = o[u] : f[u] = o[u];
        }
        this._transitionState(t, {
          shape: f
        }, h);
      } else
        this.shape = o, this.dirtyShape();
  }, i.prototype._mergeStates = function(t) {
    for (var e = l.prototype._mergeStates.call(this, t), r, s = 0; s < t.length; s++) {
      var a = t[s];
      a.shape && (r = r || {}, this._mergeStyle(r, a.shape));
    }
    return r && (e.shape = r), e;
  }, i.prototype.getAnimationStyleProps = function() {
    return z;
  }, i.prototype.isZeroArea = function() {
    return !1;
  }, i.extend = function(t) {
    var e = function(s) {
      m(a, s);
      function a(h) {
        var n = s.call(this, h) || this;
        return t.init && t.init.call(n, h), n;
      }
      return _(a, "Sub"), a.prototype.getDefaultStyle = function() {
        return P(t.style);
      }, a.prototype.getDefaultShape = function() {
        return P(t.shape);
      }, a;
    }(i);
    for (var r in t)
      typeof t[r] == "function" && (e.prototype[r] = t[r]);
    return e;
  }, i.initDefaultProps = function() {
    var t = i.prototype;
    t.type = "path", t.strokeContainThreshold = 5, t.segmentIgnoreThreshold = 0, t.subPixelOptimize = !1, t.autoBatch = !1, t.__dirty = L | H | c;
  }(), i;
}(b);
export {
  z as DEFAULT_PATH_ANIMATION_PROPS,
  k as DEFAULT_PATH_STYLE,
  Q as default
};
