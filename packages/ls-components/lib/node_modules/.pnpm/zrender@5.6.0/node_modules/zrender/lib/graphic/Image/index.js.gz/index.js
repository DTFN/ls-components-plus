var s = Object.defineProperty;
var o = (t, e) => s(t, "name", { value: e, configurable: !0 });
import { __extends as p } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import y, { DEFAULT_COMMON_STYLE as f, DEFAULT_COMMON_ANIMATION_PROPS as l } from "../Displayable/index.js";
import _ from "../../core/BoundingRect/index.js";
import { defaults as a, createObject as m } from "../../core/util/index.js";
var c = a({
  x: 0,
  y: 0
}, f), A = {
  style: a({
    x: !0,
    y: !0,
    width: !0,
    height: !0,
    sx: !0,
    sy: !0,
    sWidth: !0,
    sHeight: !0
  }, l.style)
};
function S(t) {
  return !!(t && typeof t != "string" && t.width && t.height);
}
o(S, "isImageLike");
var d = function(t) {
  p(e, t);
  function e() {
    return t !== null && t.apply(this, arguments) || this;
  }
  return o(e, "ZRImage"), e.prototype.createStyle = function(r) {
    return m(c, r);
  }, e.prototype._getSize = function(r) {
    var i = this.style, h = i[r];
    if (h != null)
      return h;
    var n = S(i.image) ? i.image : this.__image;
    if (!n)
      return 0;
    var u = r === "width" ? "height" : "width", g = i[u];
    return g == null ? n[r] : n[r] / n[u] * g;
  }, e.prototype.getWidth = function() {
    return this._getSize("width");
  }, e.prototype.getHeight = function() {
    return this._getSize("height");
  }, e.prototype.getAnimationStyleProps = function() {
    return A;
  }, e.prototype.getBoundingRect = function() {
    var r = this.style;
    return this._rect || (this._rect = new _(r.x || 0, r.y || 0, this.getWidth(), this.getHeight())), this._rect;
  }, e;
}(y);
d.prototype.type = "image";
export {
  A as DEFAULT_IMAGE_ANIMATION_PROPS,
  c as DEFAULT_IMAGE_STYLE,
  d as default
};
