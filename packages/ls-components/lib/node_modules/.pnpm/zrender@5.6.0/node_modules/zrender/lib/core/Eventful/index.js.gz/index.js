var c = Object.defineProperty;
var e = (o, r) => c(o, "name", { value: r, configurable: !0 });
var v = function() {
  function o(r) {
    r && (this._$eventProcessor = r);
  }
  return e(o, "Eventful"), o.prototype.on = function(r, a, t, i) {
    this._$handlers || (this._$handlers = {});
    var s = this._$handlers;
    if (typeof a == "function" && (i = t, t = a, a = null), !t || !r)
      return this;
    var f = this._$eventProcessor;
    a != null && f && f.normalizeQuery && (a = f.normalizeQuery(a)), s[r] || (s[r] = []);
    for (var h = 0; h < s[r].length; h++)
      if (s[r][h].h === t)
        return this;
    var u = {
      h: t,
      query: a,
      ctx: i || this,
      callAtLast: t.zrEventfulCallAtLast
    }, l = s[r].length - 1, n = s[r][l];
    return n && n.callAtLast ? s[r].splice(l, 0, u) : s[r].push(u), this;
  }, o.prototype.isSilent = function(r) {
    var a = this._$handlers;
    return !a || !a[r] || !a[r].length;
  }, o.prototype.off = function(r, a) {
    var t = this._$handlers;
    if (!t)
      return this;
    if (!r)
      return this._$handlers = {}, this;
    if (a) {
      if (t[r]) {
        for (var i = [], s = 0, f = t[r].length; s < f; s++)
          t[r][s].h !== a && i.push(t[r][s]);
        t[r] = i;
      }
      t[r] && t[r].length === 0 && delete t[r];
    } else
      delete t[r];
    return this;
  }, o.prototype.trigger = function(r) {
    for (var a = [], t = 1; t < arguments.length; t++)
      a[t - 1] = arguments[t];
    if (!this._$handlers)
      return this;
    var i = this._$handlers[r], s = this._$eventProcessor;
    if (i)
      for (var f = a.length, h = i.length, u = 0; u < h; u++) {
        var l = i[u];
        if (!(s && s.filter && l.query != null && !s.filter(r, l.query)))
          switch (f) {
            case 0:
              l.h.call(l.ctx);
              break;
            case 1:
              l.h.call(l.ctx, a[0]);
              break;
            case 2:
              l.h.call(l.ctx, a[0], a[1]);
              break;
            default:
              l.h.apply(l.ctx, a);
              break;
          }
      }
    return s && s.afterTrigger && s.afterTrigger(r), this;
  }, o.prototype.triggerWithContext = function(r) {
    for (var a = [], t = 1; t < arguments.length; t++)
      a[t - 1] = arguments[t];
    if (!this._$handlers)
      return this;
    var i = this._$handlers[r], s = this._$eventProcessor;
    if (i)
      for (var f = a.length, h = a[f - 1], u = i.length, l = 0; l < u; l++) {
        var n = i[l];
        if (!(s && s.filter && n.query != null && !s.filter(r, n.query)))
          switch (f) {
            case 0:
              n.h.call(h);
              break;
            case 1:
              n.h.call(h, a[0]);
              break;
            case 2:
              n.h.call(h, a[0], a[1]);
              break;
            default:
              n.h.apply(h, a.slice(1, f - 1));
              break;
          }
      }
    return s && s.afterTrigger && s.afterTrigger(r), this;
  }, o;
}();
export {
  v as default
};
