var l = Object.defineProperty;
var T = (s, a) => l(s, "name", { value: a, configurable: !0 });
import { cubicSubdivide as A } from "../../core/curve/index.js";
import aa from "../../core/PathProxy/index.js";
var C = aa.CMD;
function Y(s, a) {
  return Math.abs(s - a) < 1e-5;
}
T(Y, "aroundEqual");
function ra(s) {
  var a = s.data, m = s.len(), b = [], o, v = 0, h = 0, u = 0, t = 0;
  function M(q, P) {
    o && o.length > 2 && b.push(o), o = [q, P];
  }
  T(M, "createNewSubpath");
  function n(q, P, G, R) {
    Y(q, G) && Y(P, R) || o.push(q, P, G, R, G, R);
  }
  T(n, "addLine");
  function E(q, P, G, R, Z, w) {
    var g = Math.abs(P - q), J = Math.tan(g / 4) * 4 / 3, K = P < q ? -1 : 1, O = Math.cos(q), U = Math.sin(q), V = Math.cos(P), W = Math.sin(P), x = O * Z + G, y = U * w + R, $ = V * Z + G, k = W * w + R, F = Z * J * K, z = w * J * K;
    o.push(x - F * U, y + z * O, $ + F * W, k - z * V, $, k);
  }
  T(E, "addArc");
  for (var p, f, L, d, r = 0; r < m; ) {
    var I = a[r++], Q = r === 1;
    switch (Q && (v = a[r], h = a[r + 1], u = v, t = h, (I === C.L || I === C.C || I === C.Q) && (o = [u, t])), I) {
      case C.M:
        v = u = a[r++], h = t = a[r++], M(u, t);
        break;
      case C.L:
        p = a[r++], f = a[r++], n(v, h, p, f), v = p, h = f;
        break;
      case C.C:
        o.push(a[r++], a[r++], a[r++], a[r++], v = a[r++], h = a[r++]);
        break;
      case C.Q:
        p = a[r++], f = a[r++], L = a[r++], d = a[r++], o.push(v + 2 / 3 * (p - v), h + 2 / 3 * (f - h), L + 2 / 3 * (p - L), d + 2 / 3 * (f - d), L, d), v = L, h = d;
        break;
      case C.A:
        var X = a[r++], _ = a[r++], e = a[r++], N = a[r++], j = a[r++], D = a[r++] + j;
        r += 1;
        var S = !a[r++];
        p = Math.cos(j) * e + X, f = Math.sin(j) * N + _, Q ? (u = p, t = f, M(u, t)) : n(v, h, p, f), v = Math.cos(D) * e + X, h = Math.sin(D) * N + _;
        for (var c = (S ? -1 : 1) * Math.PI / 2, B = j; S ? B > D : B < D; B += c) {
          var i = S ? Math.max(B + c, D) : Math.min(B + c, D);
          E(B, i, X, _, e, N);
        }
        break;
      case C.R:
        u = v = a[r++], t = h = a[r++], p = u + a[r++], f = t + a[r++], M(p, t), n(p, t, p, f), n(p, f, u, f), n(u, f, u, t), n(u, t, p, t);
        break;
      case C.Z:
        o && n(v, h, u, t), v = u, h = t;
        break;
    }
  }
  return o && o.length > 2 && b.push(o), b;
}
T(ra, "pathToBezierCurves");
function H(s, a, m, b, o, v, h, u, t, M) {
  if (Y(s, m) && Y(a, b) && Y(o, h) && Y(v, u)) {
    t.push(h, u);
    return;
  }
  var n = 2 / M, E = n * n, p = h - s, f = u - a, L = Math.sqrt(p * p + f * f);
  p /= L, f /= L;
  var d = m - s, r = b - a, I = o - h, Q = v - u, X = d * d + r * r, _ = I * I + Q * Q;
  if (X < E && _ < E) {
    t.push(h, u);
    return;
  }
  var e = p * d + f * r, N = -p * I - f * Q, j = X - e * e, D = _ - N * N;
  if (j < E && e >= 0 && D < E && N >= 0) {
    t.push(h, u);
    return;
  }
  var S = [], c = [];
  A(s, m, o, h, 0.5, S), A(a, b, v, u, 0.5, c), H(S[0], c[0], S[1], c[1], S[2], c[2], S[3], c[3], t, M), H(S[4], c[4], S[5], c[5], S[6], c[6], S[7], c[7], t, M);
}
T(H, "adpativeBezier");
function ta(s, a) {
  var m = ra(s), b = [];
  a = a || 1;
  for (var o = 0; o < m.length; o++) {
    var v = m[o], h = [], u = v[0], t = v[1];
    h.push(u, t);
    for (var M = 2; M < v.length; ) {
      var n = v[M++], E = v[M++], p = v[M++], f = v[M++], L = v[M++], d = v[M++];
      H(u, t, n, E, p, f, L, d, h, a), u = L, t = d;
    }
    b.push(h);
  }
  return b;
}
T(ta, "pathToPolygons");
export {
  ra as pathToBezierCurves,
  ta as pathToPolygons
};
