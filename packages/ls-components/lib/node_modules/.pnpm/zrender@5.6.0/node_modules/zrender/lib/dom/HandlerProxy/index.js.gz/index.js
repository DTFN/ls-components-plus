var S = Object.defineProperty;
var i = (o, t) => S(o, "name", { value: t, configurable: !0 });
import { __extends as D } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { normalizeEvent as n, addEventListener as L, removeEventListener as O, getNativeEvent as C } from "../../core/event/index.js";
import { map as b, each as a, noop as c } from "../../core/util/index.js";
import P from "../../core/Eventful/index.js";
import m from "../../core/env/index.js";
var M = 300, p = m.domSupported, f = function() {
  var o = [
    "click",
    "dblclick",
    "mousewheel",
    "wheel",
    "mouseout",
    "mouseup",
    "mousedown",
    "mousemove",
    "contextmenu"
  ], t = [
    "touchstart",
    "touchend",
    "touchmove"
  ], r = {
    pointerdown: 1,
    pointerup: 1,
    pointermove: 1,
    pointerout: 1
  }, e = b(o, function(u) {
    var l = u.replace("mouse", "pointer");
    return r.hasOwnProperty(l) ? l : u;
  });
  return {
    mouse: o,
    touch: t,
    pointer: e
  };
}(), w = {
  mouse: ["mousemove", "mouseup"],
  pointer: ["pointermove", "pointerup"]
}, y = !1;
function _(o) {
  var t = o.pointerType;
  return t === "pen" || t === "touch";
}
i(_, "isPointerFromTouch");
function z(o) {
  o.touching = !0, o.touchTimer != null && (clearTimeout(o.touchTimer), o.touchTimer = null), o.touchTimer = setTimeout(function() {
    o.touching = !1, o.touchTimer = null;
  }, 700);
}
i(z, "setTouchTimer");
function d(o) {
  o && (o.zrByTouch = !0);
}
i(d, "markTouch");
function k(o, t) {
  return n(o.dom, new G(o, t), !0);
}
i(k, "normalizeGlobalEvent");
function E(o, t) {
  for (var r = t, e = !1; r && r.nodeType !== 9 && !(e = r.domBelongToZr || r !== t && r === o.painterRoot); )
    r = r.parentNode;
  return e;
}
i(E, "isLocalEl");
var G = function() {
  function o(t, r) {
    this.stopPropagation = c, this.stopImmediatePropagation = c, this.preventDefault = c, this.type = r.type, this.target = this.currentTarget = t.dom, this.pointerType = r.pointerType, this.clientX = r.clientX, this.clientY = r.clientY;
  }
  return i(o, "FakeGlobalEvent"), o;
}(), s = {
  mousedown: /* @__PURE__ */ i(function(o) {
    o = n(this.dom, o), this.__mayPointerCapture = [o.zrX, o.zrY], this.trigger("mousedown", o);
  }, "mousedown"),
  mousemove: /* @__PURE__ */ i(function(o) {
    o = n(this.dom, o);
    var t = this.__mayPointerCapture;
    t && (o.zrX !== t[0] || o.zrY !== t[1]) && this.__togglePointerCapture(!0), this.trigger("mousemove", o);
  }, "mousemove"),
  mouseup: /* @__PURE__ */ i(function(o) {
    o = n(this.dom, o), this.__togglePointerCapture(!1), this.trigger("mouseup", o);
  }, "mouseup"),
  mouseout: /* @__PURE__ */ i(function(o) {
    o = n(this.dom, o);
    var t = o.toElement || o.relatedTarget;
    E(this, t) || (this.__pointerCapturing && (o.zrEventControl = "no_globalout"), this.trigger("mouseout", o));
  }, "mouseout"),
  wheel: /* @__PURE__ */ i(function(o) {
    y = !0, o = n(this.dom, o), this.trigger("mousewheel", o);
  }, "wheel"),
  mousewheel: /* @__PURE__ */ i(function(o) {
    y || (o = n(this.dom, o), this.trigger("mousewheel", o));
  }, "mousewheel"),
  touchstart: /* @__PURE__ */ i(function(o) {
    o = n(this.dom, o), d(o), this.__lastTouchMoment = /* @__PURE__ */ new Date(), this.handler.processGesture(o, "start"), s.mousemove.call(this, o), s.mousedown.call(this, o);
  }, "touchstart"),
  touchmove: /* @__PURE__ */ i(function(o) {
    o = n(this.dom, o), d(o), this.handler.processGesture(o, "change"), s.mousemove.call(this, o);
  }, "touchmove"),
  touchend: /* @__PURE__ */ i(function(o) {
    o = n(this.dom, o), d(o), this.handler.processGesture(o, "end"), s.mouseup.call(this, o), +/* @__PURE__ */ new Date() - +this.__lastTouchMoment < M && s.click.call(this, o);
  }, "touchend"),
  pointerdown: /* @__PURE__ */ i(function(o) {
    s.mousedown.call(this, o);
  }, "pointerdown"),
  pointermove: /* @__PURE__ */ i(function(o) {
    _(o) || s.mousemove.call(this, o);
  }, "pointermove"),
  pointerup: /* @__PURE__ */ i(function(o) {
    s.mouseup.call(this, o);
  }, "pointerup"),
  pointerout: /* @__PURE__ */ i(function(o) {
    _(o) || s.mouseout.call(this, o);
  }, "pointerout")
};
a(["click", "dblclick", "contextmenu"], function(o) {
  s[o] = function(t) {
    t = n(this.dom, t), this.trigger(o, t);
  };
});
var T = {
  pointermove: /* @__PURE__ */ i(function(o) {
    _(o) || T.mousemove.call(this, o);
  }, "pointermove"),
  pointerup: /* @__PURE__ */ i(function(o) {
    T.mouseup.call(this, o);
  }, "pointerup"),
  mousemove: /* @__PURE__ */ i(function(o) {
    this.trigger("mousemove", o);
  }, "mousemove"),
  mouseup: /* @__PURE__ */ i(function(o) {
    var t = this.__pointerCapturing;
    this.__togglePointerCapture(!1), this.trigger("mouseup", o), t && (o.zrEventControl = "only_globalout", this.trigger("mouseout", o));
  }, "mouseup")
};
function x(o, t) {
  var r = t.domHandlers;
  m.pointerEventsSupported ? a(f.pointer, function(e) {
    h(t, e, function(u) {
      r[e].call(o, u);
    });
  }) : (m.touchEventsSupported && a(f.touch, function(e) {
    h(t, e, function(u) {
      r[e].call(o, u), z(t);
    });
  }), a(f.mouse, function(e) {
    h(t, e, function(u) {
      u = C(u), t.touching || r[e].call(o, u);
    });
  }));
}
i(x, "mountLocalDOMEventListeners");
function Y(o, t) {
  m.pointerEventsSupported ? a(w.pointer, r) : m.touchEventsSupported || a(w.mouse, r);
  function r(e) {
    function u(l) {
      l = C(l), E(o, l.target) || (l = k(o, l), t.domHandlers[e].call(o, l));
    }
    i(u, "nativeEventListener"), h(t, e, u, { capture: !0 });
  }
  i(r, "mount");
}
i(Y, "mountGlobalDOMEventListeners");
function h(o, t, r, e) {
  o.mounted[t] = r, o.listenerOpts[t] = e, L(o.domTarget, t, r, e);
}
i(h, "mountSingleDOMEventListener");
function g(o) {
  var t = o.mounted;
  for (var r in t)
    t.hasOwnProperty(r) && O(o.domTarget, r, t[r], o.listenerOpts[r]);
  o.mounted = {};
}
i(g, "unmountDOMEventListeners");
var H = function() {
  function o(t, r) {
    this.mounted = {}, this.listenerOpts = {}, this.touching = !1, this.domTarget = t, this.domHandlers = r;
  }
  return i(o, "DOMHandlerScope"), o;
}(), A = function(o) {
  D(t, o);
  function t(r, e) {
    var u = o.call(this) || this;
    return u.__pointerCapturing = !1, u.dom = r, u.painterRoot = e, u._localHandlerScope = new H(r, s), p && (u._globalHandlerScope = new H(document, T)), x(u, u._localHandlerScope), u;
  }
  return i(t, "HandlerDomProxy"), t.prototype.dispose = function() {
    g(this._localHandlerScope), p && g(this._globalHandlerScope);
  }, t.prototype.setCursor = function(r) {
    this.dom.style && (this.dom.style.cursor = r || "default");
  }, t.prototype.__togglePointerCapture = function(r) {
    if (this.__mayPointerCapture = null, p && +this.__pointerCapturing ^ +r) {
      this.__pointerCapturing = r;
      var e = this._globalHandlerScope;
      r ? Y(this, e) : g(e);
    }
  }, t;
}(P);
export {
  A as default
};
