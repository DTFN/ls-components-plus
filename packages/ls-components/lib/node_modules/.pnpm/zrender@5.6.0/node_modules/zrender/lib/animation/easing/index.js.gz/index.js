var a = Object.defineProperty;
var t = (n, r) => a(n, "name", { value: r, configurable: !0 });
var e = {
  linear: /* @__PURE__ */ t(function(n) {
    return n;
  }, "linear"),
  quadraticIn: /* @__PURE__ */ t(function(n) {
    return n * n;
  }, "quadraticIn"),
  quadraticOut: /* @__PURE__ */ t(function(n) {
    return n * (2 - n);
  }, "quadraticOut"),
  quadraticInOut: /* @__PURE__ */ t(function(n) {
    return (n *= 2) < 1 ? 0.5 * n * n : -0.5 * (--n * (n - 2) - 1);
  }, "quadraticInOut"),
  cubicIn: /* @__PURE__ */ t(function(n) {
    return n * n * n;
  }, "cubicIn"),
  cubicOut: /* @__PURE__ */ t(function(n) {
    return --n * n * n + 1;
  }, "cubicOut"),
  cubicInOut: /* @__PURE__ */ t(function(n) {
    return (n *= 2) < 1 ? 0.5 * n * n * n : 0.5 * ((n -= 2) * n * n + 2);
  }, "cubicInOut"),
  quarticIn: /* @__PURE__ */ t(function(n) {
    return n * n * n * n;
  }, "quarticIn"),
  quarticOut: /* @__PURE__ */ t(function(n) {
    return 1 - --n * n * n * n;
  }, "quarticOut"),
  quarticInOut: /* @__PURE__ */ t(function(n) {
    return (n *= 2) < 1 ? 0.5 * n * n * n * n : -0.5 * ((n -= 2) * n * n * n - 2);
  }, "quarticInOut"),
  quinticIn: /* @__PURE__ */ t(function(n) {
    return n * n * n * n * n;
  }, "quinticIn"),
  quinticOut: /* @__PURE__ */ t(function(n) {
    return --n * n * n * n * n + 1;
  }, "quinticOut"),
  quinticInOut: /* @__PURE__ */ t(function(n) {
    return (n *= 2) < 1 ? 0.5 * n * n * n * n * n : 0.5 * ((n -= 2) * n * n * n * n + 2);
  }, "quinticInOut"),
  sinusoidalIn: /* @__PURE__ */ t(function(n) {
    return 1 - Math.cos(n * Math.PI / 2);
  }, "sinusoidalIn"),
  sinusoidalOut: /* @__PURE__ */ t(function(n) {
    return Math.sin(n * Math.PI / 2);
  }, "sinusoidalOut"),
  sinusoidalInOut: /* @__PURE__ */ t(function(n) {
    return 0.5 * (1 - Math.cos(Math.PI * n));
  }, "sinusoidalInOut"),
  exponentialIn: /* @__PURE__ */ t(function(n) {
    return n === 0 ? 0 : Math.pow(1024, n - 1);
  }, "exponentialIn"),
  exponentialOut: /* @__PURE__ */ t(function(n) {
    return n === 1 ? 1 : 1 - Math.pow(2, -10 * n);
  }, "exponentialOut"),
  exponentialInOut: /* @__PURE__ */ t(function(n) {
    return n === 0 ? 0 : n === 1 ? 1 : (n *= 2) < 1 ? 0.5 * Math.pow(1024, n - 1) : 0.5 * (-Math.pow(2, -10 * (n - 1)) + 2);
  }, "exponentialInOut"),
  circularIn: /* @__PURE__ */ t(function(n) {
    return 1 - Math.sqrt(1 - n * n);
  }, "circularIn"),
  circularOut: /* @__PURE__ */ t(function(n) {
    return Math.sqrt(1 - --n * n);
  }, "circularOut"),
  circularInOut: /* @__PURE__ */ t(function(n) {
    return (n *= 2) < 1 ? -0.5 * (Math.sqrt(1 - n * n) - 1) : 0.5 * (Math.sqrt(1 - (n -= 2) * n) + 1);
  }, "circularInOut"),
  elasticIn: /* @__PURE__ */ t(function(n) {
    var r, u = 0.1, i = 0.4;
    return n === 0 ? 0 : n === 1 ? 1 : (!u || u < 1 ? (u = 1, r = i / 4) : r = i * Math.asin(1 / u) / (2 * Math.PI), -(u * Math.pow(2, 10 * (n -= 1)) * Math.sin((n - r) * (2 * Math.PI) / i)));
  }, "elasticIn"),
  elasticOut: /* @__PURE__ */ t(function(n) {
    var r, u = 0.1, i = 0.4;
    return n === 0 ? 0 : n === 1 ? 1 : (!u || u < 1 ? (u = 1, r = i / 4) : r = i * Math.asin(1 / u) / (2 * Math.PI), u * Math.pow(2, -10 * n) * Math.sin((n - r) * (2 * Math.PI) / i) + 1);
  }, "elasticOut"),
  elasticInOut: /* @__PURE__ */ t(function(n) {
    var r, u = 0.1, i = 0.4;
    return n === 0 ? 0 : n === 1 ? 1 : (!u || u < 1 ? (u = 1, r = i / 4) : r = i * Math.asin(1 / u) / (2 * Math.PI), (n *= 2) < 1 ? -0.5 * (u * Math.pow(2, 10 * (n -= 1)) * Math.sin((n - r) * (2 * Math.PI) / i)) : u * Math.pow(2, -10 * (n -= 1)) * Math.sin((n - r) * (2 * Math.PI) / i) * 0.5 + 1);
  }, "elasticInOut"),
  backIn: /* @__PURE__ */ t(function(n) {
    var r = 1.70158;
    return n * n * ((r + 1) * n - r);
  }, "backIn"),
  backOut: /* @__PURE__ */ t(function(n) {
    var r = 1.70158;
    return --n * n * ((r + 1) * n + r) + 1;
  }, "backOut"),
  backInOut: /* @__PURE__ */ t(function(n) {
    var r = 2.5949095;
    return (n *= 2) < 1 ? 0.5 * (n * n * ((r + 1) * n - r)) : 0.5 * ((n -= 2) * n * ((r + 1) * n + r) + 2);
  }, "backInOut"),
  bounceIn: /* @__PURE__ */ t(function(n) {
    return 1 - e.bounceOut(1 - n);
  }, "bounceIn"),
  bounceOut: /* @__PURE__ */ t(function(n) {
    return n < 0.36363636363636365 ? 7.5625 * n * n : n < 0.7272727272727273 ? 7.5625 * (n -= 0.5454545454545454) * n + 0.75 : n < 0.9090909090909091 ? 7.5625 * (n -= 0.8181818181818182) * n + 0.9375 : 7.5625 * (n -= 0.9545454545454546) * n + 0.984375;
  }, "bounceOut"),
  bounceInOut: /* @__PURE__ */ t(function(n) {
    return n < 0.5 ? e.bounceIn(n * 2) * 0.5 : e.bounceOut(n * 2 - 1) * 0.5 + 0.5;
  }, "bounceInOut")
};
export {
  e as default
};
