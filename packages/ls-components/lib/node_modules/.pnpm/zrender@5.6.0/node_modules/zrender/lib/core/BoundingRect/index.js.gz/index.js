var q = Object.defineProperty;
var j = (n, i) => q(n, "name", { value: i, configurable: !0 });
import { translate as k, scale as z, create as A } from "../matrix/index.js";
import s from "../Point/index.js";
var R = Math.min, I = Math.max, y = new s(), r = new s(), f = new s(), o = new s(), T = new s(), M = new s(), G = function() {
  function n(i, h, t, a) {
    t < 0 && (i = i + t, t = -t), a < 0 && (h = h + a, a = -a), this.x = i, this.y = h, this.width = t, this.height = a;
  }
  return j(n, "BoundingRect"), n.prototype.union = function(i) {
    var h = R(i.x, this.x), t = R(i.y, this.y);
    isFinite(this.x) && isFinite(this.width) ? this.width = I(i.x + i.width, this.x + this.width) - h : this.width = i.width, isFinite(this.y) && isFinite(this.height) ? this.height = I(i.y + i.height, this.y + this.height) - t : this.height = i.height, this.x = h, this.y = t;
  }, n.prototype.applyTransform = function(i) {
    n.applyTransform(this, this, i);
  }, n.prototype.calculateTransform = function(i) {
    var h = this, t = i.width / h.width, a = i.height / h.height, e = A();
    return k(e, e, [-h.x, -h.y]), z(e, e, [t, a]), k(e, e, [i.x, i.y]), e;
  }, n.prototype.intersect = function(i, h) {
    if (!i)
      return !1;
    i instanceof n || (i = n.create(i));
    var t = this, a = t.x, e = t.x + t.width, x = t.y, p = t.y + t.height, w = i.x, l = i.x + i.width, P = i.y, X = i.y + i.height, Y = !(e < w || l < a || p < P || X < x);
    if (h) {
      var g = 1 / 0, B = 0, u = Math.abs(e - w), c = Math.abs(l - a), m = Math.abs(p - P), F = Math.abs(X - x), v = Math.min(u, c), Z = Math.min(m, F);
      e < w || l < a ? v > B && (B = v, u < c ? s.set(M, -u, 0) : s.set(M, c, 0)) : v < g && (g = v, u < c ? s.set(T, u, 0) : s.set(T, -c, 0)), p < P || X < x ? Z > B && (B = Z, m < F ? s.set(M, 0, -m) : s.set(M, 0, F)) : v < g && (g = v, m < F ? s.set(T, 0, m) : s.set(T, 0, -F));
    }
    return h && s.copy(h, Y ? T : M), Y;
  }, n.prototype.contain = function(i, h) {
    var t = this;
    return i >= t.x && i <= t.x + t.width && h >= t.y && h <= t.y + t.height;
  }, n.prototype.clone = function() {
    return new n(this.x, this.y, this.width, this.height);
  }, n.prototype.copy = function(i) {
    n.copy(this, i);
  }, n.prototype.plain = function() {
    return {
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height
    };
  }, n.prototype.isFinite = function() {
    return isFinite(this.x) && isFinite(this.y) && isFinite(this.width) && isFinite(this.height);
  }, n.prototype.isZero = function() {
    return this.width === 0 || this.height === 0;
  }, n.create = function(i) {
    return new n(i.x, i.y, i.width, i.height);
  }, n.copy = function(i, h) {
    i.x = h.x, i.y = h.y, i.width = h.width, i.height = h.height;
  }, n.applyTransform = function(i, h, t) {
    if (!t) {
      i !== h && n.copy(i, h);
      return;
    }
    if (t[1] < 1e-5 && t[1] > -1e-5 && t[2] < 1e-5 && t[2] > -1e-5) {
      var a = t[0], e = t[3], x = t[4], p = t[5];
      i.x = h.x * a + x, i.y = h.y * e + p, i.width = h.width * a, i.height = h.height * e, i.width < 0 && (i.x += i.width, i.width = -i.width), i.height < 0 && (i.y += i.height, i.height = -i.height);
      return;
    }
    y.x = f.x = h.x, y.y = o.y = h.y, r.x = o.x = h.x + h.width, r.y = f.y = h.y + h.height, y.transform(t), o.transform(t), r.transform(t), f.transform(t), i.x = R(y.x, r.x, f.x, o.x), i.y = R(y.y, r.y, f.y, o.y);
    var w = I(y.x, r.x, f.x, o.x), l = I(y.y, r.y, f.y, o.y);
    i.width = w - i.x, i.height = l - i.y;
  }, n;
}();
export {
  G as default
};
