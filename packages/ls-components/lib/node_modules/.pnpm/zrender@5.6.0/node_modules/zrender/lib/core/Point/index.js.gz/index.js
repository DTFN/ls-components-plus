var x = Object.defineProperty;
var o = (i, t) => x(i, "name", { value: t, configurable: !0 });
var h = function() {
  function i(t, n) {
    this.x = t || 0, this.y = n || 0;
  }
  return o(i, "Point"), i.prototype.copy = function(t) {
    return this.x = t.x, this.y = t.y, this;
  }, i.prototype.clone = function() {
    return new i(this.x, this.y);
  }, i.prototype.set = function(t, n) {
    return this.x = t, this.y = n, this;
  }, i.prototype.equal = function(t) {
    return t.x === this.x && t.y === this.y;
  }, i.prototype.add = function(t) {
    return this.x += t.x, this.y += t.y, this;
  }, i.prototype.scale = function(t) {
    this.x *= t, this.y *= t;
  }, i.prototype.scaleAndAdd = function(t, n) {
    this.x += t.x * n, this.y += t.y * n;
  }, i.prototype.sub = function(t) {
    return this.x -= t.x, this.y -= t.y, this;
  }, i.prototype.dot = function(t) {
    return this.x * t.x + this.y * t.y;
  }, i.prototype.len = function() {
    return Math.sqrt(this.x * this.x + this.y * this.y);
  }, i.prototype.lenSquare = function() {
    return this.x * this.x + this.y * this.y;
  }, i.prototype.normalize = function() {
    var t = this.len();
    return this.x /= t, this.y /= t, this;
  }, i.prototype.distance = function(t) {
    var n = this.x - t.x, y = this.y - t.y;
    return Math.sqrt(n * n + y * y);
  }, i.prototype.distanceSquare = function(t) {
    var n = this.x - t.x, y = this.y - t.y;
    return n * n + y * y;
  }, i.prototype.negate = function() {
    return this.x = -this.x, this.y = -this.y, this;
  }, i.prototype.transform = function(t) {
    if (t) {
      var n = this.x, y = this.y;
      return this.x = t[0] * n + t[2] * y + t[4], this.y = t[1] * n + t[3] * y + t[5], this;
    }
  }, i.prototype.toArray = function(t) {
    return t[0] = this.x, t[1] = this.y, t;
  }, i.prototype.fromArray = function(t) {
    this.x = t[0], this.y = t[1];
  }, i.set = function(t, n, y) {
    t.x = n, t.y = y;
  }, i.copy = function(t, n) {
    t.x = n.x, t.y = n.y;
  }, i.len = function(t) {
    return Math.sqrt(t.x * t.x + t.y * t.y);
  }, i.lenSquare = function(t) {
    return t.x * t.x + t.y * t.y;
  }, i.dot = function(t, n) {
    return t.x * n.x + t.y * n.y;
  }, i.add = function(t, n, y) {
    t.x = n.x + y.x, t.y = n.y + y.y;
  }, i.sub = function(t, n, y) {
    t.x = n.x - y.x, t.y = n.y - y.y;
  }, i.scale = function(t, n, y) {
    t.x = n.x * y, t.y = n.y * y;
  }, i.scaleAndAdd = function(t, n, y, r) {
    t.x = n.x + y.x * r, t.y = n.y + y.y * r;
  }, i.lerp = function(t, n, y, r) {
    var s = 1 - r;
    t.x = s * n.x + r * y.x, t.y = s * n.y + r * y.y;
  }, i;
}();
export {
  h as default
};
