var b = Object.defineProperty;
var m = (r, i) => b(r, "name", { value: i, configurable: !0 });
var g = Math.round;
function P(r, i, f) {
  if (i) {
    var x = i.x1, d = i.x2, v = i.y1, y = i.y2;
    r.x1 = x, r.x2 = d, r.y1 = v, r.y2 = y;
    var n = f && f.lineWidth;
    return n && (g(x * 2) === g(d * 2) && (r.x1 = r.x2 = l(x, n, !0)), g(v * 2) === g(y * 2) && (r.y1 = r.y2 = l(v, n, !0))), r;
  }
}
m(P, "subPixelOptimizeLine");
function W(r, i, f) {
  if (i) {
    var x = i.x, d = i.y, v = i.width, y = i.height;
    r.x = x, r.y = d, r.width = v, r.height = y;
    var n = f && f.lineWidth;
    return n && (r.x = l(x, n, !0), r.y = l(d, n, !0), r.width = Math.max(l(x + v, n, !1) - r.x, v === 0 ? 0 : 1), r.height = Math.max(l(d + y, n, !1) - r.y, y === 0 ? 0 : 1)), r;
  }
}
m(W, "subPixelOptimizeRect");
function l(r, i, f) {
  if (!i)
    return r;
  var x = g(r * 2);
  return (x + g(i)) % 2 === 0 ? x / 2 : (x + (f ? 1 : -1)) / 2;
}
m(l, "subPixelOptimize");
export {
  l as subPixelOptimize,
  P as subPixelOptimizeLine,
  W as subPixelOptimizeRect
};
