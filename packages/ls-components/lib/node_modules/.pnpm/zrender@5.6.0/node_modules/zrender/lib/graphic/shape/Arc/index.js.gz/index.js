var v = Object.defineProperty;
var i = (r, t) => v(r, "name", { value: t, configurable: !0 });
import { __extends as A } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import p from "../../Path/index.js";
var y = function() {
  function r() {
    this.cx = 0, this.cy = 0, this.r = 0, this.startAngle = 0, this.endAngle = Math.PI * 2, this.clockwise = !0;
  }
  return i(r, "ArcShape"), r;
}(), g = function(r) {
  A(t, r);
  function t(e) {
    return r.call(this, e) || this;
  }
  return i(t, "Arc"), t.prototype.getDefaultStyle = function() {
    return {
      stroke: "#000",
      fill: null
    };
  }, t.prototype.getDefaultShape = function() {
    return new y();
  }, t.prototype.buildPath = function(e, n) {
    var c = n.cx, l = n.cy, o = Math.max(n.r, 0), a = n.startAngle, u = n.endAngle, f = n.clockwise, s = Math.cos(a), h = Math.sin(a);
    e.moveTo(s * o + c, h * o + l), e.arc(c, l, o, a, u, !f);
  }, t;
}(p);
g.prototype.type = "arc";
export {
  y as ArcShape,
  g as default
};
