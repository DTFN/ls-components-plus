var q = Object.defineProperty;
var x = (r, t) => q(r, "name", { value: t, configurable: !0 });
import { __extends as B } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import D from "../../Path/index.js";
import { normalize as P } from "../../../core/vector/index.js";
import { quadraticSubdivide as d, cubicSubdivide as m, cubicDerivativeAt as b, cubicAt as z, quadraticDerivativeAt as A, quadraticAt as C } from "../../../core/curve/index.js";
var u = [], k = function() {
  function r() {
    this.x1 = 0, this.y1 = 0, this.x2 = 0, this.y2 = 0, this.cpx1 = 0, this.cpy1 = 0, this.percent = 1;
  }
  return x(r, "BezierCurveShape"), r;
}();
function S(r, t, i) {
  var e = r.cpx2, f = r.cpy2;
  return e != null || f != null ? [
    (i ? b : z)(r.x1, r.cpx1, r.cpx2, r.x2, t),
    (i ? b : z)(r.y1, r.cpy1, r.cpy2, r.y2, t)
  ] : [
    (i ? A : C)(r.x1, r.cpx1, r.x2, t),
    (i ? A : C)(r.y1, r.cpy1, r.y2, t)
  ];
}
x(S, "someVectorAt");
var w = function(r) {
  B(t, r);
  function t(i) {
    return r.call(this, i) || this;
  }
  return x(t, "BezierCurve"), t.prototype.getDefaultStyle = function() {
    return {
      stroke: "#000",
      fill: null
    };
  }, t.prototype.getDefaultShape = function() {
    return new k();
  }, t.prototype.buildPath = function(i, e) {
    var f = e.x1, a = e.y1, o = e.x2, n = e.y2, v = e.cpx1, y = e.cpy1, p = e.cpx2, l = e.cpy2, c = e.percent;
    c !== 0 && (i.moveTo(f, a), p == null || l == null ? (c < 1 && (d(f, v, o, c, u), v = u[1], o = u[2], d(a, y, n, c, u), y = u[1], n = u[2]), i.quadraticCurveTo(v, y, o, n)) : (c < 1 && (m(f, v, p, o, c, u), v = u[1], p = u[2], o = u[3], m(a, y, l, n, c, u), y = u[1], l = u[2], n = u[3]), i.bezierCurveTo(v, y, p, l, o, n)));
  }, t.prototype.pointAt = function(i) {
    return S(this.shape, i, !1);
  }, t.prototype.tangentAt = function(i) {
    var e = S(this.shape, i, !0);
    return P(e, e);
  }, t;
}(D);
w.prototype.type = "bezier-curve";
export {
  k as BezierCurveShape,
  w as default
};
