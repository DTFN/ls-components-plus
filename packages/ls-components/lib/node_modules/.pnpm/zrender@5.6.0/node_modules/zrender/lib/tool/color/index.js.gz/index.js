var O = Object.defineProperty;
var a = (n, e) => O(n, "name", { value: e, configurable: !0 });
import R from "../../core/LRU/index.js";
import { isString as T, isGradientObject as j, extend as B, map as G } from "../../core/util/index.js";
var I = {
  transparent: [0, 0, 0, 0],
  aliceblue: [240, 248, 255, 1],
  antiquewhite: [250, 235, 215, 1],
  aqua: [0, 255, 255, 1],
  aquamarine: [127, 255, 212, 1],
  azure: [240, 255, 255, 1],
  beige: [245, 245, 220, 1],
  bisque: [255, 228, 196, 1],
  black: [0, 0, 0, 1],
  blanchedalmond: [255, 235, 205, 1],
  blue: [0, 0, 255, 1],
  blueviolet: [138, 43, 226, 1],
  brown: [165, 42, 42, 1],
  burlywood: [222, 184, 135, 1],
  cadetblue: [95, 158, 160, 1],
  chartreuse: [127, 255, 0, 1],
  chocolate: [210, 105, 30, 1],
  coral: [255, 127, 80, 1],
  cornflowerblue: [100, 149, 237, 1],
  cornsilk: [255, 248, 220, 1],
  crimson: [220, 20, 60, 1],
  cyan: [0, 255, 255, 1],
  darkblue: [0, 0, 139, 1],
  darkcyan: [0, 139, 139, 1],
  darkgoldenrod: [184, 134, 11, 1],
  darkgray: [169, 169, 169, 1],
  darkgreen: [0, 100, 0, 1],
  darkgrey: [169, 169, 169, 1],
  darkkhaki: [189, 183, 107, 1],
  darkmagenta: [139, 0, 139, 1],
  darkolivegreen: [85, 107, 47, 1],
  darkorange: [255, 140, 0, 1],
  darkorchid: [153, 50, 204, 1],
  darkred: [139, 0, 0, 1],
  darksalmon: [233, 150, 122, 1],
  darkseagreen: [143, 188, 143, 1],
  darkslateblue: [72, 61, 139, 1],
  darkslategray: [47, 79, 79, 1],
  darkslategrey: [47, 79, 79, 1],
  darkturquoise: [0, 206, 209, 1],
  darkviolet: [148, 0, 211, 1],
  deeppink: [255, 20, 147, 1],
  deepskyblue: [0, 191, 255, 1],
  dimgray: [105, 105, 105, 1],
  dimgrey: [105, 105, 105, 1],
  dodgerblue: [30, 144, 255, 1],
  firebrick: [178, 34, 34, 1],
  floralwhite: [255, 250, 240, 1],
  forestgreen: [34, 139, 34, 1],
  fuchsia: [255, 0, 255, 1],
  gainsboro: [220, 220, 220, 1],
  ghostwhite: [248, 248, 255, 1],
  gold: [255, 215, 0, 1],
  goldenrod: [218, 165, 32, 1],
  gray: [128, 128, 128, 1],
  green: [0, 128, 0, 1],
  greenyellow: [173, 255, 47, 1],
  grey: [128, 128, 128, 1],
  honeydew: [240, 255, 240, 1],
  hotpink: [255, 105, 180, 1],
  indianred: [205, 92, 92, 1],
  indigo: [75, 0, 130, 1],
  ivory: [255, 255, 240, 1],
  khaki: [240, 230, 140, 1],
  lavender: [230, 230, 250, 1],
  lavenderblush: [255, 240, 245, 1],
  lawngreen: [124, 252, 0, 1],
  lemonchiffon: [255, 250, 205, 1],
  lightblue: [173, 216, 230, 1],
  lightcoral: [240, 128, 128, 1],
  lightcyan: [224, 255, 255, 1],
  lightgoldenrodyellow: [250, 250, 210, 1],
  lightgray: [211, 211, 211, 1],
  lightgreen: [144, 238, 144, 1],
  lightgrey: [211, 211, 211, 1],
  lightpink: [255, 182, 193, 1],
  lightsalmon: [255, 160, 122, 1],
  lightseagreen: [32, 178, 170, 1],
  lightskyblue: [135, 206, 250, 1],
  lightslategray: [119, 136, 153, 1],
  lightslategrey: [119, 136, 153, 1],
  lightsteelblue: [176, 196, 222, 1],
  lightyellow: [255, 255, 224, 1],
  lime: [0, 255, 0, 1],
  limegreen: [50, 205, 50, 1],
  linen: [250, 240, 230, 1],
  magenta: [255, 0, 255, 1],
  maroon: [128, 0, 0, 1],
  mediumaquamarine: [102, 205, 170, 1],
  mediumblue: [0, 0, 205, 1],
  mediumorchid: [186, 85, 211, 1],
  mediumpurple: [147, 112, 219, 1],
  mediumseagreen: [60, 179, 113, 1],
  mediumslateblue: [123, 104, 238, 1],
  mediumspringgreen: [0, 250, 154, 1],
  mediumturquoise: [72, 209, 204, 1],
  mediumvioletred: [199, 21, 133, 1],
  midnightblue: [25, 25, 112, 1],
  mintcream: [245, 255, 250, 1],
  mistyrose: [255, 228, 225, 1],
  moccasin: [255, 228, 181, 1],
  navajowhite: [255, 222, 173, 1],
  navy: [0, 0, 128, 1],
  oldlace: [253, 245, 230, 1],
  olive: [128, 128, 0, 1],
  olivedrab: [107, 142, 35, 1],
  orange: [255, 165, 0, 1],
  orangered: [255, 69, 0, 1],
  orchid: [218, 112, 214, 1],
  palegoldenrod: [238, 232, 170, 1],
  palegreen: [152, 251, 152, 1],
  paleturquoise: [175, 238, 238, 1],
  palevioletred: [219, 112, 147, 1],
  papayawhip: [255, 239, 213, 1],
  peachpuff: [255, 218, 185, 1],
  peru: [205, 133, 63, 1],
  pink: [255, 192, 203, 1],
  plum: [221, 160, 221, 1],
  powderblue: [176, 224, 230, 1],
  purple: [128, 0, 128, 1],
  red: [255, 0, 0, 1],
  rosybrown: [188, 143, 143, 1],
  royalblue: [65, 105, 225, 1],
  saddlebrown: [139, 69, 19, 1],
  salmon: [250, 128, 114, 1],
  sandybrown: [244, 164, 96, 1],
  seagreen: [46, 139, 87, 1],
  seashell: [255, 245, 238, 1],
  sienna: [160, 82, 45, 1],
  silver: [192, 192, 192, 1],
  skyblue: [135, 206, 235, 1],
  slateblue: [106, 90, 205, 1],
  slategray: [112, 128, 144, 1],
  slategrey: [112, 128, 144, 1],
  snow: [255, 250, 250, 1],
  springgreen: [0, 255, 127, 1],
  steelblue: [70, 130, 180, 1],
  tan: [210, 180, 140, 1],
  teal: [0, 128, 128, 1],
  thistle: [216, 191, 216, 1],
  tomato: [255, 99, 71, 1],
  turquoise: [64, 224, 208, 1],
  violet: [238, 130, 238, 1],
  wheat: [245, 222, 179, 1],
  white: [255, 255, 255, 1],
  whitesmoke: [245, 245, 245, 1],
  yellow: [255, 255, 0, 1],
  yellowgreen: [154, 205, 50, 1]
};
function o(n) {
  return n = Math.round(n), n < 0 ? 0 : n > 255 ? 255 : n;
}
a(o, "clampCssByte");
function w(n) {
  return n < 0 ? 0 : n > 1 ? 1 : n;
}
a(w, "clampCssFloat");
function y(n) {
  var e = n;
  return e.length && e.charAt(e.length - 1) === "%" ? o(parseFloat(e) / 100 * 255) : o(parseInt(e, 10));
}
a(y, "parseCssInt");
function c(n) {
  var e = n;
  return e.length && e.charAt(e.length - 1) === "%" ? w(parseFloat(e) / 100) : w(parseFloat(e));
}
a(c, "parseCssFloat");
function m(n, e, t) {
  return t < 0 ? t += 1 : t > 1 && (t -= 1), t * 6 < 1 ? n + (e - n) * t * 6 : t * 2 < 1 ? e : t * 3 < 2 ? n + (e - n) * (2 / 3 - t) * 6 : n;
}
a(m, "cssHueToRgb");
function v(n, e, t) {
  return n + (e - n) * t;
}
a(v, "lerpNumber");
function s(n, e, t, l, u) {
  return n[0] = e, n[1] = t, n[2] = l, n[3] = u, n;
}
a(s, "setRgba");
function x(n, e) {
  return n[0] = e[0], n[1] = e[1], n[2] = e[2], n[3] = e[3], n;
}
a(x, "copyRgba");
var L = new R(20), k = null;
function h(n, e) {
  k && x(k, e), k = L.put(n, k || e.slice());
}
a(h, "putToCache");
function p(n, e) {
  if (n) {
    e = e || [];
    var t = L.get(n);
    if (t)
      return x(e, t);
    n = n + "";
    var l = n.replace(/ /g, "").toLowerCase();
    if (l in I)
      return x(e, I[l]), h(n, e), e;
    var u = l.length;
    if (l.charAt(0) === "#") {
      if (u === 4 || u === 5) {
        var i = parseInt(l.slice(1, 4), 16);
        if (!(i >= 0 && i <= 4095)) {
          s(e, 0, 0, 0, 1);
          return;
        }
        return s(e, (i & 3840) >> 4 | (i & 3840) >> 8, i & 240 | (i & 240) >> 4, i & 15 | (i & 15) << 4, u === 5 ? parseInt(l.slice(4), 16) / 15 : 1), h(n, e), e;
      } else if (u === 7 || u === 9) {
        var i = parseInt(l.slice(1, 7), 16);
        if (!(i >= 0 && i <= 16777215)) {
          s(e, 0, 0, 0, 1);
          return;
        }
        return s(e, (i & 16711680) >> 16, (i & 65280) >> 8, i & 255, u === 9 ? parseInt(l.slice(7), 16) / 255 : 1), h(n, e), e;
      }
      return;
    }
    var f = l.indexOf("("), d = l.indexOf(")");
    if (f !== -1 && d + 1 === u) {
      var g = l.substr(0, f), r = l.substr(f + 1, d - (f + 1)).split(","), b = 1;
      switch (g) {
        case "rgba":
          if (r.length !== 4)
            return r.length === 3 ? s(e, +r[0], +r[1], +r[2], 1) : s(e, 0, 0, 0, 1);
          b = c(r.pop());
        case "rgb":
          if (r.length >= 3)
            return s(e, y(r[0]), y(r[1]), y(r[2]), r.length === 3 ? b : c(r[3])), h(n, e), e;
          s(e, 0, 0, 0, 1);
          return;
        case "hsla":
          if (r.length !== 4) {
            s(e, 0, 0, 0, 1);
            return;
          }
          return r[3] = c(r[3]), q(r, e), h(n, e), e;
        case "hsl":
          if (r.length !== 3) {
            s(e, 0, 0, 0, 1);
            return;
          }
          return q(r, e), h(n, e), e;
        default:
          return;
      }
    }
    s(e, 0, 0, 0, 1);
  }
}
a(p, "parse");
function q(n, e) {
  var t = (parseFloat(n[0]) % 360 + 360) % 360 / 360, l = c(n[1]), u = c(n[2]), i = u <= 0.5 ? u * (l + 1) : u + l - u * l, f = u * 2 - i;
  return e = e || [], s(e, o(m(f, i, t + 1 / 3) * 255), o(m(f, i, t) * 255), o(m(f, i, t - 1 / 3) * 255), 1), n.length === 4 && (e[3] = n[3]), e;
}
a(q, "hsla2rgba");
function C(n, e) {
  var t = p(n);
  if (t) {
    for (var l = 0; l < 3; l++)
      t[l] = t[l] * (1 - e) | 0, t[l] > 255 ? t[l] = 255 : t[l] < 0 && (t[l] = 0);
    return M(t, t.length === 4 ? "rgba" : "rgb");
  }
}
a(C, "lift");
function D(n, e, t) {
  if (!(!(e && e.length) || !(n >= 0 && n <= 1))) {
    var l = n * (e.length - 1), u = Math.floor(l), i = Math.ceil(l), f = p(e[u]), d = p(e[i]), g = l - u, r = M([
      o(v(f[0], d[0], g)),
      o(v(f[1], d[1], g)),
      o(v(f[2], d[2], g)),
      w(v(f[3], d[3], g))
    ], "rgba");
    return t ? {
      color: r,
      leftIndex: u,
      rightIndex: i,
      value: l
    } : r;
  }
}
a(D, "lerp");
function M(n, e) {
  if (!(!n || !n.length)) {
    var t = n[0] + "," + n[1] + "," + n[2];
    return (e === "rgba" || e === "hsva" || e === "hsla") && (t += "," + n[3]), e + "(" + t + ")";
  }
}
a(M, "stringify");
function E(n, e) {
  var t = p(n);
  return t ? (0.299 * t[0] + 0.587 * t[1] + 0.114 * t[2]) * t[3] / 255 + (1 - t[3]) * e : 0;
}
a(E, "lum");
var F = new R(100);
function J(n) {
  if (T(n)) {
    var e = F.get(n);
    return e || (e = C(n, -0.1), F.put(n, e)), e;
  } else if (j(n)) {
    var t = B({}, n);
    return t.colorStops = G(n.colorStops, function(l) {
      return {
        offset: l.offset,
        color: C(l.color, -0.1)
      };
    }), t;
  }
  return n;
}
a(J, "liftColor");
export {
  D as lerp,
  C as lift,
  J as liftColor,
  E as lum,
  p as parse,
  M as stringify
};
