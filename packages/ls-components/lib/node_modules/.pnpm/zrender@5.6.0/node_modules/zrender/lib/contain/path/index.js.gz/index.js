var U = Object.defineProperty;
var C = (b, o) => U(b, "name", { value: o, configurable: !0 });
import V from "../../core/PathProxy/index.js";
import { containStroke as E } from "../line/index.js";
import { containStroke as X } from "../cubic/index.js";
import { containStroke as Y } from "../quadratic/index.js";
import { containStroke as i } from "../arc/index.js";
import { cubicRootAt as w, cubicExtrema as F, quadraticRootAt as T, quadraticAt as j, cubicAt as z, quadraticExtremum as d } from "../../core/curve/index.js";
import S from "../windingLine/index.js";
var L = V.CMD, D = Math.PI * 2, h = 1e-4;
function A(b, o) {
  return Math.abs(b - o) < h;
}
C(A, "isAroundEqual");
var k = [-1, -1, -1], q = [-1, -1];
function W() {
  var b = q[0];
  q[0] = q[1], q[1] = b;
}
C(W, "swapExtrema");
function _(b, o, M, f, u, r, I, e, n, v) {
  if (v > o && v > f && v > r && v > e || v < o && v < f && v < r && v < e)
    return 0;
  var t = w(o, f, r, e, v, k);
  if (t === 0)
    return 0;
  for (var c = 0, m = -1, s = void 0, a = void 0, P = 0; P < t; P++) {
    var R = k[P], p = R === 0 || R === 1 ? 0.5 : 1, Q = z(b, M, u, I, R);
    Q < n || (m < 0 && (m = F(o, f, r, e, q), q[1] < q[0] && m > 1 && W(), s = z(o, f, r, e, q[0]), m > 1 && (a = z(o, f, r, e, q[1]))), m === 2 ? R < q[0] ? c += s < o ? p : -p : R < q[1] ? c += a < s ? p : -p : c += e < a ? p : -p : R < q[0] ? c += s < o ? p : -p : c += e < s ? p : -p);
  }
  return c;
}
C(_, "windingCubic");
function l(b, o, M, f, u, r, I, e) {
  if (e > o && e > f && e > r || e < o && e < f && e < r)
    return 0;
  var n = T(o, f, r, e, k);
  if (n === 0)
    return 0;
  var v = d(o, f, r);
  if (v >= 0 && v <= 1) {
    for (var t = 0, c = j(o, f, r, v), m = 0; m < n; m++) {
      var s = k[m] === 0 || k[m] === 1 ? 0.5 : 1, a = j(b, M, u, k[m]);
      a < I || (k[m] < v ? t += c < o ? s : -s : t += r < c ? s : -s);
    }
    return t;
  } else {
    var s = k[0] === 0 || k[0] === 1 ? 0.5 : 1, a = j(b, M, u, k[0]);
    return a < I ? 0 : r < o ? s : -s;
  }
}
C(l, "windingQuadratic");
function g(b, o, M, f, u, r, I, e) {
  if (e -= o, e > M || e < -M)
    return 0;
  var n = Math.sqrt(M * M - e * e);
  k[0] = -n, k[1] = n;
  var v = Math.abs(f - u);
  if (v < 1e-4)
    return 0;
  if (v >= D - 1e-4) {
    f = 0, u = D;
    var t = r ? 1 : -1;
    return I >= k[0] + b && I <= k[1] + b ? t : 0;
  }
  if (f > u) {
    var c = f;
    f = u, u = c;
  }
  f < 0 && (f += D, u += D);
  for (var m = 0, s = 0; s < 2; s++) {
    var a = k[s];
    if (a + b > I) {
      var P = Math.atan2(e, a), t = r ? 1 : -1;
      P < 0 && (P = D + P), (P >= f && P <= u || P + D >= f && P + D <= u) && (P > Math.PI / 2 && P < Math.PI * 1.5 && (t = -t), m += t);
    }
  }
  return m;
}
C(g, "windingArc");
function H(b, o, M, f, u) {
  for (var r = b.data, I = b.len(), e = 0, n = 0, v = 0, t = 0, c = 0, m, s, a = 0; a < I; ) {
    var P = r[a++], R = a === 1;
    switch (P === L.M && a > 1 && (M || (e += S(n, v, t, c, f, u))), R && (n = r[a], v = r[a + 1], t = n, c = v), P) {
      case L.M:
        t = r[a++], c = r[a++], n = t, v = c;
        break;
      case L.L:
        if (M) {
          if (E(n, v, r[a], r[a + 1], o, f, u))
            return !0;
        } else
          e += S(n, v, r[a], r[a + 1], f, u) || 0;
        n = r[a++], v = r[a++];
        break;
      case L.C:
        if (M) {
          if (X(n, v, r[a++], r[a++], r[a++], r[a++], r[a], r[a + 1], o, f, u))
            return !0;
        } else
          e += _(n, v, r[a++], r[a++], r[a++], r[a++], r[a], r[a + 1], f, u) || 0;
        n = r[a++], v = r[a++];
        break;
      case L.Q:
        if (M) {
          if (Y(n, v, r[a++], r[a++], r[a], r[a + 1], o, f, u))
            return !0;
        } else
          e += l(n, v, r[a++], r[a++], r[a], r[a + 1], f, u) || 0;
        n = r[a++], v = r[a++];
        break;
      case L.A:
        var p = r[a++], Q = r[a++], Z = r[a++], N = r[a++], $ = r[a++], O = r[a++];
        a += 1;
        var B = !!(1 - r[a++]);
        m = Math.cos($) * Z + p, s = Math.sin($) * N + Q, R ? (t = m, c = s) : e += S(n, v, m, s, f, u);
        var G = (f - p) * N / Z + p;
        if (M) {
          if (i(p, Q, N, $, $ + O, B, o, G, u))
            return !0;
        } else
          e += g(p, Q, N, $, $ + O, B, G, u);
        n = Math.cos($ + O) * Z + p, v = Math.sin($ + O) * N + Q;
        break;
      case L.R:
        t = n = r[a++], c = v = r[a++];
        var J = r[a++], K = r[a++];
        if (m = t + J, s = c + K, M) {
          if (E(t, c, m, c, o, f, u) || E(m, c, m, s, o, f, u) || E(m, s, t, s, o, f, u) || E(t, s, t, c, o, f, u))
            return !0;
        } else
          e += S(m, c, m, s, f, u), e += S(t, s, t, c, f, u);
        break;
      case L.Z:
        if (M) {
          if (E(n, v, t, c, o, f, u))
            return !0;
        } else
          e += S(n, v, t, c, f, u);
        n = t, v = c;
        break;
    }
  }
  return !M && !A(v, c) && (e += S(n, v, t, c, f, u) || 0), e !== 0;
}
C(H, "containPath");
function ur(b, o, M) {
  return H(b, 0, !1, o, M);
}
C(ur, "contain");
function tr(b, o, M, f) {
  return H(b, o, !0, M, f);
}
C(tr, "containStroke");
export {
  ur as contain,
  tr as containStroke
};
