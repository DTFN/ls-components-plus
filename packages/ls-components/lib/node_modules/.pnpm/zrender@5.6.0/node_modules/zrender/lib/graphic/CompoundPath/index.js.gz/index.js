var s = Object.defineProperty;
var p = (r, e) => s(r, "name", { value: e, configurable: !0 });
import { __extends as u } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import n from "../Path/index.js";
var i = function(r) {
  u(e, r);
  function e() {
    var t = r !== null && r.apply(this, arguments) || this;
    return t.type = "compound", t;
  }
  return p(e, "CompoundPath"), e.prototype._updatePathDirty = function() {
    for (var t = this.shape.paths, h = this.shapeChanged(), a = 0; a < t.length; a++)
      h = h || t[a].shapeChanged();
    h && this.dirtyShape();
  }, e.prototype.beforeBrush = function() {
    this._updatePathDirty();
    for (var t = this.shape.paths || [], h = this.getGlobalScale(), a = 0; a < t.length; a++)
      t[a].path || t[a].createPathProxy(), t[a].path.setScale(h[0], h[1], t[a].segmentIgnoreThreshold);
  }, e.prototype.buildPath = function(t, h) {
    for (var a = h.paths || [], o = 0; o < a.length; o++)
      a[o].buildPath(t, a[o].shape, !0);
  }, e.prototype.afterBrush = function() {
    for (var t = this.shape.paths || [], h = 0; h < t.length; h++)
      t[h].pathUpdated();
  }, e.prototype.getBoundingRect = function() {
    return this._updatePathDirty.call(this), n.prototype.getBoundingRect.call(this);
  }, e;
}(n);
const c = i;
export {
  c as default
};
