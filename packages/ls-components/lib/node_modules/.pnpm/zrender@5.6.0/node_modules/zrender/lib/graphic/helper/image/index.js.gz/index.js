var u = Object.defineProperty;
var r = (t, o) => u(t, "name", { value: o, configurable: !0 });
import d from "../../../core/LRU/index.js";
import { platformApi as _ } from "../../../core/platform/index.js";
var l = new d(50);
function b(t) {
  if (typeof t == "string") {
    var o = l.get(t);
    return o && o.image;
  } else
    return t;
}
r(b, "findExistImage");
function c(t, o, n, i, h) {
  if (t)
    if (typeof t == "string") {
      if (o && o.__zrImageSrc === t || !n)
        return o;
      var f = l.get(t), s = { hostEl: n, cb: i, cbPayload: h };
      return f ? (o = f.image, !a(o) && f.pending.push(s)) : (o = _.loadImage(t, e, e), o.__zrImageSrc = t, l.put(t, o.__cachedImgObj = {
        image: o,
        pending: [s]
      })), o;
    } else
      return t;
  else return o;
}
r(c, "createOrUpdateImage");
function e() {
  var t = this.__cachedImgObj;
  this.onload = this.onerror = this.__cachedImgObj = null;
  for (var o = 0; o < t.pending.length; o++) {
    var n = t.pending[o], i = n.cb;
    i && i(this, n.cbPayload), n.hostEl.dirty();
  }
  t.pending.length = 0;
}
r(e, "imageOnLoad");
function a(t) {
  return t && t.width && t.height;
}
r(a, "isImageReady");
export {
  c as createOrUpdateImage,
  b as findExistImage,
  a as isImageReady
};
