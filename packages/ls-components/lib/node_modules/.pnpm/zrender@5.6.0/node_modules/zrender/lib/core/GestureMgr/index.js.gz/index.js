var g = Object.defineProperty;
var u = (r, t) => g(r, "name", { value: t, configurable: !0 });
import { clientToLocal as v } from "../event/index.js";
var d = function() {
  function r() {
    this._track = [];
  }
  return u(r, "GestureMgr"), r.prototype.recognize = function(t, n, e) {
    return this._doTrack(t, n, e), this._recognize(t);
  }, r.prototype.clear = function() {
    return this._track.length = 0, this;
  }, r.prototype._doTrack = function(t, n, e) {
    var o = t.touches;
    if (o) {
      for (var c = {
        points: [],
        touches: [],
        target: n,
        event: t
      }, i = 0, p = o.length; i < p; i++) {
        var a = o[i], s = v(e, a, {});
        c.points.push([s.zrX, s.zrY]), c.touches.push(a);
      }
      this._track.push(c);
    }
  }, r.prototype._recognize = function(t) {
    for (var n in h)
      if (h.hasOwnProperty(n)) {
        var e = h[n](this._track, t);
        if (e)
          return e;
      }
  }, r;
}();
function f(r) {
  var t = r[1][0] - r[0][0], n = r[1][1] - r[0][1];
  return Math.sqrt(t * t + n * n);
}
u(f, "dist");
function _(r) {
  return [
    (r[0][0] + r[1][0]) / 2,
    (r[0][1] + r[1][1]) / 2
  ];
}
u(_, "center");
var h = {
  pinch: /* @__PURE__ */ u(function(r, t) {
    var n = r.length;
    if (n) {
      var e = (r[n - 1] || {}).points, o = (r[n - 2] || {}).points || e;
      if (o && o.length > 1 && e && e.length > 1) {
        var c = f(e) / f(o);
        !isFinite(c) && (c = 1), t.pinchScale = c;
        var i = _(e);
        return t.pinchX = i[0], t.pinchY = i[1], {
          type: "pinch",
          target: r[0].target,
          event: t
        };
      }
    }
  }, "pinch")
};
export {
  d as GestureMgr
};
