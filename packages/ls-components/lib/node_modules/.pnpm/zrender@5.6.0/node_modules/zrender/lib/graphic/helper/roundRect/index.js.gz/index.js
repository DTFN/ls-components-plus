var M = Object.defineProperty;
var I = (t, P) => M(t, "name", { value: P, configurable: !0 });
function T(t, P) {
  var o = P.x, v = P.y, l = P.width, h = P.height, f = P.r, r, i, a, e;
  l < 0 && (o = o + l, l = -l), h < 0 && (v = v + h, h = -h), typeof f == "number" ? r = i = a = e = f : f instanceof Array ? f.length === 1 ? r = i = a = e = f[0] : f.length === 2 ? (r = a = f[0], i = e = f[1]) : f.length === 3 ? (r = f[0], i = e = f[1], a = f[2]) : (r = f[0], i = f[1], a = f[2], e = f[3]) : r = i = a = e = 0;
  var n;
  r + i > l && (n = r + i, r *= l / n, i *= l / n), a + e > l && (n = a + e, a *= l / n, e *= l / n), i + a > h && (n = i + a, i *= h / n, a *= h / n), r + e > h && (n = r + e, r *= h / n, e *= h / n), t.moveTo(o + r, v), t.lineTo(o + l - i, v), i !== 0 && t.arc(o + l - i, v + i, i, -Math.PI / 2, 0), t.lineTo(o + l, v + h - a), a !== 0 && t.arc(o + l - a, v + h - a, a, 0, Math.PI / 2), t.lineTo(o + e, v + h), e !== 0 && t.arc(o + e, v + h - e, e, Math.PI / 2, Math.PI), t.lineTo(o, v + r), r !== 0 && t.arc(o + r, v + r, r, Math.PI, Math.PI * 1.5);
}
I(T, "buildPath");
export {
  T as buildPath
};
