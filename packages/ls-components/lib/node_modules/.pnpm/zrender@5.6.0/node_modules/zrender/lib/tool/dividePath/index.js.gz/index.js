var I = Object.defineProperty;
var c = (r, a) => I(r, "name", { value: a, configurable: !0 });
import { fromPoints as T } from "../../core/bbox/index.js";
import O from "../../core/BoundingRect/index.js";
import m from "../../core/Point/index.js";
import { map as k } from "../../core/util/index.js";
import B from "../../graphic/shape/Polygon/index.js";
import C from "../../graphic/shape/Rect/index.js";
import p from "../../graphic/shape/Sector/index.js";
import { pathToPolygons as G } from "../convertPath/index.js";
import { clonePath as H } from "../path/index.js";
function q(r, a, v) {
  var n = r[a], e = r[1 - a], t = Math.abs(n / e), d = Math.ceil(Math.sqrt(t * v)), l = Math.floor(v / d);
  l === 0 && (l = 1, d = v);
  for (var s = [], i = 0; i < d; i++)
    s.push(l);
  var f = d * l, h = v - f;
  if (h > 0)
    for (var i = 0; i < h; i++)
      s[i % d] += 1;
  return s;
}
c(q, "getDividingGrids");
function D(r, a, v) {
  for (var n = r.r0, e = r.r, t = r.startAngle, d = r.endAngle, l = Math.abs(d - t), s = l * e, i = e - n, f = s > Math.abs(i), h = q([s, i], f ? 0 : 1, a), g = (f ? l : i) / h.length, u = 0; u < h.length; u++)
    for (var x = (f ? i : l) / h[u], o = 0; o < h[u]; o++) {
      var y = {};
      f ? (y.startAngle = t + g * u, y.endAngle = t + g * (u + 1), y.r0 = n + x * o, y.r = n + x * (o + 1)) : (y.startAngle = t + x * o, y.endAngle = t + x * (o + 1), y.r0 = n + g * u, y.r = n + g * (u + 1)), y.clockwise = r.clockwise, y.cx = r.cx, y.cy = r.cy, v.push(y);
    }
}
c(D, "divideSector");
function U(r, a, v) {
  for (var n = r.width, e = r.height, t = n > e, d = q([n, e], t ? 0 : 1, a), l = t ? "width" : "height", s = t ? "height" : "width", i = t ? "x" : "y", f = t ? "y" : "x", h = r[l] / d.length, g = 0; g < d.length; g++)
    for (var u = r[s] / d[g], x = 0; x < d[g]; x++) {
      var o = {};
      o[i] = g * h, o[f] = x * u, o[l] = h, o[s] = u, o.x += r.x, o.y += r.y, v.push(o);
    }
}
c(U, "divideRect");
function j(r, a, v, n) {
  return r * n - v * a;
}
c(j, "crossProduct2d");
function E(r, a, v, n, e, t, d, l) {
  var s = v - r, i = n - a, f = d - e, h = l - t, g = j(f, h, s, i);
  if (Math.abs(g) < 1e-6)
    return null;
  var u = r - e, x = a - t, o = j(u, x, f, h) / g;
  return o < 0 || o > 1 ? null : new m(o * s + r, o * i + a);
}
c(E, "lineLineIntersect");
function F(r, a, v) {
  var n = new m();
  m.sub(n, v, a), n.normalize();
  var e = new m();
  m.sub(e, r, a);
  var t = e.dot(n);
  return t;
}
c(F, "projPtOnLine");
function M(r, a) {
  var v = r[r.length - 1];
  v && v[0] === a[0] && v[1] === a[1] || r.push(a);
}
c(M, "addToPoly");
function J(r, a, v) {
  for (var n = r.length, e = [], t = 0; t < n; t++) {
    var d = r[t], l = r[(t + 1) % n], s = E(d[0], d[1], l[0], l[1], a.x, a.y, v.x, v.y);
    s && e.push({
      projPt: F(s, a, v),
      pt: s,
      idx: t
    });
  }
  if (e.length < 2)
    return [{ points: r }, { points: r }];
  e.sort(function(y, P) {
    return y.projPt - P.projPt;
  });
  var i = e[0], f = e[e.length - 1];
  if (f.idx < i.idx) {
    var h = i;
    i = f, f = h;
  }
  for (var g = [i.pt.x, i.pt.y], u = [f.pt.x, f.pt.y], x = [g], o = [u], t = i.idx + 1; t <= f.idx; t++)
    M(x, r[t].slice());
  M(x, u), M(x, g);
  for (var t = f.idx + 1; t <= i.idx + n; t++)
    M(o, r[t % n].slice());
  return M(o, g), M(o, u), [{
    points: x
  }, {
    points: o
  }];
}
c(J, "splitPolygonByLine");
function L(r) {
  var a = r.points, v = [], n = [];
  T(a, v, n);
  var e = new O(v[0], v[1], n[0] - v[0], n[1] - v[1]), t = e.width, d = e.height, l = e.x, s = e.y, i = new m(), f = new m();
  return t > d ? (i.x = f.x = l + t / 2, i.y = s, f.y = s + d) : (i.y = f.y = s + d / 2, i.x = l, f.x = l + t), J(a, i, f);
}
c(L, "binaryDividePolygon");
function A(r, a, v, n) {
  if (v === 1)
    n.push(a);
  else {
    var e = Math.floor(v / 2), t = r(a);
    A(r, t[0], e, n), A(r, t[1], v - e, n);
  }
  return n;
}
c(A, "binaryDivideRecursive");
function K(r, a) {
  for (var v = [], n = 0; n < a; n++)
    v.push(H(r));
  return v;
}
c(K, "clone");
function N(r, a) {
  a.setStyle(r.style), a.z = r.z, a.z2 = r.z2, a.zlevel = r.zlevel;
}
c(N, "copyPathProps");
function Q(r) {
  for (var a = [], v = 0; v < r.length; )
    a.push([r[v++], r[v++]]);
  return a;
}
c(Q, "polygonConvert");
function ar(r, a) {
  var v = [], n = r.shape, e;
  switch (r.type) {
    case "rect":
      U(n, a, v), e = C;
      break;
    case "sector":
      D(n, a, v), e = p;
      break;
    case "circle":
      D({
        r0: 0,
        r: n.r,
        startAngle: 0,
        endAngle: Math.PI * 2,
        cx: n.cx,
        cy: n.cy
      }, a, v), e = p;
      break;
    default:
      var t = r.getComputedTransform(), d = t ? Math.sqrt(Math.max(t[0] * t[0] + t[1] * t[1], t[2] * t[2] + t[3] * t[3])) : 1, l = k(G(r.getUpdatedPathProxy(), d), function(P) {
        return Q(P);
      }), s = l.length;
      if (s === 0)
        A(L, {
          points: l[0]
        }, a, v);
      else if (s === a)
        for (var i = 0; i < s; i++)
          v.push({
            points: l[i]
          });
      else {
        var f = 0, h = k(l, function(P) {
          var b = [], z = [];
          T(P, b, z);
          var R = (z[1] - b[1]) * (z[0] - b[0]);
          return f += R, { poly: P, area: R };
        });
        h.sort(function(P, b) {
          return b.area - P.area;
        });
        for (var g = a, i = 0; i < s; i++) {
          var u = h[i];
          if (g <= 0)
            break;
          var x = i === s - 1 ? g : Math.ceil(u.area / f * a);
          x < 0 || (A(L, {
            points: u.poly
          }, x, v), g -= x);
        }
      }
      e = B;
      break;
  }
  if (!e)
    return K(r, a);
  for (var o = [], i = 0; i < v.length; i++) {
    var y = new e();
    y.setShape(v[i]), N(r, y), o.push(y);
  }
  return o;
}
c(ar, "split");
export {
  K as clone,
  ar as split
};
