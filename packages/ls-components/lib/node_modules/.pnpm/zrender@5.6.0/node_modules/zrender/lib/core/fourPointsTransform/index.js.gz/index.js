var O = Object.defineProperty;
var i = (v, n) => O(v, "name", { value: n, configurable: !0 });
var q = Math.log(2);
function A(v, n, h, l, m, u) {
  var a = l + "-" + m, f = v.length;
  if (u.hasOwnProperty(a))
    return u[a];
  if (n === 1) {
    var g = Math.round(Math.log((1 << f) - 1 & ~m) / q);
    return v[h][g];
  }
  for (var R = l | 1 << h, b = h + 1; l & 1 << b; )
    b++;
  for (var p = 0, y = 0, K = 0; y < f; y++) {
    var N = 1 << y;
    N & m || (p += (K % 2 ? -1 : 1) * v[h][y] * A(v, n - 1, b, R, m | N, u), K++);
  }
  return u[a] = p, p;
}
i(A, "determinant");
function z(v, n) {
  var h = [
    [v[0], v[1], 1, 0, 0, 0, -n[0] * v[0], -n[0] * v[1]],
    [0, 0, 0, v[0], v[1], 1, -n[1] * v[0], -n[1] * v[1]],
    [v[2], v[3], 1, 0, 0, 0, -n[2] * v[2], -n[2] * v[3]],
    [0, 0, 0, v[2], v[3], 1, -n[3] * v[2], -n[3] * v[3]],
    [v[4], v[5], 1, 0, 0, 0, -n[4] * v[4], -n[4] * v[5]],
    [0, 0, 0, v[4], v[5], 1, -n[5] * v[4], -n[5] * v[5]],
    [v[6], v[7], 1, 0, 0, 0, -n[6] * v[6], -n[6] * v[7]],
    [0, 0, 0, v[6], v[7], 1, -n[7] * v[6], -n[7] * v[7]]
  ], l = {}, m = A(h, 8, 0, 0, 0, l);
  if (m !== 0) {
    for (var u = [], a = 0; a < 8; a++)
      for (var f = 0; f < 8; f++)
        u[f] == null && (u[f] = 0), u[f] += ((a + f) % 2 ? -1 : 1) * A(h, 7, a === 0 ? 1 : 0, 1 << a, 1 << f, l) / m * n[a];
    return function(g, R, b) {
      var p = R * u[6] + b * u[7] + 1;
      g[0] = (R * u[0] + b * u[1] + u[2]) / p, g[1] = (R * u[3] + b * u[4] + u[5]) / p;
    };
  }
}
i(z, "buildTransformer");
export {
  z as buildTransformer
};
