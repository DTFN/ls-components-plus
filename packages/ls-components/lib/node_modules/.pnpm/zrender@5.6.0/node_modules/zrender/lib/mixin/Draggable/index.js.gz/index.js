var f = Object.defineProperty;
var h = (r, t) => f(r, "name", { value: t, configurable: !0 });
var n = function() {
  function r(t, a) {
    this.target = t, this.topTarget = a && a.topTarget;
  }
  return h(r, "Param"), r;
}(), v = function() {
  function r(t) {
    this.handler = t, t.on("mousedown", this._dragStart, this), t.on("mousemove", this._drag, this), t.on("mouseup", this._dragEnd, this);
  }
  return h(r, "Draggable"), r.prototype._dragStart = function(t) {
    for (var a = t.target; a && !a.draggable; )
      a = a.parent || a.__hostTarget;
    a && (this._draggingTarget = a, a.dragging = !0, this._x = t.offsetX, this._y = t.offsetY, this.handler.dispatchToElement(new n(a, t), "dragstart", t.event));
  }, r.prototype._drag = function(t) {
    var a = this._draggingTarget;
    if (a) {
      var g = t.offsetX, s = t.offsetY, d = g - this._x, o = s - this._y;
      this._x = g, this._y = s, a.drift(d, o, t), this.handler.dispatchToElement(new n(a, t), "drag", t.event);
      var i = this.handler.findHover(g, s, a).target, e = this._dropTarget;
      this._dropTarget = i, a !== i && (e && i !== e && this.handler.dispatchToElement(new n(e, t), "dragleave", t.event), i && i !== e && this.handler.dispatchToElement(new n(i, t), "dragenter", t.event));
    }
  }, r.prototype._dragEnd = function(t) {
    var a = this._draggingTarget;
    a && (a.dragging = !1), this.handler.dispatchToElement(new n(a, t), "dragend", t.event), this._dropTarget && this.handler.dispatchToElement(new n(this._dropTarget, t), "drop", t.event), this._draggingTarget = null, this._dropTarget = null;
  }, r;
}();
export {
  v as default
};
