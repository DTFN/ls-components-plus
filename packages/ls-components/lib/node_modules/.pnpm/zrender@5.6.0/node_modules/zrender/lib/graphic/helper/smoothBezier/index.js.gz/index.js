var A = Object.defineProperty;
var q = (a, P) => A(a, "name", { value: P, configurable: !0 });
import { min as I, max as g, clone as C, sub as D, scale as B, distance as t, add as w } from "../../../core/vector/index.js";
function G(a, P, d, m) {
  var f = [], l = [], j = [], k = [], n, x, v, e;
  if (m) {
    v = [1 / 0, 1 / 0], e = [-1 / 0, -1 / 0];
    for (var r = 0, h = a.length; r < h; r++)
      I(v, v, a[r]), g(e, e, a[r]);
    I(v, v, m[0]), g(e, e, m[1]);
  }
  for (var r = 0, h = a.length; r < h; r++) {
    var y = a[r];
    if (d)
      n = a[r ? r - 1 : h - 1], x = a[(r + 1) % h];
    else if (r === 0 || r === h - 1) {
      f.push(C(a[r]));
      continue;
    } else
      n = a[r - 1], x = a[r + 1];
    D(l, x, n), B(l, l, P);
    var $ = t(y, n), b = t(y, x), z = $ + b;
    z !== 0 && ($ /= z, b /= z), B(j, l, -$), B(k, l, b);
    var u = w([], y, j), i = w([], y, k);
    m && (g(u, u, v), I(u, u, e), g(i, i, v), I(i, i, e)), f.push(u), f.push(i);
  }
  return d && f.push(f.shift()), f;
}
q(G, "smoothBezier");
export {
  G as default
};
