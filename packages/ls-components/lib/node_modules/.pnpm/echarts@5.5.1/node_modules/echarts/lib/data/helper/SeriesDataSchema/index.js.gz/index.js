var f = Object.defineProperty;
var m = (n, t) => f(n, "name", { value: t, configurable: !0 });
import { retrieve2 as S, createHashMap as C, isObject as O } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { makeInner as _ } from "../../../util/model/index.js";
import { shouldRetrieveDataByName as g } from "../../Source/index.js";
var N = _(), y = {
  float: "f",
  int: "i",
  ordinal: "o",
  number: "n",
  time: "t"
}, M = (
  /** @class */
  function() {
    function n(t) {
      this.dimensions = t.dimensions, this._dimOmitted = t.dimensionOmitted, this.source = t.source, this._fullDimCount = t.fullDimensionCount, this._updateDimOmitted(t.dimensionOmitted);
    }
    return m(n, "SeriesDataSchema"), n.prototype.isDimensionOmitted = function() {
      return this._dimOmitted;
    }, n.prototype._updateDimOmitted = function(t) {
      this._dimOmitted = t, t && (this._dimNameMap || (this._dimNameMap = k(this.source)));
    }, n.prototype.getSourceDimensionIndex = function(t) {
      return S(this._dimNameMap.get(t), -1);
    }, n.prototype.getSourceDimension = function(t) {
      var i = this.source.dimensionsDefine;
      if (i)
        return i[t];
    }, n.prototype.makeStoreSchema = function() {
      for (var t = this._fullDimCount, i = g(this.source), a = !B(t), e = "", o = [], r = 0, v = 0; r < t; r++) {
        var u = void 0, h = void 0, d = void 0, s = this.dimensions[v];
        if (s && s.storeDimIndex === r)
          u = i ? s.name : null, h = s.type, d = s.ordinalMeta, v++;
        else {
          var c = this.getSourceDimension(r);
          c && (u = i ? c.name : null, h = c.type);
        }
        o.push({
          property: u,
          type: h,
          ordinalMeta: d
        }), i && u != null && (!s || !s.isCalculationCoord) && (e += a ? u.replace(/\`/g, "`1").replace(/\$/g, "`2") : u), e += "$", e += y[h] || "f", d && (e += d.uid), e += "$";
      }
      var l = this.source, p = [l.seriesLayoutBy, l.startIndex, e].join("$$");
      return {
        dimensions: o,
        hash: p
      };
    }, n.prototype.makeOutputDimensionNames = function() {
      for (var t = [], i = 0, a = 0; i < this._fullDimCount; i++) {
        var e = void 0, o = this.dimensions[a];
        if (o && o.storeDimIndex === i)
          o.isCalculationCoord || (e = o.name), a++;
        else {
          var r = this.getSourceDimension(i);
          r && (e = r.name);
        }
        t.push(e);
      }
      return t;
    }, n.prototype.appendCalculationDimension = function(t) {
      this.dimensions.push(t), t.isCalculationCoord = !0, this._fullDimCount++, this._updateDimOmitted(!0);
    }, n;
  }()
);
function T(n) {
  return n instanceof M;
}
m(T, "isSeriesDataSchema");
function $(n) {
  for (var t = C(), i = 0; i < (n || []).length; i++) {
    var a = n[i], e = O(a) ? a.name : a;
    e != null && t.get(e) == null && t.set(e, i);
  }
  return t;
}
m($, "createDimNameMap");
function k(n) {
  var t = N(n);
  return t.dimNameMap || (t.dimNameMap = $(n.dimensionsDefine));
}
m(k, "ensureSourceDimNameMap");
function B(n) {
  return n > 30;
}
m(B, "shouldOmitUnusedDimensions");
export {
  M as SeriesDataSchema,
  $ as createDimNameMap,
  k as ensureSourceDimNameMap,
  T as isSeriesDataSchema,
  B as shouldOmitUnusedDimensions
};
