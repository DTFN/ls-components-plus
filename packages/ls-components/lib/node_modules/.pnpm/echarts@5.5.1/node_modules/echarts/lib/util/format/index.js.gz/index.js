var b = Object.defineProperty;
var i = (r, e) => b(r, "name", { value: e, configurable: !0 });
import { isArray as y, isString as l, isObject as A, normalizeCssArray as v, isStringSafe as g, isNumber as T, trim as R } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { encodeHTML as u } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/dom/index.js";
import { parseDate as N, numericToNumber as C, isNumeric as M } from "../number/index.js";
import { format as S } from "../time/index.js";
function k(r) {
  if (!M(r))
    return l(r) ? r : "-";
  var e = (r + "").split(".");
  return e[0].replace(/(\d{1,3})(?=(?:\d{3})+(?!\d))/g, "$1,") + (e.length > 1 ? "." + e[1] : "");
}
i(k, "addCommas");
function V(r, e) {
  return r = (r || "").toLowerCase().replace(/-(.)/g, function(o, n) {
    return n.toUpperCase();
  }), e && r && (r = r.charAt(0).toUpperCase() + r.slice(1)), r;
}
i(V, "toCamelCase");
var $ = v;
function z(r, e, o) {
  var n = "{yyyy}-{MM}-{dd} {HH}:{mm}:{ss}";
  function t(f) {
    return f && R(f) ? f : "-";
  }
  i(t, "stringToUserReadable");
  function a(f) {
    return !!(f != null && !isNaN(f) && isFinite(f));
  }
  i(a, "isNumberUserReadable");
  var c = e === "time", d = r instanceof Date;
  if (c || d) {
    var m = c ? N(r) : r;
    if (isNaN(+m)) {
      if (d)
        return "-";
    } else return S(m, n, o);
  }
  if (e === "ordinal")
    return g(r) ? t(r) : T(r) && a(r) ? r + "" : "-";
  var p = C(r);
  return a(p) ? k(p) : g(r) ? t(r) : typeof r == "boolean" ? r + "" : "-";
}
i(z, "makeValueReadable");
var h = ["a", "b", "c", "d", "e", "f", "g"], s = /* @__PURE__ */ i(function(r, e) {
  return "{" + r + (e ?? "") + "}";
}, "wrapVar");
function H(r, e, o) {
  y(e) || (e = [e]);
  var n = e.length;
  if (!n)
    return "";
  for (var t = e[0].$vars || [], a = 0; a < t.length; a++) {
    var c = h[a];
    r = r.replace(s(c), s(c, 0));
  }
  for (var d = 0; d < n; d++)
    for (var m = 0; m < t.length; m++) {
      var p = e[d][t[m]];
      r = r.replace(s(h[m], d), o ? u(p) : p);
    }
  return r;
}
i(H, "formatTpl");
function F(r, e) {
  var o = l(r) ? {
    color: r,
    extraCssText: e
  } : r || {}, n = o.color, t = o.type;
  e = o.extraCssText;
  var a = o.renderMode || "html";
  if (!n)
    return "";
  if (a === "html")
    return t === "subItem" ? '<span style="display:inline-block;vertical-align:middle;margin-right:8px;margin-left:3px;border-radius:4px;width:4px;height:4px;background-color:' + u(n) + ";" + (e || "") + '"></span>' : '<span style="display:inline-block;margin-right:4px;border-radius:10px;width:10px;height:10px;background-color:' + u(n) + ";" + (e || "") + '"></span>';
  var c = o.markerId || "markerX";
  return {
    renderMode: a,
    content: "{" + c + "|}  ",
    style: t === "subItem" ? {
      width: 4,
      height: 4,
      borderRadius: 2,
      backgroundColor: n
    } : {
      width: 10,
      height: 10,
      borderRadius: 5,
      backgroundColor: n
    }
  };
}
i(F, "getTooltipMarker");
function L(r, e) {
  return e = e || "transparent", l(r) ? r : A(r) && r.colorStops && (r.colorStops[0] || {}).color || e;
}
i(L, "convertToColorString");
export {
  k as addCommas,
  L as convertToColorString,
  u as encodeHTML,
  H as formatTpl,
  F as getTooltipMarker,
  z as makeValueReadable,
  $ as normalizeCssArray,
  V as toCamelCase
};
