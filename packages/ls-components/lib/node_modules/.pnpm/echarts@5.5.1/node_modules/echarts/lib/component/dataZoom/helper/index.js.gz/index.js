var x = Object.defineProperty;
var n = (r, i) => x(r, "name", { value: i, configurable: !0 });
import { createHashMap as l, assert as M, indexOf as y } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var T = ["x", "y", "radius", "angle", "single"], A = ["cartesian2d", "polar", "singleAxis"];
function E(r) {
  var i = r.get("coordinateSystem");
  return y(A, i) >= 0;
}
n(E, "isCoordSupported");
function h(r) {
  return process.env.NODE_ENV !== "production" && M(r), r + "Axis";
}
n(h, "getAxisMainType");
function O(r, i) {
  var o = l(), d = [], f = l();
  r.eachComponent({
    mainType: "dataZoom",
    query: i
  }, function(e) {
    f.get(e.uid) || c(e);
  });
  var t;
  do
    t = !1, r.eachComponent("dataZoom", a);
  while (t);
  function a(e) {
    !f.get(e.uid) && s(e) && (c(e), t = !0);
  }
  n(a, "processSingle");
  function c(e) {
    f.set(e.uid, !0), d.push(e), v(e);
  }
  n(c, "addToEffected");
  function s(e) {
    var u = !1;
    return e.eachTargetAxis(function(p, S) {
      var g = o.get(p);
      g && g[S] && (u = !0);
    }), u;
  }
  n(s, "isLinked");
  function v(e) {
    e.eachTargetAxis(function(u, p) {
      (o.get(u) || o.set(u, []))[p] = !0;
    });
  }
  return n(v, "markAxisControlled"), d;
}
n(O, "findEffectedDataZooms");
function L(r) {
  var i = r.ecModel, o = {
    infoList: [],
    infoMap: l()
  };
  return r.eachTargetAxis(function(d, f) {
    var t = i.getComponent(h(d), f);
    if (t) {
      var a = t.getCoordSysModel();
      if (a) {
        var c = a.uid, s = o.infoMap.get(c);
        s || (s = {
          model: a,
          axisModels: []
        }, o.infoList.push(s), o.infoMap.set(c, s)), s.axisModels.push(t);
      }
    }
  }), o;
}
n(L, "collectReferCoordSysModelInfo");
export {
  T as DATA_ZOOM_AXIS_DIMENSIONS,
  L as collectReferCoordSysModelInfo,
  O as findEffectedDataZooms,
  h as getAxisMainType,
  E as isCoordSupported
};
