var gr = Object.defineProperty;
var h = (r, e) => gr(r, "name", { value: e, configurable: !0 });
import vr from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/WeakMap/index.js";
import ur from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/LRU/index.js";
import { defaults as cr, isArray as sr, isString as C, isNumber as z, map as K } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getLeastCommonMultiple as G } from "../number/index.js";
import { createSymbol as mr } from "../symbol/index.js";
import { brushSingle as pr } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/canvas/graphic/index.js";
import { platformApi as yr } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/platform/index.js";
var H = new vr(), Z = new ur(100), q = ["symbol", "symbolSize", "symbolKeepAspect", "color", "backgroundColor", "dashArrayX", "dashArrayY", "maxTileWidth", "maxTileHeight"];
function Lr(r, e) {
  if (r === "none")
    return null;
  var t = e.getDevicePixelRatio(), a = e.getZr(), o = a.painter.type === "svg";
  r.dirty && H.delete(r);
  var P = H.get(r);
  if (P)
    return P;
  var i = cr(r, {
    symbol: "rect",
    symbolSize: 1,
    symbolKeepAspect: !0,
    color: "rgba(0, 0, 0, 0.2)",
    backgroundColor: null,
    dashArrayX: 5,
    dashArrayY: 5,
    rotation: 0,
    maxTileWidth: 512,
    maxTileHeight: 512
  });
  i.backgroundColor === "none" && (i.backgroundColor = null);
  var v = {
    repeat: "repeat"
  };
  return $(v), v.rotation = i.rotation, v.scaleX = v.scaleY = o ? 1 : 1 / t, H.set(r, v), r.dirty = !1, v;
  function $(y) {
    for (var R = [t], T = !0, L = 0; L < q.length; ++L) {
      var d = i[q[L]];
      if (d != null && !sr(d) && !C(d) && !z(d) && typeof d != "boolean") {
        T = !1;
        break;
      }
      R.push(d);
    }
    var x;
    if (T) {
      x = R.join(",") + (o ? "-svg" : "");
      var X = Z.get(x);
      X && (o ? y.svgElement = X : y.image = X);
    }
    var u = Q(i.dashArrayX), s = dr(i.dashArrayY), b = J(i.symbol), W = br(u), B = _(s), g = !o && yr.createCanvas(), Y = o && {
      tag: "g",
      attrs: {},
      key: "dcl",
      children: []
    }, k = O(), A;
    g && (g.width = k.width * t, g.height = k.height * t, A = g.getContext("2d")), j(), T && Z.put(x, g || Y), y.image = g, y.svgElement = Y, y.svgWidth = k.width, y.svgHeight = k.height;
    function O() {
      for (var c = 1, n = 0, m = W.length; n < m; ++n)
        c = G(c, W[n]);
      for (var f = 1, n = 0, m = b.length; n < m; ++n)
        f = G(f, b[n].length);
      c *= f;
      var w = B * W.length * b.length;
      if (process.env.NODE_ENV !== "production") {
        var l = /* @__PURE__ */ h(function(S) {
          console.warn("Calculated decal size is greater than " + S + " due to decal option settings so " + S + " is used for the decal size. Please consider changing the decal option to make a smaller decal or set " + S + " to be larger to avoid incontinuity.");
        }, "warn");
        c > i.maxTileWidth && l("maxTileWidth"), w > i.maxTileHeight && l("maxTileHeight");
      }
      return {
        width: Math.max(1, Math.min(c, i.maxTileWidth)),
        height: Math.max(1, Math.min(w, i.maxTileHeight))
      };
    }
    h(O, "getPatternSize");
    function j() {
      A && (A.clearRect(0, 0, g.width, g.height), i.backgroundColor && (A.fillStyle = i.backgroundColor, A.fillRect(0, 0, g.width, g.height)));
      for (var c = 0, n = 0; n < s.length; ++n)
        c += s[n];
      if (c <= 0)
        return;
      for (var m = -B, f = 0, w = 0, l = 0; m < k.height; ) {
        if (f % 2 === 0) {
          for (var S = w / 2 % b.length, D = 0, p = 0, E = 0; D < k.width * 2; ) {
            for (var V = 0, n = 0; n < u[l].length; ++n)
              V += u[l][n];
            if (V <= 0)
              break;
            if (p % 2 === 0) {
              var N = (1 - i.symbolSize) * 0.5, I = D + u[l][p] * N, rr = m + s[f] * N, er = u[l][p] * i.symbolSize, tr = s[f] * i.symbolSize, ar = E / 2 % b[S].length;
              ir(I, rr, er, tr, b[S][ar]);
            }
            D += u[l][p], ++E, ++p, p === u[l].length && (p = 0);
          }
          ++l, l === u.length && (l = 0);
        }
        m += s[f], ++w, ++f, f === s.length && (f = 0);
      }
      function ir(nr, or, lr, hr, fr) {
        var M = o ? 1 : t, U = mr(fr, nr * M, or * M, lr * M, hr * M, i.color, i.symbolKeepAspect);
        if (o) {
          var F = a.painter.renderOneToVNode(U);
          F && Y.children.push(F);
        } else
          pr(A, U);
      }
      h(ir, "brushSymbol");
    }
    h(j, "brushDecal");
  }
  h($, "setPatternnSource");
}
h(Lr, "createOrUpdatePatternFromDecal");
function J(r) {
  if (!r || r.length === 0)
    return [["rect"]];
  if (C(r))
    return [[r]];
  for (var e = !0, t = 0; t < r.length; ++t)
    if (!C(r[t])) {
      e = !1;
      break;
    }
  if (e)
    return J([r]);
  for (var a = [], t = 0; t < r.length; ++t)
    C(r[t]) ? a.push([r[t]]) : a.push(r[t]);
  return a;
}
h(J, "normalizeSymbolArray");
function Q(r) {
  if (!r || r.length === 0)
    return [[0, 0]];
  if (z(r)) {
    var e = Math.ceil(r);
    return [[e, e]];
  }
  for (var t = !0, a = 0; a < r.length; ++a)
    if (!z(r[a])) {
      t = !1;
      break;
    }
  if (t)
    return Q([r]);
  for (var o = [], a = 0; a < r.length; ++a)
    if (z(r[a])) {
      var e = Math.ceil(r[a]);
      o.push([e, e]);
    } else {
      var e = K(r[a], function(v) {
        return Math.ceil(v);
      });
      e.length % 2 === 1 ? o.push(e.concat(e)) : o.push(e);
    }
  return o;
}
h(Q, "normalizeDashArrayX");
function dr(r) {
  if (!r || typeof r == "object" && r.length === 0)
    return [0, 0];
  if (z(r)) {
    var e = Math.ceil(r);
    return [e, e];
  }
  var t = K(r, function(a) {
    return Math.ceil(a);
  });
  return r.length % 2 ? t.concat(t) : t;
}
h(dr, "normalizeDashArrayY");
function br(r) {
  return K(r, function(e) {
    return _(e);
  });
}
h(br, "getLineBlockLengthX");
function _(r) {
  for (var e = 0, t = 0; t < r.length; ++t)
    e += r[t];
  return r.length % 2 === 1 ? e * 2 : e;
}
h(_, "getLineBlockLengthY");
export {
  Lr as createOrUpdatePatternFromDecal
};
