var K = Object.defineProperty;
var T = (a, t) => K(a, "name", { value: t, configurable: !0 });
import "../../util/graphic/index.js";
import V from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/PathProxy/index.js";
import { normalizeRadian as q } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/contain/util/index.js";
import { quadraticProjectPoint as W, cubicProjectPoint as X } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/curve/index.js";
import { retrieve2 as _, defaults as $ } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { invert as E } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/matrix/index.js";
import { dist as B, lerp as D } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/vector/index.js";
import { DISPLAY_STATES as Q, SPECIAL_STATES as U } from "../../util/states/index.js";
import x from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/Point/index.js";
import N from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Polyline/index.js";
import rr from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
var R = Math.PI * 2, k = V.CMD, ar = ["top", "right", "bottom", "left"];
function er(a, t, v, r, o) {
  var s = v.width, f = v.height;
  switch (a) {
    case "top":
      r.set(v.x + s / 2, v.y - t), o.set(0, -1);
      break;
    case "bottom":
      r.set(v.x + s / 2, v.y + f + t), o.set(0, 1);
      break;
    case "left":
      r.set(v.x - t, v.y + f / 2), o.set(-1, 0);
      break;
    case "right":
      r.set(v.x + s + t, v.y + f / 2), o.set(1, 0);
      break;
  }
}
T(er, "getCandidateAnchor");
function or(a, t, v, r, o, s, f, i, u) {
  f -= a, i -= t;
  var h = Math.sqrt(f * f + i * i);
  f /= h, i /= h;
  var e = f * v + a, m = i * v + t;
  if (Math.abs(r - o) % R < 1e-4)
    return u[0] = e, u[1] = m, h - v;
  if (s) {
    var p = r;
    r = q(o), o = q(p);
  } else
    r = q(r), o = q(o);
  r > o && (o += R);
  var n = Math.atan2(i, f);
  if (n < 0 && (n += R), n >= r && n <= o || n + R >= r && n + R <= o)
    return u[0] = e, u[1] = m, h - v;
  var b = v * Math.cos(r) + a, l = v * Math.sin(r) + t, M = v * Math.cos(o) + a, w = v * Math.sin(o) + t, j = (b - f) * (b - f) + (l - i) * (l - i), I = (M - f) * (M - f) + (w - i) * (w - i);
  return j < I ? (u[0] = b, u[1] = l, Math.sqrt(j)) : (u[0] = M, u[1] = w, Math.sqrt(I));
}
T(or, "projectPointToArc");
function A(a, t, v, r, o, s, f, i) {
  var u = o - a, h = s - t, e = v - a, m = r - t, p = Math.sqrt(e * e + m * m);
  e /= p, m /= p;
  var n = u * e + h * m, b = n / p;
  i && (b = Math.min(Math.max(b, 0), 1)), b *= p;
  var l = f[0] = a + b * e, M = f[1] = t + b * m;
  return Math.sqrt((l - o) * (l - o) + (M - s) * (M - s));
}
T(A, "projectPointToLine");
function Y(a, t, v, r, o, s, f) {
  v < 0 && (a = a + v, v = -v), r < 0 && (t = t + r, r = -r);
  var i = a + v, u = t + r, h = f[0] = Math.min(Math.max(o, a), i), e = f[1] = Math.min(Math.max(s, t), u);
  return Math.sqrt((h - o) * (h - o) + (e - s) * (e - s));
}
T(Y, "projectPointToRect");
var L = [];
function vr(a, t, v) {
  var r = Y(t.x, t.y, t.width, t.height, a.x, a.y, L);
  return v.set(L[0], L[1]), r;
}
T(vr, "nearestPointOnRect");
function tr(a, t, v) {
  for (var r = 0, o = 0, s = 0, f = 0, i, u, h = 1 / 0, e = t.data, m = a.x, p = a.y, n = 0; n < e.length; ) {
    var b = e[n++];
    n === 1 && (r = e[n], o = e[n + 1], s = r, f = o);
    var l = h;
    switch (b) {
      case k.M:
        s = e[n++], f = e[n++], r = s, o = f;
        break;
      case k.L:
        l = A(r, o, e[n], e[n + 1], m, p, L, !0), r = e[n++], o = e[n++];
        break;
      case k.C:
        l = X(r, o, e[n++], e[n++], e[n++], e[n++], e[n], e[n + 1], m, p, L), r = e[n++], o = e[n++];
        break;
      case k.Q:
        l = W(r, o, e[n++], e[n++], e[n], e[n + 1], m, p, L), r = e[n++], o = e[n++];
        break;
      case k.A:
        var M = e[n++], w = e[n++], j = e[n++], I = e[n++], G = e[n++], z = e[n++];
        n += 1;
        var Z = !!(1 - e[n++]);
        i = Math.cos(G) * j + M, u = Math.sin(G) * I + w, n <= 1 && (s = i, f = u);
        var F = (m - M) * I / j + M;
        l = or(M, w, I, G, G + z, Z, F, p, L), r = Math.cos(G + z) * j + M, o = Math.sin(G + z) * I + w;
        break;
      case k.R:
        s = r = e[n++], f = o = e[n++];
        var H = e[n++], J = e[n++];
        l = Y(s, f, H, J, m, p, L);
        break;
      case k.Z:
        l = A(r, o, s, f, m, p, L, !0), r = s, o = f;
        break;
    }
    l < h && (h = l, v.set(L[0], L[1]));
  }
  return h;
}
T(tr, "nearestPointOnPath");
var P = new x(), y = new x(), c = new x(), S = new x(), d = new x();
function Cr(a, t) {
  if (a) {
    var v = a.getTextGuideLine(), r = a.getTextContent();
    if (r && v) {
      var o = a.textGuideLineConfig || {}, s = [[0, 0], [0, 0], [0, 0]], f = o.candidates || ar, i = r.getBoundingRect().clone();
      i.applyTransform(r.getComputedTransform());
      var u = 1 / 0, h = o.anchor, e = a.getComputedTransform(), m = e && E([], e), p = t.get("length2") || 0;
      h && c.copy(h);
      for (var n = 0; n < f.length; n++) {
        var b = f[n];
        er(b, 0, i, P, S), x.scaleAndAdd(y, P, S, p), y.transform(m);
        var l = a.getBoundingRect(), M = h ? h.distance(y) : a instanceof rr ? tr(y, a.path, c) : vr(y, l, c);
        M < u && (u = M, y.transform(e), c.transform(e), c.toArray(s[0]), y.toArray(s[1]), P.toArray(s[2]));
      }
      nr(s, t.get("minTurnAngle")), v.setShape({
        points: s
      });
    }
  }
}
T(Cr, "updateLabelLinePoints");
var g = [], C = new x();
function nr(a, t) {
  if (t <= 180 && t > 0) {
    t = t / 180 * Math.PI, P.fromArray(a[0]), y.fromArray(a[1]), c.fromArray(a[2]), x.sub(S, P, y), x.sub(d, c, y);
    var v = S.len(), r = d.len();
    if (!(v < 1e-3 || r < 1e-3)) {
      S.scale(1 / v), d.scale(1 / r);
      var o = S.dot(d), s = Math.cos(t);
      if (s < o) {
        var f = A(y.x, y.y, c.x, c.y, P.x, P.y, g, !1);
        C.fromArray(g), C.scaleAndAdd(d, f / Math.tan(Math.PI - t));
        var i = c.x !== y.x ? (C.x - y.x) / (c.x - y.x) : (C.y - y.y) / (c.y - y.y);
        if (isNaN(i))
          return;
        i < 0 ? x.copy(C, y) : i > 1 && x.copy(C, c), C.toArray(a[1]);
      }
    }
  }
}
T(nr, "limitTurnAngle");
function Tr(a, t, v) {
  if (v <= 180 && v > 0) {
    v = v / 180 * Math.PI, P.fromArray(a[0]), y.fromArray(a[1]), c.fromArray(a[2]), x.sub(S, y, P), x.sub(d, c, y);
    var r = S.len(), o = d.len();
    if (!(r < 1e-3 || o < 1e-3)) {
      S.scale(1 / r), d.scale(1 / o);
      var s = S.dot(t), f = Math.cos(v);
      if (s < f) {
        var i = A(y.x, y.y, c.x, c.y, P.x, P.y, g, !1);
        C.fromArray(g);
        var u = Math.PI / 2, h = Math.acos(d.dot(t)), e = u + h - v;
        if (e >= u)
          x.copy(C, c);
        else {
          C.scaleAndAdd(d, i / Math.tan(Math.PI / 2 - e));
          var m = c.x !== y.x ? (C.x - y.x) / (c.x - y.x) : (C.y - y.y) / (c.y - y.y);
          if (isNaN(m))
            return;
          m < 0 ? x.copy(C, y) : m > 1 && x.copy(C, c);
        }
        C.toArray(a[1]);
      }
    }
  }
}
T(Tr, "limitSurfaceAngle");
function O(a, t, v, r) {
  var o = v === "normal", s = o ? a : a.ensureState(v);
  s.ignore = t;
  var f = r.get("smooth");
  f && f === !0 && (f = 0.3), s.shape = s.shape || {}, f > 0 && (s.shape.smooth = f);
  var i = r.getModel("lineStyle").getLineStyle();
  o ? a.useStyle(i) : s.style = i;
}
T(O, "setLabelLineState");
function fr(a, t) {
  var v = t.smooth, r = t.points;
  if (r)
    if (a.moveTo(r[0][0], r[0][1]), v > 0 && r.length >= 3) {
      var o = B(r[0], r[1]), s = B(r[1], r[2]);
      if (!o || !s) {
        a.lineTo(r[1][0], r[1][1]), a.lineTo(r[2][0], r[2][1]);
        return;
      }
      var f = Math.min(o, s) * v, i = D([], r[1], r[0], f / o), u = D([], r[1], r[2], f / s), h = D([], i, u, 0.5);
      a.bezierCurveTo(i[0], i[1], i[0], i[1], h[0], h[1]), a.bezierCurveTo(u[0], u[1], u[0], u[1], r[2][0], r[2][1]);
    } else
      for (var e = 1; e < r.length; e++)
        a.lineTo(r[e][0], r[e][1]);
}
T(fr, "buildLabelLinePath");
function Lr(a, t, v) {
  var r = a.getTextGuideLine(), o = a.getTextContent();
  if (!o) {
    r && a.removeTextGuideLine();
    return;
  }
  for (var s = t.normal, f = s.get("show"), i = o.ignore, u = 0; u < Q.length; u++) {
    var h = Q[u], e = t[h], m = h === "normal";
    if (e) {
      var p = e.get("show"), n = m ? i : _(o.states[h] && o.states[h].ignore, i);
      if (n || !_(p, f)) {
        var b = m ? r : r && r.states[h];
        b && (b.ignore = !0), r && O(r, !0, h, e);
        continue;
      }
      r || (r = new N(), a.setTextGuideLine(r), !m && (i || !f) && O(r, !0, "normal", t.normal), a.stateProxy && (r.stateProxy = a.stateProxy)), O(r, !1, h, e);
    }
  }
  if (r) {
    $(r.style, v), r.style.fill = null;
    var l = s.get("showAbove"), M = a.textGuideLineConfig = a.textGuideLineConfig || {};
    M.showAbove = l || !1, r.buildPath = fr;
  }
}
T(Lr, "setLabelLineStyle");
function Pr(a, t) {
  t = t || "labelLine";
  for (var v = {
    normal: a.getModel(t)
  }, r = 0; r < U.length; r++) {
    var o = U[r];
    v[o] = a.getModel([o, t]);
  }
  return v;
}
T(Pr, "getLabelLineStatesModels");
export {
  Pr as getLabelLineStatesModels,
  Tr as limitSurfaceAngle,
  nr as limitTurnAngle,
  Lr as setLabelLineStyle,
  Cr as updateLabelLinePoints
};
