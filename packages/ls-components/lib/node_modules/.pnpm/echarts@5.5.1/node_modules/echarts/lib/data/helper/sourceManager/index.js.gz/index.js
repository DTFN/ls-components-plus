var B = Object.defineProperty;
var h = (s, e) => B(s, "name", { value: e, configurable: !0 });
import { isTypedArray as N, retrieve2 as g, assert as S, each as U, map as O } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { createSource as L, cloneSourceShallow as V } from "../../Source/index.js";
import { SOURCE_FORMAT_TYPED_ARRAY as A, SOURCE_FORMAT_ORIGINAL as M } from "../../../util/types/index.js";
import { querySeriesUpstreamDatasetModel as R, queryDatasetUpstreamDatasetModels as C } from "../sourceHelper/index.js";
import { applyDataTransform as G } from "../transform/index.js";
import b from "../../DataStore/index.js";
import { DefaultDataProvider as w } from "../dataProvider/index.js";
var j = (
  /** @class */
  function() {
    function s(e) {
      this._sourceList = [], this._storeList = [], this._upstreamSignList = [], this._versionSignBase = 0, this._dirty = !0, this._sourceHost = e;
    }
    return h(s, "SourceManager"), s.prototype.dirty = function() {
      this._setLocalSource([], []), this._storeList = [], this._dirty = !0;
    }, s.prototype._setLocalSource = function(e, r) {
      this._sourceList = e, this._upstreamSignList = r, this._versionSignBase++, this._versionSignBase > 9e10 && (this._versionSignBase = 0);
    }, s.prototype._getVersionSign = function() {
      return this._sourceHost.uid + "_" + this._versionSignBase;
    }, s.prototype.prepareSource = function() {
      this._isDirty() && (this._createSource(), this._dirty = !1);
    }, s.prototype._createSource = function() {
      this._setLocalSource([], []);
      var e = this._sourceHost, r = this._getUpstreamSourceManagers(), t = !!r.length, o, i;
      if (v(e)) {
        var n = e, a = void 0, u = void 0, c = void 0;
        if (t) {
          var f = r[0];
          f.prepareSource(), c = f.getSource(), a = c.data, u = c.sourceFormat, i = [f._getVersionSign()];
        } else
          a = n.get("data", !0), u = N(a) ? A : M, i = [];
        var p = this._getSourceMetaRawOption() || {}, _ = c && c.metaRawOption || {}, m = g(p.seriesLayoutBy, _.seriesLayoutBy) || null, l = g(p.sourceHeader, _.sourceHeader), y = g(p.dimensions, _.dimensions), H = m !== _.seriesLayoutBy || !!l != !!_.sourceHeader || y;
        o = H ? [L(a, {
          seriesLayoutBy: m,
          sourceHeader: l,
          dimensions: y
        }, u)] : [];
      } else {
        var E = e;
        if (t) {
          var d = this._applyTransform(r);
          o = d.sourceList, i = d.upstreamSignList;
        } else {
          var T = E.get("source", !0);
          o = [L(T, this._getSourceMetaRawOption(), null)], i = [];
        }
      }
      process.env.NODE_ENV !== "production" && S(o && i), this._setLocalSource(o, i);
    }, s.prototype._applyTransform = function(e) {
      var r = this._sourceHost, t = r.get("transform", !0), o = r.get("fromTransformResult", !0);
      if (process.env.NODE_ENV !== "production" && S(o != null || t != null), o != null) {
        var i = "";
        e.length !== 1 && (process.env.NODE_ENV !== "production" && (i = "When using `fromTransformResult`, there should be only one upstream dataset"), D(i));
      }
      var n, a = [], u = [];
      return U(e, function(c) {
        c.prepareSource();
        var f = c.getSource(o || 0), p = "";
        o != null && !f && (process.env.NODE_ENV !== "production" && (p = "Can not retrieve result by `fromTransformResult`: " + o), D(p)), a.push(f), u.push(c._getVersionSign());
      }), t ? n = G(t, a, {
        datasetIndex: r.componentIndex
      }) : o != null && (n = [V(a[0])]), {
        sourceList: n,
        upstreamSignList: u
      };
    }, s.prototype._isDirty = function() {
      if (this._dirty)
        return !0;
      for (var e = this._getUpstreamSourceManagers(), r = 0; r < e.length; r++) {
        var t = e[r];
        if (
          // Consider the case that there is ancestor diry, call it recursively.
          // The performance is probably not an issue because usually the chain is not long.
          t._isDirty() || this._upstreamSignList[r] !== t._getVersionSign()
        )
          return !0;
      }
    }, s.prototype.getSource = function(e) {
      e = e || 0;
      var r = this._sourceList[e];
      if (!r) {
        var t = this._getUpstreamSourceManagers();
        return t[0] && t[0].getSource(e);
      }
      return r;
    }, s.prototype.getSharedDataStore = function(e) {
      process.env.NODE_ENV !== "production" && S(v(this._sourceHost), "Can only call getDataStore on series source manager.");
      var r = e.makeStoreSchema();
      return this._innerGetDataStore(r.dimensions, e.source, r.hash);
    }, s.prototype._innerGetDataStore = function(e, r, t) {
      var o = 0, i = this._storeList, n = i[o];
      n || (n = i[o] = {});
      var a = n[t];
      if (!a) {
        var u = this._getUpstreamSourceManagers()[0];
        v(this._sourceHost) && u ? a = u._innerGetDataStore(e, r, t) : (a = new b(), a.initData(new w(r, e.length), e)), n[t] = a;
      }
      return a;
    }, s.prototype._getUpstreamSourceManagers = function() {
      var e = this._sourceHost;
      if (v(e)) {
        var r = R(e);
        return r ? [r.getSourceManager()] : [];
      } else
        return O(C(e), function(t) {
          return t.getSourceManager();
        });
    }, s.prototype._getSourceMetaRawOption = function() {
      var e = this._sourceHost, r, t, o;
      if (v(e))
        r = e.get("seriesLayoutBy", !0), t = e.get("sourceHeader", !0), o = e.get("dimensions", !0);
      else if (!this._getUpstreamSourceManagers().length) {
        var i = e;
        r = i.get("seriesLayoutBy", !0), t = i.get("sourceHeader", !0), o = i.get("dimensions", !0);
      }
      return {
        seriesLayoutBy: r,
        sourceHeader: t,
        dimensions: o
      };
    }, s;
  }()
);
function v(s) {
  return s.mainType === "series";
}
h(v, "isSeries");
function D(s) {
  throw new Error(s);
}
h(D, "doThrow");
export {
  j as SourceManager
};
