var y = Object.defineProperty;
var v = (o, a) => y(o, "name", { value: a, configurable: !0 });
import { __extends as P } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import g from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
var m = (
  /** @class */
  function() {
    function o() {
      this.angle = 0, this.width = 10, this.r = 10, this.x = 0, this.y = 0;
    }
    return v(o, "PointerShape"), o;
  }()
), w = (
  /** @class */
  function(o) {
    P(a, o);
    function a(r) {
      var t = o.call(this, r) || this;
      return t.type = "pointer", t;
    }
    return v(a, "PointerPath"), a.prototype.getDefaultShape = function() {
      return new m();
    }, a.prototype.buildPath = function(r, t) {
      var e = Math.cos, l = Math.sin, u = t.r, n = t.width, i = t.angle, f = t.x - e(i) * n * (n >= u / 3 ? 1 : 2), h = t.y - l(i) * n * (n >= u / 3 ? 1 : 2);
      i = t.angle - Math.PI / 2, r.moveTo(f, h), r.lineTo(t.x + e(i) * n, t.y + l(i) * n), r.lineTo(t.x + e(t.angle) * u, t.y + l(t.angle) * u), r.lineTo(t.x - e(i) * n, t.y - l(i) * n), r.lineTo(f, h);
    }, a;
  }(g)
);
export {
  w as default
};
