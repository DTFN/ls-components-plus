var M = Object.defineProperty;
var g = (o, e) => M(o, "name", { value: e, configurable: !0 });
import { __extends as b } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { map as S } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import v from "../Scale/index.js";
import { round as p, getPrecision as w, quantity as L } from "../../util/number/index.js";
import { contain as k, normalize as P, scale as d } from "../helper/index.js";
import E from "../Interval/index.js";
var m = v.prototype, l = E.prototype, F = p, N = Math.floor, T = Math.ceil, c = Math.pow, a = Math.log, y = (
  /** @class */
  function(o) {
    b(e, o);
    function e() {
      var t = o !== null && o.apply(this, arguments) || this;
      return t.type = "log", t.base = 10, t._originalScale = new E(), t._interval = 0, t;
    }
    return g(e, "LogScale"), e.prototype.getTicks = function(t) {
      var i = this._originalScale, r = this._extent, n = i.getExtent(), x = l.getTicks.call(this, t);
      return S(x, function(u) {
        var f = u.value, s = p(c(this.base, f));
        return s = f === r[0] && this._fixMin ? h(s, n[0]) : s, s = f === r[1] && this._fixMax ? h(s, n[1]) : s, {
          value: s
        };
      }, this);
    }, e.prototype.setExtent = function(t, i) {
      var r = a(this.base);
      t = a(Math.max(0, t)) / r, i = a(Math.max(0, i)) / r, l.setExtent.call(this, t, i);
    }, e.prototype.getExtent = function() {
      var t = this.base, i = m.getExtent.call(this);
      i[0] = c(t, i[0]), i[1] = c(t, i[1]);
      var r = this._originalScale, n = r.getExtent();
      return this._fixMin && (i[0] = h(i[0], n[0])), this._fixMax && (i[1] = h(i[1], n[1])), i;
    }, e.prototype.unionExtent = function(t) {
      this._originalScale.unionExtent(t);
      var i = this.base;
      t[0] = a(t[0]) / a(i), t[1] = a(t[1]) / a(i), m.unionExtent.call(this, t);
    }, e.prototype.unionExtentFromData = function(t, i) {
      this.unionExtent(t.getApproximateExtent(i));
    }, e.prototype.calcNiceTicks = function(t) {
      t = t || 10;
      var i = this._extent, r = i[1] - i[0];
      if (!(r === 1 / 0 || r <= 0)) {
        var n = L(r), x = t / r * n;
        for (x <= 0.5 && (n *= 10); !isNaN(n) && Math.abs(n) < 1 && Math.abs(n) > 0; )
          n *= 10;
        var u = [p(T(i[0] / n) * n), p(N(i[1] / n) * n)];
        this._interval = n, this._niceExtent = u;
      }
    }, e.prototype.calcNiceExtent = function(t) {
      l.calcNiceExtent.call(this, t), this._fixMin = t.fixMin, this._fixMax = t.fixMax;
    }, e.prototype.parse = function(t) {
      return t;
    }, e.prototype.contain = function(t) {
      return t = a(t) / a(this.base), k(t, this._extent);
    }, e.prototype.normalize = function(t) {
      return t = a(t) / a(this.base), P(t, this._extent);
    }, e.prototype.scale = function(t) {
      return t = d(t, this._extent), c(this.base, t);
    }, e.type = "log", e;
  }(v)
), _ = y.prototype;
_.getMinorTicks = l.getMinorTicks;
_.getLabel = l.getLabel;
function h(o, e) {
  return F(o, w(e));
}
g(h, "fixRoundingError");
v.registerClass(y);
export {
  y as default
};
