var S = Object.defineProperty;
var t = (r, n) => S(r, "name", { value: n, configurable: !0 });
import { isString as l, reduce as v, map as g } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var D = 1e-4, x = 20;
function R(r) {
  return r.replace(/^\s+|\s+$/g, "");
}
t(R, "_trim");
function b(r, n, e, o) {
  var u = n[0], i = n[1], a = e[0], s = e[1], d = i - u, M = s - a;
  if (d === 0)
    return M === 0 ? a : (a + s) / 2;
  if (o)
    if (d > 0) {
      if (r <= u)
        return a;
      if (r >= i)
        return s;
    } else {
      if (r >= u)
        return a;
      if (r <= i)
        return s;
    }
  else {
    if (r === u)
      return a;
    if (r === i)
      return s;
  }
  return (r - u) / d * M + a;
}
t(b, "linearMap");
function C(r, n) {
  switch (r) {
    case "center":
    case "middle":
      r = "50%";
      break;
    case "left":
    case "top":
      r = "0%";
      break;
    case "right":
    case "bottom":
      r = "100%";
      break;
  }
  return l(r) ? R(r).match(/%$/) ? parseFloat(r) / 100 * n : parseFloat(r) : r == null ? NaN : +r;
}
t(C, "parsePercent");
function m(r, n, e) {
  return n == null && (n = 10), n = Math.min(Math.max(0, n), x), r = (+r).toFixed(n), e ? r : +r;
}
t(m, "round");
function E(r) {
  return r.sort(function(n, e) {
    return n - e;
  }), r;
}
t(E, "asc");
function w(r) {
  if (r = +r, isNaN(r))
    return 0;
  if (r > 1e-14) {
    for (var n = 1, e = 0; e < 15; e++, n *= 10)
      if (Math.round(r * n) / n === r)
        return e;
  }
  return F(r);
}
t(w, "getPrecision");
function F(r) {
  var n = r.toString().toLowerCase(), e = n.indexOf("e"), o = e > 0 ? +n.slice(e + 1) : 0, u = e > 0 ? e : n.length, i = n.indexOf("."), a = i < 0 ? 0 : u - 1 - i;
  return Math.max(0, a - o);
}
t(F, "getPrecisionSafe");
function A(r, n) {
  var e = Math.log, o = Math.LN10, u = Math.floor(e(r[1] - r[0]) / o), i = Math.round(e(Math.abs(n[1] - n[0])) / o), a = Math.min(Math.max(-u + i, 0), 20);
  return isFinite(a) ? a : 20;
}
t(A, "getPixelPrecision");
function y(r, n) {
  var e = v(r, function(f, N) {
    return f + (isNaN(N) ? 0 : N);
  }, 0);
  if (e === 0)
    return [];
  for (var o = Math.pow(10, n), u = g(r, function(f) {
    return (isNaN(f) ? 0 : f) / e * o * 100;
  }), i = o * 100, a = g(u, function(f) {
    return Math.floor(f);
  }), s = v(a, function(f, N) {
    return f + N;
  }, 0), d = g(u, function(f, N) {
    return f - a[N];
  }); s < i; ) {
    for (var M = Number.NEGATIVE_INFINITY, P = null, c = 0, h = d.length; c < h; ++c)
      d[c] > M && (M = d[c], P = c);
    ++a[P], d[P] = 0, ++s;
  }
  return g(a, function(f) {
    return f / o;
  });
}
t(y, "getPercentSeats");
function U(r, n) {
  var e = Math.max(w(r), w(n)), o = r + n;
  return e > x ? o : m(o, e);
}
t(U, "addSafe");
function k(r) {
  var n = Math.PI * 2;
  return (r % n + n) % n;
}
t(k, "remRadian");
function G(r) {
  return r > -D && r < D;
}
t(G, "isRadianAroundZero");
var L = /^(?:(\d{4})(?:[-\/](\d{1,2})(?:[-\/](\d{1,2})(?:[T ](\d{1,2})(?::(\d{1,2})(?::(\d{1,2})(?:[.,](\d+))?)?)?(Z|[\+\-]\d\d:?\d\d)?)?)?)?)?$/;
function Q(r) {
  if (r instanceof Date)
    return r;
  if (l(r)) {
    var n = L.exec(r);
    if (!n)
      return /* @__PURE__ */ new Date(NaN);
    if (n[8]) {
      var e = +n[4] || 0;
      return n[8].toUpperCase() !== "Z" && (e -= +n[8].slice(0, 3)), new Date(Date.UTC(+n[1], +(n[2] || 1) - 1, +n[3] || 1, e, +(n[5] || 0), +n[6] || 0, n[7] ? +n[7].substring(0, 3) : 0));
    } else
      return new Date(+n[1], +(n[2] || 1) - 1, +n[3] || 1, +n[4] || 0, +(n[5] || 0), +n[6] || 0, n[7] ? +n[7].substring(0, 3) : 0);
  } else if (r == null)
    return /* @__PURE__ */ new Date(NaN);
  return new Date(Math.round(r));
}
t(Q, "parseDate");
function Z(r) {
  return Math.pow(10, p(r));
}
t(Z, "quantity");
function p(r) {
  if (r === 0)
    return 0;
  var n = Math.floor(Math.log(r) / Math.LN10);
  return r / Math.pow(10, n) >= 10 && n++, n;
}
t(p, "quantityExponent");
function $(r, n) {
  var e = p(r), o = Math.pow(10, e), u = r / o, i;
  return u < 1.5 ? i = 1 : u < 2.5 ? i = 2 : u < 4 ? i = 3 : u < 7 ? i = 5 : i = 10, r = i * o, e >= -20 ? +r.toFixed(e < 0 ? -e : 0) : r;
}
t($, "nice");
function O(r) {
  var n = parseFloat(r);
  return n == r && (n !== 0 || !l(r) || r.indexOf("x") <= 0) ? n : NaN;
}
t(O, "numericToNumber");
function q(r) {
  return !isNaN(O(r));
}
t(q, "isNumeric");
function z() {
  return Math.round(Math.random() * 9);
}
t(z, "getRandomIdBase");
function I(r, n) {
  return n === 0 ? r : I(n, r % n);
}
t(I, "getGreatestCommonDividor");
function B(r, n) {
  return r == null ? n : n == null ? r : r * n / I(r, n);
}
t(B, "getLeastCommonMultiple");
export {
  U as addSafe,
  E as asc,
  I as getGreatestCommonDividor,
  B as getLeastCommonMultiple,
  y as getPercentSeats,
  A as getPixelPrecision,
  w as getPrecision,
  F as getPrecisionSafe,
  z as getRandomIdBase,
  q as isNumeric,
  G as isRadianAroundZero,
  b as linearMap,
  $ as nice,
  O as numericToNumber,
  Q as parseDate,
  C as parsePercent,
  Z as quantity,
  p as quantityExponent,
  k as remRadian,
  m as round
};
