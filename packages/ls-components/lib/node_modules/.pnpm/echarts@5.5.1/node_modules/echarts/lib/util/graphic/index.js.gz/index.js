var R = Object.defineProperty;
var a = (e, t) => R(e, "name", { value: t, configurable: !0 });
import { createFromString as B, mergePath as E, extendFromString as S } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/tool/path/index.js";
import { identity as G, mul as $, invert as A } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/matrix/index.js";
import { applyTransform as D } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/vector/index.js";
import F from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
import N from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/Transformable/index.js";
import M from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Image/index.js";
import { default as et } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import { default as rt } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import j from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Circle/index.js";
import k from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Ellipse/index.js";
import H from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Sector/index.js";
import W from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Ring/index.js";
import Z from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Polygon/index.js";
import q from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Polyline/index.js";
import _ from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
import J from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Line/index.js";
import K from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/BezierCurve/index.js";
import Q from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Arc/index.js";
import { default as nt } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/CompoundPath/index.js";
import { default as ot } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/LinearGradient/index.js";
import { default as ft } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/RadialGradient/index.js";
import { default as pt } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/BoundingRect/index.js";
import { default as st } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/OrientedBoundingRect/index.js";
import { default as vt } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/Point/index.js";
import { default as xt } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/IncrementalDisplayable/index.js";
import { subPixelOptimizeLine as U, subPixelOptimizeRect as V, subPixelOptimize as X } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/helper/subPixelOptimize/index.js";
import { extend as z, defaults as I, each as Y, hasOwn as ee, keys as te, isArray as re, isArrayLike as ie, isString as ne, map as ae } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getECData as C } from "../innerStore/index.js";
import { updateProps as oe } from "../../animation/basicTransition/index.js";
import { initProps as gt, isElementRemoved as yt, removeElement as Pt, removeElementWithFadeOut as Tt } from "../../animation/basicTransition/index.js";
var l = Math.max, v = Math.min, c = {};
function $e(e) {
  return F.extend(e);
}
a($e, "extendShape");
var me = S;
function Ae(e, t) {
  return me(e, t);
}
a(Ae, "extendPath");
function p(e, t) {
  c[e] = t;
}
a(p, "registerShape");
function De(e) {
  if (c.hasOwnProperty(e))
    return c[e];
}
a(De, "getShapeClass");
function fe(e, t, r, i) {
  var n = B(e, t);
  return r && (i === "center" && (r = L(r, n.getBoundingRect())), ue(n, r)), n;
}
a(fe, "makePath");
function Fe(e, t, r) {
  var i = new M({
    style: {
      image: e,
      x: t.x,
      y: t.y,
      width: t.width,
      height: t.height
    },
    onload: /* @__PURE__ */ a(function(n) {
      if (r === "center") {
        var o = {
          width: n.width,
          height: n.height
        };
        i.setStyle(L(t, o));
      }
    }, "onload")
  });
  return i;
}
a(Fe, "makeImage");
function L(e, t) {
  var r = t.width / t.height, i = e.height * r, n;
  i <= e.width ? n = e.height : (i = e.width, n = i / r);
  var o = e.x + e.width / 2, m = e.y + e.height / 2;
  return {
    x: o - i / 2,
    y: m - n / 2,
    width: i,
    height: n
  };
}
a(L, "centerGraphic");
var Ne = E;
function ue(e, t) {
  if (e.applyTransform) {
    var r = e.getBoundingRect(), i = r.calculateTransform(t);
    e.applyTransform(i);
  }
}
a(ue, "resizePath");
function je(e, t) {
  return U(e, e, {
    lineWidth: t
  }), e;
}
a(je, "subPixelOptimizeLine");
function ke(e) {
  return V(e.shape, e.shape, e.style), e;
}
a(ke, "subPixelOptimizeRect");
var He = X;
function We(e, t) {
  for (var r = G([]); e && e !== t; )
    $(r, e.getLocalTransform(), r), e = e.parent;
  return r;
}
a(We, "getTransform");
function pe(e, t, r) {
  return t && !ie(t) && (t = N.getLocalTransform(t)), r && (t = A([], t)), D([], e, t);
}
a(pe, "applyTransform");
function Ze(e, t, r) {
  var i = t[4] === 0 || t[5] === 0 || t[0] === 0 ? 1 : Math.abs(2 * t[4] / t[0]), n = t[4] === 0 || t[5] === 0 || t[2] === 0 ? 1 : Math.abs(2 * t[4] / t[2]), o = [e === "left" ? -i : e === "right" ? i : 0, e === "top" ? -n : e === "bottom" ? n : 0];
  return o = pe(o, t, r), Math.abs(o[0]) > Math.abs(o[1]) ? o[0] > 0 ? "right" : "left" : o[1] > 0 ? "bottom" : "top";
}
a(Ze, "transformDirection");
function O(e) {
  return !e.isGroup;
}
a(O, "isNotGroup");
function he(e) {
  return e.shape != null;
}
a(he, "isPath");
function qe(e, t, r) {
  if (!e || !t)
    return;
  function i(m) {
    var f = {};
    return m.traverse(function(u) {
      O(u) && u.anid && (f[u.anid] = u);
    }), f;
  }
  a(i, "getElMap");
  function n(m) {
    var f = {
      x: m.x,
      y: m.y,
      rotation: m.rotation
    };
    return he(m) && (f.shape = z({}, m.shape)), f;
  }
  a(n, "getAnimatableProps");
  var o = i(e);
  t.traverse(function(m) {
    if (O(m) && m.anid) {
      var f = o[m.anid];
      if (f) {
        var u = n(m);
        m.attr(n(f)), oe(m, u, r, C(m).dataIndex);
      }
    }
  });
}
a(qe, "groupTransition");
function _e(e, t) {
  return ae(e, function(r) {
    var i = r[0];
    i = l(i, t.x), i = v(i, t.x + t.width);
    var n = r[1];
    return n = l(n, t.y), n = v(n, t.y + t.height), [i, n];
  });
}
a(_e, "clipPointsByRect");
function Je(e, t) {
  var r = l(e.x, t.x), i = v(e.x + e.width, t.x + t.width), n = l(e.y, t.y), o = v(e.y + e.height, t.y + t.height);
  if (i >= r && o >= n)
    return {
      x: r,
      y: n,
      width: i - r,
      height: o - n
    };
}
a(Je, "clipRectByRect");
function Ke(e, t, r) {
  var i = z({
    rectHover: !0
  }, t), n = i.style = {
    strokeNoScale: !0
  };
  if (r = r || {
    x: -1,
    y: -1,
    width: 2,
    height: 2
  }, e)
    return e.indexOf("image://") === 0 ? (n.image = e.slice(8), I(n, r), new M(i)) : fe(e.replace("path://", ""), i, r, "center");
}
a(Ke, "createIcon");
function Qe(e, t, r, i, n) {
  for (var o = 0, m = n[n.length - 1]; o < n.length; o++) {
    var f = n[o];
    if (se(e, t, r, i, f[0], f[1], m[0], m[1]))
      return !0;
    m = f;
  }
}
a(Qe, "linePolygonIntersect");
function se(e, t, r, i, n, o, m, f) {
  var u = r - e, s = i - t, h = m - n, g = f - o, d = x(h, g, u, s);
  if (le(d))
    return !1;
  var y = e - n, P = t - o, T = x(y, P, u, s) / d;
  if (T < 0 || T > 1)
    return !1;
  var w = x(y, P, h, g) / d;
  return !(w < 0 || w > 1);
}
a(se, "lineLineIntersect");
function x(e, t, r, i) {
  return e * i - r * t;
}
a(x, "crossProduct2d");
function le(e) {
  return e <= 1e-6 && e >= -1e-6;
}
a(le, "nearZero");
function Ue(e) {
  var t = e.itemTooltipOption, r = e.componentModel, i = e.itemName, n = ne(t) ? {
    formatter: t
  } : t, o = r.mainType, m = r.componentIndex, f = {
    componentType: o,
    name: i,
    $vars: ["name"]
  };
  f[o + "Index"] = m;
  var u = e.formatterParamsExtra;
  u && Y(te(u), function(h) {
    ee(f, h) || (f[h] = u[h], f.$vars.push(h));
  });
  var s = C(e.el);
  s.componentMainType = o, s.componentIndex = m, s.tooltipConfig = {
    name: i,
    option: I({
      content: i,
      encodeHTMLContent: !0,
      formatterParams: f
    }, n)
  };
}
a(Ue, "setTooltipConfig");
function b(e, t) {
  var r;
  e.isGroup && (r = t(e)), r || e.traverse(t);
}
a(b, "traverseElement");
function Ve(e, t) {
  if (e)
    if (re(e))
      for (var r = 0; r < e.length; r++)
        b(e[r], t);
    else
      b(e, t);
}
a(Ve, "traverseElements");
p("circle", j);
p("ellipse", k);
p("sector", H);
p("ring", W);
p("polygon", Z);
p("polyline", q);
p("rect", _);
p("line", J);
p("bezierCurve", K);
p("arc", Q);
export {
  Q as Arc,
  K as BezierCurve,
  pt as BoundingRect,
  j as Circle,
  nt as CompoundPath,
  k as Ellipse,
  et as Group,
  M as Image,
  xt as IncrementalDisplayable,
  J as Line,
  ot as LinearGradient,
  st as OrientedBoundingRect,
  F as Path,
  vt as Point,
  Z as Polygon,
  q as Polyline,
  ft as RadialGradient,
  _ as Rect,
  W as Ring,
  H as Sector,
  rt as Text,
  pe as applyTransform,
  _e as clipPointsByRect,
  Je as clipRectByRect,
  Ke as createIcon,
  Ae as extendPath,
  $e as extendShape,
  De as getShapeClass,
  We as getTransform,
  qe as groupTransition,
  gt as initProps,
  yt as isElementRemoved,
  se as lineLineIntersect,
  Qe as linePolygonIntersect,
  Fe as makeImage,
  fe as makePath,
  Ne as mergePath,
  p as registerShape,
  Pt as removeElement,
  Tt as removeElementWithFadeOut,
  ue as resizePath,
  Ue as setTooltipConfig,
  He as subPixelOptimize,
  je as subPixelOptimizeLine,
  ke as subPixelOptimizeRect,
  Ze as transformDirection,
  Ve as traverseElements,
  oe as updateProps
};
