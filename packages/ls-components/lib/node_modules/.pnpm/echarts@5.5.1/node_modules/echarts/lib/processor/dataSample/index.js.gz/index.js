var d = Object.defineProperty;
var r = (t, n) => d(t, "name", { value: n, configurable: !0 });
import { isString as p, isFunction as N } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var y = {
  average: /* @__PURE__ */ r(function(t) {
    for (var n = 0, a = 0, i = 0; i < t.length; i++)
      isNaN(t[i]) || (n += t[i], a++);
    return a === 0 ? NaN : n / a;
  }, "average"),
  sum: /* @__PURE__ */ r(function(t) {
    for (var n = 0, a = 0; a < t.length; a++)
      n += t[a] || 0;
    return n;
  }, "sum"),
  max: /* @__PURE__ */ r(function(t) {
    for (var n = -1 / 0, a = 0; a < t.length; a++)
      t[a] > n && (n = t[a]);
    return isFinite(n) ? n : NaN;
  }, "max"),
  min: /* @__PURE__ */ r(function(t) {
    for (var n = 1 / 0, a = 0; a < t.length; a++)
      t[a] < n && (n = t[a]);
    return isFinite(n) ? n : NaN;
  }, "min"),
  minmax: /* @__PURE__ */ r(function(t) {
    for (var n = -1 / 0, a = -1 / 0, i = 0; i < t.length; i++) {
      var e = t[i], o = Math.abs(e);
      o > n && (n = o, a = e);
    }
    return isFinite(a) ? a : NaN;
  }, "minmax"),
  // TODO
  // Median
  nearest: /* @__PURE__ */ r(function(t) {
    return t[0];
  }, "nearest")
}, D = /* @__PURE__ */ r(function(t) {
  return Math.round(t.length / 2);
}, "indexSampler");
function F(t) {
  return {
    seriesType: t,
    // FIXME:TS never used, so comment it
    // modifyOutputEnd: true,
    reset: /* @__PURE__ */ r(function(n, a, i) {
      var e = n.getData(), o = n.get("sampling"), f = n.coordinateSystem, c = e.count();
      if (c > 10 && f.type === "cartesian2d" && o) {
        var g = f.getBaseAxis(), s = f.getOtherAxis(g), m = g.getExtent(), h = i.getDevicePixelRatio(), l = Math.abs(m[1] - m[0]) * (h || 1), v = Math.round(c / l);
        if (isFinite(v) && v > 1) {
          o === "lttb" && n.setData(e.lttbDownSample(e.mapDimension(s.dim), 1 / v));
          var u = void 0;
          p(o) ? u = y[o] : N(o) && (u = o), u && n.setData(e.downSample(e.mapDimension(s.dim), 1 / v, u, D));
        }
      }
    }, "reset")
  };
}
r(F, "dataSample");
export {
  F as default
};
