var b = Object.defineProperty;
var c = (r, e) => b(r, "name", { value: e, configurable: !0 });
import { curry as l, map as p, assert as h, each as f, indexOf as v, createHashMap as P } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getTransform as D } from "../../../util/graphic/index.js";
import { makeRectPanelClipPath as R, makeRectIsTargetByCursor as B, makeLinearBrushOtherExtent as E } from "../brushHelper/index.js";
import { parseFinder as L } from "../../../util/model/index.js";
var k = ["grid", "xAxis", "yAxis", "geo", "graph", "polar", "radiusAxis", "angleAxis", "bmap"], C = (
  /** @class */
  function() {
    function r(e, i, t) {
      var n = this;
      this._targetInfoList = [];
      var s = m(i, e);
      f(F, function(o, a) {
        (!t || !t.include || v(t.include, a) >= 0) && o(s, n._targetInfoList);
      });
    }
    return c(r, "BrushTargetManager"), r.prototype.setOutputRanges = function(e, i) {
      return this.matchOutputRanges(e, i, function(t, n, s) {
        if ((t.coordRanges || (t.coordRanges = [])).push(n), !t.coordRange) {
          t.coordRange = n;
          var o = x[t.brushType](0, s, n);
          t.__rangeOffset = {
            offset: N[t.brushType](o.values, t.range, [1, 1]),
            xyMinMax: o.xyMinMax
          };
        }
      }), e;
    }, r.prototype.matchOutputRanges = function(e, i, t) {
      f(e, function(n) {
        var s = this.findTargetInfo(n, i);
        s && s !== !0 && f(s.coordSyses, function(o) {
          var a = x[n.brushType](1, o, n.range, !0);
          t(n, a.values, o, i);
        });
      }, this);
    }, r.prototype.setInputRanges = function(e, i) {
      f(e, function(t) {
        var n = this.findTargetInfo(t, i);
        if (process.env.NODE_ENV !== "production" && (h(!n || n === !0 || t.coordRange, "coordRange must be specified when coord index specified."), h(!n || n !== !0 || t.range, "range must be specified in global brush.")), t.range = t.range || [], n && n !== !0) {
          t.panelId = n.panelId;
          var s = x[t.brushType](0, n.coordSys, t.coordRange), o = t.__rangeOffset;
          t.range = o ? N[t.brushType](s.values, o.offset, Y(s.xyMinMax, o.xyMinMax)) : s.values;
        }
      }, this);
    }, r.prototype.makePanelOpts = function(e, i) {
      return p(this._targetInfoList, function(t) {
        var n = t.getPanelRect();
        return {
          panelId: t.panelId,
          defaultBrushType: i ? i(t) : null,
          clipPath: R(n),
          isTargetByCursor: B(n, e, t.coordSysModel),
          getLinearBrushOtherExtent: E(n)
        };
      });
    }, r.prototype.controlSeries = function(e, i, t) {
      var n = this.findTargetInfo(e, t);
      return n === !0 || n && v(n.coordSyses, i.coordinateSystem) >= 0;
    }, r.prototype.findTargetInfo = function(e, i) {
      for (var t = this._targetInfoList, n = m(i, e), s = 0; s < t.length; s++) {
        var o = t[s], a = e.panelId;
        if (a) {
          if (o.panelId === a)
            return o;
        } else
          for (var u = 0; u < T.length; u++)
            if (T[u](n, o))
              return o;
      }
      return !0;
    }, r;
  }()
);
function M(r) {
  return r[0] > r[1] && r.reverse(), r;
}
c(M, "formatMinMax");
function m(r, e) {
  return L(r, e, {
    includeMainTypes: k
  });
}
c(m, "parseFinder");
var F = {
  grid: /* @__PURE__ */ c(function(r, e) {
    var i = r.xAxisModels, t = r.yAxisModels, n = r.gridModels, s = P(), o = {}, a = {};
    !i && !t && !n || (f(i, function(u) {
      var d = u.axis.grid.model;
      s.set(d.id, d), o[d.id] = !0;
    }), f(t, function(u) {
      var d = u.axis.grid.model;
      s.set(d.id, d), a[d.id] = !0;
    }), f(n, function(u) {
      s.set(u.id, u), o[u.id] = !0, a[u.id] = !0;
    }), s.each(function(u) {
      var d = u.coordinateSystem, g = [];
      f(d.getCartesians(), function(y, z) {
        (v(i, y.getAxis("x").model) >= 0 || v(t, y.getAxis("y").model) >= 0) && g.push(y);
      }), e.push({
        panelId: "grid--" + u.id,
        gridModel: u,
        coordSysModel: u,
        // Use the first one as the representitive coordSys.
        coordSys: g[0],
        coordSyses: g,
        getPanelRect: I.grid,
        xAxisDeclared: o[u.id],
        yAxisDeclared: a[u.id]
      });
    }));
  }, "grid"),
  geo: /* @__PURE__ */ c(function(r, e) {
    f(r.geoModels, function(i) {
      var t = i.coordinateSystem;
      e.push({
        panelId: "geo--" + i.id,
        geoModel: i,
        coordSysModel: i,
        coordSys: t,
        coordSyses: [t],
        getPanelRect: I.geo
      });
    });
  }, "geo")
}, T = [
  // grid
  function(r, e) {
    var i = r.xAxisModel, t = r.yAxisModel, n = r.gridModel;
    return !n && i && (n = i.axis.grid.model), !n && t && (n = t.axis.grid.model), n && n === e.gridModel;
  },
  // geo
  function(r, e) {
    var i = r.geoModel;
    return i && i === e.geoModel;
  }
], I = {
  grid: /* @__PURE__ */ c(function() {
    return this.coordSys.master.getRect().clone();
  }, "grid"),
  geo: /* @__PURE__ */ c(function() {
    var r = this.coordSys, e = r.getBoundingRect().clone();
    return e.applyTransform(D(r)), e;
  }, "geo")
}, x = {
  lineX: l(A, 0),
  lineY: l(A, 1),
  rect: /* @__PURE__ */ c(function(r, e, i, t) {
    var n = r ? e.pointToData([i[0][0], i[1][0]], t) : e.dataToPoint([i[0][0], i[1][0]], t), s = r ? e.pointToData([i[0][1], i[1][1]], t) : e.dataToPoint([i[0][1], i[1][1]], t), o = [M([n[0], s[0]]), M([n[1], s[1]])];
    return {
      values: o,
      xyMinMax: o
    };
  }, "rect"),
  polygon: /* @__PURE__ */ c(function(r, e, i, t) {
    var n = [[1 / 0, -1 / 0], [1 / 0, -1 / 0]], s = p(i, function(o) {
      var a = r ? e.pointToData(o, t) : e.dataToPoint(o, t);
      return n[0][0] = Math.min(n[0][0], a[0]), n[1][0] = Math.min(n[1][0], a[1]), n[0][1] = Math.max(n[0][1], a[0]), n[1][1] = Math.max(n[1][1], a[1]), a;
    });
    return {
      values: s,
      xyMinMax: n
    };
  }, "polygon")
};
function A(r, e, i, t) {
  process.env.NODE_ENV !== "production" && h(i.type === "cartesian2d", "lineX/lineY brush is available only in cartesian2d.");
  var n = i.getAxis(["x", "y"][r]), s = M(p([0, 1], function(a) {
    return e ? n.coordToData(n.toLocalCoord(t[a]), !0) : n.toGlobalCoord(n.dataToCoord(t[a]));
  })), o = [];
  return o[r] = s, o[1 - r] = [NaN, NaN], {
    values: s,
    xyMinMax: o
  };
}
c(A, "axisConvert");
var N = {
  lineX: l(S, 0),
  lineY: l(S, 1),
  rect: /* @__PURE__ */ c(function(r, e, i) {
    return [[r[0][0] - i[0] * e[0][0], r[0][1] - i[0] * e[0][1]], [r[1][0] - i[1] * e[1][0], r[1][1] - i[1] * e[1][1]]];
  }, "rect"),
  polygon: /* @__PURE__ */ c(function(r, e, i) {
    return p(r, function(t, n) {
      return [t[0] - i[0] * e[n][0], t[1] - i[1] * e[n][1]];
    });
  }, "polygon")
};
function S(r, e, i, t) {
  return [e[0] - t[r] * i[0], e[1] - t[r] * i[1]];
}
c(S, "axisDiffProcessor");
function Y(r, e) {
  var i = _(r), t = _(e), n = [i[0] / t[0], i[1] / t[1]];
  return isNaN(n[0]) && (n[0] = 1), isNaN(n[1]) && (n[1] = 1), n;
}
c(Y, "getScales");
function _(r) {
  return r ? [r[0][1] - r[0][0], r[1][1] - r[1][0]] : [NaN, NaN];
}
c(_, "getSize");
export {
  C as default
};
