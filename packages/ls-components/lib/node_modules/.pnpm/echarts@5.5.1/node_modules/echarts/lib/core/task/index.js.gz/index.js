var O = Object.defineProperty;
var h = (i, t) => O(i, "name", { value: t, configurable: !0 });
import { assert as c, isArray as x } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
function C(i) {
  return new N(i);
}
h(C, "createTask");
var N = (
  /** @class */
  function() {
    function i(t) {
      t = t || {}, this._reset = t.reset, this._plan = t.plan, this._count = t.count, this._onDirty = t.onDirty, this._dirty = !0;
    }
    return h(i, "Task"), i.prototype.perform = function(t) {
      var s = this._upstream, e = t && t.skip;
      if (this._dirty && s) {
        var n = this.context;
        n.data = n.outputData = s.context.outputData;
      }
      this.__pipeline && (this.__pipeline.currentTask = this);
      var o;
      this._plan && !e && (o = this._plan(this.context));
      var l = d(this._modBy), f = this._modDataCount || 0, r = d(t && t.modBy), u = t && t.modDataCount || 0;
      (l !== r || f !== u) && (o = "reset");
      function d(m) {
        return !(m >= 1) && (m = 1), m;
      }
      h(d, "normalizeModBy");
      var a;
      (this._dirty || o === "reset") && (this._dirty = !1, a = this._doReset(e)), this._modBy = r, this._modDataCount = u;
      var E = t && t.step;
      if (s ? (process.env.NODE_ENV !== "production" && c(s._outputDueEnd != null), this._dueEnd = s._outputDueEnd) : (process.env.NODE_ENV !== "production" && c(!this._progress || this._count), this._dueEnd = this._count ? this._count(this.context) : 1 / 0), this._progress) {
        var y = this._dueIndex, _ = Math.min(E != null ? this._dueIndex + E : 1 / 0, this._dueEnd);
        if (!e && (a || y < _)) {
          var p = this._progress;
          if (x(p))
            for (var v = 0; v < p.length; v++)
              this._doProgress(p[v], y, _, r, u);
          else
            this._doProgress(p, y, _, r, u);
        }
        this._dueIndex = _;
        var D = this._settedOutputEnd != null ? this._settedOutputEnd : _;
        process.env.NODE_ENV !== "production" && c(D >= this._outputDueEnd), this._outputDueEnd = D;
      } else
        this._dueIndex = this._outputDueEnd = this._settedOutputEnd != null ? this._settedOutputEnd : this._dueEnd;
      return this.unfinished();
    }, i.prototype.dirty = function() {
      this._dirty = !0, this._onDirty && this._onDirty(this.context);
    }, i.prototype._doProgress = function(t, s, e, n, o) {
      g.reset(s, e, n, o), this._callingProgress = t, this._callingProgress({
        start: s,
        end: e,
        count: e - s,
        next: g.next
      }, this.context);
    }, i.prototype._doReset = function(t) {
      this._dueIndex = this._outputDueEnd = this._dueEnd = 0, this._settedOutputEnd = null;
      var s, e;
      !t && this._reset && (s = this._reset(this.context), s && s.progress && (e = s.forceFirstProgress, s = s.progress), x(s) && !s.length && (s = null)), this._progress = s, this._modBy = this._modDataCount = null;
      var n = this._downstream;
      return n && n.dirty(), e;
    }, i.prototype.unfinished = function() {
      return this._progress && this._dueIndex < this._dueEnd;
    }, i.prototype.pipe = function(t) {
      process.env.NODE_ENV !== "production" && c(t && !t._disposed && t !== this), (this._downstream !== t || this._dirty) && (this._downstream = t, t._upstream = this, t.dirty());
    }, i.prototype.dispose = function() {
      this._disposed || (this._upstream && (this._upstream._downstream = null), this._downstream && (this._downstream._upstream = null), this._dirty = !1, this._disposed = !0);
    }, i.prototype.getUpstream = function() {
      return this._upstream;
    }, i.prototype.getDownstream = function() {
      return this._downstream;
    }, i.prototype.setOutputEnd = function(t) {
      this._outputDueEnd = this._settedOutputEnd = t;
    }, i;
  }()
), g = /* @__PURE__ */ function() {
  var i, t, s, e, n, o = {
    reset: /* @__PURE__ */ h(function(r, u, d, a) {
      t = r, i = u, s = d, e = a, n = Math.ceil(e / s), o.next = s > 1 && e > 0 ? f : l;
    }, "reset")
  };
  return o;
  function l() {
    return t < i ? t++ : null;
  }
  function f() {
    var r = t % n * s + Math.ceil(t / n), u = t >= i ? null : r < e ? r : t;
    return t++, u;
  }
}();
export {
  N as Task,
  C as createTask
};
