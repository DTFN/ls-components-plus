var E = Object.defineProperty;
var s = (o, e) => E(o, "name", { value: e, configurable: !0 });
import { __extends as w } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { assert as R, merge as m, isTypedArray as x, createHashMap as C, keys as N, isObject as B, mixin as k, each as P, curry as L, concatArray as O } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import F from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/env/index.js";
import { defaultEmphasis as S, isNameSpecified as H, makeInner as V } from "../../util/model/index.js";
import d from "../Component/index.js";
import { PaletteMixin as b } from "../mixin/palette/index.js";
import { DataFormatMixin as j } from "../mixin/dataFormat/index.js";
import { fetchLayoutMode as T, getLayoutParams as U, mergeLayoutParam as _ } from "../../util/layout/index.js";
import { createTask as z } from "../../core/task/index.js";
import { mountExtend as G } from "../../util/clazz/index.js";
import { SourceManager as K } from "../../data/helper/sourceManager/index.js";
import { defaultSeriesFormatTooltip as W } from "../../component/tooltip/seriesFormatTooltip/index.js";
var u = V();
function h(o, e) {
  return o.getName(e) || o.getId(e);
}
s(h, "getSelectionKey");
var J = "__universalTransitionEnabled", y = (
  /** @class */
  function(o) {
    w(e, o);
    function e() {
      var t = o !== null && o.apply(this, arguments) || this;
      return t._selectedDataIndicesMap = {}, t;
    }
    return s(e, "SeriesModel"), e.prototype.init = function(t, a, r) {
      this.seriesIndex = this.componentIndex, this.dataTask = z({
        count: X,
        reset: Y
      }), this.dataTask.context = {
        model: this
      }, this.mergeDefaultAndTheme(t, r);
      var i = u(this).sourceManager = new K(this);
      i.prepareSource();
      var n = this.getInitialData(t, r);
      A(n, this), this.dataTask.context.data = n, process.env.NODE_ENV !== "production" && R(n, "getInitialData returned invalid data."), u(this).dataBeforeProcessed = n, I(this), this._initSelectedMapFromData(n);
    }, e.prototype.mergeDefaultAndTheme = function(t, a) {
      var r = T(this), i = r ? U(t) : {}, n = this.subType;
      d.hasClass(n) && (n += "Series"), m(t, a.getTheme().get(this.subType)), m(t, this.getDefaultOption()), S(t, "label", ["show"]), this.fillDataTextStyle(t.data), r && _(t, i, r);
    }, e.prototype.mergeOption = function(t, a) {
      t = m(this.option, t, !0), this.fillDataTextStyle(t.data);
      var r = T(this);
      r && _(this.option, t, r);
      var i = u(this).sourceManager;
      i.dirty(), i.prepareSource();
      var n = this.getInitialData(t, a);
      A(n, this), this.dataTask.dirty(), this.dataTask.context.data = n, u(this).dataBeforeProcessed = n, I(this), this._initSelectedMapFromData(n);
    }, e.prototype.fillDataTextStyle = function(t) {
      if (t && !x(t))
        for (var a = ["show"], r = 0; r < t.length; r++)
          t[r] && t[r].label && S(t[r], "label", a);
    }, e.prototype.getInitialData = function(t, a) {
    }, e.prototype.appendData = function(t) {
      var a = this.getRawData();
      a.appendData(t.data);
    }, e.prototype.getData = function(t) {
      var a = v(this);
      if (a) {
        var r = a.context.data;
        return t == null || !r.getLinkedData ? r : r.getLinkedData(t);
      } else
        return u(this).data;
    }, e.prototype.getAllData = function() {
      var t = this.getData();
      return t && t.getLinkedDataAll ? t.getLinkedDataAll() : [{
        data: t
      }];
    }, e.prototype.setData = function(t) {
      var a = v(this);
      if (a) {
        var r = a.context;
        r.outputData = t, a !== this.dataTask && (r.data = t);
      }
      u(this).data = t;
    }, e.prototype.getEncode = function() {
      var t = this.get("encode", !0);
      if (t)
        return C(t);
    }, e.prototype.getSourceManager = function() {
      return u(this).sourceManager;
    }, e.prototype.getSource = function() {
      return this.getSourceManager().getSource();
    }, e.prototype.getRawData = function() {
      return u(this).dataBeforeProcessed;
    }, e.prototype.getColorBy = function() {
      var t = this.get("colorBy");
      return t || "series";
    }, e.prototype.isColorBySeries = function() {
      return this.getColorBy() === "series";
    }, e.prototype.getBaseAxis = function() {
      var t = this.coordinateSystem;
      return t && t.getBaseAxis && t.getBaseAxis();
    }, e.prototype.formatTooltip = function(t, a, r) {
      return W({
        series: this,
        dataIndex: t,
        multipleSeries: a
      });
    }, e.prototype.isAnimationEnabled = function() {
      var t = this.ecModel;
      if (F.node && !(t && t.ssr))
        return !1;
      var a = this.getShallow("animation");
      return a && this.getData().count() > this.getShallow("animationThreshold") && (a = !1), !!a;
    }, e.prototype.restoreData = function() {
      this.dataTask.dirty();
    }, e.prototype.getColorFromPalette = function(t, a, r) {
      var i = this.ecModel, n = b.prototype.getColorFromPalette.call(this, t, a, r);
      return n || (n = i.getColorFromPalette(t, a, r)), n;
    }, e.prototype.coordDimToDataDim = function(t) {
      return this.getRawData().mapDimensionsAll(t);
    }, e.prototype.getProgressive = function() {
      return this.get("progressive");
    }, e.prototype.getProgressiveThreshold = function() {
      return this.get("progressiveThreshold");
    }, e.prototype.select = function(t, a) {
      this._innerSelect(this.getData(a), t);
    }, e.prototype.unselect = function(t, a) {
      var r = this.option.selectedMap;
      if (r) {
        var i = this.option.selectedMode, n = this.getData(a);
        if (i === "series" || r === "all") {
          this.option.selectedMap = {}, this._selectedDataIndicesMap = {};
          return;
        }
        for (var l = 0; l < t.length; l++) {
          var p = t[l], f = h(n, p);
          r[f] = !1, this._selectedDataIndicesMap[f] = -1;
        }
      }
    }, e.prototype.toggleSelect = function(t, a) {
      for (var r = [], i = 0; i < t.length; i++)
        r[0] = t[i], this.isSelected(t[i], a) ? this.unselect(r, a) : this.select(r, a);
    }, e.prototype.getSelectedDataIndices = function() {
      if (this.option.selectedMap === "all")
        return [].slice.call(this.getData().getIndices());
      for (var t = this._selectedDataIndicesMap, a = N(t), r = [], i = 0; i < a.length; i++) {
        var n = t[a[i]];
        n >= 0 && r.push(n);
      }
      return r;
    }, e.prototype.isSelected = function(t, a) {
      var r = this.option.selectedMap;
      if (!r)
        return !1;
      var i = this.getData(a);
      return (r === "all" || r[h(i, t)]) && !i.getItemModel(t).get(["select", "disabled"]);
    }, e.prototype.isUniversalTransitionEnabled = function() {
      if (this[J])
        return !0;
      var t = this.option.universalTransition;
      return t ? t === !0 ? !0 : t && t.enabled : !1;
    }, e.prototype._innerSelect = function(t, a) {
      var r, i, n = this.option, l = n.selectedMode, p = a.length;
      if (!(!l || !p)) {
        if (l === "series")
          n.selectedMap = "all";
        else if (l === "multiple") {
          B(n.selectedMap) || (n.selectedMap = {});
          for (var f = n.selectedMap, g = 0; g < p; g++) {
            var D = a[g], c = h(t, D);
            f[c] = !0, this._selectedDataIndicesMap[c] = t.getRawIndex(D);
          }
        } else if (l === "single" || l === !0) {
          var M = a[p - 1], c = h(t, M);
          n.selectedMap = (r = {}, r[c] = !0, r), this._selectedDataIndicesMap = (i = {}, i[c] = t.getRawIndex(M), i);
        }
      }
    }, e.prototype._initSelectedMapFromData = function(t) {
      if (!this.option.selectedMap) {
        var a = [];
        t.hasItemOption && t.each(function(r) {
          var i = t.getRawDataItem(r);
          i && i.selected && a.push(r);
        }), a.length > 0 && this._innerSelect(t, a);
      }
    }, e.registerClass = function(t) {
      return d.registerClass(t);
    }, e.protoInitialize = function() {
      var t = e.prototype;
      t.type = "series.__base__", t.seriesIndex = 0, t.ignoreStyleOnData = !1, t.hasSymbolVisual = !1, t.defaultSymbol = "circle", t.visualStyleAccessPath = "itemStyle", t.visualDrawType = "fill";
    }(), e;
  }(d)
);
k(y, j);
k(y, b);
G(y, d);
function I(o) {
  var e = o.name;
  H(o) || (o.name = Q(o) || e);
}
s(I, "autoSeriesName");
function Q(o) {
  var e = o.getRawData(), t = e.mapDimensionsAll("seriesName"), a = [];
  return P(t, function(r) {
    var i = e.getDimensionInfo(r);
    i.displayName && a.push(i.displayName);
  }), a.join(" ");
}
s(Q, "getSeriesAutoName");
function X(o) {
  return o.model.getRawData().count();
}
s(X, "dataTaskCount");
function Y(o) {
  var e = o.model;
  return e.setData(e.getRawData().cloneShallow()), Z;
}
s(Y, "dataTaskReset");
function Z(o, e) {
  e.outputData && o.end > e.outputData.count() && e.model.getRawData().cloneShallow(e.outputData);
}
s(Z, "dataTaskProgress");
function A(o, e) {
  P(O(o.CHANGABLE_METHODS, o.DOWNSAMPLE_METHODS), function(t) {
    o.wrapMethod(t, L($, e));
  });
}
s(A, "wrapData");
function $(o, e) {
  var t = v(o);
  return t && t.setOutputEnd((e || this).count()), e;
}
s($, "onDataChange");
function v(o) {
  var e = (o.ecModel || {}).scheduler, t = e && e.getPipeline(o.uid);
  if (t) {
    var a = t.currentTask;
    if (a) {
      var r = a.agentStubMap;
      r && (a = r.get(o.uid));
    }
    return a;
  }
}
s(v, "getCurrentTask");
export {
  J as SERIES_UNIVERSAL_TRANSITION_PROP,
  y as default
};
