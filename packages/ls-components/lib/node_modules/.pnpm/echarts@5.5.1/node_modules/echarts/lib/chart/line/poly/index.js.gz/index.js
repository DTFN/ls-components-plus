var g = Object.defineProperty;
var J = (c, v) => g(c, "name", { value: v, configurable: !0 });
import { __extends as O } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import I from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
import S from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/PathProxy/index.js";
import { cubicRootAt as d, cubicAt as X } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/curve/index.js";
var G = Math.min, H = Math.max;
function Q(c, v) {
  return isNaN(c) || isNaN(v);
}
J(Q, "isPointNull");
function L(c, v, u, f, s, o, i, t, m) {
  for (var n, w, b, R, l, h, M = u, T = 0; T < f; T++) {
    var a = v[M * 2], r = v[M * 2 + 1];
    if (M >= s || M < 0)
      break;
    if (Q(a, r)) {
      if (m) {
        M += o;
        continue;
      }
      break;
    }
    if (M === u)
      c[o > 0 ? "moveTo" : "lineTo"](a, r), b = a, R = r;
    else {
      var j = a - n, p = r - w;
      if (j * j + p * p < 0.5) {
        M += o;
        continue;
      }
      if (i > 0) {
        for (var E = M + o, P = v[E * 2], k = v[E * 2 + 1]; P === a && k === r && T < f; )
          T++, E += o, M += o, P = v[E * 2], k = v[E * 2 + 1], a = v[M * 2], r = v[M * 2 + 1], j = a - n, p = r - w;
        var V = T + 1;
        if (m)
          for (; Q(P, k) && V < f; )
            V++, E += o, P = v[E * 2], k = v[E * 2 + 1];
        var U = 0.5, B = 0, F = 0, q = void 0, A = void 0;
        if (V >= f || Q(P, k))
          l = a, h = r;
        else {
          B = P - n, F = k - w;
          var W = a - n, Z = P - a, $ = r - w, K = k - r, z = void 0, D = void 0;
          if (t === "x") {
            z = Math.abs(W), D = Math.abs(Z);
            var C = B > 0 ? 1 : -1;
            l = a - C * z * i, h = r, q = a + C * D * i, A = r;
          } else if (t === "y") {
            z = Math.abs($), D = Math.abs(K);
            var N = F > 0 ? 1 : -1;
            l = a, h = r - N * z * i, q = a, A = r + N * D * i;
          } else
            z = Math.sqrt(W * W + $ * $), D = Math.sqrt(Z * Z + K * K), U = D / (D + z), l = a - B * i * (1 - U), h = r - F * i * (1 - U), q = a + B * i * U, A = r + F * i * U, q = G(q, H(P, a)), A = G(A, H(k, r)), q = H(q, G(P, a)), A = H(A, G(k, r)), B = q - a, F = A - r, l = a - B * z / D, h = r - F * z / D, l = G(l, H(n, a)), h = G(h, H(w, r)), l = H(l, G(n, a)), h = H(h, G(w, r)), B = a - l, F = r - h, q = a + B * D / z, A = r + F * D / z;
        }
        c.bezierCurveTo(b, R, l, h, a, r), b = q, R = A;
      } else
        c.lineTo(a, r);
    }
    n = a, w = r, M += o;
  }
  return T;
}
J(L, "drawSegment");
var _ = (
  /** @class */
  function() {
    function c() {
      this.smooth = 0, this.smoothConstraint = !0;
    }
    return J(c, "ECPolylineShape"), c;
  }()
), oa = (
  /** @class */
  function(c) {
    O(v, c);
    function v(u) {
      var f = c.call(this, u) || this;
      return f.type = "ec-polyline", f;
    }
    return J(v, "ECPolyline"), v.prototype.getDefaultStyle = function() {
      return {
        stroke: "#000",
        fill: null
      };
    }, v.prototype.getDefaultShape = function() {
      return new _();
    }, v.prototype.buildPath = function(u, f) {
      var s = f.points, o = 0, i = s.length / 2;
      if (f.connectNulls) {
        for (; i > 0 && Q(s[i * 2 - 2], s[i * 2 - 1]); i--)
          ;
        for (; o < i && Q(s[o * 2], s[o * 2 + 1]); o++)
          ;
      }
      for (; o < i; )
        o += L(u, s, o, i, i, 1, f.smooth, f.smoothMonotone, f.connectNulls) + 1;
    }, v.prototype.getPointOn = function(u, f) {
      this.path || (this.createPathProxy(), this.buildPath(this.path, this.shape));
      for (var s = this.path, o = s.data, i = S.CMD, t, m, n = f === "x", w = [], b = 0; b < o.length; ) {
        var R = o[b++], l = void 0, h = void 0, M = void 0, T = void 0, a = void 0, r = void 0, j = void 0;
        switch (R) {
          case i.M:
            t = o[b++], m = o[b++];
            break;
          case i.L:
            if (l = o[b++], h = o[b++], j = n ? (u - t) / (l - t) : (u - m) / (h - m), j <= 1 && j >= 0) {
              var p = n ? (h - m) * j + m : (l - t) * j + t;
              return n ? [u, p] : [p, u];
            }
            t = l, m = h;
            break;
          case i.C:
            l = o[b++], h = o[b++], M = o[b++], T = o[b++], a = o[b++], r = o[b++];
            var E = n ? d(t, l, M, a, u, w) : d(m, h, T, r, u, w);
            if (E > 0)
              for (var P = 0; P < E; P++) {
                var k = w[P];
                if (k <= 1 && k >= 0) {
                  var p = n ? X(m, h, T, r, k) : X(t, l, M, a, k);
                  return n ? [u, p] : [p, u];
                }
              }
            t = a, m = r;
            break;
        }
      }
    }, v;
  }(I)
), Y = (
  /** @class */
  function(c) {
    O(v, c);
    function v() {
      return c !== null && c.apply(this, arguments) || this;
    }
    return J(v, "ECPolygonShape"), v;
  }(_)
), ia = (
  /** @class */
  function(c) {
    O(v, c);
    function v(u) {
      var f = c.call(this, u) || this;
      return f.type = "ec-polygon", f;
    }
    return J(v, "ECPolygon"), v.prototype.getDefaultShape = function() {
      return new Y();
    }, v.prototype.buildPath = function(u, f) {
      var s = f.points, o = f.stackedOnPoints, i = 0, t = s.length / 2, m = f.smoothMonotone;
      if (f.connectNulls) {
        for (; t > 0 && Q(s[t * 2 - 2], s[t * 2 - 1]); t--)
          ;
        for (; i < t && Q(s[i * 2], s[i * 2 + 1]); i++)
          ;
      }
      for (; i < t; ) {
        var n = L(u, s, i, t, t, 1, f.smooth, m, f.connectNulls);
        L(u, o, i + n - 1, n, t, -1, f.stackedOnSmooth, m, f.connectNulls), i += n + 1, u.closePath();
      }
    }, v;
  }(I)
);
export {
  ia as ECPolygon,
  oa as ECPolyline
};
