var x = Object.defineProperty;
var v = (a, e) => x(a, "name", { value: e, configurable: !0 });
import { isDimensionStacked as l } from "../../../data/helper/dataStackHelper/index.js";
import { map as p, isNumber as A } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
function P(a, e, t) {
  var i = a.getBaseAxis(), s = a.getOtherAxis(i), m = N(s, t), r = i.dim, f = s.dim, o = e.mapDimension(f), c = e.mapDimension(r), b = f === "x" || f === "radius" ? 1 : 0, n = p(a.dimensions, function(k) {
    return e.mapDimension(k);
  }), D = !1, u = e.getCalculationInfo("stackResultDimension");
  return l(
    e,
    n[0]
    /* , dims[1] */
  ) && (D = !0, n[0] = u), l(
    e,
    n[1]
    /* , dims[0] */
  ) && (D = !0, n[1] = u), {
    dataDimsForPoint: n,
    valueStart: m,
    valueAxisDim: f,
    baseAxisDim: r,
    stacked: !!D,
    valueDim: o,
    baseDim: c,
    baseDataOffset: b,
    stackedOverDimension: e.getCalculationInfo("stackedOverDimension")
  };
}
v(P, "prepareDataCoordInfo");
function N(a, e) {
  var t = 0, i = a.scale.getExtent();
  return e === "start" ? t = i[0] : e === "end" ? t = i[1] : A(e) && !isNaN(e) ? t = e : i[0] > 0 ? t = i[0] : i[1] < 0 && (t = i[1]), t;
}
v(N, "getValueStart");
function R(a, e, t, i) {
  var s = NaN;
  a.stacked && (s = t.get(t.getCalculationInfo("stackedOverDimension"), i)), isNaN(s) && (s = a.valueStart);
  var m = a.baseDataOffset, r = [];
  return r[m] = t.get(a.baseDim, i), r[1 - m] = s, e.dataToPoint(r);
}
v(R, "getStackedOnPoint");
export {
  R as getStackedOnPoint,
  P as prepareDataCoordInfo
};
