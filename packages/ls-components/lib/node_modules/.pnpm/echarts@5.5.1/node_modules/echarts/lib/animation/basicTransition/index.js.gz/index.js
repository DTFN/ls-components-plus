var A = Object.defineProperty;
var v = (i, n) => A(i, "name", { value: n, configurable: !0 });
import { isFunction as p, isObject as F, retrieve2 as S } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { makeInner as P } from "../../util/model/index.js";
var E = P();
function h(i, n, o, e, t) {
  var r;
  if (n && n.ecModel) {
    var f = n.ecModel.getUpdatePayload();
    r = f && f.animation;
  }
  var l = n && n.isAnimationEnabled(), m = i === "update";
  if (l) {
    var a = void 0, u = void 0, s = void 0;
    e ? (a = S(e.duration, 200), u = S(e.easing, "cubicOut"), s = 0) : (a = n.getShallow(m ? "animationDurationUpdate" : "animationDuration"), u = n.getShallow(m ? "animationEasingUpdate" : "animationEasing"), s = n.getShallow(m ? "animationDelayUpdate" : "animationDelay")), r && (r.duration != null && (a = r.duration), r.easing != null && (u = r.easing), r.delay != null && (s = r.delay)), p(s) && (s = s(o, t)), p(a) && (a = a(o));
    var c = {
      duration: a || 0,
      delay: s,
      easing: u
    };
    return c;
  } else
    return null;
}
v(h, "getAnimationConfig");
function g(i, n, o, e, t, r, f) {
  var l = !1, m;
  p(t) ? (f = r, r = t, t = null) : F(t) && (r = t.cb, f = t.during, l = t.isFrom, m = t.removeOpt, t = t.dataIndex);
  var a = i === "leave";
  a || n.stopAnimation("leave");
  var u = h(i, e, t, a ? m || {} : null, e && e.getAnimationDelayParams ? e.getAnimationDelayParams(n, t) : null);
  if (u && u.duration > 0) {
    var s = u.duration, c = u.delay, O = u.easing, y = {
      duration: s,
      delay: c || 0,
      easing: O,
      done: r,
      force: !!r || !!f,
      // Set to final state in update/init animation.
      // So the post processing based on the path shape can be done correctly.
      setToFinal: !a,
      scope: i,
      during: f
    };
    l ? n.animateFrom(o, y) : n.animateTo(o, y);
  } else
    n.stopAnimation(), !l && n.attr(o), f && f(1), r && r();
}
v(g, "animateOrSetProps");
function T(i, n, o, e, t, r) {
  g("update", i, n, o, e, t, r);
}
v(T, "updateProps");
function _(i, n, o, e, t, r) {
  g("enter", i, n, o, e, t, r);
}
v(_, "initProps");
function U(i) {
  if (!i.__zr)
    return !0;
  for (var n = 0; n < i.animators.length; n++) {
    var o = i.animators[n];
    if (o.scope === "leave")
      return !0;
  }
  return !1;
}
v(U, "isElementRemoved");
function w(i, n, o, e, t, r) {
  U(i) || g("leave", i, n, o, e, t, r);
}
v(w, "removeElement");
function D(i, n, o, e) {
  i.removeTextContent(), i.removeTextGuideLine(), w(i, {
    style: {
      opacity: 0
    }
  }, n, o, e);
}
v(D, "fadeOutDisplayable");
function j(i, n, o) {
  function e() {
    i.parent && i.parent.remove(i);
  }
  v(e, "doRemove"), i.isGroup ? i.traverse(function(t) {
    t.isGroup || D(t, n, o, e);
  }) : D(i, n, o, e);
}
v(j, "removeElementWithFadeOut");
function k(i) {
  E(i).oldStyle = i.style;
}
v(k, "saveOldStyle");
function z(i) {
  return E(i).oldStyle;
}
v(z, "getOldStyle");
export {
  h as getAnimationConfig,
  z as getOldStyle,
  _ as initProps,
  U as isElementRemoved,
  w as removeElement,
  j as removeElementWithFadeOut,
  k as saveOldStyle,
  E as transitionStore,
  T as updateProps
};
