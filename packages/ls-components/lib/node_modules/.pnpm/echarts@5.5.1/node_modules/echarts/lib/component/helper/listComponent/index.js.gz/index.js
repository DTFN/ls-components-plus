var y = Object.defineProperty;
var e = (t, i) => y(t, "name", { value: i, configurable: !0 });
import { getLayoutRect as o, box as s, positionElement as u } from "../../../util/layout/index.js";
import { normalizeCssArray as m } from "../../../util/format/index.js";
import v from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
function n(t, i, a) {
  var r = i.getBoxLayoutParams(), g = i.get("padding"), h = {
    width: a.getWidth(),
    height: a.getHeight()
  }, d = o(r, h, g);
  s(i.get("orient"), t, i.get("itemGap"), d.width, d.height), u(t, r, h, g);
}
e(n, "layout");
function p(t, i) {
  var a = m(i.get("padding")), r = i.getItemStyle(["color", "opacity"]);
  return r.fill = i.get("backgroundColor"), t = new v({
    shape: {
      x: t.x - a[3],
      y: t.y - a[0],
      width: t.width + a[1] + a[3],
      height: t.height + a[0] + a[2],
      r: i.get("borderRadius")
    },
    style: r,
    silent: !0,
    z2: -1
  }), t;
}
e(p, "makeBackground");
export {
  n as layout,
  p as makeBackground
};
