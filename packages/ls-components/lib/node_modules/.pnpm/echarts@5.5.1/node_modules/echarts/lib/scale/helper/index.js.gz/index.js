var M = Object.defineProperty;
var o = (r, i) => M(r, "name", { value: i, configurable: !0 });
import { nice as g, round as l, getPrecision as y, quantityExponent as v } from "../../util/number/index.js";
function F(r) {
  var i = Math.pow(10, v(Math.abs(r))), a = Math.abs(r / i);
  return a === 0 || a === 1 || a === 2 || a === 3 || a === 5;
}
o(F, "isValueNice");
function N(r) {
  return r.type === "interval" || r.type === "log";
}
o(N, "isIntervalOrLogScale");
function S(r, i, a, n) {
  var f = {}, c = r[1] - r[0], u = f.interval = g(c / i);
  a != null && u < a && (u = f.interval = a), n != null && u > n && (u = f.interval = n);
  var s = f.intervalPrecision = P(u), h = f.niceTickExtent = [l(Math.ceil(r[0] / u) * u, s), l(Math.floor(r[1] / u) * u, s)];
  return b(h, r), f;
}
o(S, "intervalScaleNiceTicks");
function q(r) {
  var i = Math.pow(10, v(r)), a = r / i;
  return a ? a === 2 ? a = 3 : a === 3 ? a = 5 : a *= 2 : a = 1, l(a * i);
}
o(q, "increaseInterval");
function P(r) {
  return y(r) + 2;
}
o(P, "getIntervalPrecision");
function p(r, i, a) {
  r[i] = Math.max(Math.min(r[i], a[1]), a[0]);
}
o(p, "clamp");
function b(r, i) {
  !isFinite(r[0]) && (r[0] = i[0]), !isFinite(r[1]) && (r[1] = i[1]), p(r, 0, i), p(r, 1, i), r[0] > r[1] && (r[0] = r[1]);
}
o(b, "fixExtent");
function t(r, i) {
  return r >= i[0] && r <= i[1];
}
o(t, "contain");
function z(r, i) {
  return i[1] === i[0] ? 0.5 : (r - i[0]) / (i[1] - i[0]);
}
o(z, "normalize");
function L(r, i) {
  return r * (i[1] - i[0]) + i[0];
}
o(L, "scale");
export {
  t as contain,
  b as fixExtent,
  P as getIntervalPrecision,
  q as increaseInterval,
  S as intervalScaleNiceTicks,
  N as isIntervalOrLogScale,
  F as isValueNice,
  z as normalize,
  L as scale
};
