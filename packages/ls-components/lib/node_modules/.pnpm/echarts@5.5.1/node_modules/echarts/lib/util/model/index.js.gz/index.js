var L = Object.defineProperty;
var u = (n, e) => L(n, "name", { value: e, configurable: !0 });
import { isString as w, createHashMap as T, each as c, indexOf as X, assert as y, isObject as h, isNumber as q, isStringSafe as P, isArray as M, map as S } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import Y from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/env/index.js";
import { isNumeric as p, round as _, getPrecision as g, getRandomIdBase as G } from "../number/index.js";
import { warn as K } from "../log/index.js";
function R(n, e, r) {
  return (e - n) * r + n;
}
u(R, "interpolateNumber");
var B = "series\0", F = "\0_ec_\0";
function ln(n) {
  return n instanceof Array ? n : n == null ? [] : [n];
}
u(ln, "normalizeToArray");
function un(n, e, r) {
  if (n) {
    n[e] = n[e] || {}, n.emphasis = n.emphasis || {}, n.emphasis[e] = n.emphasis[e] || {};
    for (var i = 0, a = r.length; i < a; i++) {
      var l = r[i];
      !n.emphasis[e].hasOwnProperty(l) && n[e].hasOwnProperty(l) && (n.emphasis[e][l] = n[e][l]);
    }
  }
}
u(un, "defaultEmphasis");
var fn = ["fontStyle", "fontWeight", "fontSize", "fontFamily", "rich", "tag", "color", "textBorderColor", "textBorderWidth", "width", "height", "lineHeight", "align", "verticalAlign", "baseline", "shadowColor", "shadowBlur", "shadowOffsetX", "shadowOffsetY", "textShadowColor", "textShadowBlur", "textShadowOffsetX", "textShadowOffsetY", "backgroundColor", "borderColor", "borderWidth", "borderRadius", "padding"];
function on(n) {
  return h(n) && !M(n) && !(n instanceof Date) ? n.value : n;
}
u(on, "getDataItemValue");
function tn(n) {
  return h(n) && !(n instanceof Array);
}
u(tn, "isDataItemOption");
function dn(n, e, r) {
  var i = r === "normalMerge", a = r === "replaceMerge", l = r === "replaceAll";
  n = n || [], e = (e || []).slice();
  var t = T();
  c(e, function(o, v) {
    if (!h(o)) {
      e[v] = null;
      return;
    }
    process.env.NODE_ENV !== "production" && (o.id != null && !D(o.id) && A(o.id), o.name != null && !D(o.name) && A(o.name));
  });
  var f = O(n, t, r);
  return (i || a) && U(f, n, t, e), i && W(f, e), i || a ? z(f, e, a) : l && C(f, e), H(f), f;
}
u(dn, "mappingToExists");
function O(n, e, r) {
  var i = [];
  if (r === "replaceAll")
    return i;
  for (var a = 0; a < n.length; a++) {
    var l = n[a];
    l && l.id != null && e.set(l.id, a), i.push({
      existing: r === "replaceMerge" || b(l) ? null : l,
      newOption: null,
      keyInfo: null,
      brandNew: null
    });
  }
  return i;
}
u(O, "prepareResult");
function U(n, e, r, i) {
  c(i, function(a, l) {
    if (!(!a || a.id == null)) {
      var t = I(a.id), f = r.get(t);
      if (f != null) {
        var o = n[f];
        y(!o.newOption, 'Duplicated option on id "' + t + '".'), o.newOption = a, o.existing = e[f], i[l] = null;
      }
    }
  });
}
u(U, "mappingById");
function W(n, e) {
  c(e, function(r, i) {
    if (!(!r || r.name == null))
      for (var a = 0; a < n.length; a++) {
        var l = n[a].existing;
        if (!n[a].newOption && l && (l.id == null || r.id == null) && !b(r) && !b(l) && k("name", l, r)) {
          n[a].newOption = r, e[i] = null;
          return;
        }
      }
  });
}
u(W, "mappingByName");
function z(n, e, r) {
  c(e, function(i) {
    if (i) {
      for (
        var a, l = 0;
        // Be `!resultItem` only when `nextIdx >= result.length`.
        (a = n[l]) && (a.newOption || b(a.existing) || // In mode "replaceMerge", here no not-mapped-non-internal-existing.
        a.existing && i.id != null && !k("id", i, a.existing));
      )
        l++;
      a ? (a.newOption = i, a.brandNew = r) : n.push({
        newOption: i,
        brandNew: r,
        existing: null,
        keyInfo: null
      }), l++;
    }
  });
}
u(z, "mappingByIndex");
function C(n, e) {
  c(e, function(r) {
    n.push({
      newOption: r,
      brandNew: !0,
      existing: null,
      keyInfo: null
    });
  });
}
u(C, "mappingInReplaceAllMode");
function H(n) {
  var e = T();
  c(n, function(r) {
    var i = r.existing;
    i && e.set(i.id, r);
  }), c(n, function(r) {
    var i = r.newOption;
    y(!i || i.id == null || !e.get(i.id) || e.get(i.id) === r, "id duplicates: " + (i && i.id)), i && i.id != null && e.set(i.id, r), !r.keyInfo && (r.keyInfo = {});
  }), c(n, function(r, i) {
    var a = r.existing, l = r.newOption, t = r.keyInfo;
    if (h(l)) {
      if (t.name = l.name != null ? I(l.name) : a ? a.name : B + i, a)
        t.id = I(a.id);
      else if (l.id != null)
        t.id = I(l.id);
      else {
        var f = 0;
        do
          t.id = "\0" + t.name + "\0" + f++;
        while (e.get(t.id));
      }
      e.set(t.id, r);
    }
  });
}
u(H, "makeIdAndName");
function k(n, e, r) {
  var i = N(e[n], null), a = N(r[n], null);
  return i != null && a != null && i === a;
}
u(k, "keyExistAndEqual");
function I(n) {
  if (process.env.NODE_ENV !== "production" && n == null)
    throw new Error();
  return N(n, "");
}
u(I, "makeComparableKey");
function N(n, e) {
  return n == null ? e : w(n) ? n : q(n) || P(n) ? n + "" : e;
}
u(N, "convertOptionIdName");
function A(n) {
  process.env.NODE_ENV !== "production" && K("`" + n + "` is invalid id or name. Must be a string or number.");
}
u(A, "warnInvalidateIdOrName");
function D(n) {
  return P(n) || p(n);
}
u(D, "isValidIdOrName");
function sn(n) {
  var e = n.name;
  return !!(e && e.indexOf(B));
}
u(sn, "isNameSpecified");
function b(n) {
  return n && n.id != null && I(n.id).indexOf(F) === 0;
}
u(b, "isComponentIdInternal");
function vn(n) {
  return F + n;
}
u(vn, "makeInternalComponentId");
function cn(n, e, r) {
  c(n, function(i) {
    var a = i.newOption;
    h(a) && (i.keyInfo.mainType = e, i.keyInfo.subType = $(e, a, i.existing, r));
  });
}
u(cn, "setComponentTypeToKeyInfo");
function $(n, e, r, i) {
  var a = e.type ? e.type : r ? r.subType : i.determineSubType(n, e);
  return a;
}
u($, "determineSubType");
function In(n, e) {
  if (e.dataIndexInside != null)
    return e.dataIndexInside;
  if (e.dataIndex != null)
    return M(e.dataIndex) ? S(e.dataIndex, function(r) {
      return n.indexOfRawIndex(r);
    }) : n.indexOfRawIndex(e.dataIndex);
  if (e.name != null)
    return M(e.name) ? S(e.name, function(r) {
      return n.indexOfName(r);
    }) : n.indexOfName(e.name);
}
u(In, "queryDataIndex");
function hn() {
  var n = "__ec_inner_" + J++;
  return function(e) {
    return e[n] || (e[n] = {});
  };
}
u(hn, "makeInner");
var J = G();
function xn(n, e, r) {
  var i = Q(e, r), a = i.mainTypeSpecified, l = i.queryOptionMap, t = i.others, f = t, o = r ? r.defaultMainType : null;
  return !a && o && l.set(o, {}), l.each(function(v, s) {
    var d = j(n, s, v, {
      useDefault: o === s,
      enableAll: r && r.enableAll != null ? r.enableAll : !0,
      enableNone: r && r.enableNone != null ? r.enableNone : !0
    });
    f[s + "Models"] = d.models, f[s + "Model"] = d.models[0];
  }), f;
}
u(xn, "parseFinder");
function Q(n, e) {
  var r;
  if (w(n)) {
    var i = {};
    i[n + "Index"] = 0, r = i;
  } else
    r = n;
  var a = T(), l = {}, t = !1;
  return c(r, function(f, o) {
    if (o === "dataIndex" || o === "dataIndexInside") {
      l[o] = f;
      return;
    }
    var v = o.match(/^(\w+)(Index|Id|Name)$/) || [], s = v[1], d = (v[2] || "").toLowerCase();
    if (!(!s || !d || e && e.includeMainTypes && X(e.includeMainTypes, s) < 0)) {
      t = t || !!s;
      var x = a.get(s) || a.set(s, {});
      x[d] = f;
    }
  }), {
    mainTypeSpecified: t,
    queryOptionMap: a,
    others: l
  };
}
u(Q, "preParseFinder");
var Z = {
  useDefault: !0,
  enableAll: !1,
  enableNone: !1
}, gn = {
  useDefault: !1,
  enableAll: !0,
  enableNone: !0
};
function j(n, e, r, i) {
  i = i || Z;
  var a = r.index, l = r.id, t = r.name, f = {
    models: null,
    specified: a != null || l != null || t != null
  };
  if (!f.specified) {
    var o = void 0;
    return f.models = i.useDefault && (o = n.getComponent(e)) ? [o] : [], f;
  }
  return a === "none" || a === !1 ? (y(i.enableNone, '`"none"` or `false` is not a valid value on index option.'), f.models = [], f) : (a === "all" && (y(i.enableAll, '`"all"` is not a valid value on index option.'), a = l = t = null), f.models = n.queryComponents({
    mainType: e,
    index: a,
    id: l,
    name: t
  }), f);
}
u(j, "queryReferringComponents");
function yn(n, e, r) {
  n.setAttribute ? n.setAttribute(e, r) : n[e] = r;
}
u(yn, "setAttribute");
function bn(n, e) {
  return n.getAttribute ? n.getAttribute(e) : n[e];
}
u(bn, "getAttribute");
function Mn(n) {
  return n === "auto" ? Y.domSupported ? "html" : "richText" : n || "html";
}
u(Mn, "getTooltipRenderMode");
function Nn(n, e, r, i, a) {
  var l = e == null || e === "auto";
  if (i == null)
    return i;
  if (q(i)) {
    var t = R(r || 0, i, a);
    return _(t, l ? Math.max(g(r || 0), g(i)) : e);
  } else {
    if (w(i))
      return a < 1 ? r : i;
    for (var f = [], o = r, v = i, s = Math.max(o ? o.length : 0, v.length), d = 0; d < s; ++d) {
      var x = n.getDimensionInfo(d);
      if (x && x.type === "ordinal")
        f[d] = (a < 1 && o ? o : v)[d];
      else {
        var E = o && o[d] ? o[d] : 0, m = v[d], t = R(E, m, a);
        f[d] = _(t, l ? Math.max(g(E), g(m)) : e);
      }
    }
    return f;
  }
}
u(Nn, "interpolateRawValues");
export {
  gn as MULTIPLE_REFERRING,
  Z as SINGLE_REFERRING,
  fn as TEXT_STYLE_OPTIONS,
  N as convertOptionIdName,
  un as defaultEmphasis,
  bn as getAttribute,
  on as getDataItemValue,
  Mn as getTooltipRenderMode,
  Nn as interpolateRawValues,
  b as isComponentIdInternal,
  tn as isDataItemOption,
  sn as isNameSpecified,
  hn as makeInner,
  vn as makeInternalComponentId,
  dn as mappingToExists,
  ln as normalizeToArray,
  xn as parseFinder,
  Q as preParseFinder,
  In as queryDataIndex,
  j as queryReferringComponents,
  yn as setAttribute,
  cn as setComponentTypeToKeyInfo
};
