var N = Object.defineProperty;
var s = (n, t) => N(n, "name", { value: t, configurable: !0 });
import { isTypedArray as O, clone as E, isArray as p, isObject as S, hasOwn as I, isArrayLike as D, isNumber as T, each as x, assert as F, keys as L, createHashMap as U, map as B, isString as M } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { SOURCE_FORMAT_TYPED_ARRAY as v, SOURCE_FORMAT_ORIGINAL as d, SOURCE_FORMAT_OBJECT_ROWS as y, SOURCE_FORMAT_KEYED_COLUMNS as a, SOURCE_FORMAT_UNKNOWN as g, SERIES_LAYOUT_BY_COLUMN as Y, SOURCE_FORMAT_ARRAY_ROWS as _, SERIES_LAYOUT_BY_ROW as A } from "../../util/types/index.js";
import { getDataItemValue as b } from "../../util/model/index.js";
import { guessOrdinal as k, BE_ORDINAL as W } from "../helper/sourceHelper/index.js";
var c = (
  /** @class */
  function() {
    function n(t) {
      this.data = t.data || (t.sourceFormat === a ? {} : []), this.sourceFormat = t.sourceFormat || g, this.seriesLayoutBy = t.seriesLayoutBy || Y, this.startIndex = t.startIndex || 0, this.dimensionsDetectedCount = t.dimensionsDetectedCount, this.metaRawOption = t.metaRawOption;
      var r = this.dimensionsDefine = t.dimensionsDefine;
      if (r)
        for (var i = 0; i < r.length; i++) {
          var e = r[i];
          e.type == null && k(this, i) === W.Must && (e.type = "ordinal");
        }
    }
    return s(n, "SourceImpl"), n;
  }()
);
function Q(n) {
  return n instanceof c;
}
s(Q, "isSourceInstance");
function X(n, t, r) {
  r = r || j(n);
  var i = t.seriesLayoutBy, e = K(n, r, i, t.sourceHeader, t.dimensions), o = new c({
    data: n,
    sourceFormat: r,
    seriesLayoutBy: i,
    dimensionsDefine: e.dimensionsDefine,
    startIndex: e.startIndex,
    dimensionsDetectedCount: e.dimensionsDetectedCount,
    metaRawOption: E(t)
  });
  return o;
}
s(X, "createSource");
function Z(n) {
  return new c({
    data: n,
    sourceFormat: O(n) ? v : d
  });
}
s(Z, "createSourceFromSeriesDataOption");
function $(n) {
  return new c({
    data: n.data,
    sourceFormat: n.sourceFormat,
    seriesLayoutBy: n.seriesLayoutBy,
    dimensionsDefine: E(n.dimensionsDefine),
    startIndex: n.startIndex,
    dimensionsDetectedCount: n.dimensionsDetectedCount
  });
}
s($, "cloneSourceShallow");
function j(n) {
  var t = g;
  if (O(n))
    t = v;
  else if (p(n)) {
    n.length === 0 && (t = _);
    for (var r = 0, i = n.length; r < i; r++) {
      var e = n[r];
      if (e != null) {
        if (p(e) || O(e)) {
          t = _;
          break;
        } else if (S(e)) {
          t = y;
          break;
        }
      }
    }
  } else if (S(n)) {
    for (var o in n)
      if (I(n, o) && D(n[o])) {
        t = a;
        break;
      }
  }
  return t;
}
s(j, "detectSourceFormat");
function K(n, t, r, i, e) {
  var o, u;
  if (!n)
    return {
      dimensionsDefine: R(e),
      startIndex: u,
      dimensionsDetectedCount: o
    };
  if (t === _) {
    var f = n;
    i === "auto" || i == null ? C(function(l) {
      l != null && l !== "-" && (M(l) ? u == null && (u = 1) : u = 0);
    }, r, f, 10) : u = T(i) ? i : i ? 1 : 0, !e && u === 1 && (e = [], C(function(l, m) {
      e[m] = l != null ? l + "" : "";
    }, r, f, 1 / 0)), o = e ? e.length : r === A ? f.length : f[0] ? f[0].length : null;
  } else if (t === y)
    e || (e = V(n));
  else if (t === a)
    e || (e = [], x(n, function(l, m) {
      e.push(m);
    }));
  else if (t === d) {
    var h = b(n[0]);
    o = p(h) && h.length || 1;
  } else t === v && process.env.NODE_ENV !== "production" && F(!!e, "dimensions must be given if data is TypedArray.");
  return {
    startIndex: u,
    dimensionsDefine: R(e),
    dimensionsDetectedCount: o
  };
}
s(K, "determineSourceDimensions");
function V(n) {
  for (var t = 0, r; t < n.length && !(r = n[t++]); )
    ;
  if (r)
    return L(r);
}
s(V, "objectRowsCollectDimensions");
function R(n) {
  if (n) {
    var t = U();
    return B(n, function(r, i) {
      r = S(r) ? r : {
        name: r
      };
      var e = {
        name: r.name,
        displayName: r.displayName,
        type: r.type
      };
      if (e.name == null)
        return e;
      e.name += "", e.displayName == null && (e.displayName = e.name);
      var o = t.get(e.name);
      return o ? e.name += "-" + o.count++ : t.set(e.name, {
        count: 1
      }), e;
    });
  }
}
s(R, "normalizeDimensionsOption");
function C(n, t, r, i) {
  if (t === A)
    for (var e = 0; e < r.length && e < i; e++)
      n(r[e] ? r[e][0] : null, e);
  else
    for (var o = r[0] || [], e = 0; e < o.length && e < i; e++)
      n(o[e], e);
}
s(C, "arrayRowsTravelFirst");
function w(n) {
  var t = n.sourceFormat;
  return t === y || t === a;
}
s(w, "shouldRetrieveDataByName");
export {
  $ as cloneSourceShallow,
  X as createSource,
  Z as createSourceFromSeriesDataOption,
  j as detectSourceFormat,
  Q as isSourceInstance,
  w as shouldRetrieveDataByName
};
