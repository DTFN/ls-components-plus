var a = Object.defineProperty;
var e = (o, r) => a(o, "name", { value: r, configurable: !0 });
import { curry as m } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { createProgressiveLayout as I, layout as p } from "../../../layout/barGrid/index.js";
import c from "../../../processor/dataSample/index.js";
import f from "../BarSeries/index.js";
import S from "../BarView/index.js";
function L(o) {
  o.registerChartView(S), o.registerSeriesModel(f), o.registerLayout(o.PRIORITY.VISUAL.LAYOUT, m(p, "bar")), o.registerLayout(o.PRIORITY.VISUAL.PROGRESSIVE_LAYOUT, I("bar")), o.registerProcessor(o.PRIORITY.PROCESSOR.STATISTIC, c("bar")), o.registerAction({
    type: "changeAxisOrder",
    event: "changeAxisOrder",
    update: "update"
  }, function(r, t) {
    var n = r.componentType || "series";
    t.eachComponent({
      mainType: n,
      query: r
    }, function(i) {
      r.sortInfo && i.axis.setCategorySortInfo(r.sortInfo);
    });
  });
}
e(L, "install");
export {
  L as install
};
