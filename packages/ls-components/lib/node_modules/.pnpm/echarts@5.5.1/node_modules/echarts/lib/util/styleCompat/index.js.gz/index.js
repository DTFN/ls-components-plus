var g = Object.defineProperty;
var a = (n, t) => g(n, "name", { value: t, configurable: !0 });
import { hasOwn as o, each as S } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
function w(n, t, d, e) {
  return n && (n.legacy || n.legacy !== !1 && !d && !e && t !== "tspan" && (t === "text" || o(n, "text")));
}
a(w, "isEC4CompatibleStyle");
function W(n, t, d) {
  var e = n, i, l, x;
  if (t === "text")
    x = e;
  else {
    x = {}, o(e, "text") && (x.text = e.text), o(e, "rich") && (x.rich = e.rich), o(e, "textFill") && (x.fill = e.textFill), o(e, "textStroke") && (x.stroke = e.textStroke), o(e, "fontFamily") && (x.fontFamily = e.fontFamily), o(e, "fontSize") && (x.fontSize = e.fontSize), o(e, "fontStyle") && (x.fontStyle = e.fontStyle), o(e, "fontWeight") && (x.fontWeight = e.fontWeight), l = {
      type: "text",
      style: x,
      // ec4 does not support rectText trigger.
      // And when text position is different in normal and emphasis
      // => hover text trigger emphasis;
      // => text position changed, leave mouse pointer immediately;
      // That might cause incorrect state.
      silent: !0
    }, i = {};
    var s = o(e, "textPosition");
    i.position = s ? e.textPosition : "inside", o(e, "textPosition") && (i.position = e.textPosition), o(e, "textOffset") && (i.offset = e.textOffset), o(e, "textRotation") && (i.rotation = e.textRotation), o(e, "textDistance") && (i.distance = e.textDistance);
  }
  return r(x, n), S(x.rich, function(f) {
    r(f, f);
  }), {
    textConfig: i,
    textContent: l
  };
}
a(W, "convertFromEC4CompatibleStyle");
function r(n, t) {
  t && (t.font = t.textFont || t.font, o(t, "textStrokeWidth") && (n.lineWidth = t.textStrokeWidth), o(t, "textAlign") && (n.align = t.textAlign), o(t, "textVerticalAlign") && (n.verticalAlign = t.textVerticalAlign), o(t, "textLineHeight") && (n.lineHeight = t.textLineHeight), o(t, "textWidth") && (n.width = t.textWidth), o(t, "textHeight") && (n.height = t.textHeight), o(t, "textBackgroundColor") && (n.backgroundColor = t.textBackgroundColor), o(t, "textPadding") && (n.padding = t.textPadding), o(t, "textBorderColor") && (n.borderColor = t.textBorderColor), o(t, "textBorderWidth") && (n.borderWidth = t.textBorderWidth), o(t, "textBorderRadius") && (n.borderRadius = t.textBorderRadius), o(t, "textBoxShadowColor") && (n.shadowColor = t.textBoxShadowColor), o(t, "textBoxShadowBlur") && (n.shadowBlur = t.textBoxShadowBlur), o(t, "textBoxShadowOffsetX") && (n.shadowOffsetX = t.textBoxShadowOffsetX), o(t, "textBoxShadowOffsetY") && (n.shadowOffsetY = t.textBoxShadowOffsetY));
}
a(r, "convertEC4CompatibleRichItem");
export {
  W as convertFromEC4CompatibleStyle,
  w as isEC4CompatibleStyle
};
