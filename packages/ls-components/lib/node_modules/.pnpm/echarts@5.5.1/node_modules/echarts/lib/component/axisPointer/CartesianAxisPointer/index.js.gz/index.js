var y = Object.defineProperty;
var g = (a, r) => y(a, "name", { value: r, configurable: !0 });
import { __extends as b } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import P from "../BaseAxisPointer/index.js";
import { buildElStyle as A, buildCartesianSingleLabelElOption as C, getTransformedPosition as I, makeLineShape as E, makeRectShape as S } from "../viewHelper/index.js";
import { layout as c } from "../../../coord/cartesian/cartesianAxisHelper/index.js";
var D = (
  /** @class */
  function(a) {
    b(r, a);
    function r() {
      return a !== null && a.apply(this, arguments) || this;
    }
    return g(r, "CartesianAxisPointer"), r.prototype.makeElOption = function(t, e, l, s, n) {
      var u = l.axis, m = u.grid, d = s.get("type"), i = f(m, u).getOtherAxis(u).getGlobalExtent(), o = u.toGlobalCoord(u.dataToCoord(e, !0));
      if (d && d !== "none") {
        var v = A(s), p = T[d](u, o, i);
        p.style = v, t.graphicKey = p.type, t.pointer = p;
      }
      var x = c(m.model, l);
      C(
        // @ts-ignore
        e,
        t,
        x,
        l,
        s,
        n
      );
    }, r.prototype.getHandleTransform = function(t, e, l) {
      var s = c(e.axis.grid.model, e, {
        labelInside: !1
      });
      s.labelMargin = l.get(["handle", "margin"]);
      var n = I(e.axis, t, s);
      return {
        x: n[0],
        y: n[1],
        rotation: s.rotation + (s.labelDirection < 0 ? Math.PI : 0)
      };
    }, r.prototype.updateHandleTransform = function(t, e, l, s) {
      var n = l.axis, u = n.grid, m = n.getGlobalExtent(!0), d = f(u, n).getOtherAxis(n).getGlobalExtent(), i = n.dim === "x" ? 0 : 1, o = [t.x, t.y];
      o[i] += e[i], o[i] = Math.min(m[1], o[i]), o[i] = Math.max(m[0], o[i]);
      var v = (d[1] + d[0]) / 2, p = [v, v];
      p[i] = o[i];
      var x = [{
        verticalAlign: "middle"
      }, {
        align: "center"
      }];
      return {
        x: o[0],
        y: o[1],
        rotation: t.rotation,
        cursorPoint: p,
        tooltipOption: x[i]
      };
    }, r;
  }(P)
);
function f(a, r) {
  var t = {};
  return t[r.dim + "AxisIndex"] = r.index, a.getCartesian(t);
}
g(f, "getCartesian");
var T = {
  line: /* @__PURE__ */ g(function(a, r, t) {
    var e = E([r, t[0]], [r, t[1]], h(a));
    return {
      type: "Line",
      subPixelOptimize: !0,
      shape: e
    };
  }, "line"),
  shadow: /* @__PURE__ */ g(function(a, r, t) {
    var e = Math.max(1, a.getBandWidth()), l = t[1] - t[0];
    return {
      type: "Rect",
      shape: S([r - e / 2, t[0]], [e, l], h(a))
    };
  }, "shadow")
};
function h(a) {
  return a.dim === "x" ? 0 : 1;
}
g(h, "getAxisDimIndex");
export {
  D as default
};
