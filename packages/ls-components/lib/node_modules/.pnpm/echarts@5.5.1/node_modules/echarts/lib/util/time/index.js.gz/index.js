var P = Object.defineProperty;
var a = (e, t) => P(e, "name", { value: t, configurable: !0 });
import { isString as R, isFunction as V, extend as k, defaults as Q, isArray as j, isNumber as z } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { parseDate as D } from "../number/index.js";
import { getLocaleModel as B, getDefaultLocaleModel as I, SYSTEM_LANG as J } from "../../core/locale/index.js";
import K from "../../model/Model/index.js";
var X = 1e3, Z = X * 60, U = Z * 60, T = U * 24, oe = T * 365, h = {
  year: "{yyyy}",
  month: "{MMM}",
  day: "{d}",
  hour: "{HH}:{mm}",
  minute: "{HH}:{mm}",
  second: "{HH}:{mm}:{ss}",
  millisecond: "{HH}:{mm}:{ss} {SSS}",
  none: "{yyyy}-{MM}-{dd} {HH}:{mm}:{ss} {SSS}"
}, S = "{yyyy}-{MM}-{dd}", ue = {
  year: "{yyyy}",
  month: "{yyyy}-{MM}",
  day: S,
  hour: S + " " + h.hour,
  minute: S + " " + h.minute,
  second: S + " " + h.second,
  millisecond: h.none
}, H = ["year", "month", "day", "hour", "minute", "second", "millisecond"], $ = ["year", "half-year", "quarter", "month", "week", "half-week", "day", "half-day", "quarter-day", "hour", "minute", "second", "millisecond"];
function y(e, t) {
  return e += "", "0000".substr(0, t - e.length) + e;
}
a(y, "pad");
function C(e) {
  switch (e) {
    case "half-year":
    case "quarter":
      return "month";
    case "week":
    case "half-week":
      return "day";
    case "half-day":
    case "quarter-day":
      return "hour";
    default:
      return e;
  }
}
a(C, "getPrimaryTimeUnit");
function se(e) {
  return e === C(e);
}
a(se, "isPrimaryTimeUnit");
function ce(e) {
  switch (e) {
    case "year":
    case "month":
      return "day";
    case "millisecond":
      return "millisecond";
    default:
      return "second";
  }
}
a(ce, "getDefaultFormatPrecisionOfInterval");
function ee(e, t, r, n) {
  var o = D(e), l = o[G(r)](), u = o[g(r)]() + 1, c = Math.floor((u - 1) / 3) + 1, i = o[O(r)](), s = o["get" + (r ? "UTC" : "") + "Day"](), m = o[N(r)](), d = (m - 1) % 12 + 1, v = o[b(r)](), f = o[A(r)](), M = o[Y(r)](), E = m >= 12 ? "pm" : "am", F = E.toUpperCase(), q = n instanceof K ? n : B(n || J) || I(), p = q.getModel("time"), _ = p.get("month"), L = p.get("monthAbbr"), W = p.get("dayOfWeek"), x = p.get("dayOfWeekAbbr");
  return (t || "").replace(/{a}/g, E + "").replace(/{A}/g, F + "").replace(/{yyyy}/g, l + "").replace(/{yy}/g, y(l % 100 + "", 2)).replace(/{Q}/g, c + "").replace(/{MMMM}/g, _[u - 1]).replace(/{MMM}/g, L[u - 1]).replace(/{MM}/g, y(u, 2)).replace(/{M}/g, u + "").replace(/{dd}/g, y(i, 2)).replace(/{d}/g, i + "").replace(/{eeee}/g, W[s]).replace(/{ee}/g, x[s]).replace(/{e}/g, s + "").replace(/{HH}/g, y(m, 2)).replace(/{H}/g, m + "").replace(/{hh}/g, y(d + "", 2)).replace(/{h}/g, d + "").replace(/{mm}/g, y(v, 2)).replace(/{m}/g, v + "").replace(/{ss}/g, y(f, 2)).replace(/{s}/g, f + "").replace(/{SSS}/g, y(M, 3)).replace(/{S}/g, M + "");
}
a(ee, "format");
function ie(e, t, r, n, o) {
  var l = null;
  if (R(r))
    l = r;
  else if (V(r))
    l = r(e.value, t, {
      level: e.level
    });
  else {
    var u = k({}, h);
    if (e.level > 0)
      for (var c = 0; c < H.length; ++c)
        u[H[c]] = "{primary|" + u[H[c]] + "}";
    var i = r ? r.inherit === !1 ? r : Q(r, u) : u, s = w(e.value, o);
    if (i[s])
      l = i[s];
    else if (i.inherit) {
      for (var m = $.indexOf(s), c = m - 1; c >= 0; --c)
        if (i[s]) {
          l = i[s];
          break;
        }
      l = l || u.none;
    }
    if (j(l)) {
      var d = e.level == null ? 0 : e.level >= 0 ? e.level : l.length + e.level;
      d = Math.min(d, l.length - 1), l = l[d];
    }
  }
  return ee(new Date(e.value), l, o, n);
}
a(ie, "leveledFormat");
function w(e, t) {
  var r = D(e), n = r[g(t)]() + 1, o = r[O(t)](), l = r[N(t)](), u = r[b(t)](), c = r[A(t)](), i = r[Y(t)](), s = i === 0, m = s && c === 0, d = m && u === 0, v = d && l === 0, f = v && o === 1, M = f && n === 1;
  return M ? "year" : f ? "month" : v ? "day" : d ? "hour" : m ? "minute" : s ? "second" : "millisecond";
}
a(w, "getUnitFromValue");
function me(e, t, r) {
  var n = z(e) ? D(e) : e;
  switch (t = t || w(e, r), t) {
    case "year":
      return n[G(r)]();
    case "half-year":
      return n[g(r)]() >= 6 ? 1 : 0;
    case "quarter":
      return Math.floor((n[g(r)]() + 1) / 4);
    case "month":
      return n[g(r)]();
    case "day":
      return n[O(r)]();
    case "half-day":
      return n[N(r)]() / 24;
    case "hour":
      return n[N(r)]();
    case "minute":
      return n[b(r)]();
    case "second":
      return n[A(r)]();
    case "millisecond":
      return n[Y(r)]();
  }
}
a(me, "getUnitValue");
function G(e) {
  return e ? "getUTCFullYear" : "getFullYear";
}
a(G, "fullYearGetterName");
function g(e) {
  return e ? "getUTCMonth" : "getMonth";
}
a(g, "monthGetterName");
function O(e) {
  return e ? "getUTCDate" : "getDate";
}
a(O, "dateGetterName");
function N(e) {
  return e ? "getUTCHours" : "getHours";
}
a(N, "hoursGetterName");
function b(e) {
  return e ? "getUTCMinutes" : "getMinutes";
}
a(b, "minutesGetterName");
function A(e) {
  return e ? "getUTCSeconds" : "getSeconds";
}
a(A, "secondsGetterName");
function Y(e) {
  return e ? "getUTCMilliseconds" : "getMilliseconds";
}
a(Y, "millisecondsGetterName");
function de(e) {
  return e ? "setUTCFullYear" : "setFullYear";
}
a(de, "fullYearSetterName");
function ye(e) {
  return e ? "setUTCMonth" : "setMonth";
}
a(ye, "monthSetterName");
function ve(e) {
  return e ? "setUTCDate" : "setDate";
}
a(ve, "dateSetterName");
function fe(e) {
  return e ? "setUTCHours" : "setHours";
}
a(fe, "hoursSetterName");
function he(e) {
  return e ? "setUTCMinutes" : "setMinutes";
}
a(he, "minutesSetterName");
function ge(e) {
  return e ? "setUTCSeconds" : "setSeconds";
}
a(ge, "secondsSetterName");
function Me(e) {
  return e ? "setUTCMilliseconds" : "setMilliseconds";
}
a(Me, "millisecondsSetterName");
export {
  T as ONE_DAY,
  U as ONE_HOUR,
  Z as ONE_MINUTE,
  X as ONE_SECOND,
  oe as ONE_YEAR,
  O as dateGetterName,
  ve as dateSetterName,
  h as defaultLeveledFormatter,
  ee as format,
  ue as fullLeveledFormatter,
  G as fullYearGetterName,
  de as fullYearSetterName,
  ce as getDefaultFormatPrecisionOfInterval,
  C as getPrimaryTimeUnit,
  w as getUnitFromValue,
  me as getUnitValue,
  N as hoursGetterName,
  fe as hoursSetterName,
  se as isPrimaryTimeUnit,
  ie as leveledFormat,
  Y as millisecondsGetterName,
  Me as millisecondsSetterName,
  b as minutesGetterName,
  he as minutesSetterName,
  g as monthGetterName,
  ye as monthSetterName,
  y as pad,
  H as primaryTimeUnits,
  A as secondsGetterName,
  ge as secondsSetterName,
  $ as timeUnits
};
