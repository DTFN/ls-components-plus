var I = Object.defineProperty;
var p = (o, e) => I(o, "name", { value: e, configurable: !0 });
import { traverseElements as M } from "../../../util/graphic/index.js";
import E from "../Symbol/index.js";
import { isObject as G } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getLabelStatesModels as P } from "../../../label/labelStyle/index.js";
import A from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import { updateProps as D } from "../../../animation/basicTransition/index.js";
function y(o, e, t, r) {
  return e && !isNaN(e[0]) && !isNaN(e[1]) && !(r.isIgnore && r.isIgnore(t)) && !(r.clipShape && !r.clipShape.contain(e[0], e[1])) && o.getItemVisual(t, "symbol") !== "none";
}
p(y, "symbolNeedsDraw");
function b(o) {
  return o != null && !G(o) && (o = {
    isIgnore: o
  }), o || {};
}
p(b, "normalizeUpdateOpt");
function d(o) {
  var e = o.hostModel, t = e.getModel("emphasis");
  return {
    emphasisItemStyle: t.getModel("itemStyle").getItemStyle(),
    blurItemStyle: e.getModel(["blur", "itemStyle"]).getItemStyle(),
    selectItemStyle: e.getModel(["select", "itemStyle"]).getItemStyle(),
    focus: t.get("focus"),
    blurScope: t.get("blurScope"),
    emphasisDisabled: t.get("disabled"),
    hoverScale: t.get("scale"),
    labelStatesModels: P(e),
    cursorStyle: e.get("cursor")
  };
}
p(d, "makeSeriesScope");
var V = (
  /** @class */
  function() {
    function o(e) {
      this.group = new A(), this._SymbolCtor = e || E;
    }
    return p(o, "SymbolDraw"), o.prototype.updateData = function(e, t) {
      this._progressiveEls = null, t = b(t);
      var r = this.group, l = e.hostModel, a = this._data, c = this._SymbolCtor, n = t.disableAnimation, u = d(e), v = {
        disableAnimation: n
      }, f = t.getSymbolPoint || function(s) {
        return e.getItemLayout(s);
      };
      a || r.removeAll(), e.diff(a).add(function(s) {
        var m = f(s);
        if (y(e, m, s, t)) {
          var i = new c(e, s, u, v);
          i.setPosition(m), e.setItemGraphicEl(s, i), r.add(i);
        }
      }).update(function(s, m) {
        var i = a.getItemGraphicEl(m), h = f(s);
        if (!y(e, h, s, t)) {
          r.remove(i);
          return;
        }
        var _ = e.getItemVisual(s, "symbol") || "circle", g = i && i.getSymbolType && i.getSymbolType();
        if (!i || g && g !== _)
          r.remove(i), i = new c(e, s, u, v), i.setPosition(h);
        else {
          i.updateData(e, s, u, v);
          var S = {
            x: h[0],
            y: h[1]
          };
          n ? i.attr(S) : D(i, S, l);
        }
        r.add(i), e.setItemGraphicEl(s, i);
      }).remove(function(s) {
        var m = a.getItemGraphicEl(s);
        m && m.fadeOut(function() {
          r.remove(m);
        }, l);
      }).execute(), this._getSymbolPoint = f, this._data = e;
    }, o.prototype.updateLayout = function() {
      var e = this, t = this._data;
      t && t.eachItemGraphicEl(function(r, l) {
        var a = e._getSymbolPoint(l);
        r.setPosition(a), r.markRedraw();
      });
    }, o.prototype.incrementalPrepareUpdate = function(e) {
      this._seriesScope = d(e), this._data = null, this.group.removeAll();
    }, o.prototype.incrementalUpdate = function(e, t, r) {
      this._progressiveEls = [], r = b(r);
      function l(u) {
        u.isGroup || (u.incremental = !0, u.ensureState("emphasis").hoverLayer = !0);
      }
      p(l, "updateIncrementalAndHover");
      for (var a = e.start; a < e.end; a++) {
        var c = t.getItemLayout(a);
        if (y(t, c, a, r)) {
          var n = new this._SymbolCtor(t, a, this._seriesScope);
          n.traverse(l), n.setPosition(c), this.group.add(n), t.setItemGraphicEl(a, n), this._progressiveEls.push(n);
        }
      }
    }, o.prototype.eachRendered = function(e) {
      M(this._progressiveEls || this.group, e);
    }, o.prototype.remove = function(e) {
      var t = this.group, r = this._data;
      r && e ? r.eachItemGraphicEl(function(l) {
        l.fadeOut(function() {
          t.remove(l);
        }, r.hostModel);
      }) : t.removeAll();
    }, o;
  }()
);
export {
  V as default
};
