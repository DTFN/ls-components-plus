var b = Object.defineProperty;
var C = (c, p) => b(c, "name", { value: p, configurable: !0 });
import { __extends as H } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { each as T, curry as O, isString as B, bind as Z, isFunction as j } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getBoundingRect as q } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/contain/text/index.js";
import { createIcon as G, setTooltipConfig as J } from "../../../util/graphic/index.js";
import { enterEmphasis as R, leaveEmphasis as z } from "../../../util/states/index.js";
import K from "../../../model/Model/index.js";
import L from "../../../data/DataDiffer/index.js";
import { layout as Q, makeBackground as Y } from "../../helper/listComponent/index.js";
import $ from "../../../view/Component/index.js";
import { getFeature as N, ToolboxFeature as w } from "../featureManager/index.js";
import { getUID as X } from "../../../util/component/index.js";
import A from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import { getFont as M } from "../../../label/labelStyle/index.js";
var vt = (
  /** @class */
  function(c) {
    H(p, c);
    function p() {
      return c !== null && c.apply(this, arguments) || this;
    }
    return C(p, "ToolboxView"), p.prototype.render = function(i, m, e, d) {
      var g = this.group;
      if (g.removeAll(), !i.get("show"))
        return;
      var x = +i.get("itemSize"), I = i.get("orient") === "vertical", P = i.get("feature") || {}, E = this._features || (this._features = {}), F = [];
      T(P, function(r, h) {
        F.push(h);
      }), new L(this._featureNames || [], F).add(k).update(k).remove(O(k, null)).execute(), this._featureNames = F;
      function k(r, h) {
        var o = F[r], v = F[h], n = P[o], s = new K(n, i, i.ecModel), t;
        if (d && d.newTitle != null && d.featureName === o && (n.title = d.newTitle), o && !v) {
          if (tt(o))
            t = {
              onclick: s.option.onclick,
              featureName: o
            };
          else {
            var l = N(o);
            if (!l)
              return;
            t = new l();
          }
          E[o] = t;
        } else if (t = E[v], !t)
          return;
        t.uid = X("toolbox-feature"), t.model = s, t.ecModel = m, t.api = e;
        var u = t instanceof w;
        if (!o && v) {
          u && t.dispose && t.dispose(m, e);
          return;
        }
        if (!s.get("show") || u && t.unusable) {
          u && t.remove && t.remove(m, e);
          return;
        }
        D(s, t, o), s.setIconStatus = function(S, y) {
          var a = this.option, f = this.iconPaths;
          a.iconStatus = a.iconStatus || {}, a.iconStatus[S] = y, f[S] && (y === "emphasis" ? R : z)(f[S]);
        }, t instanceof w && t.render && t.render(s, m, e, d);
      }
      C(k, "processFeature");
      function D(r, h, o) {
        var v = r.getModel("iconStyle"), n = r.getModel(["emphasis", "iconStyle"]), s = h instanceof w && h.getIcons ? h.getIcons() : r.get("icon"), t = r.get("title") || {}, l, u;
        B(s) ? (l = {}, l[o] = s) : l = s, B(t) ? (u = {}, u[o] = t) : u = t;
        var S = r.iconPaths = {};
        T(l, function(y, a) {
          var f = G(y, {}, {
            x: -x / 2,
            y: -x / 2,
            width: x,
            height: x
          });
          f.setStyle(v.getItemStyle());
          var W = f.ensureState("emphasis");
          W.style = n.getItemStyle();
          var _ = new A({
            style: {
              text: u[a],
              align: n.get("textAlign"),
              borderRadius: n.get("textBorderRadius"),
              padding: n.get("textPadding"),
              fill: null,
              font: M({
                fontStyle: n.get("textFontStyle"),
                fontFamily: n.get("textFontFamily"),
                fontSize: n.get("textFontSize"),
                fontWeight: n.get("textFontWeight")
              }, m)
            },
            ignore: !0
          });
          f.setTextContent(_), J({
            el: f,
            componentModel: i,
            itemName: a,
            formatterParamsExtra: {
              title: u[a]
            }
          }), f.__title = u[a], f.on("mouseover", function() {
            var V = n.getItemStyle(), U = I ? i.get("right") == null && i.get("left") !== "right" ? "right" : "left" : i.get("bottom") == null && i.get("top") !== "bottom" ? "bottom" : "top";
            _.setStyle({
              fill: n.get("textFill") || V.fill || V.stroke || "#000",
              backgroundColor: n.get("textBackgroundColor")
            }), f.setTextConfig({
              position: n.get("textPosition") || U
            }), _.ignore = !i.get("showTitle"), e.enterEmphasis(this);
          }).on("mouseout", function() {
            r.get(["iconStatus", a]) !== "emphasis" && e.leaveEmphasis(this), _.hide();
          }), (r.get(["iconStatus", a]) === "emphasis" ? R : z)(f), g.add(f), f.on("click", Z(h.onclick, h, m, e, a)), S[a] = f;
        });
      }
      C(D, "createIconPaths"), Q(g, i, e), g.add(Y(g.getBoundingRect(), i)), I || g.eachChild(function(r) {
        var h = r.__title, o = r.ensureState("emphasis"), v = o.textConfig || (o.textConfig = {}), n = r.getTextContent(), s = n && n.ensureState("emphasis");
        if (s && !j(s) && h) {
          var t = s.style || (s.style = {}), l = q(h, A.makeFont(t)), u = r.x + g.x, S = r.y + g.y + x, y = !1;
          S + l.height > e.getHeight() && (v.position = "top", y = !0);
          var a = y ? -5 - l.height : x + 10;
          u + l.width / 2 > e.getWidth() ? (v.position = ["100%", a], t.align = "right") : u - l.width / 2 < 0 && (v.position = [0, a], t.align = "left");
        }
      });
    }, p.prototype.updateView = function(i, m, e, d) {
      T(this._features, function(g) {
        g instanceof w && g.updateView && g.updateView(g.model, m, e, d);
      });
    }, p.prototype.remove = function(i, m) {
      T(this._features, function(e) {
        e instanceof w && e.remove && e.remove(i, m);
      }), this.group.removeAll();
    }, p.prototype.dispose = function(i, m) {
      T(this._features, function(e) {
        e instanceof w && e.dispose && e.dispose(i, m);
      });
    }, p.type = "toolbox", p;
  }($)
);
function tt(c) {
  return c.indexOf("my") === 0;
}
C(tt, "isUserFeatureName");
export {
  vt as default
};
