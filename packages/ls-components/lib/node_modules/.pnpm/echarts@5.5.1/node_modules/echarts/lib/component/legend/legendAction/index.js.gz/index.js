var d = Object.defineProperty;
var g = (e, t) => d(e, "name", { value: t, configurable: !0 });
import { curry as i, each as A } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
function r(e, t, a) {
  var n = {}, u = e === "toggleSelected", s;
  return a.eachComponent("legend", function(c) {
    u && s != null ? c[s ? "select" : "unSelect"](t.name) : e === "allSelect" || e === "inverseSelect" ? c[e]() : (c[e](t.name), s = c.isSelected(t.name));
    var v = c.getData();
    A(v, function(f) {
      var l = f.get("name");
      if (!(l === `
` || l === "")) {
        var S = c.isSelected(l);
        n.hasOwnProperty(l) ? n[l] = n[l] && S : n[l] = S;
      }
    });
  }), e === "allSelect" || e === "inverseSelect" ? {
    selected: n
  } : {
    name: t.name,
    selected: n
  };
}
g(r, "legendSelectActionHandler");
function D(e) {
  e.registerAction("legendToggleSelect", "legendselectchanged", i(r, "toggleSelected")), e.registerAction("legendAllSelect", "legendselectall", i(r, "allSelect")), e.registerAction("legendInverseSelect", "legendinverseselect", i(r, "inverseSelect")), e.registerAction("legendSelect", "legendselected", i(r, "select")), e.registerAction("legendUnSelect", "legendunselected", i(r, "unSelect"));
}
g(D, "installLegendAction");
export {
  D as installLegendAction
};
