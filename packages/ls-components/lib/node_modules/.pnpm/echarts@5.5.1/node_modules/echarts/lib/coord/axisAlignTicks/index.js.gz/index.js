var w = Object.defineProperty;
var M = (i, v) => w(i, "name", { value: v, configurable: !0 });
import { round as s, getPrecisionSafe as b } from "../../util/number/index.js";
import S from "../../scale/Interval/index.js";
import { getScaleExtent as y } from "../axisHelper/index.js";
import { warn as P } from "../../util/log/index.js";
import { increaseInterval as p, isValueNice as V } from "../../scale/helper/index.js";
var u = Math.log;
function z(i, v, c) {
  var l = S.prototype, x = l.getTicks.call(c), T = l.getTicks.call(c, !0), n = x.length - 1, E = l.getInterval.call(c), m = y(i, v), e = m.extent, o = m.fixMin, f = m.fixMax;
  if (i.type === "log") {
    var h = u(i.base);
    e = [u(e[0]) / h, u(e[1]) / h];
  }
  i.setExtent(e[0], e[1]), i.calcNiceExtent({
    splitNumber: n,
    fixMin: o,
    fixMax: f
  });
  var k = l.getExtent.call(i);
  o && (e[0] = k[0]), f && (e[1] = k[1]);
  var t = l.getInterval.call(i), r = e[0], a = e[1];
  if (o && f)
    t = (a - r) / n;
  else if (o)
    for (a = e[0] + t * n; a < e[1] && isFinite(a) && isFinite(e[1]); )
      t = p(t), a = e[0] + t * n;
  else if (f)
    for (r = e[1] - t * n; r > e[0] && isFinite(r) && isFinite(e[0]); )
      t = p(t), r = e[1] - t * n;
  else {
    var d = i.getTicks().length - 1;
    d > n && (t = p(t));
    var g = t * n;
    a = Math.ceil(e[1] / t) * t, r = s(a - g), r < 0 && e[0] >= 0 ? (r = 0, a = s(g)) : a > 0 && e[1] <= 0 && (a = 0, r = -s(g));
  }
  var N = (x[0].value - T[0].value) / E, F = (x[n].value - T[n].value) / E;
  if (l.setExtent.call(i, r + t * N, a + t * F), l.setInterval.call(i, t), (N || F) && l.setNiceExtent.call(i, r + t, a - t), process.env.NODE_ENV !== "production") {
    var I = l.getTicks.call(i);
    I[1] && (!V(t) || b(I[1].value) > b(t)) && P(
      // eslint-disable-next-line
      "The ticks may be not readable when set min: " + v.get("min") + ", max: " + v.get("max") + " and alignTicks: true"
    );
  }
}
M(z, "alignScaleTicks");
export {
  z as alignScaleTicks
};
