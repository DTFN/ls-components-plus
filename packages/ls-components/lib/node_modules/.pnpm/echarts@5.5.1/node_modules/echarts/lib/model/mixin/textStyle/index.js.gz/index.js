var a = Object.defineProperty;
var r = (t, e) => a(t, "name", { value: e, configurable: !0 });
import { getFont as h } from "../../../label/labelStyle/index.js";
import g from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
var f = ["textStyle", "color"], n = ["fontStyle", "fontWeight", "fontSize", "fontFamily", "padding", "lineHeight", "rich", "width", "height", "overflow"], i = new g(), y = (
  /** @class */
  function() {
    function t() {
    }
    return r(t, "TextStyleMixin"), t.prototype.getTextColor = function(e) {
      var o = this.ecModel;
      return this.getShallow("color") || (!e && o ? o.get(f) : null);
    }, t.prototype.getFont = function() {
      return h({
        fontStyle: this.getShallow("fontStyle"),
        fontWeight: this.getShallow("fontWeight"),
        fontSize: this.getShallow("fontSize"),
        fontFamily: this.getShallow("fontFamily")
      }, this.ecModel);
    }, t.prototype.getTextRect = function(e) {
      for (var o = {
        text: e,
        verticalAlign: this.getShallow("verticalAlign") || this.getShallow("baseline")
      }, l = 0; l < n.length; l++)
        o[n[l]] = this.getShallow(n[l]);
      return i.useStyle(o), i.update(), i.getBoundingRect();
    }, t;
  }()
);
export {
  y as default
};
