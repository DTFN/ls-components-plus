var ft = Object.defineProperty;
var _ = (v, n) => ft(v, "name", { value: n, configurable: !0 });
import { __extends as pt } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { defaults as $, isFunction as V, isNumber as gt, map as mt, each as lt } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import ct from "../../helper/SymbolDraw/index.js";
import st from "../../helper/Symbol/index.js";
import yt from "../lineAnimationDiff/index.js";
import { queryDataIndex as j, interpolateRawValues as dt } from "../../../util/model/index.js";
import { ECPolyline as _t, ECPolygon as bt } from "../poly/index.js";
import F from "../../../view/Chart/index.js";
import { prepareDataCoordInfo as St, getStackedOnPoint as xt } from "../helper/index.js";
import { createGridClipPath as wt, createPolarClipPath as It } from "../../helper/createClipPathFromCoordSys/index.js";
import { isCoordinateSystemType as Dt } from "../../../coord/CoordinateSystem/index.js";
import { setStatesStylesFromModel as K, toggleHoverEmphasis as Q, setStatesFlag as Y, SPECIAL_STATES as M } from "../../../util/states/index.js";
import { setLabelStyle as Lt, getLabelStatesModels as Pt, labelInner as Nt } from "../../../label/labelStyle/index.js";
import { getDefaultInterpolatedLabel as At, getDefaultLabel as Et } from "../../helper/labelHelper/index.js";
import { getECData as H } from "../../../util/innerStore/index.js";
import { createFloat32Array as Ct } from "../../../util/vendor/index.js";
import { convertToColorString as tt } from "../../../util/format/index.js";
import { lerp as Ot } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/tool/color/index.js";
import kt from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import Gt from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import Tt from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/LinearGradient/index.js";
import { initProps as Vt, updateProps as et } from "../../../animation/basicTransition/index.js";
function at(v, n) {
  if (v.length === n.length) {
    for (var t = 0; t < v.length; t++)
      if (v[t] !== n[t])
        return;
    return !0;
  }
}
_(at, "isPointsSame");
function rt(v) {
  for (var n = 1 / 0, t = 1 / 0, i = -1 / 0, r = -1 / 0, a = 0; a < v.length; ) {
    var e = v[a++], l = v[a++];
    isNaN(e) || (n = Math.min(e, n), i = Math.max(e, i)), isNaN(l) || (t = Math.min(l, t), r = Math.max(l, r));
  }
  return [[n, t], [i, r]];
}
_(rt, "bboxFromPoints");
function nt(v, n) {
  var t = rt(v), i = t[0], r = t[1], a = rt(n), e = a[0], l = a[1];
  return Math.max(Math.abs(i[0] - e[0]), Math.abs(i[1] - e[1]), Math.abs(r[0] - l[0]), Math.abs(r[1] - l[1]));
}
_(nt, "getBoundingDiff");
function it(v) {
  return gt(v) ? v : v ? 0.5 : 0;
}
_(it, "getSmooth");
function Ft(v, n, t) {
  if (!t.valueDim)
    return [];
  for (var i = n.count(), r = Ct(i * 2), a = 0; a < i; a++) {
    var e = xt(t, v, n, a);
    r[a * 2] = e[0], r[a * 2 + 1] = e[1];
  }
  return r;
}
_(Ft, "getStackedOnPoints");
function C(v, n, t, i) {
  var r = n.getBaseAxis(), a = r.dim === "x" || r.dim === "radius" ? 0 : 1, e = [], l = 0, s = [], o = [], h = [], u = [];
  if (i) {
    for (l = 0; l < v.length; l += 2)
      !isNaN(v[l]) && !isNaN(v[l + 1]) && u.push(v[l], v[l + 1]);
    v = u;
  }
  for (l = 0; l < v.length - 2; l += 2)
    switch (h[0] = v[l + 2], h[1] = v[l + 3], o[0] = v[l], o[1] = v[l + 1], e.push(o[0], o[1]), t) {
      case "end":
        s[a] = h[a], s[1 - a] = o[1 - a], e.push(s[0], s[1]);
        break;
      case "middle":
        var f = (o[a] + h[a]) / 2, p = [];
        s[a] = p[a] = f, s[1 - a] = o[1 - a], p[1 - a] = h[1 - a], e.push(s[0], s[1]), e.push(p[0], p[1]);
        break;
      default:
        s[a] = o[a], s[1 - a] = h[1 - a], e.push(s[0], s[1]);
    }
  return e.push(v[l++], v[l++]), e;
}
_(C, "turnPointsIntoStep");
function Ht(v, n) {
  var t = [], i = v.length, r, a;
  function e(h, u, f) {
    var p = h.coord, b = (f - p) / (u.coord - p), g = Ot(b, [h.color, u.color]);
    return {
      coord: f,
      color: g
    };
  }
  _(e, "lerpStop");
  for (var l = 0; l < i; l++) {
    var s = v[l], o = s.coord;
    if (o < 0)
      r = s;
    else if (o > n) {
      a ? t.push(e(a, s, n)) : r && t.push(e(r, s, 0), e(r, s, n));
      break;
    } else
      r && (t.push(e(r, s, 0)), r = null), t.push(s), a = s;
  }
  return t;
}
_(Ht, "clipColorStops");
function zt(v, n, t) {
  var i = v.getVisual("visualMeta");
  if (!(!i || !i.length || !v.count())) {
    if (n.type !== "cartesian2d") {
      process.env.NODE_ENV !== "production" && console.warn("Visual map on line style is only supported on cartesian2d.");
      return;
    }
    for (var r, a, e = i.length - 1; e >= 0; e--) {
      var l = v.getDimensionInfo(i[e].dimension);
      if (r = l && l.coordDim, r === "x" || r === "y") {
        a = i[e];
        break;
      }
    }
    if (!a) {
      process.env.NODE_ENV !== "production" && console.warn("Visual map on line style only support x or y dimension.");
      return;
    }
    var s = n.getAxis(r), o = mt(a.stops, function(c) {
      return {
        coord: s.toGlobalCoord(s.dataToCoord(c.value)),
        color: c.color
      };
    }), h = o.length, u = a.outerColors.slice();
    h && o[0].coord > o[h - 1].coord && (o.reverse(), u.reverse());
    var f = Ht(o, r === "x" ? t.getWidth() : t.getHeight()), p = f.length;
    if (!p && h)
      return o[0].coord < 0 ? u[1] ? u[1] : o[h - 1].color : u[0] ? u[0] : o[0].color;
    var b = 10, g = f[0].coord - b, m = f[p - 1].coord + b, y = m - g;
    if (y < 1e-3)
      return "transparent";
    lt(f, function(c) {
      c.offset = (c.coord - g) / y;
    }), f.push({
      // NOTE: inRangeStopLen may still be 0 if stoplen is zero.
      offset: p ? f[p - 1].offset : 0.5,
      color: u[1] || "transparent"
    }), f.unshift({
      offset: p ? f[0].offset : 0.5,
      color: u[0] || "transparent"
    });
    var x = new Tt(0, 0, 0, 0, f, !0);
    return x[r] = g, x[r + "2"] = m, x;
  }
}
_(zt, "getVisualGradient");
function Bt(v, n, t) {
  var i = v.get("showAllSymbol"), r = i === "auto";
  if (!(i && !r)) {
    var a = t.getAxesByScale("ordinal")[0];
    if (a && !(r && Rt(a, n))) {
      var e = n.mapDimension(a.dim), l = {};
      return lt(a.getViewLabels(), function(s) {
        var o = a.scale.getRawOrdinalNumber(s.tickValue);
        l[o] = 1;
      }), function(s) {
        return !l.hasOwnProperty(n.get(e, s));
      };
    }
  }
}
_(Bt, "getIsIgnoreFunc");
function Rt(v, n) {
  var t = v.getExtent(), i = Math.abs(t[1] - t[0]) / v.scale.count();
  isNaN(i) && (i = 0);
  for (var r = n.count(), a = Math.max(1, Math.round(r / 5)), e = 0; e < r; e += a)
    if (st.getSymbolSize(
      n,
      e
      // Only for cartesian, where `isHorizontal` exists.
    )[v.isHorizontal() ? 1 : 0] * 1.5 > i)
      return !1;
  return !0;
}
_(Rt, "canShowAllSymbolForCategory");
function Xt(v, n) {
  return isNaN(v) || isNaN(n);
}
_(Xt, "isPointNull");
function Ut(v) {
  for (var n = v.length / 2; n > 0 && Xt(v[n * 2 - 2], v[n * 2 - 1]); n--)
    ;
  return n - 1;
}
_(Ut, "getLastIndexNotNull");
function ot(v, n) {
  return [v[n * 2], v[n * 2 + 1]];
}
_(ot, "getPointAtIndex");
function Wt(v, n, t) {
  for (var i = v.length / 2, r = t === "x" ? 0 : 1, a, e, l = 0, s = -1, o = 0; o < i; o++)
    if (e = v[o * 2 + r], !(isNaN(e) || isNaN(v[o * 2 + 1 - r]))) {
      if (o === 0) {
        a = e;
        continue;
      }
      if (a <= n && e >= n || a >= n && e <= n) {
        s = o;
        break;
      }
      l = o, a = e;
    }
  return {
    range: [l, s],
    t: (n - a) / (e - a)
  };
}
_(Wt, "getIndexRange");
function vt(v) {
  if (v.get(["endLabel", "show"]))
    return !0;
  for (var n = 0; n < M.length; n++)
    if (v.get([M[n], "endLabel", "show"]))
      return !0;
  return !1;
}
_(vt, "anyStateShowEndLabel");
function z(v, n, t, i) {
  if (Dt(n, "cartesian2d")) {
    var r = i.getModel("endLabel"), a = r.get("valueAnimation"), e = i.getData(), l = {
      lastFrameIndex: 0
    }, s = vt(i) ? function(p, b) {
      v._endLabelOnDuring(p, b, e, l, a, r, n);
    } : null, o = n.getBaseAxis().isHorizontal(), h = wt(n, t, i, function() {
      var p = v._endLabel;
      p && t && l.originalX != null && p.attr({
        x: l.originalX,
        y: l.originalY
      });
    }, s);
    if (!i.get("clip", !0)) {
      var u = h.shape, f = Math.max(u.width, u.height);
      o ? (u.y -= f, u.height += f * 2) : (u.x -= f, u.width += f * 2);
    }
    return s && s(1, h), h;
  } else
    return process.env.NODE_ENV !== "production" && i.get(["endLabel", "show"]) && console.warn("endLabel is not supported for lines in polar systems."), It(n, t, i);
}
_(z, "createLineClipPath");
function Jt(v, n) {
  var t = n.getBaseAxis(), i = t.isHorizontal(), r = t.inverse, a = i ? r ? "right" : "left" : "center", e = i ? "middle" : r ? "top" : "bottom";
  return {
    normal: {
      align: v.get("align") || a,
      verticalAlign: v.get("verticalAlign") || e
    }
  };
}
_(Jt, "getEndLabelStateSpecified");
var me = (
  /** @class */
  function(v) {
    pt(n, v);
    function n() {
      return v !== null && v.apply(this, arguments) || this;
    }
    return _(n, "LineView"), n.prototype.init = function() {
      var t = new kt(), i = new ct();
      this.group.add(i.group), this._symbolDraw = i, this._lineGroup = t;
    }, n.prototype.render = function(t, i, r) {
      var a = this, e = t.coordinateSystem, l = this.group, s = t.getData(), o = t.getModel("lineStyle"), h = t.getModel("areaStyle"), u = s.getLayout("points") || [], f = e.type === "polar", p = this._coordSys, b = this._symbolDraw, g = this._polyline, m = this._polygon, y = this._lineGroup, x = !i.ssr && t.get("animation"), c = !h.isEmpty(), D = h.get("origin"), E = St(e, s, D), d = c && Ft(e, s, E), L = t.get("showSymbol"), w = t.get("connectNulls"), I = L && !f && Bt(t, s, e), A = this._data;
      A && A.eachItemGraphicEl(function(N, ht) {
        N.__temp && (l.remove(N), A.setItemGraphicEl(ht, null));
      }), L || b.remove(), l.add(y);
      var P = f ? !1 : t.get("step"), S;
      e && e.getArea && t.get("clip", !0) && (S = e.getArea(), S.width != null ? (S.x -= 0.1, S.y -= 0.1, S.width += 0.2, S.height += 0.2) : S.r0 && (S.r0 -= 0.5, S.r += 0.5)), this._clipShapeForSymbol = S;
      var O = zt(s, e, r) || s.getVisual("style")[s.getVisual("drawType")];
      if (!(g && p.type === e.type && P === this._step))
        L && b.updateData(s, {
          isIgnore: I,
          clipShape: S,
          disableAnimation: !0,
          getSymbolPoint: /* @__PURE__ */ _(function(N) {
            return [u[N * 2], u[N * 2 + 1]];
          }, "getSymbolPoint")
        }), x && this._initSymbolLabelAnimation(s, e, S), P && (u = C(u, e, P, w), d && (d = C(d, e, P, w))), g = this._newPolyline(u), c ? m = this._newPolygon(u, d) : m && (y.remove(m), m = this._polygon = null), f || this._initOrUpdateEndLabel(t, e, tt(O)), y.setClipPath(z(this, e, !0, t));
      else {
        c && !m ? m = this._newPolygon(u, d) : m && !c && (y.remove(m), m = this._polygon = null), f || this._initOrUpdateEndLabel(t, e, tt(O));
        var G = y.getClipPath();
        if (G) {
          var T = z(this, e, !1, t);
          Vt(G, {
            shape: T.shape
          }, t);
        } else
          y.setClipPath(z(this, e, !0, t));
        L && b.updateData(s, {
          isIgnore: I,
          clipShape: S,
          disableAnimation: !0,
          getSymbolPoint: /* @__PURE__ */ _(function(N) {
            return [u[N * 2], u[N * 2 + 1]];
          }, "getSymbolPoint")
        }), (!at(this._stackedOnPoints, d) || !at(this._points, u)) && (x ? this._doUpdateAnimation(s, d, e, r, P, D, w) : (P && (u = C(u, e, P, w), d && (d = C(d, e, P, w))), g.setShape({
          points: u
        }), m && m.setShape({
          points: u,
          stackedOnPoints: d
        })));
      }
      var k = t.getModel("emphasis"), B = k.get("focus"), R = k.get("blurScope"), X = k.get("disabled");
      if (g.useStyle($(
        // Use color in lineStyle first
        o.getLineStyle(),
        {
          fill: "none",
          stroke: O,
          lineJoin: "bevel"
        }
      )), K(g, t, "lineStyle"), g.style.lineWidth > 0 && t.get(["emphasis", "lineStyle", "width"]) === "bolder") {
        var ut = g.getState("emphasis").style;
        ut.lineWidth = +g.style.lineWidth + 1;
      }
      H(g).seriesIndex = t.seriesIndex, Q(g, B, R, X);
      var U = it(t.get("smooth")), W = t.get("smoothMonotone");
      if (g.setShape({
        smooth: U,
        smoothMonotone: W,
        connectNulls: w
      }), m) {
        var J = s.getCalculationInfo("stackedOnSeries"), Z = 0;
        m.useStyle($(h.getAreaStyle(), {
          fill: O,
          opacity: 0.7,
          lineJoin: "bevel",
          decal: s.getVisual("style").decal
        })), J && (Z = it(J.get("smooth"))), m.setShape({
          smooth: U,
          stackedOnSmooth: Z,
          smoothMonotone: W,
          connectNulls: w
        }), K(m, t, "areaStyle"), H(m).seriesIndex = t.seriesIndex, Q(m, B, R, X);
      }
      var q = /* @__PURE__ */ _(function(N) {
        a._changePolyState(N);
      }, "changePolyState");
      s.eachItemGraphicEl(function(N) {
        N && (N.onHoverStateChange = q);
      }), this._polyline.onHoverStateChange = q, this._data = s, this._coordSys = e, this._stackedOnPoints = d, this._points = u, this._step = P, this._valueOrigin = D, t.get("triggerLineEvent") && (this.packEventData(t, g), m && this.packEventData(t, m));
    }, n.prototype.packEventData = function(t, i) {
      H(i).eventData = {
        componentType: "series",
        componentSubType: "line",
        componentIndex: t.componentIndex,
        seriesIndex: t.seriesIndex,
        seriesName: t.name,
        seriesType: "line"
      };
    }, n.prototype.highlight = function(t, i, r, a) {
      var e = t.getData(), l = j(e, a);
      if (this._changePolyState("emphasis"), !(l instanceof Array) && l != null && l >= 0) {
        var s = e.getLayout("points"), o = e.getItemGraphicEl(l);
        if (!o) {
          var h = s[l * 2], u = s[l * 2 + 1];
          if (isNaN(h) || isNaN(u) || this._clipShapeForSymbol && !this._clipShapeForSymbol.contain(h, u))
            return;
          var f = t.get("zlevel") || 0, p = t.get("z") || 0;
          o = new st(e, l), o.x = h, o.y = u, o.setZ(f, p);
          var b = o.getSymbolPath().getTextContent();
          b && (b.zlevel = f, b.z = p, b.z2 = this._polyline.z2 + 1), o.__temp = !0, e.setItemGraphicEl(l, o), o.stopSymbolAnimation(!0), this.group.add(o);
        }
        o.highlight();
      } else
        F.prototype.highlight.call(this, t, i, r, a);
    }, n.prototype.downplay = function(t, i, r, a) {
      var e = t.getData(), l = j(e, a);
      if (this._changePolyState("normal"), l != null && l >= 0) {
        var s = e.getItemGraphicEl(l);
        s && (s.__temp ? (e.setItemGraphicEl(l, null), this.group.remove(s)) : s.downplay());
      } else
        F.prototype.downplay.call(this, t, i, r, a);
    }, n.prototype._changePolyState = function(t) {
      var i = this._polygon;
      Y(this._polyline, t), i && Y(i, t);
    }, n.prototype._newPolyline = function(t) {
      var i = this._polyline;
      return i && this._lineGroup.remove(i), i = new _t({
        shape: {
          points: t
        },
        segmentIgnoreThreshold: 2,
        z2: 10
      }), this._lineGroup.add(i), this._polyline = i, i;
    }, n.prototype._newPolygon = function(t, i) {
      var r = this._polygon;
      return r && this._lineGroup.remove(r), r = new bt({
        shape: {
          points: t,
          stackedOnPoints: i
        },
        segmentIgnoreThreshold: 2
      }), this._lineGroup.add(r), this._polygon = r, r;
    }, n.prototype._initSymbolLabelAnimation = function(t, i, r) {
      var a, e, l = i.getBaseAxis(), s = l.inverse;
      i.type === "cartesian2d" ? (a = l.isHorizontal(), e = !1) : i.type === "polar" && (a = l.dim === "angle", e = !0);
      var o = t.hostModel, h = o.get("animationDuration");
      V(h) && (h = h(null));
      var u = o.get("animationDelay") || 0, f = V(u) ? u(null) : u;
      t.eachItemGraphicEl(function(p, b) {
        var g = p;
        if (g) {
          var m = [p.x, p.y], y = void 0, x = void 0, c = void 0;
          if (r)
            if (e) {
              var D = r, E = i.pointToCoord(m);
              a ? (y = D.startAngle, x = D.endAngle, c = -E[1] / 180 * Math.PI) : (y = D.r0, x = D.r, c = E[0]);
            } else {
              var d = r;
              a ? (y = d.x, x = d.x + d.width, c = p.x) : (y = d.y + d.height, x = d.y, c = p.y);
            }
          var L = x === y ? 0 : (c - y) / (x - y);
          s && (L = 1 - L);
          var w = V(u) ? u(b) : h * L + f, I = g.getSymbolPath(), A = I.getTextContent();
          g.attr({
            scaleX: 0,
            scaleY: 0
          }), g.animateTo({
            scaleX: 1,
            scaleY: 1
          }, {
            duration: 200,
            setToFinal: !0,
            delay: w
          }), A && A.animateFrom({
            style: {
              opacity: 0
            }
          }, {
            duration: 300,
            delay: w
          }), I.disableLabelAnimation = !0;
        }
      });
    }, n.prototype._initOrUpdateEndLabel = function(t, i, r) {
      var a = t.getModel("endLabel");
      if (vt(t)) {
        var e = t.getData(), l = this._polyline, s = e.getLayout("points");
        if (!s) {
          l.removeTextContent(), this._endLabel = null;
          return;
        }
        var o = this._endLabel;
        o || (o = this._endLabel = new Gt({
          z2: 200
          // should be higher than item symbol
        }), o.ignoreClip = !0, l.setTextContent(this._endLabel), l.disableLabelAnimation = !0);
        var h = Ut(s);
        h >= 0 && (Lt(l, Pt(t, "endLabel"), {
          inheritColor: r,
          labelFetcher: t,
          labelDataIndex: h,
          defaultText: /* @__PURE__ */ _(function(u, f, p) {
            return p != null ? At(e, p) : Et(e, u);
          }, "defaultText"),
          enableTextSetter: !0
        }, Jt(a, i)), l.textConfig.position = null);
      } else this._endLabel && (this._polyline.removeTextContent(), this._endLabel = null);
    }, n.prototype._endLabelOnDuring = function(t, i, r, a, e, l, s) {
      var o = this._endLabel, h = this._polyline;
      if (o) {
        t < 1 && a.originalX == null && (a.originalX = o.x, a.originalY = o.y);
        var u = r.getLayout("points"), f = r.hostModel, p = f.get("connectNulls"), b = l.get("precision"), g = l.get("distance") || 0, m = s.getBaseAxis(), y = m.isHorizontal(), x = m.inverse, c = i.shape, D = x ? y ? c.x : c.y + c.height : y ? c.x + c.width : c.y, E = (y ? g : 0) * (x ? -1 : 1), d = (y ? 0 : -g) * (x ? -1 : 1), L = y ? "x" : "y", w = Wt(u, D, L), I = w.range, A = I[1] - I[0], P = void 0;
        if (A >= 1) {
          if (A > 1 && !p) {
            var S = ot(u, I[0]);
            o.attr({
              x: S[0] + E,
              y: S[1] + d
            }), e && (P = f.getRawValue(I[0]));
          } else {
            var S = h.getPointOn(D, L);
            S && o.attr({
              x: S[0] + E,
              y: S[1] + d
            });
            var O = f.getRawValue(I[0]), G = f.getRawValue(I[1]);
            e && (P = dt(r, b, O, G, w.t));
          }
          a.lastFrameIndex = I[0];
        } else {
          var T = t === 1 || a.lastFrameIndex > 0 ? I[0] : 0, S = ot(u, T);
          e && (P = f.getRawValue(T)), o.attr({
            x: S[0] + E,
            y: S[1] + d
          });
        }
        if (e) {
          var k = Nt(o);
          typeof k.setLabelText == "function" && k.setLabelText(P);
        }
      }
    }, n.prototype._doUpdateAnimation = function(t, i, r, a, e, l, s) {
      var o = this._polyline, h = this._polygon, u = t.hostModel, f = yt(this._data, t, this._stackedOnPoints, i, this._coordSys, r, this._valueOrigin), p = f.current, b = f.stackedOnCurrent, g = f.next, m = f.stackedOnNext;
      if (e && (p = C(f.current, r, e, s), b = C(f.stackedOnCurrent, r, e, s), g = C(f.next, r, e, s), m = C(f.stackedOnNext, r, e, s)), nt(p, g) > 3e3 || h && nt(b, m) > 3e3) {
        o.stopAnimation(), o.setShape({
          points: g
        }), h && (h.stopAnimation(), h.setShape({
          points: g,
          stackedOnPoints: m
        }));
        return;
      }
      o.shape.__points = f.current, o.shape.points = p;
      var y = {
        shape: {
          points: g
        }
      };
      f.current !== p && (y.shape.__points = f.next), o.stopAnimation(), et(o, y, u), h && (h.setShape({
        // Reuse the points with polyline.
        points: p,
        stackedOnPoints: b
      }), h.stopAnimation(), et(h, {
        shape: {
          stackedOnPoints: m
        }
      }, u), o.shape.points !== h.shape.points && (h.shape.points = o.shape.points));
      for (var x = [], c = f.status, D = 0; D < c.length; D++) {
        var E = c[D].cmd;
        if (E === "=") {
          var d = t.getItemGraphicEl(c[D].idx1);
          d && x.push({
            el: d,
            ptIdx: D
            // Index of points
          });
        }
      }
      o.animators && o.animators.length && o.animators[0].during(function() {
        h && h.dirtyShape();
        for (var L = o.shape.__points, w = 0; w < x.length; w++) {
          var I = x[w].el, A = x[w].ptIdx * 2;
          I.x = L[A], I.y = L[A + 1], I.markRedraw();
        }
      });
    }, n.prototype.remove = function(t) {
      var i = this.group, r = this._data;
      this._lineGroup.removeAll(), this._symbolDraw.remove(!0), r && r.eachItemGraphicEl(function(a, e) {
        a.__temp && (i.remove(a), r.setItemGraphicEl(e, null));
      }), this._polyline = this._polygon = this._coordSys = this._points = this._stackedOnPoints = this._endLabel = this._data = null;
    }, n.type = "line", n;
  }(F)
);
export {
  me as default
};
