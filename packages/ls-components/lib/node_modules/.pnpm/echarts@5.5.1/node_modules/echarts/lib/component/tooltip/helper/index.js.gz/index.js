var u = Object.defineProperty;
var e = (n, t) => u(n, "name", { value: t, configurable: !0 });
import { toCamelCase as a } from "../../../util/format/index.js";
import f from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/env/index.js";
function d(n) {
  var t = n.get("confine");
  return t != null ? !!t : n.get("renderMode") === "richText";
}
e(d, "shouldTooltipConfine");
function i(n) {
  if (f.domSupported) {
    for (var t = document.documentElement.style, r = 0, o = n.length; r < o; r++)
      if (n[r] in t)
        return n[r];
  }
}
e(i, "testStyle");
var S = i(["transform", "webkitTransform", "OTransform", "MozTransform", "msTransform"]), v = i(["webkitTransition", "transition", "OTransition", "MozTransition", "msTransition"]);
function O(n, t) {
  if (!n)
    return t;
  t = a(t, !0);
  var r = n.indexOf(t);
  return n = r === -1 ? t : "-" + n.slice(0, r) + "-" + t, n.toLowerCase();
}
e(O, "toCSSVendorPrefix");
function s(n, t) {
  var r = n.currentStyle || document.defaultView && document.defaultView.getComputedStyle(n);
  return r ? r[t] : null;
}
e(s, "getComputedStyle");
export {
  S as TRANSFORM_VENDOR,
  v as TRANSITION_VENDOR,
  s as getComputedStyle,
  d as shouldTooltipConfine,
  O as toCSSVendorPrefix
};
