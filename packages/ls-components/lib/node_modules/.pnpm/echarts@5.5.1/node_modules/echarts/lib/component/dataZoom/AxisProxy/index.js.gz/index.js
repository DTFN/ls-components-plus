var E = Object.defineProperty;
var g = (s, e) => E(s, "name", { value: e, configurable: !0 });
import { clone as N, map as A, each as I } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { linearMap as _, getPixelPrecision as P, asc as R } from "../../../util/number/index.js";
import V from "../../helper/sliderMove/index.js";
import { unionAxisExtentFromData as F } from "../../../coord/axisHelper/index.js";
import { ensureScaleRawExtentInfo as Z } from "../../../coord/scaleRawExtentInfo/index.js";
import { isCoordSupported as T, getAxisMainType as C } from "../helper/index.js";
import { SINGLE_REFERRING as b } from "../../../util/model/index.js";
var h = I, D = R, K = (
  /** @class */
  function() {
    function s(e, t, r, a) {
      this._dimName = e, this._axisIndex = t, this.ecModel = a, this._dataZoomModel = r;
    }
    return g(s, "AxisProxy"), s.prototype.hostedBy = function(e) {
      return this._dataZoomModel === e;
    }, s.prototype.getDataValueWindow = function() {
      return this._valueWindow.slice();
    }, s.prototype.getDataPercentWindow = function() {
      return this._percentWindow.slice();
    }, s.prototype.getTargetSeriesModels = function() {
      var e = [];
      return this.ecModel.eachSeries(function(t) {
        if (T(t)) {
          var r = C(this._dimName), a = t.getReferringComponents(r, b).models[0];
          a && this._axisIndex === a.componentIndex && e.push(t);
        }
      }, this), e;
    }, s.prototype.getAxisModel = function() {
      return this.ecModel.getComponent(this._dimName + "Axis", this._axisIndex);
    }, s.prototype.getMinMaxSpan = function() {
      return N(this._minMaxSpan);
    }, s.prototype.calculateDataWindow = function(e) {
      var t = this._dataExtent, r = this.getAxisModel(), a = r.axis.scale, o = this._dataZoomModel.getRangePropMode(), n = [0, 100], v = [], d = [], p;
      h(["start", "end"], function(m, i) {
        var l = e[m], u = e[m + "Value"];
        o[i] === "percent" ? (l == null && (l = n[i]), u = a.parse(_(l, n, t))) : (p = !0, u = u == null ? t[i] : a.parse(u), l = _(u, t, n)), d[i] = u == null || isNaN(u) ? t[i] : u, v[i] = l == null || isNaN(l) ? n[i] : l;
      }), D(d), D(v);
      var f = this._minMaxSpan;
      p ? S(d, v, t, n, !1) : S(v, d, n, t, !0);
      function S(m, i, l, u, M) {
        var x = M ? "Span" : "ValueSpan";
        V(0, m, l, "all", f["min" + x], f["max" + x]);
        for (var c = 0; c < 2; c++)
          i[c] = _(m[c], l, u, !0), M && (i[c] = a.parse(i[c]));
      }
      return g(S, "restrictSet"), {
        valueWindow: d,
        percentWindow: v
      };
    }, s.prototype.reset = function(e) {
      if (e === this._dataZoomModel) {
        var t = this.getTargetSeriesModels();
        this._dataExtent = G(this, this._dimName, t), this._updateMinMaxSpan();
        var r = this.calculateDataWindow(e.settledOption);
        this._valueWindow = r.valueWindow, this._percentWindow = r.percentWindow, this._setAxisModel();
      }
    }, s.prototype.filterData = function(e, t) {
      if (e !== this._dataZoomModel)
        return;
      var r = this._dimName, a = this.getTargetSeriesModels(), o = e.get("filterMode"), n = this._valueWindow;
      if (o === "none")
        return;
      h(a, function(d) {
        var p = d.getData(), f = p.mapDimensionsAll(r);
        if (f.length) {
          if (o === "weakFilter") {
            var S = p.getStore(), m = A(f, function(i) {
              return p.getDimensionIndex(i);
            }, p);
            p.filterSelf(function(i) {
              for (var l, u, M, x = 0; x < f.length; x++) {
                var c = S.get(m[x], i), w = !isNaN(c), W = c < n[0], y = c > n[1];
                if (w && !W && !y)
                  return !0;
                w && (M = !0), W && (l = !0), y && (u = !0);
              }
              return M && l && u;
            });
          } else
            h(f, function(i) {
              if (o === "empty")
                d.setData(p = p.map(i, function(u) {
                  return v(u) ? u : NaN;
                }));
              else {
                var l = {};
                l[i] = n, p.selectRange(l);
              }
            });
          h(f, function(i) {
            p.setApproximateExtent(n, i);
          });
        }
      });
      function v(d) {
        return d >= n[0] && d <= n[1];
      }
      g(v, "isInWindow");
    }, s.prototype._updateMinMaxSpan = function() {
      var e = this._minMaxSpan = {}, t = this._dataZoomModel, r = this._dataExtent;
      h(["min", "max"], function(a) {
        var o = t.get(a + "Span"), n = t.get(a + "ValueSpan");
        n != null && (n = this.getAxisModel().axis.scale.parse(n)), n != null ? o = _(r[0] + n, r, [0, 100], !0) : o != null && (n = _(o, [0, 100], r, !0) - r[0]), e[a + "Span"] = o, e[a + "ValueSpan"] = n;
      }, this);
    }, s.prototype._setAxisModel = function() {
      var e = this.getAxisModel(), t = this._percentWindow, r = this._valueWindow;
      if (t) {
        var a = P(r, [0, 500]);
        a = Math.min(a, 20);
        var o = e.axis.scale.rawExtentInfo;
        t[0] !== 0 && o.setDeterminedMinMax("min", +r[0].toFixed(a)), t[1] !== 100 && o.setDeterminedMinMax("max", +r[1].toFixed(a)), o.freeze();
      }
    }, s;
  }()
);
function G(s, e, t) {
  var r = [1 / 0, -1 / 0];
  h(t, function(n) {
    F(r, n.getData(), e);
  });
  var a = s.getAxisModel(), o = Z(a.axis.scale, a, r).calculate();
  return [o.min, o.max];
}
g(G, "calculateDataExtent");
export {
  K as default
};
