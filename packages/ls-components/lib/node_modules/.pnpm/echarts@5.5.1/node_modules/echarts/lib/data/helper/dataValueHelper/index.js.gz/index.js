var h = Object.defineProperty;
var e = (r, t) => h(r, "name", { value: t, configurable: !0 });
import { parseDate as N, numericToNumber as p } from "../../../util/number/index.js";
import { createHashMap as _, isString as m, trim as b, isNumber as u } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
function D(r, t) {
  var i = t && t.type;
  return i === "ordinal" ? r : (i === "time" && !u(r) && r != null && r !== "-" && (r = +N(r)), r == null || r === "" ? NaN : Number(r));
}
e(D, "parseDataValue");
_({
  number: /* @__PURE__ */ e(function(r) {
    return parseFloat(r);
  }, "number"),
  time: /* @__PURE__ */ e(function(r) {
    return +N(r);
  }, "time"),
  trim: /* @__PURE__ */ e(function(r) {
    return m(r) ? b(r) : r;
  }, "trim")
});
var F = (
  /** @class */
  function() {
    function r(t, i) {
      var n = t === "desc";
      this._resultLT = n ? 1 : -1, i == null && (i = n ? "min" : "max"), this._incomparable = i === "min" ? -1 / 0 : 1 / 0;
    }
    return e(r, "SortOrderComparator"), r.prototype.evaluate = function(t, i) {
      var n = u(t) ? t : p(t), o = u(i) ? i : p(i), a = isNaN(n), f = isNaN(o);
      if (a && (n = this._incomparable), f && (o = this._incomparable), a && f) {
        var s = m(t), c = m(i);
        s && (n = c ? t : 0), c && (o = s ? i : 0);
      }
      return n < o ? this._resultLT : n > o ? -this._resultLT : 0;
    }, r;
  }()
);
export {
  F as SortOrderComparator,
  D as parseDataValue
};
