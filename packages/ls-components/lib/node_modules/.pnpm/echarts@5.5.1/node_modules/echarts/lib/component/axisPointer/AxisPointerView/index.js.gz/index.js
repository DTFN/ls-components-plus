var g = Object.defineProperty;
var f = (o, t) => g(o, "name", { value: t, configurable: !0 });
import { __extends as u } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { register as x, unregister as a } from "../globalListener/index.js";
import c from "../../../view/Component/index.js";
var O = (
  /** @class */
  function(o) {
    u(t, o);
    function t() {
      var e = o !== null && o.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return f(t, "AxisPointerView"), t.prototype.render = function(e, i, l) {
      var p = i.getComponent("tooltip"), s = e.get("triggerOn") || p && p.get("triggerOn") || "mousemove|click";
      x("axisPointer", l, function(r, n, m) {
        s !== "none" && (r === "leave" || s.indexOf(r) >= 0) && m({
          type: "updateAxisPointer",
          currTrigger: r,
          x: n && n.offsetX,
          y: n && n.offsetY
        });
      });
    }, t.prototype.remove = function(e, i) {
      a("axisPointer", i);
    }, t.prototype.dispose = function(e, i) {
      a("axisPointer", i);
    }, t.type = "axisPointer", t;
  }(c)
);
export {
  O as default
};
