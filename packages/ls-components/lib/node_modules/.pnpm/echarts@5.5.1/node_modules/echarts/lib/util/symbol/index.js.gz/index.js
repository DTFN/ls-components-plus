var C = Object.defineProperty;
var a = (i, n) => C(i, "name", { value: n, configurable: !0 });
import { each as k, isArray as M, retrieve2 as R } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { makeImage as B, makePath as L } from "../graphic/index.js";
import T from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/BoundingRect/index.js";
import { calculateTextPosition as _ } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/contain/text/index.js";
import { parsePercent as y } from "../number/index.js";
import u from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
import E from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Line/index.js";
import g from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
import I from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Circle/index.js";
var q = u.extend({
  type: "triangle",
  shape: {
    cx: 0,
    cy: 0,
    width: 0,
    height: 0
  },
  buildPath: /* @__PURE__ */ a(function(i, n) {
    var r = n.cx, e = n.cy, t = n.width / 2, o = n.height / 2;
    i.moveTo(r, e - o), i.lineTo(r + t, e + o), i.lineTo(r - t, e + o), i.closePath();
  }, "buildPath")
}), z = u.extend({
  type: "diamond",
  shape: {
    cx: 0,
    cy: 0,
    width: 0,
    height: 0
  },
  buildPath: /* @__PURE__ */ a(function(i, n) {
    var r = n.cx, e = n.cy, t = n.width / 2, o = n.height / 2;
    i.moveTo(r, e - o), i.lineTo(r + t, e), i.lineTo(r, e + o), i.lineTo(r - t, e), i.closePath();
  }, "buildPath")
}), A = u.extend({
  type: "pin",
  shape: {
    // x, y on the cusp
    x: 0,
    y: 0,
    width: 0,
    height: 0
  },
  buildPath: /* @__PURE__ */ a(function(i, n) {
    var r = n.x, e = n.y, t = n.width / 5 * 3, o = Math.max(t, n.height), c = t / 2, v = c * c / (o - c), d = e - o + c + v, h = Math.asin(v / c), f = Math.cos(h) * c, x = Math.sin(h), w = Math.cos(h), l = c * 0.6, P = c * 0.7;
    i.moveTo(r - f, d + v), i.arc(r, d, c, Math.PI - h, Math.PI * 2 + h), i.bezierCurveTo(r + f - x * l, d + v + w * l, r, e - P, r, e), i.bezierCurveTo(r, e - P, r - f + x * l, d + v + w * l, r - f, d + v), i.closePath();
  }, "buildPath")
}), D = u.extend({
  type: "arrow",
  shape: {
    x: 0,
    y: 0,
    width: 0,
    height: 0
  },
  buildPath: /* @__PURE__ */ a(function(i, n) {
    var r = n.height, e = n.width, t = n.x, o = n.y, c = e / 3 * 2;
    i.moveTo(t, o), i.lineTo(t + c, o + r), i.lineTo(t, o + r / 4 * 3), i.lineTo(t - c, o + r), i.lineTo(t, o), i.closePath();
  }, "buildPath")
}), W = {
  line: E,
  rect: g,
  roundRect: g,
  square: g,
  circle: I,
  diamond: z,
  pin: A,
  arrow: D,
  triangle: q
}, X = {
  line: /* @__PURE__ */ a(function(i, n, r, e, t) {
    t.x1 = i, t.y1 = n + e / 2, t.x2 = i + r, t.y2 = n + e / 2;
  }, "line"),
  rect: /* @__PURE__ */ a(function(i, n, r, e, t) {
    t.x = i, t.y = n, t.width = r, t.height = e;
  }, "rect"),
  roundRect: /* @__PURE__ */ a(function(i, n, r, e, t) {
    t.x = i, t.y = n, t.width = r, t.height = e, t.r = Math.min(r, e) / 4;
  }, "roundRect"),
  square: /* @__PURE__ */ a(function(i, n, r, e, t) {
    var o = Math.min(r, e);
    t.x = i, t.y = n, t.width = o, t.height = o;
  }, "square"),
  circle: /* @__PURE__ */ a(function(i, n, r, e, t) {
    t.cx = i + r / 2, t.cy = n + e / 2, t.r = Math.min(r, e) / 2;
  }, "circle"),
  diamond: /* @__PURE__ */ a(function(i, n, r, e, t) {
    t.cx = i + r / 2, t.cy = n + e / 2, t.width = r, t.height = e;
  }, "diamond"),
  pin: /* @__PURE__ */ a(function(i, n, r, e, t) {
    t.x = i + r / 2, t.y = n + e / 2, t.width = r, t.height = e;
  }, "pin"),
  arrow: /* @__PURE__ */ a(function(i, n, r, e, t) {
    t.x = i + r / 2, t.y = n + e / 2, t.width = r, t.height = e;
  }, "arrow"),
  triangle: /* @__PURE__ */ a(function(i, n, r, e, t) {
    t.cx = i + r / 2, t.cy = n + e / 2, t.width = r, t.height = e;
  }, "triangle")
}, m = {};
k(W, function(i, n) {
  m[n] = new i();
});
var Y = u.extend({
  type: "symbol",
  shape: {
    symbolType: "",
    x: 0,
    y: 0,
    width: 0,
    height: 0
  },
  calculateTextPosition: /* @__PURE__ */ a(function(i, n, r) {
    var e = _(i, n, r), t = this.shape;
    return t && t.symbolType === "pin" && n.position === "inside" && (e.y = r.y + r.height * 0.4), e;
  }, "calculateTextPosition"),
  buildPath: /* @__PURE__ */ a(function(i, n, r) {
    var e = n.symbolType;
    if (e !== "none") {
      var t = m[e];
      t || (e = "rect", t = m[e]), X[e](n.x, n.y, n.width, n.height, t.shape), t.buildPath(i, t.shape, r);
    }
  }, "buildPath")
});
function j(i, n) {
  if (this.type !== "image") {
    var r = this.style;
    this.__isEmptyBrush ? (r.stroke = i, r.fill = n || "#fff", r.lineWidth = 2) : this.shape.symbolType === "line" ? r.stroke = i : r.fill = i, this.markRedraw();
  }
}
a(j, "symbolPathSetColor");
function $(i, n, r, e, t, o, c) {
  var v = i.indexOf("empty") === 0;
  v && (i = i.substr(5, 1).toLowerCase() + i.substr(6));
  var d;
  return i.indexOf("image://") === 0 ? d = B(i.slice(8), new T(n, r, e, t), c ? "center" : "cover") : i.indexOf("path://") === 0 ? d = L(i.slice(7), {}, new T(n, r, e, t), c ? "center" : "cover") : d = new Y({
    shape: {
      symbolType: i,
      x: n,
      y: r,
      width: e,
      height: t
    }
  }), d.__isEmptyBrush = v, d.setColor = j, o && d.setColor(o), d;
}
a($, "createSymbol");
function b(i) {
  return M(i) || (i = [+i, +i]), [i[0] || 0, i[1] || 0];
}
a(b, "normalizeSymbolSize");
function O(i, n) {
  if (i != null)
    return M(i) || (i = [i, i]), [y(i[0], n[0]) || 0, y(R(i[1], i[0]), n[1]) || 0];
}
a(O, "normalizeSymbolOffset");
export {
  $ as createSymbol,
  O as normalizeSymbolOffset,
  b as normalizeSymbolSize,
  m as symbolBuildProxies
};
