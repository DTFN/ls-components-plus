var E = Object.defineProperty;
var n = (l, c) => E(l, "name", { value: c, configurable: !0 });
import { each as h, isObject as b, isTypedArray as s, defaults as p, isArray as N } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import _ from "../helper/compatStyle/index.js";
import { normalizeToArray as A } from "../../util/model/index.js";
import { deprecateReplaceLog as i, deprecateLog as T } from "../../util/log/index.js";
function D(l, c) {
  for (var a = c.split(","), e = l, r = 0; r < a.length && (e = e && e[a[r]], e != null); r++)
    ;
  return e;
}
n(D, "get");
function S(l, c, a, e) {
  for (var r = c.split(","), f = l, u, o = 0; o < r.length - 1; o++)
    u = r[o], f[u] == null && (f[u] = {}), f = f[u];
  f[r[o]] == null && (f[r[o]] = a);
}
n(S, "set");
function d(l) {
  l && h(k, function(c) {
    c[0] in l && !(c[1] in l) && (l[c[1]] = l[c[0]]);
  });
}
n(d, "compatLayoutProperties");
var k = [["x", "left"], ["y", "top"], ["x2", "right"], ["y2", "bottom"]], V = ["grid", "geo", "parallel", "legend", "toolbox", "title", "visualMap", "dataZoom", "timeline"], v = [["borderRadius", "barBorderRadius"], ["borderColor", "barBorderColor"], ["borderWidth", "barBorderWidth"]];
function m(l) {
  var c = l && l.itemStyle;
  if (c)
    for (var a = 0; a < v.length; a++) {
      var e = v[a][1], r = v[a][0];
      c[e] != null && (c[r] = c[e], process.env.NODE_ENV !== "production" && i(e, r));
    }
}
n(m, "compatBarItemStyle");
function t(l) {
  l && l.alignTo === "edge" && l.margin != null && l.edgeDistance == null && (process.env.NODE_ENV !== "production" && i("label.margin", "label.edgeDistance", "pie"), l.edgeDistance = l.margin);
}
n(t, "compatPieLabel");
function g(l) {
  l && l.downplay && !l.blur && (l.blur = l.downplay, process.env.NODE_ENV !== "production" && i("downplay", "blur", "sunburst"));
}
n(g, "compatSunburstState");
function L(l) {
  l && l.focusNodeAdjacency != null && (l.emphasis = l.emphasis || {}, l.emphasis.focus == null && (process.env.NODE_ENV !== "production" && i("focusNodeAdjacency", "emphasis: { focus: 'adjacency'}", "graph/sankey"), l.emphasis.focus = "adjacency"));
}
n(L, "compatGraphFocus");
function y(l, c) {
  if (l)
    for (var a = 0; a < l.length; a++)
      c(l[a]), l[a] && y(l[a].children, c);
}
n(y, "traverseTree");
function M(l, c) {
  _(l, c), l.series = A(l.series), h(l.series, function(a) {
    if (b(a)) {
      var e = a.type;
      if (e === "line")
        a.clipOverflow != null && (a.clip = a.clipOverflow, process.env.NODE_ENV !== "production" && i("clipOverflow", "clip", "line"));
      else if (e === "pie" || e === "gauge") {
        a.clockWise != null && (a.clockwise = a.clockWise, process.env.NODE_ENV !== "production" && i("clockWise", "clockwise")), t(a.label);
        var r = a.data;
        if (r && !s(r))
          for (var f = 0; f < r.length; f++)
            t(r[f]);
        a.hoverOffset != null && (a.emphasis = a.emphasis || {}, (a.emphasis.scaleSize = null) && (process.env.NODE_ENV !== "production" && i("hoverOffset", "emphasis.scaleSize"), a.emphasis.scaleSize = a.hoverOffset));
      } else if (e === "gauge") {
        var u = D(a, "pointer.color");
        u != null && S(a, "itemStyle.color", u);
      } else if (e === "bar") {
        m(a), m(a.backgroundStyle), m(a.emphasis);
        var r = a.data;
        if (r && !s(r))
          for (var f = 0; f < r.length; f++)
            typeof r[f] == "object" && (m(r[f]), m(r[f] && r[f].emphasis));
      } else if (e === "sunburst") {
        var o = a.highlightPolicy;
        o && (a.emphasis = a.emphasis || {}, a.emphasis.focus || (a.emphasis.focus = o, process.env.NODE_ENV !== "production" && i("highlightPolicy", "emphasis.focus", "sunburst"))), g(a), y(a.data, g);
      } else e === "graph" || e === "sankey" ? L(a) : e === "map" && (a.mapType && !a.map && (process.env.NODE_ENV !== "production" && i("mapType", "map", "map"), a.map = a.mapType), a.mapLocation && (process.env.NODE_ENV !== "production" && T("`mapLocation` is not used anymore."), p(a, a.mapLocation)));
      a.hoverAnimation != null && (a.emphasis = a.emphasis || {}, a.emphasis && a.emphasis.scale == null && (process.env.NODE_ENV !== "production" && i("hoverAnimation", "emphasis.scale"), a.emphasis.scale = a.hoverAnimation)), d(a);
    }
  }), l.dataRange && (l.visualMap = l.dataRange), h(V, function(a) {
    var e = l[a];
    e && (N(e) || (e = [e]), h(e, function(r) {
      d(r);
    }));
  });
}
n(M, "globalBackwardCompat");
export {
  M as default
};
