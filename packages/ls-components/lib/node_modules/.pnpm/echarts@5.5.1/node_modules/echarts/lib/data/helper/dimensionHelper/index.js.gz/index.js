var E = Object.defineProperty;
var s = (e, n) => E(e, "name", { value: n, configurable: !0 });
import { createHashMap as N, each as x, assert as y, map as C } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { VISUAL_DIMENSIONS as _ } from "../../../util/types/index.js";
var b = (
  /** @class */
  function() {
    function e(n, i) {
      this._encode = n, this._schema = i;
    }
    return s(e, "DimensionUserOuput"), e.prototype.get = function() {
      return {
        // Do not generate full dimension name until fist used.
        fullDimensions: this._getFullDimensionNames(),
        encode: this._encode
      };
    }, e.prototype._getFullDimensionNames = function() {
      return this._cachedDimNames || (this._cachedDimNames = this._schema ? this._schema.makeOutputDimensionNames() : []), this._cachedDimNames;
    }, e;
  }()
);
function S(e, n) {
  var i = {}, r = i.encode = {}, D = N(), c = [], u = [], h = {};
  x(e.dimensions, function(a) {
    var t = e.getDimensionInfo(a), o = t.coordDim;
    if (o) {
      process.env.NODE_ENV !== "production" && y(_.get(o) == null);
      var g = t.coordDimIndex;
      p(r, o)[g] = a, t.isExtraCoord || (D.set(o, 1), A(t.type) && (c[0] = a), p(h, o)[g] = e.getDimensionIndex(t.name)), t.defaultTooltip && u.push(a);
    }
    _.each(function(L, O) {
      var I = p(r, O), d = t.otherDims[O];
      d != null && d !== !1 && (I[d] = t.name);
    });
  });
  var m = [], v = {};
  D.each(function(a, t) {
    var o = r[t];
    v[t] = o[0], m = m.concat(o);
  }), i.dataDimsOnCoord = m, i.dataDimIndicesOnCoord = C(m, function(a) {
    return e.getDimensionInfo(a).storeDimIndex;
  }), i.encodeFirstDimNotExtra = v;
  var l = r.label;
  l && l.length && (c = l.slice());
  var f = r.tooltip;
  return f && f.length ? u = f.slice() : u.length || (u = c.slice()), r.defaultedLabel = c, r.defaultedTooltip = u, i.userOutput = new b(h, n), i;
}
s(S, "summarizeDimensions");
function p(e, n) {
  return e.hasOwnProperty(n) || (e[n] = []), e[n];
}
s(p, "getOrCreateEncodeArr");
function U(e) {
  return e === "category" ? "ordinal" : e === "time" ? "time" : "float";
}
s(U, "getDimensionTypeByAxis");
function A(e) {
  return !(e === "ordinal" || e === "time");
}
s(A, "mayLabelDimType");
export {
  U as getDimensionTypeByAxis,
  S as summarizeDimensions
};
