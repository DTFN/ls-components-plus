var A = Object.defineProperty;
var C = (o, t) => A(o, "name", { value: t, configurable: !0 });
import { __extends as B } from "../../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import S from "../../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/env/index.js";
import { ToolboxFeature as E } from "../../featureManager/index.js";
var D = (
  /** @class */
  function(o) {
    B(t, o);
    function t() {
      return o !== null && o.apply(this, arguments) || this;
    }
    return C(t, "SaveAsImage"), t.prototype.onclick = function(n, r) {
      var e = this.model, g = e.get("name") || n.get("title.0.text") || "echarts", c = r.getZr().painter.getType() === "svg", v = c ? "svg" : e.get("type", !0) || "png", u = r.getConnectedDataURL({
        type: v,
        backgroundColor: e.get("backgroundColor", !0) || n.get("backgroundColor") || "#fff",
        connectedBackgroundColor: e.get("connectedBackgroundColor"),
        excludeComponents: e.get("excludeComponents"),
        pixelRatio: e.get("pixelRatio")
      }), m = S.browser;
      if (typeof MouseEvent == "function" && (m.newEdge || !m.ie && !m.edge)) {
        var l = document.createElement("a");
        l.download = g + "." + v, l.target = "_blank", l.href = u;
        var h = new MouseEvent("click", {
          // some micro front-end framework， window maybe is a Proxy
          view: document.defaultView,
          bubbles: !0,
          cancelable: !1
        });
        l.dispatchEvent(h);
      } else if (window.navigator.msSaveOrOpenBlob || c) {
        var s = u.split(","), k = s[0].indexOf("base64") > -1, a = c ? decodeURIComponent(s[1]) : s[1];
        k && (a = window.atob(a));
        var f = g + "." + v;
        if (window.navigator.msSaveOrOpenBlob) {
          for (var i = a.length, w = new Uint8Array(i); i--; )
            w[i] = a.charCodeAt(i);
          var L = new Blob([w]);
          window.navigator.msSaveOrOpenBlob(L, f);
        } else {
          var p = document.createElement("iframe");
          document.body.appendChild(p);
          var b = p.contentWindow, d = b.document;
          d.open("image/svg+xml", "replace"), d.write(a), d.close(), b.focus(), d.execCommand("SaveAs", !0, f), document.body.removeChild(p);
        }
      } else {
        var x = e.get("lang"), O = '<body style="margin:0;"><img src="' + u + '" style="max-width:100%;" title="' + (x && x[0] || "") + '" /></body>', y = window.open();
        y.document.write(O), y.document.title = g;
      }
    }, t.getDefaultOption = function(n) {
      var r = {
        show: !0,
        icon: "M4.7,22.9L29.3,45.5L54.7,23.4M4.6,43.6L4.6,58L53.8,58L53.8,43.6M29.2,45.1L29.2,0",
        title: n.getLocaleModel().get(["toolbox", "saveAsImage", "title"]),
        type: "png",
        // Default use option.backgroundColor
        // backgroundColor: '#fff',
        connectedBackgroundColor: "#fff",
        name: "",
        excludeComponents: ["toolbox"],
        // use current pixel ratio of device by default
        // pixelRatio: 1,
        lang: n.getLocaleModel().get(["toolbox", "saveAsImage", "lang"])
      };
      return r;
    }, t;
  }(E)
);
export {
  D as default
};
