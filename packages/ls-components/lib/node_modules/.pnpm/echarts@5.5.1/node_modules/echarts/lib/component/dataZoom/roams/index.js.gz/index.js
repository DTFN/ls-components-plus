var h = Object.defineProperty;
var d = (t, e) => h(t, "name", { value: e, configurable: !0 });
import M from "../../helper/RoamController/index.js";
import { createOrUpdate as g } from "../../../util/throttle/index.js";
import { makeInner as R } from "../../../util/model/index.js";
import { createHashMap as p, each as v, curry as m } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { collectReferCoordSysModelInfo as I } from "../helper/index.js";
var f = R();
function _(t, e, o) {
  f(t).coordSysRecordMap.each(function(c) {
    var a = c.dataZoomInfoMap.get(e.uid);
    a && (a.getRange = o);
  });
}
d(_, "setViewInfoToCoordSysRecord");
function x(t, e) {
  for (var o = f(t).coordSysRecordMap, c = o.keys(), a = 0; a < c.length; a++) {
    var n = c[a], i = o.get(n), r = i.dataZoomInfoMap;
    if (r) {
      var l = e.uid, u = r.get(l);
      u && (r.removeKey(l), r.keys().length || y(o, i));
    }
  }
}
d(x, "disposeCoordSysRecordIfNeeded");
function y(t, e) {
  if (e) {
    t.removeKey(e.model.uid);
    var o = e.controller;
    o && o.dispose();
  }
}
d(y, "disposeCoordSysRecord");
function P(t, e) {
  var o = {
    model: e,
    containsPoint: m(S, e),
    dispatchAction: m(C, t),
    dataZoomInfoMap: null,
    controller: null
  }, c = o.controller = new M(t.getZr());
  return v(["pan", "zoom", "scrollMove"], function(a) {
    c.on(a, function(n) {
      var i = [];
      o.dataZoomInfoMap.each(function(r) {
        if (n.isAvailableBehavior(r.model.option)) {
          var l = (r.getRange || {})[a], u = l && l(r.dzReferCoordSysInfo, o.model.mainType, o.controller, n);
          !r.model.get("disabled", !0) && u && i.push({
            dataZoomId: r.model.id,
            start: u[0],
            end: u[1]
          });
        }
      }), i.length && o.dispatchAction(i);
    });
  }), o;
}
d(P, "createCoordSysRecord");
function C(t, e) {
  t.isDisposed() || t.dispatchAction({
    type: "dataZoom",
    animation: {
      easing: "cubicOut",
      duration: 100
    },
    batch: e
  });
}
d(C, "dispatchAction");
function S(t, e, o, c) {
  return t.coordinateSystem.containPoint([o, c]);
}
d(S, "containsPoint");
function Z(t) {
  var e, o = "type_", c = {
    type_true: 2,
    type_move: 1,
    type_false: 0,
    type_undefined: -1
  }, a = !0;
  return t.each(function(n) {
    var i = n.model, r = i.get("disabled", !0) ? !1 : i.get("zoomLock", !0) ? "move" : !0;
    c[o + r] > c[o + e] && (e = r), a = a && i.get("preventDefaultMouseMove", !0);
  }), {
    controlType: e,
    opt: {
      // RoamController will enable all of these functionalities,
      // and the final behavior is determined by its event listener
      // provided by each inside zoom.
      zoomOnMouseWheel: !0,
      moveOnMouseMove: !0,
      moveOnMouseWheel: !0,
      preventDefaultMouseMove: !!a
    }
  };
}
d(Z, "mergeControllerParams");
function L(t) {
  t.registerProcessor(t.PRIORITY.PROCESSOR.FILTER, function(e, o) {
    var c = f(o), a = c.coordSysRecordMap || (c.coordSysRecordMap = p());
    a.each(function(n) {
      n.dataZoomInfoMap = null;
    }), e.eachComponent({
      mainType: "dataZoom",
      subType: "inside"
    }, function(n) {
      var i = I(n);
      v(i.infoList, function(r) {
        var l = r.model.uid, u = a.get(l) || a.set(l, P(o, r.model)), s = u.dataZoomInfoMap || (u.dataZoomInfoMap = p());
        s.set(n.uid, {
          dzReferCoordSysInfo: r,
          model: n,
          getRange: null
        });
      });
    }), a.each(function(n) {
      var i = n.controller, r, l = n.dataZoomInfoMap;
      if (l) {
        var u = l.keys()[0];
        u != null && (r = l.get(u));
      }
      if (!r) {
        y(a, n);
        return;
      }
      var s = Z(l);
      i.enable(s.controlType, s.opt), i.setPointerChecker(n.containsPoint), g(n, "dispatchAction", r.model.get("throttle", !0), "fixRate");
    });
  });
}
d(L, "installDataZoomRoamProcessor");
export {
  x as disposeCoordSysRecordIfNeeded,
  L as installDataZoomRoamProcessor,
  _ as setViewInfoToCoordSysRecord
};
