var R = Object.defineProperty;
var i = (t, r) => R(t, "name", { value: r, configurable: !0 });
var s = "\0__throttleOriginMethod", E = "\0__throttleRate", O = "\0__throttleType";
function _(t, r, a) {
  var l, e = 0, u = 0, n = null, c, m, h, v;
  r = r || 0;
  function T() {
    u = (/* @__PURE__ */ new Date()).getTime(), n = null, t.apply(m, h || []);
  }
  i(T, "exec");
  var g = /* @__PURE__ */ i(function() {
    for (var o = [], f = 0; f < arguments.length; f++)
      o[f] = arguments[f];
    l = (/* @__PURE__ */ new Date()).getTime(), m = this, h = o;
    var x = v || r, D = v || a;
    v = null, c = l - (D ? e : u) - x, clearTimeout(n), D ? n = setTimeout(T, x) : c >= 0 ? T() : n = setTimeout(T, -c), e = l;
  }, "cb");
  return g.clear = function() {
    n && (clearTimeout(n), n = null);
  }, g.debounceNextCall = function(o) {
    v = o;
  }, g;
}
i(_, "throttle");
function p(t, r, a, l) {
  var e = t[r];
  if (e) {
    var u = e[s] || e, n = e[O], c = e[E];
    if (c !== a || n !== l) {
      if (a == null || !l)
        return t[r] = u;
      e = t[r] = _(u, a, l === "debounce"), e[s] = u, e[O] = l, e[E] = a;
    }
    return e;
  }
}
i(p, "createOrUpdate");
function C(t, r) {
  var a = t[r];
  a && a[s] && (a.clear && a.clear(), t[r] = a[s]);
}
i(C, "clear");
export {
  C as clear,
  p as createOrUpdate,
  _ as throttle
};
