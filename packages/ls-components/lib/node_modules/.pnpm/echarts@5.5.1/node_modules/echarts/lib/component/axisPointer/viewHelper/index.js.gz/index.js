var p = Object.defineProperty;
var o = (t, r) => p(t, "name", { value: r, configurable: !0 });
import { each as y, isString as S, isFunction as A } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { applyTransform as L } from "../../../util/graphic/index.js";
import { getBoundingRect as C } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/contain/text/index.js";
import { normalizeCssArray as T } from "../../../util/format/index.js";
import { rotate as k, translate as w, create as R } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/matrix/index.js";
import { getAxisRawValue as B } from "../../../coord/axisHelper/index.js";
import E from "../../axis/AxisBuilder/index.js";
import { createTextStyle as O } from "../../../label/labelStyle/index.js";
function U(t) {
  var r = t.get("type"), e = t.getModel(r + "Style"), a;
  return r === "line" ? (a = e.getLineStyle(), a.fill = null) : r === "shadow" && (a = e.getAreaStyle(), a.stroke = null), a;
}
o(U, "buildElStyle");
function V(t, r, e, a, i) {
  var n = e.get("value"), l = F(n, r.axis, r.ecModel, e.get("seriesDataIndices"), {
    precision: e.get(["label", "precision"]),
    formatter: e.get(["label", "formatter"])
  }), c = e.getModel("label"), v = T(c.get("padding") || 0), s = c.getFont(), f = C(l, s), g = i.position, m = f.width + v[1] + v[3], b = f.height + v[0] + v[2], d = i.align;
  d === "right" && (g[0] -= m), d === "center" && (g[0] -= m / 2);
  var h = i.verticalAlign;
  h === "bottom" && (g[1] -= b), h === "middle" && (g[1] -= b / 2), z(g, m, b, a);
  var u = c.get("backgroundColor");
  (!u || u === "auto") && (u = r.get(["axisLine", "lineStyle", "color"])), t.label = {
    // shape: {x: 0, y: 0, width: width, height: height, r: labelModel.get('borderRadius')},
    x: g[0],
    y: g[1],
    style: O(c, {
      text: l,
      font: s,
      fill: c.getTextColor(),
      padding: v,
      backgroundColor: u
    }),
    // Label should be over axisPointer.
    z2: 10
  };
}
o(V, "buildLabelElOption");
function z(t, r, e, a) {
  var i = a.getWidth(), n = a.getHeight();
  t[0] = Math.min(t[0] + r, i) - r, t[1] = Math.min(t[1] + e, n) - e, t[0] = Math.max(t[0], 0), t[1] = Math.max(t[1], 0);
}
o(z, "confineInContainer");
function F(t, r, e, a, i) {
  t = r.scale.parse(t);
  var n = r.scale.getLabel({
    value: t
  }, {
    // If `precision` is set, width can be fixed (like '12.00500'), which
    // helps to debounce when when moving label.
    precision: i.precision
  }), l = i.formatter;
  if (l) {
    var c = {
      value: B(r, {
        value: t
      }),
      axisDimension: r.dim,
      axisIndex: r.index,
      seriesData: []
    };
    y(a, function(v) {
      var s = e.getSeriesByIndex(v.seriesIndex), f = v.dataIndexInside, g = s && s.getDataParams(f);
      g && c.seriesData.push(g);
    }), S(l) ? n = l.replace("{value}", n) : A(l) && (n = l(c));
  }
  return n;
}
o(F, "getValueLabel");
function H(t, r, e) {
  var a = R();
  return k(a, a, e.rotation), w(a, a, e.position), L([t.dataToCoord(r), (e.labelOffset || 0) + (e.labelDirection || 1) * (e.labelMargin || 0)], a);
}
o(H, "getTransformedPosition");
function X(t, r, e, a, i, n) {
  var l = E.innerTextLayout(e.rotation, 0, e.labelDirection);
  e.labelMargin = i.get(["label", "margin"]), V(r, a, i, n, {
    position: H(a.axis, t, e),
    align: l.textAlign,
    verticalAlign: l.textVerticalAlign
  });
}
o(X, "buildCartesianSingleLabelElOption");
function Y(t, r, e) {
  return e = e || 0, {
    x1: t[e],
    y1: t[1 - e],
    x2: r[e],
    y2: r[1 - e]
  };
}
o(Y, "makeLineShape");
function Z(t, r, e) {
  return e = e || 0, {
    x: t[e],
    y: t[1 - e],
    width: r[e],
    height: r[1 - e]
  };
}
o(Z, "makeRectShape");
export {
  X as buildCartesianSingleLabelElOption,
  U as buildElStyle,
  V as buildLabelElOption,
  H as getTransformedPosition,
  F as getValueLabel,
  Y as makeLineShape,
  Z as makeRectShape
};
