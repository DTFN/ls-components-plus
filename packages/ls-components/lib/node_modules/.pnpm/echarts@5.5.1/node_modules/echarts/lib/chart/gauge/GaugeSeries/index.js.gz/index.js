var i = Object.defineProperty;
var r = (t, e) => i(t, "name", { value: e, configurable: !0 });
import { __extends as l } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import s from "../../helper/createSeriesDataSimply/index.js";
import n from "../../../model/Series/index.js";
var h = (
  /** @class */
  function(t) {
    l(e, t);
    function e() {
      var o = t !== null && t.apply(this, arguments) || this;
      return o.type = e.type, o.visualStyleAccessPath = "itemStyle", o;
    }
    return r(e, "GaugeSeriesModel"), e.prototype.getInitialData = function(o, a) {
      return s(this, ["value"]);
    }, e.type = "series.gauge", e.defaultOption = {
      // zlevel: 0,
      z: 2,
      colorBy: "data",
      // 默认全局居中
      center: ["50%", "50%"],
      legendHoverLink: !0,
      radius: "75%",
      startAngle: 225,
      endAngle: -45,
      clockwise: !0,
      // 最小值
      min: 0,
      // 最大值
      max: 100,
      // 分割段数，默认为10
      splitNumber: 10,
      // 坐标轴线
      axisLine: {
        // 默认显示，属性show控制显示与否
        show: !0,
        roundCap: !1,
        lineStyle: {
          color: [[1, "#E6EBF8"]],
          width: 10
        }
      },
      // 坐标轴线
      progress: {
        // 默认显示，属性show控制显示与否
        show: !1,
        overlap: !0,
        width: 10,
        roundCap: !1,
        clip: !0
      },
      // 分隔线
      splitLine: {
        // 默认显示，属性show控制显示与否
        show: !0,
        // 属性length控制线长
        length: 10,
        distance: 10,
        // 属性lineStyle（详见lineStyle）控制线条样式
        lineStyle: {
          color: "#63677A",
          width: 3,
          type: "solid"
        }
      },
      // 坐标轴小标记
      axisTick: {
        // 属性show控制显示与否，默认不显示
        show: !0,
        // 每份split细分多少段
        splitNumber: 5,
        // 属性length控制线长
        length: 6,
        distance: 10,
        // 属性lineStyle控制线条样式
        lineStyle: {
          color: "#63677A",
          width: 1,
          type: "solid"
        }
      },
      axisLabel: {
        show: !0,
        distance: 15,
        // formatter: null,
        color: "#464646",
        fontSize: 12,
        rotate: 0
      },
      pointer: {
        icon: null,
        offsetCenter: [0, 0],
        show: !0,
        showAbove: !0,
        length: "60%",
        width: 6,
        keepAspect: !1
      },
      anchor: {
        show: !1,
        showAbove: !1,
        size: 6,
        icon: "circle",
        offsetCenter: [0, 0],
        keepAspect: !1,
        itemStyle: {
          color: "#fff",
          borderWidth: 0,
          borderColor: "#5470c6"
        }
      },
      title: {
        show: !0,
        // x, y，单位px
        offsetCenter: [0, "20%"],
        // 其余属性默认使用全局文本样式，详见TEXTSTYLE
        color: "#464646",
        fontSize: 16,
        valueAnimation: !1
      },
      detail: {
        show: !0,
        backgroundColor: "rgba(0,0,0,0)",
        borderWidth: 0,
        borderColor: "#ccc",
        width: 100,
        height: null,
        padding: [5, 10],
        // x, y，单位px
        offsetCenter: [0, "40%"],
        // formatter: null,
        // 其余属性默认使用全局文本样式，详见TEXTSTYLE
        color: "#464646",
        fontSize: 30,
        fontWeight: "bold",
        lineHeight: 30,
        valueAnimation: !1
      }
    }, e;
  }(n)
);
export {
  h as default
};
