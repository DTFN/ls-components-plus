var v = Object.defineProperty;
var u = (n, t) => v(n, "name", { value: t, configurable: !0 });
import { __extends as C } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { each as c, inherits as E, extend as h, isFunction as m, assert as p } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var y = ".", o = "___EC__COMPONENT__CONTAINER___", f = "___EC__EXTENDED_CLASS___";
function l(n) {
  var t = {
    main: "",
    sub: ""
  };
  if (n) {
    var a = n.split(y);
    t.main = a[0] || "", t.sub = a[1] || "";
  }
  return t;
}
u(l, "parseClassType");
function N(n) {
  p(/^[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)?$/.test(n), 'componentType "' + n + '" illegal');
}
u(N, "checkClassType");
function O(n) {
  return !!(n && n[f]);
}
u(O, "isExtendedClass");
function w(n, t) {
  n.$constructor = n, n.extend = function(a) {
    process.env.NODE_ENV !== "production" && c(t, function(r) {
      a[r] || console.warn("Method `" + r + "` should be implemented" + (a.type ? " in " + a.type : "") + ".");
    });
    var e = this, s;
    return x(e) ? s = /** @class */
    function(r) {
      C(i, r);
      function i() {
        return r.apply(this, arguments) || this;
      }
      return u(i, "class_1"), i;
    }(e) : (s = /* @__PURE__ */ u(function() {
      (a.$constructor || e).apply(this, arguments);
    }, "ExtendedClass"), E(s, this)), h(s.prototype, a), s[f] = !0, s.extend = this.extend, s.superCall = A, s.superApply = S, s.superClass = e, s;
  };
}
u(w, "enableClassExtend");
function x(n) {
  return m(n) && /^class\s/.test(Function.prototype.toString.call(n));
}
u(x, "isESClass");
function I(n, t) {
  n.extend = t.extend;
}
u(I, "mountExtend");
var b = Math.round(Math.random() * 10);
function T(n) {
  var t = ["__\0is_clz", b++].join("_");
  n.prototype[t] = !0, process.env.NODE_ENV !== "production" && p(!n.isInstance, 'The method "is" can not be defined.'), n.isInstance = function(a) {
    return !!(a && a[t]);
  };
}
u(T, "enableClassCheck");
function A(n, t) {
  for (var a = [], e = 2; e < arguments.length; e++)
    a[e - 2] = arguments[e];
  return this.superClass.prototype[t].apply(n, a);
}
u(A, "superCall");
function S(n, t, a) {
  return this.superClass.prototype[t].apply(n, a);
}
u(S, "superApply");
function j(n) {
  var t = {};
  n.registerClass = function(e) {
    var s = e.type || e.prototype.type;
    if (s) {
      N(s), e.prototype.type = s;
      var r = l(s);
      if (!r.sub)
        process.env.NODE_ENV !== "production" && t[r.main] && console.warn(r.main + " exists."), t[r.main] = e;
      else if (r.sub !== o) {
        var i = a(r);
        i[r.sub] = e;
      }
    }
    return e;
  }, n.getClass = function(e, s, r) {
    var i = t[e];
    if (i && i[o] && (i = s ? i[s] : null), r && !i)
      throw new Error(s ? "Component " + e + "." + (s || "") + " is used but not imported." : e + ".type should be specified.");
    return i;
  }, n.getClassesByMainType = function(e) {
    var s = l(e), r = [], i = t[s.main];
    return i && i[o] ? c(i, function(_, d) {
      d !== o && r.push(_);
    }) : r.push(i), r;
  }, n.hasClass = function(e) {
    var s = l(e);
    return !!t[s.main];
  }, n.getAllClassMainTypes = function() {
    var e = [];
    return c(t, function(s, r) {
      e.push(r);
    }), e;
  }, n.hasSubTypes = function(e) {
    var s = l(e), r = t[s.main];
    return r && r[o];
  };
  function a(e) {
    var s = t[e.main];
    return (!s || !s[o]) && (s = t[e.main] = {}, s[o] = !0), s;
  }
  u(a, "makeContainer");
}
u(j, "enableClassManagement");
export {
  T as enableClassCheck,
  w as enableClassExtend,
  j as enableClassManagement,
  O as isExtendedClass,
  I as mountExtend,
  l as parseClassType
};
