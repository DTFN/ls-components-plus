var i = Object.defineProperty;
var n = (e, t) => i(e, "name", { value: t, configurable: !0 });
import { __extends as p } from "../../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { registerAction as a } from "../../../../core/echarts/index.js";
import { clear as c } from "../../../dataZoom/history/index.js";
import { ToolboxFeature as l } from "../../featureManager/index.js";
var h = (
  /** @class */
  function(e) {
    p(t, e);
    function t() {
      return e !== null && e.apply(this, arguments) || this;
    }
    return n(t, "RestoreOption"), t.prototype.onclick = function(o, r) {
      c(o), r.dispatchAction({
        type: "restore",
        from: this.uid
      });
    }, t.getDefaultOption = function(o) {
      var r = {
        show: !0,
        // eslint-disable-next-line
        icon: "M3.8,33.4 M47,18.9h9.8V8.7 M56.3,20.1 C52.1,9,40.5,0.6,26.8,2.1C12.6,3.7,1.6,16.2,2.1,30.6 M13,41.1H3.1v10.2 M3.7,39.9c4.2,11.1,15.8,19.5,29.5,18 c14.2-1.6,25.2-14.1,24.7-28.5",
        title: o.getLocaleModel().get(["toolbox", "restore", "title"])
      };
      return r;
    }, t;
  }(l)
);
a({
  type: "restore",
  event: "restore",
  update: "prepareAndUpdate"
}, function(e, t) {
  t.resetOption("recreate");
});
export {
  h as default
};
