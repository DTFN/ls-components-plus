var p = Object.defineProperty;
var n = (r, e) => p(r, "name", { value: e, configurable: !0 });
import L from "../../model/Model/index.js";
import s from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/env/index.js";
import v from "../../i18n/langEN/index.js";
import d from "../../i18n/langZH/index.js";
import { isString as E, clone as o, merge as g } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var i = "ZH", u = "EN", t = u, a = {}, f = {}, N = s.domSupported ? function() {
  var r = (
    /* eslint-disable-next-line */
    (document.documentElement.lang || navigator.language || navigator.browserLanguage || t).toUpperCase()
  );
  return r.indexOf(i) > -1 ? i : t;
}() : t;
function m(r, e) {
  r = r.toUpperCase(), f[r] = new L(e), a[r] = e;
}
n(m, "registerLocale");
function U(r) {
  if (E(r)) {
    var e = a[r.toUpperCase()] || {};
    return r === i || r === u ? o(e) : g(o(e), o(a[t]), !1);
  } else
    return g(o(r), o(a[t]), !1);
}
n(U, "createLocaleObject");
function _(r) {
  return f[r];
}
n(_, "getLocaleModel");
function H() {
  return f[t];
}
n(H, "getDefaultLocaleModel");
m(u, v);
m(i, d);
export {
  N as SYSTEM_LANG,
  U as createLocaleObject,
  H as getDefaultLocaleModel,
  _ as getLocaleModel,
  m as registerLocale
};
