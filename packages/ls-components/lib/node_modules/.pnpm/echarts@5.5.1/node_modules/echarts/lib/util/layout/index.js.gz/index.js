var A = Object.defineProperty;
var s = (r, i) => A(r, "name", { value: i, configurable: !0 });
import { curry as z, defaults as C, isObject as B, isArray as S, each as T } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import k from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/BoundingRect/index.js";
import { parsePercent as N } from "../number/index.js";
import { normalizeCssArray as V } from "../format/index.js";
var R = T, E = ["left", "right", "top", "bottom", "width", "height"], M = [["width", "left", "right"], ["height", "top", "bottom"]];
function P(r, i, h, v, u) {
  var a = 0, f = 0;
  v == null && (v = 1 / 0), u == null && (u = 1 / 0);
  var n = 0;
  i.eachChild(function(l, t) {
    var e = l.getBoundingRect(), o = i.childAt(t + 1), c = o && o.getBoundingRect(), y, d;
    if (r === "horizontal") {
      var g = e.width + (c ? -c.x + e.x : 0);
      y = a + g, y > v || l.newline ? (a = 0, y = g, f += n + h, n = e.height) : n = Math.max(n, e.height);
    } else {
      var x = e.height + (c ? -c.y + e.y : 0);
      d = f + x, d > u || l.newline ? (a += n + h, f = 0, d = x, n = e.width) : n = Math.max(n, e.width);
    }
    l.newline || (l.x = a, l.y = f, l.markRedraw(), r === "horizontal" ? a = y + h : f = d + h);
  });
}
s(P, "boxLayout");
var J = P;
z(P, "vertical");
z(P, "horizontal");
function $(r, i, h) {
  h = V(h || 0);
  var v = i.width, u = i.height, a = N(r.left, v), f = N(r.top, u), n = N(r.right, v), l = N(r.bottom, u), t = N(r.width, v), e = N(r.height, u), o = h[2] + h[0], c = h[1] + h[3], y = r.aspect;
  switch (isNaN(t) && (t = v - n - c - a), isNaN(e) && (e = u - l - o - f), y != null && (isNaN(t) && isNaN(e) && (y > v / u ? t = v * 0.8 : e = u * 0.8), isNaN(t) && (t = y * e), isNaN(e) && (e = t / y)), isNaN(a) && (a = v - n - t - c), isNaN(f) && (f = u - l - e - o), r.left || r.right) {
    case "center":
      a = v / 2 - t / 2 - h[3];
      break;
    case "right":
      a = v - t - c;
      break;
  }
  switch (r.top || r.bottom) {
    case "middle":
    case "center":
      f = u / 2 - e / 2 - h[0];
      break;
    case "bottom":
      f = u - e - o;
      break;
  }
  a = a || 0, f = f || 0, isNaN(t) && (t = v - c - a - (n || 0)), isNaN(e) && (e = u - o - f - (l || 0));
  var d = new k(a + h[3], f + h[0], t, e);
  return d.margin = h, d;
}
s($, "getLayoutRect");
function K(r, i, h, v, u, a) {
  var f = !u || !u.hv || u.hv[0], n = !u || !u.hv || u.hv[1], l = u && u.boundingMode || "all";
  if (a = a || r, a.x = r.x, a.y = r.y, !f && !n)
    return !1;
  var t;
  if (l === "raw")
    t = r.type === "group" ? new k(0, 0, +i.width || 0, +i.height || 0) : r.getBoundingRect();
  else if (t = r.getBoundingRect(), r.needLocalTransform()) {
    var e = r.getLocalTransform();
    t = t.clone(), t.applyTransform(e);
  }
  var o = $(C({
    width: t.width,
    height: t.height
  }, i), h, v), c = f ? o.x - t.x : 0, y = n ? o.y - t.y : 0;
  return l === "raw" ? (a.x = c, a.y = y) : (a.x += c, a.y += y), a === r && r.markRedraw(), !0;
}
s(K, "positionElement");
function Q(r) {
  var i = r.layoutMode || r.constructor.layoutMode;
  return B(i) ? i : i ? {
    type: i
  } : null;
}
s(Q, "fetchLayoutMode");
function U(r, i, h) {
  var v = h && h.ignoreSize;
  !S(v) && (v = [v, v]);
  var u = f(M[0], 0), a = f(M[1], 1);
  t(M[0], r, u), t(M[1], r, a);
  function f(e, o) {
    var c = {}, y = 0, d = {}, g = 0, x = 2;
    if (R(e, function(w) {
      d[w] = r[w];
    }), R(e, function(w) {
      n(i, w) && (c[w] = d[w] = i[w]), l(c, w) && y++, l(d, w) && g++;
    }), v[o])
      return l(i, e[1]) ? d[e[2]] = null : l(i, e[2]) && (d[e[1]] = null), d;
    if (g === x || !y)
      return d;
    if (y >= x)
      return c;
    for (var L = 0; L < e.length; L++) {
      var b = e[L];
      if (!n(c, b) && n(r, b)) {
        c[b] = r[b];
        break;
      }
    }
    return c;
  }
  s(f, "merge");
  function n(e, o) {
    return e.hasOwnProperty(o);
  }
  s(n, "hasProp");
  function l(e, o) {
    return e[o] != null && e[o] !== "auto";
  }
  s(l, "hasValue");
  function t(e, o, c) {
    R(e, function(y) {
      o[y] = c[y];
    });
  }
  s(t, "copy");
}
s(U, "mergeLayoutParam");
function X(r) {
  return j({}, r);
}
s(X, "getLayoutParams");
function j(r, i) {
  return i && r && R(E, function(h) {
    i.hasOwnProperty(h) && (r[h] = i[h]);
  }), r;
}
s(j, "copyLayoutParams");
export {
  M as HV_NAMES,
  E as LOCATION_PARAMS,
  J as box,
  j as copyLayoutParams,
  Q as fetchLayoutMode,
  X as getLayoutParams,
  $ as getLayoutRect,
  U as mergeLayoutParam,
  K as positionElement
};
