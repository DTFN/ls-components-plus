var et = Object.defineProperty;
var h = (a, t) => et(a, "name", { value: t, configurable: !0 });
import { defaults as D, extend as at, isString as _, each as z, map as rt, retrieve as R, isObject as it, retrieve2 as B, isFunction as nt, isNumber as lt } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { subPixelOptimizeLine as E, setTooltipConfig as ot } from "../../../util/graphic/index.js";
import { getECData as Z } from "../../../util/innerStore/index.js";
import { createTextStyle as q } from "../../../label/labelStyle/index.js";
import st from "../../../model/Model/index.js";
import { remRadian as J, isRadianAroundZero as O } from "../../../util/number/index.js";
import { normalizeSymbolOffset as vt, createSymbol as gt } from "../../../util/symbol/index.js";
import { identity as ft, rotate as ut, mul as F } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/matrix/index.js";
import { applyTransform as V } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/vector/index.js";
import { shouldShowAllLabels as ct } from "../../../coord/axisHelper/index.js";
import { prepareLayoutList as mt, hideOverlap as ht } from "../../../label/labelLayoutHelper/index.js";
import G from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import K from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Line/index.js";
import Q from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
var T = Math.PI, k = (
  /** @class */
  function() {
    function a(t, e) {
      this.group = new G(), this.opt = e, this.axisModel = t, D(e, {
        labelOffset: 0,
        nameDirection: 1,
        tickDirection: 1,
        labelDirection: 1,
        silent: !0,
        handleAutoShown: /* @__PURE__ */ h(function() {
          return !0;
        }, "handleAutoShown")
      });
      var n = new G({
        x: e.position[0],
        y: e.position[1],
        rotation: e.rotation
      });
      n.updateTransform(), this._transformGroup = n;
    }
    return h(a, "AxisBuilder"), a.prototype.hasBuilder = function(t) {
      return !!I[t];
    }, a.prototype.add = function(t) {
      I[t](this.opt, this.axisModel, this.group, this._transformGroup);
    }, a.prototype.getGroup = function() {
      return this.group;
    }, a.innerTextLayout = function(t, e, n) {
      var r = J(e - t), l, i;
      return O(r) ? (i = n > 0 ? "top" : "bottom", l = "center") : O(r - T) ? (i = n > 0 ? "bottom" : "top", l = "center") : (i = "middle", r > 0 && r < T ? l = n > 0 ? "right" : "left" : l = n > 0 ? "left" : "right"), {
        rotation: r,
        textAlign: l,
        textVerticalAlign: i
      };
    }, a.makeAxisEventDataBase = function(t) {
      var e = {
        componentType: t.mainType,
        componentIndex: t.componentIndex
      };
      return e[t.mainType + "Index"] = t.componentIndex, e;
    }, a.isLabelSilent = function(t) {
      var e = t.get("tooltip");
      return t.get("silent") || !(t.get("triggerEvent") || e && e.show);
    }, a;
  }()
), I = {
  axisLine: /* @__PURE__ */ h(function(a, t, e, n) {
    var r = t.get(["axisLine", "show"]);
    if (r === "auto" && a.handleAutoShown && (r = a.handleAutoShown("axisLine")), !!r) {
      var l = t.axis.getExtent(), i = n.transform, o = [l[0], 0], s = [l[1], 0], f = o[0] > s[0];
      i && (V(o, o, i), V(s, s, i));
      var v = at({
        lineCap: "round"
      }, t.getModel(["axisLine", "lineStyle"]).getLineStyle()), u = new K({
        shape: {
          x1: o[0],
          y1: o[1],
          x2: s[0],
          y2: s[1]
        },
        style: v,
        strokeContainThreshold: a.strokeContainThreshold || 5,
        silent: !0,
        z2: 1
      });
      E(u.shape, u.style.lineWidth), u.anid = "line", e.add(u);
      var g = t.get(["axisLine", "symbol"]);
      if (g != null) {
        var c = t.get(["axisLine", "symbolSize"]);
        _(g) && (g = [g, g]), (_(c) || lt(c)) && (c = [c, c]);
        var x = vt(t.get(["axisLine", "symbolOffset"]) || 0, c), b = c[0], y = c[1];
        z([{
          rotate: a.rotation + Math.PI / 2,
          offset: x[0],
          r: 0
        }, {
          rotate: a.rotation - Math.PI / 2,
          offset: x[1],
          r: Math.sqrt((o[0] - s[0]) * (o[0] - s[0]) + (o[1] - s[1]) * (o[1] - s[1]))
        }], function(p, A) {
          if (g[A] !== "none" && g[A] != null) {
            var L = gt(g[A], -b / 2, -y / 2, b, y, v.stroke, !0), m = p.r + p.offset, w = f ? s : o;
            L.attr({
              rotation: p.rotate,
              x: w[0] + m * Math.cos(a.rotation),
              y: w[1] - m * Math.sin(a.rotation),
              silent: !0,
              z2: 11
            }), e.add(L);
          }
        });
      }
    }
  }, "axisLine"),
  axisTickLabel: /* @__PURE__ */ h(function(a, t, e, n) {
    var r = xt(e, n, t, a), l = dt(e, n, t, a);
    if (pt(t, l, r), yt(e, n, t, a.tickDirection), t.get(["axisLabel", "hideOverlap"])) {
      var i = mt(rt(l, function(o) {
        return {
          label: o,
          priority: o.z2,
          defaultAttr: {
            ignore: o.ignore
          }
        };
      }));
      ht(i);
    }
  }, "axisTickLabel"),
  axisName: /* @__PURE__ */ h(function(a, t, e, n) {
    var r = R(a.axisName, t.get("name"));
    if (r) {
      var l = t.get("nameLocation"), i = a.nameDirection, o = t.getModel("nameTextStyle"), s = t.get("nameGap") || 0, f = t.axis.getExtent(), v = f[0] > f[1] ? -1 : 1, u = [
        l === "start" ? f[0] - v * s : l === "end" ? f[1] + v * s : (f[0] + f[1]) / 2,
        // Reuse labelOffset.
        j(l) ? a.labelOffset + i * s : 0
      ], g, c = t.get("nameRotate");
      c != null && (c = c * T / 180);
      var x;
      j(l) ? g = k.innerTextLayout(
        a.rotation,
        c ?? a.rotation,
        // Adapt to axis.
        i
      ) : (g = Lt(a.rotation, l, c || 0, f), x = a.axisNameAvailableWidth, x != null && (x = Math.abs(x / Math.sin(g.rotation)), !isFinite(x) && (x = null)));
      var b = o.getFont(), y = t.get("nameTruncate", !0) || {}, p = y.ellipsis, A = R(a.nameTruncateMaxWidth, y.maxWidth, x), L = new Q({
        x: u[0],
        y: u[1],
        rotation: g.rotation,
        silent: k.isLabelSilent(t),
        style: q(o, {
          text: r,
          font: b,
          overflow: "truncate",
          width: A,
          ellipsis: p,
          fill: o.getTextColor() || t.get(["axisLine", "lineStyle", "color"]),
          align: o.get("align") || g.textAlign,
          verticalAlign: o.get("verticalAlign") || g.textVerticalAlign
        }),
        z2: 1
      });
      if (ot({
        el: L,
        componentModel: t,
        itemName: r
      }), L.__fullText = r, L.anid = "name", t.get("triggerEvent")) {
        var m = k.makeAxisEventDataBase(t);
        m.targetType = "axisName", m.name = r, Z(L).eventData = m;
      }
      n.add(L), L.updateTransform(), e.add(L), L.decomposeTransform();
    }
  }, "axisName")
};
function Lt(a, t, e, n) {
  var r = J(e - a), l, i, o = n[0] > n[1], s = t === "start" && !o || t !== "start" && o;
  return O(r - T / 2) ? (i = s ? "bottom" : "top", l = "center") : O(r - T * 1.5) ? (i = s ? "top" : "bottom", l = "center") : (i = "middle", r < T * 1.5 && r > T / 2 ? l = s ? "left" : "right" : l = s ? "right" : "left"), {
    rotation: r,
    textAlign: l,
    textVerticalAlign: i
  };
}
h(Lt, "endTextLayout");
function pt(a, t, e) {
  if (!ct(a.axis)) {
    var n = a.get(["axisLabel", "showMinLabel"]), r = a.get(["axisLabel", "showMaxLabel"]);
    t = t || [], e = e || [];
    var l = t[0], i = t[1], o = t[t.length - 1], s = t[t.length - 2], f = e[0], v = e[1], u = e[e.length - 1], g = e[e.length - 2];
    n === !1 ? (d(l), d(f)) : P(l, i) && (n ? (d(i), d(v)) : (d(l), d(f))), r === !1 ? (d(o), d(u)) : P(s, o) && (r ? (d(s), d(g)) : (d(o), d(u)));
  }
}
h(pt, "fixMinMaxLabelShow");
function d(a) {
  a && (a.ignore = !0);
}
h(d, "ignoreEl");
function P(a, t) {
  var e = a && a.getBoundingRect().clone(), n = t && t.getBoundingRect().clone();
  if (!(!e || !n)) {
    var r = ft([]);
    return ut(r, r, -a.rotation), e.applyTransform(F([], r, a.getLocalTransform())), n.applyTransform(F([], r, t.getLocalTransform())), e.intersect(n);
  }
}
h(P, "isTwoLabelOverlapped");
function j(a) {
  return a === "middle" || a === "center";
}
h(j, "isNameLocationCenter");
function U(a, t, e, n, r) {
  for (var l = [], i = [], o = [], s = 0; s < a.length; s++) {
    var f = a[s].coord;
    i[0] = f, i[1] = 0, o[0] = f, o[1] = e, t && (V(i, i, t), V(o, o, t));
    var v = new K({
      shape: {
        x1: i[0],
        y1: i[1],
        x2: o[0],
        y2: o[1]
      },
      style: n,
      z2: 2,
      autoBatch: !0,
      silent: !0
    });
    E(v.shape, v.style.lineWidth), v.anid = r + "_" + a[s].tickValue, l.push(v);
  }
  return l;
}
h(U, "createTicks");
function xt(a, t, e, n) {
  var r = e.axis, l = e.getModel("axisTick"), i = l.get("show");
  if (i === "auto" && n.handleAutoShown && (i = n.handleAutoShown("axisTick")), !(!i || r.scale.isBlank())) {
    for (var o = l.getModel("lineStyle"), s = n.tickDirection * l.get("length"), f = r.getTicksCoords(), v = U(f, t.transform, s, D(o.getLineStyle(), {
      stroke: e.get(["axisLine", "lineStyle", "color"])
    }), "ticks"), u = 0; u < v.length; u++)
      a.add(v[u]);
    return v;
  }
}
h(xt, "buildAxisMajorTicks");
function yt(a, t, e, n) {
  var r = e.axis, l = e.getModel("minorTick");
  if (!(!l.get("show") || r.scale.isBlank())) {
    var i = r.getMinorTicksCoords();
    if (i.length)
      for (var o = l.getModel("lineStyle"), s = n * l.get("length"), f = D(o.getLineStyle(), D(e.getModel("axisTick").getLineStyle(), {
        stroke: e.get(["axisLine", "lineStyle", "color"])
      })), v = 0; v < i.length; v++)
        for (var u = U(i[v], t.transform, s, f, "minorticks_" + v), g = 0; g < u.length; g++)
          a.add(u[g]);
  }
}
h(yt, "buildAxisMinorTicks");
function dt(a, t, e, n) {
  var r = e.axis, l = R(n.axisLabelShow, e.get(["axisLabel", "show"]));
  if (!(!l || r.scale.isBlank())) {
    var i = e.getModel("axisLabel"), o = i.get("margin"), s = r.getViewLabels(), f = (R(n.labelRotate, i.get("rotate")) || 0) * T / 180, v = k.innerTextLayout(n.rotation, f, n.labelDirection), u = e.getCategories && e.getCategories(!0), g = [], c = k.isLabelSilent(e), x = e.get("triggerEvent");
    return z(s, function(b, y) {
      var p = r.scale.type === "ordinal" ? r.scale.getRawOrdinalNumber(b.tickValue) : b.tickValue, A = b.formattedLabel, L = b.rawLabel, m = i;
      if (u && u[p]) {
        var w = u[p];
        it(w) && w.textStyle && (m = new st(w.textStyle, i, e.ecModel));
      }
      var N = m.getTextColor() || e.get(["axisLine", "lineStyle", "color"]), X = r.dataToCoord(p), M = m.getShallow("align", !0) || v.textAlign, Y = B(m.getShallow("alignMinLabel", !0), M), $ = B(m.getShallow("alignMaxLabel", !0), M), W = m.getShallow("verticalAlign", !0) || m.getShallow("baseline", !0) || v.textVerticalAlign, H = B(m.getShallow("verticalAlignMinLabel", !0), W), tt = B(m.getShallow("verticalAlignMaxLabel", !0), W), S = new Q({
        x: X,
        y: n.labelOffset + n.labelDirection * o,
        rotation: v.rotation,
        silent: c,
        z2: 10 + (b.level || 0),
        style: q(m, {
          text: A,
          align: y === 0 ? Y : y === s.length - 1 ? $ : M,
          verticalAlign: y === 0 ? H : y === s.length - 1 ? tt : W,
          fill: nt(N) ? N(
            // (1) In category axis with data zoom, tick is not the original
            // index of axis.data. So tick should not be exposed to user
            // in category axis.
            // (2) Compatible with previous version, which always use formatted label as
            // input. But in interval scale the formatted label is like '223,445', which
            // maked user replace ','. So we modify it to return original val but remain
            // it as 'string' to avoid error in replacing.
            r.type === "category" ? L : r.type === "value" ? p + "" : p,
            y
          ) : N
        })
      });
      if (S.anid = "label_" + p, x) {
        var C = k.makeAxisEventDataBase(e);
        C.targetType = "axisLabel", C.value = L, C.tickIndex = y, r.type === "category" && (C.dataIndex = p), Z(S).eventData = C;
      }
      t.add(S), S.updateTransform(), g.push(S), a.add(S), S.decomposeTransform();
    }), g;
  }
}
h(dt, "buildAxisLabel");
export {
  k as default
};
