var b = Object.defineProperty;
var p = (e, i) => b(e, "name", { value: i, configurable: !0 });
import { makeInner as O } from "../../../util/model/index.js";
import { makeKey as V } from "../modelHelper/index.js";
import C from "../findPointFromSeries/index.js";
import { bind as K, curry as B, each as v, extend as L } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var k = O();
function Q(e, i, a) {
  var n = e.currTrigger, t = [e.x, e.y], d = e, r = e.dispatchAction || K(a.dispatchAction, a), s = i.getComponent("axisPointer").coordSysAxesInfo;
  if (s) {
    M(t) && (t = C({
      seriesIndex: d.seriesIndex,
      // Do not use dataIndexInside from other ec instance.
      // FIXME: auto detect it?
      dataIndex: d.dataIndex
    }, i).point);
    var o = M(t), u = d.axesInfo, l = s.axesInfo, x = n === "leave" || M(t), c = {}, h = {}, g = {
      list: [],
      map: {}
    }, y = {
      showPointer: B(G, h),
      showTooltip: B(z, g)
    };
    v(s.coordSysMap, function(m, A) {
      var I = o || m.containPoint(t);
      v(s.coordSysAxesInfo[A], function(D, S) {
        var P = D.axis, f = X(u, D);
        if (!x && I && (!u || f)) {
          var w = f && f.value;
          w == null && !o && (w = P.pointToData(t)), w != null && N(D, w, y, !1, c);
        }
      });
    });
    var T = {};
    return v(l, function(m, A) {
      var I = m.linkGroup;
      I && !h[A] && v(I.axesInfo, function(D, S) {
        var P = h[S];
        if (D !== m && P) {
          var f = P.value;
          I.mapper && (f = m.axis.scale.parse(I.mapper(f, H(D), H(m)))), T[m.key] = f;
        }
      });
    }), v(T, function(m, A) {
      N(l[A], m, y, !0, c);
    }), F(h, l, c), R(g, t, e, r), U(l, r, a), c;
  }
}
p(Q, "axisTrigger");
function N(e, i, a, n, t) {
  var d = e.axis;
  if (!(d.scale.isBlank() || !d.containData(i))) {
    if (!e.involveSeries) {
      a.showPointer(e, i);
      return;
    }
    var r = E(i, e), s = r.payloadBatch, o = r.snapToValue;
    s[0] && t.seriesIndex == null && L(t, s[0]), !n && e.snap && d.containData(o) && o != null && (i = o), a.showPointer(e, i, s), a.showTooltip(e, r, o);
  }
}
p(N, "processOnAxis");
function E(e, i) {
  var a = i.axis, n = a.dim, t = e, d = [], r = Number.MAX_VALUE, s = -1;
  return v(i.seriesModels, function(o, u) {
    var l = o.getData().mapDimensionsAll(n), x, c;
    if (o.getAxisTooltipData) {
      var h = o.getAxisTooltipData(l, e, a);
      c = h.dataIndices, x = h.nestestValue;
    } else {
      if (c = o.getData().indicesOfNearest(
        l[0],
        e,
        // Add a threshold to avoid find the wrong dataIndex
        // when data length is not same.
        // false,
        a.type === "category" ? 0.5 : null
      ), !c.length)
        return;
      x = o.getData().get(l[0], c[0]);
    }
    if (!(x == null || !isFinite(x))) {
      var g = e - x, y = Math.abs(g);
      y <= r && ((y < r || g >= 0 && s < 0) && (r = y, s = g, t = x, d.length = 0), v(c, function(T) {
        d.push({
          seriesIndex: o.seriesIndex,
          dataIndexInside: T,
          dataIndex: o.getData().getRawIndex(T)
        });
      }));
    }
  }), {
    payloadBatch: d,
    snapToValue: t
  };
}
p(E, "buildPayloadsBySeries");
function G(e, i, a, n) {
  e[i.key] = {
    value: a,
    payloadBatch: n
  };
}
p(G, "showPointer");
function z(e, i, a, n) {
  var t = a.payloadBatch, d = i.axis, r = d.model, s = i.axisPointerModel;
  if (!(!i.triggerTooltip || !t.length)) {
    var o = i.coordSys.model, u = V(o), l = e.map[u];
    l || (l = e.map[u] = {
      coordSysId: o.id,
      coordSysIndex: o.componentIndex,
      coordSysType: o.type,
      coordSysMainType: o.mainType,
      dataByAxis: []
    }, e.list.push(l)), l.dataByAxis.push({
      axisDim: d.dim,
      axisIndex: r.componentIndex,
      axisType: r.type,
      axisId: r.id,
      value: n,
      // Caustion: viewHelper.getValueLabel is actually on "view stage", which
      // depends that all models have been updated. So it should not be performed
      // here. Considering axisPointerModel used here is volatile, which is hard
      // to be retrieve in TooltipView, we prepare parameters here.
      valueLabelOpt: {
        precision: s.get(["label", "precision"]),
        formatter: s.get(["label", "formatter"])
      },
      seriesDataIndices: t.slice()
    });
  }
}
p(z, "showTooltip");
function F(e, i, a) {
  var n = a.axesInfo = [];
  v(i, function(t, d) {
    var r = t.axisPointerModel.option, s = e[d];
    s ? (!t.useHandle && (r.status = "show"), r.value = s.value, r.seriesDataIndices = (s.payloadBatch || []).slice()) : !t.useHandle && (r.status = "hide"), r.status === "show" && n.push({
      axisDim: t.axis.dim,
      axisIndex: t.axis.model.componentIndex,
      value: r.value
    });
  });
}
p(F, "updateModelActually");
function R(e, i, a, n) {
  if (M(i) || !e.list.length) {
    n({
      type: "hideTip"
    });
    return;
  }
  var t = ((e.list[0].dataByAxis[0] || {}).seriesDataIndices || [])[0] || {};
  n({
    type: "showTip",
    escapeConnect: !0,
    x: i[0],
    y: i[1],
    tooltipOption: a.tooltipOption,
    position: a.position,
    dataIndexInside: t.dataIndexInside,
    dataIndex: t.dataIndex,
    seriesIndex: t.seriesIndex,
    dataByCoordSys: e.list
  });
}
p(R, "dispatchTooltipActually");
function U(e, i, a) {
  var n = a.getZr(), t = "axisPointerLastHighlights", d = k(n)[t] || {}, r = k(n)[t] = {};
  v(e, function(u, l) {
    var x = u.axisPointerModel.option;
    x.status === "show" && u.triggerEmphasis && v(x.seriesDataIndices, function(c) {
      var h = c.seriesIndex + " | " + c.dataIndex;
      r[h] = c;
    });
  });
  var s = [], o = [];
  v(d, function(u, l) {
    !r[l] && o.push(u);
  }), v(r, function(u, l) {
    !d[l] && s.push(u);
  }), o.length && a.dispatchAction({
    type: "downplay",
    escapeConnect: !0,
    // Not blur others when highlight in axisPointer.
    notBlur: !0,
    batch: o
  }), s.length && a.dispatchAction({
    type: "highlight",
    escapeConnect: !0,
    // Not blur others when highlight in axisPointer.
    notBlur: !0,
    batch: s
  });
}
p(U, "dispatchHighDownActually");
function X(e, i) {
  for (var a = 0; a < (e || []).length; a++) {
    var n = e[a];
    if (i.axis.dim === n.axisDim && i.axis.model.componentIndex === n.axisIndex)
      return n;
  }
}
p(X, "findInputAxisInfo");
function H(e) {
  var i = e.axis.model, a = {}, n = a.axisDim = e.axis.dim;
  return a.axisIndex = a[n + "AxisIndex"] = i.componentIndex, a.axisName = a[n + "AxisName"] = i.name, a.axisId = a[n + "AxisId"] = i.id, a;
}
p(H, "makeMapperParam");
function M(e) {
  return !e || e[0] == null || isNaN(e[0]) || e[1] == null || isNaN(e[1]);
}
p(M, "illegalPoint");
export {
  Q as default
};
