var a = Object.defineProperty;
var i = (e, o) => a(e, "name", { value: o, configurable: !0 });
import d from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import { getUID as l } from "../../util/component/index.js";
import { enableClassExtend as u, enableClassManagement as c } from "../../util/clazz/index.js";
var r = (
  /** @class */
  function() {
    function e() {
      this.group = new d(), this.uid = l("viewComponent");
    }
    return i(e, "ComponentView"), e.prototype.init = function(o, t) {
    }, e.prototype.render = function(o, t, p, n) {
    }, e.prototype.dispose = function(o, t) {
    }, e.prototype.updateView = function(o, t, p, n) {
    }, e.prototype.updateLayout = function(o, t, p, n) {
    }, e.prototype.updateVisual = function(o, t, p, n) {
    }, e.prototype.toggleBlurSeries = function(o, t, p) {
    }, e.prototype.eachRendered = function(o) {
      var t = this.group;
      t && t.traverse(o);
    }, e;
  }()
);
u(r);
c(r);
export {
  r as default
};
