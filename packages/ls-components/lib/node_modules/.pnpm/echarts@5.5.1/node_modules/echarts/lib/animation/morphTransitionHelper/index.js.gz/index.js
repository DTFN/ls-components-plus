var R = Object.defineProperty;
var g = (r, a) => R(r, "name", { value: a, configurable: !0 });
import { isCombineMorphing as U, morphPath as V, combineMorph as W, separateMorph as X } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/tool/morphPath/index.js";
import "../../util/graphic/index.js";
import { isArray as J, defaults as j } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getAnimationConfig as Y } from "../basicTransition/index.js";
import { clonePath as Z } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/tool/path/index.js";
import $ from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
function G(r) {
  return J(r[0]);
}
g(G, "isMultiple");
function H(r, a) {
  for (var t = [], i = r.length, n = 0; n < i; n++)
    t.push({
      one: r[n],
      many: []
    });
  for (var n = 0; n < a.length; n++) {
    var u = a[n].length, h = void 0;
    for (h = 0; h < u; h++)
      t[h % i].many.push(a[n][h]);
  }
  for (var e = 0, n = i - 1; n >= 0; n--)
    if (!t[n].many.length) {
      var v = t[e].many;
      if (v.length <= 1)
        if (e)
          e = 0;
        else
          return t;
      var u = v.length, l = Math.ceil(u / 2);
      t[n].many = v.slice(l, u), t[e].many = v.slice(0, l), e++;
    }
  return t;
}
g(H, "prepareMorphBatches");
var b = {
  clone: /* @__PURE__ */ g(function(r) {
    for (var a = [], t = 1 - Math.pow(1 - r.path.style.opacity, 1 / r.count), i = 0; i < r.count; i++) {
      var n = Z(r.path);
      n.setStyle("opacity", t), a.push(n);
    }
    return a;
  }, "clone"),
  // Use the default divider
  split: null
};
function er(r, a, t, i, n, u) {
  if (!r.length || !a.length)
    return;
  var h = Y("update", i, n);
  if (!(h && h.duration > 0))
    return;
  var e = i.getModel("universalTransition").get("delay"), v = Object.assign({
    // Need to setToFinal so the further calculation based on the style can be correct.
    // Like emphasis color.
    setToFinal: !0
  }, h), l, B;
  G(r) && (l = r, B = a), G(a) && (l = a, B = r);
  function w(d, y, D, O, K) {
    var p = d.many, M = d.one;
    if (p.length === 1 && !K) {
      var c = y ? p[0] : M, P = y ? M : p[0];
      if (U(c))
        w({
          many: [c],
          one: P
        }, !0, D, O, !0);
      else {
        var A = e ? j({
          delay: e(D, O)
        }, v) : v;
        V(c, P, A), u(c, P, c, P, A);
      }
    } else
      for (var S = j({
        dividePath: b[t],
        individualDelay: e && function(Q, T, _, I) {
          return e(Q + D, O);
        }
      }, v), q = y ? W(p, M, S) : X(M, p, S), z = q.fromIndividuals, N = q.toIndividuals, E = z.length, f = 0; f < E; f++) {
        var A = e ? j({
          delay: e(f, E)
        }, v) : v;
        u(z[f], N[f], y ? p[f] : d.one, y ? d.one : p[f], A);
      }
  }
  g(w, "morphOneBatch");
  for (var C = l ? l === r : r.length > a.length, s = l ? H(B, l) : H(C ? a : r, [C ? r : a]), x = 0, o = 0; o < s.length; o++)
    x += s[o].many.length;
  for (var L = 0, o = 0; o < s.length; o++)
    w(s[o], C, L, x), L += s[o].many.length;
}
g(er, "applyMorphAnimation");
function m(r) {
  if (!r)
    return [];
  if (J(r)) {
    for (var a = [], t = 0; t < r.length; t++)
      a.push(m(r[t]));
    return a;
  }
  var i = [];
  return r.traverse(function(n) {
    n instanceof $ && !n.disableMorphing && !n.invisible && !n.ignore && i.push(n);
  }), i;
}
g(m, "getPathList");
export {
  er as applyMorphAnimation,
  m as getPathList
};
