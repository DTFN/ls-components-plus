var E = Object.defineProperty;
var S = (h, i) => E(h, "name", { value: i, configurable: !0 });
import { __extends as w } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { createSymbol as x, normalizeSymbolOffset as N, normalizeSymbolSize as R } from "../../../util/symbol/index.js";
import { getECData as Z } from "../../../util/innerStore/index.js";
import { enterEmphasis as F, leaveEmphasis as k, toggleHoverEmphasis as B } from "../../../util/states/index.js";
import { getDefaultLabel as G } from "../labelHelper/index.js";
import { extend as T } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getLabelStatesModels as H, setLabelStyle as K } from "../../../label/labelStyle/index.js";
import $ from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Image/index.js";
import { updateProps as j, saveOldStyle as q, initProps as J, removeElement as L } from "../../../animation/basicTransition/index.js";
import Q from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
var yt = (
  /** @class */
  function(h) {
    w(i, h);
    function i(t, a, o, l) {
      var s = h.call(this) || this;
      return s.updateData(t, a, o, l), s;
    }
    return S(i, "Symbol"), i.prototype._createSymbol = function(t, a, o, l, s) {
      this.removeAll();
      var e = x(t, -1, -1, 2, 2, null, s);
      e.attr({
        z2: 100,
        culling: !0,
        scaleX: l[0] / 2,
        scaleY: l[1] / 2
      }), e.drift = U, this._symbolType = t, this.add(e);
    }, i.prototype.stopSymbolAnimation = function(t) {
      this.childAt(0).stopAnimation(null, t);
    }, i.prototype.getSymbolType = function() {
      return this._symbolType;
    }, i.prototype.getSymbolPath = function() {
      return this.childAt(0);
    }, i.prototype.highlight = function() {
      F(this.childAt(0));
    }, i.prototype.downplay = function() {
      k(this.childAt(0));
    }, i.prototype.setZ = function(t, a) {
      var o = this.childAt(0);
      o.zlevel = t, o.z = a;
    }, i.prototype.setDraggable = function(t, a) {
      var o = this.childAt(0);
      o.draggable = t, o.cursor = !a && t ? "move" : o.cursor;
    }, i.prototype.updateData = function(t, a, o, l) {
      this.silent = !1;
      var s = t.getItemVisual(a, "symbol") || "circle", e = t.hostModel, m = i.getSymbolSize(t, a), c = s !== this._symbolType, y = l && l.disableAnimation;
      if (c) {
        var f = t.getItemVisual(a, "symbolKeepAspect");
        this._createSymbol(s, t, a, m, f);
      } else {
        var r = this.childAt(0);
        r.silent = !1;
        var n = {
          scaleX: m[0] / 2,
          scaleY: m[1] / 2
        };
        y ? r.attr(n) : j(r, n, e, a), q(r);
      }
      if (this._updateCommon(t, a, m, o, l), c) {
        var r = this.childAt(0);
        if (!y) {
          var n = {
            scaleX: this._sizeX,
            scaleY: this._sizeY,
            style: {
              // Always fadeIn. Because it has fadeOut animation when symbol is removed..
              opacity: r.style.opacity
            }
          };
          r.scaleX = r.scaleY = 0, r.style.opacity = 0, J(r, n, e, a);
        }
      }
      y && this.childAt(0).stopAnimation("leave");
    }, i.prototype._updateCommon = function(t, a, o, l, s) {
      var e = this.childAt(0), m = t.hostModel, c, y, f, r, n, I, z, u, d;
      if (l && (c = l.emphasisItemStyle, y = l.blurItemStyle, f = l.selectItemStyle, r = l.focus, n = l.blurScope, z = l.labelStatesModels, u = l.hoverScale, d = l.cursorStyle, I = l.emphasisDisabled), !l || t.hasItemOption) {
        var v = l && l.itemModel ? l.itemModel : t.getItemModel(a), b = v.getModel("emphasis");
        c = b.getModel("itemStyle").getItemStyle(), f = v.getModel(["select", "itemStyle"]).getItemStyle(), y = v.getModel(["blur", "itemStyle"]).getItemStyle(), r = b.get("focus"), n = b.get("blurScope"), I = b.get("disabled"), z = H(v), u = b.getShallow("scale"), d = v.getShallow("cursor");
      }
      var M = t.getItemVisual(a, "symbolRotate");
      e.attr("rotation", (M || 0) * Math.PI / 180 || 0);
      var _ = N(t.getItemVisual(a, "symbolOffset"), o);
      _ && (e.x = _[0], e.y = _[1]), d && e.attr("cursor", d);
      var p = t.getItemVisual(a, "style"), Y = p.fill;
      if (e instanceof $) {
        var g = e.style;
        e.useStyle(T({
          // TODO other properties like x, y ?
          image: g.image,
          x: g.x,
          y: g.y,
          width: g.width,
          height: g.height
        }, p));
      } else
        e.__isEmptyBrush ? e.useStyle(T({}, p)) : e.useStyle(p), e.style.decal = null, e.setColor(Y, s && s.symbolInnerColor), e.style.strokeNoScale = !0;
      var X = t.getItemVisual(a, "liftZ"), A = this._z2;
      X != null ? A == null && (this._z2 = e.z2, e.z2 += X) : A != null && (e.z2 = A, this._z2 = null);
      var P = s && s.useNameLabel;
      K(e, z, {
        labelFetcher: m,
        labelDataIndex: a,
        defaultText: V,
        inheritColor: Y,
        defaultOpacity: p.opacity
      });
      function V(D) {
        return P ? t.getName(D) : G(t, D);
      }
      S(V, "getLabelDefaultText"), this._sizeX = o[0] / 2, this._sizeY = o[1] / 2;
      var O = e.ensureState("emphasis");
      O.style = c, e.ensureState("select").style = f, e.ensureState("blur").style = y;
      var C = u == null || u === !0 ? Math.max(1.1, 3 / this._sizeY) : isFinite(u) && u > 0 ? +u : 1;
      O.scaleX = this._sizeX * C, O.scaleY = this._sizeY * C, this.setSymbolScale(1), B(this, r, n, I);
    }, i.prototype.setSymbolScale = function(t) {
      this.scaleX = this.scaleY = t;
    }, i.prototype.fadeOut = function(t, a, o) {
      var l = this.childAt(0), s = Z(this).dataIndex, e = o && o.animation;
      if (this.silent = l.silent = !0, o && o.fadeLabel) {
        var m = l.getTextContent();
        m && L(m, {
          style: {
            opacity: 0
          }
        }, a, {
          dataIndex: s,
          removeOpt: e,
          cb: /* @__PURE__ */ S(function() {
            l.removeTextContent();
          }, "cb")
        });
      } else
        l.removeTextContent();
      L(l, {
        style: {
          opacity: 0
        },
        scaleX: 0,
        scaleY: 0
      }, a, {
        dataIndex: s,
        cb: t,
        removeOpt: e
      });
    }, i.getSymbolSize = function(t, a) {
      return R(t.getItemVisual(a, "symbolSize"));
    }, i;
  }(Q)
);
function U(h, i) {
  this.parent.drift(h, i);
}
S(U, "driftSymbol");
export {
  yt as default
};
