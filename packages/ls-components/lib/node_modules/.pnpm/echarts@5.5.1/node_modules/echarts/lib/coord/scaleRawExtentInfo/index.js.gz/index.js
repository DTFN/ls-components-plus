var c = Object.defineProperty;
var d = (r, i) => c(r, "name", { value: i, configurable: !0 });
import { isFunction as p, isArray as w, assert as x, eqNaN as M } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { parsePercent as N } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/contain/text/index.js";
var y = (
  /** @class */
  function() {
    function r(i, a, e) {
      this._prepareParams(i, a, e);
    }
    return d(r, "ScaleRawExtentInfo"), r.prototype._prepareParams = function(i, a, e) {
      e[1] < e[0] && (e = [NaN, NaN]), this._dataMin = e[0], this._dataMax = e[1];
      var l = this._isOrdinal = i.type === "ordinal";
      this._needCrossZero = i.type === "interval" && a.getNeedCrossZero && a.getNeedCrossZero();
      var u = a.get("min", !0);
      u == null && (u = a.get("startValue", !0));
      var o = this._modelMinRaw = u;
      p(o) ? this._modelMinNum = f(i, o({
        min: e[0],
        max: e[1]
      })) : o !== "dataMin" && (this._modelMinNum = f(i, o));
      var n = this._modelMaxRaw = a.get("max", !0);
      if (p(n) ? this._modelMaxNum = f(i, n({
        min: e[0],
        max: e[1]
      })) : n !== "dataMax" && (this._modelMaxNum = f(i, n)), l)
        this._axisDataLen = a.getCategories().length;
      else {
        var t = a.get("boundaryGap"), s = w(t) ? t : [t || 0, t || 0];
        typeof s[0] == "boolean" || typeof s[1] == "boolean" ? (process.env.NODE_ENV !== "production" && console.warn('Boolean type for boundaryGap is only allowed for ordinal axis. Please use string in percentage instead, e.g., "20%". Currently, boundaryGap is set to be 0.'), this._boundaryGapInner = [0, 0]) : this._boundaryGapInner = [N(s[0], 1), N(s[1], 1)];
      }
    }, r.prototype.calculate = function() {
      var i = this._isOrdinal, a = this._dataMin, e = this._dataMax, l = this._axisDataLen, u = this._boundaryGapInner, o = i ? null : e - a || Math.abs(a), n = this._modelMinRaw === "dataMin" ? a : this._modelMinNum, t = this._modelMaxRaw === "dataMax" ? e : this._modelMaxNum, s = n != null, m = t != null;
      n == null && (n = i ? l ? 0 : NaN : a - u[0] * o), t == null && (t = i ? l ? l - 1 : NaN : e + u[1] * o), (n == null || !isFinite(n)) && (n = NaN), (t == null || !isFinite(t)) && (t = NaN);
      var v = M(n) || M(t) || i && !l;
      this._needCrossZero && (n > 0 && t > 0 && !s && (n = 0), n < 0 && t < 0 && !m && (t = 0));
      var _ = this._determinedMin, h = this._determinedMax;
      return _ != null && (n = _, s = !0), h != null && (t = h, m = !0), {
        min: n,
        max: t,
        minFixed: s,
        maxFixed: m,
        isBlank: v
      };
    }, r.prototype.modifyDataMinMax = function(i, a) {
      process.env.NODE_ENV !== "production" && x(!this.frozen), this[g[i]] = a;
    }, r.prototype.setDeterminedMinMax = function(i, a) {
      var e = I[i];
      process.env.NODE_ENV !== "production" && x(!this.frozen && this[e] == null), this[e] = a;
    }, r.prototype.freeze = function() {
      this.frozen = !0;
    }, r;
  }()
), I = {
  min: "_determinedMin",
  max: "_determinedMax"
}, g = {
  min: "_dataMin",
  max: "_dataMax"
};
function F(r, i, a) {
  var e = r.rawExtentInfo;
  return e || (e = new y(r, i, a), r.rawExtentInfo = e, e);
}
d(F, "ensureScaleRawExtentInfo");
function f(r, i) {
  return i == null ? null : M(i) ? NaN : r.parse(i);
}
d(f, "parseAxisModelMinMax");
export {
  y as ScaleRawExtentInfo,
  F as ensureScaleRawExtentInfo,
  f as parseAxisModelMinMax
};
