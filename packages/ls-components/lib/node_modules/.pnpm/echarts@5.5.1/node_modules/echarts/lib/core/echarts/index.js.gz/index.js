var yt = Object.defineProperty;
var v = (c, s) => yt(c, "name", { value: s, configurable: !0 });
import { __extends as Se } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { init as Le } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/zrender/index.js";
import { isDom as Rt, isString as Ot, retrieve2 as B, bind as Me, clone as xe, setAsPrimitive as wt, isObject as X, each as R, extend as z, assert as ee, createHashMap as Ne, map as At, indexOf as et, noop as K, defaults as Pt, isFunction as tt } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import b from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/env/index.js";
import ne from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/timsort/index.js";
import Re from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/Eventful/index.js";
import Dt from "../../model/Global/index.js";
import Vt from "../ExtensionAPI/index.js";
import rt from "../CoordinateSystem/index.js";
import It from "../../model/OptionManager/index.js";
import it from "../../preprocessor/backwardCompat/index.js";
import Lt from "../../processor/dataStack/index.js";
import Ue from "../../model/Series/index.js";
import Mt from "../../view/Component/index.js";
import ae from "../../view/Chart/index.js";
import { getECData as oe } from "../../util/innerStore/index.js";
import { isSelectChangePayload as ke, isHighDownPayload as ze, allLeaveBlur as xt, getAllSelectedIndices as Nt, updateSeriesElementSelection as be, HOVER_STATE_EMPHASIS as Ut, HOVER_STATE_BLUR as kt, savePathStates as zt, enterEmphasis as Fe, leaveEmphasis as He, enterBlur as bt, leaveBlur as Ft, enterSelect as Ht, leaveSelect as Yt, HIGHLIGHT_ACTION_TYPE as H, DOWNPLAY_ACTION_TYPE as se, SELECT_ACTION_TYPE as ue, UNSELECT_ACTION_TYPE as fe, TOGGLE_SELECT_ACTION_TYPE as de, blurSeriesFromHighlightPayload as Bt, findComponentHighDownDispatchers as Gt, blurComponent as Wt, toggleSelectionFromPayload as Xt, isHighDownDispatcher as Ye, handleGlobalMouseOverForHighDown as Zt, handleGlobalMouseOutForHighDown as qt } from "../../util/states/index.js";
import { setAttribute as nt, getAttribute as Kt, parseFinder as pe, preParseFinder as $t, convertOptionIdName as jt, normalizeToArray as Jt } from "../../util/model/index.js";
import { throttle as Qt } from "../../util/throttle/index.js";
import { seriesStyleTask as er, dataStyleTask as tr, dataColorPaletteTask as rr } from "../../visual/style/index.js";
import ir from "../../loading/default/index.js";
import at from "../Scheduler/index.js";
import nr from "../../theme/light/index.js";
import ar from "../../theme/dark/index.js";
import { parseClassType as Be } from "../../util/clazz/index.js";
import { ECEventProcessor as or } from "../../util/ECEventProcessor/index.js";
import { seriesSymbolTask as sr, dataSymbolTask as ur } from "../../visual/symbol/index.js";
import { getItemVisualFromData as fr, getVisualFromData as dr } from "../../visual/helper/index.js";
import { deprecateLog as ot, warn as U, error as Ge, deprecateReplaceLog as pr } from "../../util/log/index.js";
import { handleLegacySelectEvents as lr } from "../../legacy/dataSelectAction/index.js";
import { registerExternalTransform as cr } from "../../data/helper/transform/index.js";
import { createLocaleObject as hr, SYSTEM_LANG as vr } from "../locale/index.js";
import { registerLocale as bi } from "../locale/index.js";
import { findEventDispatcher as j } from "../../util/event/index.js";
import _r from "../../visual/decal/index.js";
import M from "../lifecycle/index.js";
import { platformApi as gr } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/platform/index.js";
import { getImpl as mr } from "../impl/index.js";
import Tr from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
import Sr from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Image/index.js";
import Er from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
import { isElementRemoved as le } from "../../animation/basicTransition/index.js";
var Cr = 1, yr = 800, Rr = 900, Or = 1e3, wr = 2e3, Ar = 5e3, st = 1e3, Pr = 1100, Oe = 2e3, ut = 3e3, Dr = 4e3, ie = 4500, Vr = 4600, Ir = 5e3, Lr = 6e3, ft = 7e3, Di = {
  PROCESSOR: {
    FILTER: Or,
    SERIES_FILTER: yr,
    STATISTIC: Ar
  },
  VISUAL: {
    LAYOUT: st,
    PROGRESSIVE_LAYOUT: Pr,
    GLOBAL: Oe,
    CHART: ut,
    POST_CHART_LAYOUT: Vr,
    COMPONENT: Dr,
    BRUSH: Ir,
    CHART_ITEM: ie,
    ARIA: Lr,
    DECAL: ft
  }
}, w = "__flagInMainProcess", A = "__pendingUpdate", ce = "__needsUpdateStatus", We = /^[a-zA-Z0-9_]+$/, he = "__connectUpdateStatus", Xe = 0, Mr = 1, xr = 2;
function dt(c) {
  return function() {
    for (var s = [], r = 0; r < arguments.length; r++)
      s[r] = arguments[r];
    if (this.isDisposed()) {
      D(this.id);
      return;
    }
    return lt(this, c, s);
  };
}
v(dt, "createRegisterEventWithLowercaseECharts");
function pt(c) {
  return function() {
    for (var s = [], r = 0; r < arguments.length; r++)
      s[r] = arguments[r];
    return lt(this, c, s);
  };
}
v(pt, "createRegisterEventWithLowercaseMessageCenter");
function lt(c, s, r) {
  return r[0] = r[0] && r[0].toLowerCase(), Re.prototype[s].apply(c, r);
}
v(lt, "toLowercaseNameAndCallEventful");
var ct = (
  /** @class */
  function(c) {
    Se(s, c);
    function s() {
      return c !== null && c.apply(this, arguments) || this;
    }
    return v(s, "MessageCenter"), s;
  }(Re)
), ht = ct.prototype;
ht.on = pt("on");
ht.off = pt("off");
var F, ve, J, k, _e, ge, me, G, W, Ze, qe, Te, Ke, Q, $e, vt, I, je, _t = (
  /** @class */
  function(c) {
    Se(s, c);
    function s(r, a, l) {
      var u = c.call(this, new or()) || this;
      u._chartsViews = [], u._chartsMap = {}, u._componentsViews = [], u._componentsMap = {}, u._pendingActions = [], l = l || {}, Ot(a) && (a = gt[a]), u._dom = r;
      var T = "canvas", C = "auto", m = !1;
      if (process.env.NODE_ENV !== "production") {
        var y = (
          /* eslint-disable-next-line */
          b.hasGlobalWindow ? window : global
        );
        y && (T = B(y.__ECHARTS__DEFAULT__RENDERER__, T), C = B(y.__ECHARTS__DEFAULT__COARSE_POINTER, C), m = B(y.__ECHARTS__DEFAULT__USE_DIRTY_RECT__, m));
      }
      l.ssr;
      var S = u._zr = Le(r, {
        renderer: l.renderer || T,
        devicePixelRatio: l.devicePixelRatio,
        width: l.width,
        height: l.height,
        ssr: l.ssr,
        useDirtyRect: B(l.useDirtyRect, m),
        useCoarsePointer: B(l.useCoarsePointer, C),
        pointerSize: l.pointerSize
      });
      u._ssr = l.ssr, u._throttledZrFlush = Qt(Me(S.flush, S), 17), a = xe(a), a && it(a, !0), u._theme = a, u._locale = hr(l.locale || vr), u._coordSysMgr = new rt();
      var e = u._api = $e(u);
      function i(t, n) {
        return t.__prio - n.__prio;
      }
      return v(i, "prioritySortFunc"), ne(re, i), ne(Ee, i), u._scheduler = new at(u, e, Ee, re), u._messageCenter = new ct(), u._initEvents(), u.resize = Me(u.resize, u), S.animation.on("frame", u._onframe, u), Ze(S, u), qe(S, u), wt(u), u;
    }
    return v(s, "ECharts"), s.prototype._onframe = function() {
      if (!this._disposed) {
        je(this);
        var r = this._scheduler;
        if (this[A]) {
          var a = this[A].silent;
          this[w] = !0;
          try {
            F(this), k.update.call(this, null, this[A].updateParams);
          } catch (m) {
            throw this[w] = !1, this[A] = null, m;
          }
          this._zr.flush(), this[w] = !1, this[A] = null, G.call(this, a), W.call(this, a);
        } else if (r.unfinished) {
          var l = Cr, u = this._model, T = this._api;
          r.unfinished = !1;
          do {
            var C = +/* @__PURE__ */ new Date();
            r.performSeriesTasks(u), r.performDataProcessorTasks(u), ge(this, u), r.performVisualTasks(u), Q(this, this._model, T, "remain", {}), l -= +/* @__PURE__ */ new Date() - C;
          } while (l > 0 && r.unfinished);
          r.unfinished || this._zr.flush();
        }
      }
    }, s.prototype.getDom = function() {
      return this._dom;
    }, s.prototype.getId = function() {
      return this.id;
    }, s.prototype.getZr = function() {
      return this._zr;
    }, s.prototype.isSSR = function() {
      return this._ssr;
    }, s.prototype.setOption = function(r, a, l) {
      if (this[w]) {
        process.env.NODE_ENV !== "production" && Ge("`setOption` should not be called during main process.");
        return;
      }
      if (this._disposed) {
        D(this.id);
        return;
      }
      var u, T, C;
      if (X(a) && (l = a.lazyUpdate, u = a.silent, T = a.replaceMerge, C = a.transition, a = a.notMerge), this[w] = !0, !this._model || a) {
        var m = new It(this._api), y = this._theme, S = this._model = new Dt();
        S.scheduler = this._scheduler, S.ssr = this._ssr, S.init(null, null, null, y, this._locale, m);
      }
      this._model.setOption(r, {
        replaceMerge: T
      }, Ce);
      var e = {
        seriesTransition: C,
        optionChanged: !0
      };
      if (l)
        this[A] = {
          silent: u,
          updateParams: e
        }, this[w] = !1, this.getZr().wakeUp();
      else {
        try {
          F(this), k.update.call(this, null, e);
        } catch (i) {
          throw this[A] = null, this[w] = !1, i;
        }
        this._ssr || this._zr.flush(), this[A] = null, this[w] = !1, G.call(this, u), W.call(this, u);
      }
    }, s.prototype.setTheme = function() {
      ot("ECharts#setTheme() is DEPRECATED in ECharts 3.0");
    }, s.prototype.getModel = function() {
      return this._model;
    }, s.prototype.getOption = function() {
      return this._model && this._model.getOption();
    }, s.prototype.getWidth = function() {
      return this._zr.getWidth();
    }, s.prototype.getHeight = function() {
      return this._zr.getHeight();
    }, s.prototype.getDevicePixelRatio = function() {
      return this._zr.painter.dpr || b.hasGlobalWindow && window.devicePixelRatio || 1;
    }, s.prototype.getRenderedCanvas = function(r) {
      return process.env.NODE_ENV !== "production" && pr("getRenderedCanvas", "renderToCanvas"), this.renderToCanvas(r);
    }, s.prototype.renderToCanvas = function(r) {
      r = r || {};
      var a = this._zr.painter;
      if (process.env.NODE_ENV !== "production" && a.type !== "canvas")
        throw new Error("renderToCanvas can only be used in the canvas renderer.");
      return a.getRenderedCanvas({
        backgroundColor: r.backgroundColor || this._model.get("backgroundColor"),
        pixelRatio: r.pixelRatio || this.getDevicePixelRatio()
      });
    }, s.prototype.renderToSVGString = function(r) {
      r = r || {};
      var a = this._zr.painter;
      if (process.env.NODE_ENV !== "production" && a.type !== "svg")
        throw new Error("renderToSVGString can only be used in the svg renderer.");
      return a.renderToString({
        useViewBox: r.useViewBox
      });
    }, s.prototype.getSvgDataURL = function() {
      if (b.svgSupported) {
        var r = this._zr, a = r.storage.getDisplayList();
        return R(a, function(l) {
          l.stopAnimation(null, !0);
        }), r.painter.toDataURL();
      }
    }, s.prototype.getDataURL = function(r) {
      if (this._disposed) {
        D(this.id);
        return;
      }
      r = r || {};
      var a = r.excludeComponents, l = this._model, u = [], T = this;
      R(a, function(m) {
        l.eachComponent({
          mainType: m
        }, function(y) {
          var S = T._componentsMap[y.__viewId];
          S.group.ignore || (u.push(S), S.group.ignore = !0);
        });
      });
      var C = this._zr.painter.getType() === "svg" ? this.getSvgDataURL() : this.renderToCanvas(r).toDataURL("image/" + (r && r.type || "png"));
      return R(u, function(m) {
        m.group.ignore = !1;
      }), C;
    }, s.prototype.getConnectedDataURL = function(r) {
      if (this._disposed) {
        D(this.id);
        return;
      }
      var a = r.type === "svg", l = this.group, u = Math.min, T = Math.max, C = 1 / 0;
      if (Je[l]) {
        var m = C, y = C, S = -C, e = -C, i = [], t = r && r.pixelRatio || this.getDevicePixelRatio();
        R(q, function(d, _) {
          if (d.group === l) {
            var E = a ? d.getZr().painter.getSvgDom().innerHTML : d.renderToCanvas(xe(r)), g = d.getDom().getBoundingClientRect();
            m = u(g.left, m), y = u(g.top, y), S = T(g.right, S), e = T(g.bottom, e), i.push({
              dom: E,
              left: g.left,
              top: g.top
            });
          }
        }), m *= t, y *= t, S *= t, e *= t;
        var n = S - m, o = e - y, p = gr.createCanvas(), f = Le(p, {
          renderer: a ? "svg" : "canvas"
        });
        if (f.resize({
          width: n,
          height: o
        }), a) {
          var h = "";
          return R(i, function(d) {
            var _ = d.left - m, E = d.top - y;
            h += '<g transform="translate(' + _ + "," + E + ')">' + d.dom + "</g>";
          }), f.painter.getSvgRoot().innerHTML = h, r.connectedBackgroundColor && f.painter.setBackgroundColor(r.connectedBackgroundColor), f.refreshImmediately(), f.painter.toDataURL();
        } else
          return r.connectedBackgroundColor && f.add(new Tr({
            shape: {
              x: 0,
              y: 0,
              width: n,
              height: o
            },
            style: {
              fill: r.connectedBackgroundColor
            }
          })), R(i, function(d) {
            var _ = new Sr({
              style: {
                x: d.left * t - m,
                y: d.top * t - y,
                image: d.dom
              }
            });
            f.add(_);
          }), f.refreshImmediately(), p.toDataURL("image/" + (r && r.type || "png"));
      } else
        return this.getDataURL(r);
    }, s.prototype.convertToPixel = function(r, a) {
      return _e(this, "convertToPixel", r, a);
    }, s.prototype.convertFromPixel = function(r, a) {
      return _e(this, "convertFromPixel", r, a);
    }, s.prototype.containPixel = function(r, a) {
      if (this._disposed) {
        D(this.id);
        return;
      }
      var l = this._model, u, T = pe(l, r);
      return R(T, function(C, m) {
        m.indexOf("Models") >= 0 && R(C, function(y) {
          var S = y.coordinateSystem;
          if (S && S.containPoint)
            u = u || !!S.containPoint(a);
          else if (m === "seriesModels") {
            var e = this._chartsMap[y.__viewId];
            e && e.containPoint ? u = u || e.containPoint(a, y) : process.env.NODE_ENV !== "production" && U(m + ": " + (e ? "The found component do not support containPoint." : "No view mapping to the found component."));
          } else
            process.env.NODE_ENV !== "production" && U(m + ": containPoint is not supported");
        }, this);
      }, this), !!u;
    }, s.prototype.getVisual = function(r, a) {
      var l = this._model, u = pe(l, r, {
        defaultMainType: "series"
      }), T = u.seriesModel;
      process.env.NODE_ENV !== "production" && (T || U("There is no specified series model"));
      var C = T.getData(), m = u.hasOwnProperty("dataIndexInside") ? u.dataIndexInside : u.hasOwnProperty("dataIndex") ? C.indexOfRawIndex(u.dataIndex) : null;
      return m != null ? fr(C, m, a) : dr(C, a);
    }, s.prototype.getViewOfComponentModel = function(r) {
      return this._componentsMap[r.__viewId];
    }, s.prototype.getViewOfSeriesModel = function(r) {
      return this._chartsMap[r.__viewId];
    }, s.prototype._initEvents = function() {
      var r = this;
      R(Nr, function(a) {
        var l = /* @__PURE__ */ v(function(u) {
          var T = r.getModel(), C = u.target, m, y = a === "globalout";
          if (y ? m = {} : C && j(C, function(n) {
            var o = oe(n);
            if (o && o.dataIndex != null) {
              var p = o.dataModel || T.getSeriesByIndex(o.seriesIndex);
              return m = p && p.getDataParams(o.dataIndex, o.dataType, C) || {}, !0;
            } else if (o.eventData)
              return m = z({}, o.eventData), !0;
          }, !0), m) {
            var S = m.componentType, e = m.componentIndex;
            (S === "markLine" || S === "markPoint" || S === "markArea") && (S = "series", e = m.seriesIndex);
            var i = S && e != null && T.getComponent(S, e), t = i && r[i.mainType === "series" ? "_chartsMap" : "_componentsMap"][i.__viewId];
            process.env.NODE_ENV !== "production" && !y && !(i && t) && U("model or view can not be found by params"), m.event = u, m.type = a, r._$eventProcessor.eventInfo = {
              targetEl: C,
              packedEvent: m,
              model: i,
              view: t
            }, r.trigger(a, m);
          }
        }, "handler");
        l.zrEventfulCallAtLast = !0, r._zr.on(a, l, r);
      }), R(Z, function(a, l) {
        r._messageCenter.on(l, function(u) {
          this.trigger(l, u);
        }, r);
      }), R(["selectchanged"], function(a) {
        r._messageCenter.on(a, function(l) {
          this.trigger(a, l);
        }, r);
      }), lr(this._messageCenter, this, this._api);
    }, s.prototype.isDisposed = function() {
      return this._disposed;
    }, s.prototype.clear = function() {
      if (this._disposed) {
        D(this.id);
        return;
      }
      this.setOption({
        series: []
      }, !0);
    }, s.prototype.dispose = function() {
      if (this._disposed) {
        D(this.id);
        return;
      }
      this._disposed = !0;
      var r = this.getDom();
      r && nt(this.getDom(), Ae, "");
      var a = this, l = a._api, u = a._model;
      R(a._componentsViews, function(T) {
        T.dispose(u, l);
      }), R(a._chartsViews, function(T) {
        T.dispose(u, l);
      }), a._zr.dispose(), a._dom = a._model = a._chartsMap = a._componentsMap = a._chartsViews = a._componentsViews = a._scheduler = a._api = a._zr = a._throttledZrFlush = a._theme = a._coordSysMgr = a._messageCenter = null, delete q[a.id];
    }, s.prototype.resize = function(r) {
      if (this[w]) {
        process.env.NODE_ENV !== "production" && Ge("`resize` should not be called during main process.");
        return;
      }
      if (this._disposed) {
        D(this.id);
        return;
      }
      this._zr.resize(r);
      var a = this._model;
      if (this._loadingFX && this._loadingFX.resize(), !!a) {
        var l = a.resetOption("media"), u = r && r.silent;
        this[A] && (u == null && (u = this[A].silent), l = !0, this[A] = null), this[w] = !0;
        try {
          l && F(this), k.update.call(this, {
            type: "resize",
            animation: z({
              // Disable animation
              duration: 0
            }, r && r.animation)
          });
        } catch (T) {
          throw this[w] = !1, T;
        }
        this[w] = !1, G.call(this, u), W.call(this, u);
      }
    }, s.prototype.showLoading = function(r, a) {
      if (this._disposed) {
        D(this.id);
        return;
      }
      if (X(r) && (a = r, r = ""), r = r || "default", this.hideLoading(), !ye[r]) {
        process.env.NODE_ENV !== "production" && U("Loading effects " + r + " not exists.");
        return;
      }
      var l = ye[r](this._api, a), u = this._zr;
      this._loadingFX = l, u.add(l);
    }, s.prototype.hideLoading = function() {
      if (this._disposed) {
        D(this.id);
        return;
      }
      this._loadingFX && this._zr.remove(this._loadingFX), this._loadingFX = null;
    }, s.prototype.makeActionFromEvent = function(r) {
      var a = z({}, r);
      return a.type = Z[r.type], a;
    }, s.prototype.dispatchAction = function(r, a) {
      if (this._disposed) {
        D(this.id);
        return;
      }
      if (X(a) || (a = {
        silent: !!a
      }), !!te[r.type] && this._model) {
        if (this[w]) {
          this._pendingActions.push(r);
          return;
        }
        var l = a.silent;
        me.call(this, r, l);
        var u = a.flush;
        u ? this._zr.flush() : u !== !1 && b.browser.weChat && this._throttledZrFlush(), G.call(this, l), W.call(this, l);
      }
    }, s.prototype.updateLabelLayout = function() {
      M.trigger("series:layoutlabels", this._model, this._api, {
        // Not adding series labels.
        // TODO
        updatedSeries: []
      });
    }, s.prototype.appendData = function(r) {
      if (this._disposed) {
        D(this.id);
        return;
      }
      var a = r.seriesIndex, l = this.getModel(), u = l.getSeriesByIndex(a);
      process.env.NODE_ENV !== "production" && ee(r.data && u), u.appendData(r), this._scheduler.unfinished = !0, this.getZr().wakeUp();
    }, s.internalField = function() {
      F = /* @__PURE__ */ v(function(e) {
        var i = e._scheduler;
        i.restorePipelines(e._model), i.prepareStageTasks(), ve(e, !0), ve(e, !1), i.plan();
      }, "prepare"), ve = /* @__PURE__ */ v(function(e, i) {
        for (var t = e._model, n = e._scheduler, o = i ? e._componentsViews : e._chartsViews, p = i ? e._componentsMap : e._chartsMap, f = e._zr, h = e._api, d = 0; d < o.length; d++)
          o[d].__alive = !1;
        i ? t.eachComponent(function(g, P) {
          g !== "series" && _(P);
        }) : t.eachSeries(_);
        function _(g) {
          var P = g.__requireNewView;
          g.__requireNewView = !1;
          var x = "_ec_" + g.id + "_" + g.type, O = !P && p[x];
          if (!O) {
            var L = Be(g.type), N = i ? Mt.getClass(L.main, L.sub) : (
              // FIXME:TS
              // (ChartView as ChartViewConstructor).getClass('series', classType.sub)
              // For backward compat, still support a chart type declared as only subType
              // like "liquidfill", but recommend "series.liquidfill"
              // But need a base class to make a type series.
              ae.getClass(L.sub)
            );
            process.env.NODE_ENV !== "production" && ee(N, L.sub + " does not exist."), O = new N(), O.init(t, h), p[x] = O, o.push(O), f.add(O.group);
          }
          g.__viewId = O.__id = x, O.__alive = !0, O.__model = g, O.group.__ecComponentInfo = {
            mainType: g.mainType,
            index: g.componentIndex
          }, !i && n.prepareView(O, g, t, h);
        }
        v(_, "doPrepare");
        for (var d = 0; d < o.length; ) {
          var E = o[d];
          E.__alive ? d++ : (!i && E.renderTask.dispose(), f.remove(E.group), E.dispose(t, h), o.splice(d, 1), p[E.__id] === E && delete p[E.__id], E.__id = E.group.__ecComponentInfo = null);
        }
      }, "prepareView"), J = /* @__PURE__ */ v(function(e, i, t, n, o) {
        var p = e._model;
        if (p.setUpdatePayload(t), !n) {
          R([].concat(e._componentsViews).concat(e._chartsViews), E);
          return;
        }
        var f = {};
        f[n + "Id"] = t[n + "Id"], f[n + "Index"] = t[n + "Index"], f[n + "Name"] = t[n + "Name"];
        var h = {
          mainType: n,
          query: f
        };
        o && (h.subType = o);
        var d = t.excludeSeriesId, _;
        d != null && (_ = Ne(), R(Jt(d), function(g) {
          var P = jt(g, null);
          P != null && _.set(P, !0);
        })), p && p.eachComponent(h, function(g) {
          var P = _ && _.get(g.id) != null;
          if (!P)
            if (ze(t))
              if (g instanceof Ue)
                t.type === H && !t.notBlur && !g.get(["emphasis", "disabled"]) && Bt(g, t, e._api);
              else {
                var x = Gt(g.mainType, g.componentIndex, t.name, e._api), O = x.focusSelf, L = x.dispatchers;
                t.type === H && O && !t.notBlur && Wt(g.mainType, g.componentIndex, e._api), L && R(L, function(N) {
                  t.type === H ? Fe(N) : He(N);
                });
              }
            else ke(t) && g instanceof Ue && (Xt(g, t, e._api), be(g), I(e));
        }, e), p && p.eachComponent(h, function(g) {
          var P = _ && _.get(g.id) != null;
          P || E(e[n === "series" ? "_chartsMap" : "_componentsMap"][g.__viewId]);
        }, e);
        function E(g) {
          g && g.__alive && g[i] && g[i](g.__model, p, e._api, t);
        }
        v(E, "callView");
      }, "updateDirectly"), k = {
        prepareAndUpdate: /* @__PURE__ */ v(function(e) {
          F(this), k.update.call(this, e, {
            // Needs to mark option changed if newOption is given.
            // It's from MagicType.
            // TODO If use a separate flag optionChanged in payload?
            optionChanged: e.newOption != null
          });
        }, "prepareAndUpdate"),
        update: /* @__PURE__ */ v(function(e, i) {
          var t = this._model, n = this._api, o = this._zr, p = this._coordSysMgr, f = this._scheduler;
          if (t) {
            t.setUpdatePayload(e), f.restoreData(t, e), f.performSeriesTasks(t), p.create(t, n), f.performDataProcessorTasks(t, e), ge(this, t), p.update(t, n), r(t), f.performVisualTasks(t, e), Te(this, t, n, e, i);
            var h = t.get("backgroundColor") || "transparent", d = t.get("darkMode");
            o.setBackgroundColor(h), d != null && d !== "auto" && o.setDarkMode(d), M.trigger("afterupdate", t, n);
          }
        }, "update"),
        updateTransform: /* @__PURE__ */ v(function(e) {
          var i = this, t = this._model, n = this._api;
          if (t) {
            t.setUpdatePayload(e);
            var o = [];
            t.eachComponent(function(f, h) {
              if (f !== "series") {
                var d = i.getViewOfComponentModel(h);
                if (d && d.__alive)
                  if (d.updateTransform) {
                    var _ = d.updateTransform(h, t, n, e);
                    _ && _.update && o.push(d);
                  } else
                    o.push(d);
              }
            });
            var p = Ne();
            t.eachSeries(function(f) {
              var h = i._chartsMap[f.__viewId];
              if (h.updateTransform) {
                var d = h.updateTransform(f, t, n, e);
                d && d.update && p.set(f.uid, 1);
              } else
                p.set(f.uid, 1);
            }), r(t), this._scheduler.performVisualTasks(t, e, {
              setDirty: !0,
              dirtyMap: p
            }), Q(this, t, n, e, {}, p), M.trigger("afterupdate", t, n);
          }
        }, "updateTransform"),
        updateView: /* @__PURE__ */ v(function(e) {
          var i = this._model;
          i && (i.setUpdatePayload(e), ae.markUpdateMethod(e, "updateView"), r(i), this._scheduler.performVisualTasks(i, e, {
            setDirty: !0
          }), Te(this, i, this._api, e, {}), M.trigger("afterupdate", i, this._api));
        }, "updateView"),
        updateVisual: /* @__PURE__ */ v(function(e) {
          var i = this, t = this._model;
          t && (t.setUpdatePayload(e), t.eachSeries(function(n) {
            n.getData().clearAllVisual();
          }), ae.markUpdateMethod(e, "updateVisual"), r(t), this._scheduler.performVisualTasks(t, e, {
            visualType: "visual",
            setDirty: !0
          }), t.eachComponent(function(n, o) {
            if (n !== "series") {
              var p = i.getViewOfComponentModel(o);
              p && p.__alive && p.updateVisual(o, t, i._api, e);
            }
          }), t.eachSeries(function(n) {
            var o = i._chartsMap[n.__viewId];
            o.updateVisual(n, t, i._api, e);
          }), M.trigger("afterupdate", t, this._api));
        }, "updateVisual"),
        updateLayout: /* @__PURE__ */ v(function(e) {
          k.update.call(this, e);
        }, "updateLayout")
      }, _e = /* @__PURE__ */ v(function(e, i, t, n) {
        if (e._disposed) {
          D(e.id);
          return;
        }
        for (var o = e._model, p = e._coordSysMgr.getCoordinateSystems(), f, h = pe(o, t), d = 0; d < p.length; d++) {
          var _ = p[d];
          if (_[i] && (f = _[i](o, h, n)) != null)
            return f;
        }
        process.env.NODE_ENV !== "production" && U("No coordinate system that supports " + i + " found by the given finder.");
      }, "doConvertPixel"), ge = /* @__PURE__ */ v(function(e, i) {
        var t = e._chartsMap, n = e._scheduler;
        i.eachSeries(function(o) {
          n.updateStreamModes(o, t[o.__viewId]);
        });
      }, "updateStreamModes"), me = /* @__PURE__ */ v(function(e, i) {
        var t = this, n = this.getModel(), o = e.type, p = e.escapeConnect, f = te[o], h = f.actionInfo, d = (h.update || "update").split(":"), _ = d.pop(), E = d[0] != null && Be(d[0]);
        this[w] = !0;
        var g = [e], P = !1;
        e.batch && (P = !0, g = At(e.batch, function(V) {
          return V = Pt(z({}, V), e), V.batch = null, V;
        }));
        var x = [], O, L = ke(e), N = ze(e);
        if (N && xt(this._api), R(g, function(V) {
          if (O = f.action(V, t._model, t._api), O = O || z({}, V), O.type = h.event || O.type, x.push(O), N) {
            var Ie = $t(e), St = Ie.queryOptionMap, Et = Ie.mainTypeSpecified, Ct = Et ? St.keys()[0] : "series";
            J(t, _, V, Ct), I(t);
          } else L ? (J(t, _, V, "series"), I(t)) : E && J(t, _, V, E.main, E.sub);
        }), _ !== "none" && !N && !L && !E)
          try {
            this[A] ? (F(this), k.update.call(this, e), this[A] = null) : k[_].call(this, e);
          } catch (V) {
            throw this[w] = !1, V;
          }
        if (P ? O = {
          type: h.event || o,
          escapeConnect: p,
          batch: x
        } : O = x[0], this[w] = !1, !i) {
          var De = this._messageCenter;
          if (De.trigger(O.type, O), L) {
            var Ve = {
              type: "selectchanged",
              escapeConnect: p,
              selected: Nt(n),
              isFromClick: e.isFromClick || !1,
              fromAction: e.type,
              fromActionPayload: e
            };
            De.trigger(Ve.type, Ve);
          }
        }
      }, "doDispatchAction"), G = /* @__PURE__ */ v(function(e) {
        for (var i = this._pendingActions; i.length; ) {
          var t = i.shift();
          me.call(this, t, e);
        }
      }, "flushPendingActions"), W = /* @__PURE__ */ v(function(e) {
        !e && this.trigger("updated");
      }, "triggerUpdatedEvent"), Ze = /* @__PURE__ */ v(function(e, i) {
        e.on("rendered", function(t) {
          i.trigger("rendered", t), // Although zr is dirty if initial animation is not finished
          // and this checking is called on frame, we also check
          // animation finished for robustness.
          e.animation.isFinished() && !i[A] && !i._scheduler.unfinished && !i._pendingActions.length && i.trigger("finished");
        });
      }, "bindRenderedEvent"), qe = /* @__PURE__ */ v(function(e, i) {
        e.on("mouseover", function(t) {
          var n = t.target, o = j(n, Ye);
          o && (Zt(o, t, i._api), I(i));
        }).on("mouseout", function(t) {
          var n = t.target, o = j(n, Ye);
          o && (qt(o, t, i._api), I(i));
        }).on("click", function(t) {
          var n = t.target, o = j(n, function(h) {
            return oe(h).dataIndex != null;
          }, !0);
          if (o) {
            var p = o.selected ? "unselect" : "select", f = oe(o);
            i._api.dispatchAction({
              type: p,
              dataType: f.dataType,
              dataIndexInside: f.dataIndex,
              seriesIndex: f.seriesIndex,
              isFromClick: !0
            });
          }
        });
      }, "bindMouseEvent");
      function r(e) {
        e.clearColorPalette(), e.eachSeries(function(i) {
          i.clearColorPalette();
        });
      }
      v(r, "clearColorPalette");
      function a(e) {
        var i = [], t = [], n = !1;
        if (e.eachComponent(function(h, d) {
          var _ = d.get("zlevel") || 0, E = d.get("z") || 0, g = d.getZLevelKey();
          n = n || !!g, (h === "series" ? t : i).push({
            zlevel: _,
            z: E,
            idx: d.componentIndex,
            type: h,
            key: g
          });
        }), n) {
          var o = i.concat(t), p, f;
          ne(o, function(h, d) {
            return h.zlevel === d.zlevel ? h.z - d.z : h.zlevel - d.zlevel;
          }), R(o, function(h) {
            var d = e.getComponent(h.type, h.idx), _ = h.zlevel, E = h.key;
            p != null && (_ = Math.max(p, _)), E ? (_ === p && E !== f && _++, f = E) : f && (_ === p && _++, f = ""), p = _, d.setZLevel(_);
          });
        }
      }
      v(a, "allocateZlevels"), Te = /* @__PURE__ */ v(function(e, i, t, n, o) {
        a(i), Ke(e, i, t, n, o), R(e._chartsViews, function(p) {
          p.__alive = !1;
        }), Q(e, i, t, n, o), R(e._chartsViews, function(p) {
          p.__alive || p.remove(i, t);
        });
      }, "render"), Ke = /* @__PURE__ */ v(function(e, i, t, n, o, p) {
        R(p || e._componentsViews, function(f) {
          var h = f.__model;
          y(h, f), f.render(h, i, t, n), C(h, f), S(h, f);
        });
      }, "renderComponents"), Q = /* @__PURE__ */ v(function(e, i, t, n, o, p) {
        var f = e._scheduler;
        o = z(o || {}, {
          updatedSeries: i.getSeries()
        }), M.trigger("series:beforeupdate", i, t, o);
        var h = !1;
        i.eachSeries(function(d) {
          var _ = e._chartsMap[d.__viewId];
          _.__alive = !0;
          var E = _.renderTask;
          f.updatePayload(E, n), y(d, _), p && p.get(d.uid) && E.dirty(), E.perform(f.getPerformArgs(E)) && (h = !0), _.group.silent = !!d.get("silent"), T(d, _), be(d);
        }), f.unfinished = h || f.unfinished, M.trigger("series:layoutlabels", i, t, o), M.trigger("series:transition", i, t, o), i.eachSeries(function(d) {
          var _ = e._chartsMap[d.__viewId];
          C(d, _), S(d, _);
        }), u(e, i), M.trigger("series:afterupdate", i, t, o);
      }, "renderSeries"), I = /* @__PURE__ */ v(function(e) {
        e[ce] = !0, e.getZr().wakeUp();
      }, "markStatusToUpdate"), je = /* @__PURE__ */ v(function(e) {
        e[ce] && (e.getZr().storage.traverse(function(i) {
          le(i) || l(i);
        }), e[ce] = !1);
      }, "applyChangedStates");
      function l(e) {
        for (var i = [], t = e.currentStates, n = 0; n < t.length; n++) {
          var o = t[n];
          o === "emphasis" || o === "blur" || o === "select" || i.push(o);
        }
        e.selected && e.states.select && i.push("select"), e.hoverState === Ut && e.states.emphasis ? i.push("emphasis") : e.hoverState === kt && e.states.blur && i.push("blur"), e.useStates(i);
      }
      v(l, "applyElementStates");
      function u(e, i) {
        var t = e._zr, n = t.storage, o = 0;
        n.traverse(function(p) {
          p.isGroup || o++;
        }), o > i.get("hoverLayerThreshold") && !b.node && !b.worker && i.eachSeries(function(p) {
          if (!p.preventUsingHoverLayer) {
            var f = e._chartsMap[p.__viewId];
            f.__alive && f.eachRendered(function(h) {
              h.states.emphasis && (h.states.emphasis.hoverLayer = !0);
            });
          }
        });
      }
      v(u, "updateHoverLayerStatus");
      function T(e, i) {
        var t = e.get("blendMode") || null;
        i.eachRendered(function(n) {
          n.isGroup || (n.style.blend = t);
        });
      }
      v(T, "updateBlend");
      function C(e, i) {
        if (!e.preventAutoZ) {
          var t = e.get("z") || 0, n = e.get("zlevel") || 0;
          i.eachRendered(function(o) {
            return m(o, t, n, -1 / 0), !0;
          });
        }
      }
      v(C, "updateZ");
      function m(e, i, t, n) {
        var o = e.getTextContent(), p = e.getTextGuideLine(), f = e.isGroup;
        if (f)
          for (var h = e.childrenRef(), d = 0; d < h.length; d++)
            n = Math.max(m(h[d], i, t, n), n);
        else
          e.z = i, e.zlevel = t, n = Math.max(e.z2, n);
        if (o && (o.z = i, o.zlevel = t, isFinite(n) && (o.z2 = n + 2)), p) {
          var _ = e.textGuideLineConfig;
          p.z = i, p.zlevel = t, isFinite(n) && (p.z2 = n + (_ && _.showAbove ? 1 : -1));
        }
        return n;
      }
      v(m, "doUpdateZ");
      function y(e, i) {
        i.eachRendered(function(t) {
          if (!le(t)) {
            var n = t.getTextContent(), o = t.getTextGuideLine();
            t.stateTransition && (t.stateTransition = null), n && n.stateTransition && (n.stateTransition = null), o && o.stateTransition && (o.stateTransition = null), t.hasState() ? (t.prevStates = t.currentStates, t.clearStates()) : t.prevStates && (t.prevStates = null);
          }
        });
      }
      v(y, "clearStates");
      function S(e, i) {
        var t = e.getModel("stateAnimation"), n = e.isAnimationEnabled(), o = t.get("duration"), p = o > 0 ? {
          duration: o,
          delay: t.get("delay"),
          easing: t.get("easing")
          // additive: stateAnimationModel.get('additive')
        } : null;
        i.eachRendered(function(f) {
          if (f.states && f.states.emphasis) {
            if (le(f))
              return;
            if (f instanceof Er && zt(f), f.__dirty) {
              var h = f.prevStates;
              h && f.useStates(h);
            }
            if (n) {
              f.stateTransition = p;
              var d = f.getTextContent(), _ = f.getTextGuideLine();
              d && (d.stateTransition = p), _ && (_.stateTransition = p);
            }
            f.__dirty && l(f);
          }
        });
      }
      v(S, "updateStates"), $e = /* @__PURE__ */ v(function(e) {
        return new /** @class */
        (function(i) {
          Se(t, i);
          function t() {
            return i !== null && i.apply(this, arguments) || this;
          }
          return v(t, "class_1"), t.prototype.getCoordinateSystems = function() {
            return e._coordSysMgr.getCoordinateSystems();
          }, t.prototype.getComponentByElement = function(n) {
            for (; n; ) {
              var o = n.__ecComponentInfo;
              if (o != null)
                return e._model.getComponent(o.mainType, o.index);
              n = n.parent;
            }
          }, t.prototype.enterEmphasis = function(n, o) {
            Fe(n, o), I(e);
          }, t.prototype.leaveEmphasis = function(n, o) {
            He(n, o), I(e);
          }, t.prototype.enterBlur = function(n) {
            bt(n), I(e);
          }, t.prototype.leaveBlur = function(n) {
            Ft(n), I(e);
          }, t.prototype.enterSelect = function(n) {
            Ht(n), I(e);
          }, t.prototype.leaveSelect = function(n) {
            Yt(n), I(e);
          }, t.prototype.getModel = function() {
            return e.getModel();
          }, t.prototype.getViewOfComponentModel = function(n) {
            return e.getViewOfComponentModel(n);
          }, t.prototype.getViewOfSeriesModel = function(n) {
            return e.getViewOfSeriesModel(n);
          }, t;
        }(Vt))(e);
      }, "createExtensionAPI"), vt = /* @__PURE__ */ v(function(e) {
        function i(t, n) {
          for (var o = 0; o < t.length; o++) {
            var p = t[o];
            p[he] = n;
          }
        }
        v(i, "updateConnectedChartsStatus"), R(Z, function(t, n) {
          e._messageCenter.on(n, function(o) {
            if (Je[e.group] && e[he] !== Xe) {
              if (o && o.escapeConnect)
                return;
              var p = e.makeActionFromEvent(o), f = [];
              R(q, function(h) {
                h !== e && h.group === e.group && f.push(h);
              }), i(f, Xe), R(f, function(h) {
                h[he] !== Mr && h.dispatchAction(p);
              }), i(f, xr);
            }
          });
        });
      }, "enableConnect");
    }(), s;
  }(Re)
), we = _t.prototype;
we.on = dt("on");
we.off = dt("off");
we.one = function(c, s, r) {
  var a = this;
  ot("ECharts#one is deprecated.");
  function l() {
    for (var u = [], T = 0; T < arguments.length; T++)
      u[T] = arguments[T];
    s && s.apply && s.apply(this, u), a.off(c, l);
  }
  v(l, "wrapped"), this.on.call(this, c, l, r);
};
var Nr = ["click", "dblclick", "mouseover", "mouseout", "mousemove", "mousedown", "mouseup", "globalout", "contextmenu"];
function D(c) {
  process.env.NODE_ENV !== "production" && U("Instance " + c + " has been disposed");
}
v(D, "disposedWarning");
var te = {}, Z = {}, Ee = [], Ce = [], re = [], gt = {}, ye = {}, q = {}, Je = {}, Ur = +/* @__PURE__ */ new Date() - 0, Ae = "_echarts_instance_";
function Vi(c, s, r) {
  {
    if (process.env.NODE_ENV !== "production" && !c)
      throw new Error("Initialize failed: invalid dom.");
    var a = kr(c);
    if (a)
      return process.env.NODE_ENV !== "production" && U("There is a chart instance already initialized on the dom."), a;
    process.env.NODE_ENV !== "production" && Rt(c) && c.nodeName.toUpperCase() !== "CANVAS" && (!c.clientWidth && !r || !c.clientHeight && !r) && U("Can't get DOM width or height. Please check dom.clientWidth and dom.clientHeight. They should not be 0.For example, you may need to call this in the callback of window.onload.");
  }
  var l = new _t(c, s, r);
  return l.id = "ec_" + Ur++, q[l.id] = l, nt(c, Ae, l.id), vt(l), M.trigger("afterinit", l), l;
}
v(Vi, "init");
function kr(c) {
  return q[Kt(c, Ae)];
}
v(kr, "getInstanceByDom");
function mt(c, s) {
  gt[c] = s;
}
v(mt, "registerTheme");
function zr(c) {
  et(Ce, c) < 0 && Ce.push(c);
}
v(zr, "registerPreprocessor");
function br(c, s) {
  Pe(Ee, c, s, wr);
}
v(br, "registerProcessor");
function Ii(c) {
  Tt("afterinit", c);
}
v(Ii, "registerPostInit");
function Li(c) {
  Tt("afterupdate", c);
}
v(Li, "registerPostUpdate");
function Tt(c, s) {
  M.on(c, s);
}
v(Tt, "registerUpdateLifecycle");
function $(c, s, r) {
  tt(s) && (r = s, s = "");
  var a = X(c) ? c.type : [c, c = {
    event: s
  }][0];
  c.event = (c.event || a).toLowerCase(), s = c.event, !Z[s] && (ee(We.test(a) && We.test(s)), te[a] || (te[a] = {
    action: r,
    actionInfo: c
  }), Z[s] = a);
}
v($, "registerAction");
function Mi(c, s) {
  rt.register(c, s);
}
v(Mi, "registerCoordinateSystem");
function xi(c, s) {
  Pe(re, c, s, st, "layout");
}
v(xi, "registerLayout");
function Y(c, s) {
  Pe(re, c, s, ut, "visual");
}
v(Y, "registerVisual");
var Qe = [];
function Pe(c, s, r, a, l) {
  if ((tt(s) || X(s)) && (r = s, s = a), process.env.NODE_ENV !== "production") {
    if (isNaN(s) || s == null)
      throw new Error("Illegal priority");
    R(c, function(T) {
      ee(T.__raw !== r);
    });
  }
  if (!(et(Qe, r) >= 0)) {
    Qe.push(r);
    var u = at.wrapStageHandler(r, l);
    u.__prio = s, u.__raw = r, c.push(u);
  }
}
v(Pe, "normalizeRegister");
function Fr(c, s) {
  ye[c] = s;
}
v(Fr, "registerLoading");
function Ni(c, s, r) {
  var a = mr("registerMap");
  a && a(c, s, r);
}
v(Ni, "registerMap");
var Ui = cr;
Y(Oe, er);
Y(ie, tr);
Y(ie, rr);
Y(Oe, sr);
Y(ie, ur);
Y(ft, _r);
zr(it);
br(Rr, Lt);
Fr("default", ir);
$({
  type: H,
  event: H,
  update: H
}, K);
$({
  type: se,
  event: se,
  update: se
}, K);
$({
  type: ue,
  event: ue,
  update: ue
}, K);
$({
  type: fe,
  event: fe,
  update: fe
}, K);
$({
  type: de,
  event: de,
  update: de
}, K);
mt("light", nr);
mt("dark", ar);
export {
  Di as PRIORITY,
  kr as getInstanceByDom,
  Vi as init,
  $ as registerAction,
  Mi as registerCoordinateSystem,
  xi as registerLayout,
  Fr as registerLoading,
  bi as registerLocale,
  Ni as registerMap,
  Ii as registerPostInit,
  Li as registerPostUpdate,
  zr as registerPreprocessor,
  br as registerProcessor,
  mt as registerTheme,
  Ui as registerTransform,
  Tt as registerUpdateLifecycle,
  Y as registerVisual
};
