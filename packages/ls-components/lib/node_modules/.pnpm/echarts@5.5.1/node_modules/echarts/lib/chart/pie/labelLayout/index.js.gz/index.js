var be = Object.defineProperty;
var P = (a, t) => be(a, "name", { value: t, configurable: !0 });
import { parsePercent as W } from "../../../util/number/index.js";
import "../../../util/graphic/index.js";
import { each as z, isNumber as ce } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { limitTurnAngle as de, limitSurfaceAngle as ue } from "../../../label/labelGuideHelper/index.js";
import { shiftLayoutOnY as pe } from "../../../label/labelLayoutHelper/index.js";
import ve from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/Point/index.js";
var me = Math.PI / 180;
function ge(a, t, u, g, o, M, h, T, x, m) {
  if (a.length < 2)
    return;
  function A(n) {
    for (var l = n.rB, b = l * l, c = 0; c < n.list.length; c++) {
      var s = n.list[c], S = Math.abs(s.label.y - u), d = g + s.len, p = d * d, D = Math.sqrt((1 - Math.abs(S * S / b)) * p), i = t + (D + s.len2) * o, f = i - s.label.x, O = s.targetTextWidth - f * o;
      se(s, O, !0), s.label.x = i;
    }
  }
  P(A, "recalculateXOnSemiToAlignOnEllipseCurve");
  function N(n) {
    for (var l = {
      list: [],
      maxY: 0
    }, b = {
      list: [],
      maxY: 0
    }, c = 0; c < n.length; c++)
      if (n[c].labelAlignTo === "none") {
        var s = n[c], S = s.label.y > u ? b : l, d = Math.abs(s.label.y - u);
        if (d >= S.maxY) {
          var p = s.label.x - t - s.len2 * o, D = g + s.len, i = Math.abs(p) < D ? Math.sqrt(d * d / (1 - p * p / D / D)) : D;
          S.rB = i, S.maxY = d;
        }
        S.list.push(s);
      }
    A(l), A(b);
  }
  P(N, "recalculateX");
  for (var v = a.length, r = 0; r < v; r++)
    if (a[r].position === "outer" && a[r].labelAlignTo === "labelLine") {
      var e = a[r].label.x - m;
      a[r].linePoints[1][0] += e, a[r].label.x = m;
    }
  pe(a, x, x + h) && N(a);
}
P(ge, "adjustSingleSide");
function Ae(a, t, u, g, o, M, h, T) {
  for (var x = [], m = [], A = Number.MAX_VALUE, N = -Number.MAX_VALUE, v = 0; v < a.length; v++) {
    var r = a[v].label;
    ee(a[v]) || (r.x < t ? (A = Math.min(A, r.x), x.push(a[v])) : (N = Math.max(N, r.x), m.push(a[v])));
  }
  for (var v = 0; v < a.length; v++) {
    var e = a[v];
    if (!ee(e) && e.linePoints) {
      if (e.labelStyleWidth != null)
        continue;
      var r = e.label, n = e.linePoints, l = void 0;
      e.labelAlignTo === "edge" ? r.x < t ? l = n[2][0] - e.labelDistance - h - e.edgeDistance : l = h + o - e.edgeDistance - n[2][0] - e.labelDistance : e.labelAlignTo === "labelLine" ? r.x < t ? l = A - h - e.bleedMargin : l = h + o - N - e.bleedMargin : r.x < t ? l = r.x - h - e.bleedMargin : l = h + o - r.x - e.bleedMargin, e.targetTextWidth = l, se(e, l);
    }
  }
  ge(m, t, u, g, 1, o, M, h, T, N), ge(x, t, u, g, -1, o, M, h, T, A);
  for (var v = 0; v < a.length; v++) {
    var e = a[v];
    if (!ee(e) && e.linePoints) {
      var r = e.label, n = e.linePoints, b = e.labelAlignTo === "edge", c = r.style.padding, s = c ? c[1] + c[3] : 0, S = r.style.backgroundColor ? 0 : s, d = e.rect.width + S, p = n[1][0] - n[2][0];
      b ? r.x < t ? n[2][0] = h + e.edgeDistance + d + e.labelDistance : n[2][0] = h + o - e.edgeDistance - d - e.labelDistance : (r.x < t ? n[2][0] = r.x + e.labelDistance : n[2][0] = r.x - e.labelDistance, n[1][0] = n[2][0] + p), n[1][1] = n[2][1] = r.y;
    }
  }
}
P(Ae, "avoidOverlap");
function se(a, t, u) {
  if (u === void 0 && (u = !1), a.labelStyleWidth == null) {
    var g = a.label, o = g.style, M = a.rect, h = o.backgroundColor, T = o.padding, x = T ? T[1] + T[3] : 0, m = o.overflow, A = M.width + (h ? 0 : x);
    if (t < A || u) {
      var N = M.height;
      if (m && m.match("break")) {
        g.setStyle("backgroundColor", null), g.setStyle("width", t - x);
        var v = g.getBoundingRect();
        g.setStyle("width", Math.ceil(v.width)), g.setStyle("backgroundColor", h);
      } else {
        var r = t - x, e = t < A ? r : (
          // Current available width is enough, but the text may have
          // already been wrapped with a smaller available width.
          u ? r > a.unconstrainedWidth ? null : r : null
        );
        g.setStyle("width", e);
      }
      var n = g.getBoundingRect();
      M.width = n.width;
      var l = (g.style.margin || 0) + 2.1;
      M.height = n.height + l, M.y -= (M.height - N) / 2;
    }
  }
}
P(se, "constrainTextWidth");
function ee(a) {
  return a.position === "center";
}
P(ee, "isPositionCenter");
function Pe(a) {
  var t = a.getData(), u = [], g, o, M = !1, h = (a.get("minShowLabelAngle") || 0) * me, T = t.getLayout("viewRect"), x = t.getLayout("r"), m = T.width, A = T.x, N = T.y, v = T.height;
  function r(p) {
    p.ignore = !0;
  }
  P(r, "setNotShow");
  function e(p) {
    if (!p.ignore)
      return !0;
    for (var D in p.states)
      if (p.states[D].ignore === !1)
        return !0;
    return !1;
  }
  P(e, "isLabelShown"), t.each(function(p) {
    var D = t.getItemGraphicEl(p), i = D.shape, f = D.getTextContent(), O = D.getTextGuideLine(), F = t.getItemModel(p), Y = F.getModel("label"), w = Y.get("position") || F.get(["emphasis", "label", "position"]), J = Y.get("distanceToLabelLine"), K = Y.get("alignTo"), Q = W(Y.get("edgeDistance"), m), oe = Y.get("bleedMargin"), R = F.getModel("labelLine"), X = R.get("length");
    X = W(X, m);
    var U = R.get("length2");
    if (U = W(U, m), Math.abs(i.endAngle - i.startAngle) < h) {
      z(f.states, r), f.ignore = !0, O && (z(O.states, r), O.ignore = !0);
      return;
    }
    if (e(f)) {
      var V = (i.startAngle + i.endAngle) / 2, C = Math.cos(V), B = Math.sin(V), E, j, re, H;
      g = i.cx, o = i.cy;
      var k = w === "inside" || w === "inner";
      if (w === "center")
        E = i.cx, j = i.cy, H = "center";
      else {
        var Z = (k ? (i.r + i.r0) / 2 * C : i.r * C) + g, $ = (k ? (i.r + i.r0) / 2 * B : i.r * B) + o;
        if (E = Z + C * 3, j = $ + B * 3, !k) {
          var ae = Z + C * (X + x - i.r), ne = $ + B * (X + x - i.r), te = ae + (C < 0 ? -1 : 1) * U, le = ne;
          K === "edge" ? E = C < 0 ? A + Q : A + m - Q : E = te + (C < 0 ? -J : J), j = le, re = [[Z, $], [ae, ne], [te, le]];
        }
        H = k ? "center" : K === "edge" ? C > 0 ? "right" : "left" : C > 0 ? "left" : "right";
      }
      var _ = Math.PI, I = 0, G = Y.get("rotate");
      if (ce(G))
        I = G * (_ / 180);
      else if (w === "center")
        I = 0;
      else if (G === "radial" || G === !0) {
        var fe = C < 0 ? -V + _ : -V;
        I = fe;
      } else if (G === "tangential" && w !== "outside" && w !== "outer") {
        var L = Math.atan2(C, B);
        L < 0 && (L = _ * 2 + L);
        var he = B > 0;
        he && (L = _ + L), I = L - _;
      }
      if (M = !!I, f.x = E, f.y = j, f.rotation = I, f.setStyle({
        verticalAlign: "middle"
      }), k) {
        f.setStyle({
          align: H
        });
        var y = f.states.select;
        y && (y.x += f.x, y.y += f.y);
      } else {
        var q = f.getBoundingRect().clone();
        q.applyTransform(f.getComputedTransform());
        var ie = (f.style.margin || 0) + 2.1;
        q.y -= ie / 2, q.height += ie, u.push({
          label: f,
          labelLine: O,
          position: w,
          len: X,
          len2: U,
          minTurnAngle: R.get("minTurnAngle"),
          maxSurfaceAngle: R.get("maxSurfaceAngle"),
          surfaceNormal: new ve(C, B),
          linePoints: re,
          textAlign: H,
          labelDistance: J,
          labelAlignTo: K,
          edgeDistance: Q,
          bleedMargin: oe,
          rect: q,
          unconstrainedWidth: q.width,
          labelStyleWidth: f.style.width
        });
      }
      D.setTextConfig({
        inside: k
      });
    }
  }), !M && a.get("avoidLabelOverlap") && Ae(u, g, o, x, m, v, A, N);
  for (var n = 0; n < u.length; n++) {
    var l = u[n], b = l.label, c = l.labelLine, s = isNaN(b.x) || isNaN(b.y);
    if (b) {
      b.setStyle({
        align: l.textAlign
      }), s && (z(b.states, r), b.ignore = !0);
      var S = b.states.select;
      S && (S.x += b.x, S.y += b.y);
    }
    if (c) {
      var d = l.linePoints;
      s || !d ? (z(c.states, r), c.ignore = !0) : (de(d, l.minTurnAngle), ue(d, l.surfaceNormal, l.maxSurfaceAngle), c.setShape({
        points: d
      }), b.__hostTarget.textGuideLineConfig = {
        anchor: new ve(d[0][0], d[0][1])
      });
    }
  }
}
P(Pe, "pieLabelLayout");
export {
  Pe as default
};
