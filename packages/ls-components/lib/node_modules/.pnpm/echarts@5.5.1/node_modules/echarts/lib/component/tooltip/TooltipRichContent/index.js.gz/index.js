var c = Object.defineProperty;
var f = (e, t) => c(e, "name", { value: t, configurable: !0 });
import { isObject as g, each as u, bind as p } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import v from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import { getPaddingFromTooltipModel as y } from "../tooltipMarkup/index.js";
import { throwError as m } from "../../../util/log/index.js";
var z = (
  /** @class */
  function() {
    function e(t) {
      this._show = !1, this._styleCoord = [0, 0, 0, 0], this._alwaysShowContent = !1, this._enterable = !0, this._zr = t.getZr(), _(this._styleCoord, this._zr, t.getWidth() / 2, t.getHeight() / 2);
    }
    return f(e, "TooltipRichContent"), e.prototype.update = function(t) {
      var i = t.get("alwaysShowContent");
      i && this._moveIfResized(), this._alwaysShowContent = i;
    }, e.prototype.show = function() {
      this._hideTimeout && clearTimeout(this._hideTimeout), this.el.show(), this._show = !0;
    }, e.prototype.setContent = function(t, i, o, r, d) {
      var n = this;
      g(t) && m(process.env.NODE_ENV !== "production" ? "Passing DOM nodes as content is not supported in richText tooltip!" : ""), this.el && this._zr.remove(this.el);
      var a = o.getModel("textStyle");
      this.el = new v({
        style: {
          rich: i.richTextStyles,
          text: t,
          lineHeight: 22,
          borderWidth: 1,
          borderColor: r,
          textShadowColor: a.get("textShadowColor"),
          fill: o.get(["textStyle", "color"]),
          padding: y(o, "richText"),
          verticalAlign: "top",
          align: "left"
        },
        z: o.get("z")
      }), u(["backgroundColor", "borderRadius", "shadowColor", "shadowBlur", "shadowOffsetX", "shadowOffsetY"], function(l) {
        n.el.style[l] = o.get(l);
      }), u(["textShadowBlur", "textShadowOffsetX", "textShadowOffsetY"], function(l) {
        n.el.style[l] = a.get(l) || 0;
      }), this._zr.add(this.el);
      var h = this;
      this.el.on("mouseover", function() {
        h._enterable && (clearTimeout(h._hideTimeout), h._show = !0), h._inContent = !0;
      }), this.el.on("mouseout", function() {
        h._enterable && h._show && h.hideLater(h._hideDelay), h._inContent = !1;
      });
    }, e.prototype.setEnterable = function(t) {
      this._enterable = t;
    }, e.prototype.getSize = function() {
      var t = this.el, i = this.el.getBoundingRect(), o = w(t.style);
      return [i.width + o.left + o.right, i.height + o.top + o.bottom];
    }, e.prototype.moveTo = function(t, i) {
      var o = this.el;
      if (o) {
        var r = this._styleCoord;
        _(r, this._zr, t, i), t = r[0], i = r[1];
        var d = o.style, n = s(d.borderWidth || 0), a = w(d);
        o.x = t + n + a.left, o.y = i + n + a.top, o.markRedraw();
      }
    }, e.prototype._moveIfResized = function() {
      var t = this._styleCoord[2], i = this._styleCoord[3];
      this.moveTo(t * this._zr.getWidth(), i * this._zr.getHeight());
    }, e.prototype.hide = function() {
      this.el && this.el.hide(), this._show = !1;
    }, e.prototype.hideLater = function(t) {
      this._show && !(this._inContent && this._enterable) && !this._alwaysShowContent && (t ? (this._hideDelay = t, this._show = !1, this._hideTimeout = setTimeout(p(this.hide, this), t)) : this.hide());
    }, e.prototype.isShow = function() {
      return this._show;
    }, e.prototype.dispose = function() {
      this._zr.remove(this.el);
    }, e;
  }()
);
function s(e) {
  return Math.max(0, e);
}
f(s, "mathMaxWith0");
function w(e) {
  var t = s(e.shadowBlur || 0), i = s(e.shadowOffsetX || 0), o = s(e.shadowOffsetY || 0);
  return {
    left: s(t - i),
    right: s(t + i),
    top: s(t - o),
    bottom: s(t + o)
  };
}
f(w, "calcShadowOuterSize");
function _(e, t, i, o) {
  e[0] = i, e[1] = o, e[2] = e[0] / t.getWidth(), e[3] = e[1] / t.getHeight();
}
f(_, "makeStyleCoord");
export {
  z as default
};
