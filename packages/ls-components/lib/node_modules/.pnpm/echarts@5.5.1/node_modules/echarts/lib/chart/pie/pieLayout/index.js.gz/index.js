var O = Object.defineProperty;
var B = (g, c) => O(g, "name", { value: c, configurable: !0 });
import { linearMap as Q, parsePercent as L } from "../../../util/number/index.js";
import { getLayoutRect as U } from "../../../util/layout/index.js";
import { isArray as q } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { normalizeArcAngles as X } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/PathProxy/index.js";
import { makeInner as Y } from "../../../util/model/index.js";
var F = Math.PI * 2, z = Math.PI / 180;
function G(g, c) {
  return U(g.getBoxLayoutParams(), {
    width: c.getWidth(),
    height: c.getHeight()
  });
}
B(G, "getViewRect");
function $(g, c) {
  var u = G(g, c), a = g.get("center"), r = g.get("radius");
  q(r) || (r = [0, r]);
  var m = L(u.width, c.getWidth()), R = L(u.height, c.getHeight()), y = Math.min(m, R), x = L(r[0], y / 2), k = L(r[1], y / 2), A, N, t = g.coordinateSystem;
  if (t) {
    var o = t.dataToPoint(a);
    A = o[0] || 0, N = o[1] || 0;
  } else
    q(a) || (a = [a, a]), A = L(a[0], m) + u.x, N = L(a[1], R) + u.y;
  return {
    cx: A,
    cy: N,
    r0: x,
    r: k
  };
}
B($, "getBasicPieLayout");
function na(g, c, u) {
  c.eachSeriesByType(g, function(a) {
    var r = a.getData(), m = r.mapDimension("value"), R = G(a, u), y = $(a, u), x = y.cx, k = y.cy, A = y.r, N = y.r0, t = -a.get("startAngle") * z, o = a.get("endAngle"), p = a.get("padAngle") * z;
    o = o === "auto" ? t - F : -o * z;
    var J = a.get("minAngle") * z, I = J + p, P = 0;
    r.each(m, function(v) {
      !isNaN(v) && P++;
    });
    var C = r.getSum(m), S = Math.PI / (C || P) * 2, d = a.get("clockwise"), H = a.get("roseType"), K = a.get("stillShowZeroSum"), V = r.getDataExtent(m);
    V[0] = 0;
    var f = d ? 1 : -1, W = [t, o], l = f * p / 2;
    X(W, !d), t = W[0], o = W[1];
    var Z = E(a);
    Z.startAngle = t, Z.endAngle = o, Z.clockwise = d;
    var b = Math.abs(o - t), T = b, j = 0, h = t;
    if (r.setLayout({
      viewRect: R,
      r: A
    }), r.each(m, function(v, s) {
      var e;
      if (isNaN(v)) {
        r.setItemLayout(s, {
          angle: NaN,
          startAngle: NaN,
          endAngle: NaN,
          clockwise: d,
          cx: x,
          cy: k,
          r0: N,
          r: H ? NaN : A
        });
        return;
      }
      H !== "area" ? e = C === 0 && K ? S : v * S : e = b / P, e < I ? (e = I, T -= I) : j += v;
      var i = h + f * e, n = 0, w = 0;
      p > e ? (n = h + f * e / 2, w = n) : (n = h + l, w = i - l), r.setItemLayout(s, {
        angle: e,
        startAngle: n,
        endAngle: w,
        clockwise: d,
        cx: x,
        cy: k,
        r0: N,
        r: H ? Q(v, V, [N, A]) : A
      }), h = i;
    }), T < F && P)
      if (T <= 1e-3) {
        var D = b / P;
        r.each(m, function(v, s) {
          if (!isNaN(v)) {
            var e = r.getItemLayout(s);
            e.angle = D;
            var i = 0, n = 0;
            D < p ? (i = t + f * (s + 1 / 2) * D, n = i) : (i = t + f * s * D + l, n = t + f * (s + 1) * D - l), e.startAngle = i, e.endAngle = n;
          }
        });
      } else
        S = T / j, h = t, r.each(m, function(v, s) {
          if (!isNaN(v)) {
            var e = r.getItemLayout(s), i = e.angle === I ? I : v * S, n = 0, w = 0;
            i < p ? (n = h + f * i / 2, w = n) : (n = h + l, w = h + f * i - l), e.startAngle = n, e.endAngle = w, h += f * i;
          }
        });
  });
}
B(na, "pieLayout");
var E = Y();
export {
  na as default,
  $ as getBasicPieLayout,
  E as getSeriesLayoutData
};
