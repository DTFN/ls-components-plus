var T = Object.defineProperty;
var y = (e, r) => T(e, "name", { value: r, configurable: !0 });
import { isFunction as g, extend as I, createHashMap as A } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import k from "../../model/mixin/makeStyleMapper/index.js";
import { ITEM_STYLE_KEY_MAP as D } from "../../model/mixin/itemStyle/index.js";
import { LINE_STYLE_KEY_MAP as E } from "../../model/mixin/lineStyle/index.js";
import K from "../../model/Model/index.js";
import { makeInner as R } from "../../util/model/index.js";
var w = R(), P = {
  itemStyle: k(D, !0),
  lineStyle: k(E, !0)
}, _ = {
  lineStyle: "stroke",
  itemStyle: "fill"
};
function V(e, r) {
  var t = e.visualStyleMapper || P[r];
  return t || (console.warn("Unknown style type '" + r + "'."), P.itemStyle);
}
y(V, "getStyleMapper");
function C(e, r) {
  var t = e.visualDrawType || _[r];
  return t || (console.warn("Unknown style type '" + r + "'."), "fill");
}
y(C, "getDefaultColorKey");
var N = {
  createOnAllSeries: !0,
  performRawSeries: !0,
  reset: /* @__PURE__ */ y(function(e, r) {
    var t = e.getData(), l = e.visualStyleAccessPath || "itemStyle", u = e.getModel(l), o = V(e, l), a = o(u), c = u.getShallow("decal");
    c && (t.setVisual("decal", c), c.dirty = !0);
    var i = C(e, l), n = a[i], v = g(n) ? n : null, p = a.fill === "auto" || a.stroke === "auto";
    if (!a[i] || v || p) {
      var f = e.getColorFromPalette(
        // TODO series count changed.
        e.name,
        null,
        r.getSeriesCount()
      );
      a[i] || (a[i] = f, t.setVisual("colorFromPalette", !0)), a.fill = a.fill === "auto" || g(a.fill) ? f : a.fill, a.stroke = a.stroke === "auto" || g(a.stroke) ? f : a.stroke;
    }
    if (t.setVisual("style", a), t.setVisual("drawType", i), !r.isSeriesFiltered(e) && v)
      return t.setVisual("colorFromPalette", !1), {
        dataEach: /* @__PURE__ */ y(function(S, s) {
          var F = e.getDataParams(s), h = I({}, a);
          h[i] = v(F), S.setItemVisual(s, "style", h);
        }, "dataEach")
      };
  }, "reset")
}, m = new K(), G = {
  createOnAllSeries: !0,
  performRawSeries: !0,
  reset: /* @__PURE__ */ y(function(e, r) {
    if (!(e.ignoreStyleOnData || r.isSeriesFiltered(e))) {
      var t = e.getData(), l = e.visualStyleAccessPath || "itemStyle", u = V(e, l), o = t.getVisual("drawType");
      return {
        dataEach: t.hasItemOption ? function(a, c) {
          var i = a.getRawDataItem(c);
          if (i && i[l]) {
            m.option = i[l];
            var n = u(m), v = a.ensureUniqueItemVisual(c, "style");
            I(v, n), m.option.decal && (a.setItemVisual(c, "decal", m.option.decal), m.option.decal.dirty = !0), o in n && a.setItemVisual(c, "colorFromPalette", !1);
          }
        } : null
      };
    }
  }, "reset")
}, H = {
  performRawSeries: !0,
  overallReset: /* @__PURE__ */ y(function(e) {
    var r = A();
    e.eachSeries(function(t) {
      var l = t.getColorBy();
      if (!t.isColorBySeries()) {
        var u = t.type + "-" + l, o = r.get(u);
        o || (o = {}, r.set(u, o)), w(t).scope = o;
      }
    }), e.eachSeries(function(t) {
      if (!(t.isColorBySeries() || e.isSeriesFiltered(t))) {
        var l = t.getRawData(), u = {}, o = t.getData(), a = w(t).scope, c = t.visualStyleAccessPath || "itemStyle", i = C(t, c);
        o.each(function(n) {
          var v = o.getRawIndex(n);
          u[v] = n;
        }), l.each(function(n) {
          var v = u[n], p = o.getItemVisual(v, "colorFromPalette");
          if (p) {
            var f = o.ensureUniqueItemVisual(v, "style"), S = l.getName(n) || n + "", s = l.count();
            f[i] = t.getColorFromPalette(S, a, s);
          }
        });
      }
    });
  }, "overallReset")
};
export {
  H as dataColorPaletteTask,
  G as dataStyleTask,
  N as seriesStyleTask
};
