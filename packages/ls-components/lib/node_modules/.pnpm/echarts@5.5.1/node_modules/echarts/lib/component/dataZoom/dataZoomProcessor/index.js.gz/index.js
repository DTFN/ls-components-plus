var u = Object.defineProperty;
var x = (i, o) => u(i, "name", { value: o, configurable: !0 });
import { createHashMap as p, each as c } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getAxisMainType as A } from "../helper/index.js";
import g from "../AxisProxy/index.js";
var v = {
  // `dataZoomProcessor` will only be performed in needed series. Consider if
  // there is a line series and a pie series, it is better not to update the
  // line series if only pie series is needed to be updated.
  getTargetSeries: /* @__PURE__ */ x(function(i) {
    function o(t) {
      i.eachComponent("dataZoom", function(e) {
        e.eachTargetAxis(function(a, s) {
          var f = i.getComponent(A(a), s);
          t(a, s, f, e);
        });
      });
    }
    x(o, "eachAxisModel"), o(function(t, e, a, s) {
      a.__dzAxisProxy = null;
    });
    var n = [];
    o(function(t, e, a, s) {
      a.__dzAxisProxy || (a.__dzAxisProxy = new g(t, e, s, i), n.push(a.__dzAxisProxy));
    });
    var r = p();
    return c(n, function(t) {
      c(t.getTargetSeriesModels(), function(e) {
        r.set(e.uid, e);
      });
    }), r;
  }, "getTargetSeries"),
  // Consider appendData, where filter should be performed. Because data process is
  // in block mode currently, it is not need to worry about that the overallProgress
  // execute every frame.
  overallReset: /* @__PURE__ */ x(function(i, o) {
    i.eachComponent("dataZoom", function(n) {
      n.eachTargetAxis(function(r, t) {
        n.getAxisProxy(r, t).reset(n);
      }), n.eachTargetAxis(function(r, t) {
        n.getAxisProxy(r, t).filterData(n, o);
      });
    }), i.eachComponent("dataZoom", function(n) {
      var r = n.findRepresentativeAxisProxy();
      if (r) {
        var t = r.getDataPercentWindow(), e = r.getDataValueWindow();
        n.setCalculatedRange({
          start: t[0],
          end: t[1],
          startValue: e[0],
          endValue: e[1]
        });
      }
    });
  }, "overallReset")
};
export {
  v as default
};
