var s = Object.defineProperty;
var o = (n, t) => s(n, "name", { value: t, configurable: !0 });
import { enableClassManagement as r } from "../../util/clazz/index.js";
var p = (
  /** @class */
  function() {
    function n(t) {
      this._setting = t || {}, this._extent = [1 / 0, -1 / 0];
    }
    return o(n, "Scale"), n.prototype.getSetting = function(t) {
      return this._setting[t];
    }, n.prototype.unionExtent = function(t) {
      var e = this._extent;
      t[0] < e[0] && (e[0] = t[0]), t[1] > e[1] && (e[1] = t[1]);
    }, n.prototype.unionExtentFromData = function(t, e) {
      this.unionExtent(t.getApproximateExtent(e));
    }, n.prototype.getExtent = function() {
      return this._extent.slice();
    }, n.prototype.setExtent = function(t, e) {
      var i = this._extent;
      isNaN(t) || (i[0] = t), isNaN(e) || (i[1] = e);
    }, n.prototype.isInExtentRange = function(t) {
      return this._extent[0] <= t && this._extent[1] >= t;
    }, n.prototype.isBlank = function() {
      return this._isBlank;
    }, n.prototype.setBlank = function(t) {
      this._isBlank = t;
    }, n;
  }()
);
r(p);
export {
  p as default
};
