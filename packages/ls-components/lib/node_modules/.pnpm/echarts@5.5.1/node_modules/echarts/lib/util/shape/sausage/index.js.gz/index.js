var y = Object.defineProperty;
var P = (e, i) => y(e, "name", { value: i, configurable: !0 });
import { __extends as A } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import "../../graphic/index.js";
import I from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
var p = (
  /** @class */
  function() {
    function e() {
      this.cx = 0, this.cy = 0, this.r0 = 0, this.r = 0, this.startAngle = 0, this.endAngle = Math.PI * 2, this.clockwise = !0;
    }
    return P(e, "SausageShape"), e;
  }()
), C = (
  /** @class */
  function(e) {
    A(i, e);
    function i(n) {
      var t = e.call(this, n) || this;
      return t.type = "sausage", t;
    }
    return P(i, "SausagePath"), i.prototype.getDefaultShape = function() {
      return new p();
    }, i.prototype.buildPath = function(n, t) {
      var o = t.cx, s = t.cy, h = Math.max(t.r0 || 0, 0), c = Math.max(t.r, 0), f = (c - h) * 0.5, v = h + f, a = t.startAngle, r = t.endAngle, u = t.clockwise, l = Math.PI * 2, d = u ? r - a < l : a - r < l;
      d || (a = r - (u ? l : -l));
      var g = Math.cos(a), M = Math.sin(a), m = Math.cos(r), S = Math.sin(r);
      d ? (n.moveTo(g * h + o, M * h + s), n.arc(g * v + o, M * v + s, f, -Math.PI + a, a, !u)) : n.moveTo(g * c + o, M * c + s), n.arc(o, s, c, a, r, !u), n.arc(m * v + o, S * v + s, f, r - Math.PI * 2, r - Math.PI, !u), h !== 0 && n.arc(o, s, h, r, a, u);
    }, i;
  }(I)
);
export {
  C as default
};
