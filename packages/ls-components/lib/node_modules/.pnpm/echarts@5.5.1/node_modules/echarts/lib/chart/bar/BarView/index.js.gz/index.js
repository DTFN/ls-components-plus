var ue = Object.defineProperty;
var f = (i, r) => ue(i, "name", { value: r, configurable: !0 });
import { __extends as te } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import ge from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
import de from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import { map as fe, extend as re, each as ce } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { traverseElements as le } from "../../../util/graphic/index.js";
import { getECData as F } from "../../../util/innerStore/index.js";
import { toggleHoverEmphasis as ve, setStatesStylesFromModel as me } from "../../../util/states/index.js";
import { labelInner as _e, getLabelStatesModels as be, setLabelStyle as Ae, setLabelValueAnimation as ye } from "../../../label/labelStyle/index.js";
import { throttle as xe } from "../../../util/throttle/index.js";
import { createClipPath as we } from "../../helper/createClipPathFromCoordSys/index.js";
import U from "../../../util/shape/sausage/index.js";
import Se from "../../../view/Chart/index.js";
import { isCoordinateSystemType as ae } from "../../../coord/CoordinateSystem/index.js";
import { getDefaultLabel as De, getDefaultInterpolatedLabel as Le } from "../../helper/labelHelper/index.js";
import { warn as B } from "../../../util/log/index.js";
import { createSectorCalculateTextPosition as Ce, setSectorTextRotation as Ie } from "../../../label/sectorLabel/index.js";
import { initProps as k, updateProps as C, saveOldStyle as Pe, removeElementWithFadeOut as Y } from "../../../animation/basicTransition/index.js";
import { getSectorCornerRadius as ke } from "../../helper/sectorHelper/index.js";
import ie from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
import ne from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Sector/index.js";
var R = Math.max, W = Math.min;
function Ve(i, r) {
  var e = i.getArea && i.getArea();
  if (ae(i, "cartesian2d")) {
    var t = i.getBaseAxis();
    if (t.type !== "category" || !t.onBand) {
      var a = r.getLayout("bandWidth");
      t.isHorizontal() ? (e.x -= a, e.width += a * 2) : (e.y -= a, e.height += a * 2);
    }
  }
  return e;
}
f(Ve, "getClipArea");
var ot = (
  /** @class */
  function(i) {
    te(r, i);
    function r() {
      var e = i.call(this) || this;
      return e.type = r.type, e._isFirstFrame = !0, e;
    }
    return f(r, "BarView"), r.prototype.render = function(e, t, a, n) {
      this._model = e, this._removeOnRenderedListener(a), this._updateDrawMode(e);
      var o = e.get("coordinateSystem");
      o === "cartesian2d" || o === "polar" ? (this._progressiveEls = null, this._isLargeDraw ? this._renderLarge(e, t, a) : this._renderNormal(e, t, a, n)) : process.env.NODE_ENV !== "production" && B("Only cartesian2d and polar supported for bar.");
    }, r.prototype.incrementalPrepareRender = function(e) {
      this._clear(), this._updateDrawMode(e), this._updateLargeClip(e);
    }, r.prototype.incrementalRender = function(e, t) {
      this._progressiveEls = [], this._incrementalRenderLarge(e, t);
    }, r.prototype.eachRendered = function(e) {
      le(this._progressiveEls || this.group, e);
    }, r.prototype._updateDrawMode = function(e) {
      var t = e.pipelineContext.large;
      (this._isLargeDraw == null || t !== this._isLargeDraw) && (this._isLargeDraw = t, this._clear());
    }, r.prototype._renderNormal = function(e, t, a, n) {
      var o = this.group, s = e.getData(), u = this._data, h = e.coordinateSystem, p = h.getBaseAxis(), g;
      h.type === "cartesian2d" ? g = p.isHorizontal() : h.type === "polar" && (g = p.dim === "angle");
      var _ = e.isAnimationEnabled() ? e : null, c = Ne(e, h);
      c && this._enableRealtimeSort(c, s, a);
      var x = e.get("clip", !0) || c, D = Ve(h, s);
      o.removeClipPath();
      var w = e.get("roundCap", !0), S = e.get("showBackground", !0), y = e.getModel("backgroundStyle"), I = y.get("borderRadius") || 0, L = [], G = this._backgroundEls, T = n && n.isInitSort, M = n && n.type === "changeAxisOrder";
      function X(d) {
        var b = P[h.type](s, d), l = Ge(h, g, b);
        return l.useStyle(y.getItemStyle()), h.type === "cartesian2d" ? l.setShape("r", I) : l.setShape("cornerRadius", I), L[d] = l, l;
      }
      f(X, "createBackground"), s.diff(u).add(function(d) {
        var b = s.getItemModel(d), l = P[h.type](s, d, b);
        if (S && X(d), !(!s.hasValue(d) || !K[h.type](l))) {
          var A = !1;
          x && (A = Z[h.type](D, l));
          var v = j[h.type](e, s, d, l, g, _, p.model, !1, w);
          c && (v.forceLabelAnimation = !0), Q(v, s, d, b, l, e, g, h.type === "polar"), T ? v.attr({
            shape: l
          }) : c ? q(c, _, v, l, d, g, !1, !1) : k(v, {
            shape: l
          }, e, d), s.setItemGraphicEl(d, v), o.add(v), v.ignore = A;
        }
      }).update(function(d, b) {
        var l = s.getItemModel(d), A = P[h.type](s, d, l);
        if (S) {
          var v = void 0;
          G.length === 0 ? v = X(b) : (v = G[b], v.useStyle(y.getItemStyle()), h.type === "cartesian2d" ? v.setShape("r", I) : v.setShape("cornerRadius", I), L[d] = v);
          var he = P[h.type](s, d), pe = oe(g, he, h);
          C(v, {
            shape: pe
          }, _, d);
        }
        var m = u.getItemGraphicEl(b);
        if (!s.hasValue(d) || !K[h.type](A)) {
          o.remove(m);
          return;
        }
        var O = !1;
        if (x && (O = Z[h.type](D, A), O && o.remove(m)), m ? Pe(m) : m = j[h.type](e, s, d, A, g, _, p.model, !!m, w), c && (m.forceLabelAnimation = !0), M) {
          var z = m.getTextContent();
          if (z) {
            var E = _e(z);
            E.prevValue != null && (E.prevValue = E.value);
          }
        } else
          Q(m, s, d, l, A, e, g, h.type === "polar");
        T ? m.attr({
          shape: A
        }) : c ? q(c, _, m, A, d, g, !0, M) : C(m, {
          shape: A
        }, e, d, null), s.setItemGraphicEl(d, m), m.ignore = O, o.add(m);
      }).remove(function(d) {
        var b = u.getItemGraphicEl(d);
        b && Y(b, e, d);
      }).execute();
      var V = this._backgroundGroup || (this._backgroundGroup = new de());
      V.removeAll();
      for (var N = 0; N < L.length; ++N)
        V.add(L[N]);
      o.add(V), this._backgroundEls = L, this._data = s;
    }, r.prototype._renderLarge = function(e, t, a) {
      this._clear(), H(e, this.group), this._updateLargeClip(e);
    }, r.prototype._incrementalRenderLarge = function(e, t) {
      this._removeBackground(), H(t, this.group, this._progressiveEls, !0);
    }, r.prototype._updateLargeClip = function(e) {
      var t = e.get("clip", !0) && we(e.coordinateSystem, !1, e), a = this.group;
      t ? a.setClipPath(t) : a.removeClipPath();
    }, r.prototype._enableRealtimeSort = function(e, t, a) {
      var n = this;
      if (t.count()) {
        var o = e.baseAxis;
        if (this._isFirstFrame)
          this._dispatchInitSort(t, e, a), this._isFirstFrame = !1;
        else {
          var s = /* @__PURE__ */ f(function(u) {
            var h = t.getItemGraphicEl(u), p = h && h.shape;
            return p && // The result should be consistent with the initial sort by data value.
            // Do not support the case that both positive and negative exist.
            Math.abs(o.isHorizontal() ? p.height : p.width) || 0;
          }, "orderMapping_1");
          this._onRendered = function() {
            n._updateSortWithinSameData(t, s, o, a);
          }, a.getZr().on("rendered", this._onRendered);
        }
      }
    }, r.prototype._dataSort = function(e, t, a) {
      var n = [];
      return e.each(e.mapDimension(t.dim), function(o, s) {
        var u = a(s);
        u = u ?? NaN, n.push({
          dataIndex: s,
          mappedValue: u,
          ordinalNumber: o
        });
      }), n.sort(function(o, s) {
        return s.mappedValue - o.mappedValue;
      }), {
        ordinalNumbers: fe(n, function(o) {
          return o.ordinalNumber;
        })
      };
    }, r.prototype._isOrderChangedWithinSameData = function(e, t, a) {
      for (var n = a.scale, o = e.mapDimension(a.dim), s = Number.MAX_VALUE, u = 0, h = n.getOrdinalMeta().categories.length; u < h; ++u) {
        var p = e.rawIndexOf(o, n.getRawOrdinalNumber(u)), g = p < 0 ? Number.MIN_VALUE : t(e.indexOfRawIndex(p));
        if (g > s)
          return !0;
        s = g;
      }
      return !1;
    }, r.prototype._isOrderDifferentInView = function(e, t) {
      for (var a = t.scale, n = a.getExtent(), o = Math.max(0, n[0]), s = Math.min(n[1], a.getOrdinalMeta().categories.length - 1); o <= s; ++o)
        if (e.ordinalNumbers[o] !== a.getRawOrdinalNumber(o))
          return !0;
    }, r.prototype._updateSortWithinSameData = function(e, t, a, n) {
      if (this._isOrderChangedWithinSameData(e, t, a)) {
        var o = this._dataSort(e, a, t);
        this._isOrderDifferentInView(o, a) && (this._removeOnRenderedListener(n), n.dispatchAction({
          type: "changeAxisOrder",
          componentType: a.dim + "Axis",
          axisId: a.index,
          sortInfo: o
        }));
      }
    }, r.prototype._dispatchInitSort = function(e, t, a) {
      var n = t.baseAxis, o = this._dataSort(e, n, function(s) {
        return e.get(e.mapDimension(t.otherAxis.dim), s);
      });
      a.dispatchAction({
        type: "changeAxisOrder",
        componentType: n.dim + "Axis",
        isInitSort: !0,
        axisId: n.index,
        sortInfo: o
      });
    }, r.prototype.remove = function(e, t) {
      this._clear(this._model), this._removeOnRenderedListener(t);
    }, r.prototype.dispose = function(e, t) {
      this._removeOnRenderedListener(t);
    }, r.prototype._removeOnRenderedListener = function(e) {
      this._onRendered && (e.getZr().off("rendered", this._onRendered), this._onRendered = null);
    }, r.prototype._clear = function(e) {
      var t = this.group, a = this._data;
      e && e.isAnimationEnabled() && a && !this._isLargeDraw ? (this._removeBackground(), this._backgroundEls = [], a.eachItemGraphicEl(function(n) {
        Y(n, e, F(n).dataIndex);
      })) : t.removeAll(), this._data = null, this._isFirstFrame = !0;
    }, r.prototype._removeBackground = function() {
      this.group.remove(this._backgroundGroup), this._backgroundGroup = null;
    }, r.type = "bar", r;
  }(Se)
), Z = {
  cartesian2d: /* @__PURE__ */ f(function(i, r) {
    var e = r.width < 0 ? -1 : 1, t = r.height < 0 ? -1 : 1;
    e < 0 && (r.x += r.width, r.width = -r.width), t < 0 && (r.y += r.height, r.height = -r.height);
    var a = i.x + i.width, n = i.y + i.height, o = R(r.x, i.x), s = W(r.x + r.width, a), u = R(r.y, i.y), h = W(r.y + r.height, n), p = s < o, g = h < u;
    return r.x = p && o > a ? s : o, r.y = g && u > n ? h : u, r.width = p ? 0 : s - o, r.height = g ? 0 : h - u, e < 0 && (r.x += r.width, r.width = -r.width), t < 0 && (r.y += r.height, r.height = -r.height), p || g;
  }, "cartesian2d"),
  polar: /* @__PURE__ */ f(function(i, r) {
    var e = r.r0 <= r.r ? 1 : -1;
    if (e < 0) {
      var t = r.r;
      r.r = r.r0, r.r0 = t;
    }
    var a = W(r.r, i.r), n = R(r.r0, i.r0);
    r.r = a, r.r0 = n;
    var o = a - n < 0;
    if (e < 0) {
      var t = r.r;
      r.r = r.r0, r.r0 = t;
    }
    return o;
  }, "polar")
}, j = {
  cartesian2d: /* @__PURE__ */ f(function(i, r, e, t, a, n, o, s, u) {
    var h = new ie({
      shape: re({}, t),
      z2: 1
    });
    if (h.__dataIndex = e, h.name = "item", n) {
      var p = h.shape, g = a ? "height" : "width";
      p[g] = 0;
    }
    return h;
  }, "cartesian2d"),
  polar: /* @__PURE__ */ f(function(i, r, e, t, a, n, o, s, u) {
    var h = !a && u ? U : ne, p = new h({
      shape: t,
      z2: 1
    });
    p.name = "item";
    var g = se(a);
    if (p.calculateTextPosition = Ce(g, {
      isRoundCap: h === U
    }), n) {
      var _ = p.shape, c = a ? "r" : "endAngle", x = {};
      _[c] = a ? t.r0 : t.startAngle, x[c] = t[c], (s ? C : k)(p, {
        shape: x
        // __value: typeof dataValue === 'string' ? parseInt(dataValue, 10) : dataValue
      }, n);
    }
    return p;
  }, "polar")
};
function Ne(i, r) {
  var e = i.get("realtimeSort", !0), t = r.getBaseAxis();
  if (process.env.NODE_ENV !== "production" && e && (t.type !== "category" && B("`realtimeSort` will not work because this bar series is not based on a category axis."), r.type !== "cartesian2d" && B("`realtimeSort` will not work because this bar series is not on cartesian2d.")), e && t.type === "category" && r.type === "cartesian2d")
    return {
      baseAxis: t,
      otherAxis: r.getOtherAxis(t)
    };
}
f(Ne, "shouldRealtimeSort");
function q(i, r, e, t, a, n, o, s) {
  var u, h;
  n ? (h = {
    x: t.x,
    width: t.width
  }, u = {
    y: t.y,
    height: t.height
  }) : (h = {
    y: t.y,
    height: t.height
  }, u = {
    x: t.x,
    width: t.width
  }), s || (o ? C : k)(e, {
    shape: u
  }, r, a, null);
  var p = r ? i.baseAxis.model : null;
  (o ? C : k)(e, {
    shape: h
  }, p, a);
}
f(q, "updateRealtimeAnimation");
function J(i, r) {
  for (var e = 0; e < r.length; e++)
    if (!isFinite(i[r[e]]))
      return !0;
  return !1;
}
f(J, "checkPropertiesNotValid");
var Oe = ["x", "y", "width", "height"], Ee = ["cx", "cy", "r", "startAngle", "endAngle"], K = {
  cartesian2d: /* @__PURE__ */ f(function(i) {
    return !J(i, Oe);
  }, "cartesian2d"),
  polar: /* @__PURE__ */ f(function(i) {
    return !J(i, Ee);
  }, "polar")
}, P = {
  // itemModel is only used to get borderWidth, which is not needed
  // when calculating bar background layout.
  cartesian2d: /* @__PURE__ */ f(function(i, r, e) {
    var t = i.getItemLayout(r), a = e ? We(e, t) : 0, n = t.width > 0 ? 1 : -1, o = t.height > 0 ? 1 : -1;
    return {
      x: t.x + n * a / 2,
      y: t.y + o * a / 2,
      width: t.width - n * a,
      height: t.height - o * a
    };
  }, "cartesian2d"),
  polar: /* @__PURE__ */ f(function(i, r, e) {
    var t = i.getItemLayout(r);
    return {
      cx: t.cx,
      cy: t.cy,
      r0: t.r0,
      r: t.r,
      startAngle: t.startAngle,
      endAngle: t.endAngle,
      clockwise: t.clockwise
    };
  }, "polar")
};
function Re(i) {
  return i.startAngle != null && i.endAngle != null && i.startAngle === i.endAngle;
}
f(Re, "isZeroOnPolar");
function se(i) {
  return /* @__PURE__ */ function(r) {
    var e = r ? "Arc" : "Angle";
    return function(t) {
      switch (t) {
        case "start":
        case "insideStart":
        case "end":
        case "insideEnd":
          return t + e;
        default:
          return t;
      }
    };
  }(i);
}
f(se, "createPolarPositionMapping");
function Q(i, r, e, t, a, n, o, s) {
  var u = r.getItemVisual(e, "style");
  if (s) {
    if (!n.get("roundCap")) {
      var p = i.shape, g = ke(t.getModel("itemStyle"), p, !0);
      re(p, g), i.setShape(p);
    }
  } else {
    var h = t.get(["itemStyle", "borderRadius"]) || 0;
    i.setShape("r", h);
  }
  i.useStyle(u);
  var _ = t.getShallow("cursor");
  _ && i.attr("cursor", _);
  var c = s ? o ? a.r >= a.r0 ? "endArc" : "startArc" : a.endAngle >= a.startAngle ? "endAngle" : "startAngle" : o ? a.height >= 0 ? "bottom" : "top" : a.width >= 0 ? "right" : "left", x = be(t);
  Ae(i, x, {
    labelFetcher: n,
    labelDataIndex: e,
    defaultText: De(n.getData(), e),
    inheritColor: u.fill,
    defaultOpacity: u.opacity,
    defaultOutsidePosition: c
  });
  var D = i.getTextContent();
  if (s && D) {
    var w = t.get(["label", "position"]);
    i.textConfig.inside = w === "middle" ? !0 : null, Ie(i, w === "outside" ? c : w, se(o), t.get(["label", "rotate"]));
  }
  ye(D, x, n.getRawValue(e), function(y) {
    return Le(r, y);
  });
  var S = t.getModel(["emphasis"]);
  ve(i, S.get("focus"), S.get("blurScope"), S.get("disabled")), me(i, t), Re(a) && (i.style.fill = "none", i.style.stroke = "none", ce(i.states, function(y) {
    y.style && (y.style.fill = y.style.stroke = "none");
  }));
}
f(Q, "updateStyle");
function We(i, r) {
  var e = i.get(["itemStyle", "borderColor"]);
  if (!e || e === "none")
    return 0;
  var t = i.get(["itemStyle", "borderWidth"]) || 0, a = isNaN(r.width) ? Number.MAX_VALUE : Math.abs(r.width), n = isNaN(r.height) ? Number.MAX_VALUE : Math.abs(r.height);
  return Math.min(t, a, n);
}
f(We, "getLineWidth");
var Be = (
  /** @class */
  function() {
    function i() {
    }
    return f(i, "LagePathShape"), i;
  }()
), $ = (
  /** @class */
  function(i) {
    te(r, i);
    function r(e) {
      var t = i.call(this, e) || this;
      return t.type = "largeBar", t;
    }
    return f(r, "LargePath"), r.prototype.getDefaultShape = function() {
      return new Be();
    }, r.prototype.buildPath = function(e, t) {
      for (var a = t.points, n = this.baseDimIdx, o = 1 - this.baseDimIdx, s = [], u = [], h = this.barWidth, p = 0; p < a.length; p += 3)
        u[n] = h, u[o] = a[p + 2], s[n] = a[p + n], s[o] = a[p + o], e.rect(s[0], s[1], u[0], u[1]);
    }, r;
  }(ge)
);
function H(i, r, e, t) {
  var a = i.getData(), n = a.getLayout("valueAxisHorizontal") ? 1 : 0, o = a.getLayout("largeDataIndices"), s = a.getLayout("size"), u = i.getModel("backgroundStyle"), h = a.getLayout("largeBackgroundPoints");
  if (h) {
    var p = new $({
      shape: {
        points: h
      },
      incremental: !!t,
      silent: !0,
      z2: 0
    });
    p.baseDimIdx = n, p.largeDataIndices = o, p.barWidth = s, p.useStyle(u.getItemStyle()), r.add(p), e && e.push(p);
  }
  var g = new $({
    shape: {
      points: a.getLayout("largePoints")
    },
    incremental: !!t,
    ignoreCoarsePointer: !0,
    z2: 1
  });
  g.baseDimIdx = n, g.largeDataIndices = o, g.barWidth = s, r.add(g), g.useStyle(a.getVisual("style")), F(g).seriesIndex = i.seriesIndex, i.get("silent") || (g.on("mousedown", ee), g.on("mousemove", ee)), e && e.push(g);
}
f(H, "createLarge");
var ee = xe(function(i) {
  var r = this, e = Fe(r, i.offsetX, i.offsetY);
  F(r).dataIndex = e >= 0 ? e : null;
}, 30, !1);
function Fe(i, r, e) {
  for (var t = i.baseDimIdx, a = 1 - t, n = i.shape.points, o = i.largeDataIndices, s = [], u = [], h = i.barWidth, p = 0, g = n.length / 3; p < g; p++) {
    var _ = p * 3;
    if (u[t] = h, u[a] = n[_ + 2], s[t] = n[_ + t], s[a] = n[_ + a], u[a] < 0 && (s[a] += u[a], u[a] = -u[a]), r >= s[0] && r <= s[0] + u[0] && e >= s[1] && e <= s[1] + u[1])
      return o[p];
  }
  return -1;
}
f(Fe, "largePathFindDataIndex");
function oe(i, r, e) {
  if (ae(e, "cartesian2d")) {
    var t = r, a = e.getArea();
    return {
      x: i ? t.x : a.x,
      y: i ? a.y : t.y,
      width: i ? t.width : a.width,
      height: i ? a.height : t.height
    };
  } else {
    var a = e.getArea(), n = r;
    return {
      cx: a.cx,
      cy: a.cy,
      r0: i ? a.r0 : n.r0,
      r: i ? a.r : n.r,
      startAngle: i ? n.startAngle : 0,
      endAngle: i ? n.endAngle : Math.PI * 2
    };
  }
}
f(oe, "createBackgroundShape");
function Ge(i, r, e) {
  var t = i.type === "polar" ? ne : ie;
  return new t({
    shape: oe(r, e, i),
    silent: !0,
    z2: 0
  });
}
f(Ge, "createBackgroundEl");
export {
  ot as default
};
