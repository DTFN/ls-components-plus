var t = Object.defineProperty;
var o = (r, i) => t(r, "name", { value: i, configurable: !0 });
import n from "../../axis/AxisView/index.js";
import s from "../CartesianAxisPointer/index.js";
import a from "../AxisPointerModel/index.js";
import x from "../AxisPointerView/index.js";
import { isArray as P } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { collect as m } from "../modelHelper/index.js";
import f from "../axisTrigger/index.js";
function I(r) {
  n.registerAxisPointerClass("CartesianAxisPointer", s), r.registerComponentModel(a), r.registerComponentView(x), r.registerPreprocessor(function(i) {
    if (i) {
      (!i.axisPointer || i.axisPointer.length === 0) && (i.axisPointer = {});
      var e = i.axisPointer.link;
      e && !P(e) && (i.axisPointer.link = [e]);
    }
  }), r.registerProcessor(r.PRIORITY.PROCESSOR.STATISTIC, function(i, e) {
    i.getComponent("axisPointer").coordSysAxesInfo = m(i, e);
  }), r.registerAction({
    type: "updateAxisPointer",
    event: "updateAxisPointer",
    update: ":updateAxisPointer"
  }, f);
}
o(I, "install");
export {
  I as install
};
