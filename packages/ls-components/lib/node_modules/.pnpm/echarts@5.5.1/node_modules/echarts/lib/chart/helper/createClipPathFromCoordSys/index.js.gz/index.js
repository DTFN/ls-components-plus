var x = Object.defineProperty;
var o = (e, i) => x(e, "name", { value: i, configurable: !0 });
import { round as v } from "../../../util/number/index.js";
import { isFunction as P } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import y from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
import C from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Sector/index.js";
import { initProps as m } from "../../../animation/basicTransition/index.js";
function k(e, i, a, r, n) {
  var h = e.getArea(), t = h.x, f = h.y, l = h.width, c = h.height, g = a.get(["lineStyle", "width"]) || 2;
  t -= g / 2, f -= g / 2, l += g, c += g, l = Math.ceil(l), t !== Math.floor(t) && (t = Math.floor(t), l++);
  var p = new y({
    shape: {
      x: t,
      y: f,
      width: l,
      height: c
    }
  });
  if (i) {
    var u = e.getBaseAxis(), w = u.isHorizontal(), s = u.inverse;
    w ? (s && (p.shape.x += l), p.shape.width = 0) : (s || (p.shape.y += c), p.shape.height = 0);
    var A = P(n) ? function(d) {
      n(d, p);
    } : null;
    m(p, {
      shape: {
        width: l,
        height: c,
        x: t,
        y: f
      }
    }, a, null, r, A);
  }
  return p;
}
o(k, "createGridClipPath");
function B(e, i, a) {
  var r = e.getArea(), n = v(r.r0, 1), h = v(r.r, 1), t = new C({
    shape: {
      cx: v(e.cx, 1),
      cy: v(e.cy, 1),
      r0: n,
      r: h,
      startAngle: r.startAngle,
      endAngle: r.endAngle,
      clockwise: r.clockwise
    }
  });
  if (i) {
    var f = e.getBaseAxis().dim === "angle";
    f ? t.shape.endAngle = r.startAngle : t.shape.r = n, m(t, {
      shape: {
        endAngle: r.endAngle,
        r: h
      }
    }, a);
  }
  return t;
}
o(B, "createPolarClipPath");
function W(e, i, a, r, n) {
  if (e) {
    if (e.type === "polar")
      return B(e, i, a);
    if (e.type === "cartesian2d")
      return k(e, i, a, r, n);
  } else return null;
  return null;
}
o(W, "createClipPath");
export {
  W as createClipPath,
  k as createGridClipPath,
  B as createPolarClipPath
};
