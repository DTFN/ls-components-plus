var E = Object.defineProperty;
var g = (r, n) => E(r, "name", { value: n, configurable: !0 });
import L from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import { retrieve2 as C, extend as x, keys as Y, trim as z, isFunction as H } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { DISPLAY_STATES as V, SPECIAL_STATES as b } from "../../util/states/index.js";
import { deprecateReplaceLog as p } from "../../util/log/index.js";
import { makeInner as G, interpolateRawValues as J } from "../../util/model/index.js";
import "../../util/graphic/index.js";
import { initProps as Z, updateProps as j } from "../../animation/basicTransition/index.js";
var D = {};
function X(r, n) {
  for (var a = 0; a < b.length; a++) {
    var e = b[a], o = n[e], i = r.ensureState(e);
    i.style = i.style || {}, i.style.text = o;
  }
  var u = r.currentStates.slice();
  r.clearStates(!0), r.setStyle({
    text: n.normal
  }), r.useStates(u, !0);
}
g(X, "setLabelText");
function P(r, n, a) {
  var e = r.labelFetcher, o = r.labelDataIndex, i = r.labelDimIndex, u = n.normal, f;
  e && (f = e.getFormattedLabel(o, "normal", null, i, u && u.get("formatter"), a != null ? {
    interpolatedValue: a
  } : null)), f == null && (f = H(r.defaultText) ? r.defaultText(o, r, a) : r.defaultText);
  for (var l = {
    normal: f
  }, v = 0; v < b.length; v++) {
    var t = b[v], s = n[t];
    l[t] = C(e ? e.getFormattedLabel(o, t, null, i, s && s.get("formatter")) : null, f);
  }
  return l;
}
g(P, "getLabelText");
function nr(r, n, a, e) {
  a = a || D;
  for (var o = r instanceof L, i = !1, u = 0; u < V.length; u++) {
    var f = n[V[u]];
    if (f && f.getShallow("show")) {
      i = !0;
      break;
    }
  }
  var l = o ? r : r.getTextContent();
  if (i) {
    o || (l || (l = new L(), r.setTextContent(l)), r.stateProxy && (l.stateProxy = r.stateProxy));
    var v = P(a, n), t = n.normal, s = !!t.getShallow("show"), c = k(t, e && e.normal, a, !1, !o);
    c.text = v.normal, o || r.setTextConfig(F(t, a, !1));
    for (var u = 0; u < b.length; u++) {
      var T = b[u], f = n[T];
      if (f) {
        var m = l.ensureState(T), h = !!C(f.getShallow("show"), s);
        if (h !== s && (m.ignore = !h), m.style = k(f, e && e[T], a, !0, !o), m.style.text = v[T], !o) {
          var d = r.ensureState(T);
          d.textConfig = F(f, a, !0);
        }
      }
    }
    l.silent = !!t.getShallow("silent"), l.style.x != null && (c.x = l.style.x), l.style.y != null && (c.y = l.style.y), l.ignore = !s, l.useStyle(c), l.dirty(), a.enableTextSetter && (B(l).setLabelText = function(w) {
      var O = P(a, n, w);
      X(l, O);
    });
  } else l && (l.ignore = !0);
  r.dirty();
}
g(nr, "setLabelStyle");
function ar(r, n) {
  n = n || "label";
  for (var a = {
    normal: r.getModel(n)
  }, e = 0; e < b.length; e++) {
    var o = b[e];
    a[o] = r.getModel([o, n]);
  }
  return a;
}
g(ar, "getLabelStatesModels");
function k(r, n, a, e, o) {
  var i = {};
  return q(i, r, a, e, o), n && x(i, n), i;
}
g(k, "createTextStyle");
function F(r, n, a) {
  n = n || {};
  var e = {}, o, i = r.getShallow("rotate"), u = C(r.getShallow("distance"), a ? null : 5), f = r.getShallow("offset");
  return o = r.getShallow("position") || (a ? null : "inside"), o === "outside" && (o = n.defaultOutsidePosition || "top"), o != null && (e.position = o), f != null && (e.offset = f), i != null && (i *= Math.PI / 180, e.rotation = i), u != null && (e.distance = u), e.outsideFill = r.get("color") === "inherit" ? n.inheritColor || null : "auto", e;
}
g(F, "createTextConfig");
function q(r, n, a, e, o) {
  a = a || D;
  var i = n.ecModel, u = i && i.option.textStyle, f = Q(n), l;
  if (f) {
    l = {};
    for (var v in f)
      if (f.hasOwnProperty(v)) {
        var t = n.getModel(["rich", v]);
        W(l[v] = {}, t, u, a, e, o, !1, !0);
      }
  }
  l && (r.rich = l);
  var s = n.get("overflow");
  s && (r.overflow = s);
  var c = n.get("minMargin");
  c != null && (r.margin = c), W(r, n, u, a, e, o, !0, !1);
}
g(q, "setTextStyleCommon");
function Q(r) {
  for (var n; r && r !== r.ecModel; ) {
    var a = (r.option || D).rich;
    if (a) {
      n = n || {};
      for (var e = Y(a), o = 0; o < e.length; o++) {
        var i = e[o];
        n[i] = 1;
      }
    }
    r = r.parentModel;
  }
  return n;
}
g(Q, "getRichItemNames");
var _ = ["fontStyle", "fontWeight", "fontSize", "fontFamily", "textShadowColor", "textShadowBlur", "textShadowOffsetX", "textShadowOffsetY"], A = ["align", "lineHeight", "width", "height", "tag", "verticalAlign", "ellipsis"], R = ["padding", "borderWidth", "borderRadius", "borderDashOffset", "backgroundColor", "borderColor", "shadowColor", "shadowBlur", "shadowOffsetX", "shadowOffsetY"];
function W(r, n, a, e, o, i, u, f) {
  a = !o && a || D;
  var l = e && e.inheritColor, v = n.getShallow("color"), t = n.getShallow("textBorderColor"), s = C(n.getShallow("opacity"), a.opacity);
  (v === "inherit" || v === "auto") && (process.env.NODE_ENV !== "production" && v === "auto" && p("color: 'auto'", "color: 'inherit'"), l ? v = l : v = null), (t === "inherit" || t === "auto") && (process.env.NODE_ENV !== "production" && t === "auto" && p("color: 'auto'", "color: 'inherit'"), l ? t = l : t = null), i || (v = v || a.color, t = t || a.textBorderColor), v != null && (r.fill = v), t != null && (r.stroke = t);
  var c = C(n.getShallow("textBorderWidth"), a.textBorderWidth);
  c != null && (r.lineWidth = c);
  var T = C(n.getShallow("textBorderType"), a.textBorderType);
  T != null && (r.lineDash = T);
  var m = C(n.getShallow("textBorderDashOffset"), a.textBorderDashOffset);
  m != null && (r.lineDashOffset = m), !o && s == null && !f && (s = e && e.defaultOpacity), s != null && (r.opacity = s), !o && !i && r.fill == null && e.inheritColor && (r.fill = e.inheritColor);
  for (var h = 0; h < _.length; h++) {
    var d = _[h], w = C(n.getShallow(d), a[d]);
    w != null && (r[d] = w);
  }
  for (var h = 0; h < A.length; h++) {
    var d = A[h], w = n.getShallow(d);
    w != null && (r[d] = w);
  }
  if (r.verticalAlign == null) {
    var O = n.getShallow("baseline");
    O != null && (r.verticalAlign = O);
  }
  if (!u || !e.disableBox) {
    for (var h = 0; h < R.length; h++) {
      var d = R[h], w = n.getShallow(d);
      w != null && (r[d] = w);
    }
    var I = n.getShallow("borderType");
    I != null && (r.borderDash = I), (r.backgroundColor === "auto" || r.backgroundColor === "inherit") && l && (process.env.NODE_ENV !== "production" && r.backgroundColor === "auto" && p("backgroundColor: 'auto'", "backgroundColor: 'inherit'"), r.backgroundColor = l), (r.borderColor === "auto" || r.borderColor === "inherit") && l && (process.env.NODE_ENV !== "production" && r.borderColor === "auto" && p("borderColor: 'auto'", "borderColor: 'inherit'"), r.borderColor = l);
  }
}
g(W, "setTokenTextStyle");
function or(r, n) {
  var a = n && n.getModel("textStyle");
  return z([
    // FIXME in node-canvas fontWeight is before fontStyle
    r.fontStyle || a && a.getShallow("fontStyle") || "",
    r.fontWeight || a && a.getShallow("fontWeight") || "",
    (r.fontSize || a && a.getShallow("fontSize") || 12) + "px",
    r.fontFamily || a && a.getShallow("fontFamily") || "sans-serif"
  ].join(" "));
}
g(or, "getFont");
var B = G();
function er(r, n, a, e) {
  if (r) {
    var o = B(r);
    o.prevValue = o.value, o.value = a;
    var i = n.normal;
    o.valueAnimation = i.get("valueAnimation"), o.valueAnimation && (o.precision = i.get("precision"), o.defaultInterpolatedText = e, o.statesModels = n);
  }
}
g(er, "setLabelValueAnimation");
function ir(r, n, a, e, o) {
  var i = B(r);
  if (!i.valueAnimation || i.prevValue === i.value)
    return;
  var u = i.defaultInterpolatedText, f = C(i.interpolatedValue, i.prevValue), l = i.value;
  function v(t) {
    var s = J(a, i.precision, f, l, t);
    i.interpolatedValue = t === 1 ? null : s;
    var c = P({
      labelDataIndex: n,
      labelFetcher: o,
      defaultText: u ? u(s) : s + ""
    }, i.statesModels, s);
    X(r, c);
  }
  g(v, "during"), r.percent = 0, (i.prevValue == null ? Z : j)(r, {
    // percent is used to prevent animation from being aborted #15916
    percent: 1
  }, e, n, null, v);
}
g(ir, "animateLabelValue");
export {
  ir as animateLabelValue,
  F as createTextConfig,
  k as createTextStyle,
  or as getFont,
  ar as getLabelStatesModels,
  B as labelInner,
  nr as setLabelStyle,
  X as setLabelText,
  er as setLabelValueAnimation
};
