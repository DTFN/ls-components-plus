var f = Object.defineProperty;
var o = (i, r) => f(i, "name", { value: r, configurable: !0 });
import { curry as d, each as p } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import h from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/env/index.js";
import { makeInner as v } from "../../../util/model/index.js";
var c = v(), m = p;
function x(i, r, e) {
  if (!h.node) {
    var n = r.getZr();
    c(n).records || (c(n).records = {}), g(n, r);
    var t = c(n).records[i] || (c(n).records[i] = {});
    t.handler = e;
  }
}
o(x, "register");
function g(i, r) {
  if (c(i).initialized)
    return;
  c(i).initialized = !0, e("click", d(u, "click")), e("mousemove", d(u, "mousemove")), e("globalout", T);
  function e(n, t) {
    i.on(n, function(l) {
      var a = L(r);
      m(c(i).records, function(s) {
        s && t(s, l, a.dispatchAction);
      }), A(a.pendings, r);
    });
  }
  o(e, "useHandler");
}
o(g, "initGlobalListeners");
function A(i, r) {
  var e = i.showTip.length, n = i.hideTip.length, t;
  e ? t = i.showTip[e - 1] : n && (t = i.hideTip[n - 1]), t && (t.dispatchAction = null, r.dispatchAction(t));
}
o(A, "dispatchTooltipFinally");
function T(i, r, e) {
  i.handler("leave", null, e);
}
o(T, "onLeave");
function u(i, r, e, n) {
  r.handler(i, e, n);
}
o(u, "doEnter");
function L(i) {
  var r = {
    showTip: [],
    hideTip: []
  }, e = /* @__PURE__ */ o(function(n) {
    var t = r[n.type];
    t ? t.push(n) : (n.dispatchAction = e, i.dispatchAction(n));
  }, "dispatchAction");
  return {
    dispatchAction: e,
    pendings: r
  };
}
o(L, "makeDispatchAction");
function z(i, r) {
  if (!h.node) {
    var e = r.getZr(), n = (c(e).records || {})[i];
    n && (c(e).records[i] = null);
  }
}
o(z, "unregister");
export {
  x as register,
  z as unregister
};
