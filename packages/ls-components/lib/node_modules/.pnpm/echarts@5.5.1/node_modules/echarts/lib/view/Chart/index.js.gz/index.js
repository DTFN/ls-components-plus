var c = Object.defineProperty;
var a = (r, e) => c(r, "name", { value: e, configurable: !0 });
import { each as g } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import v from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import { getUID as y } from "../../util/component/index.js";
import { enableClassExtend as M, enableClassManagement as w } from "../../util/clazz/index.js";
import { queryDataIndex as E, normalizeToArray as T, makeInner as D } from "../../util/model/index.js";
import { getHighlightDigit as k, isHighDownDispatcher as R, enterEmphasis as I, leaveEmphasis as N } from "../../util/states/index.js";
import { createTask as V } from "../../core/task/index.js";
import C from "../../chart/helper/createRenderPlanner/index.js";
import { traverseElements as P } from "../../util/graphic/index.js";
import { error as l } from "../../util/log/index.js";
var m = D(), U = C(), f = (
  /** @class */
  function() {
    function r() {
      this.group = new v(), this.uid = y("viewChart"), this.renderTask = V({
        plan: b,
        reset: G
      }), this.renderTask.context = {
        view: this
      };
    }
    return a(r, "ChartView"), r.prototype.init = function(e, i) {
    }, r.prototype.render = function(e, i, o, t) {
      if (process.env.NODE_ENV !== "production")
        throw new Error("render method must been implemented");
    }, r.prototype.highlight = function(e, i, o, t) {
      var n = e.getData(t && t.dataType);
      if (!n) {
        process.env.NODE_ENV !== "production" && l("Unknown dataType " + t.dataType);
        return;
      }
      h(n, t, "emphasis");
    }, r.prototype.downplay = function(e, i, o, t) {
      var n = e.getData(t && t.dataType);
      if (!n) {
        process.env.NODE_ENV !== "production" && l("Unknown dataType " + t.dataType);
        return;
      }
      h(n, t, "normal");
    }, r.prototype.remove = function(e, i) {
      this.group.removeAll();
    }, r.prototype.dispose = function(e, i) {
    }, r.prototype.updateView = function(e, i, o, t) {
      this.render(e, i, o, t);
    }, r.prototype.updateLayout = function(e, i, o, t) {
      this.render(e, i, o, t);
    }, r.prototype.updateVisual = function(e, i, o, t) {
      this.render(e, i, o, t);
    }, r.prototype.eachRendered = function(e) {
      P(this.group, e);
    }, r.markUpdateMethod = function(e, i) {
      m(e).updateMethod = i;
    }, r.protoInitialize = function() {
      var e = r.prototype;
      e.type = "chart";
    }(), r;
  }()
);
function u(r, e, i) {
  r && R(r) && (e === "emphasis" ? I : N)(r, i);
}
a(u, "elSetState");
function h(r, e, i) {
  var o = E(r, e), t = e && e.highlightKey != null ? k(e.highlightKey) : null;
  o != null ? g(T(o), function(n) {
    u(r.getItemGraphicEl(n), i, t);
  }) : r.eachItemGraphicEl(function(n) {
    u(n, i, t);
  });
}
a(h, "toggleHighlight");
M(f, ["dispose"]);
w(f);
function b(r) {
  return U(r.model);
}
a(b, "renderTaskPlan");
function G(r) {
  var e = r.model, i = r.ecModel, o = r.api, t = r.payload, n = e.pipelineContext.progressiveRender, s = r.view, p = t && m(t).updateMethod, d = n ? "incrementalPrepareRender" : p && s[p] ? p : "render";
  return d !== "render" && s[d](e, i, o, t), H[d];
}
a(G, "renderTaskReset");
var H = {
  incrementalPrepareRender: {
    progress: /* @__PURE__ */ a(function(r, e) {
      e.view.incrementalRender(r, e.model, e.ecModel, e.api, e.payload);
    }, "progress")
  },
  render: {
    // Put view.render in `progress` to support appendData. But in this case
    // view.render should not be called in reset, otherwise it will be called
    // twise. Use `forceFirstProgress` to make sure that view.render is called
    // in any cases.
    forceFirstProgress: !0,
    progress: /* @__PURE__ */ a(function(r, e) {
      e.view.render(e.model, e.ecModel, e.api, e.payload);
    }, "progress")
  }
};
export {
  f as default
};
