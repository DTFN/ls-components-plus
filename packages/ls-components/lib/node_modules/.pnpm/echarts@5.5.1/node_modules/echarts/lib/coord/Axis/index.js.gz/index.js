var M = Object.defineProperty;
var s = (r, t) => M(r, "name", { value: t, configurable: !0 });
import { map as f, each as E } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getPixelPrecision as b, linearMap as d, round as v } from "../../util/number/index.js";
import { createAxisTicks as B, createAxisLabels as L, calculateCategoryInterval as _ } from "../axisTickLabelBuilder/index.js";
var x = [0, 1], V = (
  /** @class */
  function() {
    function r(t, n, e) {
      this.onBand = !1, this.inverse = !1, this.dim = t, this.scale = n, this._extent = e || [0, 0];
    }
    return s(r, "Axis"), r.prototype.contain = function(t) {
      var n = this._extent, e = Math.min(n[0], n[1]), i = Math.max(n[0], n[1]);
      return t >= e && t <= i;
    }, r.prototype.containData = function(t) {
      return this.scale.contain(t);
    }, r.prototype.getExtent = function() {
      return this._extent.slice();
    }, r.prototype.getPixelPrecision = function(t) {
      return b(t || this.scale.getExtent(), this._extent);
    }, r.prototype.setExtent = function(t, n) {
      var e = this._extent;
      e[0] = t, e[1] = n;
    }, r.prototype.dataToCoord = function(t, n) {
      var e = this._extent, i = this.scale;
      return t = i.normalize(t), this.onBand && i.type === "ordinal" && (e = e.slice(), g(e, i.count())), d(t, x, e, n);
    }, r.prototype.coordToData = function(t, n) {
      var e = this._extent, i = this.scale;
      this.onBand && i.type === "ordinal" && (e = e.slice(), g(e, i.count()));
      var o = d(t, e, x, n);
      return this.scale.scale(o);
    }, r.prototype.pointToData = function(t, n) {
    }, r.prototype.getTicksCoords = function(t) {
      t = t || {};
      var n = t.tickModel || this.getTickModel(), e = B(this, n), i = e.ticks, o = f(i, function(c) {
        return {
          coord: this.dataToCoord(this.scale.type === "ordinal" ? this.scale.getRawOrdinalNumber(c) : c),
          tickValue: c
        };
      }, this), a = n.get("alignWithLabel");
      return A(this, o, a, t.clamp), o;
    }, r.prototype.getMinorTicksCoords = function() {
      if (this.scale.type === "ordinal")
        return [];
      var t = this.model.getModel("minorTick"), n = t.get("splitNumber");
      n > 0 && n < 100 || (n = 5);
      var e = this.scale.getMinorTicks(n), i = f(e, function(o) {
        return f(o, function(a) {
          return {
            coord: this.dataToCoord(a),
            tickValue: a
          };
        }, this);
      }, this);
      return i;
    }, r.prototype.getViewLabels = function() {
      return L(this).labels;
    }, r.prototype.getLabelModel = function() {
      return this.model.getModel("axisLabel");
    }, r.prototype.getTickModel = function() {
      return this.model.getModel("axisTick");
    }, r.prototype.getBandWidth = function() {
      var t = this._extent, n = this.scale.getExtent(), e = n[1] - n[0] + (this.onBand ? 1 : 0);
      e === 0 && (e = 1);
      var i = Math.abs(t[1] - t[0]);
      return Math.abs(i) / e;
    }, r.prototype.calculateCategoryInterval = function() {
      return _(this);
    }, r;
  }()
);
function g(r, t) {
  var n = r[1] - r[0], e = t, i = n / e / 2;
  r[0] += i, r[1] -= i;
}
s(g, "fixExtentWithBands");
function A(r, t, n, e) {
  var i = t.length;
  if (!r.onBand || n || !i)
    return;
  var o = r.getExtent(), a, c;
  if (i === 1)
    t[0].coord = o[0], a = t[1] = {
      coord: o[1]
    };
  else {
    var m = t[i - 1].tickValue - t[0].tickValue, p = (t[i - 1].coord - t[0].coord) / m;
    E(t, function(l) {
      l.coord -= p / 2;
    });
    var y = r.scale.getExtent();
    c = 1 + y[1] - t[i - 1].tickValue, a = {
      coord: t[i - 1].coord + p * c
    }, t.push(a);
  }
  var T = o[0] > o[1];
  u(t[0].coord, o[0]) && (e ? t[0].coord = o[0] : t.shift()), e && u(o[0], t[0].coord) && t.unshift({
    coord: o[0]
  }), u(o[1], a.coord) && (e ? a.coord = o[1] : t.pop()), e && u(a.coord, o[1]) && t.push({
    coord: o[1]
  });
  function u(l, h) {
    return l = v(l), h = v(h), T ? l > h : l < h;
  }
  s(u, "littleThan");
}
s(A, "fixOnBandTicksCoords");
export {
  V as default
};
