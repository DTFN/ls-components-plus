var a = Object.defineProperty;
var o = (t, e) => a(t, "name", { value: e, configurable: !0 });
import { __extends as p } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import f from "../../../view/Component/index.js";
import s from "../../../coord/cartesian/GridModel/index.js";
import "../../../util/graphic/index.js";
import { defaults as d } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { CartesianAxisModel as i } from "../../../coord/cartesian/AxisModel/index.js";
import n from "../../../coord/axisModelCreator/index.js";
import l from "../../../coord/cartesian/Grid/index.js";
import { CartesianXAxisView as c, CartesianYAxisView as u } from "../../axis/CartesianAxisView/index.js";
import x from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
var C = (
  /** @class */
  function(t) {
    p(e, t);
    function e() {
      var r = t !== null && t.apply(this, arguments) || this;
      return r.type = "grid", r;
    }
    return o(e, "GridView"), e.prototype.render = function(r, w) {
      this.group.removeAll(), r.get("show") && this.group.add(new x({
        shape: r.coordinateSystem.getRect(),
        style: d({
          fill: r.get("backgroundColor")
        }, r.getItemStyle()),
        silent: !0,
        z2: -1
      }));
    }, e.type = "grid", e;
  }(f)
), m = {
  // gridIndex: 0,
  // gridId: '',
  offset: 0
};
function k(t) {
  t.registerComponentView(C), t.registerComponentModel(s), t.registerCoordinateSystem("cartesian2d", l), n(t, "x", i, m), n(t, "y", i, m), t.registerComponentView(c), t.registerComponentView(u), t.registerPreprocessor(function(e) {
    e.xAxis && e.yAxis && !e.grid && (e.grid = {});
  });
}
o(k, "install");
export {
  k as install
};
