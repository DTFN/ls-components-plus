var U = Object.defineProperty;
var x = (i, r) => U(i, "name", { value: r, configurable: !0 });
import { each as k, keys as Y } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { parsePercent as M } from "../../util/number/index.js";
import { isDimensionStacked as Z } from "../../data/helper/dataStackHelper/index.js";
import $ from "../../chart/helper/createRenderPlanner/index.js";
import { createFloat32Array as O } from "../../util/vendor/index.js";
var N = "__ec_stack_";
function F(i) {
  return i.get("stack") || N + i.seriesIndex;
}
x(F, "getSeriesStackId");
function V(i) {
  return i.dim + i.index;
}
x(V, "getAxisKey");
function j(i, r) {
  var t = [];
  return r.eachSeriesByType(i, function(a) {
    q(a) && t.push(a);
  }), t;
}
x(j, "prepareLayoutBarSeries");
function aa(i) {
  var r = {};
  k(i, function(h) {
    var v = h.coordinateSystem, o = v.getBaseAxis();
    if (!(o.type !== "time" && o.type !== "value"))
      for (var d = h.getData(), u = o.dim + "_" + o.index, m = d.getDimensionIndex(d.mapDimension(o.dim)), p = d.getStore(), b = 0, W = p.count(); b < W; ++b) {
        var f = p.get(m, b);
        r[u] ? r[u].push(f) : r[u] = [f];
      }
  });
  var t = {};
  for (var a in r)
    if (r.hasOwnProperty(a)) {
      var g = r[a];
      if (g) {
        g.sort(function(h, v) {
          return h - v;
        });
        for (var n = null, c = 1; c < g.length; ++c) {
          var e = g[c] - g[c - 1];
          e > 0 && (n = n === null ? e : Math.min(n, e));
        }
        t[a] = n;
      }
    }
  return t;
}
x(aa, "getValueAxesMinGaps");
function ta(i) {
  var r = aa(i), t = [];
  return k(i, function(a) {
    var g = a.coordinateSystem, n = g.getBaseAxis(), c = n.getExtent(), e;
    if (n.type === "category")
      e = n.getBandWidth();
    else if (n.type === "value" || n.type === "time") {
      var h = n.dim + "_" + n.index, v = r[h], o = Math.abs(c[1] - c[0]), d = n.scale.getExtent(), u = Math.abs(d[1] - d[0]);
      e = v ? o / u * v : o;
    } else {
      var m = a.getData();
      e = Math.abs(c[1] - c[0]) / m.count();
    }
    var p = M(a.get("barWidth"), e), b = M(a.get("barMaxWidth"), e), W = M(
      // barMinWidth by default is 0.5 / 1 in cartesian. Because in value axis,
      // the auto-calculated bar width might be less than 0.5 / 1.
      a.get("barMinWidth") || (J(a) ? 0.5 : 1),
      e
    ), f = a.get("barGap"), y = a.get("barCategoryGap");
    t.push({
      bandWidth: e,
      barWidth: p,
      barMaxWidth: b,
      barMinWidth: W,
      barGap: f,
      barCategoryGap: y,
      axisKey: V(n),
      stackId: F(a)
    });
  }), ra(t);
}
x(ta, "makeColumnLayout");
function ra(i) {
  var r = {};
  k(i, function(a, g) {
    var n = a.axisKey, c = a.bandWidth, e = r[n] || {
      bandWidth: c,
      remainedWidth: c,
      autoWidthCount: 0,
      categoryGap: null,
      gap: "20%",
      stacks: {}
    }, h = e.stacks;
    r[n] = e;
    var v = a.stackId;
    h[v] || e.autoWidthCount++, h[v] = h[v] || {
      width: 0,
      maxWidth: 0
    };
    var o = a.barWidth;
    o && !h[v].width && (h[v].width = o, o = Math.min(e.remainedWidth, o), e.remainedWidth -= o);
    var d = a.barMaxWidth;
    d && (h[v].maxWidth = d);
    var u = a.barMinWidth;
    u && (h[v].minWidth = u);
    var m = a.barGap;
    m != null && (e.gap = m);
    var p = a.barCategoryGap;
    p != null && (e.categoryGap = p);
  });
  var t = {};
  return k(r, function(a, g) {
    t[g] = {};
    var n = a.stacks, c = a.bandWidth, e = a.categoryGap;
    if (e == null) {
      var h = Y(n).length;
      e = Math.max(35 - h * 4, 15) + "%";
    }
    var v = M(e, c), o = M(a.gap, 1), d = a.remainedWidth, u = a.autoWidthCount, m = (d - v) / (u + (u - 1) * o);
    m = Math.max(m, 0), k(n, function(f) {
      var y = f.maxWidth, D = f.minWidth;
      if (f.width) {
        var s = f.width;
        y && (s = Math.min(s, y)), D && (s = Math.max(s, D)), f.width = s, d -= s + o * s, u--;
      } else {
        var s = m;
        y && y < s && (s = Math.min(y, d)), D && D > s && (s = D), s !== m && (f.width = s, d -= s + o * s, u--);
      }
    }), m = (d - v) / (u + (u - 1) * o), m = Math.max(m, 0);
    var p = 0, b;
    k(n, function(f, y) {
      f.width || (f.width = m), b = f, p += f.width * (1 + o);
    }), b && (p -= b.width * o);
    var W = -p / 2;
    k(n, function(f, y) {
      t[g][y] = t[g][y] || {
        bandWidth: c,
        offset: W,
        width: f.width
      }, W += f.width * (1 + o);
    });
  }), t;
}
x(ra, "doCalBarWidthAndOffset");
function fa(i, r, t) {
  if (i && r) {
    var a = i[V(r)];
    return a != null && t != null ? a[F(t)] : a;
  }
}
x(fa, "retrieveColumnLayout");
function ga(i, r) {
  var t = j(i, r), a = ta(t);
  k(t, function(g) {
    var n = g.getData(), c = g.coordinateSystem, e = c.getBaseAxis(), h = F(g), v = a[V(e)][h], o = v.offset, d = v.width;
    n.setLayout({
      bandWidth: v.bandWidth,
      offset: o,
      size: d
    });
  });
}
x(ga, "layout");
function ca(i) {
  return {
    seriesType: i,
    plan: $(),
    reset: /* @__PURE__ */ x(function(r) {
      if (q(r)) {
        var t = r.getData(), a = r.coordinateSystem, g = a.getBaseAxis(), n = a.getOtherAxis(g), c = t.getDimensionIndex(t.mapDimension(n.dim)), e = t.getDimensionIndex(t.mapDimension(g.dim)), h = r.get("showBackground", !0), v = t.mapDimension(n.dim), o = t.getCalculationInfo("stackResultDimension"), d = Z(t, v) && !!t.getCalculationInfo("stackedOnSeries"), u = n.isHorizontal(), m = ia(g, n), p = J(r), b = r.get("barMinHeight") || 0, W = o && t.getDimensionIndex(o), f = t.getLayout("size"), y = t.getLayout("offset");
        return {
          progress: /* @__PURE__ */ x(function(D, s) {
            for (var z = D.count, A = p && O(z * 3), L = p && h && O(z * 3), X = p && O(z), T = a.master.getRect(), Q = u ? T.width : T.height, l, H = s.getStore(), G = 0; (l = D.next()) != null; ) {
              var K = H.get(d ? W : c, l), _ = H.get(e, l), P = m, R = void 0;
              d && (R = +K - H.get(c, l));
              var S = void 0, B = void 0, C = void 0, w = void 0;
              if (u) {
                var I = a.dataToPoint([K, _]);
                if (d) {
                  var E = a.dataToPoint([R, _]);
                  P = E[0];
                }
                S = P, B = I[1] + y, C = I[0] - P, w = f, Math.abs(C) < b && (C = (C < 0 ? -1 : 1) * b);
              } else {
                var I = a.dataToPoint([_, K]);
                if (d) {
                  var E = a.dataToPoint([_, R]);
                  P = E[1];
                }
                S = I[0] + y, B = P, C = f, w = I[1] - P, Math.abs(w) < b && (w = (w <= 0 ? -1 : 1) * b);
              }
              p ? (A[G] = S, A[G + 1] = B, A[G + 2] = u ? C : w, L && (L[G] = u ? T.x : S, L[G + 1] = u ? B : T.y, L[G + 2] = Q), X[l] = l) : s.setItemLayout(l, {
                x: S,
                y: B,
                width: C,
                height: w
              }), G += 3;
            }
            p && s.setLayout({
              largePoints: A,
              largeDataIndices: X,
              largeBackgroundPoints: L,
              valueAxisHorizontal: u
            });
          }, "progress")
        };
      }
    }, "reset")
  };
}
x(ca, "createProgressiveLayout");
function q(i) {
  return i.coordinateSystem && i.coordinateSystem.type === "cartesian2d";
}
x(q, "isOnCartesian");
function J(i) {
  return i.pipelineContext && i.pipelineContext.large;
}
x(J, "isInLargeMode");
function ia(i, r) {
  var t = r.model.get("startValue");
  return t || (t = 0), r.toGlobalCoord(r.dataToCoord(r.type === "log" ? t > 0 ? t : 1 : t));
}
x(ia, "getValueAxisStart");
export {
  ca as createProgressiveLayout,
  ga as layout,
  ta as makeColumnLayout,
  j as prepareLayoutBarSeries,
  fa as retrieveColumnLayout
};
