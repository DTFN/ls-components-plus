var q = Object.defineProperty;
var c = (a, e) => q(a, "name", { value: e, configurable: !0 });
import { VISUAL_DIMENSIONS as G } from "../../../util/types/index.js";
import J from "../../SeriesDimensionDefine/index.js";
import { createHashMap as T, isString as L, each as S, extend as P, defaults as B, isObject as F } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { isSourceInstance as Q, createSourceFromSeriesDataOption as X } from "../../Source/index.js";
import { CtorInt32Array as Y } from "../../DataStore/index.js";
import { normalizeToArray as H } from "../../../util/model/index.js";
import { guessOrdinal as $, BE_ORDINAL as R } from "../sourceHelper/index.js";
import { shouldOmitUnusedDimensions as I, ensureSourceDimNameMap as nn, createDimNameMap as an, SeriesDataSchema as en } from "../SeriesDataSchema/index.js";
function hn(a, e) {
  Q(a) || (a = X(a)), e = e || {};
  var d = e.coordDimensions || [], f = e.dimensionsDefine || a.dimensionsDefine || [], u = T(), t = [], s = on(a, d, f, e.dimensionsCount), U = e.canOmitUnusedDimensions && I(s), K = f === a.dimensionsDefine, _ = K ? nn(a) : an(f), A = e.encodeDefine;
  !A && e.encodeDefaulter && (A = e.encodeDefaulter(a, s));
  for (var N = T(A), x = new Y(s), h = 0; h < x.length; h++)
    x[h] = -1;
  function g(i) {
    var r = x[i];
    if (r < 0) {
      var o = f[i], v = F(o) ? o : {
        name: o
      }, n = new J(), D = v.name;
      D != null && _.get(D) != null && (n.name = n.displayName = D), v.type != null && (n.type = v.type), v.displayName != null && (n.displayName = v.displayName);
      var l = t.length;
      return x[i] = l, n.storeDimIndex = i, t.push(n), n;
    }
    return t[r];
  }
  if (c(g, "getResultItem"), !U)
    for (var h = 0; h < s; h++)
      g(h);
  N.each(function(i, r) {
    var o = H(i).slice();
    if (o.length === 1 && !L(o[0]) && o[0] < 0) {
      N.set(r, !1);
      return;
    }
    var v = N.set(r, []);
    S(o, function(n, D) {
      var l = L(n) ? _.get(n) : n;
      l != null && l < s && (v[D] = l, b(g(l), r, D));
    });
  });
  var C = 0;
  S(d, function(i) {
    var r, o, v, n;
    if (L(i))
      r = i, n = {};
    else {
      n = i, r = n.name;
      var D = n.ordinalMeta;
      n.ordinalMeta = null, n = P({}, n), n.ordinalMeta = D, o = n.dimsDef, v = n.otherDims, n.name = n.coordDim = n.coordDimIndex = n.dimsDef = n.otherDims = null;
    }
    var l = N.get(r);
    if (l !== !1) {
      if (l = H(l), !l.length)
        for (var w = 0; w < (o && o.length || 1); w++) {
          for (; C < s && g(C).coordDim != null; )
            C++;
          C < s && l.push(C++);
        }
      S(l, function(k, z) {
        var p = g(k);
        if (K && n.type != null && (p.type = n.type), b(B(p, n), r, z), p.name == null && o) {
          var M = o[z];
          !F(M) && (M = {
            name: M
          }), p.name = p.displayName = M.name, p.defaultTooltip = M.defaultTooltip;
        }
        v && B(p.otherDims, v);
      });
    }
  });
  function b(i, r, o) {
    G.get(r) != null ? i.otherDims[r] = o : (i.coordDim = r, i.coordDimIndex = o, u.set(r, !0));
  }
  c(b, "applyDim");
  var E = e.generateCoord, y = e.generateCoordCount, V = y != null;
  y = E ? y || 1 : 0;
  var W = E || "value";
  function j(i) {
    i.name == null && (i.name = i.coordDim);
  }
  if (c(j, "ifNoNameFillWithCoordName"), U)
    S(t, function(i) {
      j(i);
    }), t.sort(function(i, r) {
      return i.storeDimIndex - r.storeDimIndex;
    });
  else
    for (var O = 0; O < s; O++) {
      var m = g(O), Z = m.coordDim;
      Z == null && (m.coordDim = tn(W, u, V), m.coordDimIndex = 0, (!E || y <= 0) && (m.isExtraCoord = !0), y--), j(m), m.type == null && ($(a, O) === R.Must || m.isExtraCoord && (m.otherDims.itemName != null || m.otherDims.seriesName != null)) && (m.type = "ordinal");
    }
  return rn(t), new en({
    source: a,
    dimensions: t,
    fullDimensionCount: s,
    dimensionOmitted: U
  });
}
c(hn, "prepareSeriesDataSchema");
function rn(a) {
  for (var e = T(), d = 0; d < a.length; d++) {
    var f = a[d], u = f.name, t = e.get(u) || 0;
    t > 0 && (f.name = u + (t - 1)), t++, e.set(u, t);
  }
}
c(rn, "removeDuplication");
function on(a, e, d, f) {
  var u = Math.max(a.dimensionsDetectedCount || 1, e.length, d.length, f || 0);
  return S(e, function(t) {
    var s;
    F(t) && (s = t.dimsDef) && (u = Math.max(u, s.length));
  }), u;
}
c(on, "getDimCount");
function tn(a, e, d) {
  if (d || e.hasKey(a)) {
    for (var f = 0; e.hasKey(a + f); )
      f++;
    a += f;
  }
  return e.set(a, !0), a;
}
c(tn, "genCoordDimName");
export {
  hn as default
};
