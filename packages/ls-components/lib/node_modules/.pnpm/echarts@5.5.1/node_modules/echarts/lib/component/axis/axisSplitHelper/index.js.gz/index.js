var B = Object.defineProperty;
var A = (a, f) => B(a, "name", { value: f, configurable: !0 });
import { createHashMap as H, isArray as G, defaults as x } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { makeInner as z } from "../../../util/model/index.js";
import I from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
var C = z();
function q(a, f, g, R) {
  var l = g.axis;
  if (!l.scale.isBlank()) {
    var m = g.getModel("splitArea"), S = m.getModel("areaStyle"), o = S.get("color"), n = R.coordinateSystem.getRect(), e = l.getTicksCoords({
      tickModel: m,
      clamp: !0
    });
    if (e.length) {
      var u = o.length, y = C(a).splitAreaColors, M = H(), t = 0;
      if (y)
        for (var r = 0; r < e.length; r++) {
          var h = y.get(e[r].tickValue);
          if (h != null) {
            t = (h + (u - 1) * r) % u;
            break;
          }
        }
      var v = l.toGlobalCoord(e[0].coord), b = S.getAreaStyle();
      o = G(o) ? o : [o];
      for (var r = 1; r < e.length; r++) {
        var k = l.toGlobalCoord(e[r].coord), i = void 0, s = void 0, d = void 0, c = void 0;
        l.isHorizontal() ? (i = v, s = n.y, d = k - i, c = n.height, v = i + d) : (i = n.x, s = v, d = n.width, c = k - s, v = s + c);
        var p = e[r - 1].tickValue;
        p != null && M.set(p, t), f.add(new I({
          anid: p != null ? "area_" + p : null,
          shape: {
            x: i,
            y: s,
            width: d,
            height: c
          },
          style: x({
            fill: o[t]
          }, b),
          autoBatch: !0,
          silent: !0
        })), t = (t + 1) % u;
      }
      C(a).splitAreaColors = M;
    }
  }
}
A(q, "rectCoordAxisBuildSplitArea");
function w(a) {
  C(a).splitAreaColors = null;
}
A(w, "rectCoordAxisHandleRemove");
export {
  q as rectCoordAxisBuildSplitArea,
  w as rectCoordAxisHandleRemove
};
