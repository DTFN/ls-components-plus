var X = Object.defineProperty;
var x = (a, r) => X(a, "name", { value: r, configurable: !0 });
import { __extends as j } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { defaults as q, createHashMap as J, extend as I, isFunction as P, isString as Q, curry as Y, each as M } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { parse as tt, stringify as et } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/tool/color/index.js";
import { setTooltipConfig as it } from "../../../util/graphic/index.js";
import { enableHoverEmphasis as K } from "../../../util/states/index.js";
import { setLabelStyle as rt, createTextStyle as nt } from "../../../label/labelStyle/index.js";
import { makeBackground as at } from "../../helper/listComponent/index.js";
import { getLayoutRect as V, box as z } from "../../../util/layout/index.js";
import ot from "../../../view/Component/index.js";
import { createSymbol as st } from "../../../util/symbol/index.js";
import { createOrUpdatePatternFromDecal as lt } from "../../../util/decal/index.js";
import { getECData as $ } from "../../../util/innerStore/index.js";
import U from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import ct from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
import ht from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
var _ = Y, F = M, B = ht, Dt = (
  /** @class */
  function(a) {
    j(r, a);
    function r() {
      var t = a !== null && a.apply(this, arguments) || this;
      return t.type = r.type, t.newlineDisabled = !1, t;
    }
    return x(r, "LegendView"), r.prototype.init = function() {
      this.group.add(this._contentGroup = new B()), this.group.add(this._selectorGroup = new B()), this._isFirstRender = !0;
    }, r.prototype.getContentGroup = function() {
      return this._contentGroup;
    }, r.prototype.getSelectorGroup = function() {
      return this._selectorGroup;
    }, r.prototype.render = function(t, e, h) {
      var c = this._isFirstRender;
      if (this._isFirstRender = !1, this.resetInner(), !!t.get("show", !0)) {
        var f = t.get("align"), y = t.get("orient");
        (!f || f === "auto") && (f = t.get("left") === "right" && y === "vertical" ? "right" : "left");
        var p = t.get("selector", !0), i = t.get("selectorPosition", !0);
        p && (!i || i === "auto") && (i = y === "horizontal" ? "end" : "start"), this.renderInner(f, t, e, h, p, y, i);
        var o = t.getBoxLayoutParams(), u = {
          width: h.getWidth(),
          height: h.getHeight()
        }, s = t.get("padding"), l = V(o, u, s), g = this.layoutInner(t, f, l, c, p, i), n = V(q({
          width: g.width,
          height: g.height
        }, o), u, s);
        this.group.x = n.x - g.x, this.group.y = n.y - g.y, this.group.markRedraw(), this.group.add(this._backgroundEl = at(g, t));
      }
    }, r.prototype.resetInner = function() {
      this.getContentGroup().removeAll(), this._backgroundEl && this.group.remove(this._backgroundEl), this.getSelectorGroup().removeAll();
    }, r.prototype.renderInner = function(t, e, h, c, f, y, p) {
      var i = this.getContentGroup(), o = J(), u = e.get("selectedMode"), s = [];
      h.eachRawSeries(function(l) {
        !l.get("legendHoverLink") && s.push(l.id);
      }), F(e.getData(), function(l, g) {
        var n = l.get("name");
        if (!this.newlineDisabled && (n === "" || n === `
`)) {
          var m = new B();
          m.newline = !0, i.add(m);
          return;
        }
        var v = h.getSeriesByName(n)[0];
        if (!o.get(n)) {
          if (v) {
            var w = v.getData(), d = w.getVisual("legendLineStyle") || {}, G = w.getVisual("legendIcon"), S = w.getVisual("style"), D = this._createItem(v, n, g, l, e, t, d, S, G, u, c);
            D.on("click", _(Z, n, null, c, s)).on("mouseover", _(O, v.name, null, c, s)).on("mouseout", _(E, v.name, null, c, s)), h.ssr && D.eachChild(function(R) {
              var b = $(R);
              b.seriesIndex = v.seriesIndex, b.dataIndex = g, b.ssrType = "legend";
            }), o.set(n, !0);
          } else
            h.eachRawSeries(function(R) {
              if (!o.get(n) && R.legendVisualProvider) {
                var b = R.legendVisualProvider;
                if (!b.containName(n))
                  return;
                var T = b.indexOfName(n), k = b.getItemVisual(T, "style"), W = b.getItemVisual(T, "legendIcon"), C = tt(k.fill);
                C && C[3] === 0 && (C[3] = 0.2, k = I(I({}, k), {
                  fill: et(C, "rgba")
                }));
                var L = this._createItem(R, n, g, l, e, t, {}, k, W, u, c);
                L.on("click", _(Z, null, n, c, s)).on("mouseover", _(O, null, n, c, s)).on("mouseout", _(E, null, n, c, s)), h.ssr && L.eachChild(function(H) {
                  var A = $(H);
                  A.seriesIndex = R.seriesIndex, A.dataIndex = g, A.ssrType = "legend";
                }), o.set(n, !0);
              }
            }, this);
          process.env.NODE_ENV !== "production" && (o.get(n) || console.warn(n + " series not exists. Legend data should be same with series name or data name."));
        }
      }, this), f && this._createSelector(f, e, c, y, p);
    }, r.prototype._createSelector = function(t, e, h, c, f) {
      var y = this.getSelectorGroup();
      F(t, /* @__PURE__ */ x(function(i) {
        var o = i.type, u = new U({
          style: {
            x: 0,
            y: 0,
            align: "center",
            verticalAlign: "middle"
          },
          onclick: /* @__PURE__ */ x(function() {
            h.dispatchAction({
              type: o === "all" ? "legendAllSelect" : "legendInverseSelect"
            });
          }, "onclick")
        });
        y.add(u);
        var s = e.getModel("selectorLabel"), l = e.getModel(["emphasis", "selectorLabel"]);
        rt(u, {
          normal: s,
          emphasis: l
        }, {
          defaultText: i.title
        }), K(u);
      }, "createSelectorButton"));
    }, r.prototype._createItem = function(t, e, h, c, f, y, p, i, o, u, s) {
      var l = t.visualDrawType, g = f.get("itemWidth"), n = f.get("itemHeight"), m = f.isSelected(e), v = c.get("symbolRotate"), w = c.get("symbolKeepAspect"), d = c.get("icon");
      o = d || o || "roundRect";
      var G = ut(o, c, p, i, l, m, s), S = new B(), D = c.getModel("textStyle");
      if (P(t.getLegendIcon) && (!d || d === "inherit"))
        S.add(t.getLegendIcon({
          itemWidth: g,
          itemHeight: n,
          icon: o,
          iconRotate: v,
          itemStyle: G.itemStyle,
          lineStyle: G.lineStyle,
          symbolKeepAspect: w
        }));
      else {
        var R = d === "inherit" && t.getData().getVisual("symbol") ? v === "inherit" ? t.getData().getVisual("symbolRotate") : v : 0;
        S.add(gt({
          itemWidth: g,
          itemHeight: n,
          icon: o,
          iconRotate: R,
          itemStyle: G.itemStyle,
          lineStyle: G.lineStyle,
          symbolKeepAspect: w
        }));
      }
      var b = y === "left" ? g + 5 : -5, T = y, k = f.get("formatter"), W = e;
      Q(k) && k ? W = k.replace("{name}", e ?? "") : P(k) && (W = k(e));
      var C = m ? D.getTextColor() : c.get("inactiveColor");
      S.add(new U({
        style: nt(D, {
          text: W,
          x: b,
          y: n / 2,
          fill: C,
          align: T,
          verticalAlign: "middle"
        }, {
          inheritColor: C
        })
      }));
      var L = new ct({
        shape: S.getBoundingRect(),
        style: {
          // Cannot use 'invisible' because SVG SSR will miss the node
          fill: "transparent"
        }
      }), H = c.getModel("tooltip");
      return H.get("show") && it({
        el: L,
        componentModel: f,
        itemName: e,
        itemTooltipOption: H.option
      }), S.add(L), S.eachChild(function(A) {
        A.silent = !0;
      }), L.silent = !u, this.getContentGroup().add(S), K(S), S.__legendDataIndex = h, S;
    }, r.prototype.layoutInner = function(t, e, h, c, f, y) {
      var p = this.getContentGroup(), i = this.getSelectorGroup();
      z(t.get("orient"), p, t.get("itemGap"), h.width, h.height);
      var o = p.getBoundingRect(), u = [-o.x, -o.y];
      if (i.markRedraw(), p.markRedraw(), f) {
        z(
          // Buttons in selectorGroup always layout horizontally
          "horizontal",
          i,
          t.get("selectorItemGap", !0)
        );
        var s = i.getBoundingRect(), l = [-s.x, -s.y], g = t.get("selectorButtonGap", !0), n = t.getOrient().index, m = n === 0 ? "width" : "height", v = n === 0 ? "height" : "width", w = n === 0 ? "y" : "x";
        y === "end" ? l[n] += o[m] + g : u[n] += s[m] + g, l[1 - n] += o[v] / 2 - s[v] / 2, i.x = l[0], i.y = l[1], p.x = u[0], p.y = u[1];
        var d = {
          x: 0,
          y: 0
        };
        return d[m] = o[m] + g + s[m], d[v] = Math.max(o[v], s[v]), d[w] = Math.min(0, s[w] + l[1 - n]), d;
      } else
        return p.x = u[0], p.y = u[1], this.group.getBoundingRect();
    }, r.prototype.remove = function() {
      this.getContentGroup().removeAll(), this._isFirstRender = !0;
    }, r.type = "legend.plain", r;
  }(ot)
);
function ut(a, r, t, e, h, c, f) {
  function y(m, v) {
    m.lineWidth === "auto" && (m.lineWidth = v.lineWidth > 0 ? 2 : 0), F(m, function(w, d) {
      m[d] === "inherit" && (m[d] = v[d]);
    });
  }
  x(y, "handleCommonProps");
  var p = r.getModel("itemStyle"), i = p.getItemStyle(), o = a.lastIndexOf("empty", 0) === 0 ? "fill" : "stroke", u = p.getShallow("decal");
  i.decal = !u || u === "inherit" ? e.decal : lt(u, f), i.fill === "inherit" && (i.fill = e[h]), i.stroke === "inherit" && (i.stroke = e[o]), i.opacity === "inherit" && (i.opacity = (h === "fill" ? e : t).opacity), y(i, e);
  var s = r.getModel("lineStyle"), l = s.getLineStyle();
  if (y(l, t), i.fill === "auto" && (i.fill = e.fill), i.stroke === "auto" && (i.stroke = e.fill), l.stroke === "auto" && (l.stroke = e.fill), !c) {
    var g = r.get("inactiveBorderWidth"), n = i[o];
    i.lineWidth = g === "auto" ? e.lineWidth > 0 && n ? 2 : 0 : i.lineWidth, i.fill = r.get("inactiveColor"), i.stroke = r.get("inactiveBorderColor"), l.stroke = s.get("inactiveColor"), l.lineWidth = s.get("inactiveWidth");
  }
  return {
    itemStyle: i,
    lineStyle: l
  };
}
x(ut, "getLegendStyle");
function gt(a) {
  var r = a.icon || "roundRect", t = st(r, 0, 0, a.itemWidth, a.itemHeight, a.itemStyle.fill, a.symbolKeepAspect);
  return t.setStyle(a.itemStyle), t.rotation = (a.iconRotate || 0) * Math.PI / 180, t.setOrigin([a.itemWidth / 2, a.itemHeight / 2]), r.indexOf("empty") > -1 && (t.style.stroke = t.style.fill, t.style.fill = "#fff", t.style.lineWidth = 2), t;
}
x(gt, "getDefaultLegendIcon");
function Z(a, r, t, e) {
  E(a, r, t, e), t.dispatchAction({
    type: "legendToggleSelect",
    name: a ?? r
  }), O(a, r, t, e);
}
x(Z, "dispatchSelectAction");
function N(a) {
  for (var r = a.getZr().storage.getDisplayList(), t, e = 0, h = r.length; e < h && !(t = r[e].states.emphasis); )
    e++;
  return t && t.hoverLayer;
}
x(N, "isUseHoverLayer");
function O(a, r, t, e) {
  N(t) || t.dispatchAction({
    type: "highlight",
    seriesName: a,
    name: r,
    excludeSeriesId: e
  });
}
x(O, "dispatchHighlightAction");
function E(a, r, t, e) {
  N(t) || t.dispatchAction({
    type: "downplay",
    seriesName: a,
    name: r,
    excludeSeriesId: e
  });
}
x(E, "dispatchDownplayAction");
export {
  Dt as default
};
