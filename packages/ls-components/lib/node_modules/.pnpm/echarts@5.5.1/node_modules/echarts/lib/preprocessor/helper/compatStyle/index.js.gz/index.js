var y = Object.defineProperty;
var b = (a, e) => y(a, "name", { value: e, configurable: !0 });
import { isArray as g, each as S, isObject as j, defaults as w, isTypedArray as k, merge as P } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { TEXT_STYLE_OPTIONS as V } from "../../../util/model/index.js";
import { deprecateLog as m, deprecateReplaceLog as A } from "../../../util/log/index.js";
var o = S, x = j, G = ["areaStyle", "lineStyle", "nodeStyle", "linkStyle", "chordStyle", "label", "labelLine"];
function L(a) {
  var e = a && a.itemStyle;
  if (e)
    for (var f = 0, i = G.length; f < i; f++) {
      var n = G[f], c = e.normal, l = e.emphasis;
      c && c[n] && (process.env.NODE_ENV !== "production" && A("itemStyle.normal." + n, n), a[n] = a[n] || {}, a[n].normal ? P(a[n].normal, c[n]) : a[n].normal = c[n], c[n] = null), l && l[n] && (process.env.NODE_ENV !== "production" && A("itemStyle.emphasis." + n, "emphasis." + n), a[n] = a[n] || {}, a[n].emphasis ? P(a[n].emphasis, l[n]) : a[n].emphasis = l[n], l[n] = null);
    }
}
b(L, "compatEC2ItemStyle");
function u(a, e, f) {
  if (a && a[e] && (a[e].normal || a[e].emphasis)) {
    var i = a[e].normal, n = a[e].emphasis;
    i && (process.env.NODE_ENV !== "production" && m("'normal' hierarchy in " + e + " has been removed since 4.0. All style properties are configured in " + e + " directly now."), f ? (a[e].normal = a[e].emphasis = null, w(a[e], i)) : a[e] = i), n && (process.env.NODE_ENV !== "production" && m(e + ".emphasis has been changed to emphasis." + e + " since 4.0"), a.emphasis = a.emphasis || {}, a.emphasis[e] = n, n.focus && (a.emphasis.focus = n.focus), n.blurScope && (a.emphasis.blurScope = n.blurScope));
  }
}
b(u, "convertNormalEmphasis");
function s(a) {
  u(a, "itemStyle"), u(a, "lineStyle"), u(a, "areaStyle"), u(a, "label"), u(a, "labelLine"), u(a, "upperLabel"), u(a, "edgeLabel");
}
b(s, "removeEC3NormalStatus");
function r(a, e) {
  var f = x(a) && a[e], i = x(f) && f.textStyle;
  if (i) {
    process.env.NODE_ENV !== "production" && m("textStyle hierarchy in " + e + " has been removed since 4.0. All textStyle properties are configured in " + e + " directly now.");
    for (var n = 0, c = V.length; n < c; n++) {
      var l = V[n];
      i.hasOwnProperty(l) && (f[l] = i[l]);
    }
  }
}
b(r, "compatTextStyle");
function v(a) {
  a && (s(a), r(a, "label"), a.emphasis && r(a.emphasis, "label"));
}
b(v, "compatEC3CommonStyles");
function D(a) {
  if (x(a)) {
    L(a), s(a), r(a, "label"), r(a, "upperLabel"), r(a, "edgeLabel"), a.emphasis && (r(a.emphasis, "label"), r(a.emphasis, "upperLabel"), r(a.emphasis, "edgeLabel"));
    var e = a.markPoint;
    e && (L(e), v(e));
    var f = a.markLine;
    f && (L(f), v(f));
    var i = a.markArea;
    i && v(i);
    var n = a.data;
    if (a.type === "graph") {
      n = n || a.nodes;
      var c = a.links || a.edges;
      if (c && !k(c))
        for (var l = 0; l < c.length; l++)
          v(c[l]);
      S(a.categories, function(E) {
        s(E);
      });
    }
    if (n && !k(n))
      for (var l = 0; l < n.length; l++)
        v(n[l]);
    if (e = a.markPoint, e && e.data)
      for (var _ = e.data, l = 0; l < _.length; l++)
        v(_[l]);
    if (f = a.markLine, f && f.data)
      for (var d = f.data, l = 0; l < d.length; l++)
        g(d[l]) ? (v(d[l][0]), v(d[l][1])) : v(d[l]);
    a.type === "gauge" ? (r(a, "axisLabel"), r(a, "title"), r(a, "detail")) : a.type === "treemap" ? (u(a.breadcrumb, "itemStyle"), S(a.levels, function(E) {
      s(E);
    })) : a.type === "tree" && s(a.leaves);
  }
}
b(D, "processSeries");
function h(a) {
  return g(a) ? a : a ? [a] : [];
}
b(h, "toArr");
function C(a) {
  return (g(a) ? a[0] : a) || {};
}
b(C, "toObj");
function X(a, e) {
  o(h(a.series), function(i) {
    x(i) && D(i);
  });
  var f = ["xAxis", "yAxis", "radiusAxis", "angleAxis", "singleAxis", "parallelAxis", "radar"];
  e && f.push("valueAxis", "categoryAxis", "logAxis", "timeAxis"), o(f, function(i) {
    o(h(a[i]), function(n) {
      n && (r(n, "axisLabel"), r(n.axisPointer, "label"));
    });
  }), o(h(a.parallel), function(i) {
    var n = i && i.parallelAxisDefault;
    r(n, "axisLabel"), r(n && n.axisPointer, "label");
  }), o(h(a.calendar), function(i) {
    u(i, "itemStyle"), r(i, "dayLabel"), r(i, "monthLabel"), r(i, "yearLabel");
  }), o(h(a.radar), function(i) {
    r(i, "name"), i.name && i.axisName == null && (i.axisName = i.name, delete i.name, process.env.NODE_ENV !== "production" && m("name property in radar component has been changed to axisName")), i.nameGap != null && i.axisNameGap == null && (i.axisNameGap = i.nameGap, delete i.nameGap, process.env.NODE_ENV !== "production" && m("nameGap property in radar component has been changed to axisNameGap")), process.env.NODE_ENV !== "production" && o(i.indicator, function(n) {
      n.text && A("text", "name", "radar.indicator");
    });
  }), o(h(a.geo), function(i) {
    x(i) && (v(i), o(h(i.regions), function(n) {
      v(n);
    }));
  }), o(h(a.timeline), function(i) {
    v(i), u(i, "label"), u(i, "itemStyle"), u(i, "controlStyle", !0);
    var n = i.data;
    g(n) && S(n, function(c) {
      j(c) && (u(c, "label"), u(c, "itemStyle"));
    });
  }), o(h(a.toolbox), function(i) {
    u(i, "iconStyle"), o(i.feature, function(n) {
      u(n, "iconStyle");
    });
  }), r(C(a.axisPointer), "label"), r(C(a.tooltip).axisPointer, "label");
}
b(X, "globalCompatStyle");
export {
  X as default
};
