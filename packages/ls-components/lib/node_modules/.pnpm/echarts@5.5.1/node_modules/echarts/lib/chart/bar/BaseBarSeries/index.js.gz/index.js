var H = Object.defineProperty;
var S = (i, r) => H(i, "name", { value: r, configurable: !0 });
import { __extends as G } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import B from "../../../model/Series/index.js";
import P from "../../helper/createSeriesData/index.js";
import { each as _ } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var E = (
  /** @class */
  function(i) {
    G(r, i);
    function r() {
      var o = i !== null && i.apply(this, arguments) || this;
      return o.type = r.type, o;
    }
    return S(r, "BaseBarSeriesModel"), r.prototype.getInitialData = function(o, g) {
      return P(null, this, {
        useEncodeDefaulter: !0
      });
    }, r.prototype.getMarkerPosition = function(o, g, D) {
      var t = this.coordinateSystem;
      if (t && t.clampData) {
        var y = t.clampData(o), u = t.dataToPoint(y);
        if (D)
          _(t.getAxes(), function(n, f) {
            if (n.type === "category" && g != null) {
              var e = n.getTicksCoords(), A = n.getTickModel().get("alignWithLabel"), v = y[f], b = g[f] === "x1" || g[f] === "y1";
              if (b && !A && (v += 1), e.length < 2)
                return;
              if (e.length === 2) {
                u[f] = n.toGlobalCoord(n.getExtent()[b ? 1 : 0]);
                return;
              }
              for (var s = void 0, l = void 0, M = 1, a = 0; a < e.length; a++) {
                var p = e[a].coord, h = a === e.length - 1 ? e[a - 1].tickValue + M : e[a].tickValue;
                if (h === v) {
                  l = p;
                  break;
                } else if (h < v)
                  s = p;
                else if (s != null && h > v) {
                  l = (p + s) / 2;
                  break;
                }
                a === 1 && (M = h - e[0].tickValue);
              }
              l == null && (s ? s && (l = e[e.length - 1].coord) : l = e[0].coord), u[f] = n.toGlobalCoord(l);
            }
          });
        else {
          var m = this.getData(), L = m.getLayout("offset"), N = m.getLayout("size"), z = t.getBaseAxis().isHorizontal() ? 0 : 1;
          u[z] += L + N / 2;
        }
        return u;
      }
      return [NaN, NaN];
    }, r.type = "series.__base_bar__", r.defaultOption = {
      // zlevel: 0,
      z: 2,
      coordinateSystem: "cartesian2d",
      legendHoverLink: !0,
      // stack: null
      // Cartesian coordinate system
      // xAxisIndex: 0,
      // yAxisIndex: 0,
      barMinHeight: 0,
      barMinAngle: 0,
      // cursor: null,
      large: !1,
      largeThreshold: 400,
      progressive: 3e3,
      progressiveChunkMode: "mod"
    }, r;
  }(B)
);
B.registerClass(E);
export {
  E as default
};
