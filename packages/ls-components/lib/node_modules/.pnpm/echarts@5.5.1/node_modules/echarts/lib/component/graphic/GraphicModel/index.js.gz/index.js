var _ = Object.defineProperty;
var f = (n, e) => _(n, "name", { value: e, configurable: !0 });
import { __extends as N } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { each as h, assert as v, isObject as g, filter as O, extend as S, merge as A } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { mappingToExists as C } from "../../../util/model/index.js";
import R from "../../../model/Component/index.js";
import { mergeLayoutParam as U, copyLayoutParams as I } from "../../../util/layout/index.js";
function L(n, e) {
  var t = n.existing;
  if (e.id = n.keyInfo.id, !e.type && t && (e.type = t.type), e.parentId == null) {
    var o = e.parentOption;
    o ? e.parentId = o.id : t && (e.parentId = t.parentId);
  }
  e.parentOption = null;
}
f(L, "setKeyInfoToNewElOption");
function m(n, e) {
  var t;
  return h(e, function(o) {
    n[o] != null && n[o] !== "auto" && (t = !0);
  }), t;
}
f(m, "isSetLoc");
function M(n, e, t) {
  var o = S({}, t), i = n[e], a = t.$action || "merge";
  if (a === "merge")
    if (i) {
      if (process.env.NODE_ENV !== "production") {
        var r = t.type;
        v(!r || i.type === r, 'Please set $action: "replace" to change `type`');
      }
      A(i, o, !0), U(i, o, {
        ignoreSize: !0
      }), I(t, i), p(t, i), p(t, i, "shape"), p(t, i, "style"), p(t, i, "extra"), t.clipPath = i.clipPath;
    } else
      n[e] = o;
  else a === "replace" ? n[e] = o : a === "remove" && i && (n[e] = null);
}
f(M, "mergeNewElOptionToExist");
var d = ["transition", "enterFrom", "leaveTo"], P = d.concat(["enterAnimation", "updateAnimation", "leaveAnimation"]);
function p(n, e, t) {
  if (t && (!n[t] && e[t] && (n[t] = {}), n = n[t], e = e[t]), !(!n || !e))
    for (var o = t ? d : P, i = 0; i < o.length; i++) {
      var a = o[i];
      n[a] == null && e[a] != null && (n[a] = e[a]);
    }
}
f(p, "copyTransitionInfo");
function $(n, e) {
  if (n && (n.hv = e.hv = [
    // Rigid body, don't care about `width`.
    m(e, ["left", "right"]),
    // Rigid body, don't care about `height`.
    m(e, ["top", "bottom"])
  ], n.type === "group")) {
    var t = n, o = e;
    t.width == null && (t.width = o.width = 0), t.height == null && (t.height = o.height = 0);
  }
}
f($, "setLayoutInfoToExist");
var F = (
  /** @class */
  function(n) {
    N(e, n);
    function e() {
      var t = n !== null && n.apply(this, arguments) || this;
      return t.type = e.type, t.preventAutoZ = !0, t;
    }
    return f(e, "GraphicComponentModel"), e.prototype.mergeOption = function(t, o) {
      var i = this.option.elements;
      this.option.elements = null, n.prototype.mergeOption.call(this, t, o), this.option.elements = i;
    }, e.prototype.optionUpdated = function(t, o) {
      var i = this.option, a = (o ? i : t).elements, r = i.elements = o ? [] : i.elements, u = [];
      this._flatten(a, u, null);
      var y = C(r, u, "normalMerge"), T = this._elOptionsToUpdate = [];
      h(y, function(l, c) {
        var s = l.newOption;
        process.env.NODE_ENV !== "production" && v(g(s) || l.existing, "Empty graphic option definition"), s && (T.push(s), L(l, s), M(r, c, s), $(r[c], s));
      }, this), i.elements = O(r, function(l) {
        return l && delete l.$action, l != null;
      });
    }, e.prototype._flatten = function(t, o, i) {
      h(t, function(a) {
        if (a) {
          i && (a.parentOption = i), o.push(a);
          var r = a.children;
          r && r.length && this._flatten(r, o, a), delete a.children;
        }
      }, this);
    }, e.prototype.useElOptionsToUpdate = function() {
      var t = this._elOptionsToUpdate;
      return this._elOptionsToUpdate = null, t;
    }, e.type = "graphic", e.defaultOption = {
      elements: []
      // parentId: null
    }, e;
  }(R)
);
export {
  F as GraphicComponentModel,
  L as setKeyInfoToNewElOption
};
