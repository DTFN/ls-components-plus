var U = Object.defineProperty;
var E = (_, n) => U(_, "name", { value: n, configurable: !0 });
import { __extends as $ } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { bind as m, each as B, indexOf as j, isFunction as q, isString as J } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { stop as V } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/event/index.js";
import { getTransform as K, transformDirection as Q, applyTransform as k } from "../../../util/graphic/index.js";
import { createOrUpdate as tt, clear as et } from "../../../util/throttle/index.js";
import at from "../DataZoomView/index.js";
import { linearMap as M, parsePercent as O, asc as G } from "../../../util/number/index.js";
import { getLayoutParams as rt, getLayoutRect as it } from "../../../util/layout/index.js";
import ot from "../../helper/sliderMove/index.js";
import { getAxisMainType as st, collectReferCoordSysModelInfo as nt } from "../helper/index.js";
import { enableHoverEmphasis as ht } from "../../../util/states/index.js";
import { symbolBuildProxies as lt, createSymbol as F } from "../../../util/symbol/index.js";
import { deprecateLog as dt } from "../../../util/log/index.js";
import { createTextStyle as ut } from "../../../label/labelStyle/index.js";
import H from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import pt from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import P from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
import vt from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/Point/index.js";
import gt from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Polygon/index.js";
import ft from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Polyline/index.js";
var R = P, N = 7, ct = 1, C = 30, mt = 7, L = "horizontal", W = "vertical", _t = 5, yt = ["line", "bar", "candlestick", "scatter"], wt = {
  easing: "cubicOut",
  duration: 100,
  delay: 0
}, Nt = (
  /** @class */
  function(_) {
    $(n, _);
    function n() {
      var t = _ !== null && _.apply(this, arguments) || this;
      return t.type = n.type, t._displayables = {}, t;
    }
    return E(n, "SliderZoomView"), n.prototype.init = function(t, e) {
      this.api = e, this._onBrush = m(this._onBrush, this), this._onBrushEnd = m(this._onBrushEnd, this);
    }, n.prototype.render = function(t, e, r, o) {
      if (_.prototype.render.apply(this, arguments), tt(this, "_dispatchZoomAction", t.get("throttle"), "fixRate"), this._orient = t.getOrient(), t.get("show") === !1) {
        this.group.removeAll();
        return;
      }
      if (t.noTarget()) {
        this._clear(), this.group.removeAll();
        return;
      }
      (!o || o.type !== "dataZoom" || o.from !== this.uid) && this._buildView(), this._updateView();
    }, n.prototype.dispose = function() {
      this._clear(), _.prototype.dispose.apply(this, arguments);
    }, n.prototype._clear = function() {
      et(this, "_dispatchZoomAction");
      var t = this.api.getZr();
      t.off("mousemove", this._onBrush), t.off("mouseup", this._onBrushEnd);
    }, n.prototype._buildView = function() {
      var t = this.group;
      t.removeAll(), this._brushing = !1, this._displayables.brushRect = null, this._resetLocation(), this._resetInterval();
      var e = this._displayables.sliderGroup = new H();
      this._renderBackground(), this._renderHandle(), this._renderDataShadow(), t.add(e), this._positionGroup();
    }, n.prototype._resetLocation = function() {
      var t = this.dataZoomModel, e = this.api, r = t.get("brushSelect"), o = r ? mt : 0, a = this._findCoordRect(), i = {
        width: e.getWidth(),
        height: e.getHeight()
      }, s = this._orient === L ? {
        // Why using 'right', because right should be used in vertical,
        // and it is better to be consistent for dealing with position param merge.
        right: i.width - a.x - a.width,
        top: i.height - C - N - o,
        width: a.width,
        height: C
      } : {
        right: N,
        top: a.y,
        width: C,
        height: a.height
      }, h = rt(t.option);
      B(["right", "top", "width", "height"], function(d) {
        h[d] === "ph" && (h[d] = s[d]);
      });
      var l = it(h, i);
      this._location = {
        x: l.x,
        y: l.y
      }, this._size = [l.width, l.height], this._orient === W && this._size.reverse();
    }, n.prototype._positionGroup = function() {
      var t = this.group, e = this._location, r = this._orient, o = this.dataZoomModel.getFirstTargetAxisModel(), a = o && o.get("inverse"), i = this._displayables.sliderGroup, s = (this._dataShadowInfo || {}).otherAxisInverse;
      i.attr(r === L && !a ? {
        scaleY: s ? 1 : -1,
        scaleX: 1
      } : r === L && a ? {
        scaleY: s ? 1 : -1,
        scaleX: -1
      } : r === W && !a ? {
        scaleY: s ? -1 : 1,
        scaleX: 1,
        rotation: Math.PI / 2
      } : {
        scaleY: s ? -1 : 1,
        scaleX: -1,
        rotation: Math.PI / 2
      });
      var h = t.getBoundingRect([i]);
      t.x = e.x - h.x, t.y = e.y - h.y, t.markRedraw();
    }, n.prototype._getViewExtent = function() {
      return [0, this._size[0]];
    }, n.prototype._renderBackground = function() {
      var t = this.dataZoomModel, e = this._size, r = this._displayables.sliderGroup, o = t.get("brushSelect");
      r.add(new R({
        silent: !0,
        shape: {
          x: 0,
          y: 0,
          width: e[0],
          height: e[1]
        },
        style: {
          fill: t.get("backgroundColor")
        },
        z2: -40
      }));
      var a = new R({
        shape: {
          x: 0,
          y: 0,
          width: e[0],
          height: e[1]
        },
        style: {
          fill: "transparent"
        },
        z2: 0,
        onclick: m(this._onClickPanel, this)
      }), i = this.api.getZr();
      o ? (a.on("mousedown", this._onBrushStart, this), a.cursor = "crosshair", i.on("mousemove", this._onBrush), i.on("mouseup", this._onBrushEnd)) : (i.off("mousemove", this._onBrush), i.off("mouseup", this._onBrushEnd)), r.add(a);
    }, n.prototype._renderDataShadow = function() {
      var t = this._dataShadowInfo = this._prepareDataShadowInfo();
      if (this._displayables.dataShadowSegs = [], !t)
        return;
      var e = this._size, r = this._shadowSize || [], o = t.series, a = o.getRawData(), i = o.getShadowDim && o.getShadowDim(), s = i && a.getDimensionInfo(i) ? o.getShadowDim() : t.otherDim;
      if (s == null)
        return;
      var h = this._shadowPolygonPts, l = this._shadowPolylinePts;
      if (a !== this._shadowData || s !== this._shadowDim || e[0] !== r[0] || e[1] !== r[1]) {
        var d = a.getDataExtent(s), g = (d[1] - d[0]) * 0.3;
        d = [d[0] - g, d[1] + g];
        var p = [0, e[1]], v = [0, e[0]], u = [[e[0], 0], [0, 0]], f = [], S = v[1] / (a.count() - 1), c = 0, D = Math.round(a.count() / e[0]), w;
        a.each([s], function(b, I) {
          if (D > 0 && I % D) {
            c += S;
            return;
          }
          var x = b == null || isNaN(b) || b === "", T = x ? 0 : M(b, d, p, !0);
          x && !w && I ? (u.push([u[u.length - 1][0], 0]), f.push([f[f.length - 1][0], 0])) : !x && w && (u.push([c, 0]), f.push([c, 0])), u.push([c, T]), f.push([c, T]), c += S, w = x;
        }), h = this._shadowPolygonPts = u, l = this._shadowPolylinePts = f;
      }
      this._shadowData = a, this._shadowDim = s, this._shadowSize = [e[0], e[1]];
      var y = this.dataZoomModel;
      function z(b) {
        var I = y.getModel(b ? "selectedDataBackground" : "dataBackground"), x = new H(), T = new gt({
          shape: {
            points: h
          },
          segmentIgnoreThreshold: 1,
          style: I.getModel("areaStyle").getAreaStyle(),
          silent: !0,
          z2: -20
        }), X = new ft({
          shape: {
            points: l
          },
          segmentIgnoreThreshold: 1,
          style: I.getModel("lineStyle").getLineStyle(),
          silent: !0,
          z2: -19
        });
        return x.add(T), x.add(X), x;
      }
      E(z, "createDataShadowGroup");
      for (var A = 0; A < 3; A++) {
        var Z = z(A === 1);
        this._displayables.sliderGroup.add(Z), this._displayables.dataShadowSegs.push(Z);
      }
    }, n.prototype._prepareDataShadowInfo = function() {
      var t = this.dataZoomModel, e = t.get("showDataShadow");
      if (e !== !1) {
        var r, o = this.ecModel;
        return t.eachTargetAxis(function(a, i) {
          var s = t.getAxisProxy(a, i).getTargetSeriesModels();
          B(s, function(h) {
            if (!r && !(e !== !0 && j(yt, h.get("type")) < 0)) {
              var l = o.getComponent(st(a), i).axis, d = bt(a), g, p = h.coordinateSystem;
              d != null && p.getOtherAxis && (g = p.getOtherAxis(l).inverse), d = h.getData().mapDimension(d), r = {
                thisAxis: l,
                series: h,
                thisDim: a,
                otherDim: d,
                otherAxisInverse: g
              };
            }
          }, this);
        }, this), r;
      }
    }, n.prototype._renderHandle = function() {
      var t = this.group, e = this._displayables, r = e.handles = [null, null], o = e.handleLabels = [null, null], a = this._displayables.sliderGroup, i = this._size, s = this.dataZoomModel, h = this.api, l = s.get("borderRadius") || 0, d = s.get("brushSelect"), g = e.filler = new R({
        silent: d,
        style: {
          fill: s.get("fillerColor")
        },
        textConfig: {
          position: "inside"
        }
      });
      a.add(g), a.add(new R({
        silent: !0,
        subPixelOptimize: !0,
        shape: {
          x: 0,
          y: 0,
          width: i[0],
          height: i[1],
          r: l
        },
        style: {
          // deprecated option
          stroke: s.get("dataBackgroundColor") || s.get("borderColor"),
          lineWidth: ct,
          fill: "rgba(0,0,0,0)"
        }
      })), B([0, 1], function(D) {
        var w = s.get("handleIcon");
        !lt[w] && w.indexOf("path://") < 0 && w.indexOf("image://") < 0 && (w = "path://" + w, process.env.NODE_ENV !== "production" && dt("handleIcon now needs 'path://' prefix when using a path string"));
        var y = F(w, -1, 0, 2, 2, null, !0);
        y.attr({
          cursor: Y(this._orient),
          draggable: !0,
          drift: m(this._onDragMove, this, D),
          ondragend: m(this._onDragEnd, this),
          onmouseover: m(this._showDataInfo, this, !0),
          onmouseout: m(this._showDataInfo, this, !1),
          z2: 5
        });
        var z = y.getBoundingRect(), A = s.get("handleSize");
        this._handleHeight = O(A, this._size[1]), this._handleWidth = z.width / z.height * this._handleHeight, y.setStyle(s.getModel("handleStyle").getItemStyle()), y.style.strokeNoScale = !0, y.rectHover = !0, y.ensureState("emphasis").style = s.getModel(["emphasis", "handleStyle"]).getItemStyle(), ht(y);
        var Z = s.get("handleColor");
        Z != null && (y.style.fill = Z), a.add(r[D] = y);
        var b = s.getModel("textStyle");
        t.add(o[D] = new pt({
          silent: !0,
          invisible: !0,
          style: ut(b, {
            x: 0,
            y: 0,
            text: "",
            verticalAlign: "middle",
            align: "center",
            fill: b.getTextColor(),
            font: b.getFont()
          }),
          z2: 10
        }));
      }, this);
      var p = g;
      if (d) {
        var v = O(s.get("moveHandleSize"), i[1]), u = e.moveHandle = new P({
          style: s.getModel("moveHandleStyle").getItemStyle(),
          silent: !0,
          shape: {
            r: [0, 0, 2, 2],
            y: i[1] - 0.5,
            height: v
          }
        }), f = v * 0.8, S = e.moveHandleIcon = F(s.get("moveHandleIcon"), -f / 2, -f / 2, f, f, "#fff", !0);
        S.silent = !0, S.y = i[1] + v / 2 - 0.5, u.ensureState("emphasis").style = s.getModel(["emphasis", "moveHandleStyle"]).getItemStyle();
        var c = Math.min(i[1] / 2, Math.max(v, 10));
        p = e.moveZone = new P({
          invisible: !0,
          shape: {
            y: i[1] - c,
            height: v + c
          }
        }), p.on("mouseover", function() {
          h.enterEmphasis(u);
        }).on("mouseout", function() {
          h.leaveEmphasis(u);
        }), a.add(u), a.add(S), a.add(p);
      }
      p.attr({
        draggable: !0,
        cursor: Y(this._orient),
        drift: m(this._onDragMove, this, "all"),
        ondragstart: m(this._showDataInfo, this, !0),
        ondragend: m(this._onDragEnd, this),
        onmouseover: m(this._showDataInfo, this, !0),
        onmouseout: m(this._showDataInfo, this, !1)
      });
    }, n.prototype._resetInterval = function() {
      var t = this._range = this.dataZoomModel.getPercentRange(), e = this._getViewExtent();
      this._handleEnds = [M(t[0], [0, 100], e, !0), M(t[1], [0, 100], e, !0)];
    }, n.prototype._updateInterval = function(t, e) {
      var r = this.dataZoomModel, o = this._handleEnds, a = this._getViewExtent(), i = r.findRepresentativeAxisProxy().getMinMaxSpan(), s = [0, 100];
      ot(e, o, a, r.get("zoomLock") ? "all" : t, i.minSpan != null ? M(i.minSpan, s, a, !0) : null, i.maxSpan != null ? M(i.maxSpan, s, a, !0) : null);
      var h = this._range, l = this._range = G([M(o[0], a, s, !0), M(o[1], a, s, !0)]);
      return !h || h[0] !== l[0] || h[1] !== l[1];
    }, n.prototype._updateView = function(t) {
      var e = this._displayables, r = this._handleEnds, o = G(r.slice()), a = this._size;
      B([0, 1], function(p) {
        var v = e.handles[p], u = this._handleHeight;
        v.attr({
          scaleX: u / 2,
          scaleY: u / 2,
          // This is a trick, by adding an extra tiny offset to let the default handle's end point align to the drag window.
          // NOTE: It may affect some custom shapes a bit. But we prefer to have better result by default.
          x: r[p] + (p ? -1 : 1),
          y: a[1] / 2 - u / 2
        });
      }, this), e.filler.setShape({
        x: o[0],
        y: 0,
        width: o[1] - o[0],
        height: a[1]
      });
      var i = {
        x: o[0],
        width: o[1] - o[0]
      };
      e.moveHandle && (e.moveHandle.setShape(i), e.moveZone.setShape(i), e.moveZone.getBoundingRect(), e.moveHandleIcon && e.moveHandleIcon.attr("x", i.x + i.width / 2));
      for (var s = e.dataShadowSegs, h = [0, o[0], o[1], a[0]], l = 0; l < s.length; l++) {
        var d = s[l], g = d.getClipPath();
        g || (g = new P(), d.setClipPath(g)), g.setShape({
          x: h[l],
          y: 0,
          width: h[l + 1] - h[l],
          height: a[1]
        });
      }
      this._updateDataInfo(t);
    }, n.prototype._updateDataInfo = function(t) {
      var e = this.dataZoomModel, r = this._displayables, o = r.handleLabels, a = this._orient, i = ["", ""];
      if (e.get("showDetail")) {
        var s = e.findRepresentativeAxisProxy();
        if (s) {
          var h = s.getAxisModel().axis, l = this._range, d = t ? s.calculateDataWindow({
            start: l[0],
            end: l[1]
          }).valueWindow : s.getDataValueWindow();
          i = [this._formatLabel(d[0], h), this._formatLabel(d[1], h)];
        }
      }
      var g = G(this._handleEnds.slice());
      p.call(this, 0), p.call(this, 1);
      function p(v) {
        var u = K(r.handles[v].parent, this.group), f = Q(v === 0 ? "right" : "left", u), S = this._handleWidth / 2 + _t, c = k([g[v] + (v === 0 ? -S : S), this._size[1] / 2], u);
        o[v].setStyle({
          x: c[0],
          y: c[1],
          verticalAlign: a === L ? "middle" : f,
          align: a === L ? f : "center",
          text: i[v]
        });
      }
      E(p, "setLabel");
    }, n.prototype._formatLabel = function(t, e) {
      var r = this.dataZoomModel, o = r.get("labelFormatter"), a = r.get("labelPrecision");
      (a == null || a === "auto") && (a = e.getPixelPrecision());
      var i = t == null || isNaN(t) ? "" : e.type === "category" || e.type === "time" ? e.scale.getLabel({
        value: Math.round(t)
      }) : t.toFixed(Math.min(a, 20));
      return q(o) ? o(t, i) : J(o) ? o.replace("{value}", i) : i;
    }, n.prototype._showDataInfo = function(t) {
      t = this._dragging || t;
      var e = this._displayables, r = e.handleLabels;
      r[0].attr("invisible", !t), r[1].attr("invisible", !t), e.moveHandle && this.api[t ? "enterEmphasis" : "leaveEmphasis"](e.moveHandle, 1);
    }, n.prototype._onDragMove = function(t, e, r, o) {
      this._dragging = !0, V(o.event);
      var a = this._displayables.sliderGroup.getLocalTransform(), i = k([e, r], a, !0), s = this._updateInterval(t, i[0]), h = this.dataZoomModel.get("realtime");
      this._updateView(!h), s && h && this._dispatchZoomAction(!0);
    }, n.prototype._onDragEnd = function() {
      this._dragging = !1, this._showDataInfo(!1);
      var t = this.dataZoomModel.get("realtime");
      !t && this._dispatchZoomAction(!1);
    }, n.prototype._onClickPanel = function(t) {
      var e = this._size, r = this._displayables.sliderGroup.transformCoordToLocal(t.offsetX, t.offsetY);
      if (!(r[0] < 0 || r[0] > e[0] || r[1] < 0 || r[1] > e[1])) {
        var o = this._handleEnds, a = (o[0] + o[1]) / 2, i = this._updateInterval("all", r[0] - a);
        this._updateView(), i && this._dispatchZoomAction(!1);
      }
    }, n.prototype._onBrushStart = function(t) {
      var e = t.offsetX, r = t.offsetY;
      this._brushStart = new vt(e, r), this._brushing = !0, this._brushStartTime = +/* @__PURE__ */ new Date();
    }, n.prototype._onBrushEnd = function(t) {
      if (this._brushing) {
        var e = this._displayables.brushRect;
        if (this._brushing = !1, !!e) {
          e.attr("ignore", !0);
          var r = e.shape, o = +/* @__PURE__ */ new Date();
          if (!(o - this._brushStartTime < 200 && Math.abs(r.width) < 5)) {
            var a = this._getViewExtent(), i = [0, 100];
            this._range = G([M(r.x, a, i, !0), M(r.x + r.width, a, i, !0)]), this._handleEnds = [r.x, r.x + r.width], this._updateView(), this._dispatchZoomAction(!1);
          }
        }
      }
    }, n.prototype._onBrush = function(t) {
      this._brushing && (V(t.event), this._updateBrushRect(t.offsetX, t.offsetY));
    }, n.prototype._updateBrushRect = function(t, e) {
      var r = this._displayables, o = this.dataZoomModel, a = r.brushRect;
      a || (a = r.brushRect = new R({
        silent: !0,
        style: o.getModel("brushStyle").getItemStyle()
      }), r.sliderGroup.add(a)), a.attr("ignore", !1);
      var i = this._brushStart, s = this._displayables.sliderGroup, h = s.transformCoordToLocal(t, e), l = s.transformCoordToLocal(i.x, i.y), d = this._size;
      h[0] = Math.max(Math.min(d[0], h[0]), 0), a.setShape({
        x: l[0],
        y: 0,
        width: h[0] - l[0],
        height: d[1]
      });
    }, n.prototype._dispatchZoomAction = function(t) {
      var e = this._range;
      this.api.dispatchAction({
        type: "dataZoom",
        from: this.uid,
        dataZoomId: this.dataZoomModel.id,
        animation: t ? wt : null,
        start: e[0],
        end: e[1]
      });
    }, n.prototype._findCoordRect = function() {
      var t, e = nt(this.dataZoomModel).infoList;
      if (!t && e.length) {
        var r = e[0].model.coordinateSystem;
        t = r.getRect && r.getRect();
      }
      if (!t) {
        var o = this.api.getWidth(), a = this.api.getHeight();
        t = {
          x: o * 0.2,
          y: a * 0.2,
          width: o * 0.6,
          height: a * 0.6
        };
      }
      return t;
    }, n.type = "dataZoom.slider", n;
  }(at)
);
function bt(_) {
  var n = {
    x: "y",
    y: "x",
    radius: "angle",
    angle: "radius"
  };
  return n[_];
}
E(bt, "getOtherDim");
function Y(_) {
  return _ === "vertical" ? "ns-resize" : "ew-resize";
}
E(Y, "getCursor");
export {
  Nt as default
};
