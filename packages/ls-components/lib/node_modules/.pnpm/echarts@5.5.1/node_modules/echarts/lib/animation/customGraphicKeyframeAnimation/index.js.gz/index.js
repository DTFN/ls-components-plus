var T = Object.defineProperty;
var d = (n, e) => T(n, "name", { value: e, configurable: !0 });
import { isArray as _, each as E, keys as R, filter as k, indexOf as S } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { ELEMENT_ANIMATABLE_PROPS as w } from "../customGraphicTransition/index.js";
import { getAnimationConfig as x } from "../basicTransition/index.js";
import { warn as D } from "../../util/log/index.js";
import { makeInner as I } from "../../util/model/index.js";
var p = I(), L = ["percent", "easing", "shape", "style", "extra"];
function X(n) {
  n.stopAnimation("keyframe"), n.attr(p(n));
}
d(X, "stopPreviousKeyframeAnimationAndRestore");
function V(n, e, c) {
  if (!(!c.isAnimationEnabled() || !e)) {
    if (_(e)) {
      E(e, function(r) {
        V(n, r, c);
      });
      return;
    }
    var y = e.keyframes, s = e.duration;
    if (c && s == null) {
      var m = x("enter", c, 0);
      s = m && m.duration;
    }
    if (!(!y || !s)) {
      var a = p(n);
      E(w, function(r) {
        if (!(r && !n[r])) {
          var i, h = !1;
          y.sort(function(t, f) {
            return t.percent - f.percent;
          }), E(y, function(t) {
            var f = n.animators, A = r ? t[r] : t;
            if (process.env.NODE_ENV !== "production" && t.percent >= 1 && (h = !0), !!A) {
              var o = R(A);
              if (r || (o = k(o, function(v) {
                return S(L, v) < 0;
              })), !!o.length) {
                i || (i = n.animate(r, e.loop, !0), i.scope = "keyframe");
                for (var u = 0; u < f.length; u++)
                  f[u] !== i && f[u].targetName === i.targetName && f[u].stopTracks(o);
                r && (a[r] = a[r] || {});
                var K = r ? a[r] : a;
                E(o, function(v) {
                  K[v] = ((r ? n[r] : n) || {})[v];
                }), i.whenWithKeys(s * t.percent, A, o, t.easing);
              }
            }
          }), i && (process.env.NODE_ENV !== "production" && (h || D("End frame with percent: 1 is missing in the keyframeAnimation.", !0)), i.delay(e.delay || 0).duration(s).start(e.easing));
        }
      });
    }
  }
}
d(V, "applyKeyframeAnimation");
export {
  V as applyKeyframeAnimation,
  X as stopPreviousKeyframeAnimationAndRestore
};
