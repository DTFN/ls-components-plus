var d = Object.defineProperty;
var c = (a, r) => d(a, "name", { value: r, configurable: !0 });
import { __extends as g } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import h from "../Scale/index.js";
import p from "../../data/OrdinalMeta/index.js";
import { contain as y, normalize as m, scale as _ } from "../helper/index.js";
import { isArray as x, map as N, isObject as O, isString as b } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var k = (
  /** @class */
  function(a) {
    g(r, a);
    function r(t) {
      var e = a.call(this, t) || this;
      e.type = "ordinal";
      var n = e.getSetting("ordinalMeta");
      return n || (n = new p({})), x(n) && (n = new p({
        categories: N(n, function(o) {
          return O(o) ? o.value : o;
        })
      })), e._ordinalMeta = n, e._extent = e.getSetting("extent") || [0, n.categories.length - 1], e;
    }
    return c(r, "OrdinalScale"), r.prototype.parse = function(t) {
      return t == null ? NaN : b(t) ? this._ordinalMeta.getOrdinal(t) : Math.round(t);
    }, r.prototype.contain = function(t) {
      return t = this.parse(t), y(t, this._extent) && this._ordinalMeta.categories[t] != null;
    }, r.prototype.normalize = function(t) {
      return t = this._getTickNumber(this.parse(t)), m(t, this._extent);
    }, r.prototype.scale = function(t) {
      return t = Math.round(_(t, this._extent)), this.getRawOrdinalNumber(t);
    }, r.prototype.getTicks = function() {
      for (var t = [], e = this._extent, n = e[0]; n <= e[1]; )
        t.push({
          value: n
        }), n++;
      return t;
    }, r.prototype.getMinorTicks = function(t) {
    }, r.prototype.setSortInfo = function(t) {
      if (t == null) {
        this._ordinalNumbersByTick = this._ticksByOrdinalNumber = null;
        return;
      }
      for (var e = t.ordinalNumbers, n = this._ordinalNumbersByTick = [], o = this._ticksByOrdinalNumber = [], i = 0, u = this._ordinalMeta.categories.length, f = Math.min(u, e.length); i < f; ++i) {
        var l = e[i];
        n[i] = l, o[l] = i;
      }
      for (var s = 0; i < u; ++i) {
        for (; o[s] != null; )
          s++;
        n.push(s), o[s] = i;
      }
    }, r.prototype._getTickNumber = function(t) {
      var e = this._ticksByOrdinalNumber;
      return e && t >= 0 && t < e.length ? e[t] : t;
    }, r.prototype.getRawOrdinalNumber = function(t) {
      var e = this._ordinalNumbersByTick;
      return e && t >= 0 && t < e.length ? e[t] : t;
    }, r.prototype.getLabel = function(t) {
      if (!this.isBlank()) {
        var e = this.getRawOrdinalNumber(t.value), n = this._ordinalMeta.categories[e];
        return n == null ? "" : n + "";
      }
    }, r.prototype.count = function() {
      return this._extent[1] - this._extent[0] + 1;
    }, r.prototype.unionExtentFromData = function(t, e) {
      this.unionExtent(t.getApproximateExtent(e));
    }, r.prototype.isInExtentRange = function(t) {
      return t = this._getTickNumber(t), this._extent[0] <= t && this._extent[1] >= t;
    }, r.prototype.getOrdinalMeta = function() {
      return this._ordinalMeta;
    }, r.prototype.calcNiceTicks = function() {
    }, r.prototype.calcNiceExtent = function() {
    }, r.type = "ordinal", r;
  }(h)
);
h.registerClass(k);
export {
  k as default
};
