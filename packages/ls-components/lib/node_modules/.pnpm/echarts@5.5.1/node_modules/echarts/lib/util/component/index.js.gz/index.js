var A = Object.defineProperty;
var a = (n, o) => A(n, "name", { value: o, configurable: !0 });
import { each as D, indexOf as y, merge as I } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { parseClassType as S } from "../clazz/index.js";
import { makePrintable as O } from "../log/index.js";
var k = Math.round(Math.random() * 10);
function j(n) {
  return [n || "", k++].join("_");
}
a(j, "getUID");
function P(n) {
  var o = {};
  n.registerSubTypeDefaulter = function(p, f) {
    var c = S(p);
    o[c.main] = f;
  }, n.determineSubType = function(p, f) {
    var c = f.type;
    if (!c) {
      var r = S(p).main;
      n.hasSubTypes(p) && o[r] && (c = o[r](f));
    }
    return c;
  };
}
a(P, "enableSubTypeDefaulter");
function T(n, o) {
  n.topologicalTravel = function(r, e, l, u) {
    if (!r.length)
      return;
    var s = p(e), g = s.graph, h = s.noEntryList, t = {};
    for (D(r, function(i) {
      t[i] = !0;
    }); h.length; ) {
      var v = h.pop(), b = g[v], d = !!t[v];
      d && (l.call(u, v, b.originalDeps.slice()), delete t[v]), D(b.successor, d ? w : E);
    }
    D(t, function() {
      var i = "";
      throw process.env.NODE_ENV !== "production" && (i = O("Circular dependency may exists: ", t, r, e)), new Error(i);
    });
    function E(i) {
      g[i].entryCount--, g[i].entryCount === 0 && h.push(i);
    }
    a(E, "removeEdge");
    function w(i) {
      t[i] = !0, E(i);
    }
    a(w, "removeEdgeAndAdd");
  };
  function p(r) {
    var e = {}, l = [];
    return D(r, function(u) {
      var s = f(e, u), g = s.originalDeps = o(u), h = c(g, r);
      s.entryCount = h.length, s.entryCount === 0 && l.push(u), D(h, function(t) {
        y(s.predecessor, t) < 0 && s.predecessor.push(t);
        var v = f(e, t);
        y(v.successor, t) < 0 && v.successor.push(u);
      });
    }), {
      graph: e,
      noEntryList: l
    };
  }
  a(p, "makeDepndencyGraph");
  function f(r, e) {
    return r[e] || (r[e] = {
      predecessor: [],
      successor: []
    }), r[e];
  }
  a(f, "createDependencyGraphItem");
  function c(r, e) {
    var l = [];
    return D(r, function(u) {
      y(e, u) >= 0 && l.push(u);
    }), l;
  }
  a(c, "getAvailableDependencies");
}
a(T, "enableTopologicalTravel");
function U(n, o) {
  return I(I({}, n, !0), o, !0);
}
a(U, "inheritDefaultOption");
export {
  P as enableSubTypeDefaulter,
  T as enableTopologicalTravel,
  j as getUID,
  U as inheritDefaultOption
};
