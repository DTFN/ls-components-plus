var C = Object.defineProperty;
var p = (t, e) => C(t, "name", { value: e, configurable: !0 });
import { noop as w, createHashMap as k, each as S, assert as M, isFunction as A, map as E } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { createTask as b } from "../task/index.js";
import { getUID as O } from "../../util/component/index.js";
import V from "../../model/Global/index.js";
import B from "../ExtensionAPI/index.js";
import { normalizeToArray as x } from "../../util/model/index.js";
var H = (
  /** @class */
  function() {
    function t(e, a, i, r) {
      this._stageTaskMap = k(), this.ecInstance = e, this.api = a, i = this._dataProcessorHandlers = i.slice(), r = this._visualHandlers = r.slice(), this._allHandlers = i.concat(r);
    }
    return p(t, "Scheduler"), t.prototype.restoreData = function(e, a) {
      e.restoreData(a), this._stageTaskMap.each(function(i) {
        var r = i.overallTask;
        r && r.dirty();
      });
    }, t.prototype.getPerformArgs = function(e, a) {
      if (e.__pipeline) {
        var i = this._pipelineMap.get(e.__pipeline.id), r = i.context, s = !a && i.progressiveEnabled && (!r || r.progressiveRender) && e.__idxInPipeline > i.blockIndex, n = s ? i.step : null, u = r && r.modDataCount, o = u != null ? Math.ceil(u / n) : null;
        return {
          step: n,
          modBy: o,
          modDataCount: u
        };
      }
    }, t.prototype.getPipeline = function(e) {
      return this._pipelineMap.get(e);
    }, t.prototype.updateStreamModes = function(e, a) {
      var i = this._pipelineMap.get(e.uid), r = e.getData(), s = r.count(), n = i.progressiveEnabled && a.incrementalPrepareRender && s >= i.threshold, u = e.get("large") && s >= e.get("largeThreshold"), o = e.get("progressiveChunkMode") === "mod" ? s : null;
      e.pipelineContext = i.context = {
        progressiveRender: n,
        modDataCount: o,
        large: u
      };
    }, t.prototype.restorePipelines = function(e) {
      var a = this, i = a._pipelineMap = k();
      e.eachSeries(function(r) {
        var s = r.getProgressive(), n = r.uid;
        i.set(n, {
          id: n,
          head: null,
          tail: null,
          threshold: r.getProgressiveThreshold(),
          progressiveEnabled: s && !(r.preventIncremental && r.preventIncremental()),
          blockIndex: -1,
          step: Math.round(s || 700),
          count: 0
        }), a._pipe(r, r.dataTask);
      });
    }, t.prototype.prepareStageTasks = function() {
      var e = this._stageTaskMap, a = this.api.getModel(), i = this.api;
      S(this._allHandlers, function(r) {
        var s = e.get(r.uid) || e.set(r.uid, {}), n = "";
        process.env.NODE_ENV !== "production" && (n = '"reset" and "overallReset" must not be both specified.'), M(!(r.reset && r.overallReset), n), r.reset && this._createSeriesStageTask(r, s, a, i), r.overallReset && this._createOverallStageTask(r, s, a, i);
      }, this);
    }, t.prototype.prepareView = function(e, a, i, r) {
      var s = e.renderTask, n = s.context;
      n.model = a, n.ecModel = i, n.api = r, s.__block = !e.incrementalPrepareRender, this._pipe(a, s);
    }, t.prototype.performDataProcessorTasks = function(e, a) {
      this._performStageTasks(this._dataProcessorHandlers, e, a, {
        block: !0
      });
    }, t.prototype.performVisualTasks = function(e, a, i) {
      this._performStageTasks(this._visualHandlers, e, a, i);
    }, t.prototype._performStageTasks = function(e, a, i, r) {
      r = r || {};
      var s = !1, n = this;
      S(e, function(o, h) {
        if (!(r.visualType && r.visualType !== o.visualType)) {
          var v = n._stageTaskMap.get(o.uid), f = v.seriesTaskMap, c = v.overallTask;
          if (c) {
            var d, g = c.agentStubMap;
            g.each(function(l) {
              u(r, l) && (l.dirty(), d = !0);
            }), d && c.dirty(), n.updatePayload(c, i);
            var T = n.getPerformArgs(c, r.block);
            g.each(function(l) {
              l.perform(T);
            }), c.perform(T) && (s = !0);
          } else f && f.each(function(l, y) {
            u(r, l) && l.dirty();
            var P = n.getPerformArgs(l, r.block);
            P.skip = !o.performRawSeries && a.isSeriesFiltered(l.context.model), n.updatePayload(l, i), l.perform(P) && (s = !0);
          });
        }
      });
      function u(o, h) {
        return o.setDirty && (!o.dirtyMap || o.dirtyMap.get(h.__pipeline.id));
      }
      p(u, "needSetDirty"), this.unfinished = s || this.unfinished;
    }, t.prototype.performSeriesTasks = function(e) {
      var a;
      e.eachSeries(function(i) {
        a = i.dataTask.perform() || a;
      }), this.unfinished = a || this.unfinished;
    }, t.prototype.plan = function() {
      this._pipelineMap.each(function(e) {
        var a = e.tail;
        do {
          if (a.__block) {
            e.blockIndex = a.__idxInPipeline;
            break;
          }
          a = a.getUpstream();
        } while (a);
      });
    }, t.prototype.updatePayload = function(e, a) {
      a !== "remain" && (e.context.payload = a);
    }, t.prototype._createSeriesStageTask = function(e, a, i, r) {
      var s = this, n = a.seriesTaskMap, u = a.seriesTaskMap = k(), o = e.seriesType, h = e.getTargetSeries;
      e.createOnAllSeries ? i.eachRawSeries(v) : o ? i.eachRawSeriesByType(o, v) : h && h(i, r).each(v);
      function v(f) {
        var c = f.uid, d = u.set(c, n && n.get(c) || b({
          plan: z,
          reset: G,
          count: q
        }));
        d.context = {
          model: f,
          ecModel: i,
          api: r,
          // PENDING: `useClearVisual` not used?
          useClearVisual: e.isVisual && !e.isLayout,
          plan: e.plan,
          reset: e.reset,
          scheduler: s
        }, s._pipe(f, d);
      }
      p(v, "create");
    }, t.prototype._createOverallStageTask = function(e, a, i, r) {
      var s = this, n = a.overallTask = a.overallTask || b({
        reset: N
      });
      n.context = {
        ecModel: i,
        api: r,
        overallReset: e.overallReset,
        scheduler: s
      };
      var u = n.agentStubMap, o = n.agentStubMap = k(), h = e.seriesType, v = e.getTargetSeries, f = !0, c = !1, d = "";
      process.env.NODE_ENV !== "production" && (d = '"createOnAllSeries" is not supported for "overallReset", because it will block all streams.'), M(!e.createOnAllSeries, d), h ? i.eachRawSeriesByType(h, g) : v ? v(i, r).each(g) : (f = !1, S(i.getSeries(), g));
      function g(T) {
        var l = T.uid, y = o.set(l, u && u.get(l) || // When the result of `getTargetSeries` changed, the overallTask
        // should be set as dirty and re-performed.
        (c = !0, b({
          reset: F,
          onDirty: U
        })));
        y.context = {
          model: T,
          overallProgress: f
          // FIXME:TS never used, so comment it
          // modifyOutputEnd: modifyOutputEnd
        }, y.agent = n, y.__block = f, s._pipe(T, y);
      }
      p(g, "createStub"), c && n.dirty();
    }, t.prototype._pipe = function(e, a) {
      var i = e.uid, r = this._pipelineMap.get(i);
      !r.head && (r.head = a), r.tail && r.tail.pipe(a), r.tail = a, a.__idxInPipeline = r.count++, a.__pipeline = r;
    }, t.wrapStageHandler = function(e, a) {
      return A(e) && (e = {
        overallReset: e,
        seriesType: J(e)
      }), e.uid = O("stageHandler"), a && (e.visualType = a), e;
    }, t;
  }()
);
function N(t) {
  t.overallReset(t.ecModel, t.api, t.payload);
}
p(N, "overallTaskReset");
function F(t) {
  return t.overallProgress && L;
}
p(F, "stubReset");
function L() {
  this.agent.dirty(), this.getDownstream().dirty();
}
p(L, "stubProgress");
function U() {
  this.agent && this.agent.dirty();
}
p(U, "stubOnDirty");
function z(t) {
  return t.plan ? t.plan(t.model, t.ecModel, t.api, t.payload) : null;
}
p(z, "seriesTaskPlan");
function G(t) {
  t.useClearVisual && t.data.clearAllVisual();
  var e = t.resetDefines = x(t.reset(t.model, t.ecModel, t.api, t.payload));
  return e.length > 1 ? E(e, function(a, i) {
    return D(i);
  }) : j;
}
p(G, "seriesTaskReset");
var j = D(0);
function D(t) {
  return function(e, a) {
    var i = a.data, r = a.resetDefines[t];
    if (r && r.dataEach)
      for (var s = e.start; s < e.end; s++)
        r.dataEach(i, s);
    else r && r.progress && r.progress(e, i);
  };
}
p(D, "makeSeriesTaskProgress");
function q(t) {
  return t.data.count();
}
p(q, "seriesTaskCount");
function J(t) {
  _ = null;
  try {
    t(m, R);
  } catch {
  }
  return _;
}
p(J, "detectSeriseType");
var m = {}, R = {}, _;
I(m, V);
I(R, B);
m.eachSeriesByType = m.eachRawSeriesByType = function(t) {
  _ = t;
};
m.eachComponent = function(t) {
  t.mainType === "series" && t.subType && (_ = t.subType);
};
function I(t, e) {
  for (var a in e.prototype)
    t[a] = w;
}
p(I, "mockMethods");
export {
  H as default
};
