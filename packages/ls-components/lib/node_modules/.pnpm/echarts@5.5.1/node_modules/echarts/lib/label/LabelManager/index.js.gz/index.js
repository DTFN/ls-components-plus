var z = Object.defineProperty;
var h = (v, a) => z(v, "name", { value: a, configurable: !0 });
import "../../util/graphic/index.js";
import { getECData as _ } from "../../util/innerStore/index.js";
import { parsePercent as C } from "../../util/number/index.js";
import H from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/Transformable/index.js";
import { setLabelLineStyle as N, getLabelLineStatesModels as U, updateLabelLinePoints as R } from "../labelGuideHelper/index.js";
import { makeInner as G } from "../../util/model/index.js";
import { isFunction as Y, keys as V, filter as T, each as W, retrieve2 as j, indexOf as P } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { prepareLayoutList as K, shiftLayoutOnX as w, shiftLayoutOnY as F, hideOverlap as I } from "../labelLayoutHelper/index.js";
import { labelInner as q, animateLabelValue as J } from "../labelStyle/index.js";
import { normalizeRadian as Q } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/contain/util/index.js";
import A from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/BoundingRect/index.js";
import { isElementRemoved as Z, initProps as X, updateProps as E } from "../../animation/basicTransition/index.js";
function $(v) {
  if (v) {
    for (var a = [], n = 0; n < v.length; n++)
      a.push(v[n].slice());
    return a;
  }
}
h($, "cloneArr");
function k(v, a) {
  var n = v.label, t = a && a.getTextGuideLine();
  return {
    dataIndex: v.dataIndex,
    dataType: v.dataType,
    seriesIndex: v.seriesModel.seriesIndex,
    text: v.label.style.text,
    rect: v.hostRect,
    labelRect: v.rect,
    // x: labelAttr.x,
    // y: labelAttr.y,
    align: n.style.align,
    verticalAlign: n.style.verticalAlign,
    labelLinePoints: $(t && t.shape.points)
  };
}
h(k, "prepareLayoutCallbackParams");
var D = ["align", "verticalAlign", "width", "height", "fontSize"], d = new H(), b = G(), tt = G();
function m(v, a, n) {
  for (var t = 0; t < n.length; t++) {
    var r = n[t];
    a[r] != null && (v[r] = a[r]);
  }
}
h(m, "extendWithKeys");
var x = ["x", "y", "rotation"], pt = (
  /** @class */
  function() {
    function v() {
      this._labelList = [], this._chartViewList = [];
    }
    return h(v, "LabelManager"), v.prototype.clearLabels = function() {
      this._labelList = [], this._chartViewList = [];
    }, v.prototype._addLabel = function(a, n, t, r, s) {
      var e = r.style, i = r.__hostTarget, f = i.textConfig || {}, l = r.getComputedTransform(), o = r.getBoundingRect().plain();
      A.applyTransform(o, o, l), l ? d.setLocalTransform(l) : (d.x = d.y = d.rotation = d.originX = d.originY = 0, d.scaleX = d.scaleY = 1), d.rotation = Q(d.rotation);
      var c = r.__hostTarget, g;
      if (c) {
        g = c.getBoundingRect().plain();
        var u = c.getComputedTransform();
        A.applyTransform(g, g, u);
      }
      var p = g && c.getTextGuideLine();
      this._labelList.push({
        label: r,
        labelLine: p,
        seriesModel: t,
        dataIndex: a,
        dataType: n,
        layoutOption: s,
        computedLayoutOption: null,
        rect: o,
        hostRect: g,
        // Label with lower priority will be hidden when overlapped
        // Use rect size as default priority
        priority: g ? g.width * g.height : 0,
        // Save default label attributes.
        // For restore if developers want get back to default value in callback.
        defaultAttr: {
          ignore: r.ignore,
          labelGuideIgnore: p && p.ignore,
          x: d.x,
          y: d.y,
          scaleX: d.scaleX,
          scaleY: d.scaleY,
          rotation: d.rotation,
          style: {
            x: e.x,
            y: e.y,
            align: e.align,
            verticalAlign: e.verticalAlign,
            width: e.width,
            height: e.height,
            fontSize: e.fontSize
          },
          cursor: r.cursor,
          attachedPos: f.position,
          attachedRot: f.rotation
        }
      });
    }, v.prototype.addLabelsOfSeries = function(a) {
      var n = this;
      this._chartViewList.push(a);
      var t = a.__model, r = t.get("labelLayout");
      (Y(r) || V(r).length) && a.group.traverse(function(s) {
        if (s.ignore)
          return !0;
        var e = s.getTextContent(), i = _(s);
        e && !e.disableLabelLayout && n._addLabel(i.dataIndex, i.dataType, t, e, r);
      });
    }, v.prototype.updateLayoutConfig = function(a) {
      var n = a.getWidth(), t = a.getHeight();
      function r(O, B) {
        return function() {
          R(O, B);
        };
      }
      h(r, "createDragHandler");
      for (var s = 0; s < this._labelList.length; s++) {
        var e = this._labelList[s], i = e.label, f = i.__hostTarget, l = e.defaultAttr, o = void 0;
        Y(e.layoutOption) ? o = e.layoutOption(k(e, f)) : o = e.layoutOption, o = o || {}, e.computedLayoutOption = o;
        var c = Math.PI / 180;
        f && f.setTextConfig({
          // Force to set local false.
          local: !1,
          // Ignore position and rotation config on the host el if x or y is changed.
          position: o.x != null || o.y != null ? null : l.attachedPos,
          // Ignore rotation config on the host el if rotation is changed.
          rotation: o.rotate != null ? o.rotate * c : l.attachedRot,
          offset: [o.dx || 0, o.dy || 0]
        });
        var g = !1;
        if (o.x != null ? (i.x = C(o.x, n), i.setStyle("x", 0), g = !0) : (i.x = l.x, i.setStyle("x", l.style.x)), o.y != null ? (i.y = C(o.y, t), i.setStyle("y", 0), g = !0) : (i.y = l.y, i.setStyle("y", l.style.y)), o.labelLinePoints) {
          var u = f.getTextGuideLine();
          u && (u.setShape({
            points: o.labelLinePoints
          }), g = !1);
        }
        var p = b(i);
        p.needsUpdateLabelLine = g, i.rotation = o.rotate != null ? o.rotate * c : l.rotation, i.scaleX = l.scaleX, i.scaleY = l.scaleY;
        for (var L = 0; L < D.length; L++) {
          var y = D[L];
          i.setStyle(y, o[y] != null ? o[y] : l.style[y]);
        }
        if (o.draggable) {
          if (i.draggable = !0, i.cursor = "move", f) {
            var S = e.seriesModel;
            if (e.dataIndex != null) {
              var M = e.seriesModel.getData(e.dataType);
              S = M.getItemModel(e.dataIndex);
            }
            i.on("drag", r(f, S.getModel("labelLine")));
          }
        } else
          i.off("drag"), i.cursor = l.cursor;
      }
    }, v.prototype.layout = function(a) {
      var n = a.getWidth(), t = a.getHeight(), r = K(this._labelList), s = T(r, function(f) {
        return f.layoutOption.moveOverlap === "shiftX";
      }), e = T(r, function(f) {
        return f.layoutOption.moveOverlap === "shiftY";
      });
      w(s, 0, n), F(e, 0, t);
      var i = T(r, function(f) {
        return f.layoutOption.hideOverlap;
      });
      I(i);
    }, v.prototype.processLabelsOverall = function() {
      var a = this;
      W(this._chartViewList, function(n) {
        var t = n.__model, r = n.ignoreLabelLineUpdate, s = t.isAnimationEnabled();
        n.group.traverse(function(e) {
          if (e.ignore && !e.forceLabelAnimation)
            return !0;
          var i = !r, f = e.getTextContent();
          !i && f && (i = b(f).needsUpdateLabelLine), i && a._updateLabelLine(e, t), s && a._animateLabels(e, t);
        });
      });
    }, v.prototype._updateLabelLine = function(a, n) {
      var t = a.getTextContent(), r = _(a), s = r.dataIndex;
      if (t && s != null) {
        var e = n.getData(r.dataType), i = e.getItemModel(s), f = {}, l = e.getItemVisual(s, "style");
        if (l) {
          var o = e.getVisual("drawType");
          f.stroke = l[o];
        }
        var c = i.getModel("labelLine");
        N(a, U(i), f), R(a, c);
      }
    }, v.prototype._animateLabels = function(a, n) {
      var t = a.getTextContent(), r = a.getTextGuideLine();
      if (t && (a.forceLabelAnimation || !t.ignore && !t.invisible && !a.disableLabelAnimation && !Z(a))) {
        var s = b(t), e = s.oldLayout, i = _(a), f = i.dataIndex, l = {
          x: t.x,
          y: t.y,
          rotation: t.rotation
        }, o = n.getData(i.dataType);
        if (e) {
          t.attr(e);
          var g = a.prevStates;
          g && (P(g, "select") >= 0 && t.attr(s.oldLayoutSelect), P(g, "emphasis") >= 0 && t.attr(s.oldLayoutEmphasis)), E(t, l, n, f);
        } else if (t.attr(l), !q(t).valueAnimation) {
          var c = j(t.style.opacity, 1);
          t.style.opacity = 0, X(t, {
            style: {
              opacity: c
            }
          }, n, f);
        }
        if (s.oldLayout = l, t.states.select) {
          var u = s.oldLayoutSelect = {};
          m(u, l, x), m(u, t.states.select, x);
        }
        if (t.states.emphasis) {
          var p = s.oldLayoutEmphasis = {};
          m(p, l, x), m(p, t.states.emphasis, x);
        }
        J(t, f, o, n, n);
      }
      if (r && !r.ignore && !r.invisible) {
        var s = tt(r), e = s.oldLayout, L = {
          points: r.shape.points
        };
        e ? (r.attr({
          shape: e
        }), E(r, {
          shape: L
        }, n)) : (r.setShape(L), r.style.strokePercent = 0, X(r, {
          style: {
            strokePercent: 1
          }
        }, n)), s.oldLayout = L;
      }
    }, v;
  }()
);
export {
  pt as default
};
