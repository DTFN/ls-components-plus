var x = Object.defineProperty;
var u = (i, e) => x(i, "name", { value: e, configurable: !0 });
import { curry as H, isArray as P, isObject as _, each as w, clone as z, bind as S } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import * as T from "../../../util/graphic/index.js";
import { createIcon as M } from "../../../util/graphic/index.js";
import { getAxisInfo as I } from "../modelHelper/index.js";
import { stop as D } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/event/index.js";
import { createOrUpdate as L, clear as V } from "../../../util/throttle/index.js";
import { makeInner as C } from "../../../util/model/index.js";
import K from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import O from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import { updateProps as B } from "../../../animation/basicTransition/index.js";
var p = C(), g = z, d = S, J = (
  /** @class */
  function() {
    function i() {
      this._dragging = !1, this.animationThreshold = 15;
    }
    return u(i, "BaseAxisPointer"), i.prototype.render = function(e, t, a, r) {
      var o = t.get("value"), l = t.get("status");
      if (this._axisModel = e, this._axisPointerModel = t, this._api = a, !(!r && this._lastValue === o && this._lastStatus === l)) {
        this._lastValue = o, this._lastStatus = l;
        var n = this._group, s = this._handle;
        if (!l || l === "hide") {
          n && n.hide(), s && s.hide();
          return;
        }
        n && n.show(), s && s.show();
        var h = {};
        this.makeElOption(h, o, e, t, a);
        var c = h.graphicKey;
        c !== this._lastGraphicKey && this.clear(a), this._lastGraphicKey = c;
        var E = this._moveAnimation = this.determineAnimation(e, t);
        if (!n)
          n = this._group = new K(), this.createPointerEl(n, h, e, t), this.createLabelEl(n, h, e, t), a.getZr().add(n);
        else {
          var v = H(m, t, E);
          this.updatePointerEl(n, h, v), this.updateLabelEl(n, h, v, t);
        }
        b(n, t, !0), this._renderHandle(o);
      }
    }, i.prototype.remove = function(e) {
      this.clear(e);
    }, i.prototype.dispose = function(e) {
      this.clear(e);
    }, i.prototype.determineAnimation = function(e, t) {
      var a = t.get("animation"), r = e.axis, o = r.type === "category", l = t.get("snap");
      if (!l && !o)
        return !1;
      if (a === "auto" || a == null) {
        var n = this.animationThreshold;
        if (o && r.getBandWidth() > n)
          return !0;
        if (l) {
          var s = I(e).seriesDataCount, h = r.getExtent();
          return Math.abs(h[0] - h[1]) / s > n;
        }
        return !1;
      }
      return a === !0;
    }, i.prototype.makeElOption = function(e, t, a, r, o) {
    }, i.prototype.createPointerEl = function(e, t, a, r) {
      var o = t.pointer;
      if (o) {
        var l = p(e).pointerEl = new T[o.type](g(t.pointer));
        e.add(l);
      }
    }, i.prototype.createLabelEl = function(e, t, a, r) {
      if (t.label) {
        var o = p(e).labelEl = new O(g(t.label));
        e.add(o), y(o, r);
      }
    }, i.prototype.updatePointerEl = function(e, t, a) {
      var r = p(e).pointerEl;
      r && t.pointer && (r.setStyle(t.pointer.style), a(r, {
        shape: t.pointer.shape
      }));
    }, i.prototype.updateLabelEl = function(e, t, a, r) {
      var o = p(e).labelEl;
      o && (o.setStyle(t.label.style), a(o, {
        // Consider text length change in vertical axis, animation should
        // be used on shape, otherwise the effect will be weird.
        // TODOTODO
        // shape: elOption.label.shape,
        x: t.label.x,
        y: t.label.y
      }), y(o, r));
    }, i.prototype._renderHandle = function(e) {
      if (!(this._dragging || !this.updateHandleTransform)) {
        var t = this._axisPointerModel, a = this._api.getZr(), r = this._handle, o = t.getModel("handle"), l = t.get("status");
        if (!o.get("show") || !l || l === "hide") {
          r && a.remove(r), this._handle = null;
          return;
        }
        var n;
        this._handle || (n = !0, r = this._handle = M(o.get("icon"), {
          cursor: "move",
          draggable: !0,
          onmousemove: /* @__PURE__ */ u(function(h) {
            D(h.event);
          }, "onmousemove"),
          onmousedown: d(this._onHandleDragMove, this, 0, 0),
          drift: d(this._onHandleDragMove, this),
          ondragend: d(this._onHandleDragEnd, this)
        }), a.add(r)), b(r, t, !1), r.setStyle(o.getItemStyle(null, ["color", "borderColor", "borderWidth", "opacity", "shadowColor", "shadowBlur", "shadowOffsetX", "shadowOffsetY"]));
        var s = o.get("size");
        P(s) || (s = [s, s]), r.scaleX = s[0] / 2, r.scaleY = s[1] / 2, L(this, "_doDispatchAxisPointer", o.get("throttle") || 0, "fixRate"), this._moveHandleToValue(e, n);
      }
    }, i.prototype._moveHandleToValue = function(e, t) {
      m(this._axisPointerModel, !t && this._moveAnimation, this._handle, f(this.getHandleTransform(e, this._axisModel, this._axisPointerModel)));
    }, i.prototype._onHandleDragMove = function(e, t) {
      var a = this._handle;
      if (a) {
        this._dragging = !0;
        var r = this.updateHandleTransform(f(a), [e, t], this._axisModel, this._axisPointerModel);
        this._payloadInfo = r, a.stopAnimation(), a.attr(f(r)), p(a).lastProp = null, this._doDispatchAxisPointer();
      }
    }, i.prototype._doDispatchAxisPointer = function() {
      var e = this._handle;
      if (e) {
        var t = this._payloadInfo, a = this._axisModel;
        this._api.dispatchAction({
          type: "updateAxisPointer",
          x: t.cursorPoint[0],
          y: t.cursorPoint[1],
          tooltipOption: t.tooltipOption,
          axesInfo: [{
            axisDim: a.axis.dim,
            axisIndex: a.componentIndex
          }]
        });
      }
    }, i.prototype._onHandleDragEnd = function() {
      this._dragging = !1;
      var e = this._handle;
      if (e) {
        var t = this._axisPointerModel.get("value");
        this._moveHandleToValue(t), this._api.dispatchAction({
          type: "hideTip"
        });
      }
    }, i.prototype.clear = function(e) {
      this._lastValue = null, this._lastStatus = null;
      var t = e.getZr(), a = this._group, r = this._handle;
      t && a && (this._lastGraphicKey = null, a && t.remove(a), r && t.remove(r), this._group = null, this._handle = null, this._payloadInfo = null), V(this, "_doDispatchAxisPointer");
    }, i.prototype.doClear = function() {
    }, i.prototype.buildLabel = function(e, t, a) {
      return a = a || 0, {
        x: e[a],
        y: e[1 - a],
        width: t[a],
        height: t[1 - a]
      };
    }, i;
  }()
);
function m(i, e, t, a) {
  A(p(t).lastProp, a) || (p(t).lastProp = a, e ? B(t, a, i) : (t.stopAnimation(), t.attr(a)));
}
u(m, "updateProps");
function A(i, e) {
  if (_(i) && _(e)) {
    var t = !0;
    return w(e, function(a, r) {
      t = t && A(i[r], a);
    }), !!t;
  } else
    return i === e;
}
u(A, "propsEqual");
function y(i, e) {
  i[e.get(["label", "show"]) ? "show" : "hide"]();
}
u(y, "updateLabelShowHide");
function f(i) {
  return {
    x: i.x || 0,
    y: i.y || 0,
    rotation: i.rotation || 0
  };
}
u(f, "getHandleTransProps");
function b(i, e, t) {
  var a = e.get("z"), r = e.get("zlevel");
  i && i.traverse(function(o) {
    o.type !== "group" && (a != null && (o.z = a), r != null && (o.zlevel = r), o.silent = t);
  });
}
u(b, "updateMandatoryProps");
export {
  J as default
};
