var b = Object.defineProperty;
var f = (r, i) => b(r, "name", { value: i, configurable: !0 });
import { __extends as H } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import X from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/Eventful/index.js";
import { isMiddleOrRightButtonOnMouseUpDown as g, stop as c } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/event/index.js";
import { isTaken as _ } from "../interactionMutex/index.js";
import { bind as h, defaults as Y, clone as O, isString as y } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var W = (
  /** @class */
  function(r) {
    H(i, r);
    function i(e) {
      var o = r.call(this) || this;
      o._zr = e;
      var n = h(o._mousedownHandler, o), t = h(o._mousemoveHandler, o), s = h(o._mouseupHandler, o), u = h(o._mousewheelHandler, o), l = h(o._pinchHandler, o);
      return o.enable = function(a, m) {
        this.disable(), this._opt = Y(O(m) || {}, {
          zoomOnMouseWheel: !0,
          moveOnMouseMove: !0,
          // By default, wheel do not trigger move.
          moveOnMouseWheel: !1,
          preventDefaultMouseMove: !0
        }), a == null && (a = !0), (a === !0 || a === "move" || a === "pan") && (e.on("mousedown", n), e.on("mousemove", t), e.on("mouseup", s)), (a === !0 || a === "scale" || a === "zoom") && (e.on("mousewheel", u), e.on("pinch", l));
      }, o.disable = function() {
        e.off("mousedown", n), e.off("mousemove", t), e.off("mouseup", s), e.off("mousewheel", u), e.off("pinch", l);
      }, o;
    }
    return f(i, "RoamController"), i.prototype.isDragging = function() {
      return this._dragging;
    }, i.prototype.isPinching = function() {
      return this._pinching;
    }, i.prototype.setPointerChecker = function(e) {
      this.pointerChecker = e;
    }, i.prototype.dispose = function() {
      this.disable();
    }, i.prototype._mousedownHandler = function(e) {
      if (!g(e)) {
        for (var o = e.target; o; ) {
          if (o.draggable)
            return;
          o = o.__hostTarget || o.parent;
        }
        var n = e.offsetX, t = e.offsetY;
        this.pointerChecker && this.pointerChecker(e, n, t) && (this._x = n, this._y = t, this._dragging = !0);
      }
    }, i.prototype._mousemoveHandler = function(e) {
      if (!(!this._dragging || !v("moveOnMouseMove", e, this._opt) || e.gestureEvent === "pinch" || _(this._zr, "globalPan"))) {
        var o = e.offsetX, n = e.offsetY, t = this._x, s = this._y, u = o - t, l = n - s;
        this._x = o, this._y = n, this._opt.preventDefaultMouseMove && c(e.event), M(this, "pan", "moveOnMouseMove", e, {
          dx: u,
          dy: l,
          oldX: t,
          oldY: s,
          newX: o,
          newY: n,
          isAvailableBehavior: null
        });
      }
    }, i.prototype._mouseupHandler = function(e) {
      g(e) || (this._dragging = !1);
    }, i.prototype._mousewheelHandler = function(e) {
      var o = v("zoomOnMouseWheel", e, this._opt), n = v("moveOnMouseWheel", e, this._opt), t = e.wheelDelta, s = Math.abs(t), u = e.offsetX, l = e.offsetY;
      if (!(t === 0 || !o && !n)) {
        if (o) {
          var a = s > 3 ? 1.4 : s > 1 ? 1.2 : 1.1, m = t > 0 ? a : 1 / a;
          p(this, "zoom", "zoomOnMouseWheel", e, {
            scale: m,
            originX: u,
            originY: l,
            isAvailableBehavior: null
          });
        }
        if (n) {
          var d = Math.abs(t), w = (t > 0 ? 1 : -1) * (d > 3 ? 0.4 : d > 1 ? 0.15 : 0.05);
          p(this, "scrollMove", "moveOnMouseWheel", e, {
            scrollDelta: w,
            originX: u,
            originY: l,
            isAvailableBehavior: null
          });
        }
      }
    }, i.prototype._pinchHandler = function(e) {
      if (!_(this._zr, "globalPan")) {
        var o = e.pinchScale > 1 ? 1.1 : 1 / 1.1;
        p(this, "zoom", null, e, {
          scale: o,
          originX: e.pinchX,
          originY: e.pinchY,
          isAvailableBehavior: null
        });
      }
    }, i;
  }(X)
);
function p(r, i, e, o, n) {
  r.pointerChecker && r.pointerChecker(o, n.originX, n.originY) && (c(o.event), M(r, i, e, o, n));
}
f(p, "checkPointerAndTrigger");
function M(r, i, e, o, n) {
  n.isAvailableBehavior = h(v, null, e, o), r.trigger(i, n);
}
f(M, "trigger");
function v(r, i, e) {
  var o = e[r];
  return !r || o && (!y(o) || i.event[o + "Key"]);
}
f(v, "isAvailableBehavior");
export {
  W as default
};
