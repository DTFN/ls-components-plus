var f = Object.defineProperty;
var p = (t, a) => f(t, "name", { value: a, configurable: !0 });
import { __extends as u } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import y from "../DataZoomView/index.js";
import m from "../../helper/sliderMove/index.js";
import { setViewInfoToCoordSysRecord as S, disposeCoordSysRecordIfNeeded as M } from "../roams/index.js";
import { bind as g } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var Z = (
  /** @class */
  function(t) {
    u(a, t);
    function a() {
      var n = t !== null && t.apply(this, arguments) || this;
      return n.type = "dataZoom.inside", n;
    }
    return p(a, "InsideZoomView"), a.prototype.render = function(n, o, l) {
      if (t.prototype.render.apply(this, arguments), n.noTarget()) {
        this._clear();
        return;
      }
      this.range = n.getPercentRange(), S(l, n, {
        pan: g(c.pan, this),
        zoom: g(c.zoom, this),
        scrollMove: g(c.scrollMove, this)
      });
    }, a.prototype.dispose = function() {
      this._clear(), t.prototype.dispose.apply(this, arguments);
    }, a.prototype._clear = function() {
      M(this.api, this.dataZoomModel), this.range = null;
    }, a.type = "dataZoom.inside", a;
  }(y)
), c = {
  zoom: /* @__PURE__ */ p(function(t, a, n, o) {
    var l = this.range, r = l.slice(), e = t.axisModels[0];
    if (e) {
      var i = v[a](null, [o.originX, o.originY], e, n, t), s = (i.signal > 0 ? i.pixelStart + i.pixelLength - i.pixel : i.pixel - i.pixelStart) / i.pixelLength * (r[1] - r[0]) + r[0], x = Math.max(1 / o.scale, 0);
      r[0] = (r[0] - s) * x + s, r[1] = (r[1] - s) * x + s;
      var h = this.dataZoomModel.findRepresentativeAxisProxy().getMinMaxSpan();
      if (m(0, r, [0, 100], 0, h.minSpan, h.maxSpan), this.range = r, l[0] !== r[0] || l[1] !== r[1])
        return r;
    }
  }, "zoom"),
  pan: d(function(t, a, n, o, l, r) {
    var e = v[o]([r.oldX, r.oldY], [r.newX, r.newY], a, l, n);
    return e.signal * (t[1] - t[0]) * e.pixel / e.pixelLength;
  }),
  scrollMove: d(function(t, a, n, o, l, r) {
    var e = v[o]([0, 0], [r.scrollDelta, r.scrollDelta], a, l, n);
    return e.signal * (t[1] - t[0]) * r.scrollDelta;
  })
};
function d(t) {
  return function(a, n, o, l) {
    var r = this.range, e = r.slice(), i = a.axisModels[0];
    if (i) {
      var s = t(e, i, a, n, o, l);
      if (m(s, e, [0, 100], "all"), this.range = e, r[0] !== e[0] || r[1] !== e[1])
        return e;
    }
  };
}
p(d, "makeMover");
var v = {
  grid: /* @__PURE__ */ p(function(t, a, n, o, l) {
    var r = n.axis, e = {}, i = l.model.coordinateSystem.getRect();
    return t = t || [0, 0], r.dim === "x" ? (e.pixel = a[0] - t[0], e.pixelLength = i.width, e.pixelStart = i.x, e.signal = r.inverse ? 1 : -1) : (e.pixel = a[1] - t[1], e.pixelLength = i.height, e.pixelStart = i.y, e.signal = r.inverse ? -1 : 1), e;
  }, "grid"),
  polar: /* @__PURE__ */ p(function(t, a, n, o, l) {
    var r = n.axis, e = {}, i = l.model.coordinateSystem, s = i.getRadiusAxis().getExtent(), x = i.getAngleAxis().getExtent();
    return t = t ? i.pointToCoord(t) : [0, 0], a = i.pointToCoord(a), n.mainType === "radiusAxis" ? (e.pixel = a[0] - t[0], e.pixelLength = s[1] - s[0], e.pixelStart = s[0], e.signal = r.inverse ? 1 : -1) : (e.pixel = a[1] - t[1], e.pixelLength = x[1] - x[0], e.pixelStart = x[0], e.signal = r.inverse ? -1 : 1), e;
  }, "polar"),
  singleAxis: /* @__PURE__ */ p(function(t, a, n, o, l) {
    var r = n.axis, e = l.model.coordinateSystem.getRect(), i = {};
    return t = t || [0, 0], r.orient === "horizontal" ? (i.pixel = a[0] - t[0], i.pixelLength = e.width, i.pixelStart = e.x, i.signal = r.inverse ? 1 : -1) : (i.pixel = a[1] - t[1], i.pixelLength = e.height, i.pixelStart = e.y, i.signal = r.inverse ? -1 : 1), i;
  }, "singleAxis")
};
export {
  Z as default
};
