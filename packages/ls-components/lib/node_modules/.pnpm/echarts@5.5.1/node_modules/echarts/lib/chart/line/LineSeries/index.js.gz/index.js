var f = Object.defineProperty;
var m = (r, t) => f(r, "name", { value: t, configurable: !0 });
import { __extends as h } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import c from "../../helper/createSeriesData/index.js";
import p from "../../../model/Series/index.js";
import { createSymbol as y } from "../../../util/symbol/index.js";
import "../../../util/graphic/index.js";
import g from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
var R = (
  /** @class */
  function(r) {
    h(t, r);
    function t() {
      var e = r !== null && r.apply(this, arguments) || this;
      return e.type = t.type, e.hasSymbolVisual = !0, e;
    }
    return m(t, "LineSeriesModel"), t.prototype.getInitialData = function(e) {
      if (process.env.NODE_ENV !== "production") {
        var l = e.coordinateSystem;
        if (l !== "polar" && l !== "cartesian2d")
          throw new Error("Line not support coordinateSystem besides cartesian and polar");
      }
      return c(null, this, {
        useEncodeDefaulter: !0
      });
    }, t.prototype.getLegendIcon = function(e) {
      var l = new g(), a = y("line", 0, e.itemHeight / 2, e.itemWidth, 0, e.lineStyle.stroke, !1);
      l.add(a), a.setStyle(e.lineStyle);
      var o = this.getData().getVisual("symbol"), d = this.getData().getVisual("symbolRotate"), s = o === "none" ? "circle" : o, n = e.itemHeight * 0.8, i = y(s, (e.itemWidth - n) / 2, (e.itemHeight - n) / 2, n, n, e.itemStyle.fill);
      l.add(i), i.setStyle(e.itemStyle);
      var u = e.iconRotate === "inherit" ? d : e.iconRotate || 0;
      return i.rotation = u * Math.PI / 180, i.setOrigin([e.itemWidth / 2, e.itemHeight / 2]), s.indexOf("empty") > -1 && (i.style.stroke = i.style.fill, i.style.fill = "#fff", i.style.lineWidth = 2), l;
    }, t.type = "series.line", t.dependencies = ["grid", "polar"], t.defaultOption = {
      // zlevel: 0,
      z: 3,
      coordinateSystem: "cartesian2d",
      legendHoverLink: !0,
      clip: !0,
      label: {
        position: "top"
      },
      // itemStyle: {
      // },
      endLabel: {
        show: !1,
        valueAnimation: !0,
        distance: 8
      },
      lineStyle: {
        width: 2,
        type: "solid"
      },
      emphasis: {
        scale: !0
      },
      // areaStyle: {
      // origin of areaStyle. Valid values:
      // `'auto'/null/undefined`: from axisLine to data
      // `'start'`: from min to data
      // `'end'`: from data to max
      // origin: 'auto'
      // },
      // false, 'start', 'end', 'middle'
      step: !1,
      // Disabled if step is true
      smooth: !1,
      smoothMonotone: null,
      symbol: "emptyCircle",
      symbolSize: 4,
      symbolRotate: null,
      showSymbol: !0,
      // `false`: follow the label interval strategy.
      // `true`: show all symbols.
      // `'auto'`: If possible, show all symbols, otherwise
      //           follow the label interval strategy.
      showAllSymbol: "auto",
      // Whether to connect break point.
      connectNulls: !1,
      // Sampling for large data. Can be: 'average', 'max', 'min', 'sum', 'lttb'.
      sampling: "none",
      animationEasing: "linear",
      // Disable progressive
      progressive: 0,
      hoverLayerThreshold: 1 / 0,
      universalTransition: {
        divideShape: "clone"
      },
      triggerLineEvent: !1
    }, t;
  }(p)
);
export {
  R as default
};
