var I = Object.defineProperty;
var c = (a, l) => I(a, "name", { value: l, configurable: !0 });
import { extend as O, keys as V, isFunction as R } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var b = ["symbol", "symbolSize", "symbolRotate", "symbolOffset"], g = b.concat(["symbolKeepAspect"]), k = {
  createOnAllSeries: !0,
  // For legend.
  performRawSeries: !0,
  reset: /* @__PURE__ */ c(function(a, l) {
    var f = a.getData();
    if (a.legendIcon && f.setVisual("legendIcon", a.legendIcon), !a.hasSymbolVisual)
      return;
    for (var t = {}, r = {}, u = !1, s = 0; s < b.length; s++) {
      var e = b[s], n = a.get(e);
      R(n) ? (u = !0, r[e] = n) : t[e] = n;
    }
    if (t.symbol = t.symbol || a.defaultSymbol, f.setVisual(O({
      legendIcon: a.legendIcon || t.symbol,
      symbolKeepAspect: a.get("symbolKeepAspect")
    }, t)), l.isSeriesFiltered(a))
      return;
    var o = V(r);
    function i(y, m) {
      for (var h = a.getRawValue(m), p = a.getDataParams(m), v = 0; v < o.length; v++) {
        var S = o[v];
        y.setItemVisual(m, S, r[S](h, p));
      }
    }
    return c(i, "dataEach"), {
      dataEach: u ? i : null
    };
  }, "reset")
}, C = {
  createOnAllSeries: !0,
  // For legend.
  performRawSeries: !0,
  reset: /* @__PURE__ */ c(function(a, l) {
    if (!a.hasSymbolVisual || l.isSeriesFiltered(a))
      return;
    var f = a.getData();
    function t(r, u) {
      for (var s = r.getItemModel(u), e = 0; e < g.length; e++) {
        var n = g[e], o = s.getShallow(n, !0);
        o != null && r.setItemVisual(u, n, o);
      }
    }
    return c(t, "dataEach"), {
      dataEach: f.hasItemOption ? t : null
    };
  }, "reset")
};
export {
  C as dataSymbolTask,
  k as seriesSymbolTask
};
