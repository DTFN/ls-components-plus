var O = Object.defineProperty;
var o = (r, n) => O(r, "name", { value: n, configurable: !0 });
import { makeInner as Y, normalizeToArray as _ } from "../../util/model/index.js";
import { keys as N, reduce as G, each as U, extend as y, hasOwn as S, indexOf as M, isArrayLike as X, bind as j, assert as V, eqNaN as q } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { cloneValue as z } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/animation/Animator/index.js";
import H from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Displayable/index.js";
import { getAnimationConfig as J } from "../basicTransition/index.js";
import "../../util/graphic/index.js";
import { warn as w } from "../../util/log/index.js";
import { TRANSFORMABLE_PROPS as T } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/Transformable/index.js";
import Q from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
var B = {
  position: ["x", "y"],
  scale: ["scaleX", "scaleY"],
  origin: ["originX", "originY"]
}, I = N(B), A = G(T, function(r, n) {
  return r[n] = 1, r;
}, {}), b = T.join(", "), R = ["", "style", "shape", "extra"], D = Y();
function P(r, n, a, t, s) {
  var e = r + "Animation", i = J(r, t, s) || {}, v = D(n).userDuring;
  return i.duration > 0 && (i.during = v ? j(rr, {
    el: n,
    userDuring: v
  }) : null, i.setToFinal = !0, i.scope = r), y(i, a[e]), i;
}
o(P, "getElementAnimationConfig");
function gr(r, n, a, t) {
  t = t || {};
  var s = t.dataIndex, e = t.isInit, i = t.clearStyle, v = a.isAnimationEnabled(), g = D(r), c = n.style;
  g.userDuring = n.during;
  var f = {}, u = {};
  if (tr(r, n, u), F("shape", n, u), F("extra", n, u), !e && v && (nr(r, n, f), L("shape", r, n, f), L("extra", r, n, f), ar(r, n, c, f)), u.style = c, Z(r, u, i), K(r, n), v)
    if (e) {
      var l = {};
      U(R, function(d) {
        var x = d ? n[d] : n;
        x && x.enterFrom && (d && (l[d] = l[d] || {}), y(d ? l[d] : l, x.enterFrom));
      });
      var E = P("enter", r, n, a, s);
      E.duration > 0 && r.animateFrom(l, E);
    } else
      $(r, n, s || 0, a, f);
  W(r, n), c ? r.dirty() : r.markRedraw();
}
o(gr, "applyUpdateTransition");
function W(r, n) {
  for (var a = D(r).leaveToProps, t = 0; t < R.length; t++) {
    var s = R[t], e = s ? n[s] : n;
    e && e.leaveTo && (a || (a = D(r).leaveToProps = {}), s && (a[s] = a[s] || {}), y(s ? a[s] : a, e.leaveTo));
  }
}
o(W, "updateLeaveTo");
function Er(r, n, a, t) {
  if (r) {
    var s = r.parent, e = D(r).leaveToProps;
    if (e) {
      var i = P("update", r, n, a, 0);
      i.done = function() {
        s.remove(r);
      }, r.animateTo(e, i);
    } else
      s.remove(r);
  }
}
o(Er, "applyLeaveTransition");
function m(r) {
  return r === "all";
}
o(m, "isTransitionAll");
function Z(r, n, a) {
  var t = n.style;
  if (!r.isGroup && t) {
    if (a) {
      r.useStyle({});
      for (var s = r.animators, e = 0; e < s.length; e++) {
        var i = s[e];
        i.targetName === "style" && i.changeTarget(r.style);
      }
    }
    r.setStyle(t);
  }
  n && (n.style = null, n && r.attr(n), n.style = t);
}
o(Z, "applyPropsDirectly");
function $(r, n, a, t, s) {
  if (s) {
    var e = P("update", r, n, t, a);
    e.duration > 0 && r.animateFrom(s, e);
  }
}
o($, "applyPropsTransition");
function K(r, n) {
  S(n, "silent") && (r.silent = n.silent), S(n, "ignore") && (r.ignore = n.ignore), r instanceof H && S(n, "invisible") && (r.invisible = n.invisible), r instanceof Q && S(n, "autoBatch") && (r.autoBatch = n.autoBatch);
}
o(K, "applyMiscProps");
var h = {}, k = {
  // Usually other props do not need to be changed in animation during.
  setTransform: /* @__PURE__ */ o(function(r, n) {
    return process.env.NODE_ENV !== "production" && V(S(A, r), "Only " + b + " available in `setTransform`."), h.el[r] = n, this;
  }, "setTransform"),
  getTransform: /* @__PURE__ */ o(function(r) {
    return process.env.NODE_ENV !== "production" && V(S(A, r), "Only " + b + " available in `getTransform`."), h.el[r];
  }, "getTransform"),
  setShape: /* @__PURE__ */ o(function(r, n) {
    process.env.NODE_ENV !== "production" && p(r);
    var a = h.el, t = a.shape || (a.shape = {});
    return t[r] = n, a.dirtyShape && a.dirtyShape(), this;
  }, "setShape"),
  getShape: /* @__PURE__ */ o(function(r) {
    process.env.NODE_ENV !== "production" && p(r);
    var n = h.el.shape;
    if (n)
      return n[r];
  }, "getShape"),
  setStyle: /* @__PURE__ */ o(function(r, n) {
    process.env.NODE_ENV !== "production" && p(r);
    var a = h.el, t = a.style;
    return t && (process.env.NODE_ENV !== "production" && q(n) && w("style." + r + " must not be assigned with NaN."), t[r] = n, a.dirtyStyle && a.dirtyStyle()), this;
  }, "setStyle"),
  getStyle: /* @__PURE__ */ o(function(r) {
    process.env.NODE_ENV !== "production" && p(r);
    var n = h.el.style;
    if (n)
      return n[r];
  }, "getStyle"),
  setExtra: /* @__PURE__ */ o(function(r, n) {
    process.env.NODE_ENV !== "production" && p(r);
    var a = h.el.extra || (h.el.extra = {});
    return a[r] = n, this;
  }, "setExtra"),
  getExtra: /* @__PURE__ */ o(function(r) {
    process.env.NODE_ENV !== "production" && p(r);
    var n = h.el.extra;
    if (n)
      return n[r];
  }, "getExtra")
};
function p(r) {
  if (process.env.NODE_ENV !== "production" && (r === "transition" || r === "enterFrom" || r === "leaveTo"))
    throw new Error('key must not be "' + r + '"');
}
o(p, "assertNotReserved");
function rr() {
  var r = this, n = r.el;
  if (n) {
    var a = D(n).userDuring, t = r.userDuring;
    if (a !== t) {
      r.el = r.userDuring = null;
      return;
    }
    h.el = n, t(k);
  }
}
o(rr, "duringCall");
function L(r, n, a, t) {
  var s = a[r];
  if (s) {
    var e = n[r], i;
    if (e) {
      var v = a.transition, g = s.transition;
      if (g)
        if (!i && (i = t[r] = {}), m(g))
          y(i, e);
        else
          for (var c = _(g), f = 0; f < c.length; f++) {
            var u = c[f], l = e[u];
            i[u] = l;
          }
      else if (m(v) || M(v, r) >= 0) {
        !i && (i = t[r] = {});
        for (var E = N(e), f = 0; f < E.length; f++) {
          var u = E[f], l = e[u];
          ir(s[u], l) && (i[u] = l);
        }
      }
    }
  }
}
o(L, "prepareShapeOrExtraTransitionFrom");
function F(r, n, a) {
  var t = n[r];
  if (t)
    for (var s = a[r] = {}, e = N(t), i = 0; i < e.length; i++) {
      var v = e[i];
      s[v] = z(t[v]);
    }
}
o(F, "prepareShapeOrExtraAllPropsFinal");
function nr(r, n, a) {
  for (var t = n.transition, s = m(t) ? T : _(t || []), e = 0; e < s.length; e++) {
    var i = s[e];
    if (!(i === "style" || i === "shape" || i === "extra")) {
      var v = r[i];
      process.env.NODE_ENV !== "production" && C(i, "el.transition"), a[i] = v;
    }
  }
}
o(nr, "prepareTransformTransitionFrom");
function tr(r, n, a) {
  for (var t = 0; t < I.length; t++) {
    var s = I[t], e = B[s], i = n[s];
    i && (a[e[0]] = i[0], a[e[1]] = i[1]);
  }
  for (var t = 0; t < T.length; t++) {
    var v = T[t];
    n[v] != null && (a[v] = n[v]);
  }
}
o(tr, "prepareTransformAllPropsFinal");
function ar(r, n, a, t) {
  if (a) {
    var s = r.style, e;
    if (s) {
      var i = a.transition, v = n.transition;
      if (i && !m(i)) {
        var g = _(i);
        !e && (e = t.style = {});
        for (var c = 0; c < g.length; c++) {
          var f = g[c], u = s[f];
          e[f] = u;
        }
      } else if (r.getAnimationStyleProps && (m(v) || m(i) || M(v, "style") >= 0)) {
        var l = r.getAnimationStyleProps(), E = l ? l.style : null;
        if (E) {
          !e && (e = t.style = {});
          for (var d = N(a), c = 0; c < d.length; c++) {
            var f = d[c];
            if (E[f]) {
              var u = s[f];
              e[f] = u;
            }
          }
        }
      }
    }
  }
}
o(ar, "prepareStyleTransitionFrom");
function ir(r, n) {
  return X(r) ? r !== n : r != null && isFinite(r);
}
o(ir, "isNonStyleTransitionEnabled");
var C;
process.env.NODE_ENV !== "production" && (C = /* @__PURE__ */ o(function(r, n) {
  S(A, r) || w("Prop `" + r + "` is not a permitted in `" + n + "`. Only `" + N(A).join("`, `") + "` are permitted.");
}, "checkTransformPropRefer"));
export {
  R as ELEMENT_ANIMATABLE_PROPS,
  Er as applyLeaveTransition,
  gr as applyUpdateTransition,
  m as isTransitionAll,
  W as updateLeaveTo
};
