var A = Object.defineProperty;
var l = (e, r) => A(e, "name", { value: r, configurable: !0 });
import { makeValueReadable as g, convertToColorString as D, getTooltipMarker as G } from "../../../util/format/index.js";
import { assert as _, isArray as T, hasOwn as O, each as x, extend as M, map as w, isString as U } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { SortOrderComparator as j } from "../../../data/helper/dataValueHelper/index.js";
import { getRandomIdBase as L } from "../../../util/number/index.js";
import { encodeHTML as v } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/dom/index.js";
var H = "line-height:1";
function V(e, r) {
  var t = e.color || "#6e7079", n = e.fontSize || 12, o = e.fontWeight || "400", a = e.color || "#464646", u = e.fontSize || 14, i = e.fontWeight || "900";
  return r === "html" ? {
    // eslint-disable-next-line max-len
    nameStyle: "font-size:" + v(n + "") + "px;color:" + v(t) + ";font-weight:" + v(o + ""),
    // eslint-disable-next-line max-len
    valueStyle: "font-size:" + v(u + "") + "px;color:" + v(a) + ";font-weight:" + v(i + "")
  } : {
    nameStyle: {
      fontSize: n,
      fill: t,
      fontWeight: o
    },
    valueStyle: {
      fontSize: u,
      fill: a,
      fontWeight: i
    }
  };
}
l(V, "getTooltipTextStyle");
var B = [0, 10, 20, 30], X = ["", `
`, `

`, `


`];
function oe(e, r) {
  return r.type = e, r;
}
l(oe, "createTooltipMarkup");
function F(e) {
  return e.type === "section";
}
l(F, "isSectionFragment");
function R(e) {
  return F(e) ? q : J;
}
l(R, "getBuilder");
function z(e) {
  if (F(e)) {
    var r = 0, t = e.blocks.length, n = t > 1 || t > 0 && !e.noHeader;
    return x(e.blocks, function(o) {
      var a = z(o);
      a >= r && (r = a + +(n && // 0 always can not be readable gap level.
      (!a || F(o) && !o.noHeader)));
    }), r;
  }
  return 0;
}
l(z, "getBlockGapLevel");
function q(e, r, t, n) {
  var o = r.noHeader, a = K(z(r)), u = [], i = r.blocks || [];
  _(!i || T(i)), i = i || [];
  var s = e.orderMode;
  if (r.sortBlocks && s) {
    i = i.slice();
    var h = {
      valueAsc: "asc",
      valueDesc: "desc"
    };
    if (O(h, s)) {
      var C = new j(h[s], null);
      i.sort(function(p, m) {
        return C.evaluate(p.sortParam, m.sortParam);
      });
    } else s === "seriesDesc" && i.reverse();
  }
  x(i, function(p, m) {
    var S = r.valueFormatter, y = R(p)(
      // Inherit valueFormatter
      S ? M(M({}, e), {
        valueFormatter: S
      }) : e,
      p,
      m > 0 ? a.html : 0,
      n
    );
    y != null && u.push(y);
  });
  var d = e.renderMode === "richText" ? u.join(a.richText) : b(u.join(""), o ? t : a.html);
  if (o)
    return d;
  var f = g(r.header, "ordinal", e.useUTC), c = V(n, e.renderMode).nameStyle;
  return e.renderMode === "richText" ? E(e, f, c) + a.richText + d : b('<div style="' + c + ";" + H + ';">' + v(f) + "</div>" + d, t);
}
l(q, "buildSection");
function J(e, r, t, n) {
  var o = e.renderMode, a = r.noName, u = r.noValue, i = !r.markerType, s = r.name, h = e.useUTC, C = r.valueFormatter || e.valueFormatter || function(k) {
    return k = T(k) ? k : [k], w(k, function(P, W) {
      return g(P, T(c) ? c[W] : c, h);
    });
  };
  if (!(a && u)) {
    var d = i ? "" : e.markupStyleCreator.makeTooltipMarker(r.markerType, r.markerColor || "#333", o), f = a ? "" : g(s, "ordinal", h), c = r.valueType, p = u ? [] : C(r.value, r.dataIndex), m = !i || !a, S = !i && a, y = V(n, o), I = y.nameStyle, N = y.valueStyle;
    return o === "richText" ? (i ? "" : d) + (a ? "" : E(e, f, I)) + (u ? "" : Z(e, p, m, S, N)) : b((i ? "" : d) + (a ? "" : Q(f, !i, I)) + (u ? "" : Y(p, m, S, N)), t);
  }
}
l(J, "buildNameValue");
function ie(e, r, t, n, o, a) {
  if (e) {
    var u = R(e), i = {
      useUTC: o,
      renderMode: t,
      orderMode: n,
      markupStyleCreator: r,
      valueFormatter: e.valueFormatter
    };
    return u(i, e, 0, a);
  }
}
l(ie, "buildTooltipMarkup");
function K(e) {
  return {
    html: B[e],
    richText: X[e]
  };
}
l(K, "getGap");
function b(e, r) {
  var t = '<div style="clear:both"></div>', n = "margin: " + r + "px 0 0";
  return '<div style="' + n + ";" + H + ';">' + e + t + "</div>";
}
l(b, "wrapBlockHTML");
function Q(e, r, t) {
  var n = r ? "margin-left:2px" : "";
  return '<span style="' + t + ";" + n + '">' + v(e) + "</span>";
}
l(Q, "wrapInlineNameHTML");
function Y(e, r, t, n) {
  var o = t ? "10px" : "20px", a = r ? "float:right;margin-left:" + o : "";
  return e = T(e) ? e : [e], '<span style="' + a + ";" + n + '">' + w(e, function(u) {
    return v(u);
  }).join("&nbsp;&nbsp;") + "</span>";
}
l(Y, "wrapInlineValueHTML");
function E(e, r, t) {
  return e.markupStyleCreator.wrapRichTextStyle(r, t);
}
l(E, "wrapInlineNameRichText");
function Z(e, r, t, n, o) {
  var a = [o], u = n ? 10 : 20;
  return t && a.push({
    padding: [0, 0, 0, u],
    align: "right"
  }), e.markupStyleCreator.wrapRichTextStyle(T(r) ? r.join("  ") : r, a);
}
l(Z, "wrapInlineValueRichText");
function le(e, r) {
  var t = e.getData().getItemVisual(r, "style"), n = t[e.visualDrawType];
  return D(n);
}
l(le, "retrieveVisualColorForTooltipMarker");
function ue(e, r) {
  var t = e.get("padding");
  return t ?? (r === "richText" ? [8, 10] : 10);
}
l(ue, "getPaddingFromTooltipModel");
var ve = (
  /** @class */
  function() {
    function e() {
      this.richTextStyles = {}, this._nextStyleNameId = L();
    }
    return l(e, "TooltipMarkupStyleCreator"), e.prototype._generateStyleName = function() {
      return "__EC_aUTo_" + this._nextStyleNameId++;
    }, e.prototype.makeTooltipMarker = function(r, t, n) {
      var o = n === "richText" ? this._generateStyleName() : null, a = G({
        color: t,
        type: r,
        renderMode: n,
        markerId: o
      });
      return U(a) ? a : (process.env.NODE_ENV !== "production" && _(o), this.richTextStyles[o] = a.style, a.content);
    }, e.prototype.wrapRichTextStyle = function(r, t) {
      var n = {};
      T(t) ? x(t, function(a) {
        return M(n, a);
      }) : M(n, t);
      var o = this._generateStyleName();
      return this.richTextStyles[o] = n, "{" + o + "|" + r + "}";
    }, e;
  }()
);
export {
  ve as TooltipMarkupStyleCreator,
  ie as buildTooltipMarkup,
  oe as createTooltipMarkup,
  ue as getPaddingFromTooltipModel,
  le as retrieveVisualColorForTooltipMarker
};
