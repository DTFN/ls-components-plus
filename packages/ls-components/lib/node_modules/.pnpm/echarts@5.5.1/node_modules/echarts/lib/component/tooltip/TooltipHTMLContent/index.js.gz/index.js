var N = Object.defineProperty;
var f = (e, t) => N(e, "name", { value: t, configurable: !0 });
import { isString as c, isDom as y, isFunction as R, isArray as D, each as w, bind as z, indexOf as L } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { normalizeEvent as k } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/event/index.js";
import { transformLocalCoord as F } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/dom/index.js";
import p from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/env/index.js";
import { convertToColorString as S, toCamelCase as W, normalizeCssArray as A } from "../../../util/format/index.js";
import { toCSSVendorPrefix as H, TRANSITION_VENDOR as E, TRANSFORM_VENDOR as O, getComputedStyle as I, shouldTooltipConfine as V } from "../helper/index.js";
import { getPaddingFromTooltipModel as B } from "../tooltipMarkup/index.js";
var X = H(E, "transition"), T = H(O, "transform"), Y = "position:absolute;display:block;border-style:solid;white-space:nowrap;z-index:9999999;" + (p.transform3dSupported ? "will-change:transform;" : "");
function j(e) {
  return e = e === "left" ? "right" : e === "right" ? "left" : e === "top" ? "bottom" : "top", e;
}
f(j, "mirrorPos");
function M(e, t, a) {
  if (!c(a) || a === "inside")
    return "";
  var r = e.get("backgroundColor"), i = e.get("borderWidth");
  t = S(t);
  var o = j(a), s = Math.max(Math.round(i) * 1.5, 6), n = "", h = T + ":", l;
  L(["left", "right"], o) > -1 ? (n += "top:50%", h += "translateY(-50%) rotate(" + (l = o === "left" ? -225 : -45) + "deg)") : (n += "left:50%", h += "translateX(-50%) rotate(" + (l = o === "top" ? 225 : 45) + "deg)");
  var d = l * Math.PI / 180, u = s + i, g = u * Math.abs(Math.cos(d)) + u * Math.abs(Math.sin(d)), m = Math.round(((g - Math.SQRT2 * i) / 2 + Math.SQRT2 * i - (g - u) / 2) * 100) / 100;
  n += ";" + o + ":-" + m + "px";
  var v = t + " solid " + i + "px;", _ = ["position:absolute;width:" + s + "px;height:" + s + "px;z-index:-1;", n + ";" + h + ";", "border-bottom:" + v, "border-right:" + v, "background-color:" + r + ";"];
  return '<div style="' + _.join("") + '"></div>';
}
f(M, "assembleArrow");
function P(e, t) {
  var a = "cubic-bezier(0.23,1,0.32,1)", r = " " + e / 2 + "s " + a, i = "opacity" + r + ",visibility" + r;
  return t || (r = " " + e + "s " + a, i += p.transformSupported ? "," + T + r : ",left" + r + ",top" + r), X + ":" + i;
}
f(P, "assembleTransition");
function b(e, t, a) {
  var r = e.toFixed(0) + "px", i = t.toFixed(0) + "px";
  if (!p.transformSupported)
    return a ? "top:" + i + ";left:" + r + ";" : [["top", i], ["left", r]];
  var o = p.transform3dSupported, s = "translate" + (o ? "3d" : "") + "(" + r + "," + i + (o ? ",0" : "") + ")";
  return a ? "top:0;left:0;" + T + ":" + s + ";" : [["top", 0], ["left", 0], [O, s]];
}
f(b, "assembleTransform");
function Q(e) {
  var t = [], a = e.get("fontSize"), r = e.getTextColor();
  r && t.push("color:" + r), t.push("font:" + e.getFont()), a && t.push("line-height:" + Math.round(a * 3 / 2) + "px");
  var i = e.get("textShadowColor"), o = e.get("textShadowBlur") || 0, s = e.get("textShadowOffsetX") || 0, n = e.get("textShadowOffsetY") || 0;
  return i && o && t.push("text-shadow:" + s + "px " + n + "px " + o + "px " + i), w(["decoration", "align"], function(h) {
    var l = e.get(h);
    l && t.push("text-" + h + ":" + l);
  }), t.join(";");
}
f(Q, "assembleFont");
function Z(e, t, a) {
  var r = [], i = e.get("transitionDuration"), o = e.get("backgroundColor"), s = e.get("shadowBlur"), n = e.get("shadowColor"), h = e.get("shadowOffsetX"), l = e.get("shadowOffsetY"), d = e.getModel("textStyle"), u = B(e, "html"), g = h + "px " + l + "px " + s + "px " + n;
  return r.push("box-shadow:" + g), t && i && r.push(P(i, a)), o && r.push("background-color:" + o), w(["width", "color", "radius"], function(m) {
    var v = "border-" + m, _ = W(v), C = e.get(_);
    C != null && r.push(v + ":" + C + (m === "color" ? "" : "px"));
  }), r.push(Q(d)), u != null && r.push("padding:" + A(u).join("px ") + "px"), r.join(";") + ";";
}
f(Z, "assembleCssText");
function x(e, t, a, r, i) {
  var o = t && t.painter;
  if (a) {
    var s = o && o.getViewportRoot();
    s && F(e, s, a, r, i);
  } else {
    e[0] = r, e[1] = i;
    var n = o && o.getViewportRootOffset();
    n && (e[0] += n.offsetLeft, e[1] += n.offsetTop);
  }
  e[2] = e[0] / t.getWidth(), e[3] = e[1] / t.getHeight();
}
f(x, "makeStyleCoord");
var rt = (
  /** @class */
  function() {
    function e(t, a) {
      if (this._show = !1, this._styleCoord = [0, 0, 0, 0], this._enterable = !0, this._alwaysShowContent = !1, this._firstShow = !0, this._longHide = !0, p.wxa)
        return null;
      var r = document.createElement("div");
      r.domBelongToZr = !0, this.el = r;
      var i = this._zr = t.getZr(), o = a.appendTo, s = o && (c(o) ? document.querySelector(o) : y(o) ? o : R(o) && o(t.getDom()));
      x(this._styleCoord, i, s, t.getWidth() / 2, t.getHeight() / 2), (s || t.getDom()).appendChild(r), this._api = t, this._container = s;
      var n = this;
      r.onmouseenter = function() {
        n._enterable && (clearTimeout(n._hideTimeout), n._show = !0), n._inContent = !0;
      }, r.onmousemove = function(h) {
        if (h = h || window.event, !n._enterable) {
          var l = i.handler, d = i.painter.getViewportRoot();
          k(d, h, !0), l.dispatch("mousemove", h);
        }
      }, r.onmouseleave = function() {
        n._inContent = !1, n._enterable && n._show && n.hideLater(n._hideDelay);
      };
    }
    return f(e, "TooltipHTMLContent"), e.prototype.update = function(t) {
      if (!this._container) {
        var a = this._api.getDom(), r = I(a, "position"), i = a.style;
        i.position !== "absolute" && r !== "absolute" && (i.position = "relative");
      }
      var o = t.get("alwaysShowContent");
      o && this._moveIfResized(), this._alwaysShowContent = o, this.el.className = t.get("className") || "";
    }, e.prototype.show = function(t, a) {
      clearTimeout(this._hideTimeout), clearTimeout(this._longHideTimeout);
      var r = this.el, i = r.style, o = this._styleCoord;
      r.innerHTML ? i.cssText = Y + Z(t, !this._firstShow, this._longHide) + b(o[0], o[1], !0) + ("border-color:" + S(a) + ";") + (t.get("extraCssText") || "") + (";pointer-events:" + (this._enterable ? "auto" : "none")) : i.display = "none", this._show = !0, this._firstShow = !1, this._longHide = !1;
    }, e.prototype.setContent = function(t, a, r, i, o) {
      var s = this.el;
      if (t == null) {
        s.innerHTML = "";
        return;
      }
      var n = "";
      if (c(o) && r.get("trigger") === "item" && !V(r) && (n = M(r, i, o)), c(t))
        s.innerHTML = t + n;
      else if (t) {
        s.innerHTML = "", D(t) || (t = [t]);
        for (var h = 0; h < t.length; h++)
          y(t[h]) && t[h].parentNode !== s && s.appendChild(t[h]);
        if (n && s.childNodes.length) {
          var l = document.createElement("div");
          l.innerHTML = n, s.appendChild(l);
        }
      }
    }, e.prototype.setEnterable = function(t) {
      this._enterable = t;
    }, e.prototype.getSize = function() {
      var t = this.el;
      return [t.offsetWidth, t.offsetHeight];
    }, e.prototype.moveTo = function(t, a) {
      var r = this._styleCoord;
      if (x(r, this._zr, this._container, t, a), r[0] != null && r[1] != null) {
        var i = this.el.style, o = b(r[0], r[1]);
        w(o, function(s) {
          i[s[0]] = s[1];
        });
      }
    }, e.prototype._moveIfResized = function() {
      var t = this._styleCoord[2], a = this._styleCoord[3];
      this.moveTo(t * this._zr.getWidth(), a * this._zr.getHeight());
    }, e.prototype.hide = function() {
      var t = this, a = this.el.style;
      a.visibility = "hidden", a.opacity = "0", p.transform3dSupported && (a.willChange = ""), this._show = !1, this._longHideTimeout = setTimeout(function() {
        return t._longHide = !0;
      }, 500);
    }, e.prototype.hideLater = function(t) {
      this._show && !(this._inContent && this._enterable) && !this._alwaysShowContent && (t ? (this._hideDelay = t, this._show = !1, this._hideTimeout = setTimeout(z(this.hide, this), t)) : this.hide());
    }, e.prototype.isShow = function() {
      return this._show;
    }, e.prototype.dispose = function() {
      clearTimeout(this._hideTimeout), clearTimeout(this._longHideTimeout);
      var t = this.el.parentNode;
      t && t.removeChild(this.el), this.el = this._container = null;
    }, e;
  }()
);
export {
  rt as default
};
