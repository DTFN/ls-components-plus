var P = Object.defineProperty;
var v = (o, l) => P(o, "name", { value: l, configurable: !0 });
import { isArray as T, map as h } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { queryDataIndex as S } from "../../../util/model/index.js";
function q(o, l) {
  var n = [], m = o.seriesIndex, r;
  if (m == null || !(r = l.getSeriesByIndex(m)))
    return {
      point: []
    };
  var e = r.getData(), i = S(e, o);
  if (i == null || i < 0 || T(i))
    return {
      point: []
    };
  var s = e.getItemGraphicEl(i), t = r.coordinateSystem;
  if (r.getTooltipPosition)
    n = r.getTooltipPosition(i) || [];
  else if (t && t.dataToPoint)
    if (o.isStacked) {
      var p = t.getBaseAxis(), f = t.getOtherAxis(p), g = f.dim, x = p.dim, u = g === "x" || g === "radius" ? 1 : 0, y = e.mapDimension(x), d = [];
      d[u] = e.get(y, i), d[1 - u] = e.get(e.getCalculationInfo("stackResultDimension"), i), n = t.dataToPoint(d) || [];
    } else
      n = t.dataToPoint(e.getValues(h(t.dimensions, function(I) {
        return e.mapDimension(I);
      }), i)) || [];
  else if (s) {
    var a = s.getBoundingRect().clone();
    a.applyTransform(s.transform), n = [a.x + a.width / 2, a.y + a.height / 2];
  }
  return {
    point: n,
    el: s
  };
}
v(q, "findPointFromSeries");
export {
  q as default
};
