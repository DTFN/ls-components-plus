var l = Object.defineProperty;
var n = (i, r) => l(i, "name", { value: r, configurable: !0 });
import { __extends as f } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import h from "../../Axis/index.js";
var x = (
  /** @class */
  function(i) {
    f(r, i);
    function r(o, t, s, a, p) {
      var e = i.call(this, o, t, s) || this;
      return e.index = 0, e.type = a || "value", e.position = p || "bottom", e;
    }
    return n(r, "Axis2D"), r.prototype.isHorizontal = function() {
      var o = this.position;
      return o === "top" || o === "bottom";
    }, r.prototype.getGlobalExtent = function(o) {
      var t = this.getExtent();
      return t[0] = this.toGlobalCoord(t[0]), t[1] = this.toGlobalCoord(t[1]), o && t[0] > t[1] && t.reverse(), t;
    }, r.prototype.pointToData = function(o, t) {
      return this.coordToData(this.toLocalCoord(o[this.dim === "x" ? 0 : 1]), t);
    }, r.prototype.setCategorySortInfo = function(o) {
      if (this.type !== "category")
        return !1;
      this.model.option.categorySortInfo = o, this.scale.setSortInfo(o);
    }, r;
  }(h)
);
export {
  x as default
};
