var G = Object.defineProperty;
var d = (i, e) => G(i, "name", { value: e, configurable: !0 });
import { __extends as m } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { extend as B, each as A, isArray as _, defaults as R } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { groupTransition as T, subPixelOptimizeLine as S } from "../../../util/graphic/index.js";
import z from "../AxisBuilder/index.js";
import H from "../AxisView/index.js";
import { layout as b } from "../../../coord/cartesian/cartesianAxisHelper/index.js";
import { rectCoordAxisHandleRemove as O, rectCoordAxisBuildSplitArea as I } from "../axisSplitHelper/index.js";
import { isIntervalOrLogScale as P } from "../../../scale/helper/index.js";
import k from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import w from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Line/index.js";
var M = ["axisLine", "axisTickLabel", "axisName"], W = ["splitArea", "splitLine", "minorSplitLine"], L = (
  /** @class */
  function(i) {
    m(e, i);
    function e() {
      var t = i !== null && i.apply(this, arguments) || this;
      return t.type = e.type, t.axisPointerClass = "CartesianAxisPointer", t;
    }
    return d(e, "CartesianAxisView"), e.prototype.render = function(t, x, l, h) {
      this.group.removeAll();
      var f = this._axisGroup;
      if (this._axisGroup = new k(), this.group.add(this._axisGroup), !!t.get("show")) {
        var r = t.getCoordSysModel(), u = b(r, t), s = new z(t, B({
          handleAutoShown: /* @__PURE__ */ d(function(n) {
            for (var o = r.coordinateSystem.getCartesians(), a = 0; a < o.length; a++)
              if (P(o[a].getOtherAxis(t.axis).scale))
                return !0;
            return !1;
          }, "handleAutoShown")
        }, u));
        A(M, s.add, s), this._axisGroup.add(s.getGroup()), A(W, function(n) {
          t.get([n, "show"]) && X[n](this, this._axisGroup, t, r);
        }, this);
        var p = h && h.type === "changeAxisOrder" && h.isInitSort;
        p || T(f, this._axisGroup, t), i.prototype.render.call(this, t, x, l, h);
      }
    }, e.prototype.remove = function() {
      O(this);
    }, e.type = "cartesianAxis", e;
  }(H)
), X = {
  splitLine: /* @__PURE__ */ d(function(i, e, t, x) {
    var l = t.axis;
    if (!l.scale.isBlank()) {
      var h = t.getModel("splitLine"), f = h.getModel("lineStyle"), r = f.get("color");
      r = _(r) ? r : [r];
      for (var u = x.coordinateSystem.getRect(), s = l.isHorizontal(), p = 0, n = l.getTicksCoords({
        tickModel: h
      }), o = [], a = [], y = f.getLineStyle(), v = 0; v < n.length; v++) {
        var c = l.toGlobalCoord(n[v].coord);
        s ? (o[0] = c, o[1] = u.y, a[0] = c, a[1] = u.y + u.height) : (o[0] = u.x, o[1] = c, a[0] = u.x + u.width, a[1] = c);
        var C = p++ % r.length, V = n[v].tickValue, g = new w({
          anid: V != null ? "line_" + n[v].tickValue : null,
          autoBatch: !0,
          shape: {
            x1: o[0],
            y1: o[1],
            x2: a[0],
            y2: a[1]
          },
          style: R({
            stroke: r[C]
          }, y),
          silent: !0
        });
        S(g.shape, y.lineWidth), e.add(g);
      }
    }
  }, "splitLine"),
  minorSplitLine: /* @__PURE__ */ d(function(i, e, t, x) {
    var l = t.axis, h = t.getModel("minorSplitLine"), f = h.getModel("lineStyle"), r = x.coordinateSystem.getRect(), u = l.isHorizontal(), s = l.getMinorTicksCoords();
    if (s.length)
      for (var p = [], n = [], o = f.getLineStyle(), a = 0; a < s.length; a++)
        for (var y = 0; y < s[a].length; y++) {
          var v = l.toGlobalCoord(s[a][y].coord);
          u ? (p[0] = v, p[1] = r.y, n[0] = v, n[1] = r.y + r.height) : (p[0] = r.x, p[1] = v, n[0] = r.x + r.width, n[1] = v);
          var c = new w({
            anid: "minor_line_" + s[a][y].tickValue,
            autoBatch: !0,
            shape: {
              x1: p[0],
              y1: p[1],
              x2: n[0],
              y2: n[1]
            },
            style: o,
            silent: !0
          });
          S(c.shape, o.lineWidth), e.add(c);
        }
  }, "minorSplitLine"),
  splitArea: /* @__PURE__ */ d(function(i, e, t, x) {
    I(i, e, t, x);
  }, "splitArea")
}, Y = (
  /** @class */
  function(i) {
    m(e, i);
    function e() {
      var t = i !== null && i.apply(this, arguments) || this;
      return t.type = e.type, t;
    }
    return d(e, "CartesianXAxisView"), e.type = "xAxis", e;
  }(L)
), Z = (
  /** @class */
  function(i) {
    m(e, i);
    function e() {
      var t = i !== null && i.apply(this, arguments) || this;
      return t.type = Y.type, t;
    }
    return d(e, "CartesianYAxisView"), e.type = "yAxis", e;
  }(L)
);
export {
  Y as CartesianXAxisView,
  Z as CartesianYAxisView,
  L as default
};
