var p = Object.defineProperty;
var o = (n, r) => p(n, "name", { value: r, configurable: !0 });
import { map as E, isString as N, eqNaN as g, isFunction as l, isRegExp as y } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var h = "[ECharts] ", a = {}, w = typeof console < "u" && console.warn && console.log;
function i(n, r, t) {
  if (w) {
    if (t) {
      if (a[r])
        return;
      a[r] = !0;
    }
    console[n](h + r);
  }
}
o(i, "outputLog");
function I(n, r) {
  i("log", n, r);
}
o(I, "log");
function S(n, r) {
  i("warn", n, r);
}
o(S, "warn");
function R(n, r) {
  i("error", n, r);
}
o(R, "error");
function D(n) {
  process.env.NODE_ENV !== "production" && i("warn", "DEPRECATED: " + n, !0);
}
o(D, "deprecateLog");
function v(n, r, t) {
  process.env.NODE_ENV !== "production" && D((t ? "[" + t + "]" : "") + (n + " is deprecated, use " + r + " instead."));
}
o(v, "deprecateReplaceLog");
function C() {
  for (var n = [], r = 0; r < arguments.length; r++)
    n[r] = arguments[r];
  var t = "";
  if (process.env.NODE_ENV !== "production") {
    var u = /* @__PURE__ */ o(function(e) {
      return e === void 0 ? "undefined" : e === 1 / 0 ? "Infinity" : e === -1 / 0 ? "-Infinity" : g(e) ? "NaN" : e instanceof Date ? "Date(" + e.toISOString() + ")" : l(e) ? "function () { ... }" : y(e) ? e + "" : null;
    }, "makePrintableStringIfPossible_1");
    t = E(n, function(e) {
      if (N(e))
        return e;
      var f = u(e);
      if (f != null)
        return f;
      if (typeof JSON < "u" && JSON.stringify)
        try {
          return JSON.stringify(e, function(d, c) {
            var s = u(c);
            return s ?? c;
          });
        } catch {
          return "?";
        }
      else
        return "?";
    }).join(" ");
  }
  return t;
}
o(C, "makePrintable");
function L(n) {
  throw new Error(n);
}
o(L, "throwError");
export {
  D as deprecateLog,
  v as deprecateReplaceLog,
  R as error,
  I as log,
  C as makePrintable,
  L as throwError,
  S as warn
};
