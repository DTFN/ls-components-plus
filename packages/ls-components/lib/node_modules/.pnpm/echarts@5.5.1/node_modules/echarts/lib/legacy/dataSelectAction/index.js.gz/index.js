var a = Object.defineProperty;
var s = (n, c) => a(n, "name", { value: c, configurable: !0 });
import { each as h, extend as p, isArray as S, isString as y } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { deprecateReplaceLog as E, deprecateLog as N } from "../../util/log/index.js";
import { queryDataIndex as x } from "../../util/model/index.js";
function b(n, c) {
  function r(e, t) {
    var i = [];
    return e.eachComponent({
      mainType: "series",
      subType: n,
      query: t
    }, function(o) {
      i.push(o.seriesIndex);
    }), i;
  }
  s(r, "getSeriesIndices"), h([[n + "ToggleSelect", "toggleSelect"], [n + "Select", "select"], [n + "UnSelect", "unselect"]], function(e) {
    c(e[0], function(t, i, o) {
      t = p({}, t), process.env.NODE_ENV !== "production" && E(t.type, e[1]), o.dispatchAction(p(t, {
        type: e[1],
        seriesIndex: r(i, t)
      }));
    });
  });
}
s(b, "createLegacyDataSelectAction");
function l(n, c, r, e, t) {
  var i = n + c;
  r.isSilent(i) || (process.env.NODE_ENV !== "production" && N("event " + i + " is deprecated."), e.eachComponent({
    mainType: "series",
    subType: "pie"
  }, function(o) {
    for (var v = o.seriesIndex, f = o.option.selectedMap, m = t.selected, g = 0; g < m.length; g++)
      if (m[g].seriesIndex === v) {
        var d = o.getData(), u = x(d, t.fromActionPayload);
        r.trigger(i, {
          type: i,
          seriesId: o.id,
          name: S(u) ? d.getName(u[0]) : d.getName(u),
          selected: y(f) ? f : p({}, f)
        });
      }
  }));
}
s(l, "handleSeriesLegacySelectEvents");
function q(n, c, r) {
  n.on("selectchanged", function(e) {
    var t = r.getModel();
    e.isFromClick ? (l("map", "selectchanged", c, t, e), l("pie", "selectchanged", c, t, e)) : e.fromAction === "select" ? (l("map", "selected", c, t, e), l("pie", "selected", c, t, e)) : e.fromAction === "unselect" && (l("map", "unselected", c, t, e), l("pie", "unselected", c, t, e));
  });
}
s(q, "handleLegacySelectEvents");
export {
  b as createLegacyDataSelectAction,
  q as handleLegacySelectEvents
};
