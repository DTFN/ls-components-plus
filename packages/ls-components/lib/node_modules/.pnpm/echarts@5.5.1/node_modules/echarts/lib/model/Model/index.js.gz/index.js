var a = Object.defineProperty;
var s = (e, t) => a(e, "name", { value: t, configurable: !0 });
import u from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/env/index.js";
import { enableClassExtend as f, enableClassCheck as h } from "../../util/clazz/index.js";
import { AreaStyleMixin as c } from "../mixin/areaStyle/index.js";
import m from "../mixin/textStyle/index.js";
import { LineStyleMixin as d } from "../mixin/lineStyle/index.js";
import { ItemStyleMixin as y } from "../mixin/itemStyle/index.js";
import { merge as M, clone as v, mixin as p } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var r = (
  /** @class */
  function() {
    function e(t, n, o) {
      this.parentModel = n, this.ecModel = o, this.option = t;
    }
    return s(e, "Model"), e.prototype.init = function(t, n, o) {
    }, e.prototype.mergeOption = function(t, n) {
      M(this.option, t, !0);
    }, e.prototype.get = function(t, n) {
      return t == null ? this.option : this._doGet(this.parsePath(t), !n && this.parentModel);
    }, e.prototype.getShallow = function(t, n) {
      var o = this.option, i = o == null ? o : o[t];
      if (i == null && !n) {
        var l = this.parentModel;
        l && (i = l.getShallow(t));
      }
      return i;
    }, e.prototype.getModel = function(t, n) {
      var o = t != null, i = o ? this.parsePath(t) : null, l = o ? this._doGet(i) : this.option;
      return n = n || this.parentModel && this.parentModel.getModel(this.resolveParentPath(i)), new e(l, n, this.ecModel);
    }, e.prototype.isEmpty = function() {
      return this.option == null;
    }, e.prototype.restoreData = function() {
    }, e.prototype.clone = function() {
      var t = this.constructor;
      return new t(v(this.option));
    }, e.prototype.parsePath = function(t) {
      return typeof t == "string" ? t.split(".") : t;
    }, e.prototype.resolveParentPath = function(t) {
      return t;
    }, e.prototype.isAnimationEnabled = function() {
      if (!u.node && this.option) {
        if (this.option.animation != null)
          return !!this.option.animation;
        if (this.parentModel)
          return this.parentModel.isAnimationEnabled();
      }
    }, e.prototype._doGet = function(t, n) {
      var o = this.option;
      if (!t)
        return o;
      for (var i = 0; i < t.length && !(t[i] && (o = o && typeof o == "object" ? o[t[i]] : null, o == null)); i++)
        ;
      return o == null && n && (o = n._doGet(this.resolveParentPath(t), n.parentModel)), o;
    }, e;
  }()
);
f(r);
h(r);
p(r, d);
p(r, y);
p(r, c);
p(r, m);
export {
  r as default
};
