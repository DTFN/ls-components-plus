var P = Object.defineProperty;
var m = (n, t) => P(n, "name", { value: t, configurable: !0 });
import { isString as G, assert as H, createHashMap as z, each as d, isNumber as B, isArrayLike as U, extend as v, isArray as M, bind as y, keys as j, isFunction as S, slice as X, clone as Y, isObject as $, map as q } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import W from "../../model/Model/index.js";
import J from "../DataDiffer/index.js";
import { DefaultDataProvider as K } from "../helper/dataProvider/index.js";
import { summarizeDimensions as Q } from "../helper/dimensionHelper/index.js";
import w from "../SeriesDimensionDefine/index.js";
import { SOURCE_FORMAT_TYPED_ARRAY as Z, SOURCE_FORMAT_ORIGINAL as k } from "../../util/types/index.js";
import { isDataItemOption as b, convertOptionIdName as E } from "../../util/model/index.js";
import { setCommonECData as tt } from "../../util/innerStore/index.js";
import { isSourceInstance as et } from "../Source/index.js";
import A from "../DataStore/index.js";
import { isSeriesDataSchema as it } from "../helper/SeriesDataSchema/index.js";
var D = $, c = q, rt = typeof Int32Array > "u" ? Array : Int32Array, nt = "e\0\0", C = -1, ot = ["hasItemOption", "_nameList", "_idList", "_invertedIndicesMap", "_dimSummary", "userOutput", "_rawData", "_dimValueGetter", "_nameDimIdx", "_idDimIdx", "_nameRepeatCount"], st = ["_approximateExtent"], F, x, g, I, L, O, R, gt = (
  /** @class */
  function() {
    function n(t, e) {
      this.type = "list", this._dimOmitted = !1, this._nameList = [], this._idList = [], this._visual = {}, this._layout = {}, this._itemVisuals = [], this._itemLayouts = [], this._graphicEls = [], this._approximateExtent = {}, this._calculationInfo = {}, this.hasItemOption = !1, this.TRANSFERABLE_METHODS = ["cloneShallow", "downSample", "lttbDownSample", "map"], this.CHANGABLE_METHODS = ["filterSelf", "selectRange"], this.DOWNSAMPLE_METHODS = ["downSample", "lttbDownSample"];
      var i, r = !1;
      it(t) ? (i = t.dimensions, this._dimOmitted = t.isDimensionOmitted(), this._schema = t) : (r = !0, i = t), i = i || ["x", "y"];
      for (var o = {}, u = [], s = {}, a = !1, f = {}, h = 0; h < i.length; h++) {
        var l = i[h], p = G(l) ? new w({
          name: l
        }) : l instanceof w ? l : new w(l), _ = p.name;
        p.type = p.type || "float", p.coordDim || (p.coordDim = _, p.coordDimIndex = 0);
        var V = p.otherDims = p.otherDims || {};
        u.push(_), o[_] = p, f[_] != null && (a = !0), p.createInvertedIndices && (s[_] = []), V.itemName === 0 && (this._nameDimIdx = h), V.itemId === 0 && (this._idDimIdx = h), process.env.NODE_ENV !== "production" && H(r || p.storeDimIndex >= 0), r && (p.storeDimIndex = h);
      }
      if (this.dimensions = u, this._dimInfos = o, this._initGetDimensionInfo(a), this.hostModel = e, this._invertedIndicesMap = s, this._dimOmitted) {
        var T = this._dimIdxToName = z();
        d(u, function(N) {
          T.set(o[N].storeDimIndex, N);
        });
      }
    }
    return m(n, "SeriesData"), n.prototype.getDimension = function(t) {
      var e = this._recognizeDimIndex(t);
      if (e == null)
        return t;
      if (e = t, !this._dimOmitted)
        return this.dimensions[e];
      var i = this._dimIdxToName.get(e);
      if (i != null)
        return i;
      var r = this._schema.getSourceDimension(e);
      if (r)
        return r.name;
    }, n.prototype.getDimensionIndex = function(t) {
      var e = this._recognizeDimIndex(t);
      if (e != null)
        return e;
      if (t == null)
        return -1;
      var i = this._getDimInfo(t);
      return i ? i.storeDimIndex : this._dimOmitted ? this._schema.getSourceDimensionIndex(t) : -1;
    }, n.prototype._recognizeDimIndex = function(t) {
      if (B(t) || t != null && !isNaN(t) && !this._getDimInfo(t) && (!this._dimOmitted || this._schema.getSourceDimensionIndex(t) < 0))
        return +t;
    }, n.prototype._getStoreDimIndex = function(t) {
      var e = this.getDimensionIndex(t);
      if (process.env.NODE_ENV !== "production" && e == null)
        throw new Error("Unknown dimension " + t);
      return e;
    }, n.prototype.getDimensionInfo = function(t) {
      return this._getDimInfo(this.getDimension(t));
    }, n.prototype._initGetDimensionInfo = function(t) {
      var e = this._dimInfos;
      this._getDimInfo = t ? function(i) {
        return e.hasOwnProperty(i) ? e[i] : void 0;
      } : function(i) {
        return e[i];
      };
    }, n.prototype.getDimensionsOnCoord = function() {
      return this._dimSummary.dataDimsOnCoord.slice();
    }, n.prototype.mapDimension = function(t, e) {
      var i = this._dimSummary;
      if (e == null)
        return i.encodeFirstDimNotExtra[t];
      var r = i.encode[t];
      return r ? r[e] : null;
    }, n.prototype.mapDimensionsAll = function(t) {
      var e = this._dimSummary, i = e.encode[t];
      return (i || []).slice();
    }, n.prototype.getStore = function() {
      return this._store;
    }, n.prototype.initData = function(t, e, i) {
      var r = this, o;
      if (t instanceof A && (o = t), !o) {
        var u = this.dimensions, s = et(t) || U(t) ? new K(t, u.length) : t;
        o = new A();
        var a = c(u, function(f) {
          return {
            type: r._dimInfos[f].type,
            property: f
          };
        });
        o.initData(s, a, i);
      }
      this._store = o, this._nameList = (e || []).slice(), this._idList = [], this._nameRepeatCount = {}, this._doInit(0, o.count()), this._dimSummary = Q(this, this._schema), this.userOutput = this._dimSummary.userOutput;
    }, n.prototype.appendData = function(t) {
      var e = this._store.appendData(t);
      this._doInit(e[0], e[1]);
    }, n.prototype.appendValues = function(t, e) {
      var i = this._store.appendValues(t, e.length), r = i.start, o = i.end, u = this._shouldMakeIdFromName();
      if (this._updateOrdinalMeta(), e)
        for (var s = r; s < o; s++) {
          var a = s - r;
          this._nameList[s] = e[a], u && R(this, s);
        }
    }, n.prototype._updateOrdinalMeta = function() {
      for (var t = this._store, e = this.dimensions, i = 0; i < e.length; i++) {
        var r = this._dimInfos[e[i]];
        r.ordinalMeta && t.collectOrdinalMeta(r.storeDimIndex, r.ordinalMeta);
      }
    }, n.prototype._shouldMakeIdFromName = function() {
      var t = this._store.getProvider();
      return this._idDimIdx == null && t.getSource().sourceFormat !== Z && !t.fillStorage;
    }, n.prototype._doInit = function(t, e) {
      if (!(t >= e)) {
        var i = this._store, r = i.getProvider();
        this._updateOrdinalMeta();
        var o = this._nameList, u = this._idList, s = r.getSource().sourceFormat, a = s === k;
        if (a && !r.pure)
          for (var f = [], h = t; h < e; h++) {
            var l = r.getItem(h, f);
            if (!this.hasItemOption && b(l) && (this.hasItemOption = !0), l) {
              var p = l.name;
              o[h] == null && p != null && (o[h] = E(p, null));
              var _ = l.id;
              u[h] == null && _ != null && (u[h] = E(_, null));
            }
          }
        if (this._shouldMakeIdFromName())
          for (var h = t; h < e; h++)
            R(this, h);
        F(this);
      }
    }, n.prototype.getApproximateExtent = function(t) {
      return this._approximateExtent[t] || this._store.getDataExtent(this._getStoreDimIndex(t));
    }, n.prototype.setApproximateExtent = function(t, e) {
      e = this.getDimension(e), this._approximateExtent[e] = t.slice();
    }, n.prototype.getCalculationInfo = function(t) {
      return this._calculationInfo[t];
    }, n.prototype.setCalculationInfo = function(t, e) {
      D(t) ? v(this._calculationInfo, t) : this._calculationInfo[t] = e;
    }, n.prototype.getName = function(t) {
      var e = this.getRawIndex(t), i = this._nameList[e];
      return i == null && this._nameDimIdx != null && (i = g(this, this._nameDimIdx, e)), i == null && (i = ""), i;
    }, n.prototype._getCategory = function(t, e) {
      var i = this._store.get(t, e), r = this._store.getOrdinalMeta(t);
      return r ? r.categories[i] : i;
    }, n.prototype.getId = function(t) {
      return x(this, this.getRawIndex(t));
    }, n.prototype.count = function() {
      return this._store.count();
    }, n.prototype.get = function(t, e) {
      var i = this._store, r = this._dimInfos[t];
      if (r)
        return i.get(r.storeDimIndex, e);
    }, n.prototype.getByRawIndex = function(t, e) {
      var i = this._store, r = this._dimInfos[t];
      if (r)
        return i.getByRawIndex(r.storeDimIndex, e);
    }, n.prototype.getIndices = function() {
      return this._store.getIndices();
    }, n.prototype.getDataExtent = function(t) {
      return this._store.getDataExtent(this._getStoreDimIndex(t));
    }, n.prototype.getSum = function(t) {
      return this._store.getSum(this._getStoreDimIndex(t));
    }, n.prototype.getMedian = function(t) {
      return this._store.getMedian(this._getStoreDimIndex(t));
    }, n.prototype.getValues = function(t, e) {
      var i = this, r = this._store;
      return M(t) ? r.getValues(c(t, function(o) {
        return i._getStoreDimIndex(o);
      }), e) : r.getValues(t);
    }, n.prototype.hasValue = function(t) {
      for (var e = this._dimSummary.dataDimIndicesOnCoord, i = 0, r = e.length; i < r; i++)
        if (isNaN(this._store.get(e[i], t)))
          return !1;
      return !0;
    }, n.prototype.indexOfName = function(t) {
      for (var e = 0, i = this._store.count(); e < i; e++)
        if (this.getName(e) === t)
          return e;
      return -1;
    }, n.prototype.getRawIndex = function(t) {
      return this._store.getRawIndex(t);
    }, n.prototype.indexOfRawIndex = function(t) {
      return this._store.indexOfRawIndex(t);
    }, n.prototype.rawIndexOf = function(t, e) {
      var i = t && this._invertedIndicesMap[t];
      if (process.env.NODE_ENV !== "production" && !i)
        throw new Error("Do not supported yet");
      var r = i[e];
      return r == null || isNaN(r) ? C : r;
    }, n.prototype.indicesOfNearest = function(t, e, i) {
      return this._store.indicesOfNearest(this._getStoreDimIndex(t), e, i);
    }, n.prototype.each = function(t, e, i) {
      S(t) && (i = e, e = t, t = []);
      var r = i || this, o = c(I(t), this._getStoreDimIndex, this);
      this._store.each(o, r ? y(e, r) : e);
    }, n.prototype.filterSelf = function(t, e, i) {
      S(t) && (i = e, e = t, t = []);
      var r = i || this, o = c(I(t), this._getStoreDimIndex, this);
      return this._store = this._store.filter(o, r ? y(e, r) : e), this;
    }, n.prototype.selectRange = function(t) {
      var e = this, i = {}, r = j(t);
      return d(r, function(o) {
        var u = e._getStoreDimIndex(o);
        i[u] = t[o];
      }), this._store = this._store.selectRange(i), this;
    }, n.prototype.mapArray = function(t, e, i) {
      S(t) && (i = e, e = t, t = []), i = i || this;
      var r = [];
      return this.each(t, function() {
        r.push(e && e.apply(this, arguments));
      }, i), r;
    }, n.prototype.map = function(t, e, i, r) {
      var o = i || r || this, u = c(I(t), this._getStoreDimIndex, this), s = O(this);
      return s._store = this._store.map(u, o ? y(e, o) : e), s;
    }, n.prototype.modify = function(t, e, i, r) {
      var o = this, u = i || r || this;
      process.env.NODE_ENV !== "production" && d(I(t), function(a) {
        var f = o.getDimensionInfo(a);
        f.isCalculationCoord || console.error("Danger: only stack dimension can be modified");
      });
      var s = c(I(t), this._getStoreDimIndex, this);
      this._store.modify(s, u ? y(e, u) : e);
    }, n.prototype.downSample = function(t, e, i, r) {
      var o = O(this);
      return o._store = this._store.downSample(this._getStoreDimIndex(t), e, i, r), o;
    }, n.prototype.lttbDownSample = function(t, e) {
      var i = O(this);
      return i._store = this._store.lttbDownSample(this._getStoreDimIndex(t), e), i;
    }, n.prototype.getRawDataItem = function(t) {
      return this._store.getRawDataItem(t);
    }, n.prototype.getItemModel = function(t) {
      var e = this.hostModel, i = this.getRawDataItem(t);
      return new W(i, e, e && e.ecModel);
    }, n.prototype.diff = function(t) {
      var e = this;
      return new J(t ? t.getStore().getIndices() : [], this.getStore().getIndices(), function(i) {
        return x(t, i);
      }, function(i) {
        return x(e, i);
      });
    }, n.prototype.getVisual = function(t) {
      var e = this._visual;
      return e && e[t];
    }, n.prototype.setVisual = function(t, e) {
      this._visual = this._visual || {}, D(t) ? v(this._visual, t) : this._visual[t] = e;
    }, n.prototype.getItemVisual = function(t, e) {
      var i = this._itemVisuals[t], r = i && i[e];
      return r ?? this.getVisual(e);
    }, n.prototype.hasItemVisual = function() {
      return this._itemVisuals.length > 0;
    }, n.prototype.ensureUniqueItemVisual = function(t, e) {
      var i = this._itemVisuals, r = i[t];
      r || (r = i[t] = {});
      var o = r[e];
      return o == null && (o = this.getVisual(e), M(o) ? o = o.slice() : D(o) && (o = v({}, o)), r[e] = o), o;
    }, n.prototype.setItemVisual = function(t, e, i) {
      var r = this._itemVisuals[t] || {};
      this._itemVisuals[t] = r, D(e) ? v(r, e) : r[e] = i;
    }, n.prototype.clearAllVisual = function() {
      this._visual = {}, this._itemVisuals = [];
    }, n.prototype.setLayout = function(t, e) {
      D(t) ? v(this._layout, t) : this._layout[t] = e;
    }, n.prototype.getLayout = function(t) {
      return this._layout[t];
    }, n.prototype.getItemLayout = function(t) {
      return this._itemLayouts[t];
    }, n.prototype.setItemLayout = function(t, e, i) {
      this._itemLayouts[t] = i ? v(this._itemLayouts[t] || {}, e) : e;
    }, n.prototype.clearItemLayouts = function() {
      this._itemLayouts.length = 0;
    }, n.prototype.setItemGraphicEl = function(t, e) {
      var i = this.hostModel && this.hostModel.seriesIndex;
      tt(i, this.dataType, t, e), this._graphicEls[t] = e;
    }, n.prototype.getItemGraphicEl = function(t) {
      return this._graphicEls[t];
    }, n.prototype.eachItemGraphicEl = function(t, e) {
      d(this._graphicEls, function(i, r) {
        i && t && t.call(e, i, r);
      });
    }, n.prototype.cloneShallow = function(t) {
      return t || (t = new n(this._schema ? this._schema : c(this.dimensions, this._getDimInfo, this), this.hostModel)), L(t, this), t._store = this._store, t;
    }, n.prototype.wrapMethod = function(t, e) {
      var i = this[t];
      S(i) && (this.__wrappedMethods = this.__wrappedMethods || [], this.__wrappedMethods.push(t), this[t] = function() {
        var r = i.apply(this, arguments);
        return e.apply(this, [r].concat(X(arguments)));
      });
    }, n.internalField = function() {
      F = /* @__PURE__ */ m(function(t) {
        var e = t._invertedIndicesMap;
        d(e, function(i, r) {
          var o = t._dimInfos[r], u = o.ordinalMeta, s = t._store;
          if (u) {
            i = e[r] = new rt(u.categories.length);
            for (var a = 0; a < i.length; a++)
              i[a] = C;
            for (var a = 0; a < s.count(); a++)
              i[s.get(o.storeDimIndex, a)] = a;
          }
        });
      }, "prepareInvertedIndex"), g = /* @__PURE__ */ m(function(t, e, i) {
        return E(t._getCategory(e, i), null);
      }, "getIdNameFromStore"), x = /* @__PURE__ */ m(function(t, e) {
        var i = t._idList[e];
        return i == null && t._idDimIdx != null && (i = g(t, t._idDimIdx, e)), i == null && (i = nt + e), i;
      }, "getId"), I = /* @__PURE__ */ m(function(t) {
        return M(t) || (t = t != null ? [t] : []), t;
      }, "normalizeDimensions"), O = /* @__PURE__ */ m(function(t) {
        var e = new n(t._schema ? t._schema : c(t.dimensions, t._getDimInfo, t), t.hostModel);
        return L(e, t), e;
      }, "cloneListForMapAndSample"), L = /* @__PURE__ */ m(function(t, e) {
        d(ot.concat(e.__wrappedMethods || []), function(i) {
          e.hasOwnProperty(i) && (t[i] = e[i]);
        }), t.__wrappedMethods = e.__wrappedMethods, d(st, function(i) {
          t[i] = Y(e[i]);
        }), t._calculationInfo = v({}, e._calculationInfo);
      }, "transferProperties"), R = /* @__PURE__ */ m(function(t, e) {
        var i = t._nameList, r = t._idList, o = t._nameDimIdx, u = t._idDimIdx, s = i[e], a = r[e];
        if (s == null && o != null && (i[e] = s = g(t, o, e)), a == null && u != null && (r[e] = a = g(t, u, e)), a == null && s != null) {
          var f = t._nameRepeatCount, h = f[s] = (f[s] || 0) + 1;
          a = s, h > 1 && (a += "__ec__" + h), r[e] = a;
        }
      }, "makeIdFromName");
    }(), n;
  }()
);
export {
  gt as default
};
