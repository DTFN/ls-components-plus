var A = Object.defineProperty;
var p = (e, t) => A(e, "name", { value: t, configurable: !0 });
import { SERIES_LAYOUT_BY_COLUMN as y, SOURCE_FORMAT_ARRAY_ROWS as b, SOURCE_FORMAT_OBJECT_ROWS as M } from "../../../util/types/index.js";
import { normalizeToArray as S } from "../../../util/model/index.js";
import { createHashMap as C, clone as O, isObject as x, map as h, each as B, hasOwn as _, bind as N, extend as U, isNumber as j } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getRawSourceItemGetter as G, getRawSourceDataCounter as H, getRawSourceValueGetter as L } from "../dataProvider/index.js";
import { parseDataValue as Y } from "../dataValueHelper/index.js";
import { throwError as c, makePrintable as F, log as k } from "../../../util/log/index.js";
import { detectSourceFormat as P, createSource as W } from "../../Source/index.js";
var z = (
  /** @class */
  function() {
    function e() {
    }
    return p(e, "ExternalSource"), e.prototype.getRawData = function() {
      throw new Error("not supported");
    }, e.prototype.getRawDataItem = function(t) {
      throw new Error("not supported");
    }, e.prototype.cloneRawData = function() {
    }, e.prototype.getDimensionInfo = function(t) {
    }, e.prototype.cloneAllDimensionInfo = function() {
    }, e.prototype.count = function() {
    }, e.prototype.retrieveValue = function(t, r) {
    }, e.prototype.retrieveValueFromItem = function(t, r) {
    }, e.prototype.convertValue = function(t, r) {
      return Y(t, r);
    }, e;
  }()
);
function J(e, t) {
  var r = new z(), i = e.data, n = r.sourceFormat = e.sourceFormat, a = e.startIndex, s = "";
  e.seriesLayoutBy !== y && (process.env.NODE_ENV !== "production" && (s = '`seriesLayoutBy` of upstream dataset can only be "column" in data transform.'), c(s));
  var u = [], l = {}, g = e.dimensionsDefine;
  if (g)
    B(g, function(f, m) {
      var d = f.name, I = {
        index: m,
        name: d,
        displayName: f.displayName
      };
      if (u.push(I), d != null) {
        var V = "";
        _(l, d) && (process.env.NODE_ENV !== "production" && (V = 'dimension name "' + d + '" duplicated.'), c(V)), l[d] = I;
      }
    });
  else
    for (var o = 0; o < e.dimensionsDetectedCount; o++)
      u.push({
        index: o
      });
  var E = G(n, y);
  t.__isBuiltIn && (r.getRawDataItem = function(f) {
    return E(i, a, u, f);
  }, r.getRawData = N(q, null, e)), r.cloneRawData = N(K, null, e);
  var v = H(n, y);
  r.count = N(v, null, i, a, u);
  var w = L(n);
  r.retrieveValue = function(f, m) {
    var d = E(i, a, u, f);
    return D(d, m);
  };
  var D = r.retrieveValueFromItem = function(f, m) {
    if (f != null) {
      var d = u[m];
      if (d)
        return w(f, m, d.name);
    }
  };
  return r.getDimensionInfo = N(Q, null, u, l), r.cloneAllDimensionInfo = N(X, null, u), r;
}
p(J, "createExternalSource");
function q(e) {
  var t = e.sourceFormat;
  if (!R(t)) {
    var r = "";
    process.env.NODE_ENV !== "production" && (r = "`getRawData` is not supported in source format " + t), c(r);
  }
  return e.data;
}
p(q, "getRawData");
function K(e) {
  var t = e.sourceFormat, r = e.data;
  if (!R(t)) {
    var i = "";
    process.env.NODE_ENV !== "production" && (i = "`cloneRawData` is not supported in source format " + t), c(i);
  }
  if (t === b) {
    for (var n = [], a = 0, s = r.length; a < s; a++)
      n.push(r[a].slice());
    return n;
  } else if (t === M) {
    for (var n = [], a = 0, s = r.length; a < s; a++)
      n.push(U({}, r[a]));
    return n;
  }
}
p(K, "cloneRawData");
function Q(e, t, r) {
  if (r != null) {
    if (j(r) || !isNaN(r) && !_(t, r))
      return e[r];
    if (_(t, r))
      return t[r];
  }
}
p(Q, "getDimensionInfo");
function X(e) {
  return O(e);
}
p(X, "cloneAllDimensionInfo");
var T = C();
function se(e) {
  e = O(e);
  var t = e.type, r = "";
  t || (process.env.NODE_ENV !== "production" && (r = "Must have a `type` when `registerTransform`."), c(r));
  var i = t.split(":");
  i.length !== 2 && (process.env.NODE_ENV !== "production" && (r = 'Name must include namespace like "ns:regression".'), c(r));
  var n = !1;
  i[0] === "echarts" && (t = i[1], n = !0), e.__isBuiltIn = n, T.set(t, e);
}
p(se, "registerExternalTransform");
function ue(e, t, r) {
  var i = S(e), n = i.length, a = "";
  n || (process.env.NODE_ENV !== "production" && (a = "If `transform` declared, it should at least contain one transform."), c(a));
  for (var s = 0, u = n; s < u; s++) {
    var l = i[s];
    t = Z(l, t, r, n === 1 ? null : s), s !== u - 1 && (t.length = Math.max(t.length, 1));
  }
  return t;
}
p(ue, "applyDataTransform");
function Z(e, t, r, i) {
  var n = "";
  t.length || (process.env.NODE_ENV !== "production" && (n = "Must have at least one upstream dataset."), c(n)), x(e) || (process.env.NODE_ENV !== "production" && (n = "transform declaration must be an object rather than " + typeof e + "."), c(n));
  var a = e.type, s = T.get(a);
  s || (process.env.NODE_ENV !== "production" && (n = 'Can not find transform on type "' + a + '".'), c(n));
  var u = h(t, function(o) {
    return J(o, s);
  }), l = S(s.transform({
    upstream: u[0],
    upstreamList: u,
    config: O(e.config)
  }));
  if (process.env.NODE_ENV !== "production" && e.print) {
    var g = h(l, function(o) {
      var E = i != null ? " === pipe index: " + i : "";
      return ["=== dataset index: " + r.datasetIndex + E + " ===", "- transform result data:", F(o.data), "- transform result dimensions:", F(o.dimensions)].join(`
`);
    }).join(`
`);
    k(g);
  }
  return h(l, function(o, E) {
    var v = "";
    x(o) || (process.env.NODE_ENV !== "production" && (v = "A transform should not return some empty results."), c(v)), o.data || (process.env.NODE_ENV !== "production" && (v = "Transform result data should be not be null or undefined"), c(v));
    var w = P(o.data);
    R(w) || (process.env.NODE_ENV !== "production" && (v = "Transform result data should be array rows or object rows."), c(v));
    var D, f = t[0];
    if (f && E === 0 && !o.dimensions) {
      var m = f.startIndex;
      m && (o.data = f.data.slice(0, m).concat(o.data)), D = {
        seriesLayoutBy: y,
        sourceHeader: m,
        dimensions: f.metaRawOption.dimensions
      };
    } else
      D = {
        seriesLayoutBy: y,
        sourceHeader: 0,
        dimensions: o.dimensions
      };
    return W(o.data, D, null);
  });
}
p(Z, "applySingleDataTransform");
function R(e) {
  return e === b || e === M;
}
p(R, "isSupportedSourceFormat");
export {
  z as ExternalSource,
  ue as applyDataTransform,
  se as registerExternalTransform
};
