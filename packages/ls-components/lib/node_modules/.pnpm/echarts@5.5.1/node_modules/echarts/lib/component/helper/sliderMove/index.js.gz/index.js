var k = Object.defineProperty;
var c = (t, i) => k(t, "name", { value: i, configurable: !0 });
function w(t, i, f, r, u, g) {
  t = t || 0;
  var s = f[1] - f[0];
  if (u != null && (u = M(u, [0, s])), g != null && (g = Math.max(g, u ?? 0)), r === "all") {
    var o = Math.abs(i[1] - i[0]);
    o = M(o, [0, s]), u = g = M(o, [u, g]), r = 0;
  }
  i[0] = M(i[0], f), i[1] = M(i[1], f);
  var b = D(i, r);
  i[r] += t;
  var j = u || 0, y = f.slice();
  b.sign < 0 ? y[0] += j : y[1] -= j, i[r] = M(i[r], y);
  var v;
  return v = D(i, r), u != null && (v.sign !== b.sign || v.span < u) && (i[1 - r] = i[r] + b.sign * u), v = D(i, r), g != null && v.span > g && (i[1 - r] = i[r] + v.sign * g), i;
}
c(w, "sliderMove");
function D(t, i) {
  var f = t[i] - t[1 - i];
  return {
    span: Math.abs(f),
    sign: f > 0 ? -1 : f < 0 ? 1 : i ? -1 : 1
  };
}
c(D, "getSpanSign");
function M(t, i) {
  return Math.min(i[1] != null ? i[1] : 1 / 0, Math.max(i[0] != null ? i[0] : -1 / 0, t));
}
c(M, "restrict");
export {
  w as default
};
