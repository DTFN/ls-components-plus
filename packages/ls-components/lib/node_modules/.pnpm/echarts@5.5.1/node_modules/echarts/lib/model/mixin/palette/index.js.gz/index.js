var h = Object.defineProperty;
var i = (t, e) => h(t, "name", { value: e, configurable: !0 });
import { normalizeToArray as m, makeInner as P } from "../../../util/model/index.js";
var g = P();
P();
var N = (
  /** @class */
  function() {
    function t() {
    }
    return i(t, "PaletteMixin"), t.prototype.getColorFromPalette = function(e, a, r) {
      var l = m(this.get("color", !0)), o = this.get("colorLayer", !0);
      return d(this, g, l, o, e, a, r);
    }, t.prototype.clearColorPalette = function() {
      I(this, g);
    }, t;
  }()
);
function x(t, e) {
  for (var a = t.length, r = 0; r < a; r++)
    if (t[r].length > e)
      return t[r];
  return t[a - 1];
}
i(x, "getNearestPalette");
function d(t, e, a, r, l, o, f) {
  o = o || t;
  var p = e(o), c = p.paletteIdx || 0, u = p.paletteNameMap = p.paletteNameMap || {};
  if (u.hasOwnProperty(l))
    return u[l];
  var n = f == null || !r ? a : x(r, f);
  if (n = n || a, !(!n || !n.length)) {
    var v = n[c];
    return l && (u[l] = v), p.paletteIdx = (c + 1) % n.length, v;
  }
}
i(d, "getFromPalette");
function I(t, e) {
  e(t).paletteIdx = 0, e(t).paletteNameMap = {};
}
i(I, "clearPalette");
export {
  N as PaletteMixin
};
