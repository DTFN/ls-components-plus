var O = Object.defineProperty;
var h = (s, n) => O(s, "name", { value: n, configurable: !0 });
import { __extends as R } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { merge as _, each as f, createHashMap as P, assert as x } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import I from "../../../model/Component/index.js";
import { getAxisMainType as g, DATA_ZOOM_AXIS_DIMENSIONS as M } from "../helper/index.js";
import { MULTIPLE_REFERRING as V, SINGLE_REFERRING as T } from "../../../util/model/index.js";
var y = (
  /** @class */
  function() {
    function s() {
      this.indexList = [], this.indexMap = [];
    }
    return h(s, "DataZoomAxisInfo"), s.prototype.add = function(n) {
      this.indexMap[n] || (this.indexList.push(n), this.indexMap[n] = !0);
    }, s;
  }()
), D = (
  /** @class */
  function(s) {
    R(n, s);
    function n() {
      var t = s !== null && s.apply(this, arguments) || this;
      return t.type = n.type, t._autoThrottle = !0, t._noTarget = !0, t._rangePropMode = ["percent", "percent"], t;
    }
    return h(n, "DataZoomModel"), n.prototype.init = function(t, e, i) {
      var r = m(t);
      this.settledOption = r, this.mergeDefaultAndTheme(t, i), this._doInit(r);
    }, n.prototype.mergeOption = function(t) {
      var e = m(t);
      _(this.option, t, !0), _(this.settledOption, e, !0), this._doInit(e);
    }, n.prototype._doInit = function(t) {
      var e = this.option;
      this._setDefaultThrottle(t), this._updateRangeUse(t);
      var i = this.settledOption;
      f([["start", "startValue"], ["end", "endValue"]], function(r, o) {
        this._rangePropMode[o] === "value" && (e[r[0]] = i[r[0]] = null);
      }, this), this._resetTarget();
    }, n.prototype._resetTarget = function() {
      var t = this.get("orient", !0), e = this._targetAxisInfoMap = P(), i = this._fillSpecifiedTargetAxis(e);
      i ? this._orient = t || this._makeAutoOrientByTargetAxis() : (this._orient = t || "horizontal", this._fillAutoTargetAxisByOrient(e, this._orient)), this._noTarget = !0, e.each(function(r) {
        r.indexList.length && (this._noTarget = !1);
      }, this);
    }, n.prototype._fillSpecifiedTargetAxis = function(t) {
      var e = !1;
      return f(M, function(i) {
        var r = this.getReferringComponents(g(i), V);
        if (r.specified) {
          e = !0;
          var o = new y();
          f(r.models, function(a) {
            o.add(a.componentIndex);
          }), t.set(i, o);
        }
      }, this), e;
    }, n.prototype._fillAutoTargetAxisByOrient = function(t, e) {
      var i = this.ecModel, r = !0;
      if (r) {
        var o = e === "vertical" ? "y" : "x", a = i.findComponents({
          mainType: o + "Axis"
        });
        p(a, o);
      }
      if (r) {
        var a = i.findComponents({
          mainType: "singleAxis",
          filter: /* @__PURE__ */ h(function(l) {
            return l.get("orient", !0) === e;
          }, "filter")
        });
        p(a, "single");
      }
      function p(u, l) {
        var d = u[0];
        if (d) {
          var c = new y();
          if (c.add(d.componentIndex), t.set(l, c), r = !1, l === "x" || l === "y") {
            var A = d.getReferringComponents("grid", T).models[0];
            A && f(u, function(v) {
              d.componentIndex !== v.componentIndex && A === v.getReferringComponents("grid", T).models[0] && c.add(v.componentIndex);
            });
          }
        }
      }
      h(p, "setParallelAxis"), r && f(M, function(u) {
        if (r) {
          var l = i.findComponents({
            mainType: g(u),
            filter: /* @__PURE__ */ h(function(c) {
              return c.get("type", !0) === "category";
            }, "filter")
          });
          if (l[0]) {
            var d = new y();
            d.add(l[0].componentIndex), t.set(u, d), r = !1;
          }
        }
      }, this);
    }, n.prototype._makeAutoOrientByTargetAxis = function() {
      var t;
      return this.eachTargetAxis(function(e) {
        !t && (t = e);
      }, this), t === "y" ? "vertical" : "horizontal";
    }, n.prototype._setDefaultThrottle = function(t) {
      if (t.hasOwnProperty("throttle") && (this._autoThrottle = !1), this._autoThrottle) {
        var e = this.ecModel.option;
        this.option.throttle = e.animation && e.animationDurationUpdate > 0 ? 100 : 20;
      }
    }, n.prototype._updateRangeUse = function(t) {
      var e = this._rangePropMode, i = this.get("rangeMode");
      f([["start", "startValue"], ["end", "endValue"]], function(r, o) {
        var a = t[r[0]] != null, p = t[r[1]] != null;
        a && !p ? e[o] = "percent" : !a && p ? e[o] = "value" : i ? e[o] = i[o] : a && (e[o] = "percent");
      });
    }, n.prototype.noTarget = function() {
      return this._noTarget;
    }, n.prototype.getFirstTargetAxisModel = function() {
      var t;
      return this.eachTargetAxis(function(e, i) {
        t == null && (t = this.ecModel.getComponent(g(e), i));
      }, this), t;
    }, n.prototype.eachTargetAxis = function(t, e) {
      this._targetAxisInfoMap.each(function(i, r) {
        f(i.indexList, function(o) {
          t.call(e, r, o);
        });
      });
    }, n.prototype.getAxisProxy = function(t, e) {
      var i = this.getAxisModel(t, e);
      if (i)
        return i.__dzAxisProxy;
    }, n.prototype.getAxisModel = function(t, e) {
      process.env.NODE_ENV !== "production" && x(t && e != null);
      var i = this._targetAxisInfoMap.get(t);
      if (i && i.indexMap[e])
        return this.ecModel.getComponent(g(t), e);
    }, n.prototype.setRawRange = function(t) {
      var e = this.option, i = this.settledOption;
      f([["start", "startValue"], ["end", "endValue"]], function(r) {
        (t[r[0]] != null || t[r[1]] != null) && (e[r[0]] = i[r[0]] = t[r[0]], e[r[1]] = i[r[1]] = t[r[1]]);
      }, this), this._updateRangeUse(t);
    }, n.prototype.setCalculatedRange = function(t) {
      var e = this.option;
      f(["start", "startValue", "end", "endValue"], function(i) {
        e[i] = t[i];
      });
    }, n.prototype.getPercentRange = function() {
      var t = this.findRepresentativeAxisProxy();
      if (t)
        return t.getDataPercentWindow();
    }, n.prototype.getValueRange = function(t, e) {
      if (t == null && e == null) {
        var i = this.findRepresentativeAxisProxy();
        if (i)
          return i.getDataValueWindow();
      } else
        return this.getAxisProxy(t, e).getDataValueWindow();
    }, n.prototype.findRepresentativeAxisProxy = function(t) {
      if (t)
        return t.__dzAxisProxy;
      for (var e, i = this._targetAxisInfoMap.keys(), r = 0; r < i.length; r++)
        for (var o = i[r], a = this._targetAxisInfoMap.get(o), p = 0; p < a.indexList.length; p++) {
          var u = this.getAxisProxy(o, a.indexList[p]);
          if (u.hostedBy(this))
            return u;
          e || (e = u);
        }
      return e;
    }, n.prototype.getRangePropMode = function() {
      return this._rangePropMode.slice();
    }, n.prototype.getOrient = function() {
      return process.env.NODE_ENV !== "production" && x(this._orient), this._orient;
    }, n.type = "dataZoom", n.dependencies = ["xAxis", "yAxis", "radiusAxis", "angleAxis", "singleAxis", "series", "toolbox"], n.defaultOption = {
      // zlevel: 0,
      z: 4,
      filterMode: "filter",
      start: 0,
      end: 100
    }, n;
  }(I)
);
function m(s) {
  var n = {};
  return f(["start", "end", "startValue", "endValue", "throttle"], function(t) {
    s.hasOwnProperty(t) && (n[t] = s[t]);
  }), n;
}
h(m, "retrieveRawOption");
export {
  D as default
};
