var N = Object.defineProperty;
var p = (a, r) => N(a, "name", { value: r, configurable: !0 });
import "../../util/graphic/index.js";
import W from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/OrientedBoundingRect/index.js";
import Q from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/BoundingRect/index.js";
function $(a) {
  for (var r = [], f = 0; f < a.length; f++) {
    var e = a[f];
    if (!e.defaultAttr.ignore) {
      var s = e.label, u = s.getComputedTransform(), n = s.getBoundingRect(), A = !u || u[1] < 1e-5 && u[2] < 1e-5, h = s.style.margin || 0, i = n.clone();
      i.applyTransform(u), i.x -= h / 2, i.y -= h / 2, i.width += h, i.height += h;
      var d = A ? new W(n, u) : null;
      r.push({
        label: s,
        labelLine: e.labelLine,
        rect: i,
        localRect: n,
        obb: d,
        priority: e.priority,
        defaultAttr: e.defaultAttr,
        layoutOption: e.computedLayoutOption,
        axisAligned: A,
        transform: u
      });
    }
  }
  return r;
}
p($, "prepareLayoutList");
function K(a, r, f, e, s, u) {
  var n = a.length;
  if (n < 2)
    return;
  a.sort(function(t, L) {
    return t.rect[r] - L.rect[r];
  });
  for (var A = 0, h, i = !1, d = 0, O = 0; O < n; O++) {
    var w = a[O], y = w.rect;
    h = y[r] - A, h < 0 && (y[r] -= h, w.label[r] -= h, i = !0);
    var g = Math.max(-h, 0);
    d += g, A = y[r] + y[f];
  }
  d > 0 && u && B(-d / n, 0, n);
  var G = a[0], M = a[n - 1], k, q;
  z(), k < 0 && E(-k, 0.8), q < 0 && E(q, 0.8), z(), X(k, q, 1), X(q, k, -1), z(), k < 0 && Y(-k), q < 0 && Y(q);
  function z() {
    k = G.rect[r] - e, q = s - M.rect[r] - M.rect[f];
  }
  p(z, "updateMinMaxGap");
  function X(t, L, c) {
    if (t < 0) {
      var v = Math.min(L, -t);
      if (v > 0) {
        B(v * c, 0, n);
        var o = v + t;
        o < 0 && E(-o * c, 1);
      } else
        E(-t * c, 1);
    }
  }
  p(X, "takeBoundsGap");
  function B(t, L, c) {
    t !== 0 && (i = !0);
    for (var v = L; v < c; v++) {
      var o = a[v], P = o.rect;
      P[r] += t, o.label[r] += t;
    }
  }
  p(B, "shiftList");
  function E(t, L) {
    for (var c = [], v = 0, o = 1; o < n; o++) {
      var P = a[o - 1].rect, H = Math.max(a[o].rect[r] - P[r] - P[f], 0);
      c.push(H), v += H;
    }
    if (v) {
      var J = Math.min(Math.abs(t) / v, L);
      if (t > 0)
        for (var o = 0; o < n - 1; o++) {
          var S = c[o] * J;
          B(S, 0, o + 1);
        }
      else
        for (var o = n - 1; o > 0; o--) {
          var S = c[o - 1] * J;
          B(-S, o, n);
        }
    }
  }
  p(E, "squeezeGaps");
  function Y(t) {
    var L = t < 0 ? -1 : 1;
    t = Math.abs(t);
    for (var c = Math.ceil(t / (n - 1)), v = 0; v < n - 1; v++)
      if (L > 0 ? B(c, 0, v + 1) : B(-c, n - v - 1, n), t -= c, t <= 0)
        return;
  }
  return p(Y, "squeezeWhenBailout"), i;
}
p(K, "shiftLayout");
function b(a, r, f, e) {
  return K(a, "x", "width", r, f, e);
}
p(b, "shiftLayoutOnX");
function j(a, r, f, e) {
  return K(a, "y", "height", r, f, e);
}
p(j, "shiftLayoutOnY");
function F(a) {
  var r = [];
  a.sort(function(G, M) {
    return M.priority - G.priority;
  });
  var f = new Q(0, 0, 0, 0);
  function e(G) {
    if (!G.ignore) {
      var M = G.ensureState("emphasis");
      M.ignore == null && (M.ignore = !1);
    }
    G.ignore = !0;
  }
  p(e, "hideEl");
  for (var s = 0; s < a.length; s++) {
    var u = a[s], n = u.axisAligned, A = u.localRect, h = u.transform, i = u.label, d = u.labelLine;
    f.copy(u.rect), f.width -= 0.1, f.height -= 0.1, f.x += 0.05, f.y += 0.05;
    for (var O = u.obb, w = !1, y = 0; y < r.length; y++) {
      var g = r[y];
      if (f.intersect(g.rect)) {
        if (n && g.axisAligned) {
          w = !0;
          break;
        }
        if (g.obb || (g.obb = new W(g.localRect, g.transform)), O || (O = new W(A, h)), O.intersect(g.obb)) {
          w = !0;
          break;
        }
      }
    }
    w ? (e(i), d && e(d)) : (i.attr("ignore", u.defaultAttr.ignore), d && d.attr("ignore", u.defaultAttr.labelGuideIgnore), r.push(u));
  }
}
p(F, "hideOverlap");
export {
  F as hideOverlap,
  $ as prepareLayoutList,
  b as shiftLayoutOnX,
  j as shiftLayoutOnY
};
