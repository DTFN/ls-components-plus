var I = Object.defineProperty;
var l = (s, e) => I(s, "name", { value: e, configurable: !0 });
import { each as v, isObject as D, indexOf as y, retrieve3 as M, keys as w } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getLayoutRect as P } from "../../../util/layout/index.js";
import { estimateLabelUnionRect as Z, createScaleByModel as G, getDataDimensionsOnAxis as R, ifAxisCrossZero as k, niceScaleExtent as _ } from "../../axisHelper/index.js";
import z, { cartesian2DDimensions as C } from "../Cartesian2D/index.js";
import H from "../Axis2D/index.js";
import { SINGLE_REFERRING as L } from "../../../util/model/index.js";
import { isCartesian2DSeries as S, findAxisModels as T } from "../cartesianAxisHelper/index.js";
import { isIntervalOrLogScale as b } from "../../../scale/helper/index.js";
import { alignScaleTicks as F } from "../../axisAlignTicks/index.js";
var Y = (
  /** @class */
  function() {
    function s(e, r, o) {
      this.type = "grid", this._coordsMap = {}, this._coordsList = [], this._axesMap = {}, this._axesList = [], this.axisPointerEnabled = !0, this.dimensions = C, this._initCartesian(e, r, o), this.model = e;
    }
    return l(s, "Grid"), s.prototype.getRect = function() {
      return this._rect;
    }, s.prototype.update = function(e, r) {
      var o = this._axesMap;
      this._updateScale(e, this.model);
      function t(i) {
        var f, p = w(i), a = p.length;
        if (a) {
          for (var u = [], c = a - 1; c >= 0; c--) {
            var d = +p[c], h = i[d], x = h.model, g = h.scale;
            // Only value and log axis without interval support alignTicks.
            b(g) && x.get("alignTicks") && x.get("interval") == null ? u.push(h) : (_(g, x), b(g) && (f = h));
          }
          u.length && (f || (f = u.pop(), _(f.scale, f.model)), v(u, function(A) {
            F(A.scale, A.model, f.scale);
          }));
        }
      }
      l(t, "updateAxisTicks"), t(o.x), t(o.y);
      var n = {};
      v(o.x, function(i) {
        E(o, "y", i, n);
      }), v(o.y, function(i) {
        E(o, "x", i, n);
      }), this.resize(this.model, r);
    }, s.prototype.resize = function(e, r, o) {
      var t = e.getBoxLayoutParams(), n = !o && e.get("containLabel"), i = P(t, {
        width: r.getWidth(),
        height: r.getHeight()
      });
      this._rect = i;
      var f = this._axesList;
      p(), n && (v(f, function(a) {
        if (!a.model.get(["axisLabel", "inside"])) {
          var u = Z(a);
          if (u) {
            var c = a.isHorizontal() ? "height" : "width", d = a.model.get(["axisLabel", "margin"]);
            i[c] -= u[c] + d, a.position === "top" ? i.y += u.height + d : a.position === "left" && (i.x += u.width + d);
          }
        }
      }), p()), v(this._coordsList, function(a) {
        a.calcAffineTransform();
      });
      function p() {
        v(f, function(a) {
          var u = a.isHorizontal(), c = u ? [0, i.width] : [0, i.height], d = a.inverse ? 1 : 0;
          a.setExtent(c[d], c[1 - d]), j(a, u ? i.x : i.y);
        });
      }
      l(p, "adjustAxes");
    }, s.prototype.getAxis = function(e, r) {
      var o = this._axesMap[e];
      if (o != null)
        return o[r || 0];
    }, s.prototype.getAxes = function() {
      return this._axesList.slice();
    }, s.prototype.getCartesian = function(e, r) {
      if (e != null && r != null) {
        var o = "x" + e + "y" + r;
        return this._coordsMap[o];
      }
      D(e) && (r = e.yAxisIndex, e = e.xAxisIndex);
      for (var t = 0, n = this._coordsList; t < n.length; t++)
        if (n[t].getAxis("x").index === e || n[t].getAxis("y").index === r)
          return n[t];
    }, s.prototype.getCartesians = function() {
      return this._coordsList.slice();
    }, s.prototype.convertToPixel = function(e, r, o) {
      var t = this._findConvertTarget(r);
      return t.cartesian ? t.cartesian.dataToPoint(o) : t.axis ? t.axis.toGlobalCoord(t.axis.dataToCoord(o)) : null;
    }, s.prototype.convertFromPixel = function(e, r, o) {
      var t = this._findConvertTarget(r);
      return t.cartesian ? t.cartesian.pointToData(o) : t.axis ? t.axis.coordToData(t.axis.toLocalCoord(o)) : null;
    }, s.prototype._findConvertTarget = function(e) {
      var r = e.seriesModel, o = e.xAxisModel || r && r.getReferringComponents("xAxis", L).models[0], t = e.yAxisModel || r && r.getReferringComponents("yAxis", L).models[0], n = e.gridModel, i = this._coordsList, f, p;
      if (r)
        f = r.coordinateSystem, y(i, f) < 0 && (f = null);
      else if (o && t)
        f = this.getCartesian(o.componentIndex, t.componentIndex);
      else if (o)
        p = this.getAxis("x", o.componentIndex);
      else if (t)
        p = this.getAxis("y", t.componentIndex);
      else if (n) {
        var a = n.coordinateSystem;
        a === this && (f = this._coordsList[0]);
      }
      return {
        cartesian: f,
        axis: p
      };
    }, s.prototype.containPoint = function(e) {
      var r = this._coordsList[0];
      if (r)
        return r.containPoint(e);
    }, s.prototype._initCartesian = function(e, r, o) {
      var t = this, n = this, i = {
        left: !1,
        right: !1,
        top: !1,
        bottom: !1
      }, f = {
        x: {},
        y: {}
      }, p = {
        x: 0,
        y: 0
      };
      if (r.eachComponent("xAxis", a("x"), this), r.eachComponent("yAxis", a("y"), this), !p.x || !p.y) {
        this._axesMap = {}, this._axesList = [];
        return;
      }
      this._axesMap = f, v(f.x, function(u, c) {
        v(f.y, function(d, h) {
          var x = "x" + c + "y" + h, g = new z(x);
          g.master = t, g.model = e, t._coordsMap[x] = g, t._coordsList.push(g), g.addAxis(u), g.addAxis(d);
        });
      });
      function a(u) {
        return function(c, d) {
          if (m(c, e)) {
            var h = c.get("position");
            u === "x" ? h !== "top" && h !== "bottom" && (h = i.bottom ? "top" : "bottom") : h !== "left" && h !== "right" && (h = i.left ? "right" : "left"), i[h] = !0;
            var x = new H(u, G(c), [0, 0], c.get("type"), h), g = x.type === "category";
            x.onBand = g && c.get("boundaryGap"), x.inverse = c.get("inverse"), c.axis = x, x.model = c, x.grid = n, x.index = d, n._axesList.push(x), f[u][d] = x, p[u]++;
          }
        };
      }
      l(a, "createAxisCreator");
    }, s.prototype._updateScale = function(e, r) {
      v(this._axesList, function(t) {
        if (t.scale.setExtent(1 / 0, -1 / 0), t.type === "category") {
          var n = t.model.get("categorySortInfo");
          t.scale.setSortInfo(n);
        }
      }), e.eachSeries(function(t) {
        if (S(t)) {
          var n = T(t), i = n.xAxisModel, f = n.yAxisModel;
          if (!m(i, r) || !m(f, r))
            return;
          var p = this.getCartesian(i.componentIndex, f.componentIndex), a = t.getData(), u = p.getAxis("x"), c = p.getAxis("y");
          o(a, u), o(a, c);
        }
      }, this);
      function o(t, n) {
        v(R(t, n.dim), function(i) {
          n.scale.unionExtentFromData(t, i);
        });
      }
      l(o, "unionExtent");
    }, s.prototype.getTooltipAxes = function(e) {
      var r = [], o = [];
      return v(this.getCartesians(), function(t) {
        var n = e != null && e !== "auto" ? t.getAxis(e) : t.getBaseAxis(), i = t.getOtherAxis(n);
        y(r, n) < 0 && r.push(n), y(o, i) < 0 && o.push(i);
      }), {
        baseAxes: r,
        otherAxes: o
      };
    }, s.create = function(e, r) {
      var o = [];
      return e.eachComponent("grid", function(t, n) {
        var i = new s(t, e, r);
        i.name = "grid_" + n, i.resize(t, r, !0), t.coordinateSystem = i, o.push(i);
      }), e.eachSeries(function(t) {
        if (S(t)) {
          var n = T(t), i = n.xAxisModel, f = n.yAxisModel, p = i.getCoordSysModel();
          if (process.env.NODE_ENV !== "production") {
            if (!p)
              throw new Error('Grid "' + M(i.get("gridIndex"), i.get("gridId"), 0) + '" not found');
            if (i.getCoordSysModel() !== f.getCoordSysModel())
              throw new Error("xAxis and yAxis must use the same grid");
          }
          var a = p.coordinateSystem;
          t.coordinateSystem = a.getCartesian(i.componentIndex, f.componentIndex);
        }
      }), o;
    }, s.dimensions = C, s;
  }()
);
function m(s, e) {
  return s.getCoordSysModel() === e;
}
l(m, "isAxisUsedInTheGrid");
function E(s, e, r, o) {
  r.getAxesOnZeroOf = function() {
    return n ? [n] : [];
  };
  var t = s[e], n, i = r.model, f = i.get(["axisLine", "onZero"]), p = i.get(["axisLine", "onZeroAxisIndex"]);
  if (!f)
    return;
  if (p != null)
    O(t[p]) && (n = t[p]);
  else
    for (var a in t)
      if (t.hasOwnProperty(a) && O(t[a]) && !o[u(t[a])]) {
        n = t[a];
        break;
      }
  n && (o[u(n)] = !0);
  function u(c) {
    return c.dim + "_" + c.index;
  }
  l(u, "getOnZeroRecordKey");
}
l(E, "fixAxisOnZero");
function O(s) {
  return s && s.type !== "category" && s.type !== "time" && k(s);
}
l(O, "canOnZeroToAxis");
function j(s, e) {
  var r = s.getExtent(), o = r[0] + r[1];
  s.toGlobalCoord = s.dim === "x" ? function(t) {
    return t + e;
  } : function(t) {
    return o - t + e;
  }, s.toLocalCoord = s.dim === "x" ? function(t) {
    return t - e;
  } : function(t) {
    return o - t + e;
  };
}
l(j, "updateAxisTransform");
export {
  Y as default
};
