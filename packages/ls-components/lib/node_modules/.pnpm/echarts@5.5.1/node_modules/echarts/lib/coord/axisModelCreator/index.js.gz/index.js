var c = Object.defineProperty;
var n = (r, o) => c(r, "name", { value: o, configurable: !0 });
import { __extends as M } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import v from "../axisDefault/index.js";
import { fetchLayoutMode as A, getLayoutParams as _, mergeLayoutParam as x } from "../../util/layout/index.js";
import O from "../../data/OrdinalMeta/index.js";
import { AXIS_TYPES as P } from "../axisCommonTypes/index.js";
import { each as D, merge as u } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
function U(r, o, s, d) {
  D(P, function(C, i) {
    var m = u(u({}, v[i], !0), d, !0), y = (
      /** @class */
      function(f) {
        M(e, f);
        function e() {
          var t = f !== null && f.apply(this, arguments) || this;
          return t.type = o + "Axis." + i, t;
        }
        return n(e, "AxisModel"), e.prototype.mergeDefaultAndTheme = function(t, a) {
          var p = A(this), g = p ? _(t) : {}, h = a.getTheme();
          u(t, h.get(i + "Axis")), u(t, this.getDefaultOption()), t.type = l(t), p && x(t, g, p);
        }, e.prototype.optionUpdated = function() {
          var t = this.option;
          t.type === "category" && (this.__ordinalMeta = O.createByAxisModel(this));
        }, e.prototype.getCategories = function(t) {
          var a = this.option;
          if (a.type === "category")
            return t ? a.data : this.__ordinalMeta.categories;
        }, e.prototype.getOrdinalMeta = function() {
          return this.__ordinalMeta;
        }, e.type = o + "Axis." + i, e.defaultOption = m, e;
      }(s)
    );
    r.registerComponentModel(y);
  }), r.registerSubTypeDefaulter(o + "Axis", l);
}
n(U, "axisModelCreator");
function l(r) {
  return r.type || (r.data ? "category" : "value");
}
n(l, "getAxisType");
export {
  U as default
};
