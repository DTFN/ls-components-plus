var X = Object.defineProperty;
var w = (t, r) => X(t, "name", { value: r, configurable: !0 });
import { __extends as Y } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { createHashMap as W, each as V, assert as Z, indexOf as k, hasOwn as H, retrieve2 as P, isFunction as O, keys as tt, extend as et } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import rt from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Displayable/index.js";
import { convertOptionIdName as I, makeInner as nt } from "../../../util/model/index.js";
import { setTooltipConfig as at, getShapeClass as it } from "../../../util/graphic/index.js";
import { positionElement as ot, LOCATION_PARAMS as ft } from "../../../util/layout/index.js";
import { parsePercent as B } from "../../../util/number/index.js";
import vt from "../../../view/Component/index.js";
import { getECData as M } from "../../../util/innerStore/index.js";
import { isEC4CompatibleStyle as st, convertFromEC4CompatibleStyle as mt } from "../../../util/styleCompat/index.js";
import { applyUpdateTransition as U, updateLeaveTo as ut, isTransitionAll as pt, applyLeaveTransition as dt } from "../../../animation/customGraphicTransition/index.js";
import { updateProps as lt } from "../../../animation/basicTransition/index.js";
import { stopPreviousKeyframeAnimationAndRestore as ht, applyKeyframeAnimation as R } from "../../../animation/customGraphicKeyframeAnimation/index.js";
import K from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import ct from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import gt from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Image/index.js";
var j = {
  // Reserved but not supported in graphic component.
  path: null,
  compoundPath: null,
  // Supported in graphic component.
  group: ct,
  image: gt,
  text: K
}, u = nt(), Ht = (
  /** @class */
  function(t) {
    Y(r, t);
    function r() {
      var e = t !== null && t.apply(this, arguments) || this;
      return e.type = r.type, e;
    }
    return w(r, "GraphicComponentView"), r.prototype.init = function() {
      this._elMap = W();
    }, r.prototype.render = function(e, i, n) {
      e !== this._lastGraphicModel && this._clear(), this._lastGraphicModel = e, this._updateElements(e), this._relocate(e, n);
    }, r.prototype._updateElements = function(e) {
      var i = e.useElOptionsToUpdate();
      if (i) {
        var n = this._elMap, v = this.group, _ = e.get("z"), A = e.get("zlevel");
        V(i, function(a) {
          var y = I(a.id, null), s = y != null ? n.get(y) : null, d = I(a.parentId, null), g = d != null ? n.get(d) : v, o = a.type, m = a.style;
          o === "text" && m && a.hv && a.hv[1] && (m.textVerticalAlign = m.textBaseline = m.verticalAlign = m.align = null);
          var l = a.textContent, C = a.textConfig;
          if (m && st(m, o, !!C, !!l)) {
            var h = mt(m, o);
            !C && h.textConfig && (C = a.textConfig = h.textConfig), !l && h.textContent && (l = h.textContent);
          }
          var T = Ct(a);
          process.env.NODE_ENV !== "production" && s && Z(g === s.parent, "Changing parent is not supported.");
          var E = a.$action || "merge", N = E === "merge", b = E === "replace";
          if (N) {
            var c = !s, p = s;
            c ? p = q(y, g, a.type, n) : (p && (u(p).isNew = !1), ht(p)), p && (U(p, T, e, {
              isInit: c
            }), J(p, a, _, A));
          } else if (b) {
            S(s, a, n, e);
            var x = q(y, g, a.type, n);
            x && (U(x, T, e, {
              isInit: !0
            }), J(x, a, _, A));
          } else E === "remove" && (ut(s, a), S(s, a, n, e));
          var f = n.get(y);
          if (f && l)
            if (N) {
              var F = f.getTextContent();
              F ? F.attr(l) : f.setTextContent(new K(l));
            } else b && f.setTextContent(new K(l));
          if (f) {
            var D = a.clipPath;
            if (D) {
              var z = D.type, G = void 0, c = !1;
              if (N) {
                var L = f.getClipPath();
                c = !L || u(L).type !== z, G = c ? $(z) : L;
              } else b && (c = !0, G = $(z));
              f.setClipPath(G), U(G, D, e, {
                isInit: c
              }), R(G, D.keyframeAnimation, e);
            }
            var Q = u(f);
            f.setTextConfig(C), Q.option = a, yt(f, e, a), at({
              el: f,
              componentModel: e,
              itemName: f.name,
              itemTooltipOption: a.tooltip
            }), R(f, a.keyframeAnimation, e);
          }
        });
      }
    }, r.prototype._relocate = function(e, i) {
      for (var n = e.option.elements, v = this.group, _ = this._elMap, A = i.getWidth(), a = i.getHeight(), y = ["x", "y"], s = 0; s < n.length; s++) {
        var d = n[s], g = I(d.id, null), o = g != null ? _.get(g) : null;
        if (!(!o || !o.isGroup)) {
          var m = o.parent, l = m === v, C = u(o), h = u(m);
          C.width = B(C.option.width, l ? A : h.width) || 0, C.height = B(C.option.height, l ? a : h.height) || 0;
        }
      }
      for (var s = n.length - 1; s >= 0; s--) {
        var d = n[s], g = I(d.id, null), o = g != null ? _.get(g) : null;
        if (o) {
          var m = o.parent, h = u(m), T = m === v ? {
            width: A,
            height: a
          } : {
            width: h.width,
            height: h.height
          }, E = {}, N = ot(o, d, T, null, {
            hv: d.hv,
            boundingMode: d.bounding
          }, E);
          if (!u(o).isNew && N) {
            for (var b = d.transition, c = {}, p = 0; p < y.length; p++) {
              var x = y[p], f = E[x];
              b && (pt(b) || k(b, x) >= 0) ? c[x] = f : o[x] = f;
            }
            lt(o, c, e, 0);
          } else
            o.attr(E);
        }
      }
    }, r.prototype._clear = function() {
      var e = this, i = this._elMap;
      i.each(function(n) {
        S(n, u(n).option, i, e._lastGraphicModel);
      }), this._elMap = W();
    }, r.prototype.dispose = function() {
      this._clear();
    }, r.type = "graphic", r;
  }(vt)
);
function $(t) {
  process.env.NODE_ENV !== "production" && Z(t, "graphic type MUST be set");
  var r = H(j, t) ? j[t] : it(t);
  process.env.NODE_ENV !== "production" && Z(r, "graphic type " + t + " can not be found");
  var e = new r({});
  return u(e).type = t, e;
}
w($, "newEl");
function q(t, r, e, i) {
  var n = $(e);
  return r.add(n), i.set(t, n), u(n).id = t, u(n).isNew = !0, n;
}
w(q, "createEl");
function S(t, r, e, i) {
  var n = t && t.parent;
  n && (t.type === "group" && t.traverse(function(v) {
    S(v, r, e, i);
  }), dt(t, r, i), e.removeKey(u(t).id));
}
w(S, "removeEl");
function J(t, r, e, i) {
  t.isGroup || V([
    ["cursor", rt.prototype.cursor],
    // We should not support configure z and zlevel in the element level.
    // But seems we didn't limit it previously. So here still use it to avoid breaking.
    ["zlevel", i || 0],
    ["z", e || 0],
    // z2 must not be null/undefined, otherwise sort error may occur.
    ["z2", 0]
  ], function(n) {
    var v = n[0];
    H(r, v) ? t[v] = P(r[v], n[1]) : t[v] == null && (t[v] = n[1]);
  }), V(tt(r), function(n) {
    if (n.indexOf("on") === 0) {
      var v = r[n];
      t[n] = O(v) ? v : null;
    }
  }), H(r, "draggable") && (t.draggable = r.draggable), r.name != null && (t.name = r.name), r.id != null && (t.id = r.id);
}
w(J, "updateCommonAttrs");
function Ct(t) {
  return t = et({}, t), V(["id", "parentId", "$action", "hv", "bounding", "textContent", "clipPath"].concat(ft), function(r) {
    delete t[r];
  }), t;
}
w(Ct, "getCleanedElOption");
function yt(t, r, e) {
  var i = M(t).eventData;
  !t.silent && !t.ignore && !i && (i = M(t).eventData = {
    componentType: "graphic",
    componentIndex: r.componentIndex,
    name: t.name
  }), i && (i.info = e.info);
}
w(yt, "setEventData");
export {
  Ht as GraphicComponentView,
  u as inner
};
