var s = Object.defineProperty;
var n = (t, e) => s(t, "name", { value: e, configurable: !0 });
import { map as l, isString as o, createHashMap as u, isObject as d } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var c = 0, g = (
  /** @class */
  function() {
    function t(e) {
      this.categories = e.categories || [], this._needCollect = e.needCollect, this._deduplication = e.deduplication, this.uid = ++c;
    }
    return n(t, "OrdinalMeta"), t.createByAxisModel = function(e) {
      var i = e.option, a = i.data, r = a && l(a, p);
      return new t({
        categories: r,
        needCollect: !r,
        // deduplication is default in axis.
        deduplication: i.dedplication !== !1
      });
    }, t.prototype.getOrdinal = function(e) {
      return this._getOrCreateMap().get(e);
    }, t.prototype.parseAndCollect = function(e) {
      var i, a = this._needCollect;
      if (!o(e) && !a)
        return e;
      if (a && !this._deduplication)
        return i = this.categories.length, this.categories[i] = e, i;
      var r = this._getOrCreateMap();
      return i = r.get(e), i == null && (a ? (i = this.categories.length, this.categories[i] = e, r.set(e, i)) : i = NaN), i;
    }, t.prototype._getOrCreateMap = function() {
      return this._map || (this._map = u(this.categories));
    }, t;
  }()
);
function p(t) {
  return d(t) && t.value != null ? t.value : t + "";
}
n(p, "getName");
export {
  g as default
};
