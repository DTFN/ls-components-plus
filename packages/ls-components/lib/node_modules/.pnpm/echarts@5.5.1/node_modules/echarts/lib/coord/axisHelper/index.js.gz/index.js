var h = Object.defineProperty;
var f = (e, t) => h(e, "name", { value: t, configurable: !0 });
import { each as s, keys as p, isString as y, isFunction as w } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import b from "../../scale/Ordinal/index.js";
import L from "../../scale/Interval/index.js";
import d from "../../scale/Scale/index.js";
import { prepareLayoutBarSeries as I, makeColumnLayout as E, retrieveColumnLayout as S } from "../../layout/barGrid/index.js";
import O from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/BoundingRect/index.js";
import C from "../../scale/Time/index.js";
import F from "../../scale/Log/index.js";
import { getStackedDimension as k } from "../../data/helper/dataStackHelper/index.js";
import { ensureScaleRawExtentInfo as R } from "../scaleRawExtentInfo/index.js";
function T(e, t) {
  var n = e.type, r = R(e, t, e.getExtent()).calculate();
  e.setBlank(r.isBlank);
  var a = r.min, i = r.max, u = t.ecModel;
  if (u && n === "time") {
    var o = I("bar", u), l = !1;
    if (s(o, function(m) {
      l = l || m.getBaseAxis() === t.axis;
    }), l) {
      var c = E(o), v = D(a, i, t, c);
      a = v.min, i = v.max;
    }
  }
  return {
    extent: [a, i],
    // "fix" means "fixed", the value should not be
    // changed in the subsequent steps.
    fixMin: r.minFixed,
    fixMax: r.maxFixed
  };
}
f(T, "getScaleExtent");
function D(e, t, n, r) {
  var a = n.axis.getExtent(), i = a[1] - a[0], u = S(r, n.axis);
  if (u === void 0)
    return {
      min: e,
      max: t
    };
  var o = 1 / 0;
  s(u, function(g) {
    o = Math.min(g.offset, o);
  });
  var l = -1 / 0;
  s(u, function(g) {
    l = Math.max(g.offset + g.width, l);
  }), o = Math.abs(o), l = Math.abs(l);
  var c = o + l, v = t - e, m = 1 - (o + l) / i, x = v / m - v;
  return t += x * (l / c), e -= x * (o / c), {
    min: e,
    max: t
  };
}
f(D, "adjustScaleForOverflow");
function X(e, t) {
  var n = t, r = T(e, n), a = r.extent, i = n.get("splitNumber");
  e instanceof F && (e.base = n.get("logBase"));
  var u = e.type, o = n.get("interval"), l = u === "interval" || u === "time";
  e.setExtent(a[0], a[1]), e.calcNiceExtent({
    splitNumber: i,
    fixMin: r.fixMin,
    fixMax: r.fixMax,
    minInterval: l ? n.get("minInterval") : null,
    maxInterval: l ? n.get("maxInterval") : null
  }), o != null && e.setInterval && e.setInterval(o);
}
f(X, "niceScaleExtent");
function Y(e, t) {
  if (t = t || e.get("type"), t)
    switch (t) {
      case "category":
        return new b({
          ordinalMeta: e.getOrdinalMeta ? e.getOrdinalMeta() : e.getCategories(),
          extent: [1 / 0, -1 / 0]
        });
      case "time":
        return new C({
          locale: e.ecModel.getLocaleModel(),
          useUTC: e.ecModel.get("useUTC")
        });
      default:
        return new (d.getClass(t) || L)();
    }
}
f(Y, "createScaleByModel");
function $(e) {
  var t = e.scale.getExtent(), n = t[0], r = t[1];
  return !(n > 0 && r > 0 || n < 0 && r < 0);
}
f($, "ifAxisCrossZero");
function N(e) {
  var t = e.getLabelModel().get("formatter"), n = e.type === "category" ? e.scale.getExtent()[0] : null;
  return e.scale.type === "time" ? /* @__PURE__ */ function(r) {
    return function(a, i) {
      return e.scale.getFormattedLabel(a, i, r);
    };
  }(t) : y(t) ? /* @__PURE__ */ function(r) {
    return function(a) {
      var i = e.scale.getLabel(a), u = r.replace("{value}", i ?? "");
      return u;
    };
  }(t) : w(t) ? /* @__PURE__ */ function(r) {
    return function(a, i) {
      return n != null && (i = a.value - n), r(A(e, a), i, a.level != null ? {
        level: a.level
      } : null);
    };
  }(t) : function(r) {
    return e.scale.getLabel(r);
  };
}
f(N, "makeLabelFormatter");
function A(e, t) {
  return e.type === "category" ? e.scale.getLabel(t) : t.value;
}
f(A, "getAxisRawValue");
function _(e) {
  var t = e.model, n = e.scale;
  if (!(!t.get(["axisLabel", "show"]) || n.isBlank())) {
    var r, a, i = n.getExtent();
    n instanceof b ? a = n.count() : (r = n.getTicks(), a = r.length);
    var u = e.getLabelModel(), o = N(e), l, c = 1;
    a > 40 && (c = Math.ceil(a / 40));
    for (var v = 0; v < a; v += c) {
      var m = r ? r[v] : {
        value: i[0] + v
      }, x = o(m, v), g = u.getTextRect(x), M = B(g, u.get("rotate") || 0);
      l ? l.union(M) : l = M;
    }
    return l;
  }
}
f(_, "estimateLabelUnionRect");
function B(e, t) {
  var n = t * Math.PI / 180, r = e.width, a = e.height, i = r * Math.abs(Math.cos(n)) + Math.abs(a * Math.sin(n)), u = r * Math.abs(Math.sin(n)) + Math.abs(a * Math.cos(n)), o = new O(e.x, e.y, i, u);
  return o;
}
f(B, "rotateTextRect");
function U(e) {
  var t = e.get("interval");
  return t ?? "auto";
}
f(U, "getOptionCategoryInterval");
function ee(e) {
  return e.type === "category" && U(e.getLabelModel()) === 0;
}
f(ee, "shouldShowAllLabels");
function P(e, t) {
  var n = {};
  return s(e.mapDimensionsAll(t), function(r) {
    n[k(e, r)] = !0;
  }), p(n);
}
f(P, "getDataDimensionsOnAxis");
function te(e, t, n) {
  t && s(P(t, n), function(r) {
    var a = t.getApproximateExtent(r);
    a[0] < e[0] && (e[0] = a[0]), a[1] > e[1] && (e[1] = a[1]);
  });
}
f(te, "unionAxisExtentFromData");
export {
  Y as createScaleByModel,
  _ as estimateLabelUnionRect,
  A as getAxisRawValue,
  P as getDataDimensionsOnAxis,
  U as getOptionCategoryInterval,
  T as getScaleExtent,
  $ as ifAxisCrossZero,
  N as makeLabelFormatter,
  X as niceScaleExtent,
  ee as shouldShowAllLabels,
  te as unionAxisExtentFromData
};
