var c = Object.defineProperty;
var a = (r, n) => c(r, "name", { value: n, configurable: !0 });
import { each as g } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { makeInner as l } from "../../../util/model/index.js";
var u = g, v = l();
function S(r, n) {
  var e = h(r);
  u(n, function(p, t) {
    for (var s = e.length - 1; s >= 0; s--) {
      var o = e[s];
      if (o[t])
        break;
    }
    if (s < 0) {
      var f = r.queryComponents({
        mainType: "dataZoom",
        subType: "select",
        id: t
      })[0];
      if (f) {
        var i = f.getPercentRange();
        e[0][t] = {
          dataZoomId: t,
          start: i[0],
          end: i[1]
        };
      }
    }
  }), e.push(n);
}
a(S, "push");
function b(r) {
  var n = h(r), e = n[n.length - 1];
  n.length > 1 && n.pop();
  var p = {};
  return u(e, function(t, s) {
    for (var o = n.length - 1; o >= 0; o--)
      if (t = n[o][s], t) {
        p[s] = t;
        break;
      }
  }), p;
}
a(b, "pop");
function T(r) {
  v(r).snapshots = null;
}
a(T, "clear");
function q(r) {
  return h(r).length;
}
a(q, "count");
function h(r) {
  var n = v(r);
  return n.snapshots || (n.snapshots = [{}]), n.snapshots;
}
a(h, "getStoreSnapshots");
export {
  T as clear,
  q as count,
  b as pop,
  S as push
};
