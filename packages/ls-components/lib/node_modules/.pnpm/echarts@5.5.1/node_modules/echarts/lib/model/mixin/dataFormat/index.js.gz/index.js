var N = Object.defineProperty;
var y = (t, e) => N(t, "name", { value: e, configurable: !0 });
import { isArray as T, isFunction as V, isString as b, isObject as d } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { retrieveRawValue as D } from "../../../data/helper/dataProvider/index.js";
import { formatTpl as w } from "../../../util/format/index.js";
import { error as I, makePrintable as O } from "../../../util/log/index.js";
var E = /\{@(.+?)\}/g, M = (
  /** @class */
  function() {
    function t() {
    }
    return y(t, "DataFormatMixin"), t.prototype.getDataParams = function(e, r) {
      var i = this.getData(r), p = this.getRawValue(e, r), o = i.getRawIndex(e), n = i.getName(e), m = i.getRawDataItem(e), a = i.getItemVisual(e, "style"), v = a && a[i.getItemVisual(e, "drawType") || "fill"], f = a && a.stroke, c = this.mainType, l = c === "series", s = i.userOutput && i.userOutput.get();
      return {
        componentType: c,
        componentSubType: this.subType,
        componentIndex: this.componentIndex,
        seriesType: l ? this.subType : null,
        seriesIndex: this.seriesIndex,
        seriesId: l ? this.id : null,
        seriesName: l ? this.name : null,
        name: n,
        dataIndex: o,
        data: m,
        dataType: r,
        value: p,
        color: v,
        borderColor: f,
        dimensionNames: s ? s.fullDimensions : null,
        encode: s ? s.encode : null,
        // Param name list for mapping `a`, `b`, `c`, `d`, `e`
        $vars: ["seriesName", "name", "value"]
      };
    }, t.prototype.getFormattedLabel = function(e, r, i, p, o, n) {
      r = r || "normal";
      var m = this.getData(i), a = this.getDataParams(e, i);
      if (n && (a.value = n.interpolatedValue), p != null && T(a.value) && (a.value = a.value[p]), !o) {
        var v = m.getItemModel(e);
        o = v.get(r === "normal" ? ["label", "formatter"] : [r, "label", "formatter"]);
      }
      if (V(o))
        return a.status = r, a.dimensionIndex = p, o(a);
      if (b(o)) {
        var f = w(o, a);
        return f.replace(E, function(c, l) {
          var s = l.length, u = l;
          u.charAt(0) === "[" && u.charAt(s - 1) === "]" && (u = +u.slice(1, s - 1), process.env.NODE_ENV !== "production" && isNaN(u) && I("Invalide label formatter: @" + l + ", only support @[0], @[1], @[2], ..."));
          var g = D(m, e, u);
          if (n && T(n.interpolatedValue)) {
            var h = m.getDimensionIndex(u);
            h >= 0 && (g = n.interpolatedValue[h]);
          }
          return g != null ? g + "" : "";
        });
      }
    }, t.prototype.getRawValue = function(e, r) {
      return D(this.getData(r), e);
    }, t.prototype.formatTooltip = function(e, r, i) {
    }, t;
  }()
);
function _(t) {
  var e, r;
  return d(t) ? t.type ? r = t : process.env.NODE_ENV !== "production" && console.warn("The return type of `formatTooltip` is not supported: " + O(t)) : e = t, {
    text: e,
    // markers: markers || markersExisting,
    frag: r
  };
}
y(_, "normalizeTooltipFormatResult");
export {
  M as DataFormatMixin,
  _ as normalizeTooltipFormatResult
};
