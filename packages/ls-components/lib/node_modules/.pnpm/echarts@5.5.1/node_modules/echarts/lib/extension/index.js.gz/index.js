var a = Object.defineProperty;
var r = (e, i) => a(e, "name", { value: i, configurable: !0 });
import { registerPreprocessor as m, registerProcessor as p, registerPostInit as f, registerPostUpdate as l, registerUpdateLifecycle as u, registerAction as c, registerCoordinateSystem as d, registerLayout as C, registerVisual as P, registerTransform as y, registerLoading as I, registerMap as M, PRIORITY as V } from "../core/echarts/index.js";
import s from "../view/Component/index.js";
import o from "../view/Chart/index.js";
import t from "../model/Component/index.js";
import n from "../model/Series/index.js";
import { isArray as S, each as w, indexOf as L, isFunction as T } from "../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { registerImpl as h } from "../core/impl/index.js";
import { registerPainter as R } from "../../../../../zrender@5.6.0/node_modules/zrender/lib/zrender/index.js";
var g = [], U = {
  registerPreprocessor: m,
  registerProcessor: p,
  registerPostInit: f,
  registerPostUpdate: l,
  registerUpdateLifecycle: u,
  registerAction: c,
  registerCoordinateSystem: d,
  registerLayout: C,
  registerVisual: P,
  registerTransform: y,
  registerLoading: I,
  registerMap: M,
  registerImpl: h,
  PRIORITY: V,
  ComponentModel: t,
  ComponentView: s,
  SeriesModel: n,
  ChartView: o,
  // TODO Use ComponentModel and SeriesModel instead of Constructor
  registerComponentModel: /* @__PURE__ */ r(function(e) {
    t.registerClass(e);
  }, "registerComponentModel"),
  registerComponentView: /* @__PURE__ */ r(function(e) {
    s.registerClass(e);
  }, "registerComponentView"),
  registerSeriesModel: /* @__PURE__ */ r(function(e) {
    n.registerClass(e);
  }, "registerSeriesModel"),
  registerChartView: /* @__PURE__ */ r(function(e) {
    o.registerClass(e);
  }, "registerChartView"),
  registerSubTypeDefaulter: /* @__PURE__ */ r(function(e, i) {
    t.registerSubTypeDefaulter(e, i);
  }, "registerSubTypeDefaulter"),
  registerPainter: /* @__PURE__ */ r(function(e, i) {
    R(e, i);
  }, "registerPainter")
};
function A(e) {
  if (S(e)) {
    w(e, function(i) {
      A(i);
    });
    return;
  }
  L(g, e) >= 0 || (g.push(e), T(e) && (e = {
    install: e
  }), e.install(U));
}
r(A, "use");
export {
  A as use
};
