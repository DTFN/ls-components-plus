var g = Object.defineProperty;
var f = (i, t) => g(i, "name", { value: t, configurable: !0 });
import { __extends as c } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { merge as u, each as y, map as v, indexOf as M } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import h from "../Model/index.js";
import { getUID as x, enableSubTypeDefaulter as C, enableTopologicalTravel as b } from "../../util/component/index.js";
import { isExtendedClass as O, mountExtend as T, enableClassManagement as D, parseClassType as I } from "../../util/clazz/index.js";
import { queryReferringComponents as L, makeInner as P } from "../../util/model/index.js";
import { fetchLayoutMode as m, getLayoutParams as w, mergeLayoutParam as l } from "../../util/layout/index.js";
var _ = P(), a = (
  /** @class */
  function(i) {
    c(t, i);
    function t(e, n, o) {
      var r = i.call(this, e, n, o) || this;
      return r.uid = x("ec_cpt_model"), r;
    }
    return f(t, "ComponentModel"), t.prototype.init = function(e, n, o) {
      this.mergeDefaultAndTheme(e, o);
    }, t.prototype.mergeDefaultAndTheme = function(e, n) {
      var o = m(this), r = o ? w(e) : {}, p = n.getTheme();
      u(e, p.get(this.mainType)), u(e, this.getDefaultOption()), o && l(e, r, o);
    }, t.prototype.mergeOption = function(e, n) {
      u(this.option, e, !0);
      var o = m(this);
      o && l(this.option, e, o);
    }, t.prototype.optionUpdated = function(e, n) {
    }, t.prototype.getDefaultOption = function() {
      var e = this.constructor;
      if (!O(e))
        return e.defaultOption;
      var n = _(this);
      if (!n.defaultOption) {
        for (var o = [], r = e; r; ) {
          var p = r.prototype.defaultOption;
          p && o.push(p), r = r.superClass;
        }
        for (var s = {}, d = o.length - 1; d >= 0; d--)
          s = u(s, o[d], !0);
        n.defaultOption = s;
      }
      return n.defaultOption;
    }, t.prototype.getReferringComponents = function(e, n) {
      var o = e + "Index", r = e + "Id";
      return L(this.ecModel, e, {
        index: this.get(o, !0),
        id: this.get(r, !0)
      }, n);
    }, t.prototype.getBoxLayoutParams = function() {
      var e = this;
      return {
        left: e.get("left"),
        top: e.get("top"),
        right: e.get("right"),
        bottom: e.get("bottom"),
        width: e.get("width"),
        height: e.get("height")
      };
    }, t.prototype.getZLevelKey = function() {
      return "";
    }, t.prototype.setZLevel = function(e) {
      this.option.zlevel = e;
    }, t.protoInitialize = function() {
      var e = t.prototype;
      e.type = "component", e.id = "", e.name = "", e.mainType = "", e.subType = "", e.componentIndex = 0;
    }(), t;
  }(h)
);
T(a, h);
D(a);
C(a);
b(a, K);
function K(i) {
  var t = [];
  return y(a.getClassesByMainType(i), function(e) {
    t = t.concat(e.dependencies || e.prototype.dependencies || []);
  }), t = v(t, function(e) {
    return I(e).main;
  }), i !== "dataset" && M(t, "dataset") <= 0 && t.unshift("dataset"), t;
}
f(K, "getDependencies");
export {
  a as default
};
