var x = Object.defineProperty;
var c = (r, e) => x(r, "name", { value: e, configurable: !0 });
import { isFunction as N, curry as A, isArray as I, map as E, each as F } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import M from "../../../data/SeriesData/index.js";
import R from "../../../data/helper/createDimensions/index.js";
import { getDimensionTypeByAxis as k } from "../../../data/helper/dimensionHelper/index.js";
import { getDataItemValue as w } from "../../../util/model/index.js";
import G from "../../../core/CoordinateSystem/index.js";
import { getCoordSysInfoBySeries as V } from "../../../model/referHelper/index.js";
import { enableDataStack as B } from "../../../data/helper/dataStackHelper/index.js";
import { makeSeriesEncodeForAxisCoordSys as T } from "../../../data/helper/sourceHelper/index.js";
import { SOURCE_FORMAT_ORIGINAL as v } from "../../../util/types/index.js";
function U(r, e) {
  var o = r.get("coordinateSystem"), a = G.get(o), t;
  return e && e.coordSysDims && (t = E(e.coordSysDims, function(i) {
    var s = {
      name: i
    }, m = e.axisMap.get(i);
    if (m) {
      var n = m.get("type");
      s.type = k(n);
    }
    return s;
  })), t || (t = a && (a.getDimensionsInfo ? a.getDimensionsInfo() : a.dimensions.slice()) || ["x", "y"]), t;
}
c(U, "getCoordSysDimDefs");
function _(r, e, o) {
  var a, t;
  return o && F(r, function(i, s) {
    var m = i.coordDim, n = o.categoryAxisMap.get(m);
    n && (a == null && (a = s), i.ordinalMeta = n.getOrdinalMeta(), e && (i.createInvertedIndices = !0)), i.otherDims.itemName != null && (t = !0);
  }), !t && a != null && (r[a].otherDims.itemName = 0), a;
}
c(_, "injectOrdinalMeta");
function Z(r, e, o) {
  o = o || {};
  var a = e.getSourceManager(), t, i = !1;
  t = a.getSource(), i = t.sourceFormat === v;
  var s = V(e), m = U(e, s), n = o.useEncodeDefaulter, S = N(n) ? n : n ? A(T, m, e) : null, y = {
    coordDimensions: m,
    generateCoord: o.generateCoord,
    encodeDefine: e.getEncode(),
    encodeDefaulter: S,
    canOmitUnusedDimensions: !i
  }, u = R(t, y), l = _(u.dimensions, o.createInvertedIndices, s), D = i ? null : a.getSharedDataStore(u), p = B(e, {
    schema: u,
    store: D
  }), f = new M(u, e);
  f.setCalculationInfo(p);
  var C = l != null && b(t) ? function(h, O, d, g) {
    return g === l ? d : this.defaultDimValueGetter(h, O, d, g);
  } : null;
  return f.hasItemOption = !1, f.initData(
    // Try to reuse the data store in sourceManager if using dataset.
    i ? t : D,
    null,
    C
  ), f;
}
c(Z, "createSeriesData");
function b(r) {
  if (r.sourceFormat === v) {
    var e = j(r.data || []);
    return !I(w(e));
  }
}
c(b, "isNeedCompleteOrdinalData");
function j(r) {
  for (var e = 0; e < r.length && r[e] == null; )
    e++;
  return r[e];
}
c(j, "firstDataNotNull");
export {
  Z as default
};
