var B = Object.defineProperty;
var D = (n, e) => B(n, "name", { value: e, configurable: !0 });
import { createHashMap as f, each as N } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { addSafe as x } from "../../util/number/index.js";
function w(n) {
  var e = f();
  n.eachSeries(function(d) {
    var s = d.get("stack");
    if (s) {
      var t = e.get(s) || e.set(s, []), a = d.getData(), i = {
        // Used for calculate axis extent automatically.
        // TODO: Type getCalculationInfo return more specific type?
        stackResultDimension: a.getCalculationInfo("stackResultDimension"),
        stackedOverDimension: a.getCalculationInfo("stackedOverDimension"),
        stackedDimension: a.getCalculationInfo("stackedDimension"),
        stackedByDimension: a.getCalculationInfo("stackedByDimension"),
        isStackedByIndex: a.getCalculationInfo("isStackedByIndex"),
        data: a,
        seriesModel: d
      };
      if (!i.stackedDimension || !(i.isStackedByIndex || i.stackedByDimension))
        return;
      t.length && a.setCalculationInfo("stackedOnSeries", t[t.length - 1].seriesModel), t.push(i);
    }
  }), e.each(h);
}
D(w, "dataStack");
function h(n) {
  N(n, function(e, d) {
    var s = [], t = [NaN, NaN], a = [e.stackResultDimension, e.stackedOverDimension], i = e.data, g = e.isStackedByIndex, o = e.seriesModel.get("stackStrategy") || "samesign";
    i.modify(a, function(p, R, l) {
      var r = i.get(e.stackedDimension, l);
      if (isNaN(r))
        return t;
      var k, m;
      g ? m = i.getRawIndex(l) : k = i.get(e.stackedByDimension, l);
      for (var y = NaN, v = d - 1; v >= 0; v--) {
        var u = n[v];
        if (g || (m = u.data.rawIndexOf(u.stackedByDimension, k)), m >= 0) {
          var c = u.data.getByRawIndex(u.stackResultDimension, m);
          if (o === "all" || o === "positive" && c > 0 || o === "negative" && c < 0 || o === "samesign" && r >= 0 && c > 0 || o === "samesign" && r <= 0 && c < 0) {
            r = x(r, c), y = c;
            break;
          }
        }
      }
      return s[0] = r, s[1] = y, s;
    });
  });
}
D(h, "calculateStack");
export {
  w as default
};
