var a = Object.defineProperty;
var i = (t, o) => a(t, "name", { value: o, configurable: !0 });
import { __extends as l } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { each as d, merge as u } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getFeature as f } from "../featureManager/index.js";
import m from "../../../model/Component/index.js";
var g = (
  /** @class */
  function(t) {
    l(o, t);
    function o() {
      var r = t !== null && t.apply(this, arguments) || this;
      return r.type = o.type, r;
    }
    return i(o, "ToolboxModel"), o.prototype.optionUpdated = function() {
      t.prototype.optionUpdated.apply(this, arguments);
      var r = this.ecModel;
      d(this.option.feature, function(n, p) {
        var e = f(p);
        e && (e.getDefaultOption && (e.defaultOption = e.getDefaultOption(r)), u(n, e.defaultOption));
      });
    }, o.type = "toolbox", o.layoutMode = {
      type: "box",
      ignoreSize: !0
    }, o.defaultOption = {
      show: !0,
      z: 6,
      // zlevel: 0,
      orient: "horizontal",
      left: "right",
      top: "top",
      // right
      // bottom
      backgroundColor: "transparent",
      borderColor: "#ccc",
      borderRadius: 0,
      borderWidth: 0,
      padding: 5,
      itemSize: 15,
      itemGap: 8,
      showTitle: !0,
      iconStyle: {
        borderColor: "#666",
        color: "none"
      },
      emphasis: {
        iconStyle: {
          borderColor: "#3E98C5"
        }
      },
      // textStyle: {},
      // feature
      tooltip: {
        show: !1,
        position: "bottom"
      }
    }, o;
  }(m)
);
export {
  g as default
};
