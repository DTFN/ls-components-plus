var h = Object.defineProperty;
var v = (i, e) => h(i, "name", { value: e, configurable: !0 });
import { retrieve as D, each as y, retrieve3 as O } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { SINGLE_REFERRING as R } from "../../../util/model/index.js";
function Z(i, e, c) {
  c = c || {};
  var f = i.coordinateSystem, o = e.axis, t = {}, s = o.getAxesOnZeroOf()[0], g = o.position, m = s ? "onZero" : g, x = o.dim, a = f.getRect(), n = [a.x, a.x + a.width, a.y, a.y + a.height], l = {
    left: 0,
    right: 1,
    top: 0,
    bottom: 1,
    onZero: 2
  }, d = e.get("offset") || 0, r = x === "x" ? [n[2] - d, n[3] + d] : [n[0] - d, n[1] + d];
  if (s) {
    var p = s.toGlobalCoord(s.dataToCoord(0));
    r[l.onZero] = Math.max(Math.min(p, r[1]), r[0]);
  }
  t.position = [x === "y" ? r[l[m]] : n[0], x === "x" ? r[l[m]] : n[3]], t.rotation = Math.PI / 2 * (x === "x" ? 0 : 1);
  var b = {
    top: -1,
    bottom: 1,
    left: -1,
    right: 1
  };
  t.labelDirection = t.tickDirection = t.nameDirection = b[g], t.labelOffset = s ? r[l[g]] - r[l.onZero] : 0, e.get(["axisTick", "inside"]) && (t.tickDirection = -t.tickDirection), D(c.labelInside, e.get(["axisLabel", "inside"])) && (t.labelDirection = -t.labelDirection);
  var u = e.get(["axisLabel", "rotate"]);
  return t.labelRotate = m === "top" ? -u : u, t.z2 = 1, t;
}
v(Z, "layout");
function M(i) {
  return i.get("coordinateSystem") === "cartesian2d";
}
v(M, "isCartesian2DSeries");
function w(i) {
  var e = {
    xAxisModel: null,
    yAxisModel: null
  };
  return y(e, function(c, f) {
    var o = f.replace(/Model$/, ""), t = i.getReferringComponents(o, R).models[0];
    if (process.env.NODE_ENV !== "production" && !t)
      throw new Error(o + ' "' + O(i.get(o + "Index"), i.get(o + "Id"), 0) + '" not found');
    e[f] = t;
  }), e;
}
v(w, "findAxisModels");
export {
  w as findAxisModels,
  M as isCartesian2DSeries,
  Z as layout
};
