var u = Object.defineProperty;
var s = (a, e) => u(a, "name", { value: e, configurable: !0 });
import { __extends as h } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import c from "../../helper/createSeriesDataSimply/index.js";
import { bind as p, curry as d } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { defaultEmphasis as g, makeInner as f } from "../../../util/model/index.js";
import { getPercentSeats as y } from "../../../util/number/index.js";
import { makeSeriesEncodeForNameBased as b } from "../../../data/helper/sourceHelper/index.js";
import v from "../../../visual/LegendVisualProvider/index.js";
import w from "../../../model/Series/index.js";
var L = f(), I = (
  /** @class */
  function(a) {
    h(e, a);
    function e() {
      return a !== null && a.apply(this, arguments) || this;
    }
    return s(e, "PieSeriesModel"), e.prototype.init = function(t) {
      a.prototype.init.apply(this, arguments), this.legendVisualProvider = new v(p(this.getData, this), p(this.getRawData, this)), this._defaultLabelLine(t);
    }, e.prototype.mergeOption = function() {
      a.prototype.mergeOption.apply(this, arguments);
    }, e.prototype.getInitialData = function() {
      return c(this, {
        coordDimensions: ["value"],
        encodeDefaulter: d(b, this)
      });
    }, e.prototype.getDataParams = function(t) {
      var i = this.getData(), n = L(i), r = n.seats;
      if (!r) {
        var l = [];
        i.each(i.mapDimension("value"), function(m) {
          l.push(m);
        }), r = n.seats = y(l, i.hostModel.get("percentPrecision"));
      }
      var o = a.prototype.getDataParams.call(this, t);
      return o.percent = r[t] || 0, o.$vars.push("percent"), o;
    }, e.prototype._defaultLabelLine = function(t) {
      g(t, "labelLine", ["show"]);
      var i = t.labelLine, n = t.emphasis.labelLine;
      i.show = i.show && t.label.show, n.show = n.show && t.emphasis.label.show;
    }, e.type = "series.pie", e.defaultOption = {
      // zlevel: 0,
      z: 2,
      legendHoverLink: !0,
      colorBy: "data",
      // 默认全局居中
      center: ["50%", "50%"],
      radius: [0, "75%"],
      // 默认顺时针
      clockwise: !0,
      startAngle: 90,
      endAngle: "auto",
      padAngle: 0,
      // 最小角度改为0
      minAngle: 0,
      // If the angle of a sector less than `minShowLabelAngle`,
      // the label will not be displayed.
      minShowLabelAngle: 0,
      // 选中时扇区偏移量
      selectedOffset: 10,
      // 选择模式，默认关闭，可选single，multiple
      // selectedMode: false,
      // 南丁格尔玫瑰图模式，'radius'（半径） | 'area'（面积）
      // roseType: null,
      percentPrecision: 2,
      // If still show when all data zero.
      stillShowZeroSum: !0,
      // cursor: null,
      left: 0,
      top: 0,
      right: 0,
      bottom: 0,
      width: null,
      height: null,
      label: {
        // color: 'inherit',
        // If rotate around circle
        rotate: 0,
        show: !0,
        overflow: "truncate",
        // 'outer', 'inside', 'center'
        position: "outer",
        // 'none', 'labelLine', 'edge'. Works only when position is 'outer'
        alignTo: "none",
        // Closest distance between label and chart edge.
        // Works only position is 'outer' and alignTo is 'edge'.
        edgeDistance: "25%",
        // Works only position is 'outer' and alignTo is not 'edge'.
        bleedMargin: 10,
        // Distance between text and label line.
        distanceToLabelLine: 5
        // formatter: 标签文本格式器，同 tooltip.formatter，不支持异步回调
        // 默认使用全局文本样式，详见 textStyle
        // distance: 当position为inner时有效，为label位置到圆心的距离与圆半径(环状图为内外半径和)的比例系数
      },
      // Enabled when label.normal.position is 'outer'
      labelLine: {
        show: !0,
        // 引导线两段中的第一段长度
        length: 15,
        // 引导线两段中的第二段长度
        length2: 15,
        smooth: !1,
        minTurnAngle: 90,
        maxSurfaceAngle: 90,
        lineStyle: {
          // color: 各异,
          width: 1,
          type: "solid"
        }
      },
      itemStyle: {
        borderWidth: 1,
        borderJoin: "round"
      },
      showEmptyCircle: !0,
      emptyCircleStyle: {
        color: "lightgray",
        opacity: 1
      },
      labelLayout: {
        // Hide the overlapped label.
        hideOverlap: !0
      },
      emphasis: {
        scale: !0,
        scaleSize: 5
      },
      // If use strategy to avoid label overlapping
      avoidLabelOverlap: !0,
      // Animation type. Valid values: expansion, scale
      animationType: "expansion",
      animationDuration: 1e3,
      // Animation type when update. Valid values: transition, expansion
      animationTypeUpdate: "transition",
      animationEasingUpdate: "cubicInOut",
      animationDurationUpdate: 500,
      animationEasing: "cubicInOut"
    }, e;
  }(w)
);
export {
  I as default
};
