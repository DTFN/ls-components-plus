var W = Object.defineProperty;
var S = (e, r) => W(e, "name", { value: r, configurable: !0 });
import { prepareDataCoordInfo as Z, getStackedOnPoint as _ } from "../helper/index.js";
import { createFloat32Array as C } from "../../../util/vendor/index.js";
function $(e, r) {
  var o = [];
  return r.diff(e).add(function(a) {
    o.push({
      cmd: "+",
      idx: a
    });
  }).update(function(a, p) {
    o.push({
      cmd: "=",
      idx: p,
      idx1: a
    });
  }).remove(function(a) {
    o.push({
      cmd: "-",
      idx: a
    });
  }).execute(), o;
}
S($, "diffData");
function w(e, r, o, a, p, d, O, X) {
  for (var T = $(e, r), h = [], g = [], N = [], P = [], V = [], c = [], m = [], j = Z(p, r, O), q = e.getLayout("points") || [], k = r.getLayout("points") || [], s = 0; s < T.length; s++) {
    var i = T[s], z = !0, f = void 0, t = void 0;
    switch (i.cmd) {
      case "=":
        f = i.idx * 2, t = i.idx1 * 2;
        var R = q[f], b = q[f + 1], B = k[t], E = k[t + 1];
        (isNaN(R) || isNaN(b)) && (R = B, b = E), h.push(R, b), g.push(B, E), N.push(o[f], o[f + 1]), P.push(a[t], a[t + 1]), m.push(r.getRawIndex(i.idx1));
        break;
      case "+":
        var n = i.idx, G = j.dataDimsForPoint, H = p.dataToPoint([r.get(G[0], n), r.get(G[1], n)]);
        t = n * 2, h.push(H[0], H[1]), g.push(k[t], k[t + 1]);
        var J = _(j, p, r, n);
        N.push(J[0], J[1]), P.push(a[t], a[t + 1]), m.push(r.getRawIndex(n));
        break;
      case "-":
        z = !1;
    }
    z && (V.push(i), c.push(c.length));
  }
  c.sort(function(Q, U) {
    return m[Q] - m[U];
  });
  for (var l = h.length, y = C(l), L = C(l), A = C(l), F = C(l), K = [], s = 0; s < c.length; s++) {
    var M = c[s], v = s * 2, u = M * 2;
    y[v] = h[u], y[v + 1] = h[u + 1], L[v] = g[u], L[v + 1] = g[u + 1], A[v] = N[u], A[v + 1] = N[u + 1], F[v] = P[u], F[v + 1] = P[u + 1], K[s] = V[M];
  }
  return {
    current: y,
    next: L,
    stackedOnCurrent: A,
    stackedOnNext: F,
    status: K
  };
}
S(w, "lineAnimationDiff");
export {
  w as default
};
