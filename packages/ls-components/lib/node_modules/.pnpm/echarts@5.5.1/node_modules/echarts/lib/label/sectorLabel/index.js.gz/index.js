var E = Object.defineProperty;
var C = (r, t) => E(r, "name", { value: t, configurable: !0 });
import { calculateTextPosition as w } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/contain/text/index.js";
import { isNumber as I, isArray as D } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
function V(r, t) {
  t = t || {};
  var k = t.isRoundCap;
  return function(n, i, S) {
    var p = i.position;
    if (!p || p instanceof Array)
      return w(n, i, S);
    var y = r(p), e = i.distance != null ? i.distance : 5, h = this.shape, a = h.cx, c = h.cy, b = h.r, M = h.r0, l = (b + M) / 2, s = h.startAngle, u = h.endAngle, d = (s + u) / 2, x = k ? Math.abs(b - M) / 2 : 0, o = Math.cos, A = Math.sin, g = a + b * o(s), v = c + b * A(s), f = "left", m = "top";
    switch (y) {
      case "startArc":
        g = a + (M - e) * o(d), v = c + (M - e) * A(d), f = "center", m = "top";
        break;
      case "insideStartArc":
        g = a + (M + e) * o(d), v = c + (M + e) * A(d), f = "center", m = "bottom";
        break;
      case "startAngle":
        g = a + l * o(s) + P(s, e + x, !1), v = c + l * A(s) + T(s, e + x, !1), f = "right", m = "middle";
        break;
      case "insideStartAngle":
        g = a + l * o(s) + P(s, -e + x, !1), v = c + l * A(s) + T(s, -e + x, !1), f = "left", m = "middle";
        break;
      case "middle":
        g = a + l * o(d), v = c + l * A(d), f = "center", m = "middle";
        break;
      case "endArc":
        g = a + (b + e) * o(d), v = c + (b + e) * A(d), f = "center", m = "bottom";
        break;
      case "insideEndArc":
        g = a + (b - e) * o(d), v = c + (b - e) * A(d), f = "center", m = "top";
        break;
      case "endAngle":
        g = a + l * o(u) + P(u, e + x, !0), v = c + l * A(u) + T(u, e + x, !0), f = "left", m = "middle";
        break;
      case "insideEndAngle":
        g = a + l * o(u) + P(u, -e + x, !0), v = c + l * A(u) + T(u, -e + x, !0), f = "right", m = "middle";
        break;
      default:
        return w(n, i, S);
    }
    return n = n || {}, n.x = g, n.y = v, n.align = f, n.verticalAlign = m, n;
  };
}
C(V, "createSectorCalculateTextPosition");
function X(r, t, k, n) {
  if (I(n)) {
    r.setTextConfig({
      rotation: n
    });
    return;
  } else if (D(t)) {
    r.setTextConfig({
      rotation: 0
    });
    return;
  }
  var i = r.shape, S = i.clockwise ? i.startAngle : i.endAngle, p = i.clockwise ? i.endAngle : i.startAngle, y = (S + p) / 2, e, h = k(t);
  switch (h) {
    case "startArc":
    case "insideStartArc":
    case "middle":
    case "insideEndArc":
    case "endArc":
      e = y;
      break;
    case "startAngle":
    case "insideStartAngle":
      e = S;
      break;
    case "endAngle":
    case "insideEndAngle":
      e = p;
      break;
    default:
      r.setTextConfig({
        rotation: 0
      });
      return;
  }
  var a = Math.PI * 1.5 - e;
  h === "middle" && a > Math.PI / 2 && a < Math.PI * 1.5 && (a -= Math.PI), r.setTextConfig({
    rotation: a
  });
}
C(X, "setSectorTextRotation");
function P(r, t, k) {
  return t * Math.sin(r) * (k ? -1 : 1);
}
C(P, "adjustAngleDistanceX");
function T(r, t, k) {
  return t * Math.cos(r) * (k ? 1 : -1);
}
C(T, "adjustAngleDistanceY");
export {
  V as createSectorCalculateTextPosition,
  X as setSectorTextRotation
};
