var $ = Object.defineProperty;
var C = (d, a) => $(d, "name", { value: a, configurable: !0 });
import { __extends as E } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { bind as R, each as S, trim as tt, extend as V, isString as L, clone as N, isArray as A, isFunction as U, isObject as et } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import P from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/env/index.js";
import it from "../TooltipHTMLContent/index.js";
import ot from "../TooltipRichContent/index.js";
import { convertToColorString as W, formatTpl as rt } from "../../../util/format/index.js";
import { parsePercent as q } from "../../../util/number/index.js";
import "../../../util/graphic/index.js";
import nt from "../../axisPointer/findPointFromSeries/index.js";
import { getLayoutRect as at } from "../../../util/layout/index.js";
import B from "../../../model/Model/index.js";
import { register as st, unregister as lt } from "../../axisPointer/globalListener/index.js";
import { getAxisRawValue as ft } from "../../../coord/axisHelper/index.js";
import { getValueLabel as ht } from "../../axisPointer/viewHelper/index.js";
import { getTooltipRenderMode as ut, preParseFinder as dt, queryReferringComponents as vt } from "../../../util/model/index.js";
import pt from "../../../view/Component/index.js";
import { format as mt } from "../../../util/time/index.js";
import { getECData as I } from "../../../util/innerStore/index.js";
import { shouldTooltipConfine as gt } from "../helper/index.js";
import { normalizeTooltipFormatResult as j } from "../../../model/mixin/dataFormat/index.js";
import { createTooltipMarkup as G, buildTooltipMarkup as Q, TooltipMarkupStyleCreator as H } from "../tooltipMarkup/index.js";
import { findEventDispatcher as ct } from "../../../util/event/index.js";
import { createOrUpdate as _t, clear as Z } from "../../../util/throttle/index.js";
import Tt from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
import { encodeHTML as xt } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/dom/index.js";
var yt = new Tt({
  shape: {
    x: -1,
    y: -1,
    width: 2,
    height: 2
  }
}), $t = (
  /** @class */
  function(d) {
    E(a, d);
    function a() {
      var o = d !== null && d.apply(this, arguments) || this;
      return o.type = a.type, o;
    }
    return C(a, "TooltipView"), a.prototype.init = function(o, r) {
      if (!(P.node || !r.getDom())) {
        var e = o.getComponent("tooltip"), t = this._renderMode = ut(e.get("renderMode"));
        this._tooltipContent = t === "richText" ? new ot(r) : new it(r, {
          appendTo: e.get("appendToBody", !0) ? "body" : e.get("appendTo", !0)
        });
      }
    }, a.prototype.render = function(o, r, e) {
      if (!(P.node || !e.getDom())) {
        this.group.removeAll(), this._tooltipModel = o, this._ecModel = r, this._api = e;
        var t = this._tooltipContent;
        t.update(o), t.setEnterable(o.get("enterable")), this._initGlobalListener(), this._keepShow(), this._renderMode !== "richText" && o.get("transitionDuration") ? _t(this, "_updatePosition", 50, "fixRate") : Z(this, "_updatePosition");
      }
    }, a.prototype._initGlobalListener = function() {
      var o = this._tooltipModel, r = o.get("triggerOn");
      st("itemTooltip", this._api, R(function(e, t, i) {
        r !== "none" && (r.indexOf(e) >= 0 ? this._tryShow(t, i) : e === "leave" && this._hide(i));
      }, this));
    }, a.prototype._keepShow = function() {
      var o = this._tooltipModel, r = this._ecModel, e = this._api, t = o.get("triggerOn");
      if (this._lastX != null && this._lastY != null && t !== "none" && t !== "click") {
        var i = this;
        clearTimeout(this._refreshUpdateTimeout), this._refreshUpdateTimeout = setTimeout(function() {
          !e.isDisposed() && i.manuallyShowTip(o, r, e, {
            x: i._lastX,
            y: i._lastY,
            dataByCoordSys: i._lastDataByCoordSys
          });
        });
      }
    }, a.prototype.manuallyShowTip = function(o, r, e, t) {
      if (!(t.from === this.uid || P.node || !e.getDom())) {
        var i = J(t, e);
        this._ticket = "";
        var f = t.dataByCoordSys, n = St(t, r, e);
        if (n) {
          var s = n.el.getBoundingRect().clone();
          s.applyTransform(n.el.transform), this._tryShow({
            offsetX: s.x + s.width / 2,
            offsetY: s.y + s.height / 2,
            target: n.el,
            position: t.position,
            // When manully trigger, the mouse is not on the el, so we'd better to
            // position tooltip on the bottom of the el and display arrow is possible.
            positionDefault: "bottom"
          }, i);
        } else if (t.tooltip && t.x != null && t.y != null) {
          var l = yt;
          l.x = t.x, l.y = t.y, l.update(), I(l).tooltipConfig = {
            name: null,
            option: t.tooltip
          }, this._tryShow({
            offsetX: t.x,
            offsetY: t.y,
            target: l
          }, i);
        } else if (f)
          this._tryShow({
            offsetX: t.x,
            offsetY: t.y,
            position: t.position,
            dataByCoordSys: f,
            tooltipOption: t.tooltipOption
          }, i);
        else if (t.seriesIndex != null) {
          if (this._manuallyAxisShowTip(o, r, e, t))
            return;
          var h = nt(t, r), u = h.point[0], v = h.point[1];
          u != null && v != null && this._tryShow({
            offsetX: u,
            offsetY: v,
            target: h.el,
            position: t.position,
            // When manully trigger, the mouse is not on the el, so we'd better to
            // position tooltip on the bottom of the el and display arrow is possible.
            positionDefault: "bottom"
          }, i);
        } else t.x != null && t.y != null && (e.dispatchAction({
          type: "updateAxisPointer",
          x: t.x,
          y: t.y
        }), this._tryShow({
          offsetX: t.x,
          offsetY: t.y,
          position: t.position,
          target: e.getZr().findHover(t.x, t.y).target
        }, i));
      }
    }, a.prototype.manuallyHideTip = function(o, r, e, t) {
      var i = this._tooltipContent;
      this._tooltipModel && i.hideLater(this._tooltipModel.get("hideDelay")), this._lastX = this._lastY = this._lastDataByCoordSys = null, t.from !== this.uid && this._hide(J(t, e));
    }, a.prototype._manuallyAxisShowTip = function(o, r, e, t) {
      var i = t.seriesIndex, f = t.dataIndex, n = r.getComponent("axisPointer").coordSysAxesInfo;
      if (!(i == null || f == null || n == null)) {
        var s = r.getSeriesByIndex(i);
        if (s) {
          var l = s.getData(), h = k([l.getItemModel(f), s, (s.coordinateSystem || {}).model], this._tooltipModel);
          if (h.get("trigger") === "axis")
            return e.dispatchAction({
              type: "updateAxisPointer",
              seriesIndex: i,
              dataIndex: f,
              position: t.position
            }), !0;
        }
      }
    }, a.prototype._tryShow = function(o, r) {
      var e = o.target, t = this._tooltipModel;
      if (t) {
        this._lastX = o.offsetX, this._lastY = o.offsetY;
        var i = o.dataByCoordSys;
        if (i && i.length)
          this._showAxisTooltip(i, o);
        else if (e) {
          var f = I(e);
          if (f.ssrType === "legend")
            return;
          this._lastDataByCoordSys = null;
          var n, s;
          ct(e, function(l) {
            if (I(l).dataIndex != null)
              return n = l, !0;
            if (I(l).tooltipConfig != null)
              return s = l, !0;
          }, !0), n ? this._showSeriesItemTooltip(o, n, r) : s ? this._showComponentItemTooltip(o, s, r) : this._hide(r);
        } else
          this._lastDataByCoordSys = null, this._hide(r);
      }
    }, a.prototype._showOrMove = function(o, r) {
      var e = o.get("showDelay");
      r = R(r, this), clearTimeout(this._showTimout), e > 0 ? this._showTimout = setTimeout(r, e) : r();
    }, a.prototype._showAxisTooltip = function(o, r) {
      var e = this._ecModel, t = this._tooltipModel, i = [r.offsetX, r.offsetY], f = k([r.tooltipOption], t), n = this._renderMode, s = [], l = G("section", {
        blocks: [],
        noHeader: !0
      }), h = [], u = new H();
      S(o, function(T) {
        S(T.dataByAxis, function(g) {
          var x = e.getComponent(g.axisDim + "Axis", g.axisIndex), M = g.value;
          if (!(!x || M == null)) {
            var w = ht(M, x.axis, e, g.seriesDataIndices, g.valueLabelOpt), b = G("section", {
              header: w,
              noHeader: !tt(w),
              sortBlocks: !0,
              blocks: []
            });
            l.blocks.push(b), S(g.seriesDataIndices, function(D) {
              var O = e.getSeriesByIndex(D.seriesIndex), z = D.dataIndexInside, y = O.getDataParams(z);
              if (!(y.dataIndex < 0)) {
                y.axisDim = g.axisDim, y.axisIndex = g.axisIndex, y.axisType = g.axisType, y.axisId = g.axisId, y.axisValue = ft(x.axis, {
                  value: M
                }), y.axisValueLabel = w, y.marker = u.makeTooltipMarker("item", W(y.color), n);
                var X = j(O.formatTooltip(z, !0, null)), Y = X.frag;
                if (Y) {
                  var F = k([O], t).get("valueFormatter");
                  b.blocks.push(F ? V({
                    valueFormatter: F
                  }, Y) : Y);
                }
                X.text && h.push(X.text), s.push(y);
              }
            });
          }
        });
      }), l.blocks.reverse(), h.reverse();
      var v = r.position, c = f.get("order"), m = Q(l, u, n, c, e.get("useUTC"), f.get("textStyle"));
      m && h.unshift(m);
      var _ = n === "richText" ? `

` : "<br/>", p = h.join(_);
      this._showOrMove(f, function() {
        this._updateContentNotChangedOnAxis(o, s) ? this._updatePosition(f, v, i[0], i[1], this._tooltipContent, s) : this._showTooltipContent(f, p, s, Math.random() + "", i[0], i[1], v, null, u);
      });
    }, a.prototype._showSeriesItemTooltip = function(o, r, e) {
      var t = this._ecModel, i = I(r), f = i.seriesIndex, n = t.getSeriesByIndex(f), s = i.dataModel || n, l = i.dataIndex, h = i.dataType, u = s.getData(h), v = this._renderMode, c = o.positionDefault, m = k([u.getItemModel(l), s, n && (n.coordinateSystem || {}).model], this._tooltipModel, c ? {
        position: c
      } : null), _ = m.get("trigger");
      if (!(_ != null && _ !== "item")) {
        var p = s.getDataParams(l, h), T = new H();
        p.marker = T.makeTooltipMarker("item", W(p.color), v);
        var g = j(s.formatTooltip(l, !1, h)), x = m.get("order"), M = m.get("valueFormatter"), w = g.frag, b = w ? Q(M ? V({
          valueFormatter: M
        }, w) : w, T, v, x, t.get("useUTC"), m.get("textStyle")) : g.text, D = "item_" + s.name + "_" + l;
        this._showOrMove(m, function() {
          this._showTooltipContent(m, b, p, D, o.offsetX, o.offsetY, o.position, o.target, T);
        }), e({
          type: "showTip",
          dataIndexInside: l,
          dataIndex: u.getRawIndex(l),
          seriesIndex: f,
          from: this.uid
        });
      }
    }, a.prototype._showComponentItemTooltip = function(o, r, e) {
      var t = this._renderMode === "html", i = I(r), f = i.tooltipConfig, n = f.option || {}, s = n.encodeHTMLContent;
      if (L(n)) {
        var l = n;
        n = {
          content: l,
          // Fixed formatter
          formatter: l
        }, s = !0;
      }
      s && t && n.content && (n = N(n), n.content = xt(n.content));
      var h = [n], u = this._ecModel.getComponent(i.componentMainType, i.componentIndex);
      u && h.push(u), h.push({
        formatter: n.content
      });
      var v = o.positionDefault, c = k(h, this._tooltipModel, v ? {
        position: v
      } : null), m = c.get("content"), _ = Math.random() + "", p = new H();
      this._showOrMove(c, function() {
        var T = N(c.get("formatterParams") || {});
        this._showTooltipContent(c, m, T, _, o.offsetX, o.offsetY, o.position, r, p);
      }), e({
        type: "showTip",
        from: this.uid
      });
    }, a.prototype._showTooltipContent = function(o, r, e, t, i, f, n, s, l) {
      if (this._ticket = "", !(!o.get("showContent") || !o.get("show"))) {
        var h = this._tooltipContent;
        h.setEnterable(o.get("enterable"));
        var u = o.get("formatter");
        n = n || o.get("position");
        var v = r, c = this._getNearestPoint([i, f], e, o.get("trigger"), o.get("borderColor")), m = c.color;
        if (u)
          if (L(u)) {
            var _ = o.ecModel.get("useUTC"), p = A(e) ? e[0] : e, T = p && p.axisType && p.axisType.indexOf("time") >= 0;
            v = u, T && (v = mt(p.axisValue, v, _)), v = rt(v, e, !0);
          } else if (U(u)) {
            var g = R(function(x, M) {
              x === this._ticket && (h.setContent(M, l, o, m, n), this._updatePosition(o, n, i, f, h, e, s));
            }, this);
            this._ticket = t, v = u(e, t, g);
          } else
            v = u;
        h.setContent(v, l, o, m, n), h.show(o, m), this._updatePosition(o, n, i, f, h, e, s);
      }
    }, a.prototype._getNearestPoint = function(o, r, e, t) {
      if (e === "axis" || A(r))
        return {
          color: t || (this._renderMode === "html" ? "#fff" : "none")
        };
      if (!A(r))
        return {
          color: t || r.color || r.borderColor
        };
    }, a.prototype._updatePosition = function(o, r, e, t, i, f, n) {
      var s = this._api.getWidth(), l = this._api.getHeight();
      r = r || o.get("position");
      var h = i.getSize(), u = o.get("align"), v = o.get("verticalAlign"), c = n && n.getBoundingRect().clone();
      if (n && c.applyTransform(n.transform), U(r) && (r = r([e, t], f, i.el, c, {
        viewSize: [s, l],
        contentSize: h.slice()
      })), A(r))
        e = q(r[0], s), t = q(r[1], l);
      else if (et(r)) {
        var m = r;
        m.width = h[0], m.height = h[1];
        var _ = at(m, {
          width: s,
          height: l
        });
        e = _.x, t = _.y, u = null, v = null;
      } else if (L(r) && n) {
        var p = wt(r, c, h, o.get("borderWidth"));
        e = p[0], t = p[1];
      } else {
        var p = Ct(e, t, i, s, l, u ? null : 20, v ? null : 20);
        e = p[0], t = p[1];
      }
      if (u && (e -= K(u) ? h[0] / 2 : u === "right" ? h[0] : 0), v && (t -= K(v) ? h[1] / 2 : v === "bottom" ? h[1] : 0), gt(o)) {
        var p = Mt(e, t, i, s, l);
        e = p[0], t = p[1];
      }
      i.moveTo(e, t);
    }, a.prototype._updateContentNotChangedOnAxis = function(o, r) {
      var e = this._lastDataByCoordSys, t = this._cbParamsList, i = !!e && e.length === o.length;
      return i && S(e, function(f, n) {
        var s = f.dataByAxis || [], l = o[n] || {}, h = l.dataByAxis || [];
        i = i && s.length === h.length, i && S(s, function(u, v) {
          var c = h[v] || {}, m = u.seriesDataIndices || [], _ = c.seriesDataIndices || [];
          i = i && u.value === c.value && u.axisType === c.axisType && u.axisId === c.axisId && m.length === _.length, i && S(m, function(p, T) {
            var g = _[T];
            i = i && p.seriesIndex === g.seriesIndex && p.dataIndex === g.dataIndex;
          }), t && S(u.seriesDataIndices, function(p) {
            var T = p.seriesIndex, g = r[T], x = t[T];
            g && x && x.data !== g.data && (i = !1);
          });
        });
      }), this._lastDataByCoordSys = o, this._cbParamsList = r, !!i;
    }, a.prototype._hide = function(o) {
      this._lastDataByCoordSys = null, o({
        type: "hideTip",
        from: this.uid
      });
    }, a.prototype.dispose = function(o, r) {
      P.node || !r.getDom() || (Z(this, "_updatePosition"), this._tooltipContent.dispose(), lt("itemTooltip", r));
    }, a.type = "tooltip", a;
  }(pt)
);
function k(d, a, o) {
  var r = a.ecModel, e;
  o ? (e = new B(o, r, r), e = new B(a.option, e, r)) : e = a;
  for (var t = d.length - 1; t >= 0; t--) {
    var i = d[t];
    i && (i instanceof B && (i = i.get("tooltip", !0)), L(i) && (i = {
      formatter: i
    }), i && (e = new B(i, e, r)));
  }
  return e;
}
C(k, "buildTooltipModel");
function J(d, a) {
  return d.dispatchAction || R(a.dispatchAction, a);
}
C(J, "makeDispatchAction");
function Ct(d, a, o, r, e, t, i) {
  var f = o.getSize(), n = f[0], s = f[1];
  return t != null && (d + n + t + 2 > r ? d -= n + t : d += t), i != null && (a + s + i > e ? a -= s + i : a += i), [d, a];
}
C(Ct, "refixTooltipPosition");
function Mt(d, a, o, r, e) {
  var t = o.getSize(), i = t[0], f = t[1];
  return d = Math.min(d + i, r) - i, a = Math.min(a + f, e) - f, d = Math.max(d, 0), a = Math.max(a, 0), [d, a];
}
C(Mt, "confineTooltipPosition");
function wt(d, a, o, r) {
  var e = o[0], t = o[1], i = Math.ceil(Math.SQRT2 * r) + 8, f = 0, n = 0, s = a.width, l = a.height;
  switch (d) {
    case "inside":
      f = a.x + s / 2 - e / 2, n = a.y + l / 2 - t / 2;
      break;
    case "top":
      f = a.x + s / 2 - e / 2, n = a.y - t - i;
      break;
    case "bottom":
      f = a.x + s / 2 - e / 2, n = a.y + l + i;
      break;
    case "left":
      f = a.x - e - i, n = a.y + l / 2 - t / 2;
      break;
    case "right":
      f = a.x + s + i, n = a.y + l / 2 - t / 2;
  }
  return [f, n];
}
C(wt, "calcTooltipPosition");
function K(d) {
  return d === "center" || d === "middle";
}
C(K, "isCenterAlign");
function St(d, a, o) {
  var r = dt(d).queryOptionMap, e = r.keys()[0];
  if (!(!e || e === "series")) {
    var t = vt(a, e, r.get(e), {
      useDefault: !1,
      enableAll: !1,
      enableNone: !1
    }), i = t.models[0];
    if (i) {
      var f = o.getViewOfComponentModel(i), n;
      if (f.group.traverse(function(s) {
        var l = I(s).tooltipConfig;
        if (l && l.name === d.name)
          return n = s, !0;
      }), n)
        return {
          componentMainType: e,
          componentIndex: i.componentIndex,
          el: n
        };
    }
  }
}
C(St, "findComponentReference");
export {
  $t as default
};
