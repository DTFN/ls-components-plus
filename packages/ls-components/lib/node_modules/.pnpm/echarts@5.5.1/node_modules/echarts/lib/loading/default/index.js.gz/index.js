var c = Object.defineProperty;
var m = (t, e) => c(t, "name", { value: e, configurable: !0 });
import { defaults as v } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import z from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import u from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
import S from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import w from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Arc/index.js";
var a = Math.PI;
function A(t, e) {
  e = e || {}, v(e, {
    text: "loading",
    textColor: "#000",
    fontSize: 12,
    fontWeight: "normal",
    fontStyle: "normal",
    fontFamily: "sans-serif",
    maskColor: "rgba(255, 255, 255, 0.8)",
    showSpinner: !0,
    color: "#5470c6",
    spinnerRadius: 10,
    lineWidth: 5,
    zlevel: 0
  });
  var n = new z(), o = new u({
    style: {
      fill: e.maskColor
    },
    zlevel: e.zlevel,
    z: 1e4
  });
  n.add(o);
  var h = new S({
    style: {
      text: e.text,
      fill: e.textColor,
      fontSize: e.fontSize,
      fontWeight: e.fontWeight,
      fontStyle: e.fontStyle,
      fontFamily: e.fontFamily
    },
    zlevel: e.zlevel,
    z: 10001
  }), d = new u({
    style: {
      fill: "none"
    },
    textContent: h,
    textConfig: {
      position: "right",
      distance: 10
    },
    zlevel: e.zlevel,
    z: 10001
  });
  n.add(d);
  var l;
  return e.showSpinner && (l = new w({
    shape: {
      startAngle: -a / 2,
      endAngle: -a / 2 + 0.1,
      r: e.spinnerRadius
    },
    style: {
      stroke: e.color,
      lineCap: "round",
      lineWidth: e.lineWidth
    },
    zlevel: e.zlevel,
    z: 10001
  }), l.animateShape(!0).when(1e3, {
    endAngle: a * 3 / 2
  }).start("circularInOut"), l.animateShape(!0).when(1e3, {
    startAngle: a * 3 / 2
  }).delay(300).start("circularInOut"), n.add(l)), n.resize = function() {
    var r = h.getBoundingRect().width, i = e.showSpinner ? e.spinnerRadius : 0, f = (t.getWidth() - i * 2 - (e.showSpinner && r ? 10 : 0) - r) / 2 - (e.showSpinner && r ? 0 : 5 + r / 2) + (e.showSpinner ? 0 : r / 2) + (r ? 0 : i), g = t.getHeight() / 2;
    e.showSpinner && l.setShape({
      cx: f,
      cy: g
    }), d.setShape({
      x: f - i,
      y: g - i,
      width: i * 2,
      height: i * 2
    }), o.setShape({
      x: 0,
      y: 0,
      width: t.getWidth(),
      height: t.getHeight()
    });
  }, n.resize(), n;
}
m(A, "defaultLoading");
export {
  A as default
};
