var y = Object.defineProperty;
var u = (o, t) => y(o, "name", { value: t, configurable: !0 });
import { __extends as g } from "../../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { bind as I, clone as Z, each as _ } from "../../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import M from "../../../helper/BrushController/index.js";
import b from "../../../helper/BrushTargetManager/index.js";
import { push as C, pop as S, count as k } from "../../../dataZoom/history/index.js";
import D from "../../../helper/sliderMove/index.js";
import { ToolboxFeature as T } from "../../featureManager/index.js";
import { parseFinder as B, makeInternalComponentId as O } from "../../../../util/model/index.js";
import { registerInternalOptionCreator as V } from "../../../../model/internalComponentCreator/index.js";
var A = _, H = O("toolbox-dataZoom_"), q = (
  /** @class */
  function(o) {
    g(t, o);
    function t() {
      return o !== null && o.apply(this, arguments) || this;
    }
    return u(t, "DataZoomFeature"), t.prototype.render = function(n, e, r, i) {
      this._brushController || (this._brushController = new M(r.getZr()), this._brushController.on("brush", I(this._onBrush, this)).mount()), F(n, e, this, i, r), E(n, e);
    }, t.prototype.onclick = function(n, e, r) {
      w[r].call(this);
    }, t.prototype.remove = function(n, e) {
      this._brushController && this._brushController.unmount();
    }, t.prototype.dispose = function(n, e) {
      this._brushController && this._brushController.dispose();
    }, t.prototype._onBrush = function(n) {
      var e = n.areas;
      if (!n.isEnd || !e.length)
        return;
      var r = {}, i = this.ecModel;
      this._brushController.updateCovers([]);
      var p = new b(v(this.model), i, {
        include: ["grid"]
      });
      p.matchOutputRanges(e, i, function(h, d, a) {
        if (a.type === "cartesian2d") {
          var l = h.brushType;
          l === "rect" ? (c("x", a, d[0]), c("y", a, d[1])) : c({
            lineX: "x",
            lineY: "y"
          }[l], a, d);
        }
      }), C(i, r), this._dispatchZoomAction(r);
      function c(h, d, a) {
        var l = d.getAxis(h), m = l.model, x = s(h, m, i), f = x.findRepresentativeAxisProxy(m).getMinMaxSpan();
        (f.minValueSpan != null || f.maxValueSpan != null) && (a = D(0, a.slice(), l.scale.getExtent(), 0, f.minValueSpan, f.maxValueSpan)), x && (r[x.id] = {
          dataZoomId: x.id,
          startValue: a[0],
          endValue: a[1]
        });
      }
      u(c, "setBatch");
      function s(h, d, a) {
        var l;
        return a.eachComponent({
          mainType: "dataZoom",
          subType: "select"
        }, function(m) {
          var x = m.getAxisModel(h, d.componentIndex);
          x && (l = m);
        }), l;
      }
      u(s, "findDataZoom");
    }, t.prototype._dispatchZoomAction = function(n) {
      var e = [];
      A(n, function(r, i) {
        e.push(Z(r));
      }), e.length && this.api.dispatchAction({
        type: "dataZoom",
        from: this.uid,
        batch: e
      });
    }, t.getDefaultOption = function(n) {
      var e = {
        show: !0,
        filterMode: "filter",
        // Icon group
        icon: {
          zoom: "M0,13.5h26.9 M13.5,26.9V0 M32.1,13.5H58V58H13.5 V32.1",
          back: "M22,1.4L9.9,13.5l12.3,12.3 M10.3,13.5H54.9v44.6 H10.3v-26"
        },
        // `zoom`, `back`
        title: n.getLocaleModel().get(["toolbox", "dataZoom", "title"]),
        brushStyle: {
          borderWidth: 0,
          color: "rgba(210,219,238,0.2)"
        }
      };
      return e;
    }, t;
  }(T)
), w = {
  zoom: /* @__PURE__ */ u(function() {
    var o = !this._isZoomActive;
    this.api.dispatchAction({
      type: "takeGlobalCursor",
      key: "dataZoomSelect",
      dataZoomSelectActive: o
    });
  }, "zoom"),
  back: /* @__PURE__ */ u(function() {
    this._dispatchZoomAction(S(this.ecModel));
  }, "back")
};
function v(o) {
  var t = {
    xAxisIndex: o.get("xAxisIndex", !0),
    yAxisIndex: o.get("yAxisIndex", !0),
    xAxisId: o.get("xAxisId", !0),
    yAxisId: o.get("yAxisId", !0)
  };
  return t.xAxisIndex == null && t.xAxisId == null && (t.xAxisIndex = "all"), t.yAxisIndex == null && t.yAxisId == null && (t.yAxisIndex = "all"), t;
}
u(v, "makeAxisFinder");
function E(o, t) {
  o.setIconStatus("back", k(t) > 1 ? "emphasis" : "normal");
}
u(E, "updateBackBtnStatus");
function F(o, t, n, e, r) {
  var i = n._isZoomActive;
  e && e.type === "takeGlobalCursor" && (i = e.key === "dataZoomSelect" ? e.dataZoomSelectActive : !1), n._isZoomActive = i, o.setIconStatus("zoom", i ? "emphasis" : "normal");
  var p = new b(v(o), t, {
    include: ["grid"]
  }), c = p.makePanelOpts(r, function(s) {
    return s.xAxisDeclared && !s.yAxisDeclared ? "lineX" : !s.xAxisDeclared && s.yAxisDeclared ? "lineY" : "rect";
  });
  n._brushController.setPanels(c).enableBrush(i && c.length ? {
    brushType: "auto",
    brushStyle: o.getModel("brushStyle").getItemStyle()
  } : !1);
}
u(F, "updateZoomBtnStatus");
V("dataZoom", function(o) {
  var t = o.getComponent("toolbox", 0), n = ["feature", "dataZoom"];
  if (!t || t.get(n) == null)
    return;
  var e = t.getModel(n), r = [], i = v(e), p = B(o, i);
  A(p.xAxisModels, function(s) {
    return c(s, "xAxis", "xAxisIndex");
  }), A(p.yAxisModels, function(s) {
    return c(s, "yAxis", "yAxisIndex");
  });
  function c(s, h, d) {
    var a = s.componentIndex, l = {
      type: "select",
      $fromToolbox: !0,
      // Default to be filter
      filterMode: e.get("filterMode", !0) || "filter",
      // Id for merge mapping.
      id: H + h + a
    };
    l[d] = a, r.push(l);
  }
  return u(c, "buildInternalOptions"), r;
});
export {
  q as default
};
