var C = Object.defineProperty;
var S = (f, s) => C(f, "name", { value: s, configurable: !0 });
import { __extends as P } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { extend as y, retrieve3 as x } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { setStatesStylesFromModel as w, toggleHoverEmphasis as D } from "../../../util/states/index.js";
import G from "../../../view/Chart/index.js";
import _ from "../labelLayout/index.js";
import { setLabelLineStyle as E, getLabelLineStatesModels as F } from "../../../label/labelGuideHelper/index.js";
import { setLabelStyle as N, getLabelStatesModels as O } from "../../../label/labelStyle/index.js";
import { getSectorCornerRadius as d } from "../../helper/sectorHelper/index.js";
import { initProps as L, updateProps as A, saveOldStyle as V, removeElementWithFadeOut as z } from "../../../animation/basicTransition/index.js";
import { getSeriesLayoutData as k, getBasicPieLayout as R } from "../pieLayout/index.js";
import U from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import X from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Polyline/index.js";
import I from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Sector/index.js";
var Y = (
  /** @class */
  function(f) {
    P(s, f);
    function s(t, r, n) {
      var l = f.call(this) || this;
      l.z2 = 2;
      var e = new U();
      return l.setTextContent(e), l.updateData(t, r, n, !0), l;
    }
    return S(s, "PiePiece"), s.prototype.updateData = function(t, r, n, l) {
      var e = this, o = t.hostModel, i = t.getItemModel(r), p = i.getModel("emphasis"), a = t.getItemLayout(r), u = y(d(i.getModel("itemStyle"), a, !0), a);
      if (isNaN(u.startAngle)) {
        e.setShape(u);
        return;
      }
      if (l) {
        e.setShape(u);
        var h = o.getShallow("animationType");
        o.ecModel.ssr ? (L(e, {
          scaleX: 0,
          scaleY: 0
        }, o, {
          dataIndex: r,
          isFrom: !0
        }), e.originX = u.cx, e.originY = u.cy) : h === "scale" ? (e.shape.r = a.r0, L(e, {
          shape: {
            r: a.r
          }
        }, o, r)) : n != null ? (e.setShape({
          startAngle: n,
          endAngle: n
        }), L(e, {
          shape: {
            startAngle: a.startAngle,
            endAngle: a.endAngle
          }
        }, o, r)) : (e.shape.endAngle = a.startAngle, A(e, {
          shape: {
            endAngle: a.endAngle
          }
        }, o, r));
      } else
        V(e), A(e, {
          shape: u
        }, o, r);
      e.useStyle(t.getItemVisual(r, "style")), w(e, i);
      var m = (a.startAngle + a.endAngle) / 2, c = o.get("selectedOffset"), g = Math.cos(m) * c, v = Math.sin(m) * c, b = i.getShallow("cursor");
      b && e.attr("cursor", b), this._updateLabel(o, t, r), e.ensureState("emphasis").shape = y({
        r: a.r + (p.get("scale") && p.get("scaleSize") || 0)
      }, d(p.getModel("itemStyle"), a)), y(e.ensureState("select"), {
        x: g,
        y: v,
        shape: d(i.getModel(["select", "itemStyle"]), a)
      }), y(e.ensureState("blur"), {
        shape: d(i.getModel(["blur", "itemStyle"]), a)
      });
      var M = e.getTextGuideLine(), T = e.getTextContent();
      M && y(M.ensureState("select"), {
        x: g,
        y: v
      }), y(T.ensureState("select"), {
        x: g,
        y: v
      }), D(this, p.get("focus"), p.get("blurScope"), p.get("disabled"));
    }, s.prototype._updateLabel = function(t, r, n) {
      var l = this, e = r.getItemModel(n), o = e.getModel("labelLine"), i = r.getItemVisual(n, "style"), p = i && i.fill, a = i && i.opacity;
      N(l, O(e), {
        labelFetcher: r.hostModel,
        labelDataIndex: n,
        inheritColor: p,
        defaultOpacity: a,
        defaultText: t.getFormattedLabel(n, "normal") || r.getName(n)
      });
      var u = l.getTextContent();
      l.setTextConfig({
        // reset position, rotation
        position: null,
        rotation: null
      }), u.attr({
        z2: 10
      });
      var h = t.get(["label", "position"]);
      if (h !== "outside" && h !== "outer")
        l.removeTextGuideLine();
      else {
        var m = this.getTextGuideLine();
        m || (m = new X(), this.setTextGuideLine(m)), E(this, F(e), {
          stroke: p,
          opacity: x(o.get(["lineStyle", "opacity"]), a, 1)
        });
      }
    }, s;
  }(I)
), oe = (
  /** @class */
  function(f) {
    P(s, f);
    function s() {
      var t = f !== null && f.apply(this, arguments) || this;
      return t.ignoreLabelLineUpdate = !0, t;
    }
    return S(s, "PieView"), s.prototype.render = function(t, r, n, l) {
      var e = t.getData(), o = this._data, i = this.group, p;
      if (!o && e.count() > 0) {
        for (var a = e.getItemLayout(0), u = 1; isNaN(a && a.startAngle) && u < e.count(); ++u)
          a = e.getItemLayout(u);
        a && (p = a.startAngle);
      }
      if (this._emptyCircleSector && i.remove(this._emptyCircleSector), e.count() === 0 && t.get("showEmptyCircle")) {
        var h = k(t), m = new I({
          shape: y(R(t, n), h)
        });
        m.useStyle(t.getModel("emptyCircleStyle").getItemStyle()), this._emptyCircleSector = m, i.add(m);
      }
      e.diff(o).add(function(c) {
        var g = new Y(e, c, p);
        e.setItemGraphicEl(c, g), i.add(g);
      }).update(function(c, g) {
        var v = o.getItemGraphicEl(g);
        v.updateData(e, c, p), v.off("click"), i.add(v), e.setItemGraphicEl(c, v);
      }).remove(function(c) {
        var g = o.getItemGraphicEl(c);
        z(g, t, c);
      }).execute(), _(t), t.get("animationTypeUpdate") !== "expansion" && (this._data = e);
    }, s.prototype.dispose = function() {
    }, s.prototype.containPoint = function(t, r) {
      var n = r.getData(), l = n.getItemLayout(0);
      if (l) {
        var e = t[0] - l.cx, o = t[1] - l.cy, i = Math.sqrt(e * e + o * o);
        return i <= l.r && i >= l.r0;
      }
    }, s.type = "pie", s;
  }(G)
);
export {
  oe as default
};
