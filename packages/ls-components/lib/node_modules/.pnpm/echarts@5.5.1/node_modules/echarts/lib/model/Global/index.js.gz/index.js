var $ = Object.defineProperty;
var v = (s, o) => $(s, "name", { value: o, configurable: !0 });
import { __extends as ee } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { assert as D, each as h, createHashMap as _, clone as L, merge as T, extend as j, filter as C, isFunction as te, isString as ne, isObject as K, isArray as re, mixin as oe } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { normalizeToArray as A, mappingToExists as ie, setComponentTypeToKeyInfo as se, isComponentIdInternal as ae, convertOptionIdName as G } from "../../util/model/index.js";
import k from "../Model/index.js";
import g from "../Component/index.js";
import ue from "../globalDefault/index.js";
import { resetSourceDefaulter as le } from "../../data/helper/sourceHelper/index.js";
import { concatInternalOptions as pe } from "../internalComponentCreator/index.js";
import { PaletteMixin as fe } from "../mixin/palette/index.js";
import { error as U, warn as ce } from "../../util/log/index.js";
var I, S, Z, w = "\0_ec_inner", q = 1, he = {
  grid: "GridComponent",
  polar: "PolarComponent",
  geo: "GeoComponent",
  singleAxis: "SingleAxisComponent",
  parallel: "ParallelComponent",
  calendar: "CalendarComponent",
  graphic: "GraphicComponent",
  toolbox: "ToolboxComponent",
  tooltip: "TooltipComponent",
  axisPointer: "AxisPointerComponent",
  brush: "BrushComponent",
  title: "TitleComponent",
  timeline: "TimelineComponent",
  markPoint: "MarkPointComponent",
  markLine: "MarkLineComponent",
  markArea: "MarkAreaComponent",
  legend: "LegendComponent",
  dataZoom: "DataZoomComponent",
  visualMap: "VisualMapComponent",
  // aria: 'AriaComponent',
  // dataset: 'DatasetComponent',
  // Dependencies
  xAxis: "GridComponent",
  yAxis: "GridComponent",
  angleAxis: "PolarComponent",
  radiusAxis: "PolarComponent"
}, ve = {
  line: "LineChart",
  bar: "BarChart",
  pie: "PieChart",
  scatter: "ScatterChart",
  radar: "RadarChart",
  map: "MapChart",
  tree: "TreeChart",
  treemap: "TreemapChart",
  graph: "GraphChart",
  gauge: "GaugeChart",
  funnel: "FunnelChart",
  parallel: "ParallelChart",
  sankey: "SankeyChart",
  boxplot: "BoxplotChart",
  candlestick: "CandlestickChart",
  effectScatter: "EffectScatterChart",
  lines: "LinesChart",
  heatmap: "HeatmapChart",
  pictorialBar: "PictorialBarChart",
  themeRiver: "ThemeRiverChart",
  sunburst: "SunburstChart",
  custom: "CustomChart"
}, E = {};
function ge(s) {
  h(s, function(o, e) {
    if (!g.hasClass(e)) {
      var n = he[e];
      n && !E[n] && (U("Component " + e + ` is used but not imported.
import { ` + n + ` } from 'echarts/components';
echarts.use([` + n + "]);"), E[n] = !0);
    }
  });
}
v(ge, "checkMissingComponents");
var Ce = (
  /** @class */
  function(s) {
    ee(o, s);
    function o() {
      return s !== null && s.apply(this, arguments) || this;
    }
    return v(o, "GlobalModel"), o.prototype.init = function(e, n, t, r, i, p) {
      r = r || {}, this.option = null, this._theme = new k(r), this._locale = new k(i), this._optionManager = p;
    }, o.prototype.setOption = function(e, n, t) {
      process.env.NODE_ENV !== "production" && (D(e != null, "option is null/undefined"), D(e[w] !== q, "please use chart.getOption()"));
      var r = Y(n);
      this._optionManager.setOption(e, t, r), this._resetOption(null, r);
    }, o.prototype.resetOption = function(e, n) {
      return this._resetOption(e, Y(n));
    }, o.prototype._resetOption = function(e, n) {
      var t = !1, r = this._optionManager;
      if (!e || e === "recreate") {
        var i = r.mountOption(e === "recreate");
        process.env.NODE_ENV !== "production" && ge(i), !this.option || e === "recreate" ? Z(this, i) : (this.restoreData(), this._mergeOption(i, n)), t = !0;
      }
      if ((e === "timeline" || e === "media") && this.restoreData(), !e || e === "recreate" || e === "timeline") {
        var p = r.getTimelineOption(this);
        p && (t = !0, this._mergeOption(p, n));
      }
      if (!e || e === "recreate" || e === "media") {
        var l = r.getMediaOption(this);
        l.length && h(l, function(a) {
          t = !0, this._mergeOption(a, n);
        }, this);
      }
      return t;
    }, o.prototype.mergeOption = function(e) {
      this._mergeOption(e, null);
    }, o.prototype._mergeOption = function(e, n) {
      var t = this.option, r = this._componentsMap, i = this._componentsCount, p = [], l = _(), a = n && n.replaceMergeMainTypeMap;
      le(this), h(e, function(u, f) {
        u != null && (g.hasClass(f) ? f && (p.push(f), l.set(f, !0)) : t[f] = t[f] == null ? L(u) : T(t[f], u, !0));
      }), a && a.each(function(u, f) {
        g.hasClass(f) && !l.get(f) && (p.push(f), l.set(f, !0));
      }), g.topologicalTravel(p, g.getAllClassMainTypes(), d, this);
      function d(u) {
        var f = pe(this, u, A(e[u])), M = r.get(u), y = (
          // `!oldCmptList` means init. See the comment in `mappingToExists`
          M ? a && a.get(u) ? "replaceMerge" : "normalMerge" : "replaceAll"
        ), V = ie(M, f, y);
        se(V, u, g), t[u] = null, r.set(u, null), i.set(u, 0);
        var P = [], B = [], F = 0, R, z;
        h(V, function(m, J) {
          var c = m.existing, O = m.newOption;
          if (!O)
            c && (c.mergeOption({}, this), c.optionUpdated({}, !1));
          else {
            var X = u === "series", N = g.getClass(
              u,
              m.keyInfo.subType,
              !X
              // Give a more detailed warn later if series don't exists
            );
            if (!N) {
              if (process.env.NODE_ENV !== "production") {
                var x = m.keyInfo.subType, b = ve[x];
                E[x] || (E[x] = !0, b ? U("Series " + x + ` is used but not imported.
import { ` + b + ` } from 'echarts/charts';
echarts.use([` + b + "]);") : U("Unknown series " + x));
              }
              return;
            }
            if (u === "tooltip") {
              if (R) {
                process.env.NODE_ENV !== "production" && (z || (ce("Currently only one tooltip component is allowed."), z = !0));
                return;
              }
              R = !0;
            }
            if (c && c.constructor === N)
              c.name = m.keyInfo.name, c.mergeOption(O, this), c.optionUpdated(O, !1);
            else {
              var H = j({
                componentIndex: J
              }, m.keyInfo);
              c = new N(O, this, this, H), j(c, H), m.brandNew && (c.__requireNewView = !0), c.init(O, this, this), c.optionUpdated(null, !0);
            }
          }
          c ? (P.push(c.option), B.push(c), F++) : (P.push(void 0), B.push(void 0));
        }, this), t[u] = P, r.set(u, B), i.set(u, F), u === "series" && I(this);
      }
      v(d, "visitComponent"), this._seriesIndices || I(this);
    }, o.prototype.getOption = function() {
      var e = L(this.option);
      return h(e, function(n, t) {
        if (g.hasClass(t)) {
          for (var r = A(n), i = r.length, p = !1, l = i - 1; l >= 0; l--)
            r[l] && !ae(r[l]) ? p = !0 : (r[l] = null, !p && i--);
          r.length = i, e[t] = r;
        }
      }), delete e[w], e;
    }, o.prototype.getTheme = function() {
      return this._theme;
    }, o.prototype.getLocaleModel = function() {
      return this._locale;
    }, o.prototype.setUpdatePayload = function(e) {
      this._payload = e;
    }, o.prototype.getUpdatePayload = function() {
      return this._payload;
    }, o.prototype.getComponent = function(e, n) {
      var t = this._componentsMap.get(e);
      if (t) {
        var r = t[n || 0];
        if (r)
          return r;
        if (n == null) {
          for (var i = 0; i < t.length; i++)
            if (t[i])
              return t[i];
        }
      }
    }, o.prototype.queryComponents = function(e) {
      var n = e.mainType;
      if (!n)
        return [];
      var t = e.index, r = e.id, i = e.name, p = this._componentsMap.get(n);
      if (!p || !p.length)
        return [];
      var l;
      return t != null ? (l = [], h(A(t), function(a) {
        p[a] && l.push(p[a]);
      })) : r != null ? l = Q("id", r, p) : i != null ? l = Q("name", i, p) : l = C(p, function(a) {
        return !!a;
      }), W(l, e);
    }, o.prototype.findComponents = function(e) {
      var n = e.query, t = e.mainType, r = p(n), i = r ? this.queryComponents(r) : C(this._componentsMap.get(t), function(a) {
        return !!a;
      });
      return l(W(i, e));
      function p(a) {
        var d = t + "Index", u = t + "Id", f = t + "Name";
        return a && (a[d] != null || a[u] != null || a[f] != null) ? {
          mainType: t,
          // subType will be filtered finally.
          index: a[d],
          id: a[u],
          name: a[f]
        } : null;
      }
      function l(a) {
        return e.filter ? C(a, e.filter) : a;
      }
    }, o.prototype.eachComponent = function(e, n, t) {
      var r = this._componentsMap;
      if (te(e)) {
        var i = n, p = e;
        r.each(function(u, f) {
          for (var M = 0; u && M < u.length; M++) {
            var y = u[M];
            y && p.call(i, f, y, y.componentIndex);
          }
        });
      } else
        for (var l = ne(e) ? r.get(e) : K(e) ? this.findComponents(e) : null, a = 0; l && a < l.length; a++) {
          var d = l[a];
          d && n.call(t, d, d.componentIndex);
        }
    }, o.prototype.getSeriesByName = function(e) {
      var n = G(e, null);
      return C(this._componentsMap.get("series"), function(t) {
        return !!t && n != null && t.name === n;
      });
    }, o.prototype.getSeriesByIndex = function(e) {
      return this._componentsMap.get("series")[e];
    }, o.prototype.getSeriesByType = function(e) {
      return C(this._componentsMap.get("series"), function(n) {
        return !!n && n.subType === e;
      });
    }, o.prototype.getSeries = function() {
      return C(this._componentsMap.get("series"), function(e) {
        return !!e;
      });
    }, o.prototype.getSeriesCount = function() {
      return this._componentsCount.get("series");
    }, o.prototype.eachSeries = function(e, n) {
      S(this), h(this._seriesIndices, function(t) {
        var r = this._componentsMap.get("series")[t];
        e.call(n, r, t);
      }, this);
    }, o.prototype.eachRawSeries = function(e, n) {
      h(this._componentsMap.get("series"), function(t) {
        t && e.call(n, t, t.componentIndex);
      });
    }, o.prototype.eachSeriesByType = function(e, n, t) {
      S(this), h(this._seriesIndices, function(r) {
        var i = this._componentsMap.get("series")[r];
        i.subType === e && n.call(t, i, r);
      }, this);
    }, o.prototype.eachRawSeriesByType = function(e, n, t) {
      return h(this.getSeriesByType(e), n, t);
    }, o.prototype.isSeriesFiltered = function(e) {
      return S(this), this._seriesIndicesMap.get(e.componentIndex) == null;
    }, o.prototype.getCurrentSeriesIndices = function() {
      return (this._seriesIndices || []).slice();
    }, o.prototype.filterSeries = function(e, n) {
      S(this);
      var t = [];
      h(this._seriesIndices, function(r) {
        var i = this._componentsMap.get("series")[r];
        e.call(n, i, r) && t.push(r);
      }, this), this._seriesIndices = t, this._seriesIndicesMap = _(t);
    }, o.prototype.restoreData = function(e) {
      I(this);
      var n = this._componentsMap, t = [];
      n.each(function(r, i) {
        g.hasClass(i) && t.push(i);
      }), g.topologicalTravel(t, g.getAllClassMainTypes(), function(r) {
        h(n.get(r), function(i) {
          i && (r !== "series" || !de(i, e)) && i.restoreData();
        });
      });
    }, o.internalField = function() {
      I = /* @__PURE__ */ v(function(e) {
        var n = e._seriesIndices = [];
        h(e._componentsMap.get("series"), function(t) {
          t && n.push(t.componentIndex);
        }), e._seriesIndicesMap = _(n);
      }, "reCreateSeriesIndices"), S = /* @__PURE__ */ v(function(e) {
        if (process.env.NODE_ENV !== "production" && !e._seriesIndices)
          throw new Error("Option should contains series.");
      }, "assertSeriesInitialized"), Z = /* @__PURE__ */ v(function(e, n) {
        e.option = {}, e.option[w] = q, e._componentsMap = _({
          series: []
        }), e._componentsCount = _();
        var t = n.aria;
        K(t) && t.enabled == null && (t.enabled = !0), me(n, e._theme.option), T(n, ue, !1), e._mergeOption(n, null);
      }, "initBase");
    }(), o;
  }(k)
);
function de(s, o) {
  if (o) {
    var e = o.seriesIndex, n = o.seriesId, t = o.seriesName;
    return e != null && s.componentIndex !== e || n != null && s.id !== n || t != null && s.name !== t;
  }
}
v(de, "isNotTargetSeries");
function me(s, o) {
  var e = s.color && !s.colorLayer;
  h(o, function(n, t) {
    t === "colorLayer" && e || g.hasClass(t) || (typeof n == "object" ? s[t] = s[t] ? T(s[t], n, !1) : L(n) : s[t] == null && (s[t] = n));
  });
}
v(me, "mergeTheme");
function Q(s, o, e) {
  if (re(o)) {
    var n = _();
    return h(o, function(r) {
      if (r != null) {
        var i = G(r, null);
        i != null && n.set(r, !0);
      }
    }), C(e, function(r) {
      return r && n.get(r[s]);
    });
  } else {
    var t = G(o, null);
    return C(e, function(r) {
      return r && t != null && r[s] === t;
    });
  }
}
v(Q, "queryByIdOrName");
function W(s, o) {
  return o.hasOwnProperty("subType") ? C(s, function(e) {
    return e && e.subType === o.subType;
  }) : s;
}
v(W, "filterBySubType");
function Y(s) {
  var o = _();
  return s && h(A(s.replaceMerge), function(e) {
    process.env.NODE_ENV !== "production" && D(g.hasClass(e), '"' + e + '" is not valid component main type in "replaceMerge"'), o.set(e, !0);
  }), {
    replaceMergeMainTypeMap: o
  };
}
v(Y, "normalizeSetOptionInput");
oe(Ce, fe);
export {
  Ce as default
};
