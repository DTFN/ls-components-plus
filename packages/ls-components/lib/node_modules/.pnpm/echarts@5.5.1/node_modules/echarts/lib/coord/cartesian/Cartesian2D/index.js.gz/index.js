var u = Object.defineProperty;
var v = (x, e) => u(x, "name", { value: e, configurable: !0 });
import { __extends as d } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import m from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/BoundingRect/index.js";
import T from "../Cartesian/index.js";
import { invert as D } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/matrix/index.js";
import { applyTransform as f } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/vector/index.js";
var C = ["x", "y"];
function y(x) {
  return x.type === "interval" || x.type === "time";
}
v(y, "canCalculateAffineTransform");
var B = (
  /** @class */
  function(x) {
    d(e, x);
    function e() {
      var t = x !== null && x.apply(this, arguments) || this;
      return t.type = "cartesian2d", t.dimensions = C, t;
    }
    return v(e, "Cartesian2D"), e.prototype.calcAffineTransform = function() {
      this._transform = this._invTransform = null;
      var t = this.getAxis("x").scale, r = this.getAxis("y").scale;
      if (!(!y(t) || !y(r))) {
        var a = t.getExtent(), i = r.getExtent(), n = this.dataToPoint([a[0], i[0]]), o = this.dataToPoint([a[1], i[1]]), s = a[1] - a[0], h = i[1] - i[0];
        if (!(!s || !h)) {
          var c = (o[0] - n[0]) / s, l = (o[1] - n[1]) / h, g = n[0] - a[0] * c, p = n[1] - i[0] * l, A = this._transform = [c, 0, 0, l, g, p];
          this._invTransform = D([], A);
        }
      }
    }, e.prototype.getBaseAxis = function() {
      return this.getAxesByScale("ordinal")[0] || this.getAxesByScale("time")[0] || this.getAxis("x");
    }, e.prototype.containPoint = function(t) {
      var r = this.getAxis("x"), a = this.getAxis("y");
      return r.contain(r.toLocalCoord(t[0])) && a.contain(a.toLocalCoord(t[1]));
    }, e.prototype.containData = function(t) {
      return this.getAxis("x").containData(t[0]) && this.getAxis("y").containData(t[1]);
    }, e.prototype.containZone = function(t, r) {
      var a = this.dataToPoint(t), i = this.dataToPoint(r), n = this.getArea(), o = new m(a[0], a[1], i[0] - a[0], i[1] - a[1]);
      return n.intersect(o);
    }, e.prototype.dataToPoint = function(t, r, a) {
      a = a || [];
      var i = t[0], n = t[1];
      if (this._transform && i != null && isFinite(i) && n != null && isFinite(n))
        return f(a, t, this._transform);
      var o = this.getAxis("x"), s = this.getAxis("y");
      return a[0] = o.toGlobalCoord(o.dataToCoord(i, r)), a[1] = s.toGlobalCoord(s.dataToCoord(n, r)), a;
    }, e.prototype.clampData = function(t, r) {
      var a = this.getAxis("x").scale, i = this.getAxis("y").scale, n = a.getExtent(), o = i.getExtent(), s = a.parse(t[0]), h = i.parse(t[1]);
      return r = r || [], r[0] = Math.min(Math.max(Math.min(n[0], n[1]), s), Math.max(n[0], n[1])), r[1] = Math.min(Math.max(Math.min(o[0], o[1]), h), Math.max(o[0], o[1])), r;
    }, e.prototype.pointToData = function(t, r) {
      var a = [];
      if (this._invTransform)
        return f(a, t, this._invTransform);
      var i = this.getAxis("x"), n = this.getAxis("y");
      return a[0] = i.coordToData(i.toLocalCoord(t[0]), r), a[1] = n.coordToData(n.toLocalCoord(t[1]), r), a;
    }, e.prototype.getOtherAxis = function(t) {
      return this.getAxis(t.dim === "x" ? "y" : "x");
    }, e.prototype.getArea = function(t) {
      t = t || 0;
      var r = this.getAxis("x").getGlobalExtent(), a = this.getAxis("y").getGlobalExtent(), i = Math.min(r[0], r[1]) - t, n = Math.min(a[0], a[1]) - t, o = Math.max(r[0], r[1]) - i + t, s = Math.max(a[0], a[1]) - n + t;
      return new m(i, n, o, s);
    }, e;
  }(T)
);
export {
  C as cartesian2DDimensions,
  B as default
};
