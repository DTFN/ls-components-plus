var v = Object.defineProperty;
var p = (n, r) => v(n, "name", { value: r, configurable: !0 });
import { __extends as y } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { isArray as m, each as s, merge as b, createHashMap as S, map as M, filter as _, indexOf as w, isString as h, isNumber as O } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import C from "../../../model/Model/index.js";
import { isNameSpecified as D } from "../../../util/model/index.js";
import L from "../../../model/Component/index.js";
var N = /* @__PURE__ */ p(function(n, r) {
  if (r === "all")
    return {
      type: "all",
      title: n.getLocaleModel().get(["legend", "selector", "all"])
    };
  if (r === "inverse")
    return {
      type: "inverse",
      title: n.getLocaleModel().get(["legend", "selector", "inverse"])
    };
}, "getDefaultSelectorOptions"), k = (
  /** @class */
  function(n) {
    y(r, n);
    function r() {
      var e = n !== null && n.apply(this, arguments) || this;
      return e.type = r.type, e.layoutMode = {
        type: "box",
        // legend.width/height are maxWidth/maxHeight actually,
        // whereas real width/height is calculated by its content.
        // (Setting {left: 10, right: 10} does not make sense).
        // So consider the case:
        // `setOption({legend: {left: 10});`
        // then `setOption({legend: {right: 10});`
        // The previous `left` should be cleared by setting `ignoreSize`.
        ignoreSize: !0
      }, e;
    }
    return p(r, "LegendModel"), r.prototype.init = function(e, t, i) {
      this.mergeDefaultAndTheme(e, i), e.selected = e.selected || {}, this._updateSelector(e);
    }, r.prototype.mergeOption = function(e, t) {
      n.prototype.mergeOption.call(this, e, t), this._updateSelector(e);
    }, r.prototype._updateSelector = function(e) {
      var t = e.selector, i = this.ecModel;
      t === !0 && (t = e.selector = ["all", "inverse"]), m(t) && s(t, function(o, l) {
        h(o) && (o = {
          type: o
        }), t[l] = b(o, N(i, o.type));
      });
    }, r.prototype.optionUpdated = function() {
      this._updateData(this.ecModel);
      var e = this._data;
      if (e[0] && this.get("selectedMode") === "single") {
        for (var t = !1, i = 0; i < e.length; i++) {
          var o = e[i].get("name");
          if (this.isSelected(o)) {
            this.select(o), t = !0;
            break;
          }
        }
        !t && this.select(e[0].get("name"));
      }
    }, r.prototype._updateData = function(e) {
      var t = [], i = [];
      e.eachRawSeries(function(a) {
        var f = a.name;
        i.push(f);
        var c;
        if (a.legendVisualProvider) {
          var g = a.legendVisualProvider, d = g.getAllNames();
          e.isSeriesFiltered(a) || (i = i.concat(d)), d.length ? t = t.concat(d) : c = !0;
        } else
          c = !0;
        c && D(a) && t.push(a.name);
      }), this._availableNames = i;
      var o = this.get("data") || t, l = S(), u = M(o, function(a) {
        return (h(a) || O(a)) && (a = {
          name: a
        }), l.get(a.name) ? null : (l.set(a.name, !0), new C(a, this, this.ecModel));
      }, this);
      this._data = _(u, function(a) {
        return !!a;
      });
    }, r.prototype.getData = function() {
      return this._data;
    }, r.prototype.select = function(e) {
      var t = this.option.selected, i = this.get("selectedMode");
      if (i === "single") {
        var o = this._data;
        s(o, function(l) {
          t[l.get("name")] = !1;
        });
      }
      t[e] = !0;
    }, r.prototype.unSelect = function(e) {
      this.get("selectedMode") !== "single" && (this.option.selected[e] = !1);
    }, r.prototype.toggleSelected = function(e) {
      var t = this.option.selected;
      t.hasOwnProperty(e) || (t[e] = !0), this[t[e] ? "unSelect" : "select"](e);
    }, r.prototype.allSelect = function() {
      var e = this._data, t = this.option.selected;
      s(e, function(i) {
        t[i.get("name", !0)] = !0;
      });
    }, r.prototype.inverseSelect = function() {
      var e = this._data, t = this.option.selected;
      s(e, function(i) {
        var o = i.get("name", !0);
        t.hasOwnProperty(o) || (t[o] = !0), t[o] = !t[o];
      });
    }, r.prototype.isSelected = function(e) {
      var t = this.option.selected;
      return !(t.hasOwnProperty(e) && !t[e]) && w(this._availableNames, e) >= 0;
    }, r.prototype.getOrient = function() {
      return this.get("orient") === "vertical" ? {
        index: 1,
        name: "vertical"
      } : {
        index: 0,
        name: "horizontal"
      };
    }, r.type = "legend.plain", r.dependencies = ["series"], r.defaultOption = {
      // zlevel: 0,
      z: 4,
      show: !0,
      orient: "horizontal",
      left: "center",
      // right: 'center',
      top: 0,
      // bottom: null,
      align: "auto",
      backgroundColor: "rgba(0,0,0,0)",
      borderColor: "#ccc",
      borderRadius: 0,
      borderWidth: 0,
      padding: 5,
      itemGap: 10,
      itemWidth: 25,
      itemHeight: 14,
      symbolRotate: "inherit",
      symbolKeepAspect: !0,
      inactiveColor: "#ccc",
      inactiveBorderColor: "#ccc",
      inactiveBorderWidth: "auto",
      itemStyle: {
        color: "inherit",
        opacity: "inherit",
        borderColor: "inherit",
        borderWidth: "auto",
        borderCap: "inherit",
        borderJoin: "inherit",
        borderDashOffset: "inherit",
        borderMiterLimit: "inherit"
      },
      lineStyle: {
        width: "auto",
        color: "inherit",
        inactiveColor: "#ccc",
        inactiveWidth: 2,
        opacity: "inherit",
        type: "inherit",
        cap: "inherit",
        join: "inherit",
        dashOffset: "inherit",
        miterLimit: "inherit"
      },
      textStyle: {
        color: "#333"
      },
      selectedMode: !0,
      selector: !1,
      selectorLabel: {
        show: !0,
        borderRadius: 10,
        padding: [3, 5, 3, 5],
        fontSize: 12,
        fontFamily: "sans-serif",
        color: "#666",
        borderWidth: 1,
        borderColor: "#666"
      },
      emphasis: {
        selectorLabel: {
          show: !0,
          color: "#eee",
          backgroundColor: "#666"
        }
      },
      selectorPosition: "auto",
      selectorItemGap: 7,
      selectorButtonGap: 10,
      tooltip: {
        show: !1
      }
    }, r;
  }(L)
);
export {
  k as default
};
