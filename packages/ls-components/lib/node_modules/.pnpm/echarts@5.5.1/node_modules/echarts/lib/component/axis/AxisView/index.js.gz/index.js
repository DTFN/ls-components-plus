var x = Object.defineProperty;
var p = (s, t) => x(s, "name", { value: t, configurable: !0 });
import { __extends as l } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { fixValue as d, getAxisPointerModel as P } from "../../axisPointer/modelHelper/index.js";
import u from "../../../view/Component/index.js";
var n = {}, A = (
  /** @class */
  function(s) {
    l(t, s);
    function t() {
      var i = s !== null && s.apply(this, arguments) || this;
      return i.type = t.type, i;
    }
    return p(t, "AxisView"), t.prototype.render = function(i, e, o, r) {
      this.axisPointerClass && d(i), s.prototype.render.apply(this, arguments), this._doUpdateAxisPointerClass(i, o, !0);
    }, t.prototype.updateAxisPointer = function(i, e, o, r) {
      this._doUpdateAxisPointerClass(i, o, !1);
    }, t.prototype.remove = function(i, e) {
      var o = this._axisPointer;
      o && o.remove(e);
    }, t.prototype.dispose = function(i, e) {
      this._disposeAxisPointer(e), s.prototype.dispose.apply(this, arguments);
    }, t.prototype._doUpdateAxisPointerClass = function(i, e, o) {
      var r = t.getAxisPointerClass(this.axisPointerClass);
      if (r) {
        var a = P(i);
        a ? (this._axisPointer || (this._axisPointer = new r())).render(i, a, e, o) : this._disposeAxisPointer(e);
      }
    }, t.prototype._disposeAxisPointer = function(i) {
      this._axisPointer && this._axisPointer.dispose(i), this._axisPointer = null;
    }, t.registerAxisPointerClass = function(i, e) {
      if (process.env.NODE_ENV !== "production" && n[i])
        throw new Error("axisPointer " + i + " exists");
      n[i] = e;
    }, t.getAxisPointerClass = function(i) {
      return i && n[i];
    }, t.type = "axis", t;
  }(u)
);
export {
  A as default
};
