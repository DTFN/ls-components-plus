var y = Object.defineProperty;
var m = (d, v) => y(d, "name", { value: v, configurable: !0 });
import { isString as E, each as Q } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { parseClassType as h } from "../clazz/index.js";
var w = (
  /** @class */
  function() {
    function d() {
    }
    return m(d, "ECEventProcessor"), d.prototype.normalizeQuery = function(v) {
      var t = {}, o = {}, f = {};
      if (E(v)) {
        var i = h(v);
        t.mainType = i.main || null, t.subType = i.sub || null;
      } else {
        var a = ["Index", "Name", "Id"], c = {
          name: 1,
          dataIndex: 1,
          dataType: 1
        };
        Q(v, function(n, r) {
          for (var e = !1, l = 0; l < a.length; l++) {
            var p = a[l], u = r.lastIndexOf(p);
            if (u > 0 && u === r.length - p.length) {
              var s = r.slice(0, u);
              s !== "data" && (t.mainType = s, t[p.toLowerCase()] = n, e = !0);
            }
          }
          c.hasOwnProperty(r) && (o[r] = n, e = !0), e || (f[r] = n);
        });
      }
      return {
        cptQuery: t,
        dataQuery: o,
        otherQuery: f
      };
    }, d.prototype.filter = function(v, t) {
      var o = this.eventInfo;
      if (!o)
        return !0;
      var f = o.targetEl, i = o.packedEvent, a = o.model, c = o.view;
      if (!a || !c)
        return !0;
      var n = t.cptQuery, r = t.dataQuery;
      return e(n, a, "mainType") && e(n, a, "subType") && e(n, a, "index", "componentIndex") && e(n, a, "name") && e(n, a, "id") && e(r, i, "name") && e(r, i, "dataIndex") && e(r, i, "dataType") && (!c.filterForExposedEvent || c.filterForExposedEvent(v, t.otherQuery, f, i));
      function e(l, p, u, s) {
        return l[u] == null || p[s || u] === l[u];
      }
    }, d.prototype.afterTrigger = function() {
      this.eventInfo = null;
    }, d;
  }()
);
export {
  w as ECEventProcessor
};
