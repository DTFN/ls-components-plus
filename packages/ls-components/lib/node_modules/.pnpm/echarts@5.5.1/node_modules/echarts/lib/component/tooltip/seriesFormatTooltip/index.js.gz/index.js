var D = Object.defineProperty;
var d = (i, r) => D(i, "name", { value: r, configurable: !0 });
import { isArray as b, trim as S, reduce as x, each as I } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { retrieveVisualColorForTooltipMarker as C, createTooltipMarkup as V } from "../tooltipMarkup/index.js";
import { retrieveRawValue as g } from "../../../data/helper/dataProvider/index.js";
import { isNameSpecified as w } from "../../../util/model/index.js";
function H(i) {
  var r = i.series, l = i.dataIndex, u = i.multipleSeries, m = r.getData(), n = m.mapDimensionsAll("defaultedTooltip"), p = n.length, o = r.getRawValue(l), v = b(o), f = C(r, l), s, e, c, a;
  if (p > 1 || v && !p) {
    var t = F(o, r, l, n, f);
    s = t.inlineValues, e = t.inlineValueTypes, c = t.blocks, a = t.inlineValues[0];
  } else if (p) {
    var h = m.getDimensionInfo(n[0]);
    a = s = g(m, l, n[0]), e = h.type;
  } else
    a = s = v ? o[0] : o;
  var y = w(r), T = y && r.name || "", N = m.getName(l), k = u ? T : N;
  return V("section", {
    header: T,
    // When series name is not specified, do not show a header line with only '-'.
    // This case always happens in tooltip.trigger: 'item'.
    noHeader: u || !y,
    sortParam: a,
    blocks: [V("nameValue", {
      markerType: "item",
      markerColor: f,
      // Do not mix display seriesName and itemName in one tooltip,
      // which might confuses users.
      name: k,
      // name dimension might be auto assigned, where the name might
      // be not readable. So we check trim here.
      noName: !S(k),
      value: s,
      valueType: e,
      dataIndex: l
    })].concat(c || [])
  });
}
d(H, "defaultSeriesFormatTooltip");
function F(i, r, l, u, m) {
  var n = r.getData(), p = x(i, function(e, c, a) {
    var t = n.getDimensionInfo(a);
    return e = e || t && t.tooltip !== !1 && t.displayName != null;
  }, !1), o = [], v = [], f = [];
  u.length ? I(u, function(e) {
    s(g(n, l, e), e);
  }) : I(i, s);
  function s(e, c) {
    var a = n.getDimensionInfo(c);
    !a || a.otherDims.tooltip === !1 || (p ? f.push(V("nameValue", {
      markerType: "subItem",
      markerColor: m,
      name: a.displayName,
      value: e,
      valueType: a.type
    })) : (o.push(e), v.push(a.type)));
  }
  return d(s, "setEachItem"), {
    inlineValues: o,
    inlineValueTypes: v,
    blocks: f
  };
}
d(F, "formatTooltipArrayValue");
export {
  H as defaultSeriesFormatTooltip
};
