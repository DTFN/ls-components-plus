var G = Object.defineProperty;
var c = (r, a) => G(r, "name", { value: a, configurable: !0 });
import { queryReferringComponents as W, SINGLE_REFERRING as T, getDataItemValue as I, makeInner as k } from "../../../util/model/index.js";
import { createHashMap as Y, each as _, isObject as D, isTypedArray as C, isArray as b, isString as A } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { SOURCE_FORMAT_OBJECT_ROWS as F, SOURCE_FORMAT_KEYED_COLUMNS as U, SOURCE_FORMAT_ARRAY_ROWS as q, SERIES_LAYOUT_BY_ROW as V, SOURCE_FORMAT_ORIGINAL as H } from "../../../util/types/index.js";
var m = {
  Must: 1,
  Might: 2,
  Not: 3
  // Other cases
}, x = k();
function Q(r) {
  x(r).datasetMap = Y();
}
c(Q, "resetSourceDefaulter");
function X(r, a, h) {
  var f = {}, R = B(a);
  if (!R || !r)
    return f;
  var N = [], n = [], g = a.ecModel, y = x(g).datasetMap, d = R.uid + "_" + h.seriesLayoutBy, t, l;
  r = r.slice(), _(r, function(v, u) {
    var s = D(v) ? v : r[u] = {
      name: v
    };
    s.type === "ordinal" && t == null && (t = u, l = S(s)), f[s.name] = [];
  });
  var o = y.get(d) || y.set(d, {
    categoryWayDim: l,
    valueWayDim: 0
  });
  _(r, function(v, u) {
    var s = v.name, i = S(v);
    if (t == null) {
      var p = o.valueWayDim;
      e(f[s], p, i), e(n, p, i), o.valueWayDim += i;
    } else if (t === u)
      e(f[s], 0, i), e(N, 0, i);
    else {
      var p = o.categoryWayDim;
      e(f[s], p, i), e(n, p, i), o.categoryWayDim += i;
    }
  });
  function e(v, u, s) {
    for (var i = 0; i < s; i++)
      v.push(u + i);
  }
  c(e, "pushDim");
  function S(v) {
    var u = v.dimsDef;
    return u ? u.length : 1;
  }
  return c(S, "getDataDimCountOnCoordDim"), N.length && (f.itemName = N), n.length && (f.seriesName = n), f;
}
c(X, "makeSeriesEncodeForAxisCoordSys");
function Z(r, a, h) {
  var f = {}, R = B(r);
  if (!R)
    return f;
  var N = a.sourceFormat, n = a.dimensionsDefine, g;
  (N === F || N === U) && _(n, function(t, l) {
    (D(t) ? t.name : t) === "name" && (g = l);
  });
  var y = function() {
    for (var t = {}, l = {}, o = [], e = 0, S = Math.min(5, h); e < S; e++) {
      var v = L(a.data, N, a.seriesLayoutBy, n, a.startIndex, e);
      o.push(v);
      var u = v === m.Not;
      if (u && t.v == null && e !== g && (t.v = e), (t.n == null || t.n === t.v || !u && o[t.n] === m.Not) && (t.n = e), s(t) && o[t.n] !== m.Not)
        return t;
      u || (v === m.Might && l.v == null && e !== g && (l.v = e), (l.n == null || l.n === l.v) && (l.n = e));
    }
    function s(i) {
      return i.v != null && i.n != null;
    }
    return c(s, "fulfilled"), s(t) ? t : s(l) ? l : null;
  }();
  if (y) {
    f.value = [y.v];
    var d = g ?? y.n;
    f.itemName = [d], f.seriesName = [d];
  }
  return f;
}
c(Z, "makeSeriesEncodeForNameBased");
function B(r) {
  var a = r.get("data", !0);
  if (!a)
    return W(r.ecModel, "dataset", {
      index: r.get("datasetIndex", !0),
      id: r.get("datasetId", !0)
    }, T).models[0];
}
c(B, "querySeriesUpstreamDatasetModel");
function $(r) {
  return !r.get("transform", !0) && !r.get("fromTransformResult", !0) ? [] : W(r.ecModel, "dataset", {
    index: r.get("fromDatasetIndex", !0),
    id: r.get("fromDatasetId", !0)
  }, T).models;
}
c($, "queryDatasetUpstreamDatasetModels");
function P(r, a) {
  return L(r.data, r.sourceFormat, r.seriesLayoutBy, r.dimensionsDefine, r.startIndex, a);
}
c(P, "guessOrdinal");
function L(r, a, h, f, R, N) {
  var n, g = 5;
  if (C(r))
    return m.Not;
  var y, d;
  if (f) {
    var t = f[N];
    D(t) ? (y = t.name, d = t.type) : A(t) && (y = t);
  }
  if (d != null)
    return d === "ordinal" ? m.Must : m.Not;
  if (a === q) {
    var l = r;
    if (h === V) {
      for (var o = l[N], e = 0; e < (o || []).length && e < g; e++)
        if ((n = O(o[R + e])) != null)
          return n;
    } else
      for (var e = 0; e < l.length && e < g; e++) {
        var S = l[R + e];
        if (S && (n = O(S[N])) != null)
          return n;
      }
  } else if (a === F) {
    var v = r;
    if (!y)
      return m.Not;
    for (var e = 0; e < v.length && e < g; e++) {
      var u = v[e];
      if (u && (n = O(u[y])) != null)
        return n;
    }
  } else if (a === U) {
    var s = r;
    if (!y)
      return m.Not;
    var o = s[y];
    if (!o || C(o))
      return m.Not;
    for (var e = 0; e < o.length && e < g; e++)
      if ((n = O(o[e])) != null)
        return n;
  } else if (a === H)
    for (var i = r, e = 0; e < i.length && e < g; e++) {
      var u = i[e], p = I(u);
      if (!b(p))
        return m.Not;
      if ((n = O(p[N])) != null)
        return n;
    }
  function O(M) {
    var E = A(M);
    if (M != null && Number.isFinite(Number(M)) && M !== "")
      return E ? m.Might : m.Not;
    if (E && M !== "-")
      return m.Must;
  }
  return c(O, "detectValue"), m.Not;
}
c(L, "doGuessOrdinal");
export {
  m as BE_ORDINAL,
  P as guessOrdinal,
  X as makeSeriesEncodeForAxisCoordSys,
  Z as makeSeriesEncodeForNameBased,
  $ as queryDatasetUpstreamDatasetModels,
  B as querySeriesUpstreamDatasetModel,
  Q as resetSourceDefaulter
};
