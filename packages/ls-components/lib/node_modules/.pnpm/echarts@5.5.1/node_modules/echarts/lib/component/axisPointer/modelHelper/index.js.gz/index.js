var U = Object.defineProperty;
var v = (e, t) => U(e, "name", { value: t, configurable: !0 });
import z from "../../../model/Model/index.js";
import { each as x, curry as b, clone as B, defaults as L, isArray as N, indexOf as O } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
function X(e, t) {
  var o = {
    /**
     * key: makeKey(axis.model)
     * value: {
     *      axis,
     *      coordSys,
     *      axisPointerModel,
     *      triggerTooltip,
     *      triggerEmphasis,
     *      involveSeries,
     *      snap,
     *      seriesModels,
     *      seriesDataCount
     * }
     */
    axesInfo: {},
    seriesInvolved: !1,
    /**
     * key: makeKey(coordSys.model)
     * value: Object: key makeKey(axis.model), value: axisInfo
     */
    coordSysAxesInfo: {},
    coordSysMap: {}
  };
  return j(o, e, t), o.seriesInvolved && F(o, e), o;
}
v(X, "collect");
function j(e, t, o) {
  var s = t.getComponent("tooltip"), a = t.getComponent("axisPointer"), l = a.get("link", !0) || [], n = [];
  x(o.getCoordinateSystems(), function(i) {
    if (!i.axisPointerEnabled)
      return;
    var r = I(i.model), d = e.coordSysAxesInfo[r] = {};
    e.coordSysMap[r] = i;
    var m = i.model, u = m.getModel("tooltip", s);
    if (x(i.getAxes(), b(S, !1, null)), i.getTooltipAxes && s && u.get("show")) {
      var c = u.get("trigger") === "axis", A = u.get(["axisPointer", "type"]) === "cross", D = i.getTooltipAxes(u.get(["axisPointer", "axis"]));
      (c || A) && x(D.baseAxes, b(S, A ? "cross" : !0, c)), A && x(D.otherAxes, b(S, "cross", !1));
    }
    function S(P, p, g) {
      var f = g.model.getModel("axisPointer", a), k = f.get("show");
      if (!(!k || k === "auto" && !P && !E(f))) {
        p == null && (p = f.get("triggerTooltip")), f = P ? q(g, u, a, t, P, p) : f;
        var T = f.get("snap"), G = f.get("triggerEmphasis"), y = I(g.model), H = p || T || g.type === "category", w = e.axesInfo[y] = {
          key: y,
          axis: g,
          coordSys: i,
          axisPointerModel: f,
          triggerTooltip: p,
          triggerEmphasis: G,
          involveSeries: H,
          snap: T,
          useHandle: E(f),
          seriesModels: [],
          linkGroup: null
        };
        d[y] = w, e.seriesInvolved = e.seriesInvolved || H;
        var h = J(l, g);
        if (h != null) {
          var M = n[h] || (n[h] = {
            axesInfo: {}
          });
          M.axesInfo[y] = w, M.mapper = l[h].mapper, w.linkGroup = M;
        }
      }
    }
    v(S, "saveTooltipAxisInfo");
  });
}
v(j, "collectAxesInfo");
function q(e, t, o, s, a, l) {
  var n = t.getModel("axisPointer"), i = ["type", "snap", "lineStyle", "shadowStyle", "label", "animation", "animationDurationUpdate", "animationEasingUpdate", "z"], r = {};
  x(i, function(c) {
    r[c] = B(n.get(c));
  }), r.snap = e.type !== "category" && !!l, n.get("type") === "cross" && (r.type = "line");
  var d = r.label || (r.label = {});
  if (d.show == null && (d.show = !1), a === "cross") {
    var m = n.get(["label", "show"]);
    if (d.show = m ?? !0, !l) {
      var u = r.lineStyle = n.get("crossStyle");
      u && L(d, u.textStyle);
    }
  }
  return e.model.getModel("axisPointer", new z(r, o, s));
}
v(q, "makeAxisPointerModel");
function F(e, t) {
  t.eachSeries(function(o) {
    var s = o.coordinateSystem, a = o.get(["tooltip", "trigger"], !0), l = o.get(["tooltip", "show"], !0);
    !s || a === "none" || a === !1 || a === "item" || l === !1 || o.get(["axisPointer", "show"], !0) === !1 || x(e.coordSysAxesInfo[I(s.model)], function(n) {
      var i = n.axis;
      s.getAxis(i.dim) === i && (n.seriesModels.push(o), n.seriesDataCount == null && (n.seriesDataCount = 0), n.seriesDataCount += o.getData().count());
    });
  });
}
v(F, "collectSeriesInfo");
function J(e, t) {
  for (var o = t.model, s = t.dim, a = 0; a < e.length; a++) {
    var l = e[a] || {};
    if (C(l[s + "AxisId"], o.id) || C(l[s + "AxisIndex"], o.componentIndex) || C(l[s + "AxisName"], o.name))
      return a;
  }
}
v(J, "getLinkGroupIndex");
function C(e, t) {
  return e === "all" || N(e) && O(e, t) >= 0 || e === t;
}
v(C, "checkPropInLink");
function Y(e) {
  var t = K(e);
  if (t) {
    var o = t.axisPointerModel, s = t.axis.scale, a = o.option, l = o.get("status"), n = o.get("value");
    n != null && (n = s.parse(n));
    var i = E(o);
    l == null && (a.status = i ? "show" : "hide");
    var r = s.getExtent().slice();
    r[0] > r[1] && r.reverse(), // Pick a value on axis when initializing.
    (n == null || n > r[1]) && (n = r[1]), n < r[0] && (n = r[0]), a.value = n, i && (a.status = t.axis.scale.isBlank() ? "hide" : "show");
  }
}
v(Y, "fixValue");
function K(e) {
  var t = (e.ecModel.getComponent("axisPointer") || {}).coordSysAxesInfo;
  return t && t.axesInfo[I(e)];
}
v(K, "getAxisInfo");
function Z(e) {
  var t = K(e);
  return t && t.axisPointerModel;
}
v(Z, "getAxisPointerModel");
function E(e) {
  return !!e.get(["handle", "show"]);
}
v(E, "isHandleTrigger");
function I(e) {
  return e.type + "||" + e.id;
}
v(I, "makeKey");
export {
  X as collect,
  Y as fixValue,
  K as getAxisInfo,
  Z as getAxisPointerModel,
  I as makeKey
};
