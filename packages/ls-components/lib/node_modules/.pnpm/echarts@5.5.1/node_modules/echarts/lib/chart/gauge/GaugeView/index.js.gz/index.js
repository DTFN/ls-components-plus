var nt = Object.defineProperty;
var W = (z, u) => nt(z, "name", { value: u, configurable: !0 });
import { __extends as lt } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import vt from "../PointerPath/index.js";
import { setStatesStylesFromModel as U, toggleHoverEmphasis as $ } from "../../../util/states/index.js";
import { createTextStyle as q, setLabelValueAnimation as gt, animateLabelValue as ht } from "../../../label/labelStyle/index.js";
import ut from "../../../view/Chart/index.js";
import { parsePercent as M, round as mt, linearMap as K } from "../../../util/number/index.js";
import F from "../../../util/shape/sausage/index.js";
import { createSymbol as j } from "../../../util/symbol/index.js";
import ot from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Image/index.js";
import { each as ct, extend as st, isString as dt, isFunction as ft, isNumber as yt } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { setCommonECData as I } from "../../../util/innerStore/index.js";
import { normalizeArcAngles as pt } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/PathProxy/index.js";
import tt from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Line/index.js";
import B from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import et from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import at from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Sector/index.js";
import { initProps as rt, updateProps as it } from "../../../animation/basicTransition/index.js";
function wt(z, u) {
  var t = z.get("center"), b = u.getWidth(), y = u.getHeight(), o = Math.min(b, y), a = M(t[0], u.getWidth()), A = M(t[1], u.getHeight()), s = M(z.get("radius"), o / 2);
  return {
    cx: a,
    cy: A,
    r: s
  };
}
W(wt, "parsePosition");
function J(z, u) {
  var t = z == null ? "" : z + "";
  return u && (dt(u) ? t = u.replace("{value}", t) : ft(u) && (t = u(z))), t;
}
W(J, "formatLabel");
var Ot = (
  /** @class */
  function(z) {
    lt(u, z);
    function u() {
      var t = z !== null && z.apply(this, arguments) || this;
      return t.type = u.type, t;
    }
    return W(u, "GaugeView"), u.prototype.render = function(t, b, y) {
      this.group.removeAll();
      var o = t.get(["axisLine", "lineStyle", "color"]), a = wt(t, y);
      this._renderMain(t, b, y, o, a), this._data = t.getData();
    }, u.prototype.dispose = function() {
    }, u.prototype._renderMain = function(t, b, y, o, a) {
      var A = this.group, s = t.get("clockwise"), V = -t.get("startAngle") / 180 * Math.PI, d = -t.get("endAngle") / 180 * Math.PI, _ = t.getModel("axisLine"), L = _.get("roundCap"), N = L ? F : at, m = _.get("show"), H = _.getModel("lineStyle"), D = H.get("width"), g = [V, d];
      pt(g, !s), V = g[0], d = g[1];
      for (var r = d - V, p = V, P = [], k = 0; m && k < o.length; k++) {
        var x = Math.min(Math.max(o[k][0], 0), 1);
        d = V + r * x;
        var E = new N({
          shape: {
            startAngle: p,
            endAngle: d,
            cx: a.cx,
            cy: a.cy,
            clockwise: s,
            r0: a.r - D,
            r: a.r
          },
          silent: !0
        });
        E.setStyle({
          fill: o[k][1]
        }), E.setStyle(H.getLineStyle(
          // Because we use sector to simulate arc
          // so the properties for stroking are useless
          ["color", "width"]
        )), P.push(E), p = d;
      }
      P.reverse(), ct(P, function(C) {
        return A.add(C);
      });
      var S = /* @__PURE__ */ W(function(C) {
        if (C <= 0)
          return o[0][1];
        var e;
        for (e = 0; e < o.length; e++)
          if (o[e][0] >= C && (e === 0 ? 0 : o[e - 1][0]) < C)
            return o[e][1];
        return o[e - 1][1];
      }, "getColor");
      this._renderTicks(t, b, y, S, a, V, d, s, D), this._renderTitleAndDetail(t, b, y, S, a), this._renderAnchor(t, a), this._renderPointer(t, b, y, S, a, V, d, s, D);
    }, u.prototype._renderTicks = function(t, b, y, o, a, A, s, V, d) {
      for (var _ = this.group, L = a.cx, N = a.cy, m = a.r, H = +t.get("min"), D = +t.get("max"), g = t.getModel("splitLine"), r = t.getModel("axisTick"), p = t.getModel("axisLabel"), P = t.get("splitNumber"), k = r.get("splitNumber"), x = M(g.get("length"), m), E = M(r.get("length"), m), S = A, C = (s - A) / P, e = C / k, h = g.getModel("lineStyle").getLineStyle(), f = r.getModel("lineStyle").getLineStyle(), c = g.get("distance"), n, l, i = 0; i <= P; i++) {
        if (n = Math.cos(S), l = Math.sin(S), g.get("show")) {
          var v = c ? c + d : d, w = new tt({
            shape: {
              x1: n * (m - v) + L,
              y1: l * (m - v) + N,
              x2: n * (m - x - v) + L,
              y2: l * (m - x - v) + N
            },
            style: h,
            silent: !0
          });
          h.stroke === "auto" && w.setStyle({
            stroke: o(i / P)
          }), _.add(w);
        }
        if (p.get("show")) {
          var v = p.get("distance") + c, G = J(mt(i / P * (D - H) + H), p.get("formatter")), T = o(i / P), O = n * (m - x - v) + L, Y = l * (m - x - v) + N, X = p.get("rotate"), R = 0;
          X === "radial" ? (R = -S + 2 * Math.PI, R > Math.PI / 2 && (R += Math.PI)) : X === "tangential" ? R = -S - Math.PI / 2 : yt(X) && (R = X * Math.PI / 180), R === 0 ? _.add(new B({
            style: q(p, {
              text: G,
              x: O,
              y: Y,
              verticalAlign: l < -0.8 ? "top" : l > 0.8 ? "bottom" : "middle",
              align: n < -0.4 ? "left" : n > 0.4 ? "right" : "center"
            }, {
              inheritColor: T
            }),
            silent: !0
          })) : _.add(new B({
            style: q(p, {
              text: G,
              x: O,
              y: Y,
              verticalAlign: "middle",
              align: "center"
            }, {
              inheritColor: T
            }),
            silent: !0,
            originX: O,
            originY: Y,
            rotation: R
          }));
        }
        if (r.get("show") && i !== P) {
          var v = r.get("distance");
          v = v ? v + d : d;
          for (var Z = 0; Z <= k; Z++) {
            n = Math.cos(S), l = Math.sin(S);
            var Q = new tt({
              shape: {
                x1: n * (m - v) + L,
                y1: l * (m - v) + N,
                x2: n * (m - E - v) + L,
                y2: l * (m - E - v) + N
              },
              silent: !0,
              style: f
            });
            f.stroke === "auto" && Q.setStyle({
              stroke: o((i + Z / k) / P)
            }), _.add(Q), S += e;
          }
          S -= e;
        } else
          S += C;
      }
    }, u.prototype._renderPointer = function(t, b, y, o, a, A, s, V, d) {
      var _ = this.group, L = this._data, N = this._progressEls, m = [], H = t.get(["pointer", "show"]), D = t.getModel("progress"), g = D.get("show"), r = t.getData(), p = r.mapDimension("value"), P = +t.get("min"), k = +t.get("max"), x = [P, k], E = [A, s];
      function S(e, h) {
        var f = r.getItemModel(e), c = f.getModel("pointer"), n = M(c.get("width"), a.r), l = M(c.get("length"), a.r), i = t.get(["pointer", "icon"]), v = c.get("offsetCenter"), w = M(v[0], a.r), G = M(v[1], a.r), T = c.get("keepAspect"), O;
        return i ? O = j(i, w - n / 2, G - l, n, l, null, T) : O = new vt({
          shape: {
            angle: -Math.PI / 2,
            width: n,
            r: l,
            x: w,
            y: G
          }
        }), O.rotation = -(h + Math.PI / 2), O.x = a.cx, O.y = a.cy, O;
      }
      W(S, "createPointer");
      function C(e, h) {
        var f = D.get("roundCap"), c = f ? F : at, n = D.get("overlap"), l = n ? D.get("width") : d / r.count(), i = n ? a.r - l : a.r - (e + 1) * l, v = n ? a.r : a.r - e * l, w = new c({
          shape: {
            startAngle: A,
            endAngle: h,
            cx: a.cx,
            cy: a.cy,
            clockwise: V,
            r0: i,
            r: v
          }
        });
        return n && (w.z2 = k - r.get(p, e) % k), w;
      }
      W(C, "createProgress"), (g || H) && (r.diff(L).add(function(e) {
        var h = r.get(p, e);
        if (H) {
          var f = S(e, A);
          rt(f, {
            rotation: -((isNaN(+h) ? E[0] : K(h, x, E, !0)) + Math.PI / 2)
          }, t), _.add(f), r.setItemGraphicEl(e, f);
        }
        if (g) {
          var c = C(e, A), n = D.get("clip");
          rt(c, {
            shape: {
              endAngle: K(h, x, E, n)
            }
          }, t), _.add(c), I(t.seriesIndex, r.dataType, e, c), m[e] = c;
        }
      }).update(function(e, h) {
        var f = r.get(p, e);
        if (H) {
          var c = L.getItemGraphicEl(h), n = c ? c.rotation : A, l = S(e, n);
          l.rotation = n, it(l, {
            rotation: -((isNaN(+f) ? E[0] : K(f, x, E, !0)) + Math.PI / 2)
          }, t), _.add(l), r.setItemGraphicEl(e, l);
        }
        if (g) {
          var i = N[h], v = i ? i.shape.endAngle : A, w = C(e, v), G = D.get("clip");
          it(w, {
            shape: {
              endAngle: K(f, x, E, G)
            }
          }, t), _.add(w), I(t.seriesIndex, r.dataType, e, w), m[e] = w;
        }
      }).execute(), r.each(function(e) {
        var h = r.getItemModel(e), f = h.getModel("emphasis"), c = f.get("focus"), n = f.get("blurScope"), l = f.get("disabled");
        if (H) {
          var i = r.getItemGraphicEl(e), v = r.getItemVisual(e, "style"), w = v.fill;
          if (i instanceof ot) {
            var G = i.style;
            i.useStyle(st({
              image: G.image,
              x: G.x,
              y: G.y,
              width: G.width,
              height: G.height
            }, v));
          } else
            i.useStyle(v), i.type !== "pointer" && i.setColor(w);
          i.setStyle(h.getModel(["pointer", "itemStyle"]).getItemStyle()), i.style.fill === "auto" && i.setStyle("fill", o(K(r.get(p, e), x, [0, 1], !0))), i.z2EmphasisLift = 0, U(i, h), $(i, c, n, l);
        }
        if (g) {
          var T = m[e];
          T.useStyle(r.getItemVisual(e, "style")), T.setStyle(h.getModel(["progress", "itemStyle"]).getItemStyle()), T.z2EmphasisLift = 0, U(T, h), $(T, c, n, l);
        }
      }), this._progressEls = m);
    }, u.prototype._renderAnchor = function(t, b) {
      var y = t.getModel("anchor"), o = y.get("show");
      if (o) {
        var a = y.get("size"), A = y.get("icon"), s = y.get("offsetCenter"), V = y.get("keepAspect"), d = j(A, b.cx - a / 2 + M(s[0], b.r), b.cy - a / 2 + M(s[1], b.r), a, a, null, V);
        d.z2 = y.get("showAbove") ? 1 : 0, d.setStyle(y.getModel("itemStyle").getItemStyle()), this.group.add(d);
      }
    }, u.prototype._renderTitleAndDetail = function(t, b, y, o, a) {
      var A = this, s = t.getData(), V = s.mapDimension("value"), d = +t.get("min"), _ = +t.get("max"), L = new et(), N = [], m = [], H = t.isAnimationEnabled(), D = t.get(["pointer", "showAbove"]);
      s.diff(this._data).add(function(g) {
        N[g] = new B({
          silent: !0
        }), m[g] = new B({
          silent: !0
        });
      }).update(function(g, r) {
        N[g] = A._titleEls[r], m[g] = A._detailEls[r];
      }).execute(), s.each(function(g) {
        var r = s.getItemModel(g), p = s.get(V, g), P = new et(), k = o(K(p, [d, _], [0, 1], !0)), x = r.getModel("title");
        if (x.get("show")) {
          var E = x.get("offsetCenter"), S = a.cx + M(E[0], a.r), C = a.cy + M(E[1], a.r), e = N[g];
          e.attr({
            z2: D ? 0 : 2,
            style: q(x, {
              x: S,
              y: C,
              text: s.getName(g),
              align: "center",
              verticalAlign: "middle"
            }, {
              inheritColor: k
            })
          }), P.add(e);
        }
        var h = r.getModel("detail");
        if (h.get("show")) {
          var f = h.get("offsetCenter"), c = a.cx + M(f[0], a.r), n = a.cy + M(f[1], a.r), l = M(h.get("width"), a.r), i = M(h.get("height"), a.r), v = t.get(["progress", "show"]) ? s.getItemVisual(g, "style").fill : k, e = m[g], w = h.get("formatter");
          e.attr({
            z2: D ? 0 : 2,
            style: q(h, {
              x: c,
              y: n,
              text: J(p, w),
              width: isNaN(l) ? null : l,
              height: isNaN(i) ? null : i,
              align: "center",
              verticalAlign: "middle"
            }, {
              inheritColor: v
            })
          }), gt(e, {
            normal: h
          }, p, function(T) {
            return J(T, w);
          }), H && ht(e, g, s, t, {
            getFormattedLabel: /* @__PURE__ */ W(function(T, O, Y, X, R, Z) {
              return J(Z ? Z.interpolatedValue : p, w);
            }, "getFormattedLabel")
          }), P.add(e);
        }
        L.add(P);
      }), this.group.add(L), this._titleEls = N, this._detailEls = m;
    }, u.type = "gauge", u;
  }(ut)
);
export {
  Ot as default
};
