var b = Object.defineProperty;
var m = (t, i) => b(t, "name", { value: i, configurable: !0 });
import { normalizeToArray as v } from "../../util/model/index.js";
import { each as f, isTypedArray as _, setAsPrimitive as O, clone as d, map as B, isArray as k, isObject as y } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { error as L } from "../../util/log/index.js";
var E = /^(min|max)?(.+)$/, C = (
  /** @class */
  function() {
    function t(i) {
      this._timelineOptions = [], this._mediaList = [], this._currentMediaIndices = [], this._api = i;
    }
    return m(t, "OptionManager"), t.prototype.setOption = function(i, a, u) {
      i && (f(v(i.series), function(e) {
        e && e.data && _(e.data) && O(e.data);
      }), f(v(i.dataset), function(e) {
        e && e.source && _(e.source) && O(e.source);
      })), i = d(i);
      var o = this._optionBackup, n = I(i, a, !o);
      this._newBaseOption = n.baseOption, o ? (n.timelineOptions.length && (o.timelineOptions = n.timelineOptions), n.mediaList.length && (o.mediaList = n.mediaList), n.mediaDefault && (o.mediaDefault = n.mediaDefault)) : this._optionBackup = n;
    }, t.prototype.mountOption = function(i) {
      var a = this._optionBackup;
      return this._timelineOptions = a.timelineOptions, this._mediaList = a.mediaList, this._mediaDefault = a.mediaDefault, this._currentMediaIndices = [], d(i ? a.baseOption : this._newBaseOption);
    }, t.prototype.getTimelineOption = function(i) {
      var a, u = this._timelineOptions;
      if (u.length) {
        var o = i.getComponent("timeline");
        o && (a = d(
          // FIXME:TS as TimelineModel or quivlant interface
          u[o.getCurrentIndex()]
        ));
      }
      return a;
    }, t.prototype.getMediaOption = function(i) {
      var a = this._api.getWidth(), u = this._api.getHeight(), o = this._mediaList, n = this._mediaDefault, e = [], s = [];
      if (!o.length && !n)
        return s;
      for (var p = 0, c = o.length; p < c; p++)
        q(o[p].query, a, u) && e.push(p);
      return !e.length && n && (e = [-1]), e.length && !A(e, this._currentMediaIndices) && (s = B(e, function(l) {
        return d(l === -1 ? n.option : o[l].option);
      })), this._currentMediaIndices = e, s;
    }, t;
  }()
);
function I(t, i, a) {
  var u = [], o, n, e = t.baseOption, s = t.timeline, p = t.options, c = t.media, l = !!t.media, g = !!(p || s || e && e.timeline);
  e ? (n = e, n.timeline || (n.timeline = s)) : ((g || l) && (t.options = t.media = null), n = t), l && (k(c) ? f(c, function(r) {
    process.env.NODE_ENV !== "production" && r && !r.option && y(r.query) && y(r.query.option) && L("Illegal media option. Must be like { media: [ { query: {}, option: {} } ] }"), r && r.option && (r.query ? u.push(r) : o || (o = r));
  }) : process.env.NODE_ENV !== "production" && L("Illegal media option. Must be an array. Like { media: [ {...}, {...} ] }")), h(n), f(p, function(r) {
    return h(r);
  }), f(u, function(r) {
    return h(r.option);
  });
  function h(r) {
    f(i, function(D) {
      D(r, a);
    });
  }
  return m(h, "doPreprocess"), {
    baseOption: n,
    timelineOptions: p || [],
    mediaDefault: o,
    mediaList: u
  };
}
m(I, "parseRawOption");
function q(t, i, a) {
  var u = {
    width: i,
    height: a,
    aspectratio: i / a
    // lower case for convenience.
  }, o = !0;
  return f(t, function(n, e) {
    var s = e.match(E);
    if (!(!s || !s[1] || !s[2])) {
      var p = s[1], c = s[2].toLowerCase();
      R(u[c], n, p) || (o = !1);
    }
  }), o;
}
m(q, "applyMediaQuery");
function R(t, i, a) {
  return a === "min" ? t >= i : a === "max" ? t <= i : t === i;
}
m(R, "compare");
function A(t, i) {
  return t.join(",") === i.join(",");
}
m(A, "indicesEquals");
export {
  C as default
};
