var te = Object.defineProperty;
var v = (t, a) => te(t, "name", { value: a, configurable: !0 });
import { SERIES_UNIVERSAL_TRANSITION_PROP as R } from "../../model/Series/index.js";
import { each as h, createHashMap as k, filter as H, map as _, isArray as V, extend as b } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { applyMorphAnimation as C, getPathList as O } from "../morphTransitionHelper/index.js";
import Y from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
import "../../util/graphic/index.js";
import j from "../../data/DataDiffer/index.js";
import { normalizeToArray as P, makeInner as re } from "../../util/model/index.js";
import { warn as Z } from "../../util/log/index.js";
import { getAnimationConfig as $, initProps as ae, getOldStyle as ie } from "../basicTransition/index.js";
import ne from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Displayable/index.js";
var K = 1e4, oe = 0, q = 1, z = 2, de = re();
function ue(t, a) {
  for (var i = t.dimensions, e = 0; e < i.length; e++) {
    var r = t.getDimensionInfo(i[e]);
    if (r && r.otherDims[a] === 0)
      return i[e];
  }
}
v(ue, "getDimension");
function se(t, a, i) {
  var e = t.getDimensionInfo(i), r = e && e.ordinalMeta;
  if (e) {
    var u = t.get(e.name, a);
    return r && r.categories[u] || u + "";
  }
}
v(se, "getValueByDimension");
function w(t, a, i, e) {
  var r = e ? "itemChildGroupId" : "itemGroupId", u = ue(t, r);
  if (u) {
    var n = se(t, a, u);
    return n;
  }
  var d = t.getRawDataItem(a), l = e ? "childGroupId" : "groupId";
  if (d && d[l])
    return d[l] + "";
  if (!e)
    return i || t.getId(a);
}
v(w, "getGroupId");
function J(t) {
  var a = [];
  return h(t, function(i) {
    var e = i.data, r = i.dataGroupId;
    if (e.count() > K) {
      process.env.NODE_ENV !== "production" && Z("Universal transition is disabled on large data > 10k.");
      return;
    }
    for (var u = e.getIndices(), n = 0; n < u.length; n++)
      a.push({
        data: e,
        groupId: w(e, n, r, !1),
        childGroupId: w(e, n, r, !0),
        divide: i.divide,
        dataIndex: n
      });
  }), a;
}
v(J, "flattenDataDiffItems");
function U(t, a, i) {
  t.traverse(function(e) {
    e instanceof Y && ae(e, {
      style: {
        opacity: 0
      }
    }, a, {
      dataIndex: i,
      isFrom: !0
    });
  });
}
v(U, "fadeInElement");
function L(t) {
  if (t.parent) {
    var a = t.getComputedTransform();
    t.setLocalTransform(a), t.parent.remove(t);
  }
}
v(L, "removeEl");
function x(t) {
  t.stopAnimation(), t.isGroup && t.traverse(function(a) {
    a.stopAnimation();
  });
}
v(x, "stopAnimation");
function fe(t, a, i) {
  var e = $("update", i, a);
  e && t.traverse(function(r) {
    if (r instanceof ne) {
      var u = ie(r);
      u && r.animateFrom({
        style: u
      }, e);
    }
  });
}
v(fe, "animateElementStyles");
function ve(t, a) {
  var i = t.length;
  if (i !== a.length)
    return !1;
  for (var e = 0; e < i; e++) {
    var r = t[e], u = a[e];
    if (r.data.getId(r.dataIndex) !== u.data.getId(u.dataIndex))
      return !1;
  }
  return !0;
}
v(ve, "isAllIdSame");
function ee(t, a, i) {
  var e = J(t), r = J(a);
  function u(s, S, o, f, g) {
    (o || s) && S.animateFrom({
      style: o && o !== s ? b(b({}, o.style), s.style) : s.style
    }, g);
  }
  v(u, "updateMorphingPathProps");
  var n = !1, d = oe, l = k(), T = k();
  e.forEach(function(s) {
    s.groupId && l.set(s.groupId, !0), s.childGroupId && T.set(s.childGroupId, !0);
  });
  for (var c = 0; c < r.length; c++) {
    var G = r[c].groupId;
    if (T.get(G)) {
      d = q;
      break;
    }
    var D = r[c].childGroupId;
    if (D && l.get(D)) {
      d = z;
      break;
    }
  }
  function m(s, S) {
    return function(o) {
      var f = o.data, g = o.dataIndex;
      return S ? f.getId(g) : s ? d === q ? o.childGroupId : o.groupId : d === z ? o.childGroupId : o.groupId;
    };
  }
  v(m, "createKeyGetter");
  var E = ve(e, r), N = {};
  if (!E)
    for (var c = 0; c < r.length; c++) {
      var A = r[c], F = A.data.getItemGraphicEl(A.dataIndex);
      F && (N[F.id] = !0);
    }
  function B(s, S) {
    var o = e[S], f = r[s], g = f.data.hostModel, I = o.data.getItemGraphicEl(o.dataIndex), p = f.data.getItemGraphicEl(f.dataIndex);
    if (I === p) {
      p && fe(p, f.dataIndex, g);
      return;
    }
    // We can't use the elements that already being morphed
    I && N[I.id] || p && (x(p), I ? (x(I), L(I), n = !0, C(O(I), O(p), f.divide, g, s, u)) : U(p, g, s));
  }
  v(B, "updateOneToOne"), new j(e, r, m(!0, E), m(!1, E), null, "multiple").update(B).updateManyToOne(function(s, S) {
    var o = r[s], f = o.data, g = f.hostModel, I = f.getItemGraphicEl(o.dataIndex), p = H(_(S, function(y) {
      return e[y].data.getItemGraphicEl(e[y].dataIndex);
    }), function(y) {
      return y && y !== I && !N[y.id];
    });
    I && (x(I), p.length ? (h(p, function(y) {
      x(y), L(y);
    }), n = !0, C(O(p), O(I), o.divide, g, s, u)) : U(I, g, o.dataIndex));
  }).updateOneToMany(function(s, S) {
    var o = e[S], f = o.data.getItemGraphicEl(o.dataIndex);
    if (!(f && N[f.id])) {
      var g = H(_(s, function(p) {
        return r[p].data.getItemGraphicEl(r[p].dataIndex);
      }), function(p) {
        return p && p !== f;
      }), I = r[s[0]].data.hostModel;
      g.length && (h(g, function(p) {
        return x(p);
      }), f ? (x(f), L(f), n = !0, C(
        O(f),
        O(g),
        o.divide,
        // Use divide on old.
        I,
        s[0],
        u
      )) : h(g, function(p) {
        return U(p, I, s[0]);
      }));
    }
  }).updateManyToMany(function(s, S) {
    new j(S, s, function(o) {
      return e[o].data.getId(e[o].dataIndex);
    }, function(o) {
      return r[o].data.getId(r[o].dataIndex);
    }).update(function(o, f) {
      B(s[o], S[f]);
    }).execute();
  }).execute(), n && h(a, function(s) {
    var S = s.data, o = S.hostModel, f = o && i.getViewOfSeriesModel(o), g = $("update", o, 0);
    f && o.isAnimationEnabled() && g && g.duration > 0 && f.group.traverse(function(I) {
      I instanceof Y && !I.animators.length && I.animateFrom({
        style: {
          opacity: 0
        }
      }, g);
    });
  });
}
v(ee, "transitionBetween");
function Q(t) {
  var a = t.getModel("universalTransition").get("seriesKey");
  return a || t.id;
}
v(Q, "getSeriesTransitionKey");
function W(t) {
  return V(t) ? t.sort().join(",") : t;
}
v(W, "convertArraySeriesKeyToString");
function M(t) {
  if (t.hostModel)
    return t.hostModel.getModel("universalTransition").get("divideShape");
}
v(M, "getDivideShapeFromData");
function pe(t, a) {
  var i = k(), e = k(), r = k();
  h(t.oldSeries, function(n, d) {
    var l = t.oldDataGroupIds[d], T = t.oldData[d], c = Q(n), G = W(c);
    e.set(G, {
      dataGroupId: l,
      data: T
    }), V(c) && h(c, function(D) {
      r.set(D, {
        key: G,
        dataGroupId: l,
        data: T
      });
    });
  });
  function u(n) {
    i.get(n) && Z("Duplicated seriesKey in universalTransition " + n);
  }
  return v(u, "checkTransitionSeriesKeyDuplicated"), h(a.updatedSeries, function(n) {
    if (n.isUniversalTransitionEnabled() && n.isAnimationEnabled()) {
      var d = n.get("dataGroupId"), l = n.getData(), T = Q(n), c = W(T), G = e.get(c);
      if (G)
        process.env.NODE_ENV !== "production" && u(c), i.set(c, {
          oldSeries: [{
            dataGroupId: G.dataGroupId,
            divide: M(G.data),
            data: G.data
          }],
          newSeries: [{
            dataGroupId: d,
            divide: M(l),
            data: l
          }]
        });
      else if (V(T)) {
        process.env.NODE_ENV !== "production" && u(c);
        var D = [];
        h(T, function(N) {
          var A = e.get(N);
          A.data && D.push({
            dataGroupId: A.dataGroupId,
            divide: M(A.data),
            data: A.data
          });
        }), D.length && i.set(c, {
          oldSeries: D,
          newSeries: [{
            dataGroupId: d,
            data: l,
            divide: M(l)
          }]
        });
      } else {
        var m = r.get(T);
        if (m) {
          var E = i.get(m.key);
          E || (E = {
            oldSeries: [{
              dataGroupId: m.dataGroupId,
              data: m.data,
              divide: M(m.data)
            }],
            newSeries: []
          }, i.set(m.key, E)), E.newSeries.push({
            dataGroupId: d,
            data: l,
            divide: M(l)
          });
        }
      }
    }
  }), i;
}
v(pe, "findTransitionSeriesBatches");
function X(t, a) {
  for (var i = 0; i < t.length; i++) {
    var e = a.seriesIndex != null && a.seriesIndex === t[i].seriesIndex || a.seriesId != null && a.seriesId === t[i].id;
    if (e)
      return i;
  }
}
v(X, "querySeries");
function le(t, a, i, e) {
  var r = [], u = [];
  h(P(t.from), function(n) {
    var d = X(a.oldSeries, n);
    d >= 0 && r.push({
      dataGroupId: a.oldDataGroupIds[d],
      data: a.oldData[d],
      // TODO can specify divideShape in transition.
      divide: M(a.oldData[d]),
      groupIdDim: n.dimension
    });
  }), h(P(t.to), function(n) {
    var d = X(i.updatedSeries, n);
    if (d >= 0) {
      var l = i.updatedSeries[d].getData();
      u.push({
        dataGroupId: a.oldDataGroupIds[d],
        data: l,
        divide: M(l),
        groupIdDim: n.dimension
      });
    }
  }), r.length > 0 && u.length > 0 && ee(r, u, e);
}
v(le, "transitionSeriesFromOpt");
function Me(t) {
  t.registerUpdateLifecycle("series:beforeupdate", function(a, i, e) {
    h(P(e.seriesTransition), function(r) {
      h(P(r.to), function(u) {
        for (var n = e.updatedSeries, d = 0; d < n.length; d++)
          (u.seriesIndex != null && u.seriesIndex === n[d].seriesIndex || u.seriesId != null && u.seriesId === n[d].id) && (n[d][R] = !0);
      });
    });
  }), t.registerUpdateLifecycle("series:transition", function(a, i, e) {
    var r = de(i);
    if (r.oldSeries && e.updatedSeries && e.optionChanged) {
      var u = e.seriesTransition;
      if (u)
        h(P(u), function(m) {
          le(m, r, e, i);
        });
      else {
        var n = pe(r, e);
        h(n.keys(), function(m) {
          var E = n.get(m);
          ee(E.oldSeries, E.newSeries, i);
        });
      }
      h(e.updatedSeries, function(m) {
        m[R] && (m[R] = !1);
      });
    }
    for (var d = a.getSeries(), l = r.oldSeries = [], T = r.oldDataGroupIds = [], c = r.oldData = [], G = 0; G < d.length; G++) {
      var D = d[G].getData();
      D.count() < K && (l.push(d[G]), T.push(d[G].get("dataGroupId")), c.push(D));
    }
  });
}
v(Me, "installUniversalTransition");
export {
  Me as installUniversalTransition
};
