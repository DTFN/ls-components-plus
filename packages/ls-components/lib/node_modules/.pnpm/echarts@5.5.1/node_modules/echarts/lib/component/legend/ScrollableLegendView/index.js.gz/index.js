var N = Object.defineProperty;
var C = (m, y) => N(m, "name", { value: y, configurable: !0 });
import { __extends as b } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { isArray as O, bind as V, clone as z, retrieve2 as k, each as F, isString as L } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { createIcon as S } from "../../../util/graphic/index.js";
import { box as R } from "../../../util/layout/index.js";
import H from "../LegendView/index.js";
import J from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Text/index.js";
import W from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
import X from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import { updateProps as Y } from "../../../animation/basicTransition/index.js";
var A = X, B = ["width", "height"], T = ["x", "y"], tt = (
  /** @class */
  function(m) {
    b(y, m);
    function y() {
      var t = m !== null && m.apply(this, arguments) || this;
      return t.type = y.type, t.newlineDisabled = !0, t._currentIndex = 0, t;
    }
    return C(y, "ScrollableLegendView"), y.prototype.init = function() {
      m.prototype.init.call(this), this.group.add(this._containerGroup = new A()), this._containerGroup.add(this.getContentGroup()), this.group.add(this._controllerGroup = new A());
    }, y.prototype.resetInner = function() {
      m.prototype.resetInner.call(this), this._controllerGroup.removeAll(), this._containerGroup.removeClipPath(), this._containerGroup.__rectSize = null;
    }, y.prototype.renderInner = function(t, l, i, a, e, x, g) {
      var p = this;
      m.prototype.renderInner.call(this, t, l, i, a, e, x, g);
      var o = this._controllerGroup, h = l.get("pageIconSize", !0), u = O(h) ? h : [h, h];
      r("pagePrev", 0);
      var c = l.getModel("pageTextStyle");
      o.add(new J({
        name: "pageText",
        style: {
          // Placeholder to calculate a proper layout.
          text: "xx/xx",
          fill: c.getTextColor(),
          font: c.getFont(),
          verticalAlign: "middle",
          align: "center"
        },
        silent: !0
      })), r("pageNext", 1);
      function r(s, f) {
        var v = s + "DataIndex", n = S(l.get("pageIcons", !0)[l.getOrient().name][f], {
          // Buttons will be created in each render, so we do not need
          // to worry about avoiding using legendModel kept in scope.
          onclick: V(p._pageGo, p, v, l, a)
        }, {
          x: -u[0] / 2,
          y: -u[1] / 2,
          width: u[0],
          height: u[1]
        });
        n.name = s, o.add(n);
      }
      C(r, "createPageButton");
    }, y.prototype.layoutInner = function(t, l, i, a, e, x) {
      var g = this.getSelectorGroup(), p = t.getOrient().index, o = B[p], h = T[p], u = B[1 - p], c = T[1 - p];
      e && R(
        // Buttons in selectorGroup always layout horizontally
        "horizontal",
        g,
        t.get("selectorItemGap", !0)
      );
      var r = t.get("selectorButtonGap", !0), s = g.getBoundingRect(), f = [-s.x, -s.y], v = z(i);
      e && (v[o] = i[o] - s[o] - r);
      var n = this._layoutContentAndController(t, a, v, p, o, u, c, h);
      if (e) {
        if (x === "end")
          f[p] += n[o] + r;
        else {
          var d = s[o] + r;
          f[p] -= d, n[h] -= d;
        }
        n[o] += s[o] + r, f[1 - p] += n[c] + n[u] / 2 - s[u] / 2, n[u] = Math.max(n[u], s[u]), n[c] = Math.min(n[c], s[c] + f[1 - p]), g.x = f[0], g.y = f[1], g.markRedraw();
      }
      return n;
    }, y.prototype._layoutContentAndController = function(t, l, i, a, e, x, g, p) {
      var o = this.getContentGroup(), h = this._containerGroup, u = this._controllerGroup;
      R(t.get("orient"), o, t.get("itemGap"), a ? i.width : null, a ? null : i.height), R(
        // Buttons in controller are layout always horizontally.
        "horizontal",
        u,
        t.get("pageButtonItemGap", !0)
      );
      var c = o.getBoundingRect(), r = u.getBoundingRect(), s = this._showController = c[e] > i[e], f = [-c.x, -c.y];
      l || (f[a] = o[p]);
      var v = [0, 0], n = [-r.x, -r.y], d = k(t.get("pageButtonGap", !0), t.get("itemGap", !0));
      if (s) {
        var P = t.get("pageButtonPosition", !0);
        P === "end" ? n[a] += i[e] - r[e] : v[a] += r[e] + d;
      }
      n[1 - a] += c[x] / 2 - r[x] / 2, o.setPosition(f), h.setPosition(v), u.setPosition(n);
      var I = {
        x: 0,
        y: 0
      };
      if (I[e] = s ? i[e] : c[e], I[x] = Math.max(c[x], r[x]), I[g] = Math.min(0, r[g] + n[1 - a]), h.__rectSize = i[e], s) {
        var G = {
          x: 0,
          y: 0
        };
        G[e] = Math.max(i[e] - r[e] - d, 0), G[x] = I[x], h.setClipPath(new W({
          shape: G
        })), h.__rectSize = G[e];
      } else
        u.eachChild(function(D) {
          D.attr({
            invisible: !0,
            silent: !0
          });
        });
      var _ = this._getPageInfo(t);
      return _.pageIndex != null && Y(
        o,
        {
          x: _.contentPosition[0],
          y: _.contentPosition[1]
        },
        // When switch from "show controller" to "not show controller", view should be
        // updated immediately without animation, otherwise causes weird effect.
        s ? t : null
      ), this._updatePageInfoView(t, _), I;
    }, y.prototype._pageGo = function(t, l, i) {
      var a = this._getPageInfo(l)[t];
      a != null && i.dispatchAction({
        type: "legendScroll",
        scrollDataIndex: a,
        legendId: l.id
      });
    }, y.prototype._updatePageInfoView = function(t, l) {
      var i = this._controllerGroup;
      F(["pagePrev", "pageNext"], function(o) {
        var h = o + "DataIndex", u = l[h] != null, c = i.childOfName(o);
        c && (c.setStyle("fill", u ? t.get("pageIconColor", !0) : t.get("pageIconInactiveColor", !0)), c.cursor = u ? "pointer" : "default");
      });
      var a = i.childOfName("pageText"), e = t.get("pageFormatter"), x = l.pageIndex, g = x != null ? x + 1 : 0, p = l.pageCount;
      a && e && a.setStyle("text", L(e) ? e.replace("{current}", g == null ? "" : g + "").replace("{total}", p == null ? "" : p + "") : e({
        current: g,
        total: p
      }));
    }, y.prototype._getPageInfo = function(t) {
      var l = t.get("scrollDataIndex", !0), i = this.getContentGroup(), a = this._containerGroup.__rectSize, e = t.getOrient().index, x = B[e], g = T[e], p = this._findTargetItemIndex(l), o = i.children(), h = o[p], u = o.length, c = u ? 1 : 0, r = {
        contentPosition: [i.x, i.y],
        pageCount: c,
        pageIndex: c - 1,
        pagePrevDataIndex: null,
        pageNextDataIndex: null
      };
      if (!h)
        return r;
      var s = P(h);
      r.contentPosition[e] = -s.s;
      for (var f = p + 1, v = s, n = s, d = null; f <= u; ++f)
        d = P(o[f]), // Half of the last item is out of the window.
        (!d && n.e > v.s + a || d && !I(d, v.s)) && (n.i > v.i ? v = n : v = d, v && (r.pageNextDataIndex == null && (r.pageNextDataIndex = v.i), ++r.pageCount)), n = d;
      for (var f = p - 1, v = s, n = s, d = null; f >= -1; --f)
        d = P(o[f]), // If the the end item does not intersect with the window started
        // from the current item, a page can be settled.
        (!d || !I(n, d.s)) && v.i < n.i && (n = v, r.pagePrevDataIndex == null && (r.pagePrevDataIndex = v.i), ++r.pageCount, ++r.pageIndex), v = d;
      return r;
      function P(G) {
        if (G) {
          var _ = G.getBoundingRect(), D = _[g] + G[g];
          return {
            s: D,
            e: D + _[x],
            i: G.__legendDataIndex
          };
        }
      }
      function I(G, _) {
        return G.e >= _ && G.s <= _ + a;
      }
    }, y.prototype._findTargetItemIndex = function(t) {
      if (!this._showController)
        return 0;
      var l, i = this.getContentGroup(), a;
      return i.eachChild(function(e, x) {
        var g = e.__legendDataIndex;
        a == null && g != null && (a = x), g === t && (l = x);
      }), l ?? a;
    }, y.type = "legend.scroll", y;
  }(H)
);
export {
  tt as default
};
