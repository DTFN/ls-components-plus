var ne = Object.defineProperty;
var i = (r, n) => ne(r, "name", { value: n, configurable: !0 });
import { __extends as ae } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { parseDate as z, nice as ue } from "../../util/number/index.js";
import { format as ie, fullLeveledFormatter as j, getDefaultFormatPrecisionOfInterval as se, getPrimaryTimeUnit as A, leveledFormat as oe, ONE_DAY as m, ONE_SECOND as Z, ONE_MINUTE as $, ONE_HOUR as G, ONE_YEAR as J, isPrimaryTimeUnit as ce, timeUnits as fe, secondsSetterName as I, millisecondsSetterName as U, minutesSetterName as T, hoursSetterName as C, dateSetterName as x, monthSetterName as ee, millisecondsGetterName as le, secondsGetterName as he, minutesGetterName as ve, hoursGetterName as me, dateGetterName as de, monthGetterName as ge, fullYearGetterName as ye, fullYearSetterName as Se, getUnitValue as K } from "../../util/time/index.js";
import { contain as _e, normalize as we, scale as be } from "../helper/index.js";
import Ee from "../Interval/index.js";
import Me from "../Scale/index.js";
import { warn as De } from "../../util/log/index.js";
import { isNumber as Oe, filter as Q, map as Ne } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
var Le = /* @__PURE__ */ i(function(r, n, e, t) {
  for (; e < t; ) {
    var a = e + t >>> 1;
    r[a][1] < n ? e = a + 1 : t = a;
  }
  return e;
}, "bisect"), Ae = (
  /** @class */
  function(r) {
    ae(n, r);
    function n(e) {
      var t = r.call(this, e) || this;
      return t.type = "time", t;
    }
    return i(n, "TimeScale"), n.prototype.getLabel = function(e) {
      var t = this.getSetting("useUTC");
      return ie(e.value, j[se(A(this._minLevelUnit))] || j.second, t, this.getSetting("locale"));
    }, n.prototype.getFormattedLabel = function(e, t, a) {
      var s = this.getSetting("useUTC"), o = this.getSetting("locale");
      return oe(e, t, a, o, s);
    }, n.prototype.getTicks = function() {
      var e = this._interval, t = this._extent, a = [];
      if (!e)
        return a;
      a.push({
        value: t[0],
        level: 0
      });
      var s = this.getSetting("useUTC"), o = qe(this._minLevelUnit, this._approxInterval, s, t);
      return a = a.concat(o), a.push({
        value: t[1],
        level: 0
      }), a;
    }, n.prototype.calcNiceExtent = function(e) {
      var t = this._extent;
      if (t[0] === t[1] && (t[0] -= m, t[1] += m), t[1] === -1 / 0 && t[0] === 1 / 0) {
        var a = /* @__PURE__ */ new Date();
        t[1] = +new Date(a.getFullYear(), a.getMonth(), a.getDate()), t[0] = t[1] - m;
      }
      this.calcNiceTicks(e.splitNumber, e.minInterval, e.maxInterval);
    }, n.prototype.calcNiceTicks = function(e, t, a) {
      e = e || 10;
      var s = this._extent, o = s[1] - s[0];
      this._approxInterval = o / e, t != null && this._approxInterval < t && (this._approxInterval = t), a != null && this._approxInterval > a && (this._approxInterval = a);
      var y = F.length, S = Math.min(Le(F, this._approxInterval, 0, y), y - 1);
      this._interval = F[S][1], this._minLevelUnit = F[Math.max(S - 1, 0)][0];
    }, n.prototype.parse = function(e) {
      return Oe(e) ? e : +z(e);
    }, n.prototype.contain = function(e) {
      return _e(this.parse(e), this._extent);
    }, n.prototype.normalize = function(e) {
      return we(this.parse(e), this._extent);
    }, n.prototype.scale = function(e) {
      return be(e, this._extent);
    }, n.type = "time", n;
  }(Ee)
), F = [
  // Format                           interval
  ["second", Z],
  ["minute", $],
  ["hour", G],
  ["quarter-day", G * 6],
  ["half-day", G * 12],
  ["day", m * 1.2],
  ["half-week", m * 3.5],
  ["week", m * 7],
  ["month", m * 31],
  ["quarter", m * 95],
  ["half-year", J / 2],
  ["year", J]
  // 1Y
];
function ke(r, n, e, t) {
  var a = z(n), s = z(e), o = /* @__PURE__ */ i(function(k) {
    return K(a, k, t) === K(s, k, t);
  }, "isSame"), y = /* @__PURE__ */ i(function() {
    return o("year");
  }, "isSameYear"), S = /* @__PURE__ */ i(function() {
    return y() && o("month");
  }, "isSameMonth"), _ = /* @__PURE__ */ i(function() {
    return S() && o("day");
  }, "isSameDay"), h = /* @__PURE__ */ i(function() {
    return _() && o("hour");
  }, "isSameHour"), w = /* @__PURE__ */ i(function() {
    return h() && o("minute");
  }, "isSameMinute"), N = /* @__PURE__ */ i(function() {
    return w() && o("second");
  }, "isSameSecond"), u = /* @__PURE__ */ i(function() {
    return N() && o("millisecond");
  }, "isSameMilliSecond");
  switch (r) {
    case "year":
      return y();
    case "month":
      return S();
    case "day":
      return _();
    case "hour":
      return h();
    case "minute":
      return w();
    case "second":
      return N();
    case "millisecond":
      return u();
  }
}
i(ke, "isUnitValueSame");
function Fe(r, n) {
  return r /= m, r > 16 ? 16 : r > 7.5 ? 7 : r > 3.5 ? 4 : r > 1.5 ? 2 : 1;
}
i(Fe, "getDateInterval");
function Ge(r) {
  var n = 30 * m;
  return r /= n, r > 6 ? 6 : r > 3 ? 3 : r > 2 ? 2 : 1;
}
i(Ge, "getMonthInterval");
function pe(r) {
  return r /= G, r > 12 ? 12 : r > 6 ? 6 : r > 3.5 ? 4 : r > 2 ? 2 : 1;
}
i(pe, "getHourInterval");
function W(r, n) {
  return r /= n ? $ : Z, r > 30 ? 30 : r > 20 ? 20 : r > 15 ? 15 : r > 10 ? 10 : r > 5 ? 5 : r > 2 ? 2 : 1;
}
i(W, "getMinutesAndSecondsInterval");
function Ye(r) {
  return ue(r);
}
i(Ye, "getMillisecondsInterval");
function Pe(r, n, e) {
  var t = new Date(r);
  switch (A(n)) {
    case "year":
    case "month":
      t[ee(e)](0);
    case "day":
      t[x(e)](1);
    case "hour":
      t[C(e)](0);
    case "minute":
      t[T(e)](0);
    case "second":
      t[I(e)](0), t[U(e)](0);
  }
  return t.getTime();
}
i(Pe, "getFirstTimestampOfUnit");
function qe(r, n, e, t) {
  var a = 1e4, s = fe, o = 0;
  function y(l, c, M, D, H, d, L) {
    for (var O = new Date(c), f = c, v = O[D](); f < M && f <= t[1]; )
      L.push({
        value: f
      }), v += l, O[H](v), f = O.getTime();
    L.push({
      value: f,
      notAdd: !0
    });
  }
  i(y, "addTicksInSpan");
  function S(l, c, M) {
    var D = [], H = !c.length;
    if (!ke(A(l), t[0], t[1], e)) {
      H && (c = [{
        // TODO Optimize. Not include so may ticks.
        value: Pe(new Date(t[0]), l, e)
      }, {
        value: t[1]
      }]);
      for (var d = 0; d < c.length - 1; d++) {
        var L = c[d].value, O = c[d + 1].value;
        if (L !== O) {
          var f = void 0, v = void 0, g = void 0, X = !1;
          switch (l) {
            case "year":
              f = Math.max(1, Math.round(n / m / 365)), v = ye(e), g = Se(e);
              break;
            case "half-year":
            case "quarter":
            case "month":
              f = Ge(n), v = ge(e), g = ee(e);
              break;
            case "week":
            case "half-week":
            case "day":
              f = Fe(n), v = de(e), g = x(e), X = !0;
              break;
            case "half-day":
            case "quarter-day":
            case "hour":
              f = pe(n), v = me(e), g = C(e);
              break;
            case "minute":
              f = W(n, !0), v = ve(e), g = T(e);
              break;
            case "second":
              f = W(n, !1), v = he(e), g = I(e);
              break;
            case "millisecond":
              f = Ye(n), v = le(e), g = U(e);
              break;
          }
          y(f, L, O, v, g, X, D), l === "year" && M.length > 1 && d === 0 && M.unshift({
            value: M[0].value - f
          });
        }
      }
      for (var d = 0; d < D.length; d++)
        M.push(D[d]);
      return D;
    }
  }
  i(S, "addLevelTicks");
  for (var _ = [], h = [], w = 0, N = 0, u = 0; u < s.length && o++ < a; ++u) {
    var k = A(s[u]);
    if (ce(s[u])) {
      S(s[u], _[_.length - 1] || [], h);
      var te = s[u + 1] ? A(s[u + 1]) : null;
      if (k !== te) {
        if (h.length) {
          N = w, h.sort(function(l, c) {
            return l.value - c.value;
          });
          for (var R = [], b = 0; b < h.length; ++b) {
            var p = h[b].value;
            (b === 0 || h[b - 1].value !== p) && (R.push(h[b]), p >= t[0] && p <= t[1] && w++);
          }
          var Y = (t[1] - t[0]) / n;
          if (w > Y * 1.5 && N > Y / 1.5 || (_.push(R), w > Y || r === s[u]))
            break;
        }
        h = [];
      }
    }
  }
  process.env.NODE_ENV !== "production" && o >= a && De("Exceed safe limit.");
  for (var P = Q(Ne(_, function(l) {
    return Q(l, function(c) {
      return c.value >= t[0] && c.value <= t[1] && !c.notAdd;
    });
  }), function(l) {
    return l.length > 0;
  }), E = [], re = P.length - 1, u = 0; u < P.length; ++u)
    for (var B = P[u], q = 0; q < B.length; ++q)
      E.push({
        value: B[q].value,
        level: re - u
      });
  E.sort(function(l, c) {
    return l.value - c.value;
  });
  for (var V = [], u = 0; u < E.length; ++u)
    (u === 0 || E[u].value !== E[u - 1].value) && V.push(E[u]);
  return V;
}
i(qe, "getIntervalTicks");
Me.registerClass(Ae);
export {
  Ae as default
};
