var ee = Object.defineProperty;
var i = (e, t) => ee(e, "name", { value: t, configurable: !0 });
import { each as d, isArray as M, isArrayLike as te, isObject as re, keys as ne, indexOf as z, extend as h } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getECData as p } from "../innerStore/index.js";
import { liftColor as A } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/tool/color/index.js";
import { makeInner as Y, queryDataIndex as R } from "../model/index.js";
import ie from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Path/index.js";
import { error as D } from "../log/index.js";
var L = 1, P = {}, U = Y(), w = Y(), I = 0, C = 1, B = 2, Le = ["emphasis", "blur", "select"], Pe = ["normal", "emphasis", "blur", "select"], ae = 10, oe = 9, le = "highlight", ue = "downplay", W = "select", fe = "unselect", Z = "toggleSelect";
function S(e) {
  return e != null && e !== "none";
}
i(S, "hasFillOrStroke");
function _(e, t, r) {
  e.onHoverStateChange && (e.hoverState || 0) !== r && e.onHoverStateChange(t), e.hoverState = r;
}
i(_, "doChangeHoverState");
function j(e) {
  _(e, "emphasis", B);
}
i(j, "singleEnterEmphasis");
function q(e) {
  e.hoverState === B && _(e, "normal", I);
}
i(q, "singleLeaveEmphasis");
function H(e) {
  _(e, "blur", C);
}
i(H, "singleEnterBlur");
function J(e) {
  e.hoverState === C && _(e, "normal", I);
}
i(J, "singleLeaveBlur");
function ce(e) {
  e.selected = !0;
}
i(ce, "singleEnterSelect");
function se(e) {
  e.selected = !1;
}
i(se, "singleLeaveSelect");
function k(e, t, r) {
  t(e, r);
}
i(k, "updateElementState");
function g(e, t, r) {
  k(e, t, r), e.isGroup && e.traverse(function(n) {
    k(n, t, r);
  });
}
i(g, "traverseUpdateState");
function ke(e, t) {
  switch (t) {
    case "emphasis":
      e.hoverState = B;
      break;
    case "normal":
      e.hoverState = I;
      break;
    case "blur":
      e.hoverState = C;
      break;
    case "select":
      e.selected = !0;
  }
}
i(ke, "setStatesFlag");
function ve(e, t, r, n) {
  for (var a = e.style, o = {}, l = 0; l < t.length; l++) {
    var f = t[l], c = a[f];
    o[f] = c ?? (n && n[f]);
  }
  for (var l = 0; l < e.animators.length; l++) {
    var u = e.animators[l];
    u.__fromStateTransition && u.__fromStateTransition.indexOf(r) < 0 && u.targetName === "style" && u.saveTo(o, t);
  }
  return o;
}
i(ve, "getFromStateStyle");
function he(e, t, r, n) {
  var a = r && z(r, "select") >= 0, o = !1;
  if (e instanceof ie) {
    var l = U(e), f = a && l.selectFill || l.normalFill, c = a && l.selectStroke || l.normalStroke;
    if (S(f) || S(c)) {
      n = n || {};
      var u = n.style || {};
      u.fill === "inherit" ? (o = !0, n = h({}, n), u = h({}, u), u.fill = f) : !S(u.fill) && S(f) ? (o = !0, n = h({}, n), u = h({}, u), u.fill = A(f)) : !S(u.stroke) && S(c) && (o || (n = h({}, n), u = h({}, u)), u.stroke = A(c)), n.style = u;
    }
  }
  if (n && n.z2 == null) {
    o || (n = h({}, n));
    var v = e.z2EmphasisLift;
    n.z2 = e.z2 + (v ?? ae);
  }
  return n;
}
i(he, "createEmphasisDefaultState");
function ge(e, t, r) {
  if (r && r.z2 == null) {
    r = h({}, r);
    var n = e.z2SelectLift;
    r.z2 = e.z2 + (n ?? oe);
  }
  return r;
}
i(ge, "createSelectDefaultState");
function Se(e, t, r) {
  var n = z(e.currentStates, t) >= 0, a = e.style.opacity, o = n ? null : ve(e, ["opacity"], t, {
    opacity: 1
  });
  r = r || {};
  var l = r.style || {};
  return l.opacity == null && (r = h({}, r), l = h({
    // Already being applied 'emphasis'. DON'T mul opacity multiple times.
    opacity: n ? a : o.opacity * 0.1
  }, l), r.style = l), r;
}
i(Se, "createBlurDefaultState");
function T(e, t) {
  var r = this.states[e];
  if (this.style) {
    if (e === "emphasis")
      return he(this, e, t, r);
    if (e === "blur")
      return Se(this, e, r);
    if (e === "select")
      return ge(this, e, r);
  }
  return r;
}
i(T, "elementStateProxy");
function de(e) {
  e.stateProxy = T;
  var t = e.getTextContent(), r = e.getTextGuideLine();
  t && (t.stateProxy = T), r && (r.stateProxy = T);
}
i(de, "setDefaultStateProxy");
function G(e, t) {
  !K(e, t) && !e.__highByOuter && g(e, j);
}
i(G, "enterEmphasisWhenMouseOver");
function F(e, t) {
  !K(e, t) && !e.__highByOuter && g(e, q);
}
i(F, "leaveEmphasisWhenMouseOut");
function Ge(e, t) {
  e.__highByOuter |= 1 << (t || 0), g(e, j);
}
i(Ge, "enterEmphasis");
function Fe(e, t) {
  !(e.__highByOuter &= ~(1 << (t || 0))) && g(e, q);
}
i(Fe, "leaveEmphasis");
function Ve(e) {
  g(e, H);
}
i(Ve, "enterBlur");
function pe(e) {
  g(e, J);
}
i(pe, "leaveBlur");
function me(e) {
  g(e, ce);
}
i(me, "enterSelect");
function ye(e) {
  g(e, se);
}
i(ye, "leaveSelect");
function K(e, t) {
  return e.__highDownSilentOnTouch && t.zrByTouch;
}
i(K, "shouldSilent");
function De(e) {
  var t = e.getModel(), r = [], n = [];
  t.eachComponent(function(a, o) {
    var l = w(o), f = a === "series", c = f ? e.getViewOfSeriesModel(o) : e.getViewOfComponentModel(o);
    !f && n.push(c), l.isBlured && (c.group.traverse(function(u) {
      J(u);
    }), f && r.push(o)), l.isBlured = !1;
  }), d(n, function(a) {
    a && a.toggleBlurSeries && a.toggleBlurSeries(r, !1, t);
  });
}
i(De, "allLeaveBlur");
function O(e, t, r, n) {
  var a = n.getModel();
  r = r || "coordinateSystem";
  function o(u, v) {
    for (var s = 0; s < v.length; s++) {
      var m = u.getItemGraphicEl(v[s]);
      m && pe(m);
    }
  }
  if (i(o, "leaveBlurOfIndices"), e != null && !(!t || t === "none")) {
    var l = a.getSeriesByIndex(e), f = l.coordinateSystem;
    f && f.master && (f = f.master);
    var c = [];
    a.eachSeries(function(u) {
      var v = l === u, s = u.coordinateSystem;
      s && s.master && (s = s.master);
      var m = s && f ? s === f : v;
      if (!// Not blur other series if blurScope series
      (r === "series" && !v || r === "coordinateSystem" && !m || t === "series" && v)) {
        var $ = n.getViewOfSeriesModel(u);
        if ($.group.traverse(function(x) {
          x.__highByOuter && v && t === "self" || H(x);
        }), te(t))
          o(u.getData(), t);
        else if (re(t))
          for (var E = ne(t), y = 0; y < E.length; y++)
            o(u.getData(E[y]), t[E[y]]);
        c.push(u), w(u).isBlured = !0;
      }
    }), a.eachComponent(function(u, v) {
      if (u !== "series") {
        var s = n.getViewOfComponentModel(v);
        s && s.toggleBlurSeries && s.toggleBlurSeries(c, !0, a);
      }
    });
  }
}
i(O, "blurSeries");
function V(e, t, r) {
  if (!(e == null || t == null)) {
    var n = r.getModel().getComponent(e, t);
    if (n) {
      w(n).isBlured = !0;
      var a = r.getViewOfComponentModel(n);
      !a || !a.focusBlurEnabled || a.group.traverse(function(o) {
        H(o);
      });
    }
  }
}
i(V, "blurComponent");
function Ne(e, t, r) {
  var n = e.seriesIndex, a = e.getData(t.dataType);
  if (!a) {
    process.env.NODE_ENV !== "production" && D("Unknown dataType " + t.dataType);
    return;
  }
  var o = R(a, t);
  o = (M(o) ? o[0] : o) || 0;
  var l = a.getItemGraphicEl(o);
  if (!l)
    for (var f = a.count(), c = 0; !l && c < f; )
      l = a.getItemGraphicEl(c++);
  if (l) {
    var u = p(l);
    O(n, u.focus, u.blurScope, r);
  } else {
    var v = e.get(["emphasis", "focus"]), s = e.get(["emphasis", "blurScope"]);
    v != null && O(n, v, s, r);
  }
}
i(Ne, "blurSeriesFromHighlightPayload");
function Q(e, t, r, n) {
  var a = {
    focusSelf: !1,
    dispatchers: null
  };
  if (e == null || e === "series" || t == null || r == null)
    return a;
  var o = n.getModel().getComponent(e, t);
  if (!o)
    return a;
  var l = n.getViewOfComponentModel(o);
  if (!l || !l.findHighDownDispatchers)
    return a;
  for (var f = l.findHighDownDispatchers(r), c, u = 0; u < f.length; u++)
    if (process.env.NODE_ENV !== "production" && !b(f[u]) && D("param should be highDownDispatcher"), p(f[u]).focus === "self") {
      c = !0;
      break;
    }
  return {
    focusSelf: c,
    dispatchers: f
  };
}
i(Q, "findComponentHighDownDispatchers");
function Me(e, t, r) {
  process.env.NODE_ENV !== "production" && !b(e) && D("param should be highDownDispatcher");
  var n = p(e), a = Q(n.componentMainType, n.componentIndex, n.componentHighDownName, r), o = a.dispatchers, l = a.focusSelf;
  o ? (l && V(n.componentMainType, n.componentIndex, r), d(o, function(f) {
    return G(f, t);
  })) : (O(n.seriesIndex, n.focus, n.blurScope, r), n.focus === "self" && V(n.componentMainType, n.componentIndex, r), G(e, t));
}
i(Me, "handleGlobalMouseOverForHighDown");
function ze(e, t, r) {
  process.env.NODE_ENV !== "production" && !b(e) && D("param should be highDownDispatcher"), De(r);
  var n = p(e), a = Q(n.componentMainType, n.componentIndex, n.componentHighDownName, r).dispatchers;
  a ? d(a, function(o) {
    return F(o, t);
  }) : F(e, t);
}
i(ze, "handleGlobalMouseOutForHighDown");
function Ye(e, t, r) {
  if (we(t)) {
    var n = t.dataType, a = e.getData(n), o = R(a, t);
    M(o) || (o = [o]), e[t.type === Z ? "toggleSelect" : t.type === W ? "select" : "unselect"](o, n);
  }
}
i(Ye, "toggleSelectionFromPayload");
function Re(e) {
  var t = e.getAllData();
  d(t, function(r) {
    var n = r.data, a = r.type;
    n.eachItemGraphicEl(function(o, l) {
      e.isSelected(l, a) ? me(o) : ye(o);
    });
  });
}
i(Re, "updateSeriesElementSelection");
function Ue(e) {
  var t = [];
  return e.eachSeries(function(r) {
    var n = r.getAllData();
    d(n, function(a) {
      a.data;
      var o = a.type, l = r.getSelectedDataIndices();
      if (l.length > 0) {
        var f = {
          dataIndex: l,
          seriesIndex: r.seriesIndex
        };
        o != null && (f.dataType = o), t.push(f);
      }
    });
  }), t;
}
i(Ue, "getAllSelectedIndices");
function _e(e, t, r) {
  X(e, !0), g(e, de), Te(e, t, r);
}
i(_e, "enableHoverEmphasis");
function Ee(e) {
  X(e, !1);
}
i(Ee, "disableHoverEmphasis");
function We(e, t, r, n) {
  n ? Ee(e) : _e(e, t, r);
}
i(We, "toggleHoverEmphasis");
function Te(e, t, r) {
  var n = p(e);
  t != null ? (n.focus = t, n.blurScope = r) : n.focus && (n.focus = null);
}
i(Te, "enableHoverFocus");
var N = ["emphasis", "blur", "select"], Oe = {
  itemStyle: "getItemStyle",
  lineStyle: "getLineStyle",
  areaStyle: "getAreaStyle"
};
function Ze(e, t, r, n) {
  r = r || "itemStyle";
  for (var a = 0; a < N.length; a++) {
    var o = N[a], l = t.getModel([o, r]), f = e.ensureState(o);
    f.style = l[Oe[r]]();
  }
}
i(Ze, "setStatesStylesFromModel");
function X(e, t) {
  var r = t === !1, n = e;
  e.highDownSilentOnTouch && (n.__highDownSilentOnTouch = e.highDownSilentOnTouch), (!r || n.__highDownDispatcher) && (n.__highByOuter = n.__highByOuter || 0, n.__highDownDispatcher = !r);
}
i(X, "setAsHighDownDispatcher");
function b(e) {
  return !!(e && e.__highDownDispatcher);
}
i(b, "isHighDownDispatcher");
function je(e) {
  var t = P[e];
  return t == null && L <= 32 && (t = P[e] = L++), t;
}
i(je, "getHighlightDigit");
function we(e) {
  var t = e.type;
  return t === W || t === fe || t === Z;
}
i(we, "isSelectChangePayload");
function qe(e) {
  var t = e.type;
  return t === le || t === ue;
}
i(qe, "isHighDownPayload");
function Je(e) {
  var t = U(e);
  t.normalFill = e.style.fill, t.normalStroke = e.style.stroke;
  var r = e.states.select || {};
  t.selectFill = r.style && r.style.fill || null, t.selectStroke = r.style && r.style.stroke || null;
}
i(Je, "savePathStates");
export {
  Pe as DISPLAY_STATES,
  ue as DOWNPLAY_ACTION_TYPE,
  le as HIGHLIGHT_ACTION_TYPE,
  C as HOVER_STATE_BLUR,
  B as HOVER_STATE_EMPHASIS,
  I as HOVER_STATE_NORMAL,
  W as SELECT_ACTION_TYPE,
  Le as SPECIAL_STATES,
  Z as TOGGLE_SELECT_ACTION_TYPE,
  fe as UNSELECT_ACTION_TYPE,
  ae as Z2_EMPHASIS_LIFT,
  oe as Z2_SELECT_LIFT,
  De as allLeaveBlur,
  V as blurComponent,
  O as blurSeries,
  Ne as blurSeriesFromHighlightPayload,
  Ee as disableHoverEmphasis,
  _e as enableHoverEmphasis,
  Te as enableHoverFocus,
  Ve as enterBlur,
  Ge as enterEmphasis,
  G as enterEmphasisWhenMouseOver,
  me as enterSelect,
  Q as findComponentHighDownDispatchers,
  Ue as getAllSelectedIndices,
  je as getHighlightDigit,
  ze as handleGlobalMouseOutForHighDown,
  Me as handleGlobalMouseOverForHighDown,
  b as isHighDownDispatcher,
  qe as isHighDownPayload,
  we as isSelectChangePayload,
  pe as leaveBlur,
  Fe as leaveEmphasis,
  F as leaveEmphasisWhenMouseOut,
  ye as leaveSelect,
  Je as savePathStates,
  X as setAsHighDownDispatcher,
  de as setDefaultStateProxy,
  ke as setStatesFlag,
  Ze as setStatesStylesFromModel,
  We as toggleHoverEmphasis,
  Ye as toggleSelectionFromPayload,
  Re as updateSeriesElementSelection
};
