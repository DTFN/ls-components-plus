var ur = Object.defineProperty;
var u = (r, e) => ur(r, "name", { value: e, configurable: !0 });
import { __extends as sr } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { assert as R, each as g, bind as or, merge as V, clone as b, map as F, curry as l, defaults as fr } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import hr from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/Eventful/index.js";
import { transformDirection as vr, getTransform as dr } from "../../../util/graphic/index.js";
import { take as pr, release as gr } from "../interactionMutex/index.js";
import _r from "../../../data/DataDiffer/index.js";
import z from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/Group/index.js";
import mr from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Polyline/index.js";
import cr from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Polygon/index.js";
import X from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/graphic/shape/Rect/index.js";
var m = !0, E = Math.min, C = Math.max, lr = Math.pow, br = 1e4, Cr = 6, yr = 6, Y = "globalPan", Er = {
  w: [0, 0],
  e: [0, 1],
  n: [1, 0],
  s: [1, 1]
}, wr = {
  w: "ew",
  e: "ew",
  n: "ns",
  s: "ns",
  ne: "nesw",
  sw: "nesw",
  nw: "nwse",
  se: "nwse"
}, W = {
  brushStyle: {
    lineWidth: 2,
    stroke: "rgba(210,219,238,0.3)",
    fill: "#D2DBEE"
  },
  transformable: !0,
  brushMode: "single",
  removeOnClick: !1
}, Tr = 0, Zr = (
  /** @class */
  function(r) {
    sr(e, r);
    function e(t) {
      var n = r.call(this) || this;
      return n._track = [], n._covers = [], n._handlers = {}, process.env.NODE_ENV !== "production" && R(t), n._zr = t, n.group = new z(), n._uid = "brushController_" + Tr++, g(Pr, function(a, i) {
        this._handlers[i] = or(a, this);
      }, n), n;
    }
    return u(e, "BrushController"), e.prototype.enableBrush = function(t) {
      return process.env.NODE_ENV !== "production" && R(this._mounted), this._brushType && this._doDisableBrush(), t.brushType && this._doEnableBrush(t), this;
    }, e.prototype._doEnableBrush = function(t) {
      var n = this._zr;
      this._enableGlobalPan || pr(n, Y, this._uid), g(this._handlers, function(a, i) {
        n.on(i, a);
      }), this._brushType = t.brushType, this._brushOption = V(b(W), t, !0);
    }, e.prototype._doDisableBrush = function() {
      var t = this._zr;
      gr(t, Y, this._uid), g(this._handlers, function(n, a) {
        t.off(a, n);
      }), this._brushType = this._brushOption = null;
    }, e.prototype.setPanels = function(t) {
      if (t && t.length) {
        var n = this._panels = {};
        g(t, function(a) {
          n[a.panelId] = b(a);
        });
      } else
        this._panels = null;
      return this;
    }, e.prototype.mount = function(t) {
      t = t || {}, process.env.NODE_ENV !== "production" && (this._mounted = !0), this._enableGlobalPan = t.enableGlobalPan;
      var n = this.group;
      return this._zr.add(n), n.attr({
        x: t.x || 0,
        y: t.y || 0,
        rotation: t.rotation || 0,
        scaleX: t.scaleX || 1,
        scaleY: t.scaleY || 1
      }), this._transform = n.getLocalTransform(), this;
    }, e.prototype.updateCovers = function(t) {
      process.env.NODE_ENV !== "production" && R(this._mounted), t = F(t, function(h) {
        return V(b(W), h, !0);
      });
      var n = "\0-brush-index-", a = this._covers, i = this._covers = [], s = this, o = this._creatingCover;
      return new _r(a, t, d, f).add(p).update(p).remove(w).execute(), this;
      function f(h, v) {
        return (h.id != null ? h.id : n + v) + "-" + h.brushType;
      }
      u(f, "getKey");
      function d(h, v) {
        return f(h.__brushOption, v);
      }
      u(d, "oldGetKey");
      function p(h, v) {
        var y = t[h];
        if (v != null && a[v] === o)
          i[h] = a[v];
        else {
          var T = i[h] = v != null ? (a[v].__brushOption = y, a[v]) : J(s, $(s, y));
          k(s, T);
        }
      }
      u(p, "addOrUpdate");
      function w(h) {
        a[h] !== o && s.group.remove(a[h]);
      }
      u(w, "remove");
    }, e.prototype.unmount = function() {
      if (!(process.env.NODE_ENV !== "production" && !this._mounted))
        return this.enableBrush(!1), D(this), this._zr.remove(this.group), process.env.NODE_ENV !== "production" && (this._mounted = !1), this;
    }, e.prototype.dispose = function() {
      this.unmount(), this.off();
    }, e;
  }(hr)
);
function $(r, e) {
  var t = O[e.brushType].createCover(r, e);
  return t.__brushOption = e, q(t, e), r.group.add(t), t;
}
u($, "createCover");
function J(r, e) {
  var t = L(e);
  return t.endCreating && (t.endCreating(r, e), q(e, e.__brushOption)), e;
}
u(J, "endCreating");
function Q(r, e) {
  var t = e.__brushOption;
  L(e).updateCoverShape(r, e, t.range, t);
}
u(Q, "updateCoverShape");
function q(r, e) {
  var t = e.z;
  t == null && (t = br), r.traverse(function(n) {
    n.z = t, n.z2 = t;
  });
}
u(q, "updateZ");
function k(r, e) {
  L(e).updateCommon(r, e), Q(r, e);
}
u(k, "updateCoverAfterCreation");
function L(r) {
  return O[r.__brushOption.brushType];
}
u(L, "getCoverRenderer");
function M(r, e, t) {
  var n = r._panels;
  if (!n)
    return m;
  var a, i = r._transform;
  return g(n, function(s) {
    s.isTargetByCursor(e, t, i) && (a = s);
  }), a;
}
u(M, "getPanelByPoint");
function x(r, e) {
  var t = r._panels;
  if (!t)
    return m;
  var n = e.__brushOption.panelId;
  return n != null ? t[n] : m;
}
u(x, "getPanelByCover");
function D(r) {
  var e = r._covers, t = e.length;
  return g(e, function(n) {
    r.group.remove(n);
  }, r), e.length = 0, !!t;
}
u(D, "clearCovers");
function c(r, e) {
  var t = F(r._covers, function(n) {
    var a = n.__brushOption, i = b(a.range);
    return {
      brushType: a.brushType,
      panelId: a.panelId,
      range: i
    };
  });
  r.trigger("brush", {
    areas: t,
    isEnd: !!e.isEnd,
    removeOnClick: !!e.removeOnClick
  });
}
u(c, "trigger");
function Rr(r) {
  var e = r._track;
  if (!e.length)
    return !1;
  var t = e[e.length - 1], n = e[0], a = t[0] - n[0], i = t[1] - n[1], s = lr(a * a + i * i, 0.5);
  return s > Cr;
}
u(Rr, "shouldShowCover");
function rr(r) {
  var e = r.length - 1;
  return e < 0 && (e = 0), [r[0], r[e]];
}
u(rr, "getTrackEnds");
function er(r, e, t, n) {
  var a = new z();
  return a.add(new X({
    name: "main",
    style: A(t),
    silent: !0,
    draggable: !0,
    cursor: "move",
    drift: l(Z, r, e, a, ["n", "s", "w", "e"]),
    ondragend: l(c, e, {
      isEnd: !0
    })
  })), g(n, function(i) {
    a.add(new X({
      name: i.join(""),
      style: {
        opacity: 0
      },
      draggable: !0,
      silent: !0,
      invisible: !0,
      drift: l(Z, r, e, a, i),
      ondragend: l(c, e, {
        isEnd: !0
      })
    }));
  }), a;
}
u(er, "createBaseRectCover");
function tr(r, e, t, n) {
  var a = n.brushStyle.lineWidth || 0, i = C(a, yr), s = t[0][0], o = t[1][0], f = s - a / 2, d = o - a / 2, p = t[0][1], w = t[1][1], h = p - i + a / 2, v = w - i + a / 2, y = p - s, T = w - o, U = y + a, H = T + a;
  _(r, e, "main", s, o, y, T), n.transformable && (_(r, e, "w", f, d, i, H), _(r, e, "e", h, d, i, H), _(r, e, "n", f, d, U, i), _(r, e, "s", f, v, U, i), _(r, e, "nw", f, d, i, i), _(r, e, "ne", h, d, i, i), _(r, e, "sw", f, v, i, i), _(r, e, "se", h, v, i, i));
}
u(tr, "updateBaseRect");
function B(r, e) {
  var t = e.__brushOption, n = t.transformable, a = e.childAt(0);
  a.useStyle(A(t)), a.attr({
    silent: !n,
    cursor: n ? "move" : "default"
  }), g([["w"], ["e"], ["n"], ["s"], ["s", "e"], ["s", "w"], ["n", "e"], ["n", "w"]], function(i) {
    var s = e.childOfName(i.join("")), o = i.length === 1 ? N(r, i[0]) : Dr(r, i);
    s && s.attr({
      silent: !n,
      invisible: !n,
      cursor: n ? wr[o] + "-resize" : null
    });
  });
}
u(B, "updateCommon");
function _(r, e, t, n, a, i, s) {
  var o = e.childOfName(t);
  o && o.setShape(Nr(G(r, e, [[n, a], [n + i, a + s]])));
}
u(_, "updateRectShape");
function A(r) {
  return fr({
    strokeNoScale: !0
  }, r.brushStyle);
}
u(A, "makeStyle");
function nr(r, e, t, n) {
  var a = [E(r, t), E(e, n)], i = [C(r, t), C(e, n)];
  return [
    [a[0], i[0]],
    [a[1], i[1]]
    // y range
  ];
}
u(nr, "formatRectRange");
function Or(r) {
  return dr(r.group);
}
u(Or, "getTransform");
function N(r, e) {
  var t = {
    w: "left",
    e: "right",
    n: "top",
    s: "bottom"
  }, n = {
    left: "w",
    right: "e",
    top: "n",
    bottom: "s"
  }, a = vr(t[e], Or(r));
  return n[a];
}
u(N, "getGlobalDirection1");
function Dr(r, e) {
  var t = [N(r, e[0]), N(r, e[1])];
  return (t[0] === "e" || t[0] === "w") && t.reverse(), t.join("");
}
u(Dr, "getGlobalDirection2");
function Z(r, e, t, n, a, i) {
  var s = t.__brushOption, o = r.toRectRange(s.range), f = ar(e, a, i);
  g(n, function(d) {
    var p = Er[d];
    o[p[0]][p[1]] += f[p[0]];
  }), s.range = r.fromRectRange(nr(o[0][0], o[1][0], o[0][1], o[1][1])), k(e, t), c(e, {
    isEnd: !1
  });
}
u(Z, "driftRect");
function Br(r, e, t, n) {
  var a = e.__brushOption.range, i = ar(r, t, n);
  g(a, function(s) {
    s[0] += i[0], s[1] += i[1];
  }), k(r, e), c(r, {
    isEnd: !1
  });
}
u(Br, "driftPolygon");
function ar(r, e, t) {
  var n = r.group, a = n.transformCoordToLocal(e, t), i = n.transformCoordToLocal(0, 0);
  return [a[0] - i[0], a[1] - i[1]];
}
u(ar, "toLocalDelta");
function G(r, e, t) {
  var n = x(r, e);
  return n && n !== m ? n.clipPath(t, r._transform) : b(t);
}
u(G, "clipByPanel");
function Nr(r) {
  var e = E(r[0][0], r[1][0]), t = E(r[0][1], r[1][1]), n = C(r[0][0], r[1][0]), a = C(r[0][1], r[1][1]);
  return {
    x: e,
    y: t,
    width: n - e,
    height: a - t
  };
}
u(Nr, "pointsToRect");
function Sr(r, e, t) {
  if (
    // Check active
    !(!r._brushType || zr(r, e.offsetX, e.offsetY))
  ) {
    var n = r._zr, a = r._covers, i = M(r, e, t);
    if (!r._dragging)
      for (var s = 0; s < a.length; s++) {
        var o = a[s].__brushOption;
        if (i && (i === m || o.panelId === i.panelId) && O[o.brushType].contain(a[s], t[0], t[1]))
          return;
      }
    i && n.setCursorStyle("crosshair");
  }
}
u(Sr, "resetCursor");
function S(r) {
  var e = r.event;
  e.preventDefault && e.preventDefault();
}
u(S, "preventDefault");
function P(r, e, t) {
  return r.childOfName("main").contain(e, t);
}
u(P, "mainShapeContain");
function ir(r, e, t, n) {
  var a = r._creatingCover, i = r._creatingPanel, s = r._brushOption, o;
  if (r._track.push(t.slice()), Rr(r) || a) {
    if (i && !a) {
      s.brushMode === "single" && D(r);
      var f = b(s);
      f.brushType = j(f.brushType, i), f.panelId = i === m ? null : i.panelId, a = r._creatingCover = $(r, f), r._covers.push(a);
    }
    if (a) {
      var d = O[j(r._brushType, i)], p = a.__brushOption;
      p.range = d.getCreatingRange(G(r, a, r._track)), n && (J(r, a), d.updateCommon(r, a)), Q(r, a), o = {
        isEnd: n
      };
    }
  } else n && s.brushMode === "single" && s.removeOnClick && M(r, e, t) && D(r) && (o = {
    isEnd: n,
    removeOnClick: !0
  });
  return o;
}
u(ir, "updateCoverByMouse");
function j(r, e) {
  return r === "auto" ? (process.env.NODE_ENV !== "production" && R(e && e.defaultBrushType, 'MUST have defaultBrushType when brushType is "atuo"'), e.defaultBrushType) : r;
}
u(j, "determineBrushType");
var Pr = {
  mousedown: /* @__PURE__ */ u(function(r) {
    if (this._dragging)
      K(this, r);
    else if (!r.target || !r.target.draggable) {
      S(r);
      var e = this.group.transformCoordToLocal(r.offsetX, r.offsetY);
      this._creatingCover = null;
      var t = this._creatingPanel = M(this, r, e);
      t && (this._dragging = !0, this._track = [e.slice()]);
    }
  }, "mousedown"),
  mousemove: /* @__PURE__ */ u(function(r) {
    var e = r.offsetX, t = r.offsetY, n = this.group.transformCoordToLocal(e, t);
    if (Sr(this, r, n), this._dragging) {
      S(r);
      var a = ir(this, r, n, !1);
      a && c(this, a);
    }
  }, "mousemove"),
  mouseup: /* @__PURE__ */ u(function(r) {
    K(this, r);
  }, "mouseup")
};
function K(r, e) {
  if (r._dragging) {
    S(e);
    var t = e.offsetX, n = e.offsetY, a = r.group.transformCoordToLocal(t, n), i = ir(r, e, a, !0);
    r._dragging = !1, r._track = [], r._creatingCover = null, i && c(r, i);
  }
}
u(K, "handleDragEnd");
function zr(r, e, t) {
  var n = r._zr;
  return e < 0 || e > n.getWidth() || t < 0 || t > n.getHeight();
}
u(zr, "isOutsideZrArea");
var O = {
  lineX: I(0),
  lineY: I(1),
  rect: {
    createCover: /* @__PURE__ */ u(function(r, e) {
      function t(n) {
        return n;
      }
      return u(t, "returnInput"), er({
        toRectRange: t,
        fromRectRange: t
      }, r, e, [["w"], ["e"], ["n"], ["s"], ["s", "e"], ["s", "w"], ["n", "e"], ["n", "w"]]);
    }, "createCover"),
    getCreatingRange: /* @__PURE__ */ u(function(r) {
      var e = rr(r);
      return nr(e[1][0], e[1][1], e[0][0], e[0][1]);
    }, "getCreatingRange"),
    updateCoverShape: /* @__PURE__ */ u(function(r, e, t, n) {
      tr(r, e, t, n);
    }, "updateCoverShape"),
    updateCommon: B,
    contain: P
  },
  polygon: {
    createCover: /* @__PURE__ */ u(function(r, e) {
      var t = new z();
      return t.add(new mr({
        name: "main",
        style: A(e),
        silent: !0
      })), t;
    }, "createCover"),
    getCreatingRange: /* @__PURE__ */ u(function(r) {
      return r;
    }, "getCreatingRange"),
    endCreating: /* @__PURE__ */ u(function(r, e) {
      e.remove(e.childAt(0)), e.add(new cr({
        name: "main",
        draggable: !0,
        drift: l(Br, r, e),
        ondragend: l(c, r, {
          isEnd: !0
        })
      }));
    }, "endCreating"),
    updateCoverShape: /* @__PURE__ */ u(function(r, e, t, n) {
      e.childAt(0).setShape({
        points: G(r, e, t)
      });
    }, "updateCoverShape"),
    updateCommon: B,
    contain: P
  }
};
function I(r) {
  return {
    createCover: /* @__PURE__ */ u(function(e, t) {
      return er({
        toRectRange: /* @__PURE__ */ u(function(n) {
          var a = [n, [0, 100]];
          return r && a.reverse(), a;
        }, "toRectRange"),
        fromRectRange: /* @__PURE__ */ u(function(n) {
          return n[r];
        }, "fromRectRange")
      }, e, t, [[["w"], ["e"]], [["n"], ["s"]]][r]);
    }, "createCover"),
    getCreatingRange: /* @__PURE__ */ u(function(e) {
      var t = rr(e), n = E(t[0][r], t[1][r]), a = C(t[0][r], t[1][r]);
      return [n, a];
    }, "getCreatingRange"),
    updateCoverShape: /* @__PURE__ */ u(function(e, t, n, a) {
      var i, s = x(e, t);
      if (s !== m && s.getLinearBrushOtherExtent)
        i = s.getLinearBrushOtherExtent(r);
      else {
        var o = e._zr;
        i = [0, [o.getWidth(), o.getHeight()][1 - r]];
      }
      var f = [n, i];
      r && f.reverse(), tr(e, t, f, a);
    }, "updateCoverShape"),
    updateCommon: B,
    contain: P
  };
}
u(I, "getLineRenderer");
export {
  Zr as default
};
