var c = Object.defineProperty;
var r = (o, e) => c(o, "name", { value: e, configurable: !0 });
import { __extends as g } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import i from "../LegendModel/index.js";
import { getLayoutParams as m, mergeLayoutParam as u } from "../../../util/layout/index.js";
import { inheritDefaultOption as d } from "../../../util/component/index.js";
var z = (
  /** @class */
  function(o) {
    g(e, o);
    function e() {
      var t = o !== null && o.apply(this, arguments) || this;
      return t.type = e.type, t;
    }
    return r(e, "ScrollableLegendModel"), e.prototype.setScrollDataIndex = function(t) {
      this.option.scrollDataIndex = t;
    }, e.prototype.init = function(t, a, n) {
      var p = m(t);
      o.prototype.init.call(this, t, a, n), l(this, t, p);
    }, e.prototype.mergeOption = function(t, a) {
      o.prototype.mergeOption.call(this, t, a), l(this, this.option, t);
    }, e.type = "legend.scroll", e.defaultOption = d(i.defaultOption, {
      scrollDataIndex: 0,
      pageButtonItemGap: 5,
      pageButtonGap: null,
      pageButtonPosition: "end",
      pageFormatter: "{current}/{total}",
      pageIcons: {
        horizontal: ["M0,0L12,-10L12,10z", "M0,0L-12,-10L-12,10z"],
        vertical: ["M0,0L20,0L10,-20z", "M0,0L20,0L10,20z"]
      },
      pageIconColor: "#2f4554",
      pageIconInactiveColor: "#aaa",
      pageIconSize: 15,
      pageTextStyle: {
        color: "#333"
      },
      animationDurationUpdate: 800
    }), e;
  }(i)
);
function l(o, e, t) {
  var a = o.getOrient(), n = [1, 1];
  n[a.index] = 0, u(e, t, {
    type: "box",
    ignoreSize: !!n
  });
}
r(l, "mergeAndNormalizeLayoutParams");
export {
  z as default
};
