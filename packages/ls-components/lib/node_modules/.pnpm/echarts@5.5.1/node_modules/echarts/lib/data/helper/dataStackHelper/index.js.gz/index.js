var g = Object.defineProperty;
var s = (a, e) => g(a, "name", { value: e, configurable: !0 });
import { each as k, isString as p } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { isSeriesDataSchema as b } from "../SeriesDataSchema/index.js";
function R(a, e, u) {
  u = u || {};
  var l = u.byIndex, x = u.stackedCoordDimension, t, o, m;
  B(e) ? t = e : (o = e.schema, t = o.dimensions, m = e.store);
  var y = !!(a && a.get("stack")), n, i, v, c;
  if (k(t, function(r, S) {
    p(r) && (t[S] = r = {
      name: r
    }), y && !r.isExtraCoord && (!l && !n && r.ordinalMeta && (n = r), !i && r.type !== "ordinal" && r.type !== "time" && (!x || x === r.coordDim) && (i = r));
  }), i && !l && !n && (l = !0), i) {
    v = "__\0ecstackresult_" + a.id, c = "__\0ecstackedover_" + a.id, n && (n.createInvertedIndices = !0);
    var h = i.coordDim, d = i.type, D = 0;
    k(t, function(r) {
      r.coordDim === h && D++;
    });
    var C = {
      name: v,
      coordDim: h,
      coordDimIndex: D,
      type: d,
      isExtraCoord: !0,
      isCalculationCoord: !0,
      storeDimIndex: t.length
    }, f = {
      name: c,
      // This dimension contains stack base (generally, 0), so do not set it as
      // `stackedDimCoordDim` to avoid extent calculation, consider log scale.
      coordDim: c,
      coordDimIndex: D + 1,
      type: d,
      isExtraCoord: !0,
      isCalculationCoord: !0,
      storeDimIndex: t.length + 1
    };
    o ? (m && (C.storeDimIndex = m.ensureCalculationDimension(c, d), f.storeDimIndex = m.ensureCalculationDimension(v, d)), o.appendCalculationDimension(C), o.appendCalculationDimension(f)) : (t.push(C), t.push(f));
  }
  return {
    stackedDimension: i && i.name,
    stackedByDimension: n && n.name,
    isStackedByIndex: l,
    stackedOverDimension: c,
    stackResultDimension: v
  };
}
s(R, "enableDataStack");
function B(a) {
  return !b(a.schema);
}
s(B, "isLegacyDimensionsInput");
function E(a, e) {
  return !!e && e === a.getCalculationInfo("stackedDimension");
}
s(E, "isDimensionStacked");
function j(a, e) {
  return E(a, e) ? a.getCalculationInfo("stackResultDimension") : e;
}
s(j, "getStackedDimension");
export {
  R as enableDataStack,
  j as getStackedDimension,
  E as isDimensionStacked
};
