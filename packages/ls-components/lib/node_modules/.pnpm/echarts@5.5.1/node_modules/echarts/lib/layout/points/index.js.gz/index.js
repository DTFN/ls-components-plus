var k = Object.defineProperty;
var i = (s, f) => k(s, "name", { value: f, configurable: !0 });
import { map as C } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import L from "../../chart/helper/createRenderPlanner/index.js";
import { isDimensionStacked as D } from "../../data/helper/dataStackHelper/index.js";
import { createFloat32Array as P } from "../../util/vendor/index.js";
function b(s, f) {
  return {
    seriesType: s,
    plan: L(),
    reset: /* @__PURE__ */ i(function(m) {
      var t = m.getData(), a = m.coordinateSystem;
      if (m.pipelineContext, !!a) {
        var e = C(a.dimensions, function(r) {
          return t.mapDimension(r);
        }).slice(0, 2), d = e.length, l = t.getCalculationInfo("stackResultDimension");
        D(t, e[0]) && (e[0] = l), D(t, e[1]) && (e[1] = l);
        var u = t.getStore(), p = t.getDimensionIndex(e[0]), I = t.getDimensionIndex(e[1]);
        return d && {
          progress: /* @__PURE__ */ i(function(r, x) {
            for (var S = r.end - r.start, v = P(S * d), c = [], g = [], n = r.start, y = 0; n < r.end; n++) {
              var o = void 0;
              if (d === 1) {
                var T = u.get(p, n);
                o = a.dataToPoint(T, null, g);
              } else
                c[0] = u.get(p, n), c[1] = u.get(I, n), o = a.dataToPoint(c, null, g);
              v[y++] = o[0], v[y++] = o[1];
            }
            x.setLayout("points", v);
          }, "progress")
        };
      }
    }, "reset")
  };
}
i(b, "pointsLayout");
export {
  b as default
};
