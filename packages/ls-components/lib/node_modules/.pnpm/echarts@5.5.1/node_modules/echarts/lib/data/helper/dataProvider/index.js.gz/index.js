var b = Object.defineProperty;
var i = (t, r) => b(t, "name", { value: r, configurable: !0 });
import { each as W, assert as E, isTypedArray as x, extend as K, bind as F } from "../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getDataItemValue as L } from "../../../util/model/index.js";
import { isSourceInstance as P, createSourceFromSeriesDataOption as J } from "../../Source/index.js";
import { SOURCE_FORMAT_ARRAY_ROWS as l, SERIES_LAYOUT_BY_COLUMN as M, SERIES_LAYOUT_BY_ROW as T, SOURCE_FORMAT_OBJECT_ROWS as A, SOURCE_FORMAT_KEYED_COLUMNS as N, SOURCE_FORMAT_ORIGINAL as O, SOURCE_FORMAT_TYPED_ARRAY as R } from "../../../util/types/index.js";
var h, D, m, C, U, nt = (
  /** @class */
  function() {
    function t(r, a) {
      var n = P(r) ? r : J(r);
      this._source = n;
      var f = this._data = n.data;
      if (n.sourceFormat === R) {
        if (process.env.NODE_ENV !== "production" && a == null)
          throw new Error("Typed array data must specify dimension size");
        this._offset = 0, this._dimSize = a, this._data = f;
      }
      U(this, f, n);
    }
    return i(t, "DefaultDataProvider"), t.prototype.getSource = function() {
      return this._source;
    }, t.prototype.count = function() {
      return 0;
    }, t.prototype.getItem = function(r, a) {
    }, t.prototype.appendData = function(r) {
    }, t.prototype.clean = function() {
    }, t.protoInitialize = function() {
      var r = t.prototype;
      r.pure = !1, r.persistent = !0;
    }(), t.internalField = function() {
      var r;
      U = /* @__PURE__ */ i(function(e, o, u) {
        var s = u.sourceFormat, v = u.seriesLayoutBy, p = u.startIndex, _ = u.dimensionsDefine, d = C[V(s, v)];
        if (process.env.NODE_ENV !== "production" && E(d, "Invalide sourceFormat: " + s), K(e, d), s === R)
          e.getItem = a, e.count = f, e.fillStorage = n;
        else {
          var S = q(s, v);
          e.getItem = F(S, null, o, p, _);
          var y = Q(s, v);
          e.count = F(y, null, o, p, _);
        }
      }, "mountMethods");
      var a = /* @__PURE__ */ i(function(e, o) {
        e = e - this._offset, o = o || [];
        for (var u = this._data, s = this._dimSize, v = s * e, p = 0; p < s; p++)
          o[p] = u[v + p];
        return o;
      }, "getItemForTypedArray"), n = /* @__PURE__ */ i(function(e, o, u, s) {
        for (var v = this._data, p = this._dimSize, _ = 0; _ < p; _++) {
          for (var d = s[_], S = d[0] == null ? 1 / 0 : d[0], y = d[1] == null ? -1 / 0 : d[1], G = o - e, B = u[_], I = 0; I < G; I++) {
            var g = v[I * p + _];
            B[e + I] = g, g < S && (S = g), g > y && (y = g);
          }
          d[0] = S, d[1] = y;
        }
      }, "fillStorageForTypedArray"), f = /* @__PURE__ */ i(function() {
        return this._data ? this._data.length / this._dimSize : 0;
      }, "countForTypedArray");
      C = (r = {}, r[l + "_" + M] = {
        pure: !0,
        appendData: c
      }, r[l + "_" + T] = {
        pure: !0,
        appendData: /* @__PURE__ */ i(function() {
          throw new Error('Do not support appendData when set seriesLayoutBy: "row".');
        }, "appendData")
      }, r[A] = {
        pure: !0,
        appendData: c
      }, r[N] = {
        pure: !0,
        appendData: /* @__PURE__ */ i(function(e) {
          var o = this._data;
          W(e, function(u, s) {
            for (var v = o[s] || (o[s] = []), p = 0; p < (u || []).length; p++)
              v.push(u[p]);
          });
        }, "appendData")
      }, r[O] = {
        appendData: c
      }, r[R] = {
        persistent: !1,
        pure: !0,
        appendData: /* @__PURE__ */ i(function(e) {
          process.env.NODE_ENV !== "production" && E(x(e), "Added data must be TypedArray if data in initialization is TypedArray"), this._data = e;
        }, "appendData"),
        // Clean self if data is already used.
        clean: /* @__PURE__ */ i(function() {
          this._offset += this.count(), this._data = null;
        }, "clean")
      }, r);
      function c(e) {
        for (var o = 0; o < e.length; o++)
          this._data.push(e[o]);
      }
      i(c, "appendDataSimply");
    }(), t;
  }()
), z = /* @__PURE__ */ i(function(t, r, a, n) {
  return t[n];
}, "getItemSimply"), j = (h = {}, h[l + "_" + M] = function(t, r, a, n) {
  return t[n + r];
}, h[l + "_" + T] = function(t, r, a, n, f) {
  n += r;
  for (var c = f || [], e = t, o = 0; o < e.length; o++) {
    var u = e[o];
    c[o] = u ? u[n] : null;
  }
  return c;
}, h[A] = z, h[N] = function(t, r, a, n, f) {
  for (var c = f || [], e = 0; e < a.length; e++) {
    var o = a[e].name;
    if (process.env.NODE_ENV !== "production" && o == null)
      throw new Error();
    var u = t[o];
    c[e] = u ? u[n] : null;
  }
  return c;
}, h[O] = z, h);
function q(t, r) {
  var a = j[V(t, r)];
  return process.env.NODE_ENV !== "production" && E(a, 'Do not support get item on "' + t + '", "' + r + '".'), a;
}
i(q, "getRawSourceItemGetter");
var Y = /* @__PURE__ */ i(function(t, r, a) {
  return t.length;
}, "countSimply"), H = (D = {}, D[l + "_" + M] = function(t, r, a) {
  return Math.max(0, t.length - r);
}, D[l + "_" + T] = function(t, r, a) {
  var n = t[0];
  return n ? Math.max(0, n.length - r) : 0;
}, D[A] = Y, D[N] = function(t, r, a) {
  var n = a[0].name;
  if (process.env.NODE_ENV !== "production" && n == null)
    throw new Error();
  var f = t[n];
  return f ? f.length : 0;
}, D[O] = Y, D);
function Q(t, r) {
  var a = H[V(t, r)];
  return process.env.NODE_ENV !== "production" && E(a, 'Do not support count on "' + t + '", "' + r + '".'), a;
}
i(Q, "getRawSourceDataCounter");
var w = /* @__PURE__ */ i(function(t, r, a) {
  return t[r];
}, "getRawValueSimply"), X = (m = {}, m[l] = w, m[A] = function(t, r, a) {
  return t[a];
}, m[N] = w, m[O] = function(t, r, a) {
  var n = L(t);
  return n instanceof Array ? n[r] : n;
}, m[R] = w, m);
function Z(t) {
  var r = X[t];
  return process.env.NODE_ENV !== "production" && E(r, 'Do not support get value on "' + t + '".'), r;
}
i(Z, "getRawSourceValueGetter");
function V(t, r) {
  return t === l ? t + "_" + r : t;
}
i(V, "getMethodMapKey");
function at(t, r, a) {
  if (t) {
    var n = t.getRawDataItem(r);
    if (n != null) {
      var f = t.getStore(), c = f.getSource().sourceFormat;
      if (a != null) {
        var e = t.getDimensionIndex(a), o = f.getDimensionProperty(e);
        return Z(c)(n, e, o);
      } else {
        var u = n;
        return c === O && (u = L(n)), u;
      }
    }
  }
}
i(at, "retrieveRawValue");
export {
  nt as DefaultDataProvider,
  Q as getRawSourceDataCounter,
  q as getRawSourceItemGetter,
  Z as getRawSourceValueGetter,
  at as retrieveRawValue
};
