var p = Object.defineProperty;
var t = (e, o) => p(e, "name", { value: o, configurable: !0 });
import { retrieve as c, each as A, createHashMap as m } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { SINGLE_REFERRING as f } from "../../util/model/index.js";
var u = (
  /** @class */
  function() {
    function e(o) {
      this.coordSysDims = [], this.axisMap = m(), this.categoryAxisMap = m(), this.coordSysName = o;
    }
    return t(e, "CoordSysInfo"), e;
  }()
);
function S(e) {
  var o = e.get("coordinateSystem"), i = new u(o), n = v[o];
  if (n)
    return n(e, i, i.axisMap, i.categoryAxisMap), i;
}
t(S, "getCoordSysInfoBySeries");
var v = {
  cartesian2d: /* @__PURE__ */ t(function(e, o, i, n) {
    var r = e.getReferringComponents("xAxis", f).models[0], s = e.getReferringComponents("yAxis", f).models[0];
    if (process.env.NODE_ENV !== "production") {
      if (!r)
        throw new Error('xAxis "' + c(e.get("xAxisIndex"), e.get("xAxisId"), 0) + '" not found');
      if (!s)
        throw new Error('yAxis "' + c(e.get("xAxisIndex"), e.get("yAxisId"), 0) + '" not found');
    }
    o.coordSysDims = ["x", "y"], i.set("x", r), i.set("y", s), d(r) && (n.set("x", r), o.firstCategoryDimIndex = 0), d(s) && (n.set("y", s), o.firstCategoryDimIndex == null && (o.firstCategoryDimIndex = 1));
  }, "cartesian2d"),
  singleAxis: /* @__PURE__ */ t(function(e, o, i, n) {
    var r = e.getReferringComponents("singleAxis", f).models[0];
    if (process.env.NODE_ENV !== "production" && !r)
      throw new Error("singleAxis should be specified.");
    o.coordSysDims = ["single"], i.set("single", r), d(r) && (n.set("single", r), o.firstCategoryDimIndex = 0);
  }, "singleAxis"),
  polar: /* @__PURE__ */ t(function(e, o, i, n) {
    var r = e.getReferringComponents("polar", f).models[0], s = r.findAxisModel("radiusAxis"), a = r.findAxisModel("angleAxis");
    if (process.env.NODE_ENV !== "production") {
      if (!a)
        throw new Error("angleAxis option not found");
      if (!s)
        throw new Error("radiusAxis option not found");
    }
    o.coordSysDims = ["radius", "angle"], i.set("radius", s), i.set("angle", a), d(s) && (n.set("radius", s), o.firstCategoryDimIndex = 0), d(a) && (n.set("angle", a), o.firstCategoryDimIndex == null && (o.firstCategoryDimIndex = 1));
  }, "polar"),
  geo: /* @__PURE__ */ t(function(e, o, i, n) {
    o.coordSysDims = ["lng", "lat"];
  }, "geo"),
  parallel: /* @__PURE__ */ t(function(e, o, i, n) {
    var r = e.ecModel, s = r.getComponent("parallel", e.get("parallelIndex")), a = o.coordSysDims = s.dimensions.slice();
    A(s.parallelAxisIndex, function(y, l) {
      var x = r.getComponent("parallelAxis", y), g = a[l];
      i.set(g, x), d(x) && (n.set(g, x), o.firstCategoryDimIndex == null && (o.firstCategoryDimIndex = l));
    });
  }, "parallel")
};
function d(e) {
  return e.get("type") === "category";
}
t(d, "isCategory");
export {
  S as getCoordSysInfoBySeries
};
