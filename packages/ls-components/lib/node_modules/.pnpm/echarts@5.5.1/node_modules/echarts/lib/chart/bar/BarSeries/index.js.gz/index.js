var a = Object.defineProperty;
var s = (t, e) => a(t, "name", { value: e, configurable: !0 });
import { __extends as n } from "../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import i from "../BaseBarSeries/index.js";
import d from "../../helper/createSeriesData/index.js";
import { inheritDefaultOption as u } from "../../../util/component/index.js";
var m = (
  /** @class */
  function(t) {
    n(e, t);
    function e() {
      var r = t !== null && t.apply(this, arguments) || this;
      return r.type = e.type, r;
    }
    return s(e, "BarSeriesModel"), e.prototype.getInitialData = function() {
      return d(null, this, {
        useEncodeDefaulter: !0,
        createInvertedIndices: !!this.get("realtimeSort", !0) || null
      });
    }, e.prototype.getProgressive = function() {
      return this.get("large") ? this.get("progressive") : !1;
    }, e.prototype.getProgressiveThreshold = function() {
      var r = this.get("progressiveThreshold"), o = this.get("largeThreshold");
      return o > r && (r = o), r;
    }, e.prototype.brushSelector = function(r, o, l) {
      return l.rect(o.getItemLayout(r));
    }, e.type = "series.bar", e.dependencies = ["grid", "polar"], e.defaultOption = u(i.defaultOption, {
      // If clipped
      // Only available on cartesian2d
      clip: !0,
      roundCap: !1,
      showBackground: !1,
      backgroundStyle: {
        color: "rgba(180, 180, 180, 0.2)",
        borderColor: null,
        borderWidth: 0,
        borderType: "solid",
        borderRadius: 0,
        shadowBlur: 0,
        shadowColor: null,
        shadowOffsetX: 0,
        shadowOffsetY: 0,
        opacity: 1
      },
      select: {
        itemStyle: {
          borderColor: "#212121"
        }
      },
      realtimeSort: !1
    }), e;
  }(i)
);
export {
  m as default
};
