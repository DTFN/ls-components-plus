var k = Object.defineProperty;
var d = (i, n) => k(i, "name", { value: n, configurable: !0 });
import { __extends as z } from "../../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { registerAction as F } from "../../../../core/echarts/index.js";
import { isFunction as A, isString as j, isDom as G, each as O, extend as P, defaults as R, filter as V, map as L, isObject as M, isArray as B } from "../../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { ToolboxFeature as U } from "../../featureManager/index.js";
import { addEventListener as H } from "../../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/event/index.js";
import { warn as W } from "../../../../util/log/index.js";
var D = new Array(60).join("-"), m = "	";
function $(i) {
  var n = {}, e = [], t = [];
  return i.eachRawSeries(function(r) {
    var o = r.coordinateSystem;
    if (o && (o.type === "cartesian2d" || o.type === "polar")) {
      var a = o.getBaseAxis();
      if (a.type === "category") {
        var s = a.dim + "_" + a.index;
        n[s] || (n[s] = {
          categoryAxis: a,
          valueAxis: o.getOtherAxis(a),
          series: []
        }, t.push({
          axisDim: a.dim,
          axisIndex: a.index
        })), n[s].series.push(r);
      } else
        e.push(r);
    } else
      e.push(r);
  }), {
    seriesGroupByCategoryAxis: n,
    other: e,
    meta: t
  };
}
d($, "groupSeries");
function q(i) {
  var n = [];
  return O(i, function(e, t) {
    var r = e.categoryAxis, o = e.valueAxis, a = o.dim, s = [" "].concat(L(e.series, function(f) {
      return f.name;
    })), l = [r.model.getCategories()];
    O(e.series, function(f) {
      var g = f.getRawData();
      l.push(f.getRawData().mapArray(g.mapDimension(a), function(h) {
        return h;
      }));
    });
    for (var u = [s.join(m)], c = 0; c < l[0].length; c++) {
      for (var v = [], p = 0; p < l.length; p++)
        v.push(l[p][c]);
      u.push(v.join(m));
    }
    n.push(u.join(`
`));
  }), n.join(`

` + D + `

`);
}
d(q, "assembleSeriesWithCategoryAxis");
function J(i) {
  return L(i, function(n) {
    var e = n.getRawData(), t = [n.name], r = [];
    return e.each(e.dimensions, function() {
      for (var o = arguments.length, a = arguments[o - 1], s = e.getName(a), l = 0; l < o - 1; l++)
        r[l] = arguments[l];
      t.push((s ? s + m : "") + r.join(m));
    }), t.join(`
`);
  }).join(`

` + D + `

`);
}
d(J, "assembleOtherSeries");
function Q(i) {
  var n = $(i);
  return {
    value: V([q(n.seriesGroupByCategoryAxis), J(n.other)], function(e) {
      return !!e.replace(/[\n\t\s]/g, "");
    }).join(`

` + D + `

`),
    meta: n.meta
  };
}
d(Q, "getContentFromModel");
function w(i) {
  return i.replace(/^\s\s*/, "").replace(/\s\s*$/, "");
}
d(w, "trim");
function X(i) {
  var n = i.slice(0, i.indexOf(`
`));
  if (n.indexOf(m) >= 0)
    return !0;
}
d(X, "isTSVFormat");
var S = new RegExp("[" + m + "]+", "g");
function Y(i) {
  for (var n = i.split(/\n+/g), e = w(n.shift()).split(S), t = [], r = L(e, function(l) {
    return {
      name: l,
      data: []
    };
  }), o = 0; o < n.length; o++) {
    var a = w(n[o]).split(S);
    t.push(a.shift());
    for (var s = 0; s < a.length; s++)
      r[s] && (r[s].data[o] = a[s]);
  }
  return {
    series: r,
    categories: t
  };
}
d(Y, "parseTSVContents");
function Z(i) {
  for (var n = i.split(/\n+/g), e = w(n.shift()), t = [], r = 0; r < n.length; r++) {
    var o = w(n[r]);
    if (o) {
      var a = o.split(S), s = "", l = void 0, u = !1;
      isNaN(a[0]) ? (u = !0, s = a[0], a = a.slice(1), t[r] = {
        name: s,
        value: []
      }, l = t[r].value) : l = t[r] = [];
      for (var c = 0; c < a.length; c++)
        l.push(+a[c]);
      l.length === 1 && (u ? t[r].value = l[0] : t[r] = l[0]);
    }
  }
  return {
    name: e,
    data: t
  };
}
d(Z, "parseListContents");
function K(i, n) {
  var e = i.split(new RegExp(`
*` + D + `
*`, "g")), t = {
    series: []
  };
  return O(e, function(r, o) {
    if (X(r)) {
      var a = Y(r), s = n[o], l = s.axisDim + "Axis";
      s && (t[l] = t[l] || [], t[l][s.axisIndex] = {
        data: a.categories
      }, t.series = t.series.concat(a.series));
    } else {
      var a = Z(r);
      t.series.push(a);
    }
  }), t;
}
d(K, "parseContents");
var le = (
  /** @class */
  function(i) {
    z(n, i);
    function n() {
      return i !== null && i.apply(this, arguments) || this;
    }
    return d(n, "DataView"), n.prototype.onclick = function(e, t) {
      setTimeout(function() {
        t.dispatchAction({
          type: "hideTip"
        });
      });
      var r = t.getDom(), o = this.model;
      this._dom && r.removeChild(this._dom);
      var a = document.createElement("div");
      a.style.cssText = "position:absolute;top:0;bottom:0;left:0;right:0;padding:5px", a.style.backgroundColor = o.get("backgroundColor") || "#fff";
      var s = document.createElement("h4"), l = o.get("lang") || [];
      s.innerHTML = l[0] || o.get("title"), s.style.cssText = "margin:10px 20px", s.style.color = o.get("textColor");
      var u = document.createElement("div"), c = document.createElement("textarea");
      u.style.cssText = "overflow:auto";
      var v = o.get("optionToContent"), p = o.get("contentToOption"), f = Q(e);
      if (A(v)) {
        var g = v(t.getOption());
        j(g) ? u.innerHTML = g : G(g) && u.appendChild(g);
      } else {
        c.readOnly = o.get("readOnly");
        var h = c.style;
        h.cssText = "display:block;width:100%;height:100%;font-family:monospace;font-size:14px;line-height:1.6rem;resize:none;box-sizing:border-box;outline:none", h.color = o.get("textColor"), h.borderColor = o.get("textareaBorderColor"), h.backgroundColor = o.get("textareaColor"), c.value = f.value, u.appendChild(c);
      }
      var _ = f.meta, x = document.createElement("div");
      x.style.cssText = "position:absolute;bottom:5px;left:0;right:0";
      var E = "float:right;margin-right:20px;border:none;cursor:pointer;padding:2px 5px;font-size:12px;border-radius:3px", C = document.createElement("div"), y = document.createElement("div");
      E += ";background-color:" + o.get("buttonColor"), E += ";color:" + o.get("buttonTextColor");
      var I = this;
      function T() {
        r.removeChild(a), I._dom = null;
      }
      d(T, "close"), H(C, "click", T), H(y, "click", function() {
        if (p == null && v != null || p != null && v == null) {
          process.env.NODE_ENV !== "production" && W("It seems you have just provided one of `contentToOption` and `optionToContent` functions but missed the other one. Data change is ignored."), T();
          return;
        }
        var b;
        try {
          A(p) ? b = p(u, t.getOption()) : b = K(c.value, _);
        } catch (N) {
          throw T(), new Error("Data view format error " + N);
        }
        b && t.dispatchAction({
          type: "changeDataView",
          newOption: b
        }), T();
      }), C.innerHTML = l[1], y.innerHTML = l[2], y.style.cssText = C.style.cssText = E, !o.get("readOnly") && x.appendChild(y), x.appendChild(C), a.appendChild(s), a.appendChild(u), a.appendChild(x), u.style.height = r.clientHeight - 80 + "px", r.appendChild(a), this._dom = a;
    }, n.prototype.remove = function(e, t) {
      this._dom && t.getDom().removeChild(this._dom);
    }, n.prototype.dispose = function(e, t) {
      this.remove(e, t);
    }, n.getDefaultOption = function(e) {
      var t = {
        show: !0,
        readOnly: !1,
        optionToContent: null,
        contentToOption: null,
        // eslint-disable-next-line
        icon: "M17.5,17.3H33 M17.5,17.3H33 M45.4,29.5h-28 M11.5,2v56H51V14.8L38.4,2H11.5z M38.4,2.2v12.7H51 M45.4,41.7h-28",
        title: e.getLocaleModel().get(["toolbox", "dataView", "title"]),
        lang: e.getLocaleModel().get(["toolbox", "dataView", "lang"]),
        backgroundColor: "#fff",
        textColor: "#000",
        textareaColor: "#fff",
        textareaBorderColor: "#333",
        buttonColor: "#c23531",
        buttonTextColor: "#fff"
      };
      return t;
    }, n;
  }(U)
);
function ee(i, n) {
  return L(i, function(e, t) {
    var r = n && n[t];
    if (M(r) && !B(r)) {
      var o = M(e) && !B(e);
      o || (e = {
        value: e
      });
      var a = r.name != null && e.name == null;
      return e = R(e, r), a && delete e.name, e;
    } else
      return e;
  });
}
d(ee, "tryMergeDataOption");
F({
  type: "changeDataView",
  event: "dataViewChanged",
  update: "prepareAndUpdate"
}, function(i, n) {
  var e = [];
  O(i.newOption.series, function(t) {
    var r = n.getSeriesByName(t.name)[0];
    if (!r)
      e.push(P({
        // Default is scatter
        type: "scatter"
      }, t));
    else {
      var o = r.get("data");
      e.push({
        name: t.name,
        data: ee(t.data, o)
      });
    }
  }), n.mergeOption(R({
    series: e
  }, i.newOption));
});
export {
  le as default
};
