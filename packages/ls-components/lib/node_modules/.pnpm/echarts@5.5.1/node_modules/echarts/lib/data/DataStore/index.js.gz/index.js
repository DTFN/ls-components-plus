var T = Object.defineProperty;
var m = (u, t) => T(u, "name", { value: t, configurable: !0 });
import { assert as G, isFunction as P, map as U, keys as L, reduce as q, clone as z, createHashMap as H } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { parseDataValue as V } from "../helper/dataValueHelper/index.js";
import { shouldRetrieveDataByName as J } from "../Source/index.js";
var x = "undefined", K = typeof Uint32Array === x ? Array : Uint32Array, Q = typeof Uint16Array === x ? Array : Uint16Array, W = typeof Int32Array === x ? Array : Int32Array, F = typeof Float64Array === x ? Array : Float64Array, B = {
  float: F,
  int: W,
  // Ordinal data type can be string or int
  ordinal: Array,
  number: Array,
  time: F
}, O;
function E(u) {
  return u > 65535 ? K : Q;
}
m(E, "getIndicesCtor");
function M() {
  return [1 / 0, -1 / 0];
}
m(M, "getInitialExtent");
function Z(u) {
  var t = u.constructor;
  return t === Array ? u.slice() : new t(u);
}
m(Z, "cloneChunk");
function b(u, t, r, e, a) {
  var n = B[r || "float"];
  if (a) {
    var i = u[t], s = i && i.length;
    if (s !== e) {
      for (var o = new n(e), v = 0; v < s; v++)
        o[v] = i[v];
      u[t] = o;
    }
  } else
    u[t] = new n(e);
}
m(b, "prepareStore");
var tt = (
  /** @class */
  function() {
    function u() {
      this._chunks = [], this._rawExtent = [], this._extent = [], this._count = 0, this._rawCount = 0, this._calcDimNameToIdx = H();
    }
    return m(u, "DataStore"), u.prototype.initData = function(t, r, e) {
      process.env.NODE_ENV !== "production" && G(P(t.getItem) && P(t.count), "Invalid data provider."), this._provider = t, this._chunks = [], this._indices = null, this.getRawIndex = this._getRawIdxIdentity;
      var a = t.getSource(), n = this.defaultDimValueGetter = O[a.sourceFormat];
      this._dimValueGetter = e || n, this._rawExtent = [];
      var i = J(a);
      this._dimensions = U(r, function(s) {
        return process.env.NODE_ENV !== "production" && i && G(s.property != null), {
          // Only pick these two props. Not leak other properties like orderMeta.
          type: s.type,
          property: s.property
        };
      }), this._initDataFromProvider(0, t.count());
    }, u.prototype.getProvider = function() {
      return this._provider;
    }, u.prototype.getSource = function() {
      return this._provider.getSource();
    }, u.prototype.ensureCalculationDimension = function(t, r) {
      var e = this._calcDimNameToIdx, a = this._dimensions, n = e.get(t);
      if (n != null) {
        if (a[n].type === r)
          return n;
      } else
        n = a.length;
      return a[n] = {
        type: r
      }, e.set(t, n), this._chunks[n] = new B[r || "float"](this._rawCount), this._rawExtent[n] = M(), n;
    }, u.prototype.collectOrdinalMeta = function(t, r) {
      var e = this._chunks[t], a = this._dimensions[t], n = this._rawExtent, i = a.ordinalOffset || 0, s = e.length;
      i === 0 && (n[t] = M());
      for (var o = n[t], v = i; v < s; v++) {
        var c = e[v] = r.parseAndCollect(e[v]);
        isNaN(c) || (o[0] = Math.min(c, o[0]), o[1] = Math.max(c, o[1]));
      }
      a.ordinalMeta = r, a.ordinalOffset = s, a.type = "ordinal";
    }, u.prototype.getOrdinalMeta = function(t) {
      var r = this._dimensions[t], e = r.ordinalMeta;
      return e;
    }, u.prototype.getDimensionProperty = function(t) {
      var r = this._dimensions[t];
      return r && r.property;
    }, u.prototype.appendData = function(t) {
      process.env.NODE_ENV !== "production" && G(!this._indices, "appendData can only be called on raw data.");
      var r = this._provider, e = this.count();
      r.appendData(t);
      var a = r.count();
      return r.persistent || (a += e), e < a && this._initDataFromProvider(e, a, !0), [e, a];
    }, u.prototype.appendValues = function(t, r) {
      for (var e = this._chunks, a = this._dimensions, n = a.length, i = this._rawExtent, s = this.count(), o = s + Math.max(t.length, r || 0), v = 0; v < n; v++) {
        var c = a[v];
        b(e, v, c.type, o, !0);
      }
      for (var y = [], _ = s; _ < o; _++)
        for (var f = _ - s, h = 0; h < n; h++) {
          var c = a[h], w = O.arrayRows.call(this, t[f] || y, c.property, f, h);
          e[h][_] = w;
          var l = i[h];
          w < l[0] && (l[0] = w), w > l[1] && (l[1] = w);
        }
      return this._rawCount = this._count = o, {
        start: s,
        end: o
      };
    }, u.prototype._initDataFromProvider = function(t, r, e) {
      for (var a = this._provider, n = this._chunks, i = this._dimensions, s = i.length, o = this._rawExtent, v = U(i, function(g) {
        return g.property;
      }), c = 0; c < s; c++) {
        var y = i[c];
        o[c] || (o[c] = M()), b(n, c, y.type, r, e);
      }
      if (a.fillStorage)
        a.fillStorage(t, r, n, o);
      else
        for (var _ = [], f = t; f < r; f++) {
          _ = a.getItem(f, _);
          for (var h = 0; h < s; h++) {
            var w = n[h], l = this._dimValueGetter(_, v[h], f, h);
            w[f] = l;
            var p = o[h];
            l < p[0] && (p[0] = l), l > p[1] && (p[1] = l);
          }
        }
      !a.persistent && a.clean && a.clean(), this._rawCount = this._count = r, this._extent = [];
    }, u.prototype.count = function() {
      return this._count;
    }, u.prototype.get = function(t, r) {
      if (!(r >= 0 && r < this._count))
        return NaN;
      var e = this._chunks[t];
      return e ? e[this.getRawIndex(r)] : NaN;
    }, u.prototype.getValues = function(t, r) {
      var e = [], a = [];
      if (r == null) {
        r = t, t = [];
        for (var n = 0; n < this._dimensions.length; n++)
          a.push(n);
      } else
        a = t;
      for (var n = 0, i = a.length; n < i; n++)
        e.push(this.get(a[n], r));
      return e;
    }, u.prototype.getByRawIndex = function(t, r) {
      if (!(r >= 0 && r < this._rawCount))
        return NaN;
      var e = this._chunks[t];
      return e ? e[r] : NaN;
    }, u.prototype.getSum = function(t) {
      var r = this._chunks[t], e = 0;
      if (r)
        for (var a = 0, n = this.count(); a < n; a++) {
          var i = this.get(t, a);
          isNaN(i) || (e += i);
        }
      return e;
    }, u.prototype.getMedian = function(t) {
      var r = [];
      this.each([t], function(n) {
        isNaN(n) || r.push(n);
      });
      var e = r.sort(function(n, i) {
        return n - i;
      }), a = this.count();
      return a === 0 ? 0 : a % 2 === 1 ? e[(a - 1) / 2] : (e[a / 2] + e[a / 2 - 1]) / 2;
    }, u.prototype.indexOfRawIndex = function(t) {
      if (t >= this._rawCount || t < 0)
        return -1;
      if (!this._indices)
        return t;
      var r = this._indices, e = r[t];
      if (e != null && e < this._count && e === t)
        return t;
      for (var a = 0, n = this._count - 1; a <= n; ) {
        var i = (a + n) / 2 | 0;
        if (r[i] < t)
          a = i + 1;
        else if (r[i] > t)
          n = i - 1;
        else
          return i;
      }
      return -1;
    }, u.prototype.indicesOfNearest = function(t, r, e) {
      var a = this._chunks, n = a[t], i = [];
      if (!n)
        return i;
      e == null && (e = 1 / 0);
      for (var s = 1 / 0, o = -1, v = 0, c = 0, y = this.count(); c < y; c++) {
        var _ = this.getRawIndex(c), f = r - n[_], h = Math.abs(f);
        h <= e && ((h < s || h === s && f >= 0 && o < 0) && (s = h, o = f, v = 0), f === o && (i[v++] = c));
      }
      return i.length = v, i;
    }, u.prototype.getIndices = function() {
      var t, r = this._indices;
      if (r) {
        var e = r.constructor, a = this._count;
        if (e === Array) {
          t = new e(a);
          for (var n = 0; n < a; n++)
            t[n] = r[n];
        } else
          t = new e(r.buffer, 0, a);
      } else {
        var e = E(this._rawCount);
        t = new e(this.count());
        for (var n = 0; n < t.length; n++)
          t[n] = n;
      }
      return t;
    }, u.prototype.filter = function(t, r) {
      if (!this._count)
        return this;
      for (var e = this.clone(), a = e.count(), n = E(e._rawCount), i = new n(a), s = [], o = t.length, v = 0, c = t[0], y = e._chunks, _ = 0; _ < a; _++) {
        var f = void 0, h = e.getRawIndex(_);
        if (o === 0)
          f = r(_);
        else if (o === 1) {
          var w = y[c][h];
          f = r(w, _);
        } else {
          for (var l = 0; l < o; l++)
            s[l] = y[t[l]][h];
          s[l] = _, f = r.apply(null, s);
        }
        f && (i[v++] = h);
      }
      return v < a && (e._indices = i), e._count = v, e._extent = [], e._updateGetRawIdx(), e;
    }, u.prototype.selectRange = function(t) {
      var r = this.clone(), e = r._count;
      if (!e)
        return this;
      var a = L(t), n = a.length;
      if (!n)
        return this;
      var i = r.count(), s = E(r._rawCount), o = new s(i), v = 0, c = a[0], y = t[c][0], _ = t[c][1], f = r._chunks, h = !1;
      if (!r._indices) {
        var w = 0;
        if (n === 1) {
          for (var l = f[a[0]], p = 0; p < e; p++) {
            var g = l[p];
            (g >= y && g <= _ || isNaN(g)) && (o[v++] = w), w++;
          }
          h = !0;
        } else if (n === 2) {
          for (var l = f[a[0]], d = f[a[1]], R = t[a[1]][0], I = t[a[1]][1], p = 0; p < e; p++) {
            var g = l[p], N = d[p];
            (g >= y && g <= _ || isNaN(g)) && (N >= R && N <= I || isNaN(N)) && (o[v++] = w), w++;
          }
          h = !0;
        }
      }
      if (!h)
        if (n === 1)
          for (var p = 0; p < i; p++) {
            var A = r.getRawIndex(p), g = f[a[0]][A];
            (g >= y && g <= _ || isNaN(g)) && (o[v++] = A);
          }
        else
          for (var p = 0; p < i; p++) {
            for (var S = !0, A = r.getRawIndex(p), C = 0; C < n; C++) {
              var D = a[C], g = f[D][A];
              (g < t[D][0] || g > t[D][1]) && (S = !1);
            }
            S && (o[v++] = r.getRawIndex(p));
          }
      return v < i && (r._indices = o), r._count = v, r._extent = [], r._updateGetRawIdx(), r;
    }, u.prototype.map = function(t, r) {
      var e = this.clone(t);
      return this._updateDims(e, t, r), e;
    }, u.prototype.modify = function(t, r) {
      this._updateDims(this, t, r);
    }, u.prototype._updateDims = function(t, r, e) {
      for (var a = t._chunks, n = [], i = r.length, s = t.count(), o = [], v = t._rawExtent, c = 0; c < r.length; c++)
        v[r[c]] = M();
      for (var y = 0; y < s; y++) {
        for (var _ = t.getRawIndex(y), f = 0; f < i; f++)
          o[f] = a[r[f]][_];
        o[i] = y;
        var h = e && e.apply(null, o);
        if (h != null) {
          typeof h != "object" && (n[0] = h, h = n);
          for (var c = 0; c < h.length; c++) {
            var w = r[c], l = h[c], p = v[w], g = a[w];
            g && (g[_] = l), l < p[0] && (p[0] = l), l > p[1] && (p[1] = l);
          }
        }
      }
    }, u.prototype.lttbDownSample = function(t, r) {
      var e = this.clone([t], !0), a = e._chunks, n = a[t], i = this.count(), s = 0, o = Math.floor(1 / r), v = this.getRawIndex(0), c, y, _, f = new (E(this._rawCount))(Math.min((Math.ceil(i / o) + 2) * 2, i));
      f[s++] = v;
      for (var h = 1; h < i - 1; h += o) {
        for (var w = Math.min(h + o, i - 1), l = Math.min(h + o * 2, i), p = (l + w) / 2, g = 0, d = w; d < l; d++) {
          var R = this.getRawIndex(d), I = n[R];
          isNaN(I) || (g += I);
        }
        g /= l - w;
        var N = h, A = Math.min(h + o, i), S = h - 1, C = n[v];
        c = -1, _ = N;
        for (var D = -1, k = 0, d = N; d < A; d++) {
          var R = this.getRawIndex(d), I = n[R];
          if (isNaN(I)) {
            k++, D < 0 && (D = R);
            continue;
          }
          y = Math.abs((S - p) * (I - C) - (S - d) * (g - C)), y > c && (c = y, _ = R);
        }
        k > 0 && k < A - N && (f[s++] = Math.min(D, _), _ = Math.max(D, _)), f[s++] = _, v = _;
      }
      return f[s++] = this.getRawIndex(i - 1), e._count = s, e._indices = f, e.getRawIndex = this._getRawIdx, e;
    }, u.prototype.downSample = function(t, r, e, a) {
      for (var n = this.clone([t], !0), i = n._chunks, s = [], o = Math.floor(1 / r), v = i[t], c = this.count(), y = n._rawExtent[t] = M(), _ = new (E(this._rawCount))(Math.ceil(c / o)), f = 0, h = 0; h < c; h += o) {
        o > c - h && (o = c - h, s.length = o);
        for (var w = 0; w < o; w++) {
          var l = this.getRawIndex(h + w);
          s[w] = v[l];
        }
        var p = e(s), g = this.getRawIndex(Math.min(h + a(s, p) || 0, c - 1));
        v[g] = p, p < y[0] && (y[0] = p), p > y[1] && (y[1] = p), _[f++] = g;
      }
      return n._count = f, n._indices = _, n._updateGetRawIdx(), n;
    }, u.prototype.each = function(t, r) {
      if (this._count)
        for (var e = t.length, a = this._chunks, n = 0, i = this.count(); n < i; n++) {
          var s = this.getRawIndex(n);
          switch (e) {
            case 0:
              r(n);
              break;
            case 1:
              r(a[t[0]][s], n);
              break;
            case 2:
              r(a[t[0]][s], a[t[1]][s], n);
              break;
            default:
              for (var o = 0, v = []; o < e; o++)
                v[o] = a[t[o]][s];
              v[o] = n, r.apply(null, v);
          }
        }
    }, u.prototype.getDataExtent = function(t) {
      var r = this._chunks[t], e = M();
      if (!r)
        return e;
      var a = this.count(), n = !this._indices, i;
      if (n)
        return this._rawExtent[t].slice();
      if (i = this._extent[t], i)
        return i.slice();
      i = e;
      for (var s = i[0], o = i[1], v = 0; v < a; v++) {
        var c = this.getRawIndex(v), y = r[c];
        y < s && (s = y), y > o && (o = y);
      }
      return i = [s, o], this._extent[t] = i, i;
    }, u.prototype.getRawDataItem = function(t) {
      var r = this.getRawIndex(t);
      if (this._provider.persistent)
        return this._provider.getItem(r);
      for (var e = [], a = this._chunks, n = 0; n < a.length; n++)
        e.push(a[n][r]);
      return e;
    }, u.prototype.clone = function(t, r) {
      var e = new u(), a = this._chunks, n = t && q(t, function(s, o) {
        return s[o] = !0, s;
      }, {});
      if (n)
        for (var i = 0; i < a.length; i++)
          e._chunks[i] = n[i] ? Z(a[i]) : a[i];
      else
        e._chunks = a;
      return this._copyCommonProps(e), r || (e._indices = this._cloneIndices()), e._updateGetRawIdx(), e;
    }, u.prototype._copyCommonProps = function(t) {
      t._count = this._count, t._rawCount = this._rawCount, t._provider = this._provider, t._dimensions = this._dimensions, t._extent = z(this._extent), t._rawExtent = z(this._rawExtent);
    }, u.prototype._cloneIndices = function() {
      if (this._indices) {
        var t = this._indices.constructor, r = void 0;
        if (t === Array) {
          var e = this._indices.length;
          r = new t(e);
          for (var a = 0; a < e; a++)
            r[a] = this._indices[a];
        } else
          r = new t(this._indices);
        return r;
      }
      return null;
    }, u.prototype._getRawIdxIdentity = function(t) {
      return t;
    }, u.prototype._getRawIdx = function(t) {
      return t < this._count && t >= 0 ? this._indices[t] : -1;
    }, u.prototype._updateGetRawIdx = function() {
      this.getRawIndex = this._indices ? this._getRawIdx : this._getRawIdxIdentity;
    }, u.internalField = function() {
      function t(r, e, a, n) {
        return V(r[n], this._dimensions[n]);
      }
      m(t, "getDimValueSimply"), O = {
        arrayRows: t,
        objectRows: /* @__PURE__ */ m(function(r, e, a, n) {
          return V(r[e], this._dimensions[n]);
        }, "objectRows"),
        keyedColumns: t,
        original: /* @__PURE__ */ m(function(r, e, a, n) {
          var i = r && (r.value == null ? r : r.value);
          return V(i instanceof Array ? i[n] : i, this._dimensions[n]);
        }, "original"),
        typedArray: /* @__PURE__ */ m(function(r, e, a, n) {
          return r[n];
        }, "typedArray")
      };
    }(), u;
  }()
);
export {
  F as CtorFloat64Array,
  W as CtorInt32Array,
  Q as CtorUint16Array,
  K as CtorUint32Array,
  tt as default
};
