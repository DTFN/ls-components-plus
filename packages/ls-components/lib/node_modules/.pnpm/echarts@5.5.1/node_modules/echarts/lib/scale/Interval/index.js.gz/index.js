var y = Object.defineProperty;
var h = (o, n) => y(o, "name", { value: n, configurable: !0 });
import { __extends as m } from "../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { getPrecision as g, round as E } from "../../util/number/index.js";
import { addCommas as k } from "../../util/format/index.js";
import p from "../Scale/index.js";
import { contain as N, normalize as P, scale as I, getIntervalPrecision as M, intervalScaleNiceTicks as T } from "../helper/index.js";
var v = E, F = (
  /** @class */
  function(o) {
    m(n, o);
    function n() {
      var t = o !== null && o.apply(this, arguments) || this;
      return t.type = "interval", t._interval = 0, t._intervalPrecision = 2, t;
    }
    return h(n, "IntervalScale"), n.prototype.parse = function(t) {
      return t;
    }, n.prototype.contain = function(t) {
      return N(t, this._extent);
    }, n.prototype.normalize = function(t) {
      return P(t, this._extent);
    }, n.prototype.scale = function(t) {
      return I(t, this._extent);
    }, n.prototype.setExtent = function(t, e) {
      var i = this._extent;
      isNaN(t) || (i[0] = parseFloat(t)), isNaN(e) || (i[1] = parseFloat(e));
    }, n.prototype.unionExtent = function(t) {
      var e = this._extent;
      t[0] < e[0] && (e[0] = t[0]), t[1] > e[1] && (e[1] = t[1]), this.setExtent(e[0], e[1]);
    }, n.prototype.getInterval = function() {
      return this._interval;
    }, n.prototype.setInterval = function(t) {
      this._interval = t, this._niceExtent = this._extent.slice(), this._intervalPrecision = M(t);
    }, n.prototype.getTicks = function(t) {
      var e = this._interval, i = this._extent, s = this._niceExtent, a = this._intervalPrecision, r = [];
      if (!e)
        return r;
      var u = 1e4;
      i[0] < s[0] && (t ? r.push({
        value: v(s[0] - e, a)
      }) : r.push({
        value: i[0]
      }));
      for (var l = s[0]; l <= s[1] && (r.push({
        value: l
      }), l = v(l + e, a), l !== r[r.length - 1].value); )
        if (r.length > u)
          return [];
      var c = r.length ? r[r.length - 1].value : s[1];
      return i[1] > c && (t ? r.push({
        value: v(c + e, a)
      }) : r.push({
        value: i[1]
      })), r;
    }, n.prototype.getMinorTicks = function(t) {
      for (var e = this.getTicks(!0), i = [], s = this.getExtent(), a = 1; a < e.length; a++) {
        for (var r = e[a], u = e[a - 1], l = 0, c = [], x = r.value - u.value, _ = x / t; l < t - 1; ) {
          var f = v(u.value + (l + 1) * _);
          f > s[0] && f < s[1] && c.push(f), l++;
        }
        i.push(c);
      }
      return i;
    }, n.prototype.getLabel = function(t, e) {
      if (t == null)
        return "";
      var i = e && e.precision;
      i == null ? i = g(t.value) || 0 : i === "auto" && (i = this._intervalPrecision);
      var s = v(t.value, i, !0);
      return k(s);
    }, n.prototype.calcNiceTicks = function(t, e, i) {
      t = t || 5;
      var s = this._extent, a = s[1] - s[0];
      if (isFinite(a)) {
        a < 0 && (a = -a, s.reverse());
        var r = T(s, t, e, i);
        this._intervalPrecision = r.intervalPrecision, this._interval = r.interval, this._niceExtent = r.niceTickExtent;
      }
    }, n.prototype.calcNiceExtent = function(t) {
      var e = this._extent;
      if (e[0] === e[1])
        if (e[0] !== 0) {
          var i = Math.abs(e[0]);
          t.fixMax || (e[1] += i / 2), e[0] -= i / 2;
        } else
          e[1] = 1;
      var s = e[1] - e[0];
      isFinite(s) || (e[0] = 0, e[1] = 1), this.calcNiceTicks(t.splitNumber, t.minInterval, t.maxInterval);
      var a = this._interval;
      t.fixMin || (e[0] = v(Math.floor(e[0] / a) * a)), t.fixMax || (e[1] = v(Math.ceil(e[1] / a) * a));
    }, n.prototype.setNiceExtent = function(t, e) {
      this._niceExtent = [t, e];
    }, n.type = "interval", n;
  }(p)
);
p.registerClass(F);
export {
  F as default
};
