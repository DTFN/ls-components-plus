var O = Object.defineProperty;
var v = (t, e) => O(t, "name", { value: e, configurable: !0 });
import { map as p, isFunction as E, each as P } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { getBoundingRect as W } from "../../../../../../zrender@5.6.0/node_modules/zrender/lib/contain/text/index.js";
import { makeInner as j } from "../../util/model/index.js";
import { makeLabelFormatter as C, getOptionCategoryInterval as V, shouldShowAllLabels as G } from "../axisHelper/index.js";
var d = j();
function F(t, e) {
  var a = p(e, function(r) {
    return t.scale.parse(r);
  });
  return t.type === "time" && a.length > 0 && (a.sort(), a.unshift(a[0]), a.push(a[a.length - 1])), a;
}
v(F, "tickValuesToNumbers");
function $(t) {
  var e = t.getLabelModel().get("customValues");
  if (e) {
    var a = C(t);
    return {
      labels: F(t, e).map(function(r) {
        var o = {
          value: r
        };
        return {
          formattedLabel: a(o),
          rawLabel: t.scale.getLabel(o),
          tickValue: r
        };
      })
    };
  }
  return t.type === "category" ? q(t) : J(t);
}
v($, "createAxisLabels");
function x(t, e) {
  var a = t.getTickModel().get("customValues");
  return a ? {
    ticks: F(t, a)
  } : t.type === "category" ? D(t, e) : {
    ticks: p(t.scale.getTicks(), function(r) {
      return r.value;
    })
  };
}
v(x, "createAxisTicks");
function q(t) {
  var e = t.getLabelModel(), a = N(t, e);
  return !e.get("show") || t.scale.isBlank() ? {
    labels: [],
    labelCategoryInterval: a.labelCategoryInterval
  } : a;
}
v(q, "makeCategoryLabels");
function N(t, e) {
  var a = R(t, "labels"), r = V(e), o = S(a, r);
  if (o)
    return o;
  var l, n;
  return E(r) ? l = z(t, r) : (n = r === "auto" ? K(t) : r, l = H(t, n)), B(a, r, {
    labels: l,
    labelCategoryInterval: n
  });
}
v(N, "makeCategoryLabelsActually");
function D(t, e) {
  var a = R(t, "ticks"), r = V(e), o = S(a, r);
  if (o)
    return o;
  var l, n;
  if ((!e.get("show") || t.scale.isBlank()) && (l = []), E(r))
    l = z(t, r, !0);
  else if (r === "auto") {
    var c = N(t, t.getLabelModel());
    n = c.labelCategoryInterval, l = p(c.labels, function(u) {
      return u.tickValue;
    });
  } else
    n = r, l = H(t, n, !0);
  return B(a, r, {
    ticks: l,
    tickCategoryInterval: n
  });
}
v(D, "makeCategoryTicks");
function J(t) {
  var e = t.scale.getTicks(), a = C(t);
  return {
    labels: p(e, function(r, o) {
      return {
        level: r.level,
        formattedLabel: a(r, o),
        rawLabel: t.scale.getLabel(r),
        tickValue: r.value
      };
    })
  };
}
v(J, "makeRealNumberLabels");
function R(t, e) {
  return d(t)[e] || (d(t)[e] = []);
}
v(R, "getListCache");
function S(t, e) {
  for (var a = 0; a < t.length; a++)
    if (t[a].key === e)
      return t[a].value;
}
v(S, "listCacheGet");
function B(t, e, a) {
  return t.push({
    key: e,
    value: a
  }), a;
}
v(B, "listCacheSet");
function K(t) {
  var e = d(t).autoInterval;
  return e ?? (d(t).autoInterval = t.calculateCategoryInterval());
}
v(K, "makeAutoCategoryInterval");
function tt(t) {
  var e = Q(t), a = C(t), r = (e.axisRotate - e.labelRotate) / 180 * Math.PI, o = t.scale, l = o.getExtent(), n = o.count();
  if (l[1] - l[0] < 1)
    return 0;
  var c = 1;
  n > 40 && (c = Math.max(1, Math.floor(n / 40)));
  for (var u = l[0], i = t.dataToCoord(u + 1) - t.dataToCoord(u), T = Math.abs(i * Math.cos(r)), M = Math.abs(i * Math.sin(r)), h = 0, k = 0; u <= l[1]; u += c) {
    var b = 0, f = 0, g = W(a({
      value: u
    }), e.font, "center", "top");
    b = g.width * 1.3, f = g.height * 1.3, h = Math.max(h, b, 7), k = Math.max(k, f, 7);
  }
  var m = h / T, w = k / M;
  isNaN(m) && (m = 1 / 0), isNaN(w) && (w = 1 / 0);
  var L = Math.max(0, Math.floor(Math.min(m, w))), s = d(t.model), y = t.getExtent(), I = s.lastAutoInterval, A = s.lastTickCount;
  return I != null && A != null && Math.abs(I - L) <= 1 && Math.abs(A - n) <= 1 && I > L && s.axisExtent0 === y[0] && s.axisExtent1 === y[1] ? L = I : (s.lastTickCount = n, s.lastAutoInterval = L, s.axisExtent0 = y[0], s.axisExtent1 = y[1]), L;
}
v(tt, "calculateCategoryInterval");
function Q(t) {
  var e = t.getLabelModel();
  return {
    axisRotate: t.getRotate ? t.getRotate() : t.isHorizontal && !t.isHorizontal() ? 90 : 0,
    labelRotate: e.get("rotate") || 0,
    font: e.getFont()
  };
}
v(Q, "fetchAutoCategoryIntervalCalculationParams");
function H(t, e, a) {
  var r = C(t), o = t.scale, l = o.getExtent(), n = t.getLabelModel(), c = [], u = Math.max((e || 0) + 1, 1), i = l[0], T = o.count();
  i !== 0 && u > 1 && T / u > 2 && (i = Math.round(Math.ceil(i / u) * u));
  var M = G(t), h = n.get("showMinLabel") || M, k = n.get("showMaxLabel") || M;
  h && i !== l[0] && f(l[0]);
  for (var b = i; b <= l[1]; b += u)
    f(b);
  k && b - u !== l[1] && f(l[1]);
  function f(g) {
    var m = {
      value: g
    };
    c.push(a ? g : {
      formattedLabel: r(m),
      rawLabel: o.getLabel(m),
      tickValue: g
    });
  }
  return v(f, "addItem"), c;
}
v(H, "makeLabelsByNumericCategoryInterval");
function z(t, e, a) {
  var r = t.scale, o = C(t), l = [];
  return P(r.getTicks(), function(n) {
    var c = r.getLabel(n), u = n.value;
    e(n.value, c) && l.push(a ? u : {
      formattedLabel: o(n),
      rawLabel: c,
      tickValue: u
    });
  }), l;
}
v(z, "makeLabelsByCustomizedCategoryInterval");
export {
  tt as calculateCategoryInterval,
  $ as createAxisLabels,
  x as createAxisTicks
};
