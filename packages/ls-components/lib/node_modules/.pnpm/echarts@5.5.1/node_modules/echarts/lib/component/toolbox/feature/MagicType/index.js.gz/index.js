var w = Object.defineProperty;
var u = (a, n) => w(a, "name", { value: n, configurable: !0 });
import { __extends as z } from "../../../../../../../../tslib@2.3.0/node_modules/tslib/tslib.es6/index.js";
import { registerAction as N } from "../../../../core/echarts/index.js";
import { each as v, indexOf as R, merge as m, defaults as A } from "../../../../../../../../zrender@5.6.0/node_modules/zrender/lib/core/util/index.js";
import { ToolboxFeature as E } from "../../featureManager/index.js";
import { SINGLE_REFERRING as C } from "../../../../util/model/index.js";
var T = "__ec_magicType_stack__", G = [["line", "bar"], ["stack"]], q = (
  /** @class */
  function(a) {
    z(n, a);
    function n() {
      return a !== null && a.apply(this, arguments) || this;
    }
    return u(n, "MagicType"), n.prototype.getIcons = function() {
      var t = this.model, r = t.get("icon"), e = {};
      return v(t.get("type"), function(i) {
        r[i] && (e[i] = r[i]);
      }), e;
    }, n.getDefaultOption = function(t) {
      var r = {
        show: !0,
        type: [],
        // Icon group
        icon: {
          line: "M4.1,28.9h7.1l9.3-22l7.4,38l9.7-19.7l3,12.8h14.9M4.1,58h51.4",
          bar: "M6.7,22.9h10V48h-10V22.9zM24.9,13h10v35h-10V13zM43.2,2h10v46h-10V2zM3.1,58h53.7",
          // eslint-disable-next-line
          stack: "M8.2,38.4l-8.4,4.1l30.6,15.3L60,42.5l-8.1-4.1l-21.5,11L8.2,38.4z M51.9,30l-8.1,4.2l-13.4,6.9l-13.9-6.9L8.2,30l-8.4,4.2l8.4,4.2l22.2,11l21.5-11l8.1-4.2L51.9,30z M51.9,21.7l-8.1,4.2L35.7,30l-5.3,2.8L24.9,30l-8.4-4.1l-8.3-4.2l-8.4,4.2L8.2,30l8.3,4.2l13.9,6.9l13.4-6.9l8.1-4.2l8.1-4.1L51.9,21.7zM30.4,2.2L-0.2,17.5l8.4,4.1l8.3,4.2l8.4,4.2l5.5,2.7l5.3-2.7l8.1-4.2l8.1-4.2l8.1-4.1L30.4,2.2z"
          // jshint ignore:line
        },
        // `line`, `bar`, `stack`, `tiled`
        title: t.getLocaleModel().get(["toolbox", "magicType", "title"]),
        option: {},
        seriesIndex: {}
      };
      return r;
    }, n.prototype.onclick = function(t, r, e) {
      var i = this.model, h = i.get(["seriesIndex", e]);
      if (S[e]) {
        var l = {
          series: []
        }, y = /* @__PURE__ */ u(function(o) {
          var s = o.subType, I = o.id, g = S[e](s, I, o, i);
          g && (A(g, o.option), l.series.push(g));
          var f = o.coordinateSystem;
          if (f && f.type === "cartesian2d" && (e === "line" || e === "bar")) {
            var L = f.getAxesByScale("ordinal")[0];
            if (L) {
              var O = L.dim, c = O + "Axis", _ = o.getReferringComponents(c, C).models[0], p = _.componentIndex;
              l[c] = l[c] || [];
              for (var b = 0; b <= p; b++)
                l[c][p] = l[c][p] || {};
              l[c][p].boundaryGap = e === "bar";
            }
          }
        }, "generateNewSeriesTypes");
        v(G, function(o) {
          R(o, e) >= 0 && v(o, function(s) {
            i.setIconStatus(s, "normal");
          });
        }), i.setIconStatus(e, "emphasis"), t.eachComponent({
          mainType: "series",
          query: h == null ? null : {
            seriesIndex: h
          }
        }, y);
        var k, d = e;
        e === "stack" && (k = m({
          stack: i.option.title.tiled,
          tiled: i.option.title.stack
        }, i.option.title), i.get(["iconStatus", e]) !== "emphasis" && (d = "tiled")), r.dispatchAction({
          type: "changeMagicType",
          currentType: d,
          newOption: l,
          newTitle: k,
          featureName: "magicType"
        });
      }
    }, n;
  }(E)
), S = {
  line: /* @__PURE__ */ u(function(a, n, t, r) {
    if (a === "bar")
      return m({
        id: n,
        type: "line",
        // Preserve data related option
        data: t.get("data"),
        stack: t.get("stack"),
        markPoint: t.get("markPoint"),
        markLine: t.get("markLine")
      }, r.get(["option", "line"]) || {}, !0);
  }, "line"),
  bar: /* @__PURE__ */ u(function(a, n, t, r) {
    if (a === "line")
      return m({
        id: n,
        type: "bar",
        // Preserve data related option
        data: t.get("data"),
        stack: t.get("stack"),
        markPoint: t.get("markPoint"),
        markLine: t.get("markLine")
      }, r.get(["option", "bar"]) || {}, !0);
  }, "bar"),
  stack: /* @__PURE__ */ u(function(a, n, t, r) {
    var e = t.get("stack") === T;
    if (a === "line" || a === "bar")
      return r.setIconStatus("stack", e ? "normal" : "emphasis"), m({
        id: n,
        stack: e ? "" : T
      }, r.get(["option", "stack"]) || {}, !0);
  }, "stack")
};
N({
  type: "changeMagicType",
  event: "magicTypeChanged",
  update: "prepareAndUpdate"
}, function(a, n) {
  n.mergeOption(a.newOption);
});
export {
  q as default
};
