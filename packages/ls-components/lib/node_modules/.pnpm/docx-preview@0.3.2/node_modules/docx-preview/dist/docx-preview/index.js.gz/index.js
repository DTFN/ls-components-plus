var Rt = Object.defineProperty;
var c = (a, e) => Rt(a, "name", { value: e, configurable: !0 });
import Bt from "../../../../../jszip@3.10.1/node_modules/jszip/dist/jszip.min/index.js";
var v;
(function(a) {
  a.OfficeDocument = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument", a.FontTable = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/fontTable", a.Image = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", a.Numbering = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering", a.Styles = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles", a.StylesWithEffects = "http://schemas.microsoft.com/office/2007/relationships/stylesWithEffects", a.Theme = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme", a.Settings = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings", a.WebSettings = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/webSettings", a.Hyperlink = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", a.Footnotes = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes", a.Endnotes = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/endnotes", a.Footer = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer", a.Header = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header", a.ExtendedProperties = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties", a.CoreProperties = "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties", a.CustomProperties = "http://schemas.openxmlformats.org/package/2006/relationships/metadata/custom-properties", a.Comments = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments", a.CommentsExtended = "http://schemas.microsoft.com/office/2011/relationships/commentsExtended";
})(v || (v = {}));
function Lt(a, e) {
  return e.elements(a).map((t) => ({
    id: e.attr(t, "Id"),
    type: e.attr(t, "Type"),
    target: e.attr(t, "Target"),
    targetMode: e.attr(t, "TargetMode")
  }));
}
c(Lt, "parseRelationships");
const vt = {
  wordml: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
  drawingml: "http://schemas.openxmlformats.org/drawingml/2006/main",
  picture: "http://schemas.openxmlformats.org/drawingml/2006/picture",
  compatibility: "http://schemas.openxmlformats.org/markup-compatibility/2006",
  math: "http://schemas.openxmlformats.org/officeDocument/2006/math"
}, y = {
  Dxa: { mul: 0.05, unit: "pt" },
  Emu: { mul: 1 / 12700, unit: "pt" },
  FontSize: { mul: 0.5, unit: "pt" },
  Border: { mul: 0.125, unit: "pt" },
  Point: { mul: 1, unit: "pt" },
  Percent: { mul: 0.02, unit: "%" },
  LineHeight: { mul: 1 / 240, unit: "" },
  VmlEmu: { mul: 1 / 12700, unit: "" }
};
function yt(a, e = y.Dxa) {
  return a == null || /.+(p[xt]|[%])$/.test(a) ? a : `${(parseInt(a) * e.mul).toFixed(2)}${e.unit}`;
}
c(yt, "convertLength");
function Ft(a, e = !1) {
  switch (a) {
    case "1":
      return !0;
    case "0":
      return !1;
    case "on":
      return !0;
    case "off":
      return !1;
    case "true":
      return !0;
    case "false":
      return !1;
    default:
      return e;
  }
}
c(Ft, "convertBoolean");
function St(a, e, t) {
  if (a.namespaceURI != vt.wordml)
    return !1;
  switch (a.localName) {
    case "color":
      e.color = t.attr(a, "val");
      break;
    case "sz":
      e.fontSize = t.lengthAttr(a, "val", y.FontSize);
      break;
    default:
      return !1;
  }
  return !0;
}
c(St, "parseCommonProperty");
function $t(a, e = !1) {
  e && (a = a.replace(/<[?].*[?]>/, "")), a = It(a);
  const t = new DOMParser().parseFromString(a, "application/xml"), r = Tt(t);
  if (r)
    throw new Error(r);
  return t;
}
c($t, "parseXmlString");
function Tt(a) {
  var e;
  return (e = a.getElementsByTagName("parsererror")[0]) == null ? void 0 : e.textContent;
}
c(Tt, "hasXmlParserError");
function It(a) {
  return a.charCodeAt(0) === 65279 ? a.substring(1) : a;
}
c(It, "removeUTF8BOM");
function Dt(a) {
  return new XMLSerializer().serializeToString(a);
}
c(Dt, "serializeXmlString");
const Ae = class Ae {
  elements(e, t = null) {
    const r = [];
    for (let s = 0, n = e.childNodes.length; s < n; s++) {
      let o = e.childNodes.item(s);
      o.nodeType == 1 && (t == null || o.localName == t) && r.push(o);
    }
    return r;
  }
  element(e, t) {
    for (let r = 0, s = e.childNodes.length; r < s; r++) {
      let n = e.childNodes.item(r);
      if (n.nodeType == 1 && n.localName == t)
        return n;
    }
    return null;
  }
  elementAttr(e, t, r) {
    var s = this.element(e, t);
    return s ? this.attr(s, r) : void 0;
  }
  attrs(e) {
    return Array.from(e.attributes);
  }
  attr(e, t) {
    for (let r = 0, s = e.attributes.length; r < s; r++) {
      let n = e.attributes.item(r);
      if (n.localName == t)
        return n.value;
    }
    return null;
  }
  intAttr(e, t, r = null) {
    var s = this.attr(e, t);
    return s ? parseInt(s) : r;
  }
  hexAttr(e, t, r = null) {
    var s = this.attr(e, t);
    return s ? parseInt(s, 16) : r;
  }
  floatAttr(e, t, r = null) {
    var s = this.attr(e, t);
    return s ? parseFloat(s) : r;
  }
  boolAttr(e, t, r = null) {
    return Ft(this.attr(e, t), r);
  }
  lengthAttr(e, t, r = y.Dxa) {
    return yt(this.attr(e, t), r);
  }
};
c(Ae, "XmlParser");
let V = Ae;
const i = new V(), Ee = class Ee {
  constructor(e, t) {
    this._package = e, this.path = t;
  }
  async load() {
    this.rels = await this._package.loadRelationships(this.path);
    const e = await this._package.load(this.path), t = this._package.parseXmlDocument(e);
    this._package.options.keepOrigin && (this._xmlDocument = t), this.parseXml(t.firstElementChild);
  }
  save() {
    this._package.update(this.path, Dt(this._xmlDocument));
  }
  parseXml(e) {
  }
};
c(Ee, "Part");
let w = Ee;
const Ot = {
  embedRegular: "regular",
  embedBold: "bold",
  embedItalic: "italic",
  embedBoldItalic: "boldItalic"
};
function Ht(a, e) {
  return e.elements(a).map((t) => zt(t, e));
}
c(Ht, "parseFonts");
function zt(a, e) {
  let t = {
    name: e.attr(a, "name"),
    embedFontRefs: []
  };
  for (let r of e.elements(a))
    switch (r.localName) {
      case "family":
        t.family = e.attr(r, "val");
        break;
      case "altName":
        t.altName = e.attr(r, "val");
        break;
      case "embedRegular":
      case "embedBold":
      case "embedItalic":
      case "embedBoldItalic":
        t.embedFontRefs.push(Vt(r, e));
        break;
    }
  return t;
}
c(zt, "parseFont");
function Vt(a, e) {
  return {
    id: e.attr(a, "id"),
    key: e.attr(a, "fontKey"),
    type: Ot[a.localName]
  };
}
c(Vt, "parseEmbedFontRef");
const xe = class xe extends w {
  parseXml(e) {
    this.fonts = Ht(e, this._package.xmlParser);
  }
};
c(xe, "FontTablePart");
let Z = xe;
function jt(a) {
  return a == null ? void 0 : a.replace(/[ .]+/g, "-").replace(/[&]+/g, "and").toLowerCase();
}
c(jt, "escapeClassName");
function H(a) {
  let e = a.lastIndexOf("/") + 1, t = e == 0 ? "" : a.substring(0, e), r = e == 0 ? a : a.substring(e);
  return [t, r];
}
c(H, "splitPath");
function W(a, e) {
  try {
    const t = "http://docx/";
    return new URL(a, t + e).toString().substring(t.length);
  } catch {
    return `${e}${a}`;
  }
}
c(W, "resolvePath");
function x(a, e) {
  return a.reduce((t, r) => (t[e(r)] = r, t), {});
}
c(x, "keyBy");
function _t(a) {
  return new Promise((e, t) => {
    const r = new FileReader();
    r.onloadend = () => e(r.result), r.onerror = () => t(), r.readAsDataURL(a);
  });
}
c(_t, "blobToBase64");
function J(a) {
  return a && typeof a == "object" && !Array.isArray(a);
}
c(J, "isObject");
function Xt(a) {
  return typeof a == "string" || a instanceof String;
}
c(Xt, "isString");
function j(a, ...e) {
  if (!e.length)
    return a;
  const t = e.shift();
  if (J(a) && J(t))
    for (const r in t)
      if (J(t[r])) {
        const s = a[r] ?? (a[r] = {});
        j(s, t[r]);
      } else
        a[r] = t[r];
  return j(a, ...e);
}
c(j, "mergeDeep");
function F(a) {
  return Array.isArray(a) ? a : [a];
}
c(F, "asArray");
const G = class G {
  constructor(e, t) {
    this._zip = e, this.options = t, this.xmlParser = new V();
  }
  get(e) {
    const t = Ut(e);
    return this._zip.files[t] ?? this._zip.files[t.replace(/\//g, "\\")];
  }
  update(e, t) {
    this._zip.file(e, t);
  }
  static async load(e, t) {
    const r = await Bt.loadAsync(e);
    return new G(r, t);
  }
  save(e = "blob") {
    return this._zip.generateAsync({ type: e });
  }
  load(e, t = "string") {
    var r;
    return ((r = this.get(e)) == null ? void 0 : r.async(t)) ?? Promise.resolve(null);
  }
  async loadRelationships(e = null) {
    let t = "_rels/.rels";
    if (e != null) {
      const [s, n] = H(e);
      t = `${s}_rels/${n}.rels`;
    }
    const r = await this.load(t);
    return r ? Lt(this.parseXmlDocument(r).firstElementChild, this.xmlParser) : null;
  }
  parseXmlDocument(e) {
    return $t(e, this.options.trimXmlDeclaration);
  }
};
c(G, "OpenXmlPackage");
let Y = G;
function Ut(a) {
  return a.startsWith("/") ? a.substr(1) : a;
}
c(Ut, "normalizePath");
const Re = class Re extends w {
  constructor(e, t, r) {
    super(e, t), this._documentParser = r;
  }
  parseXml(e) {
    this.body = this._documentParser.parseDocumentFile(e);
  }
};
c(Re, "DocumentPart");
let K = Re;
function O(a, e) {
  return {
    type: e.attr(a, "val"),
    color: e.attr(a, "color"),
    size: e.lengthAttr(a, "sz", y.Border),
    offset: e.lengthAttr(a, "space", y.Point),
    frame: e.boolAttr(a, "frame"),
    shadow: e.boolAttr(a, "shadow")
  };
}
c(O, "parseBorder");
function Gt(a, e) {
  var t = {};
  for (let r of e.elements(a))
    switch (r.localName) {
      case "left":
        t.left = O(r, e);
        break;
      case "top":
        t.top = O(r, e);
        break;
      case "right":
        t.right = O(r, e);
        break;
      case "bottom":
        t.bottom = O(r, e);
        break;
    }
  return t;
}
c(Gt, "parseBorders");
var ct;
(function(a) {
  a.Continuous = "continuous", a.NextPage = "nextPage", a.NextColumn = "nextColumn", a.EvenPage = "evenPage", a.OddPage = "oddPage";
})(ct || (ct = {}));
function wt(a, e = i) {
  var t = {};
  for (let r of e.elements(a))
    switch (r.localName) {
      case "pgSz":
        t.pageSize = {
          width: e.lengthAttr(r, "w"),
          height: e.lengthAttr(r, "h"),
          orientation: e.attr(r, "orient")
        };
        break;
      case "type":
        t.type = e.attr(r, "val");
        break;
      case "pgMar":
        t.pageMargins = {
          left: e.lengthAttr(r, "left"),
          right: e.lengthAttr(r, "right"),
          top: e.lengthAttr(r, "top"),
          bottom: e.lengthAttr(r, "bottom"),
          header: e.lengthAttr(r, "header"),
          footer: e.lengthAttr(r, "footer"),
          gutter: e.lengthAttr(r, "gutter")
        };
        break;
      case "cols":
        t.columns = qt(r, e);
        break;
      case "headerReference":
        (t.headerRefs ?? (t.headerRefs = [])).push(ht(r, e));
        break;
      case "footerReference":
        (t.footerRefs ?? (t.footerRefs = [])).push(ht(r, e));
        break;
      case "titlePg":
        t.titlePage = e.boolAttr(r, "val", !0);
        break;
      case "pgBorders":
        t.pageBorders = Gt(r, e);
        break;
      case "pgNumType":
        t.pageNumber = Wt(r, e);
        break;
    }
  return t;
}
c(wt, "parseSectionProperties");
function qt(a, e) {
  return {
    numberOfColumns: e.intAttr(a, "num"),
    space: e.lengthAttr(a, "space"),
    separator: e.boolAttr(a, "sep"),
    equalWidth: e.boolAttr(a, "equalWidth", !0),
    columns: e.elements(a, "col").map((t) => ({
      width: e.lengthAttr(t, "w"),
      space: e.lengthAttr(t, "space")
    }))
  };
}
c(qt, "parseColumns");
function Wt(a, e) {
  return {
    chapSep: e.attr(a, "chapSep"),
    chapStyle: e.attr(a, "chapStyle"),
    format: e.attr(a, "fmt"),
    start: e.intAttr(a, "start")
  };
}
c(Wt, "parsePageNumber");
function ht(a, e) {
  return {
    id: e.attr(a, "id"),
    type: e.attr(a, "type")
  };
}
c(ht, "parseFooterHeaderReference");
function Jt(a, e) {
  return {
    before: e.lengthAttr(a, "before"),
    after: e.lengthAttr(a, "after"),
    line: e.intAttr(a, "line"),
    lineRule: e.attr(a, "lineRule")
  };
}
c(Jt, "parseLineSpacing");
function Ne(a, e) {
  let t = {};
  for (let r of e.elements(a))
    Zt(r, t, e);
  return t;
}
c(Ne, "parseRunProperties");
function Zt(a, e, t) {
  return !!St(a, e, t);
}
c(Zt, "parseRunProperty");
function Pt(a, e) {
  let t = {};
  for (let r of e.elements(a))
    Ct(r, t, e);
  return t;
}
c(Pt, "parseParagraphProperties");
function Ct(a, e, t) {
  if (a.namespaceURI != vt.wordml)
    return !1;
  if (St(a, e, t))
    return !0;
  switch (a.localName) {
    case "tabs":
      e.tabs = Yt(a, t);
      break;
    case "sectPr":
      e.sectionProps = wt(a, t);
      break;
    case "numPr":
      e.numbering = Kt(a, t);
      break;
    case "spacing":
      return e.lineSpacing = Jt(a, t), !1;
    case "textAlignment":
      return e.textAlignment = t.attr(a, "val"), !1;
    case "keepLines":
      e.keepLines = t.boolAttr(a, "val", !0);
      break;
    case "keepNext":
      e.keepNext = t.boolAttr(a, "val", !0);
      break;
    case "pageBreakBefore":
      e.pageBreakBefore = t.boolAttr(a, "val", !0);
      break;
    case "outlineLvl":
      e.outlineLevel = t.intAttr(a, "val");
      break;
    case "pStyle":
      e.styleName = t.attr(a, "val");
      break;
    case "rPr":
      e.runProps = Ne(a, t);
      break;
    default:
      return !1;
  }
  return !0;
}
c(Ct, "parseParagraphProperty");
function Yt(a, e) {
  return e.elements(a, "tab").map((t) => ({
    position: e.lengthAttr(t, "pos"),
    leader: e.attr(t, "leader"),
    style: e.attr(t, "val")
  }));
}
c(Yt, "parseTabs");
function Kt(a, e) {
  var t = {};
  for (let r of e.elements(a))
    switch (r.localName) {
      case "numId":
        t.id = e.attr(r, "val");
        break;
      case "ilvl":
        t.level = e.intAttr(r, "val");
        break;
    }
  return t;
}
c(Kt, "parseNumbering$1");
function Qt(a, e) {
  let t = {
    numberings: [],
    abstractNumberings: [],
    bulletPictures: []
  };
  for (let r of e.elements(a))
    switch (r.localName) {
      case "num":
        t.numberings.push(er(r, e));
        break;
      case "abstractNum":
        t.abstractNumberings.push(tr(r, e));
        break;
      case "numPicBullet":
        t.bulletPictures.push(ar(r, e));
        break;
    }
  return t;
}
c(Qt, "parseNumberingPart");
function er(a, e) {
  let t = {
    id: e.attr(a, "numId"),
    overrides: []
  };
  for (let r of e.elements(a))
    switch (r.localName) {
      case "abstractNumId":
        t.abstractId = e.attr(r, "val");
        break;
      case "lvlOverride":
        t.overrides.push(rr(r, e));
        break;
    }
  return t;
}
c(er, "parseNumbering");
function tr(a, e) {
  let t = {
    id: e.attr(a, "abstractNumId"),
    levels: []
  };
  for (let r of e.elements(a))
    switch (r.localName) {
      case "name":
        t.name = e.attr(r, "val");
        break;
      case "multiLevelType":
        t.multiLevelType = e.attr(r, "val");
        break;
      case "numStyleLink":
        t.numberingStyleLink = e.attr(r, "val");
        break;
      case "styleLink":
        t.styleLink = e.attr(r, "val");
        break;
      case "lvl":
        t.levels.push(Mt(r, e));
        break;
    }
  return t;
}
c(tr, "parseAbstractNumbering");
function Mt(a, e) {
  let t = {
    level: e.intAttr(a, "ilvl")
  };
  for (let r of e.elements(a))
    switch (r.localName) {
      case "start":
        t.start = e.attr(r, "val");
        break;
      case "lvlRestart":
        t.restart = e.intAttr(r, "val");
        break;
      case "numFmt":
        t.format = e.attr(r, "val");
        break;
      case "lvlText":
        t.text = e.attr(r, "val");
        break;
      case "lvlJc":
        t.justification = e.attr(r, "val");
        break;
      case "lvlPicBulletId":
        t.bulletPictureId = e.attr(r, "val");
        break;
      case "pStyle":
        t.paragraphStyle = e.attr(r, "val");
        break;
      case "pPr":
        t.paragraphProps = Pt(r, e);
        break;
      case "rPr":
        t.runProps = Ne(r, e);
        break;
    }
  return t;
}
c(Mt, "parseNumberingLevel");
function rr(a, e) {
  let t = {
    level: e.intAttr(a, "ilvl")
  };
  for (let r of e.elements(a))
    switch (r.localName) {
      case "startOverride":
        t.start = e.intAttr(r, "val");
        break;
      case "lvl":
        t.numberingLevel = Mt(r, e);
        break;
    }
  return t;
}
c(rr, "parseNumberingLevelOverrride");
function ar(a, e) {
  var t = e.element(a, "pict"), r = t && e.element(t, "shape"), s = r && e.element(r, "imagedata");
  return s ? {
    id: e.attr(a, "numPicBulletId"),
    referenceId: e.attr(s, "id"),
    style: e.attr(r, "style")
  } : null;
}
c(ar, "parseNumberingBulletPicture");
const Be = class Be extends w {
  constructor(e, t, r) {
    super(e, t), this._documentParser = r;
  }
  parseXml(e) {
    Object.assign(this, Qt(e, this._package.xmlParser)), this.domNumberings = this._documentParser.parseNumberingFile(e);
  }
};
c(Be, "NumberingPart");
let Q = Be;
const Le = class Le extends w {
  constructor(e, t, r) {
    super(e, t), this._documentParser = r;
  }
  parseXml(e) {
    this.styles = this._documentParser.parseStylesFile(e);
  }
};
c(Le, "StylesPart");
let ee = Le;
var l;
(function(a) {
  a.Document = "document", a.Paragraph = "paragraph", a.Run = "run", a.Break = "break", a.NoBreakHyphen = "noBreakHyphen", a.Table = "table", a.Row = "row", a.Cell = "cell", a.Hyperlink = "hyperlink", a.SmartTag = "smartTag", a.Drawing = "drawing", a.Image = "image", a.Text = "text", a.Tab = "tab", a.Symbol = "symbol", a.BookmarkStart = "bookmarkStart", a.BookmarkEnd = "bookmarkEnd", a.Footer = "footer", a.Header = "header", a.FootnoteReference = "footnoteReference", a.EndnoteReference = "endnoteReference", a.Footnote = "footnote", a.Endnote = "endnote", a.SimpleField = "simpleField", a.ComplexField = "complexField", a.Instruction = "instruction", a.VmlPicture = "vmlPicture", a.MmlMath = "mmlMath", a.MmlMathParagraph = "mmlMathParagraph", a.MmlFraction = "mmlFraction", a.MmlFunction = "mmlFunction", a.MmlFunctionName = "mmlFunctionName", a.MmlNumerator = "mmlNumerator", a.MmlDenominator = "mmlDenominator", a.MmlRadical = "mmlRadical", a.MmlBase = "mmlBase", a.MmlDegree = "mmlDegree", a.MmlSuperscript = "mmlSuperscript", a.MmlSubscript = "mmlSubscript", a.MmlPreSubSuper = "mmlPreSubSuper", a.MmlSubArgument = "mmlSubArgument", a.MmlSuperArgument = "mmlSuperArgument", a.MmlNary = "mmlNary", a.MmlDelimiter = "mmlDelimiter", a.MmlRun = "mmlRun", a.MmlEquationArray = "mmlEquationArray", a.MmlLimit = "mmlLimit", a.MmlLimitLower = "mmlLimitLower", a.MmlMatrix = "mmlMatrix", a.MmlMatrixRow = "mmlMatrixRow", a.MmlBox = "mmlBox", a.MmlBar = "mmlBar", a.MmlGroupChar = "mmlGroupChar", a.VmlElement = "vmlElement", a.Inserted = "inserted", a.Deleted = "deleted", a.DeletedText = "deletedText", a.Comment = "comment", a.CommentReference = "commentReference", a.CommentRangeStart = "commentRangeStart", a.CommentRangeEnd = "commentRangeEnd";
})(l || (l = {}));
const Fe = class Fe {
  constructor() {
    this.children = [], this.cssStyle = {};
  }
};
c(Fe, "OpenXmlElementBase");
let N = Fe;
const $e = class $e extends N {
  constructor() {
    super(...arguments), this.type = l.Header;
  }
};
c($e, "WmlHeader");
let te = $e;
const Te = class Te extends N {
  constructor() {
    super(...arguments), this.type = l.Footer;
  }
};
c(Te, "WmlFooter");
let re = Te;
const Ie = class Ie extends w {
  constructor(e, t, r) {
    super(e, t), this._documentParser = r;
  }
  parseXml(e) {
    this.rootElement = this.createRootElement(), this.rootElement.children = this._documentParser.parseBodyElements(e);
  }
};
c(Ie, "BaseHeaderFooterPart");
let _ = Ie;
const De = class De extends _ {
  createRootElement() {
    return new te();
  }
};
c(De, "HeaderPart");
let ae = De;
const Oe = class Oe extends _ {
  createRootElement() {
    return new re();
  }
};
c(Oe, "FooterPart");
let se = Oe;
function sr(a, e) {
  const t = {};
  for (let r of e.elements(a))
    switch (r.localName) {
      case "Template":
        t.template = r.textContent;
        break;
      case "Pages":
        t.pages = $(r.textContent);
        break;
      case "Words":
        t.words = $(r.textContent);
        break;
      case "Characters":
        t.characters = $(r.textContent);
        break;
      case "Application":
        t.application = r.textContent;
        break;
      case "Lines":
        t.lines = $(r.textContent);
        break;
      case "Paragraphs":
        t.paragraphs = $(r.textContent);
        break;
      case "Company":
        t.company = r.textContent;
        break;
      case "AppVersion":
        t.appVersion = r.textContent;
        break;
    }
  return t;
}
c(sr, "parseExtendedProps");
function $(a) {
  if (!(typeof a > "u"))
    return parseInt(a);
}
c($, "safeParseToInt");
const He = class He extends w {
  parseXml(e) {
    this.props = sr(e, this._package.xmlParser);
  }
};
c(He, "ExtendedPropsPart");
let ne = He;
function nr(a, e) {
  const t = {};
  for (let r of e.elements(a))
    switch (r.localName) {
      case "title":
        t.title = r.textContent;
        break;
      case "description":
        t.description = r.textContent;
        break;
      case "subject":
        t.subject = r.textContent;
        break;
      case "creator":
        t.creator = r.textContent;
        break;
      case "keywords":
        t.keywords = r.textContent;
        break;
      case "language":
        t.language = r.textContent;
        break;
      case "lastModifiedBy":
        t.lastModifiedBy = r.textContent;
        break;
      case "revision":
        r.textContent && (t.revision = parseInt(r.textContent));
        break;
    }
  return t;
}
c(nr, "parseCoreProps");
const ze = class ze extends w {
  parseXml(e) {
    this.props = nr(e, this._package.xmlParser);
  }
};
c(ze, "CorePropsPart");
let ie = ze;
const Ve = class Ve {
};
c(Ve, "DmlTheme");
let le = Ve;
function ir(a, e) {
  var t = new le(), r = e.element(a, "themeElements");
  for (let s of e.elements(r))
    switch (s.localName) {
      case "clrScheme":
        t.colorScheme = lr(s, e);
        break;
      case "fontScheme":
        t.fontScheme = or(s, e);
        break;
    }
  return t;
}
c(ir, "parseTheme");
function lr(a, e) {
  var t = {
    name: e.attr(a, "name"),
    colors: {}
  };
  for (let n of e.elements(a)) {
    var r = e.element(n, "srgbClr"), s = e.element(n, "sysClr");
    r ? t.colors[n.localName] = e.attr(r, "val") : s && (t.colors[n.localName] = e.attr(s, "lastClr"));
  }
  return t;
}
c(lr, "parseColorScheme");
function or(a, e) {
  var t = {
    name: e.attr(a, "name")
  };
  for (let r of e.elements(a))
    switch (r.localName) {
      case "majorFont":
        t.majorFont = ut(r, e);
        break;
      case "minorFont":
        t.minorFont = ut(r, e);
        break;
    }
  return t;
}
c(or, "parseFontScheme");
function ut(a, e) {
  return {
    latinTypeface: e.elementAttr(a, "latin", "typeface"),
    eaTypeface: e.elementAttr(a, "ea", "typeface"),
    csTypeface: e.elementAttr(a, "cs", "typeface")
  };
}
c(ut, "parseFontInfo");
const je = class je extends w {
  constructor(e, t) {
    super(e, t);
  }
  parseXml(e) {
    this.theme = ir(e, this._package.xmlParser);
  }
};
c(je, "ThemePart");
let oe = je;
const _e = class _e {
};
c(_e, "WmlBaseNote");
let X = _e;
const Xe = class Xe extends X {
  constructor() {
    super(...arguments), this.type = l.Footnote;
  }
};
c(Xe, "WmlFootnote");
let ce = Xe;
const Ue = class Ue extends X {
  constructor() {
    super(...arguments), this.type = l.Endnote;
  }
};
c(Ue, "WmlEndnote");
let he = Ue;
const Ge = class Ge extends w {
  constructor(e, t, r) {
    super(e, t), this._documentParser = r;
  }
};
c(Ge, "BaseNotePart");
let U = Ge;
const qe = class qe extends U {
  constructor(e, t, r) {
    super(e, t, r);
  }
  parseXml(e) {
    this.notes = this._documentParser.parseNotes(e, "footnote", ce);
  }
};
c(qe, "FootnotesPart");
let ue = qe;
const We = class We extends U {
  constructor(e, t, r) {
    super(e, t, r);
  }
  parseXml(e) {
    this.notes = this._documentParser.parseNotes(e, "endnote", he);
  }
};
c(We, "EndnotesPart");
let de = We;
function cr(a, e) {
  var t = {};
  for (let r of e.elements(a))
    switch (r.localName) {
      case "defaultTabStop":
        t.defaultTabStop = e.lengthAttr(r, "val");
        break;
      case "footnotePr":
        t.footnoteProps = dt(r, e);
        break;
      case "endnotePr":
        t.endnoteProps = dt(r, e);
        break;
      case "autoHyphenation":
        t.autoHyphenation = e.boolAttr(r, "val");
        break;
    }
  return t;
}
c(cr, "parseSettings");
function dt(a, e) {
  var t = {
    defaultNoteIds: []
  };
  for (let r of e.elements(a))
    switch (r.localName) {
      case "numFmt":
        t.nummeringFormat = e.attr(r, "val");
        break;
      case "footnote":
      case "endnote":
        t.defaultNoteIds.push(e.attr(r, "id"));
        break;
    }
  return t;
}
c(dt, "parseNoteProperties");
const Je = class Je extends w {
  constructor(e, t) {
    super(e, t);
  }
  parseXml(e) {
    this.settings = cr(e, this._package.xmlParser);
  }
};
c(Je, "SettingsPart");
let pe = Je;
function hr(a, e) {
  return e.elements(a, "property").map((t) => {
    const r = t.firstChild;
    return {
      formatId: e.attr(t, "fmtid"),
      name: e.attr(t, "name"),
      type: r.nodeName,
      value: r.textContent
    };
  });
}
c(hr, "parseCustomProps");
const Ze = class Ze extends w {
  parseXml(e) {
    this.props = hr(e, this._package.xmlParser);
  }
};
c(Ze, "CustomPropsPart");
let me = Ze;
const Ye = class Ye extends w {
  constructor(e, t, r) {
    super(e, t), this._documentParser = r;
  }
  parseXml(e) {
    this.comments = this._documentParser.parseComments(e), this.commentMap = x(this.comments, (t) => t.id);
  }
};
c(Ye, "CommentsPart");
let fe = Ye;
const Ke = class Ke extends w {
  constructor(e, t) {
    super(e, t), this.comments = [];
  }
  parseXml(e) {
    const t = this._package.xmlParser;
    for (let r of t.elements(e, "commentEx"))
      this.comments.push({
        paraId: t.attr(r, "paraId"),
        paraIdParent: t.attr(r, "paraIdParent"),
        done: t.boolAttr(r, "done")
      });
    this.commentMap = x(this.comments, (r) => r.paraId);
  }
};
c(Ke, "CommentsExtendedPart");
let ge = Ke;
const ur = [
  { type: v.OfficeDocument, target: "word/document.xml" },
  { type: v.ExtendedProperties, target: "docProps/app.xml" },
  { type: v.CoreProperties, target: "docProps/core.xml" },
  { type: v.CustomProperties, target: "docProps/custom.xml" }
], q = class q {
  constructor() {
    this.parts = [], this.partsMap = {};
  }
  static async load(e, t, r) {
    var s = new q();
    return s._options = r, s._parser = t, s._package = await Y.load(e, r), s.rels = await s._package.loadRelationships(), await Promise.all(ur.map((n) => {
      const o = s.rels.find((h) => h.type === n.type) ?? n;
      return s.loadRelationshipPart(o.target, o.type);
    })), s;
  }
  save(e = "blob") {
    return this._package.save(e);
  }
  async loadRelationshipPart(e, t) {
    var s;
    if (this.partsMap[e])
      return this.partsMap[e];
    if (!this._package.get(e))
      return null;
    let r = null;
    switch (t) {
      case v.OfficeDocument:
        this.documentPart = r = new K(this._package, e, this._parser);
        break;
      case v.FontTable:
        this.fontTablePart = r = new Z(this._package, e);
        break;
      case v.Numbering:
        this.numberingPart = r = new Q(this._package, e, this._parser);
        break;
      case v.Styles:
        this.stylesPart = r = new ee(this._package, e, this._parser);
        break;
      case v.Theme:
        this.themePart = r = new oe(this._package, e);
        break;
      case v.Footnotes:
        this.footnotesPart = r = new ue(this._package, e, this._parser);
        break;
      case v.Endnotes:
        this.endnotesPart = r = new de(this._package, e, this._parser);
        break;
      case v.Footer:
        r = new se(this._package, e, this._parser);
        break;
      case v.Header:
        r = new ae(this._package, e, this._parser);
        break;
      case v.CoreProperties:
        this.corePropsPart = r = new ie(this._package, e);
        break;
      case v.ExtendedProperties:
        this.extendedPropsPart = r = new ne(this._package, e);
        break;
      case v.CustomProperties:
        r = new me(this._package, e);
        break;
      case v.Settings:
        this.settingsPart = r = new pe(this._package, e);
        break;
      case v.Comments:
        this.commentsPart = r = new fe(this._package, e, this._parser);
        break;
      case v.CommentsExtended:
        this.commentsExtendedPart = r = new ge(this._package, e);
        break;
    }
    if (r == null)
      return Promise.resolve(null);
    if (this.partsMap[e] = r, this.parts.push(r), await r.load(), ((s = r.rels) == null ? void 0 : s.length) > 0) {
      const [n] = H(r.path);
      await Promise.all(r.rels.map((o) => this.loadRelationshipPart(W(o.target, n), o.type)));
    }
    return r;
  }
  async loadDocumentImage(e, t) {
    const r = await this.loadResource(t ?? this.documentPart, e, "blob");
    return this.blobToURL(r);
  }
  async loadNumberingImage(e) {
    const t = await this.loadResource(this.numberingPart, e, "blob");
    return this.blobToURL(t);
  }
  async loadFont(e, t) {
    const r = await this.loadResource(this.fontTablePart, e, "uint8array");
    return r && this.blobToURL(new Blob([dr(r, t)]));
  }
  blobToURL(e) {
    return e ? this._options.useBase64URL ? _t(e) : URL.createObjectURL(e) : null;
  }
  findPartByRelId(e, t = null) {
    var r = (t.rels ?? this.rels).find((n) => n.id == e);
    const s = t ? H(t.path)[0] : "";
    return r ? this.partsMap[W(r.target, s)] : null;
  }
  getPathById(e, t) {
    const r = e.rels.find((n) => n.id == t), [s] = H(e.path);
    return r ? W(r.target, s) : null;
  }
  loadResource(e, t, r) {
    const s = this.getPathById(e, t);
    return s ? this._package.load(s, r) : Promise.resolve(null);
  }
};
c(q, "WordDocument");
let be = q;
function dr(a, e) {
  const r = e.replace(/{|}|-/g, ""), s = new Array(16);
  for (let n = 0; n < 16; n++)
    s[16 - n - 1] = parseInt(r.substr(n * 2, 2), 16);
  for (let n = 0; n < 32; n++)
    a[n] = a[n] ^ s[n % 16];
  return a;
}
c(dr, "deobfuscate");
function pr(a, e) {
  return {
    type: l.BookmarkStart,
    id: e.attr(a, "id"),
    name: e.attr(a, "name"),
    colFirst: e.intAttr(a, "colFirst"),
    colLast: e.intAttr(a, "colLast")
  };
}
c(pr, "parseBookmarkStart");
function mr(a, e) {
  return {
    type: l.BookmarkEnd,
    id: e.attr(a, "id")
  };
}
c(mr, "parseBookmarkEnd");
const Qe = class Qe extends N {
  constructor() {
    super(...arguments), this.type = l.VmlElement, this.attrs = {};
  }
};
c(Qe, "VmlElement");
let ke = Qe;
function Nt(a, e) {
  var t = new ke();
  switch (a.localName) {
    case "rect":
      t.tagName = "rect", Object.assign(t.attrs, { width: "100%", height: "100%" });
      break;
    case "oval":
      t.tagName = "ellipse", Object.assign(t.attrs, { cx: "50%", cy: "50%", rx: "50%", ry: "50%" });
      break;
    case "line":
      t.tagName = "line";
      break;
    case "shape":
      t.tagName = "g";
      break;
    case "textbox":
      t.tagName = "foreignObject", Object.assign(t.attrs, { width: "100%", height: "100%" });
      break;
    default:
      return null;
  }
  for (const r of i.attrs(a))
    switch (r.localName) {
      case "style":
        t.cssStyleText = r.value;
        break;
      case "fillcolor":
        t.attrs.fill = r.value;
        break;
      case "from":
        const [s, n] = pt(r.value);
        Object.assign(t.attrs, { x1: s, y1: n });
        break;
      case "to":
        const [o, h] = pt(r.value);
        Object.assign(t.attrs, { x2: o, y2: h });
        break;
    }
  for (const r of i.elements(a))
    switch (r.localName) {
      case "stroke":
        Object.assign(t.attrs, fr(r));
        break;
      case "fill":
        Object.assign(t.attrs, gr());
        break;
      case "imagedata":
        t.tagName = "image", Object.assign(t.attrs, { width: "100%", height: "100%" }), t.imageHref = {
          id: i.attr(r, "id"),
          title: i.attr(r, "title")
        };
        break;
      case "txbxContent":
        t.children.push(...e.parseBodyElements(r));
        break;
      default:
        const s = Nt(r, e);
        s && t.children.push(s);
        break;
    }
  return t;
}
c(Nt, "parseVmlElement");
function fr(a) {
  return {
    stroke: i.attr(a, "color"),
    "stroke-width": i.lengthAttr(a, "weight", y.Emu) ?? "1px"
  };
}
c(fr, "parseStroke");
function gr(a) {
  return {};
}
c(gr, "parseFill");
function pt(a) {
  return a.split(",");
}
c(pt, "parsePoint");
const et = class et extends N {
  constructor() {
    super(...arguments), this.type = l.Comment;
  }
};
c(et, "WmlComment");
let ve = et;
const tt = class tt extends N {
  constructor(e) {
    super(), this.id = e, this.type = l.CommentReference;
  }
};
c(tt, "WmlCommentReference");
let ye = tt;
const rt = class rt extends N {
  constructor(e) {
    super(), this.id = e, this.type = l.CommentRangeStart;
  }
};
c(rt, "WmlCommentRangeStart");
let Se = rt;
const at = class at extends N {
  constructor(e) {
    super(), this.id = e, this.type = l.CommentRangeEnd;
  }
};
c(at, "WmlCommentRangeEnd");
let we = at;
var z = {
  shd: "inherit",
  color: "black",
  borderColor: "black",
  highlight: "transparent"
};
const br = [], mt = {
  oMath: l.MmlMath,
  oMathPara: l.MmlMathParagraph,
  f: l.MmlFraction,
  func: l.MmlFunction,
  fName: l.MmlFunctionName,
  num: l.MmlNumerator,
  den: l.MmlDenominator,
  rad: l.MmlRadical,
  deg: l.MmlDegree,
  e: l.MmlBase,
  sSup: l.MmlSuperscript,
  sSub: l.MmlSubscript,
  sPre: l.MmlPreSubSuper,
  sup: l.MmlSuperArgument,
  sub: l.MmlSubArgument,
  d: l.MmlDelimiter,
  nary: l.MmlNary,
  eqArr: l.MmlEquationArray,
  lim: l.MmlLimit,
  limLow: l.MmlLimitLower,
  m: l.MmlMatrix,
  mr: l.MmlMatrixRow,
  box: l.MmlBox,
  bar: l.MmlBar,
  groupChr: l.MmlGroupChar
}, st = class st {
  constructor(e) {
    this.options = {
      ignoreWidth: !1,
      debug: !1,
      ...e
    };
  }
  parseNotes(e, t, r) {
    var s = [];
    for (let n of i.elements(e, t)) {
      const o = new r();
      o.id = i.attr(n, "id"), o.noteType = i.attr(n, "type"), o.children = this.parseBodyElements(n), s.push(o);
    }
    return s;
  }
  parseComments(e) {
    var t = [];
    for (let r of i.elements(e, "comment")) {
      const s = new ve();
      s.id = i.attr(r, "id"), s.author = i.attr(r, "author"), s.initials = i.attr(r, "initials"), s.date = i.attr(r, "date"), s.children = this.parseBodyElements(r), t.push(s);
    }
    return t;
  }
  parseDocumentFile(e) {
    var t = i.element(e, "body"), r = i.element(e, "background"), s = i.element(t, "sectPr");
    return {
      type: l.Document,
      children: this.parseBodyElements(t),
      props: s ? wt(s, i) : {},
      cssStyle: r ? this.parseBackground(r) : {}
    };
  }
  parseBackground(e) {
    var t = {}, r = f.colorAttr(e, "color");
    return r && (t["background-color"] = r), t;
  }
  parseBodyElements(e) {
    var t = [];
    for (let r of i.elements(e))
      switch (r.localName) {
        case "p":
          t.push(this.parseParagraph(r));
          break;
        case "tbl":
          t.push(this.parseTable(r));
          break;
        case "sdt":
          t.push(...this.parseSdt(r, (s) => this.parseBodyElements(s)));
          break;
      }
    return t;
  }
  parseStylesFile(e) {
    var t = [];
    return f.foreach(e, (r) => {
      switch (r.localName) {
        case "style":
          t.push(this.parseStyle(r));
          break;
        case "docDefaults":
          t.push(this.parseDefaultStyles(r));
          break;
      }
    }), t;
  }
  parseDefaultStyles(e) {
    var t = {
      id: null,
      name: null,
      target: null,
      basedOn: null,
      styles: []
    };
    return f.foreach(e, (r) => {
      switch (r.localName) {
        case "rPrDefault":
          var s = i.element(r, "rPr");
          s && t.styles.push({
            target: "span",
            values: this.parseDefaultProperties(s, {})
          });
          break;
        case "pPrDefault":
          var n = i.element(r, "pPr");
          n && t.styles.push({
            target: "p",
            values: this.parseDefaultProperties(n, {})
          });
          break;
      }
    }), t;
  }
  parseStyle(e) {
    var t = {
      id: i.attr(e, "styleId"),
      isDefault: i.boolAttr(e, "default"),
      name: null,
      target: null,
      basedOn: null,
      styles: [],
      linked: null
    };
    switch (i.attr(e, "type")) {
      case "paragraph":
        t.target = "p";
        break;
      case "table":
        t.target = "table";
        break;
      case "character":
        t.target = "span";
        break;
    }
    return f.foreach(e, (r) => {
      switch (r.localName) {
        case "basedOn":
          t.basedOn = i.attr(r, "val");
          break;
        case "name":
          t.name = i.attr(r, "val");
          break;
        case "link":
          t.linked = i.attr(r, "val");
          break;
        case "next":
          t.next = i.attr(r, "val");
          break;
        case "aliases":
          t.aliases = i.attr(r, "val").split(",");
          break;
        case "pPr":
          t.styles.push({
            target: "p",
            values: this.parseDefaultProperties(r, {})
          }), t.paragraphProps = Pt(r, i);
          break;
        case "rPr":
          t.styles.push({
            target: "span",
            values: this.parseDefaultProperties(r, {})
          }), t.runProps = Ne(r, i);
          break;
        case "tblPr":
        case "tcPr":
          t.styles.push({
            target: "td",
            values: this.parseDefaultProperties(r, {})
          });
          break;
        case "tblStylePr":
          for (let s of this.parseTableStyle(r))
            t.styles.push(s);
          break;
        case "rsid":
        case "qFormat":
        case "hidden":
        case "semiHidden":
        case "unhideWhenUsed":
        case "autoRedefine":
        case "uiPriority":
          break;
        default:
          this.options.debug && console.warn(`DOCX: Unknown style element: ${r.localName}`);
      }
    }), t;
  }
  parseTableStyle(e) {
    var t = [], r = i.attr(e, "type"), s = "", n = "";
    switch (r) {
      case "firstRow":
        n = ".first-row", s = "tr.first-row td";
        break;
      case "lastRow":
        n = ".last-row", s = "tr.last-row td";
        break;
      case "firstCol":
        n = ".first-col", s = "td.first-col";
        break;
      case "lastCol":
        n = ".last-col", s = "td.last-col";
        break;
      case "band1Vert":
        n = ":not(.no-vband)", s = "td.odd-col";
        break;
      case "band2Vert":
        n = ":not(.no-vband)", s = "td.even-col";
        break;
      case "band1Horz":
        n = ":not(.no-hband)", s = "tr.odd-row";
        break;
      case "band2Horz":
        n = ":not(.no-hband)", s = "tr.even-row";
        break;
      default:
        return [];
    }
    return f.foreach(e, (o) => {
      switch (o.localName) {
        case "pPr":
          t.push({
            target: `${s} p`,
            mod: n,
            values: this.parseDefaultProperties(o, {})
          });
          break;
        case "rPr":
          t.push({
            target: `${s} span`,
            mod: n,
            values: this.parseDefaultProperties(o, {})
          });
          break;
        case "tblPr":
        case "tcPr":
          t.push({
            target: s,
            mod: n,
            values: this.parseDefaultProperties(o, {})
          });
          break;
      }
    }), t;
  }
  parseNumberingFile(e) {
    var t = [], r = {}, s = [];
    return f.foreach(e, (n) => {
      switch (n.localName) {
        case "abstractNum":
          this.parseAbstractNumbering(n, s).forEach((u) => t.push(u));
          break;
        case "numPicBullet":
          s.push(this.parseNumberingPicBullet(n));
          break;
        case "num":
          var o = i.attr(n, "numId"), h = i.elementAttr(n, "abstractNumId", "val");
          r[h] = o;
          break;
      }
    }), t.forEach((n) => n.id = r[n.id]), t;
  }
  parseNumberingPicBullet(e) {
    var t = i.element(e, "pict"), r = t && i.element(t, "shape"), s = r && i.element(r, "imagedata");
    return s ? {
      id: i.intAttr(e, "numPicBulletId"),
      src: i.attr(s, "id"),
      style: i.attr(r, "style")
    } : null;
  }
  parseAbstractNumbering(e, t) {
    var r = [], s = i.attr(e, "abstractNumId");
    return f.foreach(e, (n) => {
      switch (n.localName) {
        case "lvl":
          r.push(this.parseNumberingLevel(s, n, t));
          break;
      }
    }), r;
  }
  parseNumberingLevel(e, t, r) {
    var s = {
      id: e,
      level: i.intAttr(t, "ilvl"),
      start: 1,
      pStyleName: void 0,
      pStyle: {},
      rStyle: {},
      suff: "tab"
    };
    return f.foreach(t, (n) => {
      switch (n.localName) {
        case "start":
          s.start = i.intAttr(n, "val");
          break;
        case "pPr":
          this.parseDefaultProperties(n, s.pStyle);
          break;
        case "rPr":
          this.parseDefaultProperties(n, s.rStyle);
          break;
        case "lvlPicBulletId":
          var o = i.intAttr(n, "val");
          s.bullet = r.find((h) => (h == null ? void 0 : h.id) == o);
          break;
        case "lvlText":
          s.levelText = i.attr(n, "val");
          break;
        case "pStyle":
          s.pStyleName = i.attr(n, "val");
          break;
        case "numFmt":
          s.format = i.attr(n, "val");
          break;
        case "suff":
          s.suff = i.attr(n, "val");
          break;
      }
    }), s;
  }
  parseSdt(e, t) {
    const r = i.element(e, "sdtContent");
    return r ? t(r) : [];
  }
  parseInserted(e, t) {
    var r;
    return {
      type: l.Inserted,
      children: ((r = t(e)) == null ? void 0 : r.children) ?? []
    };
  }
  parseDeleted(e, t) {
    var r;
    return {
      type: l.Deleted,
      children: ((r = t(e)) == null ? void 0 : r.children) ?? []
    };
  }
  parseParagraph(e) {
    var t = { type: l.Paragraph, children: [] };
    for (let r of i.elements(e))
      switch (r.localName) {
        case "pPr":
          this.parseParagraphProperties(r, t);
          break;
        case "r":
          t.children.push(this.parseRun(r, t));
          break;
        case "hyperlink":
          t.children.push(this.parseHyperlink(r, t));
          break;
        case "smartTag":
          t.children.push(this.parseSmartTag(r, t));
          break;
        case "bookmarkStart":
          t.children.push(pr(r, i));
          break;
        case "bookmarkEnd":
          t.children.push(mr(r, i));
          break;
        case "commentRangeStart":
          t.children.push(new Se(i.attr(r, "id")));
          break;
        case "commentRangeEnd":
          t.children.push(new we(i.attr(r, "id")));
          break;
        case "oMath":
        case "oMathPara":
          t.children.push(this.parseMathElement(r));
          break;
        case "sdt":
          t.children.push(...this.parseSdt(r, (s) => this.parseParagraph(s).children));
          break;
        case "ins":
          t.children.push(this.parseInserted(r, (s) => this.parseParagraph(s)));
          break;
        case "del":
          t.children.push(this.parseDeleted(r, (s) => this.parseParagraph(s)));
          break;
      }
    return t;
  }
  parseParagraphProperties(e, t) {
    this.parseDefaultProperties(e, t.cssStyle = {}, null, (r) => {
      if (Ct(r, t, i))
        return !0;
      switch (r.localName) {
        case "pStyle":
          t.styleName = i.attr(r, "val");
          break;
        case "cnfStyle":
          t.className = m.classNameOfCnfStyle(r);
          break;
        case "framePr":
          this.parseFrame(r, t);
          break;
        case "rPr":
          break;
        default:
          return !1;
      }
      return !0;
    });
  }
  parseFrame(e, t) {
    var r = i.attr(e, "dropCap");
    r == "drop" && (t.cssStyle.float = "left");
  }
  parseHyperlink(e, t) {
    var r = { type: l.Hyperlink, parent: t, children: [] }, s = i.attr(e, "anchor"), n = i.attr(e, "id");
    return s && (r.href = "#" + s), n && (r.id = n), f.foreach(e, (o) => {
      switch (o.localName) {
        case "r":
          r.children.push(this.parseRun(o, r));
          break;
      }
    }), r;
  }
  parseSmartTag(e, t) {
    var r = { type: l.SmartTag, parent: t, children: [] }, s = i.attr(e, "uri"), n = i.attr(e, "element");
    return s && (r.uri = s), n && (r.element = n), f.foreach(e, (o) => {
      switch (o.localName) {
        case "r":
          r.children.push(this.parseRun(o, r));
          break;
      }
    }), r;
  }
  parseRun(e, t) {
    var r = { type: l.Run, parent: t, children: [] };
    return f.foreach(e, (s) => {
      switch (s = this.checkAlternateContent(s), s.localName) {
        case "t":
          r.children.push({
            type: l.Text,
            text: s.textContent
          });
          break;
        case "delText":
          r.children.push({
            type: l.DeletedText,
            text: s.textContent
          });
          break;
        case "commentReference":
          r.children.push(new ye(i.attr(s, "id")));
          break;
        case "fldSimple":
          r.children.push({
            type: l.SimpleField,
            instruction: i.attr(s, "instr"),
            lock: i.boolAttr(s, "lock", !1),
            dirty: i.boolAttr(s, "dirty", !1)
          });
          break;
        case "instrText":
          r.fieldRun = !0, r.children.push({
            type: l.Instruction,
            text: s.textContent
          });
          break;
        case "fldChar":
          r.fieldRun = !0, r.children.push({
            type: l.ComplexField,
            charType: i.attr(s, "fldCharType"),
            lock: i.boolAttr(s, "lock", !1),
            dirty: i.boolAttr(s, "dirty", !1)
          });
          break;
        case "noBreakHyphen":
          r.children.push({ type: l.NoBreakHyphen });
          break;
        case "br":
          r.children.push({
            type: l.Break,
            break: i.attr(s, "type") || "textWrapping"
          });
          break;
        case "lastRenderedPageBreak":
          r.children.push({
            type: l.Break,
            break: "lastRenderedPageBreak"
          });
          break;
        case "sym":
          r.children.push({
            type: l.Symbol,
            font: i.attr(s, "font"),
            char: i.attr(s, "char")
          });
          break;
        case "tab":
          r.children.push({ type: l.Tab });
          break;
        case "footnoteReference":
          r.children.push({
            type: l.FootnoteReference,
            id: i.attr(s, "id")
          });
          break;
        case "endnoteReference":
          r.children.push({
            type: l.EndnoteReference,
            id: i.attr(s, "id")
          });
          break;
        case "drawing":
          let n = this.parseDrawing(s);
          n && (r.children = [n]);
          break;
        case "pict":
          r.children.push(this.parseVmlPicture(s));
          break;
        case "rPr":
          this.parseRunProperties(s, r);
          break;
      }
    }), r;
  }
  parseMathElement(e) {
    const t = `${e.localName}Pr`, r = { type: mt[e.localName], children: [] };
    for (const n of i.elements(e))
      if (mt[n.localName])
        r.children.push(this.parseMathElement(n));
      else if (n.localName == "r") {
        var s = this.parseRun(n);
        s.type = l.MmlRun, r.children.push(s);
      } else n.localName == t && (r.props = this.parseMathProperies(n));
    return r;
  }
  parseMathProperies(e) {
    const t = {};
    for (const r of i.elements(e))
      switch (r.localName) {
        case "chr":
          t.char = i.attr(r, "val");
          break;
        case "vertJc":
          t.verticalJustification = i.attr(r, "val");
          break;
        case "pos":
          t.position = i.attr(r, "val");
          break;
        case "degHide":
          t.hideDegree = i.boolAttr(r, "val");
          break;
        case "begChr":
          t.beginChar = i.attr(r, "val");
          break;
        case "endChr":
          t.endChar = i.attr(r, "val");
          break;
      }
    return t;
  }
  parseRunProperties(e, t) {
    this.parseDefaultProperties(e, t.cssStyle = {}, null, (r) => {
      switch (r.localName) {
        case "rStyle":
          t.styleName = i.attr(r, "val");
          break;
        case "vertAlign":
          t.verticalAlign = m.valueOfVertAlign(r, !0);
          break;
        default:
          return !1;
      }
      return !0;
    });
  }
  parseVmlPicture(e) {
    const t = { type: l.VmlPicture, children: [] };
    for (const r of i.elements(e)) {
      const s = Nt(r, this);
      s && t.children.push(s);
    }
    return t;
  }
  checkAlternateContent(e) {
    var n;
    if (e.localName != "AlternateContent")
      return e;
    var t = i.element(e, "Choice");
    if (t) {
      var r = i.attr(t, "Requires"), s = e.lookupNamespaceURI(r);
      if (br.includes(s))
        return t.firstElementChild;
    }
    return (n = i.element(e, "Fallback")) == null ? void 0 : n.firstElementChild;
  }
  parseDrawing(e) {
    for (var t of i.elements(e))
      switch (t.localName) {
        case "inline":
        case "anchor":
          return this.parseDrawingWrapper(t);
      }
  }
  parseDrawingWrapper(e) {
    var t = { type: l.Drawing, children: [], cssStyle: {} }, r = e.localName == "anchor";
    let s = null, n = i.boolAttr(e, "simplePos");
    i.boolAttr(e, "behindDoc");
    let o = { relative: "page", align: "left", offset: "0" }, h = { relative: "page", align: "top", offset: "0" };
    for (var u of i.elements(e))
      switch (u.localName) {
        case "simplePos":
          n && (o.offset = i.lengthAttr(u, "x", y.Emu), h.offset = i.lengthAttr(u, "y", y.Emu));
          break;
        case "extent":
          t.cssStyle.width = i.lengthAttr(u, "cx", y.Emu), t.cssStyle.height = i.lengthAttr(u, "cy", y.Emu);
          break;
        case "positionH":
        case "positionV":
          if (!n) {
            let p = u.localName == "positionH" ? o : h;
            var k = i.element(u, "align"), b = i.element(u, "posOffset");
            p.relative = i.attr(u, "relativeFrom") ?? p.relative, k && (p.align = k.textContent), b && (p.offset = f.sizeValue(b, y.Emu));
          }
          break;
        case "wrapTopAndBottom":
          s = "wrapTopAndBottom";
          break;
        case "wrapNone":
          s = "wrapNone";
          break;
        case "graphic":
          var S = this.parseGraphic(u);
          S && t.children.push(S);
          break;
      }
    return s == "wrapTopAndBottom" ? (t.cssStyle.display = "block", o.align && (t.cssStyle["text-align"] = o.align, t.cssStyle.width = "100%")) : s == "wrapNone" ? (t.cssStyle.display = "block", t.cssStyle.position = "relative", t.cssStyle.width = "0px", t.cssStyle.height = "0px", o.offset && (t.cssStyle.left = o.offset), h.offset && (t.cssStyle.top = h.offset)) : r && (o.align == "left" || o.align == "right") && (t.cssStyle.float = o.align), t;
  }
  parseGraphic(e) {
    var t = i.element(e, "graphicData");
    for (let r of i.elements(t))
      switch (r.localName) {
        case "pic":
          return this.parsePicture(r);
      }
    return null;
  }
  parsePicture(e) {
    var t = { type: l.Image, src: "", cssStyle: {} }, r = i.element(e, "blipFill"), s = i.element(r, "blip");
    t.src = i.attr(s, "embed");
    var n = i.element(e, "spPr"), o = i.element(n, "xfrm");
    t.cssStyle.position = "relative";
    for (var h of i.elements(o))
      switch (h.localName) {
        case "ext":
          t.cssStyle.width = i.lengthAttr(h, "cx", y.Emu), t.cssStyle.height = i.lengthAttr(h, "cy", y.Emu);
          break;
        case "off":
          t.cssStyle.left = i.lengthAttr(h, "x", y.Emu), t.cssStyle.top = i.lengthAttr(h, "y", y.Emu);
          break;
      }
    return t;
  }
  parseTable(e) {
    var t = { type: l.Table, children: [] };
    return f.foreach(e, (r) => {
      switch (r.localName) {
        case "tr":
          t.children.push(this.parseTableRow(r));
          break;
        case "tblGrid":
          t.columns = this.parseTableColumns(r);
          break;
        case "tblPr":
          this.parseTableProperties(r, t);
          break;
      }
    }), t;
  }
  parseTableColumns(e) {
    var t = [];
    return f.foreach(e, (r) => {
      switch (r.localName) {
        case "gridCol":
          t.push({ width: i.lengthAttr(r, "w") });
          break;
      }
    }), t;
  }
  parseTableProperties(e, t) {
    switch (t.cssStyle = {}, t.cellStyle = {}, this.parseDefaultProperties(e, t.cssStyle, t.cellStyle, (r) => {
      switch (r.localName) {
        case "tblStyle":
          t.styleName = i.attr(r, "val");
          break;
        case "tblLook":
          t.className = m.classNameOftblLook(r);
          break;
        case "tblpPr":
          this.parseTablePosition(r, t);
          break;
        case "tblStyleColBandSize":
          t.colBandSize = i.intAttr(r, "val");
          break;
        case "tblStyleRowBandSize":
          t.rowBandSize = i.intAttr(r, "val");
          break;
        default:
          return !1;
      }
      return !0;
    }), t.cssStyle["text-align"]) {
      case "center":
        delete t.cssStyle["text-align"], t.cssStyle["margin-left"] = "auto", t.cssStyle["margin-right"] = "auto";
        break;
      case "right":
        delete t.cssStyle["text-align"], t.cssStyle["margin-left"] = "auto";
        break;
    }
  }
  parseTablePosition(e, t) {
    var r = i.lengthAttr(e, "topFromText"), s = i.lengthAttr(e, "bottomFromText"), n = i.lengthAttr(e, "rightFromText"), o = i.lengthAttr(e, "leftFromText");
    t.cssStyle.float = "left", t.cssStyle["margin-bottom"] = m.addSize(t.cssStyle["margin-bottom"], s), t.cssStyle["margin-left"] = m.addSize(t.cssStyle["margin-left"], o), t.cssStyle["margin-right"] = m.addSize(t.cssStyle["margin-right"], n), t.cssStyle["margin-top"] = m.addSize(t.cssStyle["margin-top"], r);
  }
  parseTableRow(e) {
    var t = { type: l.Row, children: [] };
    return f.foreach(e, (r) => {
      switch (r.localName) {
        case "tc":
          t.children.push(this.parseTableCell(r));
          break;
        case "trPr":
          this.parseTableRowProperties(r, t);
          break;
      }
    }), t;
  }
  parseTableRowProperties(e, t) {
    t.cssStyle = this.parseDefaultProperties(e, {}, null, (r) => {
      switch (r.localName) {
        case "cnfStyle":
          t.className = m.classNameOfCnfStyle(r);
          break;
        case "tblHeader":
          t.isHeader = i.boolAttr(r, "val");
          break;
        default:
          return !1;
      }
      return !0;
    });
  }
  parseTableCell(e) {
    var t = { type: l.Cell, children: [] };
    return f.foreach(e, (r) => {
      switch (r.localName) {
        case "tbl":
          t.children.push(this.parseTable(r));
          break;
        case "p":
          t.children.push(this.parseParagraph(r));
          break;
        case "tcPr":
          this.parseTableCellProperties(r, t);
          break;
      }
    }), t;
  }
  parseTableCellProperties(e, t) {
    t.cssStyle = this.parseDefaultProperties(e, {}, null, (r) => {
      switch (r.localName) {
        case "gridSpan":
          t.span = i.intAttr(r, "val", null);
          break;
        case "vMerge":
          t.verticalMerge = i.attr(r, "val") ?? "continue";
          break;
        case "cnfStyle":
          t.className = m.classNameOfCnfStyle(r);
          break;
        default:
          return !1;
      }
      return !0;
    });
  }
  parseDefaultProperties(e, t = null, r = null, s = null) {
    return t = t || {}, f.foreach(e, (n) => {
      if (!(s != null && s(n)))
        switch (n.localName) {
          case "jc":
            t["text-align"] = m.valueOfJc(n);
            break;
          case "textAlignment":
            t["vertical-align"] = m.valueOfTextAlignment(n);
            break;
          case "color":
            t.color = f.colorAttr(n, "val", null, z.color);
            break;
          case "sz":
            t["font-size"] = t["min-height"] = i.lengthAttr(n, "val", y.FontSize);
            break;
          case "shd":
            t["background-color"] = f.colorAttr(n, "fill", null, z.shd);
            break;
          case "highlight":
            t["background-color"] = f.colorAttr(n, "val", null, z.highlight);
            break;
          case "vertAlign":
            break;
          case "position":
            t.verticalAlign = i.lengthAttr(n, "val", y.FontSize);
            break;
          case "tcW":
            if (this.options.ignoreWidth)
              break;
          case "tblW":
            t.width = m.valueOfSize(n, "w");
            break;
          case "trHeight":
            this.parseTrHeight(n, t);
            break;
          case "strike":
            t["text-decoration"] = i.boolAttr(n, "val", !0) ? "line-through" : "none";
            break;
          case "b":
            t["font-weight"] = i.boolAttr(n, "val", !0) ? "bold" : "normal";
            break;
          case "i":
            t["font-style"] = i.boolAttr(n, "val", !0) ? "italic" : "normal";
            break;
          case "caps":
            t["text-transform"] = i.boolAttr(n, "val", !0) ? "uppercase" : "none";
            break;
          case "smallCaps":
            t["font-variant"] = i.boolAttr(n, "val", !0) ? "small-caps" : "none";
            break;
          case "u":
            this.parseUnderline(n, t);
            break;
          case "ind":
          case "tblInd":
            this.parseIndentation(n, t);
            break;
          case "rFonts":
            this.parseFont(n, t);
            break;
          case "tblBorders":
            this.parseBorderProperties(n, r || t);
            break;
          case "tblCellSpacing":
            t["border-spacing"] = m.valueOfMargin(n), t["border-collapse"] = "separate";
            break;
          case "pBdr":
            this.parseBorderProperties(n, t);
            break;
          case "bdr":
            t.border = m.valueOfBorder(n);
            break;
          case "tcBorders":
            this.parseBorderProperties(n, t);
            break;
          case "vanish":
            i.boolAttr(n, "val", !0) && (t.display = "none");
            break;
          case "kern":
            break;
          case "noWrap":
            break;
          case "tblCellMar":
          case "tcMar":
            this.parseMarginProperties(n, r || t);
            break;
          case "tblLayout":
            t["table-layout"] = m.valueOfTblLayout(n);
            break;
          case "vAlign":
            t["vertical-align"] = m.valueOfTextAlignment(n);
            break;
          case "spacing":
            e.localName == "pPr" && this.parseSpacing(n, t);
            break;
          case "wordWrap":
            i.boolAttr(n, "val") && (t["overflow-wrap"] = "break-word");
            break;
          case "suppressAutoHyphens":
            t.hyphens = i.boolAttr(n, "val", !0) ? "none" : "auto";
            break;
          case "lang":
            t.$lang = i.attr(n, "val");
            break;
          case "bCs":
          case "iCs":
          case "szCs":
          case "tabs":
          case "outlineLvl":
          case "contextualSpacing":
          case "tblStyleColBandSize":
          case "tblStyleRowBandSize":
          case "webHidden":
          case "pageBreakBefore":
          case "suppressLineNumbers":
          case "keepLines":
          case "keepNext":
          case "widowControl":
          case "bidi":
          case "rtl":
          case "noProof":
            break;
          default:
            this.options.debug && console.warn(`DOCX: Unknown document element: ${e.localName}.${n.localName}`);
            break;
        }
    }), t;
  }
  parseUnderline(e, t) {
    var r = i.attr(e, "val");
    if (r != null) {
      switch (r) {
        case "dash":
        case "dashDotDotHeavy":
        case "dashDotHeavy":
        case "dashedHeavy":
        case "dashLong":
        case "dashLongHeavy":
        case "dotDash":
        case "dotDotDash":
          t["text-decoration"] = "underline dashed";
          break;
        case "dotted":
        case "dottedHeavy":
          t["text-decoration"] = "underline dotted";
          break;
        case "double":
          t["text-decoration"] = "underline double";
          break;
        case "single":
        case "thick":
          t["text-decoration"] = "underline";
          break;
        case "wave":
        case "wavyDouble":
        case "wavyHeavy":
          t["text-decoration"] = "underline wavy";
          break;
        case "words":
          t["text-decoration"] = "underline";
          break;
        case "none":
          t["text-decoration"] = "none";
          break;
      }
      var s = f.colorAttr(e, "color");
      s && (t["text-decoration-color"] = s);
    }
  }
  parseFont(e, t) {
    var r = i.attr(e, "ascii"), s = m.themeValue(e, "asciiTheme"), n = [r, s].filter((o) => o).join(", ");
    n.length > 0 && (t["font-family"] = n);
  }
  parseIndentation(e, t) {
    var r = i.lengthAttr(e, "firstLine"), s = i.lengthAttr(e, "hanging"), n = i.lengthAttr(e, "left"), o = i.lengthAttr(e, "start"), h = i.lengthAttr(e, "right"), u = i.lengthAttr(e, "end");
    r && (t["text-indent"] = r), s && (t["text-indent"] = `-${s}`), (n || o) && (t["margin-left"] = n || o), (h || u) && (t["margin-right"] = h || u);
  }
  parseSpacing(e, t) {
    var r = i.lengthAttr(e, "before"), s = i.lengthAttr(e, "after"), n = i.intAttr(e, "line", null), o = i.attr(e, "lineRule");
    if (r && (t["margin-top"] = r), s && (t["margin-bottom"] = s), n !== null)
      switch (o) {
        case "auto":
          t["line-height"] = `${(n / 240).toFixed(2)}`;
          break;
        case "atLeast":
          t["line-height"] = `calc(100% + ${n / 20}pt)`;
          break;
        default:
          t["line-height"] = t["min-height"] = `${n / 20}pt`;
          break;
      }
  }
  parseMarginProperties(e, t) {
    f.foreach(e, (r) => {
      switch (r.localName) {
        case "left":
          t["padding-left"] = m.valueOfMargin(r);
          break;
        case "right":
          t["padding-right"] = m.valueOfMargin(r);
          break;
        case "top":
          t["padding-top"] = m.valueOfMargin(r);
          break;
        case "bottom":
          t["padding-bottom"] = m.valueOfMargin(r);
          break;
      }
    });
  }
  parseTrHeight(e, t) {
    switch (i.attr(e, "hRule")) {
      case "exact":
        t.height = i.lengthAttr(e, "val");
        break;
      case "atLeast":
      default:
        t.height = i.lengthAttr(e, "val");
        break;
    }
  }
  parseBorderProperties(e, t) {
    f.foreach(e, (r) => {
      switch (r.localName) {
        case "start":
        case "left":
          t["border-left"] = m.valueOfBorder(r);
          break;
        case "end":
        case "right":
          t["border-right"] = m.valueOfBorder(r);
          break;
        case "top":
          t["border-top"] = m.valueOfBorder(r);
          break;
        case "bottom":
          t["border-bottom"] = m.valueOfBorder(r);
          break;
      }
    });
  }
};
c(st, "DocumentParser");
let Pe = st;
const kr = ["black", "blue", "cyan", "darkBlue", "darkCyan", "darkGray", "darkGreen", "darkMagenta", "darkRed", "darkYellow", "green", "lightGray", "magenta", "none", "red", "white", "yellow"], nt = class nt {
  static foreach(e, t) {
    for (var r = 0; r < e.childNodes.length; r++) {
      let s = e.childNodes[r];
      s.nodeType == Node.ELEMENT_NODE && t(s);
    }
  }
  static colorAttr(e, t, r = null, s = "black") {
    var n = i.attr(e, t);
    if (n)
      return n == "auto" ? s : kr.includes(n) ? n : `#${n}`;
    var o = i.attr(e, "themeColor");
    return o ? `var(--docx-${o}-color)` : r;
  }
  static sizeValue(e, t = y.Dxa) {
    return yt(e.textContent, t);
  }
};
c(nt, "xmlUtil");
let f = nt;
const it = class it {
  static themeValue(e, t) {
    var r = i.attr(e, t);
    return r ? `var(--docx-${r}-font)` : null;
  }
  static valueOfSize(e, t) {
    var r = y.Dxa;
    switch (i.attr(e, "type")) {
      case "dxa":
        break;
      case "pct":
        r = y.Percent;
        break;
      case "auto":
        return "auto";
    }
    return i.lengthAttr(e, t, r);
  }
  static valueOfMargin(e) {
    return i.lengthAttr(e, "w");
  }
  static valueOfBorder(e) {
    var t = i.attr(e, "val");
    if (t == "nil")
      return "none";
    var r = f.colorAttr(e, "color"), s = i.lengthAttr(e, "sz", y.Border);
    return `${s} solid ${r == "auto" ? z.borderColor : r}`;
  }
  static valueOfTblLayout(e) {
    var t = i.attr(e, "val");
    return t == "fixed" ? "fixed" : "auto";
  }
  static classNameOfCnfStyle(e) {
    const t = i.attr(e, "val");
    return [
      "first-row",
      "last-row",
      "first-col",
      "last-col",
      "odd-col",
      "even-col",
      "odd-row",
      "even-row",
      "ne-cell",
      "nw-cell",
      "se-cell",
      "sw-cell"
    ].filter((s, n) => t[n] == "1").join(" ");
  }
  static valueOfJc(e) {
    var t = i.attr(e, "val");
    switch (t) {
      case "start":
      case "left":
        return "left";
      case "center":
        return "center";
      case "end":
      case "right":
        return "right";
      case "both":
        return "justify";
    }
    return t;
  }
  static valueOfVertAlign(e, t = !1) {
    var r = i.attr(e, "val");
    switch (r) {
      case "subscript":
        return "sub";
      case "superscript":
        return t ? "sup" : "super";
    }
    return t ? null : r;
  }
  static valueOfTextAlignment(e) {
    var t = i.attr(e, "val");
    switch (t) {
      case "auto":
      case "baseline":
        return "baseline";
      case "top":
        return "top";
      case "center":
        return "middle";
      case "bottom":
        return "bottom";
    }
    return t;
  }
  static addSize(e, t) {
    return e == null ? t : t == null ? e : `calc(${e} + ${t})`;
  }
  static classNameOftblLook(e) {
    const t = i.hexAttr(e, "val", 0);
    let r = "";
    return (i.boolAttr(e, "firstRow") || t & 32) && (r += " first-row"), (i.boolAttr(e, "lastRow") || t & 64) && (r += " last-row"), (i.boolAttr(e, "firstColumn") || t & 128) && (r += " first-col"), (i.boolAttr(e, "lastColumn") || t & 256) && (r += " last-col"), (i.boolAttr(e, "noHBand") || t & 512) && (r += " no-hband"), (i.boolAttr(e, "noVBand") || t & 1024) && (r += " no-vband"), r.trim();
  }
};
c(it, "values");
let m = it;
const ft = { pos: 0, leader: "none", style: "left" }, vr = 50;
function yr(a = document.body) {
  const e = document.createElement("div");
  e.style.width = "100pt", a.appendChild(e);
  const t = 100 / e.offsetWidth;
  return a.removeChild(e), t;
}
c(yr, "computePixelToPoint");
function Sr(a, e, t, r = 72 / 96) {
  const s = a.closest("p"), n = a.getBoundingClientRect(), o = s.getBoundingClientRect(), h = getComputedStyle(s), u = (e == null ? void 0 : e.length) > 0 ? e.map((C) => ({
    pos: gt(C.position),
    leader: C.leader,
    style: C.style
  })).sort((C, I) => C.pos - I.pos) : [ft], k = u[u.length - 1], b = o.width * r, S = gt(t);
  let p = k.pos + S;
  if (p < b)
    for (; p < b && u.length < vr; p += S)
      u.push({ ...ft, pos: p });
  const P = parseFloat(h.marginLeft), A = o.left + P, E = (n.left - A) * r, M = u.find((C) => C.style != "clear" && C.pos > E);
  if (M == null)
    return;
  let L = 1;
  if (M.style == "right" || M.style == "center") {
    const C = Array.from(s.querySelectorAll(`.${a.className}`)), I = C.indexOf(a) + 1, D = document.createRange();
    D.setStart(a, 1), I < C.length ? D.setEndBefore(C[I]) : D.setEndAfter(s);
    const Et = M.style == "center" ? 0.5 : 1, ot = D.getBoundingClientRect(), xt = ot.left + Et * ot.width - (o.left - P);
    L = M.pos - xt * r;
  } else
    L = M.pos - E;
  switch (a.innerHTML = "&nbsp;", a.style.textDecoration = "inherit", a.style.wordSpacing = `${L.toFixed(0)}pt`, M.leader) {
    case "dot":
    case "middleDot":
      a.style.textDecoration = "underline", a.style.textDecorationStyle = "dotted";
      break;
    case "hyphen":
    case "heavy":
    case "underscore":
      a.style.textDecoration = "underline";
      break;
  }
}
c(Sr, "updateTabStop");
function gt(a) {
  return parseFloat(a);
}
c(gt, "lengthToPoint");
const d = {
  svg: "http://www.w3.org/2000/svg",
  mathML: "http://www.w3.org/1998/Math/MathML"
}, lt = class lt {
  constructor(e) {
    this.htmlDocument = e, this.className = "docx", this.styleMap = {}, this.currentPart = null, this.tableVerticalMerges = [], this.currentVerticalMerge = null, this.tableCellPositions = [], this.currentCellPosition = null, this.footnoteMap = {}, this.endnoteMap = {}, this.currentEndnoteIds = [], this.usedHederFooterParts = [], this.currentTabs = [], this.tabsTimeout = 0, this.commentMap = {}, this.tasks = [], this.postRenderTasks = [], this.createElement = R;
  }
  render(e, t, r = null, s) {
    var o;
    this.document = e, this.options = s, this.className = s.className, this.rootSelector = s.inWrapper ? `.${this.className}-wrapper` : ":root", this.styleMap = null, this.tasks = [], this.options.renderComments && globalThis.Highlight && (this.commentHighlight = new Highlight()), r = r || t, kt(r), kt(t), T(r, "docxjs library predefined styles"), r.appendChild(this.renderDefaultStyle()), e.themePart && (T(r, "docxjs document theme values"), this.renderTheme(e.themePart, r)), e.stylesPart != null && (this.styleMap = this.processStyles(e.stylesPart.styles), T(r, "docxjs document styles"), r.appendChild(this.renderStyles(e.stylesPart.styles))), e.numberingPart && (this.prodessNumberings(e.numberingPart.domNumberings), T(r, "docxjs document numbering styles"), r.appendChild(this.renderNumbering(e.numberingPart.domNumberings, r))), e.footnotesPart && (this.footnoteMap = x(e.footnotesPart.notes, (h) => h.id)), e.endnotesPart && (this.endnoteMap = x(e.endnotesPart.notes, (h) => h.id)), e.settingsPart && (this.defaultTabSize = (o = e.settingsPart.settings) == null ? void 0 : o.defaultTabStop), !s.ignoreFonts && e.fontTablePart && this.renderFontTable(e.fontTablePart, r);
    var n = this.renderSections(e.documentPart.body);
    this.options.inWrapper ? t.appendChild(this.renderWrapper(n)) : Me(t, n), this.commentHighlight && s.renderComments && CSS.highlights.set(`${this.className}-comments`, this.commentHighlight), this.refreshTabStops(), this.postRenderTasks.forEach((h) => h());
  }
  renderTheme(e, t) {
    var h, u;
    const r = {}, s = (h = e.theme) == null ? void 0 : h.fontScheme;
    s && (s.majorFont && (r["--docx-majorHAnsi-font"] = s.majorFont.latinTypeface), s.minorFont && (r["--docx-minorHAnsi-font"] = s.minorFont.latinTypeface));
    const n = (u = e.theme) == null ? void 0 : u.colorScheme;
    if (n)
      for (let [k, b] of Object.entries(n.colors))
        r[`--docx-${k}-color`] = `#${b}`;
    const o = this.styleToString(`.${this.className}`, r);
    t.appendChild(B(o));
  }
  renderFontTable(e, t) {
    for (let r of e.fonts)
      for (let s of r.embedFontRefs)
        this.tasks.push(this.document.loadFont(s.id, s.key).then((n) => {
          const o = {
            "font-family": r.name,
            src: `url(${n})`
          };
          (s.type == "bold" || s.type == "boldItalic") && (o["font-weight"] = "bold"), (s.type == "italic" || s.type == "boldItalic") && (o["font-style"] = "italic"), T(t, `docxjs ${r.name} font`);
          const h = this.styleToString("@font-face", o);
          t.appendChild(B(h)), this.refreshTabStops();
        }));
  }
  processStyleName(e) {
    return e ? `${this.className}_${jt(e)}` : this.className;
  }
  processStyles(e) {
    const t = x(e.filter((s) => s.id != null), (s) => s.id);
    for (const s of e.filter((n) => n.basedOn)) {
      var r = t[s.basedOn];
      if (r) {
        s.paragraphProps = j(s.paragraphProps, r.paragraphProps), s.runProps = j(s.runProps, r.runProps);
        for (const n of r.styles) {
          const o = s.styles.find((h) => h.target == n.target);
          o ? this.copyStyleProperties(n.values, o.values) : s.styles.push({ ...n, values: { ...n.values } });
        }
      } else this.options.debug && console.warn(`Can't find base style ${s.basedOn}`);
    }
    for (let s of e)
      s.cssName = this.processStyleName(s.id);
    return t;
  }
  prodessNumberings(e) {
    var t;
    for (let r of e.filter((s) => s.pStyleName)) {
      const s = this.findStyle(r.pStyleName);
      (t = s == null ? void 0 : s.paragraphProps) != null && t.numbering && (s.paragraphProps.numbering.level = r.level);
    }
  }
  processElement(e) {
    if (e.children)
      for (var t of e.children)
        t.parent = e, t.type == l.Table ? this.processTable(t) : this.processElement(t);
  }
  processTable(e) {
    for (var t of e.children)
      for (var r of t.children)
        r.cssStyle = this.copyStyleProperties(e.cellStyle, r.cssStyle, [
          "border-left",
          "border-right",
          "border-top",
          "border-bottom",
          "padding-left",
          "padding-right",
          "padding-top",
          "padding-bottom"
        ]), this.processElement(r);
  }
  copyStyleProperties(e, t, r = null) {
    if (!e)
      return t;
    t == null && (t = {}), r == null && (r = Object.getOwnPropertyNames(e));
    for (var s of r)
      e.hasOwnProperty(s) && !t.hasOwnProperty(s) && (t[s] = e[s]);
    return t;
  }
  createPageElement(e, t) {
    var r = this.createElement("section", { className: e });
    return t && (t.pageMargins && (r.style.paddingLeft = t.pageMargins.left, r.style.paddingRight = t.pageMargins.right, r.style.paddingTop = t.pageMargins.top, r.style.paddingBottom = t.pageMargins.bottom), t.pageSize && (this.options.ignoreWidth || (r.style.width = t.pageSize.width), this.options.ignoreHeight || (r.style.minHeight = t.pageSize.height))), r;
  }
  createSectionContent(e) {
    var t = this.createElement("article");
    return e.columns && e.columns.numberOfColumns && (t.style.columnCount = `${e.columns.numberOfColumns}`, t.style.columnGap = e.columns.space, e.columns.separator && (t.style.columnRule = "1px solid black")), t;
  }
  renderSections(e) {
    const t = [];
    this.processElement(e);
    const r = this.splitBySection(e.children, e.props), s = this.groupByPageBreaks(r);
    let n = null;
    for (let h = 0, u = s.length; h < u; h++) {
      this.currentFootnoteIds = [];
      let b = s[h][0].sectProps;
      const S = this.createPageElement(this.className, b);
      this.renderStyleValues(e.cssStyle, S), this.options.renderHeaders && this.renderHeaderFooter(b.headerRefs, b, t.length, n != b, S);
      for (const p of s[h]) {
        var o = this.createSectionContent(p.sectProps);
        this.renderElements(p.elements, o), S.appendChild(o), b = p.sectProps;
      }
      this.options.renderFootnotes && this.renderNotes(this.currentFootnoteIds, this.footnoteMap, S), this.options.renderEndnotes && h == u - 1 && this.renderNotes(this.currentEndnoteIds, this.endnoteMap, S), this.options.renderFooters && this.renderHeaderFooter(b.footerRefs, b, t.length, n != b, S), t.push(S), n = b;
    }
    return t;
  }
  renderHeaderFooter(e, t, r, s, n) {
    if (e) {
      var o = (t.titlePage && s ? e.find((u) => u.type == "first") : null) ?? (r % 2 == 1 ? e.find((u) => u.type == "even") : null) ?? e.find((u) => u.type == "default"), h = o && this.document.findPartByRelId(o.id, this.document.documentPart);
      if (h) {
        this.currentPart = h, this.usedHederFooterParts.includes(h.path) || (this.processElement(h.rootElement), this.usedHederFooterParts.push(h.path));
        const [u] = this.renderElements([h.rootElement], n);
        t != null && t.pageMargins && (h.rootElement.type === l.Header ? (u.style.marginTop = `calc(${t.pageMargins.header} - ${t.pageMargins.top})`, u.style.minHeight = `calc(${t.pageMargins.top} - ${t.pageMargins.header})`) : h.rootElement.type === l.Footer && (u.style.marginBottom = `calc(${t.pageMargins.footer} - ${t.pageMargins.bottom})`, u.style.minHeight = `calc(${t.pageMargins.bottom} - ${t.pageMargins.footer})`)), this.currentPart = null;
      }
    }
  }
  isPageBreakElement(e) {
    return e.type != l.Break ? !1 : e.break == "lastRenderedPageBreak" ? !this.options.ignoreLastRenderedPageBreak : e.break == "page";
  }
  isPageBreakSection(e, t) {
    var r, s, n, o, h, u;
    return !e || !t ? !1 : ((r = e.pageSize) == null ? void 0 : r.orientation) != ((s = t.pageSize) == null ? void 0 : s.orientation) || ((n = e.pageSize) == null ? void 0 : n.width) != ((o = t.pageSize) == null ? void 0 : o.width) || ((h = e.pageSize) == null ? void 0 : h.height) != ((u = t.pageSize) == null ? void 0 : u.height);
  }
  splitBySection(e, t) {
    var S;
    var r = { sectProps: null, elements: [], pageBreak: !1 }, s = [r];
    for (let p of e) {
      if (p.type == l.Paragraph) {
        const P = this.findStyle(p.styleName);
        (S = P == null ? void 0 : P.paragraphProps) != null && S.pageBreakBefore && (r.sectProps = n, r.pageBreak = !0, r = { sectProps: null, elements: [], pageBreak: !1 }, s.push(r));
      }
      if (r.elements.push(p), p.type == l.Paragraph) {
        const P = p;
        var n = P.sectionProps, o = -1, h = -1;
        if (this.options.breakPages && P.children && (o = P.children.findIndex((A) => {
          var E;
          return h = ((E = A.children) == null ? void 0 : E.findIndex(this.isPageBreakElement.bind(this))) ?? -1, h != -1;
        })), (n || o != -1) && (r.sectProps = n, r.pageBreak = o != -1, r = { sectProps: null, elements: [], pageBreak: !1 }, s.push(r)), o != -1) {
          let A = P.children[o], E = h < A.children.length - 1;
          if (o < P.children.length - 1 || E) {
            var u = p.children, k = { ...p, children: u.slice(o) };
            if (p.children = u.slice(0, o), r.elements.push(k), E) {
              let M = A.children, L = { ...A, children: M.slice(0, h) };
              p.children.push(L), A.children = M.slice(h);
            }
          }
        }
      }
    }
    let b = null;
    for (let p = s.length - 1; p >= 0; p--)
      s[p].sectProps == null ? s[p].sectProps = b ?? t : b = s[p].sectProps;
    return s;
  }
  groupByPageBreaks(e) {
    let t = [], r;
    const s = [t];
    for (let n of e)
      t.push(n), (this.options.ignoreLastRenderedPageBreak || n.pageBreak || this.isPageBreakSection(r, n.sectProps)) && s.push(t = []), r = n.sectProps;
    return s.filter((n) => n.length > 0);
  }
  renderWrapper(e) {
    return this.createElement("div", { className: `${this.className}-wrapper` }, e);
  }
  renderDefaultStyle() {
    var e = this.className, t = `
.${e}-wrapper { background: gray; padding: 30px; padding-bottom: 0px; display: flex; flex-flow: column; align-items: center; } 
.${e}-wrapper>section.${e} { background: white; box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); margin-bottom: 30px; }
.${e} { color: black; hyphens: auto; text-underline-position: from-font; }
section.${e} { box-sizing: border-box; display: flex; flex-flow: column nowrap; position: relative; overflow: hidden; }
section.${e}>article { margin-bottom: auto; z-index: 1; }
section.${e}>footer { z-index: 1; }
.${e} table { border-collapse: collapse; }
.${e} table td, .${e} table th { vertical-align: top; }
.${e} p { margin: 0pt; min-height: 1em; }
.${e} span { white-space: pre-wrap; overflow-wrap: break-word; }
.${e} a { color: inherit; text-decoration: inherit; }
.${e} svg { fill: transparent; }
`;
    return this.options.renderComments && (t += `
.${e}-comment-ref { cursor: default; }
.${e}-comment-popover { display: none; z-index: 1000; padding: 0.5rem; background: white; position: absolute; box-shadow: 0 0 0.25rem rgba(0, 0, 0, 0.25); width: 30ch; }
.${e}-comment-ref:hover~.${e}-comment-popover { display: block; }
.${e}-comment-author,.${e}-comment-date { font-size: 0.875rem; color: #888; }
`), B(t);
  }
  renderNumbering(e, t) {
    var r = "", s = [];
    for (var n of e) {
      var o = `p.${this.numberingClass(n.id, n.level)}`, h = "none";
      if (n.bullet) {
        let u = `--${this.className}-${n.bullet.src}`.toLowerCase();
        r += this.styleToString(`${o}:before`, {
          content: "' '",
          display: "inline-block",
          background: `var(${u})`
        }, n.bullet.style), this.tasks.push(this.document.loadNumberingImage(n.bullet.src).then((k) => {
          var b = `${this.rootSelector} { ${u}: url(${k}) }`;
          t.appendChild(B(b));
        }));
      } else if (n.levelText) {
        let u = this.numberingCounter(n.id, n.level);
        const k = u + " " + (n.start - 1);
        n.level > 0 && (r += this.styleToString(`p.${this.numberingClass(n.id, n.level - 1)}`, {
          "counter-reset": k
        })), s.push(k), r += this.styleToString(`${o}:before`, {
          content: this.levelTextToContent(n.levelText, n.suff, n.id, this.numFormatToCssValue(n.format)),
          "counter-increment": u,
          ...n.rStyle
        });
      } else
        h = this.numFormatToCssValue(n.format);
      r += this.styleToString(o, {
        display: "list-item",
        "list-style-position": "inside",
        "list-style-type": h,
        ...n.pStyle
      });
    }
    return s.length > 0 && (r += this.styleToString(this.rootSelector, {
      "counter-reset": s.join(" ")
    })), B(r);
  }
  renderStyles(e) {
    var t = "";
    const r = this.styleMap, s = x(e.filter((u) => u.isDefault), (u) => u.target);
    for (const u of e) {
      var n = u.styles;
      if (u.linked) {
        var o = u.linked && r[u.linked];
        o ? n = n.concat(o.styles) : this.options.debug && console.warn(`Can't find linked style ${u.linked}`);
      }
      for (const k of n) {
        var h = `${u.target ?? ""}.${u.cssName}`;
        u.target != k.target && (h += ` ${k.target}`), s[u.target] == u && (h = `.${this.className} ${u.target}, ` + h), t += this.styleToString(h, k.values);
      }
    }
    return B(t);
  }
  renderNotes(e, t, r) {
    var s = e.map((o) => t[o]).filter((o) => o);
    if (s.length > 0) {
      var n = this.createElement("ol", null, this.renderElements(s));
      r.appendChild(n);
    }
  }
  renderElement(e) {
    switch (e.type) {
      case l.Paragraph:
        return this.renderParagraph(e);
      case l.BookmarkStart:
        return this.renderBookmarkStart(e);
      case l.BookmarkEnd:
        return null;
      case l.Run:
        return this.renderRun(e);
      case l.Table:
        return this.renderTable(e);
      case l.Row:
        return this.renderTableRow(e);
      case l.Cell:
        return this.renderTableCell(e);
      case l.Hyperlink:
        return this.renderHyperlink(e);
      case l.SmartTag:
        return this.renderSmartTag(e);
      case l.Drawing:
        return this.renderDrawing(e);
      case l.Image:
        return this.renderImage(e);
      case l.Text:
        return this.renderText(e);
      case l.Text:
        return this.renderText(e);
      case l.DeletedText:
        return this.renderDeletedText(e);
      case l.Tab:
        return this.renderTab(e);
      case l.Symbol:
        return this.renderSymbol(e);
      case l.Break:
        return this.renderBreak(e);
      case l.Footer:
        return this.renderContainer(e, "footer");
      case l.Header:
        return this.renderContainer(e, "header");
      case l.Footnote:
      case l.Endnote:
        return this.renderContainer(e, "li");
      case l.FootnoteReference:
        return this.renderFootnoteReference(e);
      case l.EndnoteReference:
        return this.renderEndnoteReference(e);
      case l.NoBreakHyphen:
        return this.createElement("wbr");
      case l.VmlPicture:
        return this.renderVmlPicture(e);
      case l.VmlElement:
        return this.renderVmlElement(e);
      case l.MmlMath:
        return this.renderContainerNS(e, d.mathML, "math", { xmlns: d.mathML });
      case l.MmlMathParagraph:
        return this.renderContainer(e, "span");
      case l.MmlFraction:
        return this.renderContainerNS(e, d.mathML, "mfrac");
      case l.MmlBase:
        return this.renderContainerNS(e, d.mathML, e.parent.type == l.MmlMatrixRow ? "mtd" : "mrow");
      case l.MmlNumerator:
      case l.MmlDenominator:
      case l.MmlFunction:
      case l.MmlLimit:
      case l.MmlBox:
        return this.renderContainerNS(e, d.mathML, "mrow");
      case l.MmlGroupChar:
        return this.renderMmlGroupChar(e);
      case l.MmlLimitLower:
        return this.renderContainerNS(e, d.mathML, "munder");
      case l.MmlMatrix:
        return this.renderContainerNS(e, d.mathML, "mtable");
      case l.MmlMatrixRow:
        return this.renderContainerNS(e, d.mathML, "mtr");
      case l.MmlRadical:
        return this.renderMmlRadical(e);
      case l.MmlSuperscript:
        return this.renderContainerNS(e, d.mathML, "msup");
      case l.MmlSubscript:
        return this.renderContainerNS(e, d.mathML, "msub");
      case l.MmlDegree:
      case l.MmlSuperArgument:
      case l.MmlSubArgument:
        return this.renderContainerNS(e, d.mathML, "mn");
      case l.MmlFunctionName:
        return this.renderContainerNS(e, d.mathML, "ms");
      case l.MmlDelimiter:
        return this.renderMmlDelimiter(e);
      case l.MmlRun:
        return this.renderMmlRun(e);
      case l.MmlNary:
        return this.renderMmlNary(e);
      case l.MmlPreSubSuper:
        return this.renderMmlPreSubSuper(e);
      case l.MmlBar:
        return this.renderMmlBar(e);
      case l.MmlEquationArray:
        return this.renderMllList(e);
      case l.Inserted:
        return this.renderInserted(e);
      case l.Deleted:
        return this.renderDeleted(e);
      case l.CommentRangeStart:
        return this.renderCommentRangeStart(e);
      case l.CommentRangeEnd:
        return this.renderCommentRangeEnd(e);
      case l.CommentReference:
        return this.renderCommentReference(e);
    }
    return null;
  }
  renderChildren(e, t) {
    return this.renderElements(e.children, t);
  }
  renderElements(e, t) {
    if (e == null)
      return null;
    var r = e.flatMap((s) => this.renderElement(s)).filter((s) => s != null);
    return t && Me(t, r), r;
  }
  renderContainer(e, t, r) {
    return this.createElement(t, r, this.renderChildren(e));
  }
  renderContainerNS(e, t, r, s) {
    return g(t, r, s, this.renderChildren(e));
  }
  renderParagraph(e) {
    var n, o;
    var t = this.createElement("p");
    const r = this.findStyle(e.styleName);
    e.tabs ?? (e.tabs = (n = r == null ? void 0 : r.paragraphProps) == null ? void 0 : n.tabs), this.renderClass(e, t), this.renderChildren(e, t), this.renderStyleValues(e.cssStyle, t), this.renderCommonProperties(t.style, e);
    const s = e.numbering ?? ((o = r == null ? void 0 : r.paragraphProps) == null ? void 0 : o.numbering);
    return s && t.classList.add(this.numberingClass(s.id, s.level)), t;
  }
  renderRunProperties(e, t) {
    this.renderCommonProperties(e, t);
  }
  renderCommonProperties(e, t) {
    t != null && (t.color && (e.color = t.color), t.fontSize && (e["font-size"] = t.fontSize));
  }
  renderHyperlink(e) {
    var t = this.createElement("a");
    if (this.renderChildren(e, t), this.renderStyleValues(e.cssStyle, t), e.href)
      t.href = e.href;
    else if (e.id) {
      const r = this.document.documentPart.rels.find((s) => s.id == e.id && s.targetMode === "External");
      t.href = r == null ? void 0 : r.target;
    }
    return t;
  }
  renderSmartTag(e) {
    var t = this.createElement("span");
    return this.renderChildren(e, t), t;
  }
  renderCommentRangeStart(e) {
    var s;
    if (!this.options.renderComments)
      return null;
    const t = new Range();
    (s = this.commentHighlight) == null || s.add(t);
    const r = this.htmlDocument.createComment(`start of comment #${e.id}`);
    return this.later(() => t.setStart(r, 0)), this.commentMap[e.id] = t, r;
  }
  renderCommentRangeEnd(e) {
    if (!this.options.renderComments)
      return null;
    const t = this.commentMap[e.id], r = this.htmlDocument.createComment(`end of comment #${e.id}`);
    return this.later(() => t == null ? void 0 : t.setEnd(r, 0)), r;
  }
  renderCommentReference(e) {
    var o;
    if (!this.options.renderComments)
      return null;
    var t = (o = this.document.commentsPart) == null ? void 0 : o.commentMap[e.id];
    if (!t)
      return null;
    const r = new DocumentFragment(), s = R("span", { className: `${this.className}-comment-ref` }, ["💬"]), n = R("div", { className: `${this.className}-comment-popover` });
    return this.renderCommentContent(t, n), r.appendChild(this.htmlDocument.createComment(`comment #${t.id} by ${t.author} on ${t.date}`)), r.appendChild(s), r.appendChild(n), r;
  }
  renderCommentContent(e, t) {
    t.appendChild(R("div", { className: `${this.className}-comment-author` }, [e.author])), t.appendChild(R("div", { className: `${this.className}-comment-date` }, [new Date(e.date).toLocaleString()])), this.renderChildren(e, t);
  }
  renderDrawing(e) {
    var t = this.createElement("div");
    return t.style.display = "inline-block", t.style.position = "relative", t.style.textIndent = "0px", this.renderChildren(e, t), this.renderStyleValues(e.cssStyle, t), t;
  }
  renderImage(e) {
    let t = this.createElement("img");
    return this.renderStyleValues(e.cssStyle, t), this.document && this.tasks.push(this.document.loadDocumentImage(e.src, this.currentPart).then((r) => {
      t.src = r;
    })), t;
  }
  renderText(e) {
    return this.htmlDocument.createTextNode(e.text);
  }
  renderDeletedText(e) {
    return this.options.renderEndnotes ? this.htmlDocument.createTextNode(e.text) : null;
  }
  renderBreak(e) {
    return e.break == "textWrapping" ? this.createElement("br") : null;
  }
  renderInserted(e) {
    return this.options.renderChanges ? this.renderContainer(e, "ins") : this.renderChildren(e);
  }
  renderDeleted(e) {
    return this.options.renderChanges ? this.renderContainer(e, "del") : null;
  }
  renderSymbol(e) {
    var t = this.createElement("span");
    return t.style.fontFamily = e.font, t.innerHTML = `&#x${e.char};`, t;
  }
  renderFootnoteReference(e) {
    var t = this.createElement("sup");
    return this.currentFootnoteIds.push(e.id), t.textContent = `${this.currentFootnoteIds.length}`, t;
  }
  renderEndnoteReference(e) {
    var t = this.createElement("sup");
    return this.currentEndnoteIds.push(e.id), t.textContent = `${this.currentEndnoteIds.length}`, t;
  }
  renderTab(e) {
    var s;
    var t = this.createElement("span");
    if (t.innerHTML = "&emsp;", this.options.experimental) {
      t.className = this.tabStopClass();
      var r = (s = wr(e, l.Paragraph)) == null ? void 0 : s.tabs;
      this.currentTabs.push({ stops: r, span: t });
    }
    return t;
  }
  renderBookmarkStart(e) {
    var t = this.createElement("span");
    return t.id = e.name, t;
  }
  renderRun(e) {
    if (e.fieldRun)
      return null;
    const t = this.createElement("span");
    if (e.id && (t.id = e.id), this.renderClass(e, t), this.renderStyleValues(e.cssStyle, t), e.verticalAlign) {
      const r = this.createElement(e.verticalAlign);
      this.renderChildren(e, r), t.appendChild(r);
    } else
      this.renderChildren(e, t);
    return t;
  }
  renderTable(e) {
    let t = this.createElement("table");
    return this.tableCellPositions.push(this.currentCellPosition), this.tableVerticalMerges.push(this.currentVerticalMerge), this.currentVerticalMerge = {}, this.currentCellPosition = { col: 0, row: 0 }, e.columns && t.appendChild(this.renderTableColumns(e.columns)), this.renderClass(e, t), this.renderChildren(e, t), this.renderStyleValues(e.cssStyle, t), this.currentVerticalMerge = this.tableVerticalMerges.pop(), this.currentCellPosition = this.tableCellPositions.pop(), t;
  }
  renderTableColumns(e) {
    let t = this.createElement("colgroup");
    for (let r of e) {
      let s = this.createElement("col");
      r.width && (s.style.width = r.width), t.appendChild(s);
    }
    return t;
  }
  renderTableRow(e) {
    let t = this.createElement("tr");
    return this.currentCellPosition.col = 0, this.renderClass(e, t), this.renderChildren(e, t), this.renderStyleValues(e.cssStyle, t), this.currentCellPosition.row++, t;
  }
  renderTableCell(e) {
    let t = this.createElement("td");
    const r = this.currentCellPosition.col;
    return e.verticalMerge ? e.verticalMerge == "restart" ? (this.currentVerticalMerge[r] = t, t.rowSpan = 1) : this.currentVerticalMerge[r] && (this.currentVerticalMerge[r].rowSpan += 1, t.style.display = "none") : this.currentVerticalMerge[r] = null, this.renderClass(e, t), this.renderChildren(e, t), this.renderStyleValues(e.cssStyle, t), e.span && (t.colSpan = e.span), this.currentCellPosition.col += t.colSpan, t;
  }
  renderVmlPicture(e) {
    var t = R("div");
    return this.renderChildren(e, t), t;
  }
  renderVmlElement(e) {
    var s, n;
    var t = bt("svg");
    t.setAttribute("style", e.cssStyleText);
    const r = this.renderVmlChildElement(e);
    return (s = e.imageHref) != null && s.id && this.tasks.push((n = this.document) == null ? void 0 : n.loadDocumentImage(e.imageHref.id, this.currentPart).then((o) => r.setAttribute("href", o))), t.appendChild(r), requestAnimationFrame(() => {
      const o = t.firstElementChild.getBBox();
      t.setAttribute("width", `${Math.ceil(o.x + o.width)}`), t.setAttribute("height", `${Math.ceil(o.y + o.height)}`);
    }), t;
  }
  renderVmlChildElement(e) {
    const t = bt(e.tagName);
    Object.entries(e.attrs).forEach(([r, s]) => t.setAttribute(r, s));
    for (let r of e.children)
      r.type == l.VmlElement ? t.appendChild(this.renderVmlChildElement(r)) : t.appendChild(...F(this.renderElement(r)));
    return t;
  }
  renderMmlRadical(e) {
    var s;
    const t = e.children.find((n) => n.type == l.MmlBase);
    if ((s = e.props) != null && s.hideDegree)
      return g(d.mathML, "msqrt", null, this.renderElements([t]));
    const r = e.children.find((n) => n.type == l.MmlDegree);
    return g(d.mathML, "mroot", null, this.renderElements([t, r]));
  }
  renderMmlDelimiter(e) {
    const t = [];
    return t.push(g(d.mathML, "mo", null, [e.props.beginChar ?? "("])), t.push(...this.renderElements(e.children)), t.push(g(d.mathML, "mo", null, [e.props.endChar ?? ")"])), g(d.mathML, "mrow", null, t);
  }
  renderMmlNary(e) {
    var k;
    const t = [], r = x(e.children, (b) => b.type), s = r[l.MmlSuperArgument], n = r[l.MmlSubArgument], o = s ? g(d.mathML, "mo", null, F(this.renderElement(s))) : null, h = n ? g(d.mathML, "mo", null, F(this.renderElement(n))) : null, u = g(d.mathML, "mo", null, [((k = e.props) == null ? void 0 : k.char) ?? "∫"]);
    return o || h ? t.push(g(d.mathML, "munderover", null, [u, h, o])) : o ? t.push(g(d.mathML, "mover", null, [u, o])) : h ? t.push(g(d.mathML, "munder", null, [u, h])) : t.push(u), t.push(...this.renderElements(r[l.MmlBase].children)), g(d.mathML, "mrow", null, t);
  }
  renderMmlPreSubSuper(e) {
    const t = [], r = x(e.children, (k) => k.type), s = r[l.MmlSuperArgument], n = r[l.MmlSubArgument], o = s ? g(d.mathML, "mo", null, F(this.renderElement(s))) : null, h = n ? g(d.mathML, "mo", null, F(this.renderElement(n))) : null, u = g(d.mathML, "mo", null);
    return t.push(g(d.mathML, "msubsup", null, [u, h, o])), t.push(...this.renderElements(r[l.MmlBase].children)), g(d.mathML, "mrow", null, t);
  }
  renderMmlGroupChar(e) {
    const t = e.props.verticalJustification === "bot" ? "mover" : "munder", r = this.renderContainerNS(e, d.mathML, t);
    return e.props.char && r.appendChild(g(d.mathML, "mo", null, [e.props.char])), r;
  }
  renderMmlBar(e) {
    const t = this.renderContainerNS(e, d.mathML, "mrow");
    switch (e.props.position) {
      case "top":
        t.style.textDecoration = "overline";
        break;
      case "bottom":
        t.style.textDecoration = "underline";
        break;
    }
    return t;
  }
  renderMmlRun(e) {
    const t = g(d.mathML, "ms");
    return this.renderClass(e, t), this.renderStyleValues(e.cssStyle, t), this.renderChildren(e, t), t;
  }
  renderMllList(e) {
    const t = g(d.mathML, "mtable");
    this.renderClass(e, t), this.renderStyleValues(e.cssStyle, t), this.renderChildren(e);
    for (let r of this.renderChildren(e))
      t.appendChild(g(d.mathML, "mtr", null, [
        g(d.mathML, "mtd", null, [r])
      ]));
    return t;
  }
  renderStyleValues(e, t) {
    for (let r in e)
      r.startsWith("$") ? t.setAttribute(r.slice(1), e[r]) : t.style[r] = e[r];
  }
  renderClass(e, t) {
    e.className && (t.className = e.className), e.styleName && t.classList.add(this.processStyleName(e.styleName));
  }
  findStyle(e) {
    var t;
    return e && ((t = this.styleMap) == null ? void 0 : t[e]);
  }
  numberingClass(e, t) {
    return `${this.className}-num-${e}-${t}`;
  }
  tabStopClass() {
    return `${this.className}-tab-stop`;
  }
  styleToString(e, t, r = null) {
    let s = `${e} {\r
`;
    for (const n in t)
      n.startsWith("$") || (s += `  ${n}: ${t[n]};\r
`);
    return r && (s += r), s + `}\r
`;
  }
  numberingCounter(e, t) {
    return `${this.className}-num-${e}-${t}`;
  }
  levelTextToContent(e, t, r, s) {
    const n = {
      tab: "\\9",
      space: "\\a0"
    };
    var o = e.replace(/%\d*/g, (h) => {
      let u = parseInt(h.substring(1), 10) - 1;
      return `"counter(${this.numberingCounter(r, u)}, ${s})"`;
    });
    return `"${o}${n[t] ?? ""}"`;
  }
  numFormatToCssValue(e) {
    var t = {
      none: "none",
      bullet: "disc",
      decimal: "decimal",
      lowerLetter: "lower-alpha",
      upperLetter: "upper-alpha",
      lowerRoman: "lower-roman",
      upperRoman: "upper-roman",
      decimalZero: "decimal-leading-zero",
      aiueo: "katakana",
      aiueoFullWidth: "katakana",
      chineseCounting: "simp-chinese-informal",
      chineseCountingThousand: "simp-chinese-informal",
      chineseLegalSimplified: "simp-chinese-formal",
      chosung: "hangul-consonant",
      ideographDigital: "cjk-ideographic",
      ideographTraditional: "cjk-heavenly-stem",
      ideographLegalTraditional: "trad-chinese-formal",
      ideographZodiac: "cjk-earthly-branch",
      iroha: "katakana-iroha",
      irohaFullWidth: "katakana-iroha",
      japaneseCounting: "japanese-informal",
      japaneseDigitalTenThousand: "cjk-decimal",
      japaneseLegal: "japanese-formal",
      thaiNumbers: "thai",
      koreanCounting: "korean-hangul-formal",
      koreanDigital: "korean-hangul-formal",
      koreanDigital2: "korean-hanja-informal",
      hebrew1: "hebrew",
      hebrew2: "hebrew",
      hindiNumbers: "devanagari",
      ganada: "hangul",
      taiwaneseCounting: "cjk-ideographic",
      taiwaneseCountingThousand: "cjk-ideographic",
      taiwaneseDigital: "cjk-decimal"
    };
    return t[e] ?? e;
  }
  refreshTabStops() {
    this.options.experimental && (clearTimeout(this.tabsTimeout), this.tabsTimeout = setTimeout(() => {
      const e = yr();
      for (let t of this.currentTabs)
        Sr(t.span, t.stops, this.defaultTabSize, e);
    }, 500));
  }
  later(e) {
    this.postRenderTasks.push(e);
  }
};
c(lt, "HtmlRenderer");
let Ce = lt;
function R(a, e, t) {
  return g(void 0, a, e, t);
}
c(R, "createElement");
function bt(a, e, t) {
  return g(d.svg, a, e, t);
}
c(bt, "createSvgElement");
function g(a, e, t, r) {
  var s = a ? document.createElementNS(a, e) : document.createElement(e);
  return Object.assign(s, t), r && Me(s, r), s;
}
c(g, "createElementNS");
function kt(a) {
  a.innerHTML = "";
}
c(kt, "removeAllElements");
function Me(a, e) {
  e.forEach((t) => a.appendChild(Xt(t) ? document.createTextNode(t) : t));
}
c(Me, "appendChildren");
function B(a) {
  return R("style", { innerHTML: a });
}
c(B, "createStyleElement");
function T(a, e) {
  a.appendChild(document.createComment(e));
}
c(T, "appendComment");
function wr(a, e) {
  for (var t = a.parent; t != null && t.type != e; )
    t = t.parent;
  return t;
}
c(wr, "findParent");
const At = {
  ignoreHeight: !1,
  ignoreWidth: !1,
  ignoreFonts: !1,
  breakPages: !0,
  debug: !1,
  experimental: !1,
  className: "docx",
  inWrapper: !0,
  trimXmlDeclaration: !0,
  ignoreLastRenderedPageBreak: !0,
  renderHeaders: !0,
  renderFooters: !0,
  renderFootnotes: !0,
  renderEndnotes: !0,
  useBase64URL: !1,
  renderChanges: !1,
  renderComments: !1
};
function Pr(a, e) {
  const t = { ...At, ...e };
  return be.load(a, new Pe(t), t);
}
c(Pr, "parseAsync");
async function Cr(a, e, t, r) {
  const s = { ...At, ...r }, n = new Ce(window.document);
  return n.render(a, e, t, s), Promise.allSettled(n.tasks);
}
c(Cr, "renderDocument");
async function Ar(a, e, t, r) {
  const s = await Pr(a, r);
  return await Cr(s, e, t, r), s;
}
c(Ar, "renderAsync");
export {
  At as defaultOptions,
  Pr as parseAsync,
  Ar as renderAsync,
  Cr as renderDocument
};
