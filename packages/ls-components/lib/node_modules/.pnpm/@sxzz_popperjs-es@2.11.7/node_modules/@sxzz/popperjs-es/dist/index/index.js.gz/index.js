var ht = Object.defineProperty;
var s = (t, e) => ht(t, "name", { value: e, configurable: !0 });
var k = "top", S = "bottom", M = "right", B = "left", Ee = "auto", ce = [k, S, M, B], Z = "start", se = "end", vt = "clippingParents", Ye = "viewport", oe = "popper", gt = "reference", Ie = ce.reduce(function(t, e) {
  return t.concat([e + "-" + Z, e + "-" + se]);
}, []), $e = [].concat(ce, [Ee]).reduce(function(t, e) {
  return t.concat([e, e + "-" + Z, e + "-" + se]);
}, []), yt = "beforeRead", bt = "read", xt = "afterRead", wt = "beforeMain", Ot = "main", jt = "afterMain", Et = "beforeWrite", At = "write", Dt = "afterWrite", Pt = [yt, bt, xt, wt, Ot, jt, Et, At, Dt];
function V(t) {
  return t ? (t.nodeName || "").toLowerCase() : null;
}
s(V, "C");
function N(t) {
  if (t == null) return window;
  if (t.toString() !== "[object Window]") {
    var e = t.ownerDocument;
    return e && e.defaultView || window;
  }
  return t;
}
s(N, "H");
function Y(t) {
  var e = N(t).Element;
  return t instanceof e || t instanceof Element;
}
s(Y, "Q");
function L(t) {
  var e = N(t).HTMLElement;
  return t instanceof e || t instanceof HTMLElement;
}
s(L, "B");
function Ae(t) {
  if (typeof ShadowRoot > "u") return !1;
  var e = N(t).ShadowRoot;
  return t instanceof e || t instanceof ShadowRoot;
}
s(Ae, "Pe");
function Wt(t) {
  var e = t.state;
  Object.keys(e.elements).forEach(function(n) {
    var r = e.styles[n] || {}, o = e.attributes[n] || {}, i = e.elements[n];
    !L(i) || !V(i) || (Object.assign(i.style, r), Object.keys(o).forEach(function(a) {
      var f = o[a];
      f === !1 ? i.removeAttribute(a) : i.setAttribute(a, f === !0 ? "" : f);
    }));
  });
}
s(Wt, "Mt");
function kt(t) {
  var e = t.state, n = { popper: { position: e.options.strategy, left: "0", top: "0", margin: "0" }, arrow: { position: "absolute" }, reference: {} };
  return Object.assign(e.elements.popper.style, n.popper), e.styles = n, e.elements.arrow && Object.assign(e.elements.arrow.style, n.arrow), function() {
    Object.keys(e.elements).forEach(function(r) {
      var o = e.elements[r], i = e.attributes[r] || {}, a = Object.keys(e.styles.hasOwnProperty(r) ? e.styles[r] : n[r]), f = a.reduce(function(c, p) {
        return c[p] = "", c;
      }, {});
      !L(o) || !V(o) || (Object.assign(o.style, f), Object.keys(i).forEach(function(c) {
        o.removeAttribute(c);
      }));
    });
  };
}
s(kt, "Rt");
var _e = { name: "applyStyles", enabled: !0, phase: "write", fn: Wt, effect: kt, requires: ["computeStyles"] };
function T(t) {
  return t.split("-")[0];
}
s(T, "q");
var K = Math.max, ye = Math.min, $ = Math.round;
function _(t, e) {
  e === void 0 && (e = !1);
  var n = t.getBoundingClientRect(), r = 1, o = 1;
  if (L(t) && e) {
    var i = t.offsetHeight, a = t.offsetWidth;
    a > 0 && (r = $(n.width) / a || 1), i > 0 && (o = $(n.height) / i || 1);
  }
  return { width: n.width / r, height: n.height / o, top: n.top / o, right: n.right / r, bottom: n.bottom / o, left: n.left / r, x: n.left / r, y: n.top / o };
}
s(_, "ee");
function De(t) {
  var e = _(t), n = t.offsetWidth, r = t.offsetHeight;
  return Math.abs(e.width - n) <= 1 && (n = e.width), Math.abs(e.height - r) <= 1 && (r = e.height), { x: t.offsetLeft, y: t.offsetTop, width: n, height: r };
}
s(De, "ke");
function Fe(t, e) {
  var n = e.getRootNode && e.getRootNode();
  if (t.contains(e)) return !0;
  if (n && Ae(n)) {
    var r = e;
    do {
      if (r && t.isSameNode(r)) return !0;
      r = r.parentNode || r.host;
    } while (r);
  }
  return !1;
}
s(Fe, "it");
function U(t) {
  return N(t).getComputedStyle(t);
}
s(U, "N");
function Bt(t) {
  return ["table", "td", "th"].indexOf(V(t)) >= 0;
}
s(Bt, "Wt");
function X(t) {
  return ((Y(t) ? t.ownerDocument : t.document) || window.document).documentElement;
}
s(X, "I");
function be(t) {
  return V(t) === "html" ? t : t.assignedSlot || t.parentNode || (Ae(t) ? t.host : null) || X(t);
}
s(be, "ge");
function Ue(t) {
  return !L(t) || U(t).position === "fixed" ? null : t.offsetParent;
}
s(Ue, "at");
function Rt(t) {
  var e = navigator.userAgent.toLowerCase().indexOf("firefox") !== -1, n = navigator.userAgent.indexOf("Trident") !== -1;
  if (n && L(t)) {
    var r = U(t);
    if (r.position === "fixed") return null;
  }
  var o = be(t);
  for (Ae(o) && (o = o.host); L(o) && ["html", "body"].indexOf(V(o)) < 0; ) {
    var i = U(o);
    if (i.transform !== "none" || i.perspective !== "none" || i.contain === "paint" || ["transform", "perspective"].indexOf(i.willChange) !== -1 || e && i.willChange === "filter" || e && i.filter && i.filter !== "none") return o;
    o = o.parentNode;
  }
  return null;
}
s(Rt, "Bt");
function pe(t) {
  for (var e = N(t), n = Ue(t); n && Bt(n) && U(n).position === "static"; ) n = Ue(n);
  return n && (V(n) === "html" || V(n) === "body" && U(n).position === "static") ? e : n || Rt(t) || e;
}
s(pe, "se");
function Pe(t) {
  return ["top", "bottom"].indexOf(t) >= 0 ? "x" : "y";
}
s(Pe, "Le");
function ie(t, e, n) {
  return K(t, ye(e, n));
}
s(ie, "fe");
function Ht(t, e, n) {
  var r = ie(t, e, n);
  return r > n ? n : r;
}
s(Ht, "St");
function et() {
  return { top: 0, right: 0, bottom: 0, left: 0 };
}
s(et, "st");
function tt(t) {
  return Object.assign({}, et(), t);
}
s(tt, "ft");
function nt(t, e) {
  return e.reduce(function(n, r) {
    return n[r] = t, n;
  }, {});
}
s(nt, "ct");
var Lt = /* @__PURE__ */ s(function(t, e) {
  return t = typeof t == "function" ? t(Object.assign({}, e.rects, { placement: e.placement })) : t, tt(typeof t != "number" ? t : nt(t, ce));
}, "Tt");
function St(t) {
  var e, n = t.state, r = t.name, o = t.options, i = n.elements.arrow, a = n.modifiersData.popperOffsets, f = T(n.placement), c = Pe(f), p = [B, M].indexOf(f) >= 0, l = p ? "height" : "width";
  if (!(!i || !a)) {
    var v = Lt(o.padding, n), g = De(i), d = c === "y" ? k : B, h = c === "y" ? S : M, u = n.rects.reference[l] + n.rects.reference[c] - a[c] - n.rects.popper[l], y = a[c] - n.rects.reference[c], O = pe(i), b = O ? c === "y" ? O.clientHeight || 0 : O.clientWidth || 0 : 0, E = u / 2 - y / 2, m = v[d], x = b - g[l] - v[h], w = b / 2 - g[l] / 2 + E, j = ie(m, w, x), A = c;
    n.modifiersData[r] = (e = {}, e[A] = j, e.centerOffset = j - w, e);
  }
}
s(St, "Ht");
function Mt(t) {
  var e = t.state, n = t.options, r = n.element, o = r === void 0 ? "[data-popper-arrow]" : r;
  o != null && (typeof o == "string" && (o = e.elements.popper.querySelector(o), !o) || !Fe(e.elements.popper, o) || (e.elements.arrow = o));
}
s(Mt, "Ct");
var Ct = { name: "arrow", enabled: !0, phase: "main", fn: St, effect: Mt, requires: ["popperOffsets"], requiresIfExists: ["preventOverflow"] };
function F(t) {
  return t.split("-")[1];
}
s(F, "te");
var qt = { top: "auto", right: "auto", bottom: "auto", left: "auto" };
function Nt(t) {
  var e = t.x, n = t.y, r = window, o = r.devicePixelRatio || 1;
  return { x: $(e * o) / o || 0, y: $(n * o) / o || 0 };
}
s(Nt, "Vt");
function Xe(t) {
  var e, n = t.popper, r = t.popperRect, o = t.placement, i = t.variation, a = t.offsets, f = t.position, c = t.gpuAcceleration, p = t.adaptive, l = t.roundOffsets, v = t.isFixed, g = a.x, d = g === void 0 ? 0 : g, h = a.y, u = h === void 0 ? 0 : h, y = typeof l == "function" ? l({ x: d, y: u }) : { x: d, y: u };
  d = y.x, u = y.y;
  var O = a.hasOwnProperty("x"), b = a.hasOwnProperty("y"), E = B, m = k, x = window;
  if (p) {
    var w = pe(n), j = "clientHeight", A = "clientWidth";
    if (w === N(n) && (w = X(n), U(w).position !== "static" && f === "absolute" && (j = "scrollHeight", A = "scrollWidth")), w = w, o === k || (o === B || o === M) && i === se) {
      m = S;
      var P = v && w === x && x.visualViewport ? x.visualViewport.height : w[j];
      u -= P - r.height, u *= c ? 1 : -1;
    }
    if (o === B || (o === k || o === S) && i === se) {
      E = M;
      var W = v && w === x && x.visualViewport ? x.visualViewport.width : w[A];
      d -= W - r.width, d *= c ? 1 : -1;
    }
  }
  var D = Object.assign({ position: f }, p && qt), C = l === !0 ? Nt({ x: d, y: u }) : { x: d, y: u };
  if (d = C.x, u = C.y, c) {
    var R;
    return Object.assign({}, D, (R = {}, R[m] = b ? "0" : "", R[E] = O ? "0" : "", R.transform = (x.devicePixelRatio || 1) <= 1 ? "translate(" + d + "px, " + u + "px)" : "translate3d(" + d + "px, " + u + "px, 0)", R));
  }
  return Object.assign({}, D, (e = {}, e[m] = b ? u + "px" : "", e[E] = O ? d + "px" : "", e.transform = "", e));
}
s(Xe, "ut");
function Tt(t) {
  var e = t.state, n = t.options, r = n.gpuAcceleration, o = r === void 0 ? !0 : r, i = n.adaptive, a = i === void 0 ? !0 : i, f = n.roundOffsets, c = f === void 0 ? !0 : f, p = { placement: T(e.placement), variation: F(e.placement), popper: e.elements.popper, popperRect: e.rects.popper, gpuAcceleration: o, isFixed: e.options.strategy === "fixed" };
  e.modifiersData.popperOffsets != null && (e.styles.popper = Object.assign({}, e.styles.popper, Xe(Object.assign({}, p, { offsets: e.modifiersData.popperOffsets, position: e.options.strategy, adaptive: a, roundOffsets: c })))), e.modifiersData.arrow != null && (e.styles.arrow = Object.assign({}, e.styles.arrow, Xe(Object.assign({}, p, { offsets: e.modifiersData.arrow, position: "absolute", adaptive: !1, roundOffsets: c })))), e.attributes.popper = Object.assign({}, e.attributes.popper, { "data-popper-placement": e.placement });
}
s(Tt, "Nt");
var rt = { name: "computeStyles", enabled: !0, phase: "beforeWrite", fn: Tt, data: {} }, ve = { passive: !0 };
function Vt(t) {
  var e = t.state, n = t.instance, r = t.options, o = r.scroll, i = o === void 0 ? !0 : o, a = r.resize, f = a === void 0 ? !0 : a, c = N(e.elements.popper), p = [].concat(e.scrollParents.reference, e.scrollParents.popper);
  return i && p.forEach(function(l) {
    l.addEventListener("scroll", n.update, ve);
  }), f && c.addEventListener("resize", n.update, ve), function() {
    i && p.forEach(function(l) {
      l.removeEventListener("scroll", n.update, ve);
    }), f && c.removeEventListener("resize", n.update, ve);
  };
}
s(Vt, "It");
var ot = { name: "eventListeners", enabled: !0, phase: "write", fn: /* @__PURE__ */ s(function() {
}, "fn"), effect: Vt, data: {} }, It = { left: "right", right: "left", bottom: "top", top: "bottom" };
function ge(t) {
  return t.replace(/left|right|bottom|top/g, function(e) {
    return It[e];
  });
}
s(ge, "be");
var Ut = { start: "end", end: "start" };
function Ge(t) {
  return t.replace(/start|end/g, function(e) {
    return Ut[e];
  });
}
s(Ge, "lt");
function We(t) {
  var e = N(t), n = e.pageXOffset, r = e.pageYOffset;
  return { scrollLeft: n, scrollTop: r };
}
s(We, "We");
function ke(t) {
  return _(X(t)).left + We(t).scrollLeft;
}
s(ke, "Be");
function Xt(t) {
  var e = N(t), n = X(t), r = e.visualViewport, o = n.clientWidth, i = n.clientHeight, a = 0, f = 0;
  return r && (o = r.width, i = r.height, /^((?!chrome|android).)*safari/i.test(navigator.userAgent) || (a = r.offsetLeft, f = r.offsetTop)), { width: o, height: i, x: a + ke(t), y: f };
}
s(Xt, "Ft");
function Gt(t) {
  var e, n = X(t), r = We(t), o = (e = t.ownerDocument) == null ? void 0 : e.body, i = K(n.scrollWidth, n.clientWidth, o ? o.scrollWidth : 0, o ? o.clientWidth : 0), a = K(n.scrollHeight, n.clientHeight, o ? o.scrollHeight : 0, o ? o.clientHeight : 0), f = -r.scrollLeft + ke(t), c = -r.scrollTop;
  return U(o || n).direction === "rtl" && (f += K(n.clientWidth, o ? o.clientWidth : 0) - i), { width: i, height: a, x: f, y: c };
}
s(Gt, "Ut");
function Be(t) {
  var e = U(t), n = e.overflow, r = e.overflowX, o = e.overflowY;
  return /auto|scroll|overlay|hidden/.test(n + o + r);
}
s(Be, "Se");
function it(t) {
  return ["html", "body", "#document"].indexOf(V(t)) >= 0 ? t.ownerDocument.body : L(t) && Be(t) ? t : it(be(t));
}
s(it, "dt");
function ae(t, e) {
  var n;
  e === void 0 && (e = []);
  var r = it(t), o = r === ((n = t.ownerDocument) == null ? void 0 : n.body), i = N(r), a = o ? [i].concat(i.visualViewport || [], Be(r) ? r : []) : r, f = e.concat(a);
  return o ? f : f.concat(ae(be(a)));
}
s(ae, "ce");
function je(t) {
  return Object.assign({}, t, { left: t.x, top: t.y, right: t.x + t.width, bottom: t.y + t.height });
}
s(je, "Te");
function zt(t) {
  var e = _(t);
  return e.top = e.top + t.clientTop, e.left = e.left + t.clientLeft, e.bottom = e.top + t.clientHeight, e.right = e.left + t.clientWidth, e.width = t.clientWidth, e.height = t.clientHeight, e.x = e.left, e.y = e.top, e;
}
s(zt, "Xt");
function ze(t, e) {
  return e === Ye ? je(Xt(t)) : Y(e) ? zt(e) : je(Gt(X(t)));
}
s(ze, "ht");
function Jt(t) {
  var e = ae(be(t)), n = ["absolute", "fixed"].indexOf(U(t).position) >= 0, r = n && L(t) ? pe(t) : t;
  return Y(r) ? e.filter(function(o) {
    return Y(o) && Fe(o, r) && V(o) !== "body";
  }) : [];
}
s(Jt, "Yt");
function Kt(t, e, n) {
  var r = e === "clippingParents" ? Jt(t) : [].concat(e), o = [].concat(r, [n]), i = o[0], a = o.reduce(function(f, c) {
    var p = ze(t, c);
    return f.top = K(p.top, f.top), f.right = ye(p.right, f.right), f.bottom = ye(p.bottom, f.bottom), f.left = K(p.left, f.left), f;
  }, ze(t, i));
  return a.width = a.right - a.left, a.height = a.bottom - a.top, a.x = a.left, a.y = a.top, a;
}
s(Kt, "Gt");
function at(t) {
  var e = t.reference, n = t.element, r = t.placement, o = r ? T(r) : null, i = r ? F(r) : null, a = e.x + e.width / 2 - n.width / 2, f = e.y + e.height / 2 - n.height / 2, c;
  switch (o) {
    case k:
      c = { x: a, y: e.y - n.height };
      break;
    case S:
      c = { x: a, y: e.y + e.height };
      break;
    case M:
      c = { x: e.x + e.width, y: f };
      break;
    case B:
      c = { x: e.x - n.width, y: f };
      break;
    default:
      c = { x: e.x, y: e.y };
  }
  var p = o ? Pe(o) : null;
  if (p != null) {
    var l = p === "y" ? "height" : "width";
    switch (i) {
      case Z:
        c[p] = c[p] - (e[l] / 2 - n[l] / 2);
        break;
      case se:
        c[p] = c[p] + (e[l] / 2 - n[l] / 2);
        break;
    }
  }
  return c;
}
s(at, "mt");
function fe(t, e) {
  e === void 0 && (e = {});
  var n = e, r = n.placement, o = r === void 0 ? t.placement : r, i = n.boundary, a = i === void 0 ? vt : i, f = n.rootBoundary, c = f === void 0 ? Ye : f, p = n.elementContext, l = p === void 0 ? oe : p, v = n.altBoundary, g = v === void 0 ? !1 : v, d = n.padding, h = d === void 0 ? 0 : d, u = tt(typeof h != "number" ? h : nt(h, ce)), y = l === oe ? gt : oe, O = t.rects.popper, b = t.elements[g ? y : l], E = Kt(Y(b) ? b : b.contextElement || X(t.elements.popper), a, c), m = _(t.elements.reference), x = at({ reference: m, element: O, strategy: "absolute", placement: o }), w = je(Object.assign({}, O, x)), j = l === oe ? w : m, A = { top: E.top - j.top + u.top, bottom: j.bottom - E.bottom + u.bottom, left: E.left - j.left + u.left, right: j.right - E.right + u.right }, P = t.modifiersData.offset;
  if (l === oe && P) {
    var W = P[o];
    Object.keys(A).forEach(function(D) {
      var C = [M, S].indexOf(D) >= 0 ? 1 : -1, R = [k, S].indexOf(D) >= 0 ? "y" : "x";
      A[D] += W[R] * C;
    });
  }
  return A;
}
s(fe, "ne");
function Qt(t, e) {
  e === void 0 && (e = {});
  var n = e, r = n.placement, o = n.boundary, i = n.rootBoundary, a = n.padding, f = n.flipVariations, c = n.allowedAutoPlacements, p = c === void 0 ? $e : c, l = F(r), v = l ? f ? Ie : Ie.filter(function(h) {
    return F(h) === l;
  }) : ce, g = v.filter(function(h) {
    return p.indexOf(h) >= 0;
  });
  g.length === 0 && (g = v);
  var d = g.reduce(function(h, u) {
    return h[u] = fe(t, { placement: u, boundary: o, rootBoundary: i, padding: a })[T(u)], h;
  }, {});
  return Object.keys(d).sort(function(h, u) {
    return d[h] - d[u];
  });
}
s(Qt, "Jt");
function Zt(t) {
  if (T(t) === Ee) return [];
  var e = ge(t);
  return [Ge(t), e, Ge(e)];
}
s(Zt, "Kt");
function Yt(t) {
  var e = t.state, n = t.options, r = t.name;
  if (!e.modifiersData[r]._skip) {
    for (var o = n.mainAxis, i = o === void 0 ? !0 : o, a = n.altAxis, f = a === void 0 ? !0 : a, c = n.fallbackPlacements, p = n.padding, l = n.boundary, v = n.rootBoundary, g = n.altBoundary, d = n.flipVariations, h = d === void 0 ? !0 : d, u = n.allowedAutoPlacements, y = e.options.placement, O = T(y), b = O === y, E = c || (b || !h ? [ge(y)] : Zt(y)), m = [y].concat(E).reduce(function(z, I) {
      return z.concat(T(I) === Ee ? Qt(e, { placement: I, boundary: l, rootBoundary: v, padding: p, flipVariations: h, allowedAutoPlacements: u }) : I);
    }, []), x = e.rects.reference, w = e.rects.popper, j = /* @__PURE__ */ new Map(), A = !0, P = m[0], W = 0; W < m.length; W++) {
      var D = m[W], C = T(D), R = F(D) === Z, ee = [k, S].indexOf(C) >= 0, te = ee ? "width" : "height", H = fe(e, { placement: D, boundary: l, rootBoundary: v, altBoundary: g, padding: p }), q = ee ? R ? M : B : R ? S : k;
      x[te] > w[te] && (q = ge(q));
      var ue = ge(q), G = [];
      if (i && G.push(H[C] <= 0), f && G.push(H[q] <= 0, H[ue] <= 0), G.every(function(z) {
        return z;
      })) {
        P = D, A = !1;
        break;
      }
      j.set(D, G);
    }
    if (A) for (var le = h ? 3 : 1, xe = function(z) {
      var I = m.find(function(me) {
        var re = j.get(me);
        if (re) return re.slice(0, z).every(function(Q) {
          return Q;
        });
      });
      if (I) return P = I, "break";
    }, ne = le; ne > 0; ne--) {
      var de = xe(ne);
      if (de === "break") break;
    }
    e.placement !== P && (e.modifiersData[r]._skip = !0, e.placement = P, e.reset = !0);
  }
}
s(Yt, "Qt");
var $t = { name: "flip", enabled: !0, phase: "main", fn: Yt, requiresIfExists: ["offset"], data: { _skip: !1 } };
function Je(t, e, n) {
  return n === void 0 && (n = { x: 0, y: 0 }), { top: t.top - e.height - n.y, right: t.right - e.width + n.x, bottom: t.bottom - e.height + n.y, left: t.left - e.width - n.x };
}
s(Je, "gt");
function Ke(t) {
  return [k, M, S, B].some(function(e) {
    return t[e] >= 0;
  });
}
s(Ke, "yt");
function _t(t) {
  var e = t.state, n = t.name, r = e.rects.reference, o = e.rects.popper, i = e.modifiersData.preventOverflow, a = fe(e, { elementContext: "reference" }), f = fe(e, { altBoundary: !0 }), c = Je(a, r), p = Je(f, o, i), l = Ke(c), v = Ke(p);
  e.modifiersData[n] = { referenceClippingOffsets: c, popperEscapeOffsets: p, isReferenceHidden: l, hasPopperEscaped: v }, e.attributes.popper = Object.assign({}, e.attributes.popper, { "data-popper-reference-hidden": l, "data-popper-escaped": v });
}
s(_t, "Zt");
var Ft = { name: "hide", enabled: !0, phase: "main", requiresIfExists: ["preventOverflow"], fn: _t };
function en(t, e, n) {
  var r = T(t), o = [B, k].indexOf(r) >= 0 ? -1 : 1, i = typeof n == "function" ? n(Object.assign({}, e, { placement: t })) : n, a = i[0], f = i[1];
  return a = a || 0, f = (f || 0) * o, [B, M].indexOf(r) >= 0 ? { x: f, y: a } : { x: a, y: f };
}
s(en, "en");
function tn(t) {
  var e = t.state, n = t.options, r = t.name, o = n.offset, i = o === void 0 ? [0, 0] : o, a = $e.reduce(function(l, v) {
    return l[v] = en(v, e.rects, i), l;
  }, {}), f = a[e.placement], c = f.x, p = f.y;
  e.modifiersData.popperOffsets != null && (e.modifiersData.popperOffsets.x += c, e.modifiersData.popperOffsets.y += p), e.modifiersData[r] = a;
}
s(tn, "tn");
var nn = { name: "offset", enabled: !0, phase: "main", requires: ["popperOffsets"], fn: tn };
function rn(t) {
  var e = t.state, n = t.name;
  e.modifiersData[n] = at({ reference: e.rects.reference, element: e.rects.popper, strategy: "absolute", placement: e.placement });
}
s(rn, "nn");
var st = { name: "popperOffsets", enabled: !0, phase: "read", fn: rn, data: {} };
function on(t) {
  return t === "x" ? "y" : "x";
}
s(on, "rn");
function an(t) {
  var e = t.state, n = t.options, r = t.name, o = n.mainAxis, i = o === void 0 ? !0 : o, a = n.altAxis, f = a === void 0 ? !1 : a, c = n.boundary, p = n.rootBoundary, l = n.altBoundary, v = n.padding, g = n.tether, d = g === void 0 ? !0 : g, h = n.tetherOffset, u = h === void 0 ? 0 : h, y = fe(e, { boundary: c, rootBoundary: p, padding: v, altBoundary: l }), O = T(e.placement), b = F(e.placement), E = !b, m = Pe(O), x = on(m), w = e.modifiersData.popperOffsets, j = e.rects.reference, A = e.rects.popper, P = typeof u == "function" ? u(Object.assign({}, e.rects, { placement: e.placement })) : u, W = typeof P == "number" ? { mainAxis: P, altAxis: P } : Object.assign({ mainAxis: 0, altAxis: 0 }, P), D = e.modifiersData.offset ? e.modifiersData.offset[e.placement] : null, C = { x: 0, y: 0 };
  if (w) {
    if (i) {
      var R, ee = m === "y" ? k : B, te = m === "y" ? S : M, H = m === "y" ? "height" : "width", q = w[m], ue = q + y[ee], G = q - y[te], le = d ? -A[H] / 2 : 0, xe = b === Z ? j[H] : A[H], ne = b === Z ? -A[H] : -j[H], de = e.elements.arrow, z = d && de ? De(de) : { width: 0, height: 0 }, I = e.modifiersData["arrow#persistent"] ? e.modifiersData["arrow#persistent"].padding : et(), me = I[ee], re = I[te], Q = ie(0, j[H], z[H]), ft = E ? j[H] / 2 - le - Q - me - W.mainAxis : xe - Q - me - W.mainAxis, ct = E ? -j[H] / 2 + le + Q + re + W.mainAxis : ne + Q + re + W.mainAxis, we = e.elements.arrow && pe(e.elements.arrow), pt = we ? m === "y" ? we.clientTop || 0 : we.clientLeft || 0 : 0, He = (R = D == null ? void 0 : D[m]) != null ? R : 0, ut = q + ft - He - pt, lt = q + ct - He, Le = ie(d ? ye(ue, ut) : ue, q, d ? K(G, lt) : G);
      w[m] = Le, C[m] = Le - q;
    }
    if (f) {
      var Se, dt = m === "x" ? k : B, mt = m === "x" ? S : M, J = w[x], he = x === "y" ? "height" : "width", Me = J + y[dt], Ce = J - y[mt], Oe = [k, B].indexOf(O) !== -1, qe = (Se = D == null ? void 0 : D[x]) != null ? Se : 0, Ne = Oe ? Me : J - j[he] - A[he] - qe + W.altAxis, Te = Oe ? J + j[he] + A[he] - qe - W.altAxis : Ce, Ve = d && Oe ? Ht(Ne, J, Te) : ie(d ? Ne : Me, J, d ? Te : Ce);
      w[x] = Ve, C[x] = Ve - J;
    }
    e.modifiersData[r] = C;
  }
}
s(an, "on");
var sn = { name: "preventOverflow", enabled: !0, phase: "main", fn: an, requiresIfExists: ["offset"] };
function fn(t) {
  return { scrollLeft: t.scrollLeft, scrollTop: t.scrollTop };
}
s(fn, "an");
function cn(t) {
  return t === N(t) || !L(t) ? We(t) : fn(t);
}
s(cn, "sn");
function pn(t) {
  var e = t.getBoundingClientRect(), n = $(e.width) / t.offsetWidth || 1, r = $(e.height) / t.offsetHeight || 1;
  return n !== 1 || r !== 1;
}
s(pn, "fn");
function un(t, e, n) {
  n === void 0 && (n = !1);
  var r = L(e), o = L(e) && pn(e), i = X(e), a = _(t, o), f = { scrollLeft: 0, scrollTop: 0 }, c = { x: 0, y: 0 };
  return (r || !r && !n) && ((V(e) !== "body" || Be(i)) && (f = cn(e)), L(e) ? (c = _(e, !0), c.x += e.clientLeft, c.y += e.clientTop) : i && (c.x = ke(i))), { x: a.left + f.scrollLeft - c.x, y: a.top + f.scrollTop - c.y, width: a.width, height: a.height };
}
s(un, "cn");
function ln(t) {
  var e = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Set(), r = [];
  t.forEach(function(i) {
    e.set(i.name, i);
  });
  function o(i) {
    n.add(i.name);
    var a = [].concat(i.requires || [], i.requiresIfExists || []);
    a.forEach(function(f) {
      if (!n.has(f)) {
        var c = e.get(f);
        c && o(c);
      }
    }), r.push(i);
  }
  return s(o, "o"), t.forEach(function(i) {
    n.has(i.name) || o(i);
  }), r;
}
s(ln, "pn");
function dn(t) {
  var e = ln(t);
  return Pt.reduce(function(n, r) {
    return n.concat(e.filter(function(o) {
      return o.phase === r;
    }));
  }, []);
}
s(dn, "un");
function mn(t) {
  var e;
  return function() {
    return e || (e = new Promise(function(n) {
      Promise.resolve().then(function() {
        e = void 0, n(t());
      });
    })), e;
  };
}
s(mn, "ln");
function hn(t) {
  var e = t.reduce(function(n, r) {
    var o = n[r.name];
    return n[r.name] = o ? Object.assign({}, o, r, { options: Object.assign({}, o.options, r.options), data: Object.assign({}, o.data, r.data) }) : r, n;
  }, {});
  return Object.keys(e).map(function(n) {
    return e[n];
  });
}
s(hn, "dn");
var Qe = { placement: "bottom", modifiers: [], strategy: "absolute" };
function Ze() {
  for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
  return !e.some(function(r) {
    return !(r && typeof r.getBoundingClientRect == "function");
  });
}
s(Ze, "$t");
function Re(t) {
  t === void 0 && (t = {});
  var e = t, n = e.defaultModifiers, r = n === void 0 ? [] : n, o = e.defaultOptions, i = o === void 0 ? Qe : o;
  return function(a, f, c) {
    c === void 0 && (c = i);
    var p = { placement: "bottom", orderedModifiers: [], options: Object.assign({}, Qe, i), modifiersData: {}, elements: { reference: a, popper: f }, attributes: {}, styles: {} }, l = [], v = !1, g = { state: p, setOptions: /* @__PURE__ */ s(function(u) {
      var y = typeof u == "function" ? u(p.options) : u;
      h(), p.options = Object.assign({}, i, p.options, y), p.scrollParents = { reference: Y(a) ? ae(a) : a.contextElement ? ae(a.contextElement) : [], popper: ae(f) };
      var O = dn(hn([].concat(r, p.options.modifiers)));
      return p.orderedModifiers = O.filter(function(b) {
        return b.enabled;
      }), d(), g.update();
    }, "setOptions"), forceUpdate: /* @__PURE__ */ s(function() {
      if (!v) {
        var u = p.elements, y = u.reference, O = u.popper;
        if (Ze(y, O)) {
          p.rects = { reference: un(y, pe(O), p.options.strategy === "fixed"), popper: De(O) }, p.reset = !1, p.placement = p.options.placement, p.orderedModifiers.forEach(function(A) {
            return p.modifiersData[A.name] = Object.assign({}, A.data);
          });
          for (var b = 0; b < p.orderedModifiers.length; b++) {
            if (p.reset === !0) {
              p.reset = !1, b = -1;
              continue;
            }
            var E = p.orderedModifiers[b], m = E.fn, x = E.options, w = x === void 0 ? {} : x, j = E.name;
            typeof m == "function" && (p = m({ state: p, options: w, name: j, instance: g }) || p);
          }
        }
      }
    }, "forceUpdate"), update: mn(function() {
      return new Promise(function(u) {
        g.forceUpdate(), u(p);
      });
    }), destroy: /* @__PURE__ */ s(function() {
      h(), v = !0;
    }, "destroy") };
    if (!Ze(a, f)) return g;
    g.setOptions(c).then(function(u) {
      !v && c.onFirstUpdate && c.onFirstUpdate(u);
    });
    function d() {
      p.orderedModifiers.forEach(function(u) {
        var y = u.name, O = u.options, b = O === void 0 ? {} : O, E = u.effect;
        if (typeof E == "function") {
          var m = E({ state: p, name: y, instance: g, options: b }), x = /* @__PURE__ */ s(function() {
          }, "b");
          l.push(m || x);
        }
      });
    }
    s(d, "l");
    function h() {
      l.forEach(function(u) {
        return u();
      }), l = [];
    }
    return s(h, "h"), g;
  };
}
s(Re, "we");
Re();
var vn = [ot, st, rt, _e];
Re({ defaultModifiers: vn });
var gn = [ot, st, rt, _e, nn, $t, sn, Ct, Ft], bn = Re({ defaultModifiers: gn });
export {
  jt as afterMain,
  xt as afterRead,
  Dt as afterWrite,
  _e as applyStyles,
  Ct as arrow,
  Ee as auto,
  ce as basePlacements,
  wt as beforeMain,
  yt as beforeRead,
  Et as beforeWrite,
  S as bottom,
  vt as clippingParents,
  rt as computeStyles,
  bn as createPopper,
  fe as detectOverflow,
  se as end,
  ot as eventListeners,
  $t as flip,
  Ft as hide,
  B as left,
  Ot as main,
  Pt as modifierPhases,
  nn as offset,
  $e as placements,
  oe as popper,
  Re as popperGenerator,
  st as popperOffsets,
  sn as preventOverflow,
  bt as read,
  gt as reference,
  M as right,
  Z as start,
  k as top,
  Ie as variationPlacements,
  Ye as viewport,
  At as write
};
