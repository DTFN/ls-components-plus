var S = Object.defineProperty;
var t = (e, n) => S(e, "name", { value: n, configurable: !0 });
var M = !1, d, f, p, c, l, E, s, w, m, v, O, x, h, X, A;
function o() {
  if (!M) {
    M = !0;
    var e = navigator.userAgent, n = /(?:MSIE.(\d+\.\d+))|(?:(?:Firefox|GranParadiso|Iceweasel).(\d+\.\d+))|(?:Opera(?:.+Version.|.)(\d+\.\d+))|(?:AppleWebKit.(\d+(?:\.\d+)?))|(?:Trident\/\d+\.\d+.*rv:(\d+\.\d+))/.exec(e), r = /(Mac OS X)|(Windows)|(Linux)/.exec(e);
    if (x = /\b(iPhone|iP[ao]d)/.exec(e), h = /\b(iP[ao]d)/.exec(e), v = /Android/i.exec(e), X = /FBAN\/\w+;/i.exec(e), A = /Mobile/i.exec(e), O = !!/Win64/.exec(e), n) {
      d = n[1] ? parseFloat(n[1]) : n[5] ? parseFloat(n[5]) : NaN, d && document && document.documentMode && (d = document.documentMode);
      var i = /(?:Trident\/(\d+.\d+))/.exec(e);
      E = i ? parseFloat(i[1]) + 4 : d, f = n[2] ? parseFloat(n[2]) : NaN, p = n[3] ? parseFloat(n[3]) : NaN, c = n[4] ? parseFloat(n[4]) : NaN, c ? (n = /(?:Chrome\/(\d+\.\d+))/.exec(e), l = n && n[1] ? parseFloat(n[1]) : NaN) : l = NaN;
    } else d = f = p = l = c = NaN;
    if (r) {
      if (r[1]) {
        var a = /(?:Mac OS X (\d+(?:[._]\d+)?))/.exec(e);
        s = a ? parseFloat(a[1].replace("_", ".")) : !0;
      } else s = !1;
      w = !!r[2], m = !!r[3];
    } else s = w = m = !1;
  }
}
t(o, "a");
var N = { ie: /* @__PURE__ */ t(function() {
  return o() || d;
}, "ie"), ieCompatibilityMode: /* @__PURE__ */ t(function() {
  return o() || E > d;
}, "ieCompatibilityMode"), ie64: /* @__PURE__ */ t(function() {
  return N.ie() && O;
}, "ie64"), firefox: /* @__PURE__ */ t(function() {
  return o() || f;
}, "firefox"), opera: /* @__PURE__ */ t(function() {
  return o() || p;
}, "opera"), webkit: /* @__PURE__ */ t(function() {
  return o() || c;
}, "webkit"), safari: /* @__PURE__ */ t(function() {
  return N.webkit();
}, "safari"), chrome: /* @__PURE__ */ t(function() {
  return o() || l;
}, "chrome"), windows: /* @__PURE__ */ t(function() {
  return o() || w;
}, "windows"), osx: /* @__PURE__ */ t(function() {
  return o() || s;
}, "osx"), linux: /* @__PURE__ */ t(function() {
  return o() || m;
}, "linux"), iphone: /* @__PURE__ */ t(function() {
  return o() || x;
}, "iphone"), mobile: /* @__PURE__ */ t(function() {
  return o() || x || h || v || A;
}, "mobile"), nativeApp: /* @__PURE__ */ t(function() {
  return o() || X;
}, "nativeApp"), android: /* @__PURE__ */ t(function() {
  return o() || v;
}, "android"), ipad: /* @__PURE__ */ t(function() {
  return o() || h;
}, "ipad") }, W = N, u = !!(typeof window < "u" && window.document && window.document.createElement), k = { canUseDOM: u, canUseWorkers: typeof Worker < "u", canUseEventListeners: u && !!(window.addEventListener || window.attachEvent), canUseViewport: u && !!window.screen, isInWorker: !u }, U = k, Y;
U.canUseDOM && (Y = document.implementation && document.implementation.hasFeature && document.implementation.hasFeature("", "") !== !0);
function y(e, n) {
  if (!U.canUseDOM || n && !("addEventListener" in document)) return !1;
  var r = "on" + e, i = r in document;
  if (!i) {
    var a = document.createElement("div");
    a.setAttribute(r, "return;"), i = typeof a[r] == "function";
  }
  return !i && Y && e === "wheel" && (i = document.implementation.hasFeature("Events.wheel", "3.0")), i;
}
t(y, "S");
var L = y, F = 10, D = 40, b = 800;
function I(e) {
  var n = 0, r = 0, i = 0, a = 0;
  return "detail" in e && (r = e.detail), "wheelDelta" in e && (r = -e.wheelDelta / 120), "wheelDeltaY" in e && (r = -e.wheelDeltaY / 120), "wheelDeltaX" in e && (n = -e.wheelDeltaX / 120), "axis" in e && e.axis === e.HORIZONTAL_AXIS && (n = r, r = 0), i = n * F, a = r * F, "deltaY" in e && (a = e.deltaY), "deltaX" in e && (i = e.deltaX), (i || a) && e.deltaMode && (e.deltaMode == 1 ? (i *= D, a *= D) : (i *= b, a *= b)), i && !n && (n = i < 1 ? -1 : 1), a && !r && (r = a < 1 ? -1 : 1), { spinX: n, spinY: r, pixelX: i, pixelY: a };
}
t(I, "T");
I.getEventType = function() {
  return W.firefox() ? "DOMMouseScroll" : L("wheel") ? "wheel" : "mousewheel";
};
var T = I;
/**
* Checks if an event is supported in the current execution environment.
*
* NOTE: This will not work correctly for non-generic events such as `change`,
* `reset`, `load`, `error`, and `select`.
*
* Borrows from Modernizr.
*
* @param {string} eventNameSuffix Event name, e.g. "click".
* @param {?boolean} capture Check if the capture phase is supported.
* @return {boolean} True if the event is supported.
* @internal
* @license Modernizr 3.0.0pre (Custom Build) | MIT
*/
export {
  T as default
};
