var ne = Object.defineProperty;
var s = (i, e) => ne(i, "name", { value: e, configurable: !0 });
function N() {
  return N = Object.assign ? Object.assign.bind() : function(i) {
    for (var e = 1; e < arguments.length; e++) {
      var r = arguments[e];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (i[n] = r[n]);
    }
    return i;
  }, N.apply(this, arguments);
}
s(N, "_extends");
function te(i, e) {
  i.prototype = Object.create(e.prototype), i.prototype.constructor = i, S(i, e);
}
s(te, "_inheritsLoose");
function J(i) {
  return J = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : /* @__PURE__ */ s(function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, "_getPrototypeOf"), J(i);
}
s(J, "_getPrototypeOf");
function S(i, e) {
  return S = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : /* @__PURE__ */ s(function(n, t) {
    return n.__proto__ = t, n;
  }, "_setPrototypeOf"), S(i, e);
}
s(S, "_setPrototypeOf");
function ie() {
  if (typeof Reflect > "u" || !Reflect.construct || Reflect.construct.sham) return !1;
  if (typeof Proxy == "function") return !0;
  try {
    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    })), !0;
  } catch {
    return !1;
  }
}
s(ie, "_isNativeReflectConstruct");
function L(i, e, r) {
  return ie() ? L = Reflect.construct.bind() : L = /* @__PURE__ */ s(function(t, f, a) {
    var o = [null];
    o.push.apply(o, f);
    var u = Function.bind.apply(t, o), q = new u();
    return a && S(q, a.prototype), q;
  }, "_construct"), L.apply(null, arguments);
}
s(L, "_construct");
function ae(i) {
  return Function.toString.call(i).indexOf("[native code]") !== -1;
}
s(ae, "_isNativeFunction");
function W(i) {
  var e = typeof Map == "function" ? /* @__PURE__ */ new Map() : void 0;
  return W = /* @__PURE__ */ s(function(n) {
    if (n === null || !ae(n)) return n;
    if (typeof n != "function")
      throw new TypeError("Super expression must either be null or a function");
    if (typeof e < "u") {
      if (e.has(n)) return e.get(n);
      e.set(n, t);
    }
    function t() {
      return L(n, arguments, J(this).constructor);
    }
    return s(t, "Wrapper"), t.prototype = Object.create(n.prototype, {
      constructor: {
        value: t,
        enumerable: !1,
        writable: !0,
        configurable: !0
      }
    }), S(t, n);
  }, "_wrapNativeSuper"), W(i);
}
s(W, "_wrapNativeSuper");
var fe = /%[sdj%]/g, k = /* @__PURE__ */ s(function() {
}, "warning");
typeof process < "u" && process.env && process.env.NODE_ENV !== "production" && typeof window < "u" && typeof document < "u" && (k = /* @__PURE__ */ s(function(e, r) {
  typeof console < "u" && console.warn && typeof ASYNC_VALIDATOR_NO_WARNING > "u" && r.every(function(n) {
    return typeof n == "string";
  }) && console.warn(e, r);
}, "warning"));
function Z(i) {
  if (!i || !i.length) return null;
  var e = {};
  return i.forEach(function(r) {
    var n = r.field;
    e[n] = e[n] || [], e[n].push(r);
  }), e;
}
s(Z, "convertFieldsError");
function x(i) {
  for (var e = arguments.length, r = new Array(e > 1 ? e - 1 : 0), n = 1; n < e; n++)
    r[n - 1] = arguments[n];
  var t = 0, f = r.length;
  if (typeof i == "function")
    return i.apply(null, r);
  if (typeof i == "string") {
    var a = i.replace(fe, function(o) {
      if (o === "%%")
        return "%";
      if (t >= f)
        return o;
      switch (o) {
        case "%s":
          return String(r[t++]);
        case "%d":
          return Number(r[t++]);
        case "%j":
          try {
            return JSON.stringify(r[t++]);
          } catch {
            return "[Circular]";
          }
          break;
        default:
          return o;
      }
    });
    return a;
  }
  return i;
}
s(x, "format");
function se(i) {
  return i === "string" || i === "url" || i === "hex" || i === "email" || i === "date" || i === "pattern";
}
s(se, "isNativeStringType");
function m(i, e) {
  return !!(i == null || e === "array" && Array.isArray(i) && !i.length || se(e) && typeof i == "string" && !i);
}
s(m, "isEmptyValue");
function oe(i, e, r) {
  var n = [], t = 0, f = i.length;
  function a(o) {
    n.push.apply(n, o || []), t++, t === f && r(n);
  }
  s(a, "count"), i.forEach(function(o) {
    e(o, a);
  });
}
s(oe, "asyncParallelArray");
function K(i, e, r) {
  var n = 0, t = i.length;
  function f(a) {
    if (a && a.length) {
      r(a);
      return;
    }
    var o = n;
    n = n + 1, o < t ? e(i[o], f) : r([]);
  }
  s(f, "next"), f([]);
}
s(K, "asyncSerialArray");
function de(i) {
  var e = [];
  return Object.keys(i).forEach(function(r) {
    e.push.apply(e, i[r] || []);
  }), e;
}
s(de, "flattenObjArr");
var H = /* @__PURE__ */ function(i) {
  te(e, i);
  function e(r, n) {
    var t;
    return t = i.call(this, "Async Validation Error") || this, t.errors = r, t.fields = n, t;
  }
  return s(e, "AsyncValidationError"), e;
}(/* @__PURE__ */ W(Error));
function ue(i, e, r, n, t) {
  if (e.first) {
    var f = new Promise(function(w, E) {
      var O = /* @__PURE__ */ s(function(d) {
        return n(d), d.length ? E(new H(d, Z(d))) : w(t);
      }, "next"), c = de(i);
      K(c, r, O);
    });
    return f.catch(function(w) {
      return w;
    }), f;
  }
  var a = e.firstFields === !0 ? Object.keys(i) : e.firstFields || [], o = Object.keys(i), u = o.length, q = 0, v = [], l = new Promise(function(w, E) {
    var O = /* @__PURE__ */ s(function(h) {
      if (v.push.apply(v, h), q++, q === u)
        return n(v), v.length ? E(new H(v, Z(v))) : w(t);
    }, "next");
    o.length || (n(v), w(t)), o.forEach(function(c) {
      var h = i[c];
      a.indexOf(c) !== -1 ? K(h, r, O) : oe(h, r, O);
    });
  });
  return l.catch(function(w) {
    return w;
  }), l;
}
s(ue, "asyncMap");
function ce(i) {
  return !!(i && i.message !== void 0);
}
s(ce, "isErrorObj");
function pe(i, e) {
  for (var r = i, n = 0; n < e.length; n++) {
    if (r == null)
      return r;
    r = r[e[n]];
  }
  return r;
}
s(pe, "getValue");
function Q(i, e) {
  return function(r) {
    var n;
    return i.fullFields ? n = pe(e, i.fullFields) : n = e[r.field || i.fullField], ce(r) ? (r.field = r.field || i.fullField, r.fieldValue = n, r) : {
      message: typeof r == "function" ? r() : r,
      fieldValue: n,
      field: r.field || i.fullField
    };
  };
}
s(Q, "complementError");
function X(i, e) {
  if (e) {
    for (var r in e)
      if (e.hasOwnProperty(r)) {
        var n = e[r];
        typeof n == "object" && typeof i[r] == "object" ? i[r] = N({}, i[r], n) : i[r] = n;
      }
  }
  return i;
}
s(X, "deepMerge");
var ee = /* @__PURE__ */ s(function(e, r, n, t, f, a) {
  e.required && (!n.hasOwnProperty(e.field) || m(r, a || e.type)) && t.push(x(f.messages.required, e.fullField));
}, "required"), ye = /* @__PURE__ */ s(function(e, r, n, t, f) {
  (/^\s+$/.test(r) || r === "") && t.push(x(f.messages.whitespace, e.fullField));
}, "whitespace"), M, ge = /* @__PURE__ */ s(function() {
  if (M)
    return M;
  var i = "[a-fA-F\\d:]", e = /* @__PURE__ */ s(function(g) {
    return g && g.includeBoundaries ? "(?:(?<=\\s|^)(?=" + i + ")|(?<=" + i + ")(?=\\s|$))" : "";
  }, "b"), r = "(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)(?:\\.(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)){3}", n = "[a-fA-F\\d]{1,4}", t = (`
(?:
(?:` + n + ":){7}(?:" + n + `|:)|                                    // 1:2:3:4:5:6:7::  1:2:3:4:5:6:7:8
(?:` + n + ":){6}(?:" + r + "|:" + n + `|:)|                             // 1:2:3:4:5:6::    1:2:3:4:5:6::8   1:2:3:4:5:6::8  1:2:3:4:5:6::1.2.3.4
(?:` + n + ":){5}(?::" + r + "|(?::" + n + `){1,2}|:)|                   // 1:2:3:4:5::      1:2:3:4:5::7:8   1:2:3:4:5::8    1:2:3:4:5::7:1.2.3.4
(?:` + n + ":){4}(?:(?::" + n + "){0,1}:" + r + "|(?::" + n + `){1,3}|:)| // 1:2:3:4::        1:2:3:4::6:7:8   1:2:3:4::8      1:2:3:4::6:7:1.2.3.4
(?:` + n + ":){3}(?:(?::" + n + "){0,2}:" + r + "|(?::" + n + `){1,4}|:)| // 1:2:3::          1:2:3::5:6:7:8   1:2:3::8        1:2:3::5:6:7:1.2.3.4
(?:` + n + ":){2}(?:(?::" + n + "){0,3}:" + r + "|(?::" + n + `){1,5}|:)| // 1:2::            1:2::4:5:6:7:8   1:2::8          1:2::4:5:6:7:1.2.3.4
(?:` + n + ":){1}(?:(?::" + n + "){0,4}:" + r + "|(?::" + n + `){1,6}|:)| // 1::              1::3:4:5:6:7:8   1::8            1::3:4:5:6:7:1.2.3.4
(?::(?:(?::` + n + "){0,5}:" + r + "|(?::" + n + `){1,7}|:))             // ::2:3:4:5:6:7:8  ::2:3:4:5:6:7:8  ::8             ::1.2.3.4
)(?:%[0-9a-zA-Z]{1,})?                                             // %eth0            %1
`).replace(/\s*\/\/.*$/gm, "").replace(/\n/g, "").trim(), f = new RegExp("(?:^" + r + "$)|(?:^" + t + "$)"), a = new RegExp("^" + r + "$"), o = new RegExp("^" + t + "$"), u = /* @__PURE__ */ s(function(g) {
    return g && g.exact ? f : new RegExp("(?:" + e(g) + r + e(g) + ")|(?:" + e(g) + t + e(g) + ")", "g");
  }, "ip");
  u.v4 = function(y) {
    return y && y.exact ? a : new RegExp("" + e(y) + r + e(y), "g");
  }, u.v6 = function(y) {
    return y && y.exact ? o : new RegExp("" + e(y) + t + e(y), "g");
  };
  var q = "(?:(?:[a-z]+:)?//)", v = "(?:\\S+(?::\\S*)?@)?", l = u.v4().source, w = u.v6().source, E = "(?:(?:[a-z\\u00a1-\\uffff0-9][-_]*)*[a-z\\u00a1-\\uffff0-9]+)", O = "(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*", c = "(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))", h = "(?::\\d{2,5})?", d = '(?:[/?#][^\\s"]*)?', P = "(?:" + q + "|www\\.)" + v + "(?:localhost|" + l + "|" + w + "|" + E + O + c + ")" + h + d;
  return M = new RegExp("(?:^" + P + "$)", "i"), M;
}, "getUrlRegex"), C = {
  // http://emailregex.com/
  email: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+\.)+[a-zA-Z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]{2,}))$/,
  // url: new RegExp(
  //   '^(?!mailto:)(?:(?:http|https|ftp)://|//)(?:\\S+(?::\\S*)?@)?(?:(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[0-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]+-*)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]+-*)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))|localhost)(?::\\d{2,5})?(?:(/|\\?|#)[^\\s]*)?$',
  //   'i',
  // ),
  hex: /^#?([a-f0-9]{6}|[a-f0-9]{3})$/i
}, T = {
  integer: /* @__PURE__ */ s(function(e) {
    return T.number(e) && parseInt(e, 10) === e;
  }, "integer"),
  float: /* @__PURE__ */ s(function(e) {
    return T.number(e) && !T.integer(e);
  }, "float"),
  array: /* @__PURE__ */ s(function(e) {
    return Array.isArray(e);
  }, "array"),
  regexp: /* @__PURE__ */ s(function(e) {
    if (e instanceof RegExp)
      return !0;
    try {
      return !!new RegExp(e);
    } catch {
      return !1;
    }
  }, "regexp"),
  date: /* @__PURE__ */ s(function(e) {
    return typeof e.getTime == "function" && typeof e.getMonth == "function" && typeof e.getYear == "function" && !isNaN(e.getTime());
  }, "date"),
  number: /* @__PURE__ */ s(function(e) {
    return isNaN(e) ? !1 : typeof e == "number";
  }, "number"),
  object: /* @__PURE__ */ s(function(e) {
    return typeof e == "object" && !T.array(e);
  }, "object"),
  method: /* @__PURE__ */ s(function(e) {
    return typeof e == "function";
  }, "method"),
  email: /* @__PURE__ */ s(function(e) {
    return typeof e == "string" && e.length <= 320 && !!e.match(C.email);
  }, "email"),
  url: /* @__PURE__ */ s(function(e) {
    return typeof e == "string" && e.length <= 2048 && !!e.match(ge());
  }, "url"),
  hex: /* @__PURE__ */ s(function(e) {
    return typeof e == "string" && !!e.match(C.hex);
  }, "hex")
}, he = /* @__PURE__ */ s(function(e, r, n, t, f) {
  if (e.required && r === void 0) {
    ee(e, r, n, t, f);
    return;
  }
  var a = ["integer", "float", "array", "regexp", "object", "method", "email", "number", "date", "url", "hex"], o = e.type;
  a.indexOf(o) > -1 ? T[o](r) || t.push(x(f.messages.types[o], e.fullField, e.type)) : o && typeof r !== e.type && t.push(x(f.messages.types[o], e.fullField, e.type));
}, "type"), ve = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = typeof e.len == "number", o = typeof e.min == "number", u = typeof e.max == "number", q = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g, v = r, l = null, w = typeof r == "number", E = typeof r == "string", O = Array.isArray(r);
  if (w ? l = "number" : E ? l = "string" : O && (l = "array"), !l)
    return !1;
  O && (v = r.length), E && (v = r.replace(q, "_").length), a ? v !== e.len && t.push(x(f.messages[l].len, e.fullField, e.len)) : o && !u && v < e.min ? t.push(x(f.messages[l].min, e.fullField, e.min)) : u && !o && v > e.max ? t.push(x(f.messages[l].max, e.fullField, e.max)) : o && u && (v < e.min || v > e.max) && t.push(x(f.messages[l].range, e.fullField, e.min, e.max));
}, "range"), V = "enum", me = /* @__PURE__ */ s(function(e, r, n, t, f) {
  e[V] = Array.isArray(e[V]) ? e[V] : [], e[V].indexOf(r) === -1 && t.push(x(f.messages[V], e.fullField, e[V].join(", ")));
}, "enumerable"), le = /* @__PURE__ */ s(function(e, r, n, t, f) {
  if (e.pattern) {
    if (e.pattern instanceof RegExp)
      e.pattern.lastIndex = 0, e.pattern.test(r) || t.push(x(f.messages.pattern.mismatch, e.fullField, r, e.pattern));
    else if (typeof e.pattern == "string") {
      var a = new RegExp(e.pattern);
      a.test(r) || t.push(x(f.messages.pattern.mismatch, e.fullField, r, e.pattern));
    }
  }
}, "pattern"), p = {
  required: ee,
  whitespace: ye,
  type: he,
  range: ve,
  enum: me,
  pattern: le
}, we = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r, "string") && !e.required)
      return n();
    p.required(e, r, t, a, f, "string"), m(r, "string") || (p.type(e, r, t, a, f), p.range(e, r, t, a, f), p.pattern(e, r, t, a, f), e.whitespace === !0 && p.whitespace(e, r, t, a, f));
  }
  n(a);
}, "string"), qe = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r) && !e.required)
      return n();
    p.required(e, r, t, a, f), r !== void 0 && p.type(e, r, t, a, f);
  }
  n(a);
}, "method"), be = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (r === "" && (r = void 0), m(r) && !e.required)
      return n();
    p.required(e, r, t, a, f), r !== void 0 && (p.type(e, r, t, a, f), p.range(e, r, t, a, f));
  }
  n(a);
}, "number"), Fe = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r) && !e.required)
      return n();
    p.required(e, r, t, a, f), r !== void 0 && p.type(e, r, t, a, f);
  }
  n(a);
}, "_boolean"), xe = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r) && !e.required)
      return n();
    p.required(e, r, t, a, f), m(r) || p.type(e, r, t, a, f);
  }
  n(a);
}, "regexp"), Oe = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r) && !e.required)
      return n();
    p.required(e, r, t, a, f), r !== void 0 && (p.type(e, r, t, a, f), p.range(e, r, t, a, f));
  }
  n(a);
}, "integer"), Ee = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r) && !e.required)
      return n();
    p.required(e, r, t, a, f), r !== void 0 && (p.type(e, r, t, a, f), p.range(e, r, t, a, f));
  }
  n(a);
}, "floatFn"), Ae = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (r == null && !e.required)
      return n();
    p.required(e, r, t, a, f, "array"), r != null && (p.type(e, r, t, a, f), p.range(e, r, t, a, f));
  }
  n(a);
}, "array"), Pe = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r) && !e.required)
      return n();
    p.required(e, r, t, a, f), r !== void 0 && p.type(e, r, t, a, f);
  }
  n(a);
}, "object"), je = "enum", _e = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r) && !e.required)
      return n();
    p.required(e, r, t, a, f), r !== void 0 && p[je](e, r, t, a, f);
  }
  n(a);
}, "enumerable"), Re = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r, "string") && !e.required)
      return n();
    p.required(e, r, t, a, f), m(r, "string") || p.pattern(e, r, t, a, f);
  }
  n(a);
}, "pattern"), Ne = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r, "date") && !e.required)
      return n();
    if (p.required(e, r, t, a, f), !m(r, "date")) {
      var u;
      r instanceof Date ? u = r : u = new Date(r), p.type(e, u, t, a, f), u && p.range(e, u.getTime(), t, a, f);
    }
  }
  n(a);
}, "date"), Ve = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = Array.isArray(r) ? "array" : typeof r;
  p.required(e, r, t, a, f, o), n(a);
}, "required"), U = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = e.type, o = [], u = e.required || !e.required && t.hasOwnProperty(e.field);
  if (u) {
    if (m(r, a) && !e.required)
      return n();
    p.required(e, r, t, o, f, a), m(r, a) || p.type(e, r, t, o, f);
  }
  n(o);
}, "type"), De = /* @__PURE__ */ s(function(e, r, n, t, f) {
  var a = [], o = e.required || !e.required && t.hasOwnProperty(e.field);
  if (o) {
    if (m(r) && !e.required)
      return n();
    p.required(e, r, t, a, f);
  }
  n(a);
}, "any"), $ = {
  string: we,
  method: qe,
  number: be,
  boolean: Fe,
  regexp: xe,
  integer: Oe,
  float: Ee,
  array: Ae,
  object: Pe,
  enum: _e,
  pattern: Re,
  date: Ne,
  url: U,
  hex: U,
  email: U,
  required: Ve,
  any: De
};
function I() {
  return {
    default: "Validation error on field %s",
    required: "%s is required",
    enum: "%s must be one of %s",
    whitespace: "%s cannot be empty",
    date: {
      format: "%s date %s is invalid for format %s",
      parse: "%s date could not be parsed, %s is invalid ",
      invalid: "%s date %s is invalid"
    },
    types: {
      string: "%s is not a %s",
      method: "%s is not a %s (function)",
      array: "%s is not an %s",
      object: "%s is not an %s",
      number: "%s is not a %s",
      date: "%s is not a %s",
      boolean: "%s is not a %s",
      integer: "%s is not an %s",
      float: "%s is not a %s",
      regexp: "%s is not a valid %s",
      email: "%s is not a valid %s",
      url: "%s is not a valid %s",
      hex: "%s is not a valid %s"
    },
    string: {
      len: "%s must be exactly %s characters",
      min: "%s must be at least %s characters",
      max: "%s cannot be longer than %s characters",
      range: "%s must be between %s and %s characters"
    },
    number: {
      len: "%s must equal %s",
      min: "%s cannot be less than %s",
      max: "%s cannot be greater than %s",
      range: "%s must be between %s and %s"
    },
    array: {
      len: "%s must be exactly %s in length",
      min: "%s cannot be less than %s in length",
      max: "%s cannot be greater than %s in length",
      range: "%s must be between %s and %s in length"
    },
    pattern: {
      mismatch: "%s value %s does not match pattern %s"
    },
    clone: /* @__PURE__ */ s(function() {
      var e = JSON.parse(JSON.stringify(this));
      return e.clone = this.clone, e;
    }, "clone")
  };
}
s(I, "newMessages");
var Y = I(), B = /* @__PURE__ */ function() {
  function i(r) {
    this.rules = null, this._messages = Y, this.define(r);
  }
  s(i, "Schema");
  var e = i.prototype;
  return e.define = /* @__PURE__ */ s(function(n) {
    var t = this;
    if (!n)
      throw new Error("Cannot configure a schema with no rules");
    if (typeof n != "object" || Array.isArray(n))
      throw new Error("Rules must be an object");
    this.rules = {}, Object.keys(n).forEach(function(f) {
      var a = n[f];
      t.rules[f] = Array.isArray(a) ? a : [a];
    });
  }, "define"), e.messages = /* @__PURE__ */ s(function(n) {
    return n && (this._messages = X(I(), n)), this._messages;
  }, "messages"), e.validate = /* @__PURE__ */ s(function(n, t, f) {
    var a = this;
    t === void 0 && (t = {}), f === void 0 && (f = /* @__PURE__ */ s(function() {
    }, "oc"));
    var o = n, u = t, q = f;
    if (typeof u == "function" && (q = u, u = {}), !this.rules || Object.keys(this.rules).length === 0)
      return q && q(null, o), Promise.resolve(o);
    function v(c) {
      var h = [], d = {};
      function P(g) {
        if (Array.isArray(g)) {
          var F;
          h = (F = h).concat.apply(F, g);
        } else
          h.push(g);
      }
      s(P, "add");
      for (var y = 0; y < c.length; y++)
        P(c[y]);
      h.length ? (d = Z(h), q(h, d)) : q(null, o);
    }
    if (s(v, "complete"), u.messages) {
      var l = this.messages();
      l === Y && (l = I()), X(l, u.messages), u.messages = l;
    } else
      u.messages = this.messages();
    var w = {}, E = u.keys || Object.keys(this.rules);
    E.forEach(function(c) {
      var h = a.rules[c], d = o[c];
      h.forEach(function(P) {
        var y = P;
        typeof y.transform == "function" && (o === n && (o = N({}, o)), d = o[c] = y.transform(d)), typeof y == "function" ? y = {
          validator: y
        } : y = N({}, y), y.validator = a.getValidationMethod(y), y.validator && (y.field = c, y.fullField = y.fullField || c, y.type = a.getType(y), w[c] = w[c] || [], w[c].push({
          rule: y,
          value: d,
          source: o,
          field: c
        }));
      });
    });
    var O = {};
    return ue(w, u, function(c, h) {
      var d = c.rule, P = (d.type === "object" || d.type === "array") && (typeof d.fields == "object" || typeof d.defaultField == "object");
      P = P && (d.required || !d.required && c.value), d.field = c.field;
      function y(b, R) {
        return N({}, R, {
          fullField: d.fullField + "." + b,
          fullFields: d.fullFields ? [].concat(d.fullFields, [b]) : [b]
        });
      }
      s(y, "addFullField");
      function g(b) {
        b === void 0 && (b = []);
        var R = Array.isArray(b) ? b : [b];
        !u.suppressWarning && R.length && i.warning("async-validator:", R), R.length && d.message !== void 0 && (R = [].concat(d.message));
        var j = R.map(Q(d, o));
        if (u.first && j.length)
          return O[d.field] = 1, h(j);
        if (!P)
          h(j);
        else {
          if (d.required && !c.value)
            return d.message !== void 0 ? j = [].concat(d.message).map(Q(d, o)) : u.error && (j = [u.error(d, x(u.messages.required, d.field))]), h(j);
          var D = {};
          d.defaultField && Object.keys(c.value).map(function(_) {
            D[_] = d.defaultField;
          }), D = N({}, D, c.rule.fields);
          var z = {};
          Object.keys(D).forEach(function(_) {
            var A = D[_], re = Array.isArray(A) ? A : [A];
            z[_] = re.map(y.bind(null, _));
          });
          var G = new i(z);
          G.messages(u.messages), c.rule.options && (c.rule.options.messages = u.messages, c.rule.options.error = u.error), G.validate(c.value, c.rule.options || u, function(_) {
            var A = [];
            j && j.length && A.push.apply(A, j), _ && _.length && A.push.apply(A, _), h(A.length ? A : null);
          });
        }
      }
      s(g, "cb");
      var F;
      if (d.asyncValidator)
        F = d.asyncValidator(d, c.value, g, c.source, u);
      else if (d.validator) {
        try {
          F = d.validator(d, c.value, g, c.source, u);
        } catch (b) {
          console.error == null || console.error(b), u.suppressValidatorError || setTimeout(function() {
            throw b;
          }, 0), g(b.message);
        }
        F === !0 ? g() : F === !1 ? g(typeof d.message == "function" ? d.message(d.fullField || d.field) : d.message || (d.fullField || d.field) + " fails") : F instanceof Array ? g(F) : F instanceof Error && g(F.message);
      }
      F && F.then && F.then(function() {
        return g();
      }, function(b) {
        return g(b);
      });
    }, function(c) {
      v(c);
    }, o);
  }, "validate"), e.getType = /* @__PURE__ */ s(function(n) {
    if (n.type === void 0 && n.pattern instanceof RegExp && (n.type = "pattern"), typeof n.validator != "function" && n.type && !$.hasOwnProperty(n.type))
      throw new Error(x("Unknown rule type %s", n.type));
    return n.type || "string";
  }, "getType"), e.getValidationMethod = /* @__PURE__ */ s(function(n) {
    if (typeof n.validator == "function")
      return n.validator;
    var t = Object.keys(n), f = t.indexOf("message");
    return f !== -1 && t.splice(f, 1), t.length === 1 && t[0] === "required" ? $.required : $[this.getType(n)] || void 0;
  }, "getValidationMethod"), i;
}();
B.register = /* @__PURE__ */ s(function(e, r) {
  if (typeof r != "function")
    throw new Error("Cannot register a validator by type, validator is not a function");
  $[e] = r;
}, "register");
B.warning = k;
B.messages = Y;
B.validators = $;
export {
  B as default
};
