var E = Object.defineProperty;
var x = (r, n) => E(r, "name", { value: n, configurable: !0 });
import R from "../_getAllKeys/index.js";
var F = 1, G = Object.prototype, I = G.hasOwnProperty;
function T(r, n, A, a, S, f) {
  var v = A & F, d = R(r), g = d.length, _ = R(n), q = _.length;
  if (g != q && !v)
    return !1;
  for (var l = g; l--; ) {
    var i = d[l];
    if (!(v ? i in n : I.call(n, i)))
      return !1;
  }
  var O = f.get(r), w = f.get(n);
  if (O && w)
    return O == n && w == r;
  var s = !0;
  f.set(r, n), f.set(n, r);
  for (var t = v; ++l < g; ) {
    i = d[l];
    var p = r[i], e = n[i];
    if (a)
      var L = v ? a(e, p, i, n, r, f) : a(p, e, i, r, n, f);
    if (!(L === void 0 ? p === e || S(p, e, A, a, f) : L)) {
      s = !1;
      break;
    }
    t || (t = i == "constructor");
  }
  if (s && !t) {
    var u = r.constructor, P = n.constructor;
    u != P && "constructor" in r && "constructor" in n && !(typeof u == "function" && u instanceof u && typeof P == "function" && P instanceof P) && (s = !1);
  }
  return f.delete(r), f.delete(n), s;
}
x(T, "equalObjects");
export {
  T as default
};
