var o = Object.defineProperty;
var e = (t, r) => o(t, "name", { value: r, configurable: !0 });
import g from "../_baseGetTag/index.js";
import b from "../isLength/index.js";
import c from "../isObjectLike/index.js";
var j = "[object Arguments]", n = "[object Array]", T = "[object Boolean]", i = "[object Date]", y = "[object Error]", p = "[object Function]", A = "[object Map]", f = "[object Number]", u = "[object Object]", m = "[object RegExp]", s = "[object Set]", l = "[object String]", d = "[object WeakMap]", I = "[object ArrayBuffer]", U = "[object DataView]", k = "[object Float32Array]", w = "[object Float64Array]", x = "[object Int8Array]", B = "[object Int16Array]", F = "[object Int32Array]", M = "[object Uint8Array]", h = "[object Uint8ClampedArray]", C = "[object Uint16Array]", D = "[object Uint32Array]", a = {};
a[k] = a[w] = a[x] = a[B] = a[F] = a[M] = a[h] = a[C] = a[D] = !0;
a[j] = a[n] = a[I] = a[T] = a[U] = a[i] = a[y] = a[p] = a[A] = a[f] = a[u] = a[m] = a[s] = a[l] = a[d] = !1;
function V(t) {
  return c(t) && b(t.length) && !!a[g(t)];
}
e(V, "baseIsTypedArray");
export {
  V as default
};
