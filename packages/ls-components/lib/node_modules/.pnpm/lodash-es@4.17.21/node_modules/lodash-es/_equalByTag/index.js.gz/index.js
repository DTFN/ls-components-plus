var b = Object.defineProperty;
var m = (e, a) => b(e, "name", { value: a, configurable: !0 });
import t from "../_Symbol/index.js";
import i from "../_Uint8Array/index.js";
import o from "../eq/index.js";
import d from "../_equalArrays/index.js";
import L from "../_mapToArray/index.js";
import O from "../_setToArray/index.js";
var v = 1, E = 2, R = "[object Boolean]", w = "[object Date]", B = "[object Error]", D = "[object Map]", P = "[object Number]", S = "[object RegExp]", _ = "[object Set]", c = "[object String]", x = "[object Symbol]", M = "[object ArrayBuffer]", V = "[object DataView]", l = t ? t.prototype : void 0, n = l ? l.valueOf : void 0;
function I(e, a, y, s, T, u, r) {
  switch (y) {
    case V:
      if (e.byteLength != a.byteLength || e.byteOffset != a.byteOffset)
        return !1;
      e = e.buffer, a = a.buffer;
    case M:
      return !(e.byteLength != a.byteLength || !u(new i(e), new i(a)));
    case R:
    case w:
    case P:
      return o(+e, +a);
    case B:
      return e.name == a.name && e.message == a.message;
    case S:
    case c:
      return e == a + "";
    case D:
      var f = L;
    case _:
      var p = s & v;
      if (f || (f = O), e.size != a.size && !p)
        return !1;
      var g = r.get(e);
      if (g)
        return g == a;
      s |= E, r.set(e, a);
      var A = d(f(e), f(a), s, T, u, r);
      return r.delete(e), A;
    case x:
      if (n)
        return n.call(e) == n.call(a);
  }
  return !1;
}
m(I, "equalByTag");
export {
  I as default
};
