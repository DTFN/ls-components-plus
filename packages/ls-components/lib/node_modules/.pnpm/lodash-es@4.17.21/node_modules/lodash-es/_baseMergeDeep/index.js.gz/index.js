var j = Object.defineProperty;
var d = (o, l) => j(o, "name", { value: l, configurable: !0 });
import g from "../_assignMergeValue/index.js";
import y from "../_cloneBuffer/index.js";
import c from "../_cloneTypedArray/index.js";
import C from "../_copyArray/index.js";
import M from "../_initCloneObject/index.js";
import O from "../isArguments/index.js";
import b from "../isArray/index.js";
import P from "../isArrayLikeObject/index.js";
import w from "../isBuffer/index.js";
import x from "../isFunction/index.js";
import D from "../isObject/index.js";
import F from "../isPlainObject/index.js";
import G from "../isTypedArray/index.js";
import v from "../_safeGet/index.js";
import L from "../toPlainObject/index.js";
function Y(o, l, f, A, V, a, m) {
  var i = v(o, f), e = v(l, f), s = m.get(e);
  if (s) {
    g(o, f, s);
    return;
  }
  var r = a ? a(i, e, f + "", o, l, m) : void 0, t = r === void 0;
  if (t) {
    var n = b(e), p = !n && w(e), u = !n && !p && G(e);
    r = e, n || p || u ? b(i) ? r = i : P(i) ? r = C(i) : p ? (t = !1, r = y(e, !0)) : u ? (t = !1, r = c(e, !0)) : r = [] : F(e) || O(e) ? (r = i, O(i) ? r = L(i) : (!D(i) || x(i)) && (r = M(e))) : t = !1;
  }
  t && (m.set(e, r), V(r, e, A, a, m), m.delete(e)), g(o, f, r);
}
d(Y, "baseMergeDeep");
export {
  Y as default
};
