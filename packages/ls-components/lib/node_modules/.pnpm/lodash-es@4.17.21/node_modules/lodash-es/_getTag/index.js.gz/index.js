var T = Object.defineProperty;
var g = (e, a) => T(e, "name", { value: a, configurable: !0 });
import o from "../_DataView/index.js";
import i from "../_Map/index.js";
import n from "../_Promise/index.js";
import m from "../_Set/index.js";
import c from "../_WeakMap/index.js";
import j from "../_baseGetTag/index.js";
import t from "../_toSource/index.js";
var f = "[object Map]", C = "[object Object]", u = "[object Promise]", w = "[object Set]", b = "[object WeakMap]", S = "[object DataView]", M = t(o), d = t(i), v = t(n), k = t(m), V = t(c), r = j;
(o && r(new o(new ArrayBuffer(1))) != S || i && r(new i()) != f || n && r(n.resolve()) != u || m && r(new m()) != w || c && r(new c()) != b) && (r = /* @__PURE__ */ g(function(e) {
  var a = j(e), p = a == C ? e.constructor : void 0, s = p ? t(p) : "";
  if (s)
    switch (s) {
      case M:
        return S;
      case d:
        return f;
      case v:
        return u;
      case k:
        return w;
      case V:
        return b;
    }
  return a;
}, "getTag"));
export {
  r as default
};
