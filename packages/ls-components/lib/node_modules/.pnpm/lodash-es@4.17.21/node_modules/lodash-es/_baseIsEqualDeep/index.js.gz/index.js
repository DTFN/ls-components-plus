var E = Object.defineProperty;
var _ = (r, a) => E(r, "name", { value: a, configurable: !0 });
import v from "../_Stack/index.js";
import L from "../_equalArrays/index.js";
import R from "../_equalByTag/index.js";
import S from "../_equalObjects/index.js";
import O from "../_getTag/index.js";
import u from "../isArray/index.js";
import w from "../isBuffer/index.js";
import q from "../isTypedArray/index.js";
var x = 1, P = "[object Arguments]", I = "[object Array]", l = "[object Object]", C = Object.prototype, j = C.hasOwnProperty;
function U(r, a, p, i, g, f) {
  var m = u(r), d = u(a), e = m ? I : O(r), o = d ? I : O(a);
  e = e == P ? l : e, o = o == P ? l : o;
  var A = e == l, s = o == l, n = e == o;
  if (n && w(r)) {
    if (!w(a))
      return !1;
    m = !0, A = !1;
  }
  if (n && !A)
    return f || (f = new v()), m || q(r) ? L(r, a, p, i, g, f) : R(r, a, e, p, i, g, f);
  if (!(p & x)) {
    var y = A && j.call(r, "__wrapped__"), T = s && j.call(a, "__wrapped__");
    if (y || T) {
      var t = y ? r.value() : r, B = T ? a.value() : a;
      return f || (f = new v()), g(t, B, p, i, f);
    }
  }
  return n ? (f || (f = new v()), S(r, a, p, i, g, f)) : !1;
}
_(U, "baseIsEqualDeep");
export {
  U as default
};
