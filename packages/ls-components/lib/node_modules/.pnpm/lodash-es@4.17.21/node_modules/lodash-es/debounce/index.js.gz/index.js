var y = Object.defineProperty;
var i = (s, t) => y(s, "name", { value: t, configurable: !0 });
import R from "../isObject/index.js";
import E from "../now/index.js";
import b from "../toNumber/index.js";
var A = "Expected a function", F = Math.max, N = Math.min;
function X(s, t, a) {
  var f, l, g, d, n, u, m = 0, k = !1, o = !1, T = !0;
  if (typeof s != "function")
    throw new TypeError(A);
  t = b(t) || 0, R(a) && (k = !!a.leading, o = "maxWait" in a, g = o ? F(b(a.maxWait) || 0, t) : g, T = "trailing" in a ? !!a.trailing : T);
  function h(e) {
    var r = f, c = l;
    return f = l = void 0, m = e, d = s.apply(c, r), d;
  }
  i(h, "invokeFunc");
  function C(e) {
    return m = e, n = setTimeout(v, t), k ? h(e) : d;
  }
  i(C, "leadingEdge");
  function L(e) {
    var r = e - u, c = e - m, W = t - r;
    return o ? N(W, g - c) : W;
  }
  i(L, "remainingWait");
  function I(e) {
    var r = e - u, c = e - m;
    return u === void 0 || r >= t || r < 0 || o && c >= g;
  }
  i(I, "shouldInvoke");
  function v() {
    var e = E();
    if (I(e))
      return p(e);
    n = setTimeout(v, L(e));
  }
  i(v, "timerExpired");
  function p(e) {
    return n = void 0, T && f ? h(e) : (f = l = void 0, d);
  }
  i(p, "trailingEdge");
  function M() {
    n !== void 0 && clearTimeout(n), m = 0, f = u = l = n = void 0;
  }
  i(M, "cancel");
  function S() {
    return n === void 0 ? d : p(E());
  }
  i(S, "flush");
  function x() {
    var e = E(), r = I(e);
    if (f = arguments, l = this, u = e, r) {
      if (n === void 0)
        return C(u);
      if (o)
        return clearTimeout(n), n = setTimeout(v, t), h(u);
    }
    return n === void 0 && (n = setTimeout(v, t)), d;
  }
  return i(x, "debounced"), x.cancel = M, x.flush = S, x;
}
i(X, "debounce");
export {
  X as default
};
