var n = Object.defineProperty;
var o = (a, r) => n(a, "name", { value: r, configurable: !0 });
import c from "../_cloneArrayBuffer/index.js";
import g from "../_cloneDataView/index.js";
import i from "../_cloneRegExp/index.js";
import s from "../_cloneSymbol/index.js";
import u from "../_cloneTypedArray/index.js";
var T = "[object Boolean]", b = "[object Date]", l = "[object Map]", m = "[object Number]", y = "[object RegExp]", f = "[object Set]", p = "[object String]", j = "[object Symbol]", A = "[object ArrayBuffer]", w = "[object DataView]", d = "[object Float32Array]", B = "[object Float64Array]", x = "[object Int8Array]", C = "[object Int16Array]", S = "[object Int32Array]", U = "[object Uint8Array]", v = "[object Uint8ClampedArray]", I = "[object Uint16Array]", V = "[object Uint32Array]";
function N(a, r, t) {
  var e = a.constructor;
  switch (r) {
    case A:
      return c(a);
    case T:
    case b:
      return new e(+a);
    case w:
      return g(a, t);
    case d:
    case B:
    case x:
    case C:
    case S:
    case U:
    case v:
    case I:
    case V:
      return u(a, t);
    case l:
      return new e();
    case m:
    case p:
      return new e(a);
    case y:
      return i(a);
    case f:
      return new e();
    case j:
      return s(a);
  }
}
o(N, "initCloneByTag");
export {
  N as default
};
