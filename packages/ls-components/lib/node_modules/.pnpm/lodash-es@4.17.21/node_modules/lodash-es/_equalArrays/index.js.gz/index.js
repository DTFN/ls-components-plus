var G = Object.defineProperty;
var D = (f, e) => G(f, "name", { value: e, configurable: !0 });
import M from "../_SetCache/index.js";
import x from "../_arraySome/index.js";
import F from "../_cacheHas/index.js";
var H = 1, N = 2;
function q(f, e, A, d, p, n) {
  var E = A & H, R = f.length, P = e.length;
  if (R != P && !(E && P > R))
    return !1;
  var S = n.get(f), _ = n.get(e);
  if (S && _)
    return S == e && _ == f;
  var v = -1, g = !0, l = A & N ? new M() : void 0;
  for (n.set(f, e), n.set(e, f); ++v < R; ) {
    var i = f[v], L = e[v];
    if (d)
      var C = E ? d(L, i, v, e, f, n) : d(i, L, v, f, e, n);
    if (C !== void 0) {
      if (C)
        continue;
      g = !1;
      break;
    }
    if (l) {
      if (!x(e, function(O, w) {
        if (!F(l, w) && (i === O || p(i, O, A, d, n)))
          return l.push(w);
      })) {
        g = !1;
        break;
      }
    } else if (!(i === L || p(i, L, A, d, n))) {
      g = !1;
      break;
    }
  }
  return n.delete(f), n.delete(e), g;
}
D(q, "equalArrays");
export {
  q as default
};
