var L = Object.defineProperty;
var A = (r, e) => L(r, "name", { value: e, configurable: !0 });
import B from "../_Stack/index.js";
import I from "../_arrayEach/index.js";
import O from "../_assignValue/index.js";
import _ from "../_baseAssign/index.js";
import M from "../_baseAssignIn/index.js";
import l from "../_cloneBuffer/index.js";
import w from "../_copyArray/index.js";
import D from "../_copySymbols/index.js";
import G from "../_copySymbolsIn/index.js";
import N from "../_getAllKeys/index.js";
import U from "../_getAllKeysIn/index.js";
import h from "../_getTag/index.js";
import x from "../_initCloneArray/index.js";
import K from "../_initCloneByTag/index.js";
import P from "../_initCloneObject/index.js";
import R from "../isArray/index.js";
import W from "../isBuffer/index.js";
import Y from "../isMap/index.js";
import q from "../isObject/index.js";
import H from "../isSet/index.js";
import J from "../keys/index.js";
import Q from "../keysIn/index.js";
var V = 1, X = 2, Z = 4, d = "[object Arguments]", $ = "[object Array]", u = "[object Boolean]", z = "[object Date]", k = "[object Error]", E = "[object Function]", v = "[object GeneratorFunction]", rr = "[object Map]", or = "[object Number]", F = "[object Object]", tr = "[object RegExp]", er = "[object Set]", ir = "[object String]", nr = "[object Symbol]", fr = "[object WeakMap]", ar = "[object ArrayBuffer]", mr = "[object DataView]", cr = "[object Float32Array]", gr = "[object Float64Array]", pr = "[object Int8Array]", br = "[object Int16Array]", Tr = "[object Int32Array]", jr = "[object Uint8Array]", yr = "[object Uint8ClampedArray]", sr = "[object Uint16Array]", Ar = "[object Uint32Array]", o = {};
o[d] = o[$] = o[ar] = o[mr] = o[u] = o[z] = o[cr] = o[gr] = o[pr] = o[br] = o[Tr] = o[rr] = o[or] = o[F] = o[tr] = o[er] = o[ir] = o[nr] = o[jr] = o[yr] = o[sr] = o[Ar] = !0;
o[k] = o[E] = o[fr] = !1;
function p(r, e, g, dr, b, n) {
  var t, m = e & V, c = e & X, C = e & Z;
  if (t !== void 0)
    return t;
  if (!q(r))
    return r;
  var T = R(r);
  if (T) {
    if (t = x(r), !m)
      return w(r, t);
  } else {
    var a = h(r), j = a == E || a == v;
    if (W(r))
      return l(r, m);
    if (a == F || a == d || j && !b) {
      if (t = c || j ? {} : P(r), !m)
        return c ? G(r, M(t, r)) : D(r, _(t, r));
    } else {
      if (!o[a])
        return b ? r : {};
      t = K(r, a, m);
    }
  }
  n || (n = new B());
  var y = n.get(r);
  if (y)
    return y;
  n.set(r, t), H(r) ? r.forEach(function(i) {
    t.add(p(i, e, g, i, r, n));
  }) : Y(r) && r.forEach(function(i, f) {
    t.set(f, p(i, e, g, f, r, n));
  });
  var S = C ? c ? U : N : c ? Q : J, s = T ? void 0 : S(r);
  return I(s || r, function(i, f) {
    s && (f = i, i = r[f]), O(t, f, p(i, e, g, f, r, n));
  }), t;
}
A(p, "baseClone");
export {
  p as default
};
