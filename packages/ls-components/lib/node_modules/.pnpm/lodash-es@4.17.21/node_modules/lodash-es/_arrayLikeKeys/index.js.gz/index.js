var g = Object.defineProperty;
var m = (r, i) => g(r, "name", { value: i, configurable: !0 });
import h from "../_baseTimes/index.js";
import b from "../isArguments/index.js";
import A from "../isArray/index.js";
import c from "../isBuffer/index.js";
import d from "../_isIndex/index.js";
import O from "../isTypedArray/index.js";
var u = Object.prototype, x = u.hasOwnProperty;
function I(r, i) {
  var o = A(r), s = !o && b(r), f = !o && !s && c(r), n = !o && !s && !f && O(r), p = o || s || f || n, e = p ? h(r.length, String) : [], a = e.length;
  for (var t in r)
    (i || x.call(r, t)) && !(p && // Safari 9 has enumerable `arguments.length` in strict mode.
    (t == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    f && (t == "offset" || t == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    n && (t == "buffer" || t == "byteLength" || t == "byteOffset") || // Skip index properties.
    d(t, a))) && e.push(t);
  return e;
}
m(I, "arrayLikeKeys");
export {
  I as default
};
