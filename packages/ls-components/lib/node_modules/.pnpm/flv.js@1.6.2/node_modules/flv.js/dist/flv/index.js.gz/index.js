var be = Object.defineProperty;
var d = (_e, ge) => be(_e, "name", { value: ge, configurable: !0 });
import { getDefaultExportFromCjs as Re } from "../../../../../../../_virtual/_commonjsHelpers/index.js";
import { __module as xe } from "../../../../../../../_virtual/flv/index.js";
(function(_e, ge) {
  (/* @__PURE__ */ d(function(pe, Q) {
    _e.exports = Q();
  }, "webpackUniversalModuleDefinition"))(self, function() {
    return (
      /******/
      function() {
        var ce = {
          /***/
          "./node_modules/es6-promise/dist/es6-promise.js": (
            /*!******************************************************!*\
              !*** ./node_modules/es6-promise/dist/es6-promise.js ***!
              \******************************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              /*!
               * @overview es6-promise - a tiny implementation of Promises/A+.
               * @copyright Copyright (c) 2014 Yehuda Katz, Tom Dale, Stefan Penner and contributors (Conversion to ES6 API by Jake Archibald)
               * @license   Licensed under MIT license
               *            See https://raw.githubusercontent.com/stefanpenner/es6-promise/master/LICENSE
               * @version   v4.2.8+1e68dce6
               */
              (function(S, _) {
                D.exports = _();
              })(this, function() {
                function S(b) {
                  var T = typeof b;
                  return b !== null && (T === "object" || T === "function");
                }
                d(S, "objectOrFunction");
                function _(b) {
                  return typeof b == "function";
                }
                d(_, "isFunction");
                var u = void 0;
                Array.isArray ? u = Array.isArray : u = /* @__PURE__ */ d(function(b) {
                  return Object.prototype.toString.call(b) === "[object Array]";
                }, "_isArray");
                var o = u, h = 0, r = void 0, a = void 0, l = /* @__PURE__ */ d(function(T, C) {
                  x[h] = T, x[h + 1] = C, h += 2, h === 2 && (a ? a(L) : R());
                }, "asap");
                function i(b) {
                  a = b;
                }
                d(i, "setScheduler");
                function t(b) {
                  l = b;
                }
                d(t, "setAsap");
                var s = typeof window < "u" ? window : void 0, n = s || {}, e = n.MutationObserver || n.WebKitMutationObserver, f = typeof self > "u" && typeof process < "u" && {}.toString.call(process) === "[object process]", c = typeof Uint8ClampedArray < "u" && typeof importScripts < "u" && typeof MessageChannel < "u";
                function p() {
                  return function() {
                    return process.nextTick(L);
                  };
                }
                d(p, "useNextTick");
                function g() {
                  return typeof r < "u" ? function() {
                    r(L);
                  } : m();
                }
                d(g, "useVertxTimer");
                function y() {
                  var b = 0, T = new e(L), C = document.createTextNode("");
                  return T.observe(C, { characterData: !0 }), function() {
                    C.data = b = ++b % 2;
                  };
                }
                d(y, "useMutationObserver");
                function E() {
                  var b = new MessageChannel();
                  return b.port1.onmessage = L, function() {
                    return b.port2.postMessage(0);
                  };
                }
                d(E, "useMessageChannel");
                function m() {
                  var b = setTimeout;
                  return function() {
                    return b(L, 1);
                  };
                }
                d(m, "useSetTimeout");
                var x = new Array(1e3);
                function L() {
                  for (var b = 0; b < h; b += 2) {
                    var T = x[b], C = x[b + 1];
                    T(C), x[b] = void 0, x[b + 1] = void 0;
                  }
                  h = 0;
                }
                d(L, "flush");
                function O() {
                  try {
                    var b = Function("return this")().require("vertx");
                    return r = b.runOnLoop || b.runOnContext, g();
                  } catch {
                    return m();
                  }
                }
                d(O, "attemptVertx");
                var R = void 0;
                f ? R = p() : e ? R = y() : c ? R = E() : s === void 0 ? R = O() : R = m();
                function I(b, T) {
                  var C = this, M = new this.constructor(F);
                  M[j] === void 0 && ue(M);
                  var B = C._state;
                  if (B) {
                    var k = arguments[B - 1];
                    l(function() {
                      return oe(B, M, k, C._result);
                    });
                  } else
                    J(C, M, b, T);
                  return M;
                }
                d(I, "then");
                function U(b) {
                  var T = this;
                  if (b && typeof b == "object" && b.constructor === T)
                    return b;
                  var C = new T(F);
                  return Z(C, b), C;
                }
                d(U, "resolve$1");
                var j = Math.random().toString(36).substring(2);
                function F() {
                }
                d(F, "noop");
                var N = void 0, W = 1, w = 2;
                function G() {
                  return new TypeError("You cannot resolve a promise with itself");
                }
                d(G, "selfFulfillment");
                function ee() {
                  return new TypeError("A promises callback cannot return that same promise.");
                }
                d(ee, "cannotReturnOwn");
                function K(b, T, C, M) {
                  try {
                    b.call(T, C, M);
                  } catch (B) {
                    return B;
                  }
                }
                d(K, "tryThen");
                function V(b, T, C) {
                  l(function(M) {
                    var B = !1, k = K(C, T, function(H) {
                      B || (B = !0, T !== H ? Z(M, H) : z(M, H));
                    }, function(H) {
                      B || (B = !0, P(M, H));
                    }, "Settle: " + (M._label || " unknown promise"));
                    !B && k && (B = !0, P(M, k));
                  }, b);
                }
                d(V, "handleForeignThenable");
                function $(b, T) {
                  T._state === W ? z(b, T._result) : T._state === w ? P(b, T._result) : J(T, void 0, function(C) {
                    return Z(b, C);
                  }, function(C) {
                    return P(b, C);
                  });
                }
                d($, "handleOwnThenable");
                function X(b, T, C) {
                  T.constructor === b.constructor && C === I && T.constructor.resolve === U ? $(b, T) : C === void 0 ? z(b, T) : _(C) ? V(b, T, C) : z(b, T);
                }
                d(X, "handleMaybeThenable");
                function Z(b, T) {
                  if (b === T)
                    P(b, G());
                  else if (S(T)) {
                    var C = void 0;
                    try {
                      C = T.then;
                    } catch (M) {
                      P(b, M);
                      return;
                    }
                    X(b, T, C);
                  } else
                    z(b, T);
                }
                d(Z, "resolve");
                function ie(b) {
                  b._onerror && b._onerror(b._result), te(b);
                }
                d(ie, "publishRejection");
                function z(b, T) {
                  b._state === N && (b._result = T, b._state = W, b._subscribers.length !== 0 && l(te, b));
                }
                d(z, "fulfill");
                function P(b, T) {
                  b._state === N && (b._state = w, b._result = T, l(ie, b));
                }
                d(P, "reject");
                function J(b, T, C, M) {
                  var B = b._subscribers, k = B.length;
                  b._onerror = null, B[k] = T, B[k + W] = C, B[k + w] = M, k === 0 && b._state && l(te, b);
                }
                d(J, "subscribe");
                function te(b) {
                  var T = b._subscribers, C = b._state;
                  if (T.length !== 0) {
                    for (var M = void 0, B = void 0, k = b._result, H = 0; H < T.length; H += 3)
                      M = T[H], B = T[H + C], M ? oe(C, M, B, k) : B(k);
                    b._subscribers.length = 0;
                  }
                }
                d(te, "publish");
                function oe(b, T, C, M) {
                  var B = _(C), k = void 0, H = void 0, le = !0;
                  if (B) {
                    try {
                      k = C(M);
                    } catch (he) {
                      le = !1, H = he;
                    }
                    if (T === k) {
                      P(T, ee());
                      return;
                    }
                  } else
                    k = M;
                  T._state !== N || (B && le ? Z(T, k) : le === !1 ? P(T, H) : b === W ? z(T, k) : b === w && P(T, k));
                }
                d(oe, "invokeCallback");
                function ne(b, T) {
                  try {
                    T(/* @__PURE__ */ d(function(M) {
                      Z(b, M);
                    }, "resolvePromise"), /* @__PURE__ */ d(function(M) {
                      P(b, M);
                    }, "rejectPromise"));
                  } catch (C) {
                    P(b, C);
                  }
                }
                d(ne, "initializePromise");
                var se = 0;
                function ae() {
                  return se++;
                }
                d(ae, "nextId");
                function ue(b) {
                  b[j] = se++, b._state = void 0, b._result = void 0, b._subscribers = [];
                }
                d(ue, "makePromise");
                function re() {
                  return new Error("Array Methods must be provided an Array");
                }
                d(re, "validationError");
                var q = function() {
                  function b(T, C) {
                    this._instanceConstructor = T, this.promise = new T(F), this.promise[j] || ue(this.promise), o(C) ? (this.length = C.length, this._remaining = C.length, this._result = new Array(this.length), this.length === 0 ? z(this.promise, this._result) : (this.length = this.length || 0, this._enumerate(C), this._remaining === 0 && z(this.promise, this._result))) : P(this.promise, re());
                  }
                  return d(b, "Enumerator"), b.prototype._enumerate = /* @__PURE__ */ d(function(C) {
                    for (var M = 0; this._state === N && M < C.length; M++)
                      this._eachEntry(C[M], M);
                  }, "_enumerate"), b.prototype._eachEntry = /* @__PURE__ */ d(function(C, M) {
                    var B = this._instanceConstructor, k = B.resolve;
                    if (k === U) {
                      var H = void 0, le = void 0, he = !1;
                      try {
                        H = C.then;
                      } catch (ve) {
                        he = !0, le = ve;
                      }
                      if (H === I && C._state !== N)
                        this._settledAt(C._state, M, C._result);
                      else if (typeof H != "function")
                        this._remaining--, this._result[M] = C;
                      else if (B === Y) {
                        var me = new B(F);
                        he ? P(me, le) : X(me, C, H), this._willSettleAt(me, M);
                      } else
                        this._willSettleAt(new B(function(ve) {
                          return ve(C);
                        }), M);
                    } else
                      this._willSettleAt(k(C), M);
                  }, "_eachEntry"), b.prototype._settledAt = /* @__PURE__ */ d(function(C, M, B) {
                    var k = this.promise;
                    k._state === N && (this._remaining--, C === w ? P(k, B) : this._result[M] = B), this._remaining === 0 && z(k, this._result);
                  }, "_settledAt"), b.prototype._willSettleAt = /* @__PURE__ */ d(function(C, M) {
                    var B = this;
                    J(C, void 0, function(k) {
                      return B._settledAt(W, M, k);
                    }, function(k) {
                      return B._settledAt(w, M, k);
                    });
                  }, "_willSettleAt"), b;
                }();
                function fe(b) {
                  return new q(this, b).promise;
                }
                d(fe, "all");
                function de(b) {
                  var T = this;
                  return o(b) ? new T(function(C, M) {
                    for (var B = b.length, k = 0; k < B; k++)
                      T.resolve(b[k]).then(C, M);
                  }) : new T(function(C, M) {
                    return M(new TypeError("You must pass an array to race."));
                  });
                }
                d(de, "race");
                function ye(b) {
                  var T = this, C = new T(F);
                  return P(C, b), C;
                }
                d(ye, "reject$1");
                function Se() {
                  throw new TypeError("You must pass a resolver function as the first argument to the promise constructor");
                }
                d(Se, "needsResolver");
                function Le() {
                  throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.");
                }
                d(Le, "needsNew");
                var Y = function() {
                  function b(T) {
                    this[j] = ae(), this._result = this._state = void 0, this._subscribers = [], F !== T && (typeof T != "function" && Se(), this instanceof b ? ne(this, T) : Le());
                  }
                  return d(b, "Promise"), b.prototype.catch = /* @__PURE__ */ d(function(C) {
                    return this.then(null, C);
                  }, "_catch"), b.prototype.finally = /* @__PURE__ */ d(function(C) {
                    var M = this, B = M.constructor;
                    return _(C) ? M.then(function(k) {
                      return B.resolve(C()).then(function() {
                        return k;
                      });
                    }, function(k) {
                      return B.resolve(C()).then(function() {
                        throw k;
                      });
                    }) : M.then(C, C);
                  }, "_finally"), b;
                }();
                Y.prototype.then = I, Y.all = fe, Y.race = de, Y.resolve = U, Y.reject = ye, Y._setScheduler = i, Y._setAsap = t, Y._asap = l;
                function Ae() {
                  var b = void 0;
                  if (typeof v.g < "u")
                    b = v.g;
                  else if (typeof self < "u")
                    b = self;
                  else
                    try {
                      b = Function("return this")();
                    } catch {
                      throw new Error("polyfill failed because global object is unavailable in this environment");
                    }
                  var T = b.Promise;
                  if (T) {
                    var C = null;
                    try {
                      C = Object.prototype.toString.call(T.resolve());
                    } catch {
                    }
                    if (C === "[object Promise]" && !T.cast)
                      return;
                  }
                  b.Promise = Y;
                }
                return d(Ae, "polyfill"), Y.polyfill = Ae, Y.Promise = Y, Y;
              });
            }, "./node_modules/es6-promise/dist/es6-promise.js")
          ),
          /***/
          "./node_modules/events/events.js": (
            /*!***************************************!*\
              !*** ./node_modules/events/events.js ***!
              \***************************************/
            /***/
            /* @__PURE__ */ d(function(D) {
              var A = typeof Reflect == "object" ? Reflect : null, v = A && typeof A.apply == "function" ? A.apply : /* @__PURE__ */ d(function(m, x, L) {
                return Function.prototype.apply.call(m, x, L);
              }, "ReflectApply"), S;
              A && typeof A.ownKeys == "function" ? S = A.ownKeys : Object.getOwnPropertySymbols ? S = /* @__PURE__ */ d(function(m) {
                return Object.getOwnPropertyNames(m).concat(Object.getOwnPropertySymbols(m));
              }, "ReflectOwnKeys") : S = /* @__PURE__ */ d(function(m) {
                return Object.getOwnPropertyNames(m);
              }, "ReflectOwnKeys");
              function _(E) {
                console && console.warn && console.warn(E);
              }
              d(_, "ProcessEmitWarning");
              var u = Number.isNaN || /* @__PURE__ */ d(function(m) {
                return m !== m;
              }, "NumberIsNaN");
              function o() {
                o.init.call(this);
              }
              d(o, "EventEmitter"), D.exports = o, D.exports.once = p, o.EventEmitter = o, o.prototype._events = void 0, o.prototype._eventsCount = 0, o.prototype._maxListeners = void 0;
              var h = 10;
              function r(E) {
                if (typeof E != "function")
                  throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof E);
              }
              d(r, "checkListener"), Object.defineProperty(o, "defaultMaxListeners", {
                enumerable: !0,
                get: /* @__PURE__ */ d(function() {
                  return h;
                }, "get"),
                set: /* @__PURE__ */ d(function(E) {
                  if (typeof E != "number" || E < 0 || u(E))
                    throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + E + ".");
                  h = E;
                }, "set")
              }), o.init = function() {
                (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
              }, o.prototype.setMaxListeners = /* @__PURE__ */ d(function(m) {
                if (typeof m != "number" || m < 0 || u(m))
                  throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + m + ".");
                return this._maxListeners = m, this;
              }, "setMaxListeners");
              function a(E) {
                return E._maxListeners === void 0 ? o.defaultMaxListeners : E._maxListeners;
              }
              d(a, "_getMaxListeners"), o.prototype.getMaxListeners = /* @__PURE__ */ d(function() {
                return a(this);
              }, "getMaxListeners"), o.prototype.emit = /* @__PURE__ */ d(function(m) {
                for (var x = [], L = 1; L < arguments.length; L++)
                  x.push(arguments[L]);
                var O = m === "error", R = this._events;
                if (R !== void 0)
                  O = O && R.error === void 0;
                else if (!O)
                  return !1;
                if (O) {
                  var I;
                  if (x.length > 0 && (I = x[0]), I instanceof Error)
                    throw I;
                  var U = new Error("Unhandled error." + (I ? " (" + I.message + ")" : ""));
                  throw U.context = I, U;
                }
                var j = R[m];
                if (j === void 0)
                  return !1;
                if (typeof j == "function")
                  v(j, this, x);
                else
                  for (var F = j.length, N = e(j, F), L = 0; L < F; ++L)
                    v(N[L], this, x);
                return !0;
              }, "emit");
              function l(E, m, x, L) {
                var O, R, I;
                if (r(x), R = E._events, R === void 0 ? (R = E._events = /* @__PURE__ */ Object.create(null), E._eventsCount = 0) : (R.newListener !== void 0 && (E.emit("newListener", m, x.listener ? x.listener : x), R = E._events), I = R[m]), I === void 0)
                  I = R[m] = x, ++E._eventsCount;
                else if (typeof I == "function" ? I = R[m] = L ? [x, I] : [I, x] : L ? I.unshift(x) : I.push(x), O = a(E), O > 0 && I.length > O && !I.warned) {
                  I.warned = !0;
                  var U = new Error("Possible EventEmitter memory leak detected. " + I.length + " " + String(m) + " listeners added. Use emitter.setMaxListeners() to increase limit");
                  U.name = "MaxListenersExceededWarning", U.emitter = E, U.type = m, U.count = I.length, _(U);
                }
                return E;
              }
              d(l, "_addListener"), o.prototype.addListener = /* @__PURE__ */ d(function(m, x) {
                return l(this, m, x, !1);
              }, "addListener"), o.prototype.on = o.prototype.addListener, o.prototype.prependListener = /* @__PURE__ */ d(function(m, x) {
                return l(this, m, x, !0);
              }, "prependListener");
              function i() {
                if (!this.fired)
                  return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
              }
              d(i, "onceWrapper");
              function t(E, m, x) {
                var L = { fired: !1, wrapFn: void 0, target: E, type: m, listener: x }, O = i.bind(L);
                return O.listener = x, L.wrapFn = O, O;
              }
              d(t, "_onceWrap"), o.prototype.once = /* @__PURE__ */ d(function(m, x) {
                return r(x), this.on(m, t(this, m, x)), this;
              }, "once"), o.prototype.prependOnceListener = /* @__PURE__ */ d(function(m, x) {
                return r(x), this.prependListener(m, t(this, m, x)), this;
              }, "prependOnceListener"), o.prototype.removeListener = /* @__PURE__ */ d(function(m, x) {
                var L, O, R, I, U;
                if (r(x), O = this._events, O === void 0)
                  return this;
                if (L = O[m], L === void 0)
                  return this;
                if (L === x || L.listener === x)
                  --this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : (delete O[m], O.removeListener && this.emit("removeListener", m, L.listener || x));
                else if (typeof L != "function") {
                  for (R = -1, I = L.length - 1; I >= 0; I--)
                    if (L[I] === x || L[I].listener === x) {
                      U = L[I].listener, R = I;
                      break;
                    }
                  if (R < 0)
                    return this;
                  R === 0 ? L.shift() : f(L, R), L.length === 1 && (O[m] = L[0]), O.removeListener !== void 0 && this.emit("removeListener", m, U || x);
                }
                return this;
              }, "removeListener"), o.prototype.off = o.prototype.removeListener, o.prototype.removeAllListeners = /* @__PURE__ */ d(function(m) {
                var x, L, O;
                if (L = this._events, L === void 0)
                  return this;
                if (L.removeListener === void 0)
                  return arguments.length === 0 ? (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0) : L[m] !== void 0 && (--this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : delete L[m]), this;
                if (arguments.length === 0) {
                  var R = Object.keys(L), I;
                  for (O = 0; O < R.length; ++O)
                    I = R[O], I !== "removeListener" && this.removeAllListeners(I);
                  return this.removeAllListeners("removeListener"), this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0, this;
                }
                if (x = L[m], typeof x == "function")
                  this.removeListener(m, x);
                else if (x !== void 0)
                  for (O = x.length - 1; O >= 0; O--)
                    this.removeListener(m, x[O]);
                return this;
              }, "removeAllListeners");
              function s(E, m, x) {
                var L = E._events;
                if (L === void 0)
                  return [];
                var O = L[m];
                return O === void 0 ? [] : typeof O == "function" ? x ? [O.listener || O] : [O] : x ? c(O) : e(O, O.length);
              }
              d(s, "_listeners"), o.prototype.listeners = /* @__PURE__ */ d(function(m) {
                return s(this, m, !0);
              }, "listeners"), o.prototype.rawListeners = /* @__PURE__ */ d(function(m) {
                return s(this, m, !1);
              }, "rawListeners"), o.listenerCount = function(E, m) {
                return typeof E.listenerCount == "function" ? E.listenerCount(m) : n.call(E, m);
              }, o.prototype.listenerCount = n;
              function n(E) {
                var m = this._events;
                if (m !== void 0) {
                  var x = m[E];
                  if (typeof x == "function")
                    return 1;
                  if (x !== void 0)
                    return x.length;
                }
                return 0;
              }
              d(n, "listenerCount"), o.prototype.eventNames = /* @__PURE__ */ d(function() {
                return this._eventsCount > 0 ? S(this._events) : [];
              }, "eventNames");
              function e(E, m) {
                for (var x = new Array(m), L = 0; L < m; ++L)
                  x[L] = E[L];
                return x;
              }
              d(e, "arrayClone");
              function f(E, m) {
                for (; m + 1 < E.length; m++)
                  E[m] = E[m + 1];
                E.pop();
              }
              d(f, "spliceOne");
              function c(E) {
                for (var m = new Array(E.length), x = 0; x < m.length; ++x)
                  m[x] = E[x].listener || E[x];
                return m;
              }
              d(c, "unwrapListeners");
              function p(E, m) {
                return new Promise(function(x, L) {
                  function O(I) {
                    E.removeListener(m, R), L(I);
                  }
                  d(O, "errorListener");
                  function R() {
                    typeof E.removeListener == "function" && E.removeListener("error", O), x([].slice.call(arguments));
                  }
                  d(R, "resolver"), y(E, m, R, { once: !0 }), m !== "error" && g(E, O, { once: !0 });
                });
              }
              d(p, "once");
              function g(E, m, x) {
                typeof E.on == "function" && y(E, "error", m, x);
              }
              d(g, "addErrorHandlerIfEventEmitter");
              function y(E, m, x, L) {
                if (typeof E.on == "function")
                  L.once ? E.once(m, x) : E.on(m, x);
                else if (typeof E.addEventListener == "function")
                  E.addEventListener(m, /* @__PURE__ */ d(function O(R) {
                    L.once && E.removeEventListener(m, O), x(R);
                  }, "wrapListener"));
                else
                  throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof E);
              }
              d(y, "eventTargetAgnosticAddListener");
            }, "./node_modules/events/events.js")
          ),
          /***/
          "./node_modules/webworkify-webpack/index.js": (
            /*!**************************************************!*\
              !*** ./node_modules/webworkify-webpack/index.js ***!
              \**************************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              function S(i) {
                var t = {};
                function s(e) {
                  if (t[e])
                    return t[e].exports;
                  var f = t[e] = {
                    /******/
                    i: e,
                    /******/
                    l: !1,
                    /******/
                    exports: {}
                    /******/
                  };
                  return i[e].call(f.exports, f, f.exports, s), f.l = !0, f.exports;
                }
                d(s, "__nested_webpack_require_164__"), s.m = i, s.c = t, s.i = function(e) {
                  return e;
                }, s.d = function(e, f, c) {
                  s.o(e, f) || Object.defineProperty(e, f, {
                    /******/
                    configurable: !1,
                    /******/
                    enumerable: !0,
                    /******/
                    get: c
                    /******/
                  });
                }, s.r = function(e) {
                  Object.defineProperty(e, "__esModule", { value: !0 });
                }, s.n = function(e) {
                  var f = e && e.__esModule ? (
                    /******/
                    /* @__PURE__ */ d(function() {
                      return e.default;
                    }, "getDefault")
                  ) : (
                    /******/
                    /* @__PURE__ */ d(function() {
                      return e;
                    }, "getModuleExports")
                  );
                  return s.d(f, "a", f), f;
                }, s.o = function(e, f) {
                  return Object.prototype.hasOwnProperty.call(e, f);
                }, s.p = "/", s.oe = function(e) {
                  throw console.error(e), e;
                };
                var n = s(s.s = ENTRY_MODULE);
                return n.default || n;
              }
              d(S, "webpackBootstrapFunc");
              var _ = "[\\.|\\-|\\+|\\w|/|@]+", u = "\\(\\s*(/\\*.*?\\*/)?\\s*.*?(" + _ + ").*?\\)";
              function o(i) {
                return (i + "").replace(/[.?*+^$[\]\\(){}|-]/g, "\\$&");
              }
              d(o, "quoteRegExp");
              function h(i) {
                return !isNaN(1 * i);
              }
              d(h, "isNumeric");
              function r(i, t, s) {
                var n = {};
                n[s] = [];
                var e = t.toString(), f = e.match(/^function\s?\w*\(\w+,\s*\w+,\s*(\w+)\)/);
                if (!f)
                  return n;
                for (var c = f[1], p = new RegExp("(\\\\n|\\W)" + o(c) + u, "g"), g; g = p.exec(e); )
                  g[3] !== "dll-reference" && n[s].push(g[3]);
                for (p = new RegExp("\\(" + o(c) + '\\("(dll-reference\\s(' + _ + '))"\\)\\)' + u, "g"); g = p.exec(e); )
                  i[g[2]] || (n[s].push(g[1]), i[g[2]] = v(g[1]).m), n[g[2]] = n[g[2]] || [], n[g[2]].push(g[4]);
                for (var y = Object.keys(n), E = 0; E < y.length; E++)
                  for (var m = 0; m < n[y[E]].length; m++)
                    h(n[y[E]][m]) && (n[y[E]][m] = 1 * n[y[E]][m]);
                return n;
              }
              d(r, "getModuleDependencies");
              function a(i) {
                var t = Object.keys(i);
                return t.reduce(function(s, n) {
                  return s || i[n].length > 0;
                }, !1);
              }
              d(a, "hasValuesInQueues");
              function l(i, t) {
                for (var s = {
                  main: [t]
                }, n = {
                  main: []
                }, e = {
                  main: {}
                }; a(s); )
                  for (var f = Object.keys(s), c = 0; c < f.length; c++) {
                    var p = f[c], g = s[p], y = g.pop();
                    if (e[p] = e[p] || {}, !(e[p][y] || !i[p][y])) {
                      e[p][y] = !0, n[p] = n[p] || [], n[p].push(y);
                      for (var E = r(i, i[p][y], p), m = Object.keys(E), x = 0; x < m.length; x++)
                        s[m[x]] = s[m[x]] || [], s[m[x]] = s[m[x]].concat(E[m[x]]);
                    }
                  }
                return n;
              }
              d(l, "getRequiredModules"), D.exports = function(i, t) {
                t = t || {};
                var s = {
                  main: v.m
                }, n = t.all ? { main: Object.keys(s.main) } : l(s, i), e = "";
                Object.keys(n).filter(function(y) {
                  return y !== "main";
                }).forEach(function(y) {
                  for (var E = 0; n[y][E]; )
                    E++;
                  n[y].push(E), s[y][E] = "(function(module, exports, __webpack_require__) { module.exports = __webpack_require__; })", e = e + "var " + y + " = (" + S.toString().replace("ENTRY_MODULE", JSON.stringify(E)) + ")({" + n[y].map(function(m) {
                    return "" + JSON.stringify(m) + ": " + s[y][m].toString();
                  }).join(",") + `});
`;
                }), e = e + "new ((" + S.toString().replace("ENTRY_MODULE", JSON.stringify(i)) + ")({" + n.main.map(function(y) {
                  return "" + JSON.stringify(y) + ": " + s.main[y].toString();
                }).join(",") + "}))(self);";
                var f = new window.Blob([e], { type: "text/javascript" });
                if (t.bare)
                  return f;
                var c = window.URL || window.webkitURL || window.mozURL || window.msURL, p = c.createObjectURL(f), g = new window.Worker(p);
                return g.objectURL = p, g;
              };
            }, "./node_modules/webworkify-webpack/index.js")
          ),
          /***/
          "./src/config.js": (
            /*!***********************!*\
              !*** ./src/config.js ***!
              \***********************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A), v.d(A, {
                /* harmony export */
                defaultConfig: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    S
                  );
                }, "defaultConfig"),
                /* harmony export */
                createDefaultConfig: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    _
                  );
                }, "createDefaultConfig")
                /* harmony export */
              });
              var S = {
                enableWorker: !1,
                enableStashBuffer: !0,
                stashInitialSize: void 0,
                isLive: !1,
                lazyLoad: !0,
                lazyLoadMaxDuration: 3 * 60,
                lazyLoadRecoverDuration: 30,
                deferLoadAfterSourceOpen: !0,
                // autoCleanupSourceBuffer: default as false, leave unspecified
                autoCleanupMaxBackwardDuration: 3 * 60,
                autoCleanupMinBackwardDuration: 2 * 60,
                statisticsInfoReportInterval: 600,
                fixAudioTimestampGap: !0,
                accurateSeek: !1,
                seekType: "range",
                seekParamStart: "bstart",
                seekParamEnd: "bend",
                rangeLoadZeroStart: !1,
                customSeekHandler: void 0,
                reuseRedirectedURL: !1,
                // referrerPolicy: leave as unspecified
                headers: void 0,
                customLoader: void 0
              };
              function _() {
                return Object.assign({}, S);
              }
              d(_, "createDefaultConfig");
            }, "./src/config.js")
          ),
          /***/
          "./src/core/features.js": (
            /*!******************************!*\
              !*** ./src/core/features.js ***!
              \******************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ../io/io-controller.js */
                "./src/io/io-controller.js"
              ), _ = v(
                /*! ../config.js */
                "./src/config.js"
              ), u = (
                /** @class */
                function() {
                  function o() {
                  }
                  return d(o, "Features"), o.supportMSEH264Playback = function() {
                    return window.MediaSource && window.MediaSource.isTypeSupported('video/mp4; codecs="avc1.42E01E,mp4a.40.2"');
                  }, o.supportNetworkStreamIO = function() {
                    var h = new S.default({}, (0, _.createDefaultConfig)()), r = h.loaderType;
                    return h.destroy(), r == "fetch-stream-loader" || r == "xhr-moz-chunked-loader";
                  }, o.getNetworkLoaderTypeName = function() {
                    var h = new S.default({}, (0, _.createDefaultConfig)()), r = h.loaderType;
                    return h.destroy(), r;
                  }, o.supportNativeMediaPlayback = function(h) {
                    o.videoElement == null && (o.videoElement = window.document.createElement("video"));
                    var r = o.videoElement.canPlayType(h);
                    return r === "probably" || r == "maybe";
                  }, o.getFeatureList = function() {
                    var h = {
                      mseFlvPlayback: !1,
                      mseLiveFlvPlayback: !1,
                      networkStreamIO: !1,
                      networkLoaderName: "",
                      nativeMP4H264Playback: !1,
                      nativeWebmVP8Playback: !1,
                      nativeWebmVP9Playback: !1
                    };
                    return h.mseFlvPlayback = o.supportMSEH264Playback(), h.networkStreamIO = o.supportNetworkStreamIO(), h.networkLoaderName = o.getNetworkLoaderTypeName(), h.mseLiveFlvPlayback = h.mseFlvPlayback && h.networkStreamIO, h.nativeMP4H264Playback = o.supportNativeMediaPlayback('video/mp4; codecs="avc1.42001E, mp4a.40.2"'), h.nativeWebmVP8Playback = o.supportNativeMediaPlayback('video/webm; codecs="vp8.0, vorbis"'), h.nativeWebmVP9Playback = o.supportNativeMediaPlayback('video/webm; codecs="vp9"'), h;
                  }, o;
                }()
              );
              A.default = u;
            }, "./src/core/features.js")
          ),
          /***/
          "./src/core/media-info.js": (
            /*!********************************!*\
              !*** ./src/core/media-info.js ***!
              \********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = (
                /** @class */
                function() {
                  function _() {
                    this.mimeType = null, this.duration = null, this.hasAudio = null, this.hasVideo = null, this.audioCodec = null, this.videoCodec = null, this.audioDataRate = null, this.videoDataRate = null, this.audioSampleRate = null, this.audioChannelCount = null, this.width = null, this.height = null, this.fps = null, this.profile = null, this.level = null, this.refFrames = null, this.chromaFormat = null, this.sarNum = null, this.sarDen = null, this.metadata = null, this.segments = null, this.segmentCount = null, this.hasKeyframesIndex = null, this.keyframesIndex = null;
                  }
                  return d(_, "MediaInfo"), _.prototype.isComplete = function() {
                    var u = this.hasAudio === !1 || this.hasAudio === !0 && this.audioCodec != null && this.audioSampleRate != null && this.audioChannelCount != null, o = this.hasVideo === !1 || this.hasVideo === !0 && this.videoCodec != null && this.width != null && this.height != null && this.fps != null && this.profile != null && this.level != null && this.refFrames != null && this.chromaFormat != null && this.sarNum != null && this.sarDen != null;
                    return this.mimeType != null && this.duration != null && this.metadata != null && this.hasKeyframesIndex != null && u && o;
                  }, _.prototype.isSeekable = function() {
                    return this.hasKeyframesIndex === !0;
                  }, _.prototype.getNearestKeyframe = function(u) {
                    if (this.keyframesIndex == null)
                      return null;
                    var o = this.keyframesIndex, h = this._search(o.times, u);
                    return {
                      index: h,
                      milliseconds: o.times[h],
                      fileposition: o.filepositions[h]
                    };
                  }, _.prototype._search = function(u, o) {
                    var h = 0, r = u.length - 1, a = 0, l = 0, i = r;
                    for (o < u[0] && (h = 0, l = i + 1); l <= i; )
                      if (a = l + Math.floor((i - l) / 2), a === r || o >= u[a] && o < u[a + 1]) {
                        h = a;
                        break;
                      } else u[a] < o ? l = a + 1 : i = a - 1;
                    return h;
                  }, _;
                }()
              );
              A.default = S;
            }, "./src/core/media-info.js")
          ),
          /***/
          "./src/core/media-segment-info.js": (
            /*!****************************************!*\
              !*** ./src/core/media-segment-info.js ***!
              \****************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A), v.d(A, {
                /* harmony export */
                SampleInfo: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    S
                  );
                }, "SampleInfo"),
                /* harmony export */
                MediaSegmentInfo: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    _
                  );
                }, "MediaSegmentInfo"),
                /* harmony export */
                IDRSampleList: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    u
                  );
                }, "IDRSampleList"),
                /* harmony export */
                MediaSegmentInfoList: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    o
                  );
                }, "MediaSegmentInfoList")
                /* harmony export */
              });
              var S = (
                /** @class */
                function() {
                  function h(r, a, l, i, t) {
                    this.dts = r, this.pts = a, this.duration = l, this.originalDts = i, this.isSyncPoint = t, this.fileposition = null;
                  }
                  return d(h, "SampleInfo"), h;
                }()
              ), _ = (
                /** @class */
                function() {
                  function h() {
                    this.beginDts = 0, this.endDts = 0, this.beginPts = 0, this.endPts = 0, this.originalBeginDts = 0, this.originalEndDts = 0, this.syncPoints = [], this.firstSample = null, this.lastSample = null;
                  }
                  return d(h, "MediaSegmentInfo"), h.prototype.appendSyncPoint = function(r) {
                    r.isSyncPoint = !0, this.syncPoints.push(r);
                  }, h;
                }()
              ), u = (
                /** @class */
                function() {
                  function h() {
                    this._list = [];
                  }
                  return d(h, "IDRSampleList"), h.prototype.clear = function() {
                    this._list = [];
                  }, h.prototype.appendArray = function(r) {
                    var a = this._list;
                    r.length !== 0 && (a.length > 0 && r[0].originalDts < a[a.length - 1].originalDts && this.clear(), Array.prototype.push.apply(a, r));
                  }, h.prototype.getLastSyncPointBeforeDts = function(r) {
                    if (this._list.length == 0)
                      return null;
                    var a = this._list, l = 0, i = a.length - 1, t = 0, s = 0, n = i;
                    for (r < a[0].dts && (l = 0, s = n + 1); s <= n; )
                      if (t = s + Math.floor((n - s) / 2), t === i || r >= a[t].dts && r < a[t + 1].dts) {
                        l = t;
                        break;
                      } else a[t].dts < r ? s = t + 1 : n = t - 1;
                    return this._list[l];
                  }, h;
                }()
              ), o = (
                /** @class */
                function() {
                  function h(r) {
                    this._type = r, this._list = [], this._lastAppendLocation = -1;
                  }
                  return d(h, "MediaSegmentInfoList"), Object.defineProperty(h.prototype, "type", {
                    get: /* @__PURE__ */ d(function() {
                      return this._type;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h.prototype, "length", {
                    get: /* @__PURE__ */ d(function() {
                      return this._list.length;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), h.prototype.isEmpty = function() {
                    return this._list.length === 0;
                  }, h.prototype.clear = function() {
                    this._list = [], this._lastAppendLocation = -1;
                  }, h.prototype._searchNearestSegmentBefore = function(r) {
                    var a = this._list;
                    if (a.length === 0)
                      return -2;
                    var l = a.length - 1, i = 0, t = 0, s = l, n = 0;
                    if (r < a[0].originalBeginDts)
                      return n = -1, n;
                    for (; t <= s; )
                      if (i = t + Math.floor((s - t) / 2), i === l || r > a[i].lastSample.originalDts && r < a[i + 1].originalBeginDts) {
                        n = i;
                        break;
                      } else a[i].originalBeginDts < r ? t = i + 1 : s = i - 1;
                    return n;
                  }, h.prototype._searchNearestSegmentAfter = function(r) {
                    return this._searchNearestSegmentBefore(r) + 1;
                  }, h.prototype.append = function(r) {
                    var a = this._list, l = r, i = this._lastAppendLocation, t = 0;
                    i !== -1 && i < a.length && l.originalBeginDts >= a[i].lastSample.originalDts && (i === a.length - 1 || i < a.length - 1 && l.originalBeginDts < a[i + 1].originalBeginDts) ? t = i + 1 : a.length > 0 && (t = this._searchNearestSegmentBefore(l.originalBeginDts) + 1), this._lastAppendLocation = t, this._list.splice(t, 0, l);
                  }, h.prototype.getLastSegmentBefore = function(r) {
                    var a = this._searchNearestSegmentBefore(r);
                    return a >= 0 ? this._list[a] : null;
                  }, h.prototype.getLastSampleBefore = function(r) {
                    var a = this.getLastSegmentBefore(r);
                    return a != null ? a.lastSample : null;
                  }, h.prototype.getLastSyncPointBefore = function(r) {
                    for (var a = this._searchNearestSegmentBefore(r), l = this._list[a].syncPoints; l.length === 0 && a > 0; )
                      a--, l = this._list[a].syncPoints;
                    return l.length > 0 ? l[l.length - 1] : null;
                  }, h;
                }()
              );
            }, "./src/core/media-segment-info.js")
          ),
          /***/
          "./src/core/mse-controller.js": (
            /*!************************************!*\
              !*** ./src/core/mse-controller.js ***!
              \************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! events */
                "./node_modules/events/events.js"
              ), _ = /* @__PURE__ */ v.n(S), u = v(
                /*! ../utils/logger.js */
                "./src/utils/logger.js"
              ), o = v(
                /*! ../utils/browser.js */
                "./src/utils/browser.js"
              ), h = v(
                /*! ./mse-events.js */
                "./src/core/mse-events.js"
              ), r = v(
                /*! ./media-segment-info.js */
                "./src/core/media-segment-info.js"
              ), a = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), l = (
                /** @class */
                function() {
                  function i(t) {
                    this.TAG = "MSEController", this._config = t, this._emitter = new (_())(), this._config.isLive && this._config.autoCleanupSourceBuffer == null && (this._config.autoCleanupSourceBuffer = !0), this.e = {
                      onSourceOpen: this._onSourceOpen.bind(this),
                      onSourceEnded: this._onSourceEnded.bind(this),
                      onSourceClose: this._onSourceClose.bind(this),
                      onSourceBufferError: this._onSourceBufferError.bind(this),
                      onSourceBufferUpdateEnd: this._onSourceBufferUpdateEnd.bind(this)
                    }, this._mediaSource = null, this._mediaSourceObjectURL = null, this._mediaElement = null, this._isBufferFull = !1, this._hasPendingEos = !1, this._requireSetMediaDuration = !1, this._pendingMediaDuration = 0, this._pendingSourceBufferInit = [], this._mimeTypes = {
                      video: null,
                      audio: null
                    }, this._sourceBuffers = {
                      video: null,
                      audio: null
                    }, this._lastInitSegments = {
                      video: null,
                      audio: null
                    }, this._pendingSegments = {
                      video: [],
                      audio: []
                    }, this._pendingRemoveRanges = {
                      video: [],
                      audio: []
                    }, this._idrList = new r.IDRSampleList();
                  }
                  return d(i, "MSEController"), i.prototype.destroy = function() {
                    (this._mediaElement || this._mediaSource) && this.detachMediaElement(), this.e = null, this._emitter.removeAllListeners(), this._emitter = null;
                  }, i.prototype.on = function(t, s) {
                    this._emitter.addListener(t, s);
                  }, i.prototype.off = function(t, s) {
                    this._emitter.removeListener(t, s);
                  }, i.prototype.attachMediaElement = function(t) {
                    if (this._mediaSource)
                      throw new a.IllegalStateException("MediaSource has been attached to an HTMLMediaElement!");
                    var s = this._mediaSource = new window.MediaSource();
                    s.addEventListener("sourceopen", this.e.onSourceOpen), s.addEventListener("sourceended", this.e.onSourceEnded), s.addEventListener("sourceclose", this.e.onSourceClose), this._mediaElement = t, this._mediaSourceObjectURL = window.URL.createObjectURL(this._mediaSource), t.src = this._mediaSourceObjectURL;
                  }, i.prototype.detachMediaElement = function() {
                    if (this._mediaSource) {
                      var t = this._mediaSource;
                      for (var s in this._sourceBuffers) {
                        var n = this._pendingSegments[s];
                        n.splice(0, n.length), this._pendingSegments[s] = null, this._pendingRemoveRanges[s] = null, this._lastInitSegments[s] = null;
                        var e = this._sourceBuffers[s];
                        if (e) {
                          if (t.readyState !== "closed") {
                            try {
                              t.removeSourceBuffer(e);
                            } catch (f) {
                              u.default.e(this.TAG, f.message);
                            }
                            e.removeEventListener("error", this.e.onSourceBufferError), e.removeEventListener("updateend", this.e.onSourceBufferUpdateEnd);
                          }
                          this._mimeTypes[s] = null, this._sourceBuffers[s] = null;
                        }
                      }
                      if (t.readyState === "open")
                        try {
                          t.endOfStream();
                        } catch (f) {
                          u.default.e(this.TAG, f.message);
                        }
                      t.removeEventListener("sourceopen", this.e.onSourceOpen), t.removeEventListener("sourceended", this.e.onSourceEnded), t.removeEventListener("sourceclose", this.e.onSourceClose), this._pendingSourceBufferInit = [], this._isBufferFull = !1, this._idrList.clear(), this._mediaSource = null;
                    }
                    this._mediaElement && (this._mediaElement.src = "", this._mediaElement.removeAttribute("src"), this._mediaElement = null), this._mediaSourceObjectURL && (window.URL.revokeObjectURL(this._mediaSourceObjectURL), this._mediaSourceObjectURL = null);
                  }, i.prototype.appendInitSegment = function(t, s) {
                    if (!this._mediaSource || this._mediaSource.readyState !== "open") {
                      this._pendingSourceBufferInit.push(t), this._pendingSegments[t.type].push(t);
                      return;
                    }
                    var n = t, e = "" + n.container;
                    n.codec && n.codec.length > 0 && (e += ";codecs=" + n.codec);
                    var f = !1;
                    if (u.default.v(this.TAG, "Received Initialization Segment, mimeType: " + e), this._lastInitSegments[n.type] = n, e !== this._mimeTypes[n.type]) {
                      if (this._mimeTypes[n.type])
                        u.default.v(this.TAG, "Notice: " + n.type + " mimeType changed, origin: " + this._mimeTypes[n.type] + ", target: " + e);
                      else {
                        f = !0;
                        try {
                          var c = this._sourceBuffers[n.type] = this._mediaSource.addSourceBuffer(e);
                          c.addEventListener("error", this.e.onSourceBufferError), c.addEventListener("updateend", this.e.onSourceBufferUpdateEnd);
                        } catch (p) {
                          u.default.e(this.TAG, p.message), this._emitter.emit(h.default.ERROR, { code: p.code, msg: p.message });
                          return;
                        }
                      }
                      this._mimeTypes[n.type] = e;
                    }
                    s || this._pendingSegments[n.type].push(n), f || this._sourceBuffers[n.type] && !this._sourceBuffers[n.type].updating && this._doAppendSegments(), o.default.safari && n.container === "audio/mpeg" && n.mediaDuration > 0 && (this._requireSetMediaDuration = !0, this._pendingMediaDuration = n.mediaDuration / 1e3, this._updateMediaSourceDuration());
                  }, i.prototype.appendMediaSegment = function(t) {
                    var s = t;
                    this._pendingSegments[s.type].push(s), this._config.autoCleanupSourceBuffer && this._needCleanupSourceBuffer() && this._doCleanupSourceBuffer();
                    var n = this._sourceBuffers[s.type];
                    n && !n.updating && !this._hasPendingRemoveRanges() && this._doAppendSegments();
                  }, i.prototype.seek = function(t) {
                    for (var s in this._sourceBuffers)
                      if (this._sourceBuffers[s]) {
                        var n = this._sourceBuffers[s];
                        if (this._mediaSource.readyState === "open")
                          try {
                            n.abort();
                          } catch (y) {
                            u.default.e(this.TAG, y.message);
                          }
                        this._idrList.clear();
                        var e = this._pendingSegments[s];
                        if (e.splice(0, e.length), this._mediaSource.readyState !== "closed") {
                          for (var f = 0; f < n.buffered.length; f++) {
                            var c = n.buffered.start(f), p = n.buffered.end(f);
                            this._pendingRemoveRanges[s].push({ start: c, end: p });
                          }
                          if (n.updating || this._doRemoveRanges(), o.default.safari) {
                            var g = this._lastInitSegments[s];
                            g && (this._pendingSegments[s].push(g), n.updating || this._doAppendSegments());
                          }
                        }
                      }
                  }, i.prototype.endOfStream = function() {
                    var t = this._mediaSource, s = this._sourceBuffers;
                    if (!t || t.readyState !== "open") {
                      t && t.readyState === "closed" && this._hasPendingSegments() && (this._hasPendingEos = !0);
                      return;
                    }
                    s.video && s.video.updating || s.audio && s.audio.updating ? this._hasPendingEos = !0 : (this._hasPendingEos = !1, t.endOfStream());
                  }, i.prototype.getNearestKeyframe = function(t) {
                    return this._idrList.getLastSyncPointBeforeDts(t);
                  }, i.prototype._needCleanupSourceBuffer = function() {
                    if (!this._config.autoCleanupSourceBuffer)
                      return !1;
                    var t = this._mediaElement.currentTime;
                    for (var s in this._sourceBuffers) {
                      var n = this._sourceBuffers[s];
                      if (n) {
                        var e = n.buffered;
                        if (e.length >= 1 && t - e.start(0) >= this._config.autoCleanupMaxBackwardDuration)
                          return !0;
                      }
                    }
                    return !1;
                  }, i.prototype._doCleanupSourceBuffer = function() {
                    var t = this._mediaElement.currentTime;
                    for (var s in this._sourceBuffers) {
                      var n = this._sourceBuffers[s];
                      if (n) {
                        for (var e = n.buffered, f = !1, c = 0; c < e.length; c++) {
                          var p = e.start(c), g = e.end(c);
                          if (p <= t && t < g + 3) {
                            if (t - p >= this._config.autoCleanupMaxBackwardDuration) {
                              f = !0;
                              var y = t - this._config.autoCleanupMinBackwardDuration;
                              this._pendingRemoveRanges[s].push({ start: p, end: y });
                            }
                          } else g < t && (f = !0, this._pendingRemoveRanges[s].push({ start: p, end: g }));
                        }
                        f && !n.updating && this._doRemoveRanges();
                      }
                    }
                  }, i.prototype._updateMediaSourceDuration = function() {
                    var t = this._sourceBuffers;
                    if (!(this._mediaElement.readyState === 0 || this._mediaSource.readyState !== "open") && !(t.video && t.video.updating || t.audio && t.audio.updating)) {
                      var s = this._mediaSource.duration, n = this._pendingMediaDuration;
                      n > 0 && (isNaN(s) || n > s) && (u.default.v(this.TAG, "Update MediaSource duration from " + s + " to " + n), this._mediaSource.duration = n), this._requireSetMediaDuration = !1, this._pendingMediaDuration = 0;
                    }
                  }, i.prototype._doRemoveRanges = function() {
                    for (var t in this._pendingRemoveRanges)
                      if (!(!this._sourceBuffers[t] || this._sourceBuffers[t].updating))
                        for (var s = this._sourceBuffers[t], n = this._pendingRemoveRanges[t]; n.length && !s.updating; ) {
                          var e = n.shift();
                          s.remove(e.start, e.end);
                        }
                  }, i.prototype._doAppendSegments = function() {
                    var t = this._pendingSegments;
                    for (var s in t)
                      if (!(!this._sourceBuffers[s] || this._sourceBuffers[s].updating) && t[s].length > 0) {
                        var n = t[s].shift();
                        if (n.timestampOffset) {
                          var e = this._sourceBuffers[s].timestampOffset, f = n.timestampOffset / 1e3, c = Math.abs(e - f);
                          c > 0.1 && (u.default.v(this.TAG, "Update MPEG audio timestampOffset from " + e + " to " + f), this._sourceBuffers[s].timestampOffset = f), delete n.timestampOffset;
                        }
                        if (!n.data || n.data.byteLength === 0)
                          continue;
                        try {
                          this._sourceBuffers[s].appendBuffer(n.data), this._isBufferFull = !1, s === "video" && n.hasOwnProperty("info") && this._idrList.appendArray(n.info.syncPoints);
                        } catch (p) {
                          this._pendingSegments[s].unshift(n), p.code === 22 ? (this._isBufferFull || this._emitter.emit(h.default.BUFFER_FULL), this._isBufferFull = !0) : (u.default.e(this.TAG, p.message), this._emitter.emit(h.default.ERROR, { code: p.code, msg: p.message }));
                        }
                      }
                  }, i.prototype._onSourceOpen = function() {
                    if (u.default.v(this.TAG, "MediaSource onSourceOpen"), this._mediaSource.removeEventListener("sourceopen", this.e.onSourceOpen), this._pendingSourceBufferInit.length > 0)
                      for (var t = this._pendingSourceBufferInit; t.length; ) {
                        var s = t.shift();
                        this.appendInitSegment(s, !0);
                      }
                    this._hasPendingSegments() && this._doAppendSegments(), this._emitter.emit(h.default.SOURCE_OPEN);
                  }, i.prototype._onSourceEnded = function() {
                    u.default.v(this.TAG, "MediaSource onSourceEnded");
                  }, i.prototype._onSourceClose = function() {
                    u.default.v(this.TAG, "MediaSource onSourceClose"), this._mediaSource && this.e != null && (this._mediaSource.removeEventListener("sourceopen", this.e.onSourceOpen), this._mediaSource.removeEventListener("sourceended", this.e.onSourceEnded), this._mediaSource.removeEventListener("sourceclose", this.e.onSourceClose));
                  }, i.prototype._hasPendingSegments = function() {
                    var t = this._pendingSegments;
                    return t.video.length > 0 || t.audio.length > 0;
                  }, i.prototype._hasPendingRemoveRanges = function() {
                    var t = this._pendingRemoveRanges;
                    return t.video.length > 0 || t.audio.length > 0;
                  }, i.prototype._onSourceBufferUpdateEnd = function() {
                    this._requireSetMediaDuration ? this._updateMediaSourceDuration() : this._hasPendingRemoveRanges() ? this._doRemoveRanges() : this._hasPendingSegments() ? this._doAppendSegments() : this._hasPendingEos && this.endOfStream(), this._emitter.emit(h.default.UPDATE_END);
                  }, i.prototype._onSourceBufferError = function(t) {
                    u.default.e(this.TAG, "SourceBuffer Error: " + t);
                  }, i;
                }()
              );
              A.default = l;
            }, "./src/core/mse-controller.js")
          ),
          /***/
          "./src/core/mse-events.js": (
            /*!********************************!*\
              !*** ./src/core/mse-events.js ***!
              \********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = {
                ERROR: "error",
                SOURCE_OPEN: "source_open",
                UPDATE_END: "update_end",
                BUFFER_FULL: "buffer_full"
              };
              A.default = S;
            }, "./src/core/mse-events.js")
          ),
          /***/
          "./src/core/transmuxer.js": (
            /*!********************************!*\
              !*** ./src/core/transmuxer.js ***!
              \********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! events */
                "./node_modules/events/events.js"
              ), _ = /* @__PURE__ */ v.n(S), u = v(
                /*! webworkify-webpack */
                "./node_modules/webworkify-webpack/index.js"
              ), o = /* @__PURE__ */ v.n(u), h = v(
                /*! ../utils/logger.js */
                "./src/utils/logger.js"
              ), r = v(
                /*! ../utils/logging-control.js */
                "./src/utils/logging-control.js"
              ), a = v(
                /*! ./transmuxing-controller.js */
                "./src/core/transmuxing-controller.js"
              ), l = v(
                /*! ./transmuxing-events.js */
                "./src/core/transmuxing-events.js"
              ), i = v(
                /*! ./media-info.js */
                "./src/core/media-info.js"
              ), t = (
                /** @class */
                function() {
                  function s(n, e) {
                    if (this.TAG = "Transmuxer", this._emitter = new (_())(), e.enableWorker && typeof Worker < "u")
                      try {
                        this._worker = o()(
                          /*require.resolve*/
                          /*! ./transmuxing-worker */
                          "./src/core/transmuxing-worker.js"
                        ), this._workerDestroying = !1, this._worker.addEventListener("message", this._onWorkerMessage.bind(this)), this._worker.postMessage({ cmd: "init", param: [n, e] }), this.e = {
                          onLoggingConfigChanged: this._onLoggingConfigChanged.bind(this)
                        }, r.default.registerListener(this.e.onLoggingConfigChanged), this._worker.postMessage({ cmd: "logging_config", param: r.default.getConfig() });
                      } catch {
                        h.default.e(this.TAG, "Error while initialize transmuxing worker, fallback to inline transmuxing"), this._worker = null, this._controller = new a.default(n, e);
                      }
                    else
                      this._controller = new a.default(n, e);
                    if (this._controller) {
                      var f = this._controller;
                      f.on(l.default.IO_ERROR, this._onIOError.bind(this)), f.on(l.default.DEMUX_ERROR, this._onDemuxError.bind(this)), f.on(l.default.INIT_SEGMENT, this._onInitSegment.bind(this)), f.on(l.default.MEDIA_SEGMENT, this._onMediaSegment.bind(this)), f.on(l.default.LOADING_COMPLETE, this._onLoadingComplete.bind(this)), f.on(l.default.RECOVERED_EARLY_EOF, this._onRecoveredEarlyEof.bind(this)), f.on(l.default.MEDIA_INFO, this._onMediaInfo.bind(this)), f.on(l.default.METADATA_ARRIVED, this._onMetaDataArrived.bind(this)), f.on(l.default.SCRIPTDATA_ARRIVED, this._onScriptDataArrived.bind(this)), f.on(l.default.STATISTICS_INFO, this._onStatisticsInfo.bind(this)), f.on(l.default.RECOMMEND_SEEKPOINT, this._onRecommendSeekpoint.bind(this));
                    }
                  }
                  return d(s, "Transmuxer"), s.prototype.destroy = function() {
                    this._worker ? this._workerDestroying || (this._workerDestroying = !0, this._worker.postMessage({ cmd: "destroy" }), r.default.removeListener(this.e.onLoggingConfigChanged), this.e = null) : (this._controller.destroy(), this._controller = null), this._emitter.removeAllListeners(), this._emitter = null;
                  }, s.prototype.on = function(n, e) {
                    this._emitter.addListener(n, e);
                  }, s.prototype.off = function(n, e) {
                    this._emitter.removeListener(n, e);
                  }, s.prototype.hasWorker = function() {
                    return this._worker != null;
                  }, s.prototype.open = function() {
                    this._worker ? this._worker.postMessage({ cmd: "start" }) : this._controller.start();
                  }, s.prototype.close = function() {
                    this._worker ? this._worker.postMessage({ cmd: "stop" }) : this._controller.stop();
                  }, s.prototype.seek = function(n) {
                    this._worker ? this._worker.postMessage({ cmd: "seek", param: n }) : this._controller.seek(n);
                  }, s.prototype.pause = function() {
                    this._worker ? this._worker.postMessage({ cmd: "pause" }) : this._controller.pause();
                  }, s.prototype.resume = function() {
                    this._worker ? this._worker.postMessage({ cmd: "resume" }) : this._controller.resume();
                  }, s.prototype._onInitSegment = function(n, e) {
                    var f = this;
                    Promise.resolve().then(function() {
                      f._emitter.emit(l.default.INIT_SEGMENT, n, e);
                    });
                  }, s.prototype._onMediaSegment = function(n, e) {
                    var f = this;
                    Promise.resolve().then(function() {
                      f._emitter.emit(l.default.MEDIA_SEGMENT, n, e);
                    });
                  }, s.prototype._onLoadingComplete = function() {
                    var n = this;
                    Promise.resolve().then(function() {
                      n._emitter.emit(l.default.LOADING_COMPLETE);
                    });
                  }, s.prototype._onRecoveredEarlyEof = function() {
                    var n = this;
                    Promise.resolve().then(function() {
                      n._emitter.emit(l.default.RECOVERED_EARLY_EOF);
                    });
                  }, s.prototype._onMediaInfo = function(n) {
                    var e = this;
                    Promise.resolve().then(function() {
                      e._emitter.emit(l.default.MEDIA_INFO, n);
                    });
                  }, s.prototype._onMetaDataArrived = function(n) {
                    var e = this;
                    Promise.resolve().then(function() {
                      e._emitter.emit(l.default.METADATA_ARRIVED, n);
                    });
                  }, s.prototype._onScriptDataArrived = function(n) {
                    var e = this;
                    Promise.resolve().then(function() {
                      e._emitter.emit(l.default.SCRIPTDATA_ARRIVED, n);
                    });
                  }, s.prototype._onStatisticsInfo = function(n) {
                    var e = this;
                    Promise.resolve().then(function() {
                      e._emitter.emit(l.default.STATISTICS_INFO, n);
                    });
                  }, s.prototype._onIOError = function(n, e) {
                    var f = this;
                    Promise.resolve().then(function() {
                      f._emitter.emit(l.default.IO_ERROR, n, e);
                    });
                  }, s.prototype._onDemuxError = function(n, e) {
                    var f = this;
                    Promise.resolve().then(function() {
                      f._emitter.emit(l.default.DEMUX_ERROR, n, e);
                    });
                  }, s.prototype._onRecommendSeekpoint = function(n) {
                    var e = this;
                    Promise.resolve().then(function() {
                      e._emitter.emit(l.default.RECOMMEND_SEEKPOINT, n);
                    });
                  }, s.prototype._onLoggingConfigChanged = function(n) {
                    this._worker && this._worker.postMessage({ cmd: "logging_config", param: n });
                  }, s.prototype._onWorkerMessage = function(n) {
                    var e = n.data, f = e.data;
                    if (e.msg === "destroyed" || this._workerDestroying) {
                      this._workerDestroying = !1, this._worker.terminate(), this._worker = null;
                      return;
                    }
                    switch (e.msg) {
                      case l.default.INIT_SEGMENT:
                      case l.default.MEDIA_SEGMENT:
                        this._emitter.emit(e.msg, f.type, f.data);
                        break;
                      case l.default.LOADING_COMPLETE:
                      case l.default.RECOVERED_EARLY_EOF:
                        this._emitter.emit(e.msg);
                        break;
                      case l.default.MEDIA_INFO:
                        Object.setPrototypeOf(f, i.default.prototype), this._emitter.emit(e.msg, f);
                        break;
                      case l.default.METADATA_ARRIVED:
                      case l.default.SCRIPTDATA_ARRIVED:
                      case l.default.STATISTICS_INFO:
                        this._emitter.emit(e.msg, f);
                        break;
                      case l.default.IO_ERROR:
                      case l.default.DEMUX_ERROR:
                        this._emitter.emit(e.msg, f.type, f.info);
                        break;
                      case l.default.RECOMMEND_SEEKPOINT:
                        this._emitter.emit(e.msg, f);
                        break;
                      case "logcat_callback":
                        h.default.emitter.emit("log", f.type, f.logcat);
                        break;
                    }
                  }, s;
                }()
              );
              A.default = t;
            }, "./src/core/transmuxer.js")
          ),
          /***/
          "./src/core/transmuxing-controller.js": (
            /*!********************************************!*\
              !*** ./src/core/transmuxing-controller.js ***!
              \********************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! events */
                "./node_modules/events/events.js"
              ), _ = /* @__PURE__ */ v.n(S), u = v(
                /*! ../utils/logger.js */
                "./src/utils/logger.js"
              ), o = v(
                /*! ../utils/browser.js */
                "./src/utils/browser.js"
              ), h = v(
                /*! ./media-info.js */
                "./src/core/media-info.js"
              ), r = v(
                /*! ../demux/flv-demuxer.js */
                "./src/demux/flv-demuxer.js"
              ), a = v(
                /*! ../remux/mp4-remuxer.js */
                "./src/remux/mp4-remuxer.js"
              ), l = v(
                /*! ../demux/demux-errors.js */
                "./src/demux/demux-errors.js"
              ), i = v(
                /*! ../io/io-controller.js */
                "./src/io/io-controller.js"
              ), t = v(
                /*! ./transmuxing-events.js */
                "./src/core/transmuxing-events.js"
              ), s = (
                /** @class */
                function() {
                  function n(e, f) {
                    this.TAG = "TransmuxingController", this._emitter = new (_())(), this._config = f, e.segments || (e.segments = [{
                      duration: e.duration,
                      filesize: e.filesize,
                      url: e.url
                    }]), typeof e.cors != "boolean" && (e.cors = !0), typeof e.withCredentials != "boolean" && (e.withCredentials = !1), this._mediaDataSource = e, this._currentSegmentIndex = 0;
                    var c = 0;
                    this._mediaDataSource.segments.forEach(function(p) {
                      p.timestampBase = c, c += p.duration, p.cors = e.cors, p.withCredentials = e.withCredentials, f.referrerPolicy && (p.referrerPolicy = f.referrerPolicy);
                    }), !isNaN(c) && this._mediaDataSource.duration !== c && (this._mediaDataSource.duration = c), this._mediaInfo = null, this._demuxer = null, this._remuxer = null, this._ioctl = null, this._pendingSeekTime = null, this._pendingResolveSeekPoint = null, this._statisticsReporter = null;
                  }
                  return d(n, "TransmuxingController"), n.prototype.destroy = function() {
                    this._mediaInfo = null, this._mediaDataSource = null, this._statisticsReporter && this._disableStatisticsReporter(), this._ioctl && (this._ioctl.destroy(), this._ioctl = null), this._demuxer && (this._demuxer.destroy(), this._demuxer = null), this._remuxer && (this._remuxer.destroy(), this._remuxer = null), this._emitter.removeAllListeners(), this._emitter = null;
                  }, n.prototype.on = function(e, f) {
                    this._emitter.addListener(e, f);
                  }, n.prototype.off = function(e, f) {
                    this._emitter.removeListener(e, f);
                  }, n.prototype.start = function() {
                    this._loadSegment(0), this._enableStatisticsReporter();
                  }, n.prototype._loadSegment = function(e, f) {
                    this._currentSegmentIndex = e;
                    var c = this._mediaDataSource.segments[e], p = this._ioctl = new i.default(c, this._config, e);
                    p.onError = this._onIOException.bind(this), p.onSeeked = this._onIOSeeked.bind(this), p.onComplete = this._onIOComplete.bind(this), p.onRedirect = this._onIORedirect.bind(this), p.onRecoveredEarlyEof = this._onIORecoveredEarlyEof.bind(this), f ? this._demuxer.bindDataSource(this._ioctl) : p.onDataArrival = this._onInitChunkArrival.bind(this), p.open(f);
                  }, n.prototype.stop = function() {
                    this._internalAbort(), this._disableStatisticsReporter();
                  }, n.prototype._internalAbort = function() {
                    this._ioctl && (this._ioctl.destroy(), this._ioctl = null);
                  }, n.prototype.pause = function() {
                    this._ioctl && this._ioctl.isWorking() && (this._ioctl.pause(), this._disableStatisticsReporter());
                  }, n.prototype.resume = function() {
                    this._ioctl && this._ioctl.isPaused() && (this._ioctl.resume(), this._enableStatisticsReporter());
                  }, n.prototype.seek = function(e) {
                    if (!(this._mediaInfo == null || !this._mediaInfo.isSeekable())) {
                      var f = this._searchSegmentIndexContains(e);
                      if (f === this._currentSegmentIndex) {
                        var c = this._mediaInfo.segments[f];
                        if (c == null)
                          this._pendingSeekTime = e;
                        else {
                          var p = c.getNearestKeyframe(e);
                          this._remuxer.seek(p.milliseconds), this._ioctl.seek(p.fileposition), this._pendingResolveSeekPoint = p.milliseconds;
                        }
                      } else {
                        var g = this._mediaInfo.segments[f];
                        if (g == null)
                          this._pendingSeekTime = e, this._internalAbort(), this._remuxer.seek(), this._remuxer.insertDiscontinuity(), this._loadSegment(f);
                        else {
                          var p = g.getNearestKeyframe(e);
                          this._internalAbort(), this._remuxer.seek(e), this._remuxer.insertDiscontinuity(), this._demuxer.resetMediaInfo(), this._demuxer.timestampBase = this._mediaDataSource.segments[f].timestampBase, this._loadSegment(f, p.fileposition), this._pendingResolveSeekPoint = p.milliseconds, this._reportSegmentMediaInfo(f);
                        }
                      }
                      this._enableStatisticsReporter();
                    }
                  }, n.prototype._searchSegmentIndexContains = function(e) {
                    for (var f = this._mediaDataSource.segments, c = f.length - 1, p = 0; p < f.length; p++)
                      if (e < f[p].timestampBase) {
                        c = p - 1;
                        break;
                      }
                    return c;
                  }, n.prototype._onInitChunkArrival = function(e, f) {
                    var c = this, p = null, g = 0;
                    if (f > 0)
                      this._demuxer.bindDataSource(this._ioctl), this._demuxer.timestampBase = this._mediaDataSource.segments[this._currentSegmentIndex].timestampBase, g = this._demuxer.parseChunks(e, f);
                    else if ((p = r.default.probe(e)).match) {
                      this._demuxer = new r.default(p, this._config), this._remuxer || (this._remuxer = new a.default(this._config));
                      var y = this._mediaDataSource;
                      y.duration != null && !isNaN(y.duration) && (this._demuxer.overridedDuration = y.duration), typeof y.hasAudio == "boolean" && (this._demuxer.overridedHasAudio = y.hasAudio), typeof y.hasVideo == "boolean" && (this._demuxer.overridedHasVideo = y.hasVideo), this._demuxer.timestampBase = y.segments[this._currentSegmentIndex].timestampBase, this._demuxer.onError = this._onDemuxException.bind(this), this._demuxer.onMediaInfo = this._onMediaInfo.bind(this), this._demuxer.onMetaDataArrived = this._onMetaDataArrived.bind(this), this._demuxer.onScriptDataArrived = this._onScriptDataArrived.bind(this), this._remuxer.bindDataSource(this._demuxer.bindDataSource(this._ioctl)), this._remuxer.onInitSegment = this._onRemuxerInitSegmentArrival.bind(this), this._remuxer.onMediaSegment = this._onRemuxerMediaSegmentArrival.bind(this), g = this._demuxer.parseChunks(e, f);
                    } else
                      p = null, u.default.e(this.TAG, "Non-FLV, Unsupported media type!"), Promise.resolve().then(function() {
                        c._internalAbort();
                      }), this._emitter.emit(t.default.DEMUX_ERROR, l.default.FORMAT_UNSUPPORTED, "Non-FLV, Unsupported media type"), g = 0;
                    return g;
                  }, n.prototype._onMediaInfo = function(e) {
                    var f = this;
                    this._mediaInfo == null && (this._mediaInfo = Object.assign({}, e), this._mediaInfo.keyframesIndex = null, this._mediaInfo.segments = [], this._mediaInfo.segmentCount = this._mediaDataSource.segments.length, Object.setPrototypeOf(this._mediaInfo, h.default.prototype));
                    var c = Object.assign({}, e);
                    Object.setPrototypeOf(c, h.default.prototype), this._mediaInfo.segments[this._currentSegmentIndex] = c, this._reportSegmentMediaInfo(this._currentSegmentIndex), this._pendingSeekTime != null && Promise.resolve().then(function() {
                      var p = f._pendingSeekTime;
                      f._pendingSeekTime = null, f.seek(p);
                    });
                  }, n.prototype._onMetaDataArrived = function(e) {
                    this._emitter.emit(t.default.METADATA_ARRIVED, e);
                  }, n.prototype._onScriptDataArrived = function(e) {
                    this._emitter.emit(t.default.SCRIPTDATA_ARRIVED, e);
                  }, n.prototype._onIOSeeked = function() {
                    this._remuxer.insertDiscontinuity();
                  }, n.prototype._onIOComplete = function(e) {
                    var f = e, c = f + 1;
                    c < this._mediaDataSource.segments.length ? (this._internalAbort(), this._remuxer.flushStashedSamples(), this._loadSegment(c)) : (this._remuxer.flushStashedSamples(), this._emitter.emit(t.default.LOADING_COMPLETE), this._disableStatisticsReporter());
                  }, n.prototype._onIORedirect = function(e) {
                    var f = this._ioctl.extraData;
                    this._mediaDataSource.segments[f].redirectedURL = e;
                  }, n.prototype._onIORecoveredEarlyEof = function() {
                    this._emitter.emit(t.default.RECOVERED_EARLY_EOF);
                  }, n.prototype._onIOException = function(e, f) {
                    u.default.e(this.TAG, "IOException: type = " + e + ", code = " + f.code + ", msg = " + f.msg), this._emitter.emit(t.default.IO_ERROR, e, f), this._disableStatisticsReporter();
                  }, n.prototype._onDemuxException = function(e, f) {
                    u.default.e(this.TAG, "DemuxException: type = " + e + ", info = " + f), this._emitter.emit(t.default.DEMUX_ERROR, e, f);
                  }, n.prototype._onRemuxerInitSegmentArrival = function(e, f) {
                    this._emitter.emit(t.default.INIT_SEGMENT, e, f);
                  }, n.prototype._onRemuxerMediaSegmentArrival = function(e, f) {
                    if (this._pendingSeekTime == null && (this._emitter.emit(t.default.MEDIA_SEGMENT, e, f), this._pendingResolveSeekPoint != null && e === "video")) {
                      var c = f.info.syncPoints, p = this._pendingResolveSeekPoint;
                      this._pendingResolveSeekPoint = null, o.default.safari && c.length > 0 && c[0].originalDts === p && (p = c[0].pts), this._emitter.emit(t.default.RECOMMEND_SEEKPOINT, p);
                    }
                  }, n.prototype._enableStatisticsReporter = function() {
                    this._statisticsReporter == null && (this._statisticsReporter = self.setInterval(this._reportStatisticsInfo.bind(this), this._config.statisticsInfoReportInterval));
                  }, n.prototype._disableStatisticsReporter = function() {
                    this._statisticsReporter && (self.clearInterval(this._statisticsReporter), this._statisticsReporter = null);
                  }, n.prototype._reportSegmentMediaInfo = function(e) {
                    var f = this._mediaInfo.segments[e], c = Object.assign({}, f);
                    c.duration = this._mediaInfo.duration, c.segmentCount = this._mediaInfo.segmentCount, delete c.segments, delete c.keyframesIndex, this._emitter.emit(t.default.MEDIA_INFO, c);
                  }, n.prototype._reportStatisticsInfo = function() {
                    var e = {};
                    e.url = this._ioctl.currentURL, e.hasRedirect = this._ioctl.hasRedirect, e.hasRedirect && (e.redirectedURL = this._ioctl.currentRedirectedURL), e.speed = this._ioctl.currentSpeed, e.loaderType = this._ioctl.loaderType, e.currentSegmentIndex = this._currentSegmentIndex, e.totalSegmentCount = this._mediaDataSource.segments.length, this._emitter.emit(t.default.STATISTICS_INFO, e);
                  }, n;
                }()
              );
              A.default = s;
            }, "./src/core/transmuxing-controller.js")
          ),
          /***/
          "./src/core/transmuxing-events.js": (
            /*!****************************************!*\
              !*** ./src/core/transmuxing-events.js ***!
              \****************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = {
                IO_ERROR: "io_error",
                DEMUX_ERROR: "demux_error",
                INIT_SEGMENT: "init_segment",
                MEDIA_SEGMENT: "media_segment",
                LOADING_COMPLETE: "loading_complete",
                RECOVERED_EARLY_EOF: "recovered_early_eof",
                MEDIA_INFO: "media_info",
                METADATA_ARRIVED: "metadata_arrived",
                SCRIPTDATA_ARRIVED: "scriptdata_arrived",
                STATISTICS_INFO: "statistics_info",
                RECOMMEND_SEEKPOINT: "recommend_seekpoint"
              };
              A.default = S;
            }, "./src/core/transmuxing-events.js")
          ),
          /***/
          "./src/core/transmuxing-worker.js": (
            /*!****************************************!*\
              !*** ./src/core/transmuxing-worker.js ***!
              \****************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ../utils/logging-control.js */
                "./src/utils/logging-control.js"
              ), _ = v(
                /*! ../utils/polyfill.js */
                "./src/utils/polyfill.js"
              ), u = v(
                /*! ./transmuxing-controller.js */
                "./src/core/transmuxing-controller.js"
              ), o = v(
                /*! ./transmuxing-events.js */
                "./src/core/transmuxing-events.js"
              ), h = /* @__PURE__ */ d(function(r) {
                var a = null, l = m.bind(this);
                _.default.install(), r.addEventListener("message", function(x) {
                  switch (x.data.cmd) {
                    case "init":
                      a = new u.default(x.data.param[0], x.data.param[1]), a.on(o.default.IO_ERROR, g.bind(this)), a.on(o.default.DEMUX_ERROR, y.bind(this)), a.on(o.default.INIT_SEGMENT, i.bind(this)), a.on(o.default.MEDIA_SEGMENT, t.bind(this)), a.on(o.default.LOADING_COMPLETE, s.bind(this)), a.on(o.default.RECOVERED_EARLY_EOF, n.bind(this)), a.on(o.default.MEDIA_INFO, e.bind(this)), a.on(o.default.METADATA_ARRIVED, f.bind(this)), a.on(o.default.SCRIPTDATA_ARRIVED, c.bind(this)), a.on(o.default.STATISTICS_INFO, p.bind(this)), a.on(o.default.RECOMMEND_SEEKPOINT, E.bind(this));
                      break;
                    case "destroy":
                      a && (a.destroy(), a = null), r.postMessage({ msg: "destroyed" });
                      break;
                    case "start":
                      a.start();
                      break;
                    case "stop":
                      a.stop();
                      break;
                    case "seek":
                      a.seek(x.data.param);
                      break;
                    case "pause":
                      a.pause();
                      break;
                    case "resume":
                      a.resume();
                      break;
                    case "logging_config": {
                      var L = x.data.param;
                      S.default.applyConfig(L), L.enableCallback === !0 ? S.default.addLogListener(l) : S.default.removeLogListener(l);
                      break;
                    }
                  }
                });
                function i(x, L) {
                  var O = {
                    msg: o.default.INIT_SEGMENT,
                    data: {
                      type: x,
                      data: L
                    }
                  };
                  r.postMessage(O, [L.data]);
                }
                d(i, "onInitSegment");
                function t(x, L) {
                  var O = {
                    msg: o.default.MEDIA_SEGMENT,
                    data: {
                      type: x,
                      data: L
                    }
                  };
                  r.postMessage(O, [L.data]);
                }
                d(t, "onMediaSegment");
                function s() {
                  var x = {
                    msg: o.default.LOADING_COMPLETE
                  };
                  r.postMessage(x);
                }
                d(s, "onLoadingComplete");
                function n() {
                  var x = {
                    msg: o.default.RECOVERED_EARLY_EOF
                  };
                  r.postMessage(x);
                }
                d(n, "onRecoveredEarlyEof");
                function e(x) {
                  var L = {
                    msg: o.default.MEDIA_INFO,
                    data: x
                  };
                  r.postMessage(L);
                }
                d(e, "onMediaInfo");
                function f(x) {
                  var L = {
                    msg: o.default.METADATA_ARRIVED,
                    data: x
                  };
                  r.postMessage(L);
                }
                d(f, "onMetaDataArrived");
                function c(x) {
                  var L = {
                    msg: o.default.SCRIPTDATA_ARRIVED,
                    data: x
                  };
                  r.postMessage(L);
                }
                d(c, "onScriptDataArrived");
                function p(x) {
                  var L = {
                    msg: o.default.STATISTICS_INFO,
                    data: x
                  };
                  r.postMessage(L);
                }
                d(p, "onStatisticsInfo");
                function g(x, L) {
                  r.postMessage({
                    msg: o.default.IO_ERROR,
                    data: {
                      type: x,
                      info: L
                    }
                  });
                }
                d(g, "onIOError");
                function y(x, L) {
                  r.postMessage({
                    msg: o.default.DEMUX_ERROR,
                    data: {
                      type: x,
                      info: L
                    }
                  });
                }
                d(y, "onDemuxError");
                function E(x) {
                  r.postMessage({
                    msg: o.default.RECOMMEND_SEEKPOINT,
                    data: x
                  });
                }
                d(E, "onRecommendSeekpoint");
                function m(x, L) {
                  r.postMessage({
                    msg: "logcat_callback",
                    data: {
                      type: x,
                      logcat: L
                    }
                  });
                }
                d(m, "onLogcatCallback");
              }, "TransmuxingWorker");
              A.default = h;
            }, "./src/core/transmuxing-worker.js")
          ),
          /***/
          "./src/demux/amf-parser.js": (
            /*!*********************************!*\
              !*** ./src/demux/amf-parser.js ***!
              \*********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ../utils/logger.js */
                "./src/utils/logger.js"
              ), _ = v(
                /*! ../utils/utf8-conv.js */
                "./src/utils/utf8-conv.js"
              ), u = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), o = function() {
                var r = new ArrayBuffer(2);
                return new DataView(r).setInt16(0, 256, !0), new Int16Array(r)[0] === 256;
              }(), h = (
                /** @class */
                function() {
                  function r() {
                  }
                  return d(r, "AMF"), r.parseScriptData = function(a, l, i) {
                    var t = {};
                    try {
                      var s = r.parseValue(a, l, i), n = r.parseValue(a, l + s.size, i - s.size);
                      t[s.data] = n.data;
                    } catch (e) {
                      S.default.e("AMF", e.toString());
                    }
                    return t;
                  }, r.parseObject = function(a, l, i) {
                    if (i < 3)
                      throw new u.IllegalStateException("Data not enough when parse ScriptDataObject");
                    var t = r.parseString(a, l, i), s = r.parseValue(a, l + t.size, i - t.size), n = s.objectEnd;
                    return {
                      data: {
                        name: t.data,
                        value: s.data
                      },
                      size: t.size + s.size,
                      objectEnd: n
                    };
                  }, r.parseVariable = function(a, l, i) {
                    return r.parseObject(a, l, i);
                  }, r.parseString = function(a, l, i) {
                    if (i < 2)
                      throw new u.IllegalStateException("Data not enough when parse String");
                    var t = new DataView(a, l, i), s = t.getUint16(0, !o), n;
                    return s > 0 ? n = (0, _.default)(new Uint8Array(a, l + 2, s)) : n = "", {
                      data: n,
                      size: 2 + s
                    };
                  }, r.parseLongString = function(a, l, i) {
                    if (i < 4)
                      throw new u.IllegalStateException("Data not enough when parse LongString");
                    var t = new DataView(a, l, i), s = t.getUint32(0, !o), n;
                    return s > 0 ? n = (0, _.default)(new Uint8Array(a, l + 4, s)) : n = "", {
                      data: n,
                      size: 4 + s
                    };
                  }, r.parseDate = function(a, l, i) {
                    if (i < 10)
                      throw new u.IllegalStateException("Data size invalid when parse Date");
                    var t = new DataView(a, l, i), s = t.getFloat64(0, !o), n = t.getInt16(8, !o);
                    return s += n * 60 * 1e3, {
                      data: new Date(s),
                      size: 10
                    };
                  }, r.parseValue = function(a, l, i) {
                    if (i < 1)
                      throw new u.IllegalStateException("Data not enough when parse Value");
                    var t = new DataView(a, l, i), s = 1, n = t.getUint8(0), e, f = !1;
                    try {
                      switch (n) {
                        case 0:
                          e = t.getFloat64(1, !o), s += 8;
                          break;
                        case 1: {
                          var c = t.getUint8(1);
                          e = !!c, s += 1;
                          break;
                        }
                        case 2: {
                          var p = r.parseString(a, l + 1, i - 1);
                          e = p.data, s += p.size;
                          break;
                        }
                        case 3: {
                          e = {};
                          var g = 0;
                          for ((t.getUint32(i - 4, !o) & 16777215) === 9 && (g = 3); s < i - 4; ) {
                            var y = r.parseObject(a, l + s, i - s - g);
                            if (y.objectEnd)
                              break;
                            e[y.data.name] = y.data.value, s += y.size;
                          }
                          if (s <= i - 3) {
                            var E = t.getUint32(s - 1, !o) & 16777215;
                            E === 9 && (s += 3);
                          }
                          break;
                        }
                        case 8: {
                          e = {}, s += 4;
                          var g = 0;
                          for ((t.getUint32(i - 4, !o) & 16777215) === 9 && (g = 3); s < i - 8; ) {
                            var m = r.parseVariable(a, l + s, i - s - g);
                            if (m.objectEnd)
                              break;
                            e[m.data.name] = m.data.value, s += m.size;
                          }
                          if (s <= i - 3) {
                            var E = t.getUint32(s - 1, !o) & 16777215;
                            E === 9 && (s += 3);
                          }
                          break;
                        }
                        case 9:
                          e = void 0, s = 1, f = !0;
                          break;
                        case 10: {
                          e = [];
                          var x = t.getUint32(1, !o);
                          s += 4;
                          for (var L = 0; L < x; L++) {
                            var O = r.parseValue(a, l + s, i - s);
                            e.push(O.data), s += O.size;
                          }
                          break;
                        }
                        case 11: {
                          var R = r.parseDate(a, l + 1, i - 1);
                          e = R.data, s += R.size;
                          break;
                        }
                        case 12: {
                          var I = r.parseString(a, l + 1, i - 1);
                          e = I.data, s += I.size;
                          break;
                        }
                        default:
                          s = i, S.default.w("AMF", "Unsupported AMF value type " + n);
                      }
                    } catch (U) {
                      S.default.e("AMF", U.toString());
                    }
                    return {
                      data: e,
                      size: s,
                      objectEnd: f
                    };
                  }, r;
                }()
              );
              A.default = h;
            }, "./src/demux/amf-parser.js")
          ),
          /***/
          "./src/demux/demux-errors.js": (
            /*!***********************************!*\
              !*** ./src/demux/demux-errors.js ***!
              \***********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = {
                OK: "OK",
                FORMAT_ERROR: "FormatError",
                FORMAT_UNSUPPORTED: "FormatUnsupported",
                CODEC_UNSUPPORTED: "CodecUnsupported"
              };
              A.default = S;
            }, "./src/demux/demux-errors.js")
          ),
          /***/
          "./src/demux/exp-golomb.js": (
            /*!*********************************!*\
              !*** ./src/demux/exp-golomb.js ***!
              \*********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), _ = (
                /** @class */
                function() {
                  function u(o) {
                    this.TAG = "ExpGolomb", this._buffer = o, this._buffer_index = 0, this._total_bytes = o.byteLength, this._total_bits = o.byteLength * 8, this._current_word = 0, this._current_word_bits_left = 0;
                  }
                  return d(u, "ExpGolomb"), u.prototype.destroy = function() {
                    this._buffer = null;
                  }, u.prototype._fillCurrentWord = function() {
                    var o = this._total_bytes - this._buffer_index;
                    if (o <= 0)
                      throw new S.IllegalStateException("ExpGolomb: _fillCurrentWord() but no bytes available");
                    var h = Math.min(4, o), r = new Uint8Array(4);
                    r.set(this._buffer.subarray(this._buffer_index, this._buffer_index + h)), this._current_word = new DataView(r.buffer).getUint32(0, !1), this._buffer_index += h, this._current_word_bits_left = h * 8;
                  }, u.prototype.readBits = function(o) {
                    if (o > 32)
                      throw new S.InvalidArgumentException("ExpGolomb: readBits() bits exceeded max 32bits!");
                    if (o <= this._current_word_bits_left) {
                      var h = this._current_word >>> 32 - o;
                      return this._current_word <<= o, this._current_word_bits_left -= o, h;
                    }
                    var r = this._current_word_bits_left ? this._current_word : 0;
                    r = r >>> 32 - this._current_word_bits_left;
                    var a = o - this._current_word_bits_left;
                    this._fillCurrentWord();
                    var l = Math.min(a, this._current_word_bits_left), i = this._current_word >>> 32 - l;
                    return this._current_word <<= l, this._current_word_bits_left -= l, r = r << l | i, r;
                  }, u.prototype.readBool = function() {
                    return this.readBits(1) === 1;
                  }, u.prototype.readByte = function() {
                    return this.readBits(8);
                  }, u.prototype._skipLeadingZero = function() {
                    var o;
                    for (o = 0; o < this._current_word_bits_left; o++)
                      if (this._current_word & 2147483648 >>> o)
                        return this._current_word <<= o, this._current_word_bits_left -= o, o;
                    return this._fillCurrentWord(), o + this._skipLeadingZero();
                  }, u.prototype.readUEG = function() {
                    var o = this._skipLeadingZero();
                    return this.readBits(o + 1) - 1;
                  }, u.prototype.readSEG = function() {
                    var o = this.readUEG();
                    return o & 1 ? o + 1 >>> 1 : -1 * (o >>> 1);
                  }, u;
                }()
              );
              A.default = _;
            }, "./src/demux/exp-golomb.js")
          ),
          /***/
          "./src/demux/flv-demuxer.js": (
            /*!**********************************!*\
              !*** ./src/demux/flv-demuxer.js ***!
              \**********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ../utils/logger.js */
                "./src/utils/logger.js"
              ), _ = v(
                /*! ./amf-parser.js */
                "./src/demux/amf-parser.js"
              ), u = v(
                /*! ./sps-parser.js */
                "./src/demux/sps-parser.js"
              ), o = v(
                /*! ./demux-errors.js */
                "./src/demux/demux-errors.js"
              ), h = v(
                /*! ../core/media-info.js */
                "./src/core/media-info.js"
              ), r = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              );
              function a(i, t) {
                return i[t] << 24 | i[t + 1] << 16 | i[t + 2] << 8 | i[t + 3];
              }
              d(a, "ReadBig32");
              var l = (
                /** @class */
                function() {
                  function i(t, s) {
                    this.TAG = "FLVDemuxer", this._config = s, this._onError = null, this._onMediaInfo = null, this._onMetaDataArrived = null, this._onScriptDataArrived = null, this._onTrackMetadata = null, this._onDataAvailable = null, this._dataOffset = t.dataOffset, this._firstParse = !0, this._dispatch = !1, this._hasAudio = t.hasAudioTrack, this._hasVideo = t.hasVideoTrack, this._hasAudioFlagOverrided = !1, this._hasVideoFlagOverrided = !1, this._audioInitialMetadataDispatched = !1, this._videoInitialMetadataDispatched = !1, this._mediaInfo = new h.default(), this._mediaInfo.hasAudio = this._hasAudio, this._mediaInfo.hasVideo = this._hasVideo, this._metadata = null, this._audioMetadata = null, this._videoMetadata = null, this._naluLengthSize = 4, this._timestampBase = 0, this._timescale = 1e3, this._duration = 0, this._durationOverrided = !1, this._referenceFrameRate = {
                      fixed: !0,
                      fps: 23.976,
                      fps_num: 23976,
                      fps_den: 1e3
                    }, this._flvSoundRateTable = [5500, 11025, 22050, 44100, 48e3], this._mpegSamplingRates = [
                      96e3,
                      88200,
                      64e3,
                      48e3,
                      44100,
                      32e3,
                      24e3,
                      22050,
                      16e3,
                      12e3,
                      11025,
                      8e3,
                      7350
                    ], this._mpegAudioV10SampleRateTable = [44100, 48e3, 32e3, 0], this._mpegAudioV20SampleRateTable = [22050, 24e3, 16e3, 0], this._mpegAudioV25SampleRateTable = [11025, 12e3, 8e3, 0], this._mpegAudioL1BitRateTable = [0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, -1], this._mpegAudioL2BitRateTable = [0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, -1], this._mpegAudioL3BitRateTable = [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, -1], this._videoTrack = { type: "video", id: 1, sequenceNumber: 0, samples: [], length: 0 }, this._audioTrack = { type: "audio", id: 2, sequenceNumber: 0, samples: [], length: 0 }, this._littleEndian = function() {
                      var n = new ArrayBuffer(2);
                      return new DataView(n).setInt16(0, 256, !0), new Int16Array(n)[0] === 256;
                    }();
                  }
                  return d(i, "FLVDemuxer"), i.prototype.destroy = function() {
                    this._mediaInfo = null, this._metadata = null, this._audioMetadata = null, this._videoMetadata = null, this._videoTrack = null, this._audioTrack = null, this._onError = null, this._onMediaInfo = null, this._onMetaDataArrived = null, this._onScriptDataArrived = null, this._onTrackMetadata = null, this._onDataAvailable = null;
                  }, i.probe = function(t) {
                    var s = new Uint8Array(t), n = { match: !1 };
                    if (s[0] !== 70 || s[1] !== 76 || s[2] !== 86 || s[3] !== 1)
                      return n;
                    var e = (s[4] & 4) >>> 2 !== 0, f = (s[4] & 1) !== 0, c = a(s, 5);
                    return c < 9 ? n : {
                      match: !0,
                      consumed: c,
                      dataOffset: c,
                      hasAudioTrack: e,
                      hasVideoTrack: f
                    };
                  }, i.prototype.bindDataSource = function(t) {
                    return t.onDataArrival = this.parseChunks.bind(this), this;
                  }, Object.defineProperty(i.prototype, "onTrackMetadata", {
                    // prototype: function(type: string, metadata: any): void
                    get: /* @__PURE__ */ d(function() {
                      return this._onTrackMetadata;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(t) {
                      this._onTrackMetadata = t;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(i.prototype, "onMediaInfo", {
                    // prototype: function(mediaInfo: MediaInfo): void
                    get: /* @__PURE__ */ d(function() {
                      return this._onMediaInfo;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(t) {
                      this._onMediaInfo = t;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(i.prototype, "onMetaDataArrived", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onMetaDataArrived;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(t) {
                      this._onMetaDataArrived = t;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(i.prototype, "onScriptDataArrived", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onScriptDataArrived;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(t) {
                      this._onScriptDataArrived = t;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(i.prototype, "onError", {
                    // prototype: function(type: number, info: string): void
                    get: /* @__PURE__ */ d(function() {
                      return this._onError;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(t) {
                      this._onError = t;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(i.prototype, "onDataAvailable", {
                    // prototype: function(videoTrack: any, audioTrack: any): void
                    get: /* @__PURE__ */ d(function() {
                      return this._onDataAvailable;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(t) {
                      this._onDataAvailable = t;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(i.prototype, "timestampBase", {
                    // timestamp base for output samples, must be in milliseconds
                    get: /* @__PURE__ */ d(function() {
                      return this._timestampBase;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(t) {
                      this._timestampBase = t;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(i.prototype, "overridedDuration", {
                    get: /* @__PURE__ */ d(function() {
                      return this._duration;
                    }, "get"),
                    // Force-override media duration. Must be in milliseconds, int32
                    set: /* @__PURE__ */ d(function(t) {
                      this._durationOverrided = !0, this._duration = t, this._mediaInfo.duration = t;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(i.prototype, "overridedHasAudio", {
                    // Force-override audio track present flag, boolean
                    set: /* @__PURE__ */ d(function(t) {
                      this._hasAudioFlagOverrided = !0, this._hasAudio = t, this._mediaInfo.hasAudio = t;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(i.prototype, "overridedHasVideo", {
                    // Force-override video track present flag, boolean
                    set: /* @__PURE__ */ d(function(t) {
                      this._hasVideoFlagOverrided = !0, this._hasVideo = t, this._mediaInfo.hasVideo = t;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), i.prototype.resetMediaInfo = function() {
                    this._mediaInfo = new h.default();
                  }, i.prototype._isInitialMetadataDispatched = function() {
                    return this._hasAudio && this._hasVideo ? this._audioInitialMetadataDispatched && this._videoInitialMetadataDispatched : this._hasAudio && !this._hasVideo ? this._audioInitialMetadataDispatched : !this._hasAudio && this._hasVideo ? this._videoInitialMetadataDispatched : !1;
                  }, i.prototype.parseChunks = function(t, s) {
                    if (!this._onError || !this._onMediaInfo || !this._onTrackMetadata || !this._onDataAvailable)
                      throw new r.IllegalStateException("Flv: onError & onMediaInfo & onTrackMetadata & onDataAvailable callback must be specified");
                    var n = 0, e = this._littleEndian;
                    if (s === 0)
                      if (t.byteLength > 13) {
                        var f = i.probe(t);
                        n = f.dataOffset;
                      } else
                        return 0;
                    if (this._firstParse) {
                      this._firstParse = !1, s + n !== this._dataOffset && S.default.w(this.TAG, "First time parsing but chunk byteStart invalid!");
                      var c = new DataView(t, n), p = c.getUint32(0, !e);
                      p !== 0 && S.default.w(this.TAG, "PrevTagSize0 !== 0 !!!"), n += 4;
                    }
                    for (; n < t.byteLength; ) {
                      this._dispatch = !0;
                      var c = new DataView(t, n);
                      if (n + 11 + 4 > t.byteLength)
                        break;
                      var g = c.getUint8(0), y = c.getUint32(0, !e) & 16777215;
                      if (n + 11 + y + 4 > t.byteLength)
                        break;
                      if (g !== 8 && g !== 9 && g !== 18) {
                        S.default.w(this.TAG, "Unsupported tag type " + g + ", skipped"), n += 11 + y + 4;
                        continue;
                      }
                      var E = c.getUint8(4), m = c.getUint8(5), x = c.getUint8(6), L = c.getUint8(7), O = x | m << 8 | E << 16 | L << 24, R = c.getUint32(7, !e) & 16777215;
                      R !== 0 && S.default.w(this.TAG, "Meet tag which has StreamID != 0!");
                      var I = n + 11;
                      switch (g) {
                        case 8:
                          this._parseAudioData(t, I, y, O);
                          break;
                        case 9:
                          this._parseVideoData(t, I, y, O, s + n);
                          break;
                        case 18:
                          this._parseScriptData(t, I, y);
                          break;
                      }
                      var U = c.getUint32(11 + y, !e);
                      U !== 11 + y && S.default.w(this.TAG, "Invalid PrevTagSize " + U), n += 11 + y + 4;
                    }
                    return this._isInitialMetadataDispatched() && this._dispatch && (this._audioTrack.length || this._videoTrack.length) && this._onDataAvailable(this._audioTrack, this._videoTrack), n;
                  }, i.prototype._parseScriptData = function(t, s, n) {
                    var e = _.default.parseScriptData(t, s, n);
                    if (e.hasOwnProperty("onMetaData")) {
                      if (e.onMetaData == null || typeof e.onMetaData != "object") {
                        S.default.w(this.TAG, "Invalid onMetaData structure!");
                        return;
                      }
                      this._metadata && S.default.w(this.TAG, "Found another onMetaData tag!"), this._metadata = e;
                      var f = this._metadata.onMetaData;
                      if (this._onMetaDataArrived && this._onMetaDataArrived(Object.assign({}, f)), typeof f.hasAudio == "boolean" && this._hasAudioFlagOverrided === !1 && (this._hasAudio = f.hasAudio, this._mediaInfo.hasAudio = this._hasAudio), typeof f.hasVideo == "boolean" && this._hasVideoFlagOverrided === !1 && (this._hasVideo = f.hasVideo, this._mediaInfo.hasVideo = this._hasVideo), typeof f.audiodatarate == "number" && (this._mediaInfo.audioDataRate = f.audiodatarate), typeof f.videodatarate == "number" && (this._mediaInfo.videoDataRate = f.videodatarate), typeof f.width == "number" && (this._mediaInfo.width = f.width), typeof f.height == "number" && (this._mediaInfo.height = f.height), typeof f.duration == "number") {
                        if (!this._durationOverrided) {
                          var c = Math.floor(f.duration * this._timescale);
                          this._duration = c, this._mediaInfo.duration = c;
                        }
                      } else
                        this._mediaInfo.duration = 0;
                      if (typeof f.framerate == "number") {
                        var p = Math.floor(f.framerate * 1e3);
                        if (p > 0) {
                          var g = p / 1e3;
                          this._referenceFrameRate.fixed = !0, this._referenceFrameRate.fps = g, this._referenceFrameRate.fps_num = p, this._referenceFrameRate.fps_den = 1e3, this._mediaInfo.fps = g;
                        }
                      }
                      if (typeof f.keyframes == "object") {
                        this._mediaInfo.hasKeyframesIndex = !0;
                        var y = f.keyframes;
                        this._mediaInfo.keyframesIndex = this._parseKeyframesIndex(y), f.keyframes = null;
                      } else
                        this._mediaInfo.hasKeyframesIndex = !1;
                      this._dispatch = !1, this._mediaInfo.metadata = f, S.default.v(this.TAG, "Parsed onMetaData"), this._mediaInfo.isComplete() && this._onMediaInfo(this._mediaInfo);
                    }
                    Object.keys(e).length > 0 && this._onScriptDataArrived && this._onScriptDataArrived(Object.assign({}, e));
                  }, i.prototype._parseKeyframesIndex = function(t) {
                    for (var s = [], n = [], e = 1; e < t.times.length; e++) {
                      var f = this._timestampBase + Math.floor(t.times[e] * 1e3);
                      s.push(f), n.push(t.filepositions[e]);
                    }
                    return {
                      times: s,
                      filepositions: n
                    };
                  }, i.prototype._parseAudioData = function(t, s, n, e) {
                    if (n <= 1) {
                      S.default.w(this.TAG, "Flv: Invalid audio packet, missing SoundData payload!");
                      return;
                    }
                    if (!(this._hasAudioFlagOverrided === !0 && this._hasAudio === !1)) {
                      this._littleEndian;
                      var f = new DataView(t, s, n), c = f.getUint8(0), p = c >>> 4;
                      if (p !== 2 && p !== 10) {
                        this._onError(o.default.CODEC_UNSUPPORTED, "Flv: Unsupported audio codec idx: " + p);
                        return;
                      }
                      var g = 0, y = (c & 12) >>> 2;
                      if (y >= 0 && y <= 4)
                        g = this._flvSoundRateTable[y];
                      else {
                        this._onError(o.default.FORMAT_ERROR, "Flv: Invalid audio sample rate idx: " + y);
                        return;
                      }
                      var E = c & 1, m = this._audioMetadata, x = this._audioTrack;
                      if (m || (this._hasAudio === !1 && this._hasAudioFlagOverrided === !1 && (this._hasAudio = !0, this._mediaInfo.hasAudio = !0), m = this._audioMetadata = {}, m.type = "audio", m.id = x.id, m.timescale = this._timescale, m.duration = this._duration, m.audioSampleRate = g, m.channelCount = E === 0 ? 1 : 2), p === 10) {
                        var L = this._parseAACAudioData(t, s + 1, n - 1);
                        if (L == null)
                          return;
                        if (L.packetType === 0) {
                          m.config && S.default.w(this.TAG, "Found another AudioSpecificConfig!");
                          var O = L.data;
                          m.audioSampleRate = O.samplingRate, m.channelCount = O.channelCount, m.codec = O.codec, m.originalCodec = O.originalCodec, m.config = O.config, m.refSampleDuration = 1024 / m.audioSampleRate * m.timescale, S.default.v(this.TAG, "Parsed AudioSpecificConfig"), this._isInitialMetadataDispatched() ? this._dispatch && (this._audioTrack.length || this._videoTrack.length) && this._onDataAvailable(this._audioTrack, this._videoTrack) : this._audioInitialMetadataDispatched = !0, this._dispatch = !1, this._onTrackMetadata("audio", m);
                          var R = this._mediaInfo;
                          R.audioCodec = m.originalCodec, R.audioSampleRate = m.audioSampleRate, R.audioChannelCount = m.channelCount, R.hasVideo ? R.videoCodec != null && (R.mimeType = 'video/x-flv; codecs="' + R.videoCodec + "," + R.audioCodec + '"') : R.mimeType = 'video/x-flv; codecs="' + R.audioCodec + '"', R.isComplete() && this._onMediaInfo(R);
                        } else if (L.packetType === 1) {
                          var I = this._timestampBase + e, U = { unit: L.data, length: L.data.byteLength, dts: I, pts: I };
                          x.samples.push(U), x.length += L.data.length;
                        } else
                          S.default.e(this.TAG, "Flv: Unsupported AAC data type " + L.packetType);
                      } else if (p === 2) {
                        if (!m.codec) {
                          var O = this._parseMP3AudioData(t, s + 1, n - 1, !0);
                          if (O == null)
                            return;
                          m.audioSampleRate = O.samplingRate, m.channelCount = O.channelCount, m.codec = O.codec, m.originalCodec = O.originalCodec, m.refSampleDuration = 1152 / m.audioSampleRate * m.timescale, S.default.v(this.TAG, "Parsed MPEG Audio Frame Header"), this._audioInitialMetadataDispatched = !0, this._onTrackMetadata("audio", m);
                          var R = this._mediaInfo;
                          R.audioCodec = m.codec, R.audioSampleRate = m.audioSampleRate, R.audioChannelCount = m.channelCount, R.audioDataRate = O.bitRate, R.hasVideo ? R.videoCodec != null && (R.mimeType = 'video/x-flv; codecs="' + R.videoCodec + "," + R.audioCodec + '"') : R.mimeType = 'video/x-flv; codecs="' + R.audioCodec + '"', R.isComplete() && this._onMediaInfo(R);
                        }
                        var j = this._parseMP3AudioData(t, s + 1, n - 1, !1);
                        if (j == null)
                          return;
                        var I = this._timestampBase + e, F = { unit: j, length: j.byteLength, dts: I, pts: I };
                        x.samples.push(F), x.length += j.length;
                      }
                    }
                  }, i.prototype._parseAACAudioData = function(t, s, n) {
                    if (n <= 1) {
                      S.default.w(this.TAG, "Flv: Invalid AAC packet, missing AACPacketType or/and Data!");
                      return;
                    }
                    var e = {}, f = new Uint8Array(t, s, n);
                    return e.packetType = f[0], f[0] === 0 ? e.data = this._parseAACAudioSpecificConfig(t, s + 1, n - 1) : e.data = f.subarray(1), e;
                  }, i.prototype._parseAACAudioSpecificConfig = function(t, s, n) {
                    var e = new Uint8Array(t, s, n), f = null, c = 0, p = 0, g = 0, y = null;
                    if (c = p = e[0] >>> 3, g = (e[0] & 7) << 1 | e[1] >>> 7, g < 0 || g >= this._mpegSamplingRates.length) {
                      this._onError(o.default.FORMAT_ERROR, "Flv: AAC invalid sampling frequency index!");
                      return;
                    }
                    var E = this._mpegSamplingRates[g], m = (e[1] & 120) >>> 3;
                    if (m < 0 || m >= 8) {
                      this._onError(o.default.FORMAT_ERROR, "Flv: AAC invalid channel configuration");
                      return;
                    }
                    c === 5 && (y = (e[1] & 7) << 1 | e[2] >>> 7, (e[2] & 124) >>> 2);
                    var x = self.navigator.userAgent.toLowerCase();
                    return x.indexOf("firefox") !== -1 ? g >= 6 ? (c = 5, f = new Array(4), y = g - 3) : (c = 2, f = new Array(2), y = g) : x.indexOf("android") !== -1 ? (c = 2, f = new Array(2), y = g) : (c = 5, y = g, f = new Array(4), g >= 6 ? y = g - 3 : m === 1 && (c = 2, f = new Array(2), y = g)), f[0] = c << 3, f[0] |= (g & 15) >>> 1, f[1] = (g & 15) << 7, f[1] |= (m & 15) << 3, c === 5 && (f[1] |= (y & 15) >>> 1, f[2] = (y & 1) << 7, f[2] |= 8, f[3] = 0), {
                      config: f,
                      samplingRate: E,
                      channelCount: m,
                      codec: "mp4a.40." + c,
                      originalCodec: "mp4a.40." + p
                    };
                  }, i.prototype._parseMP3AudioData = function(t, s, n, e) {
                    if (n < 4) {
                      S.default.w(this.TAG, "Flv: Invalid MP3 packet, header missing!");
                      return;
                    }
                    this._littleEndian;
                    var f = new Uint8Array(t, s, n), c = null;
                    if (e) {
                      if (f[0] !== 255)
                        return;
                      var p = f[1] >>> 3 & 3, g = (f[1] & 6) >> 1, y = (f[2] & 240) >>> 4, E = (f[2] & 12) >>> 2, m = f[3] >>> 6 & 3, x = m !== 3 ? 2 : 1, L = 0, O = 0, R = "mp3";
                      switch (p) {
                        case 0:
                          L = this._mpegAudioV25SampleRateTable[E];
                          break;
                        case 2:
                          L = this._mpegAudioV20SampleRateTable[E];
                          break;
                        case 3:
                          L = this._mpegAudioV10SampleRateTable[E];
                          break;
                      }
                      switch (g) {
                        case 1:
                          y < this._mpegAudioL3BitRateTable.length && (O = this._mpegAudioL3BitRateTable[y]);
                          break;
                        case 2:
                          y < this._mpegAudioL2BitRateTable.length && (O = this._mpegAudioL2BitRateTable[y]);
                          break;
                        case 3:
                          y < this._mpegAudioL1BitRateTable.length && (O = this._mpegAudioL1BitRateTable[y]);
                          break;
                      }
                      c = {
                        bitRate: O,
                        samplingRate: L,
                        channelCount: x,
                        codec: R,
                        originalCodec: R
                      };
                    } else
                      c = f;
                    return c;
                  }, i.prototype._parseVideoData = function(t, s, n, e, f) {
                    if (n <= 1) {
                      S.default.w(this.TAG, "Flv: Invalid video packet, missing VideoData payload!");
                      return;
                    }
                    if (!(this._hasVideoFlagOverrided === !0 && this._hasVideo === !1)) {
                      var c = new Uint8Array(t, s, n)[0], p = (c & 240) >>> 4, g = c & 15;
                      if (g !== 7) {
                        this._onError(o.default.CODEC_UNSUPPORTED, "Flv: Unsupported codec in video frame: " + g);
                        return;
                      }
                      this._parseAVCVideoPacket(t, s + 1, n - 1, e, f, p);
                    }
                  }, i.prototype._parseAVCVideoPacket = function(t, s, n, e, f, c) {
                    if (n < 4) {
                      S.default.w(this.TAG, "Flv: Invalid AVC packet, missing AVCPacketType or/and CompositionTime");
                      return;
                    }
                    var p = this._littleEndian, g = new DataView(t, s, n), y = g.getUint8(0), E = g.getUint32(0, !p) & 16777215, m = E << 8 >> 8;
                    if (y === 0)
                      this._parseAVCDecoderConfigurationRecord(t, s + 4, n - 4);
                    else if (y === 1)
                      this._parseAVCVideoData(t, s + 4, n - 4, e, f, c, m);
                    else if (y !== 2) {
                      this._onError(o.default.FORMAT_ERROR, "Flv: Invalid video packet type " + y);
                      return;
                    }
                  }, i.prototype._parseAVCDecoderConfigurationRecord = function(t, s, n) {
                    if (n < 7) {
                      S.default.w(this.TAG, "Flv: Invalid AVCDecoderConfigurationRecord, lack of data!");
                      return;
                    }
                    var e = this._videoMetadata, f = this._videoTrack, c = this._littleEndian, p = new DataView(t, s, n);
                    e ? typeof e.avcc < "u" && S.default.w(this.TAG, "Found another AVCDecoderConfigurationRecord!") : (this._hasVideo === !1 && this._hasVideoFlagOverrided === !1 && (this._hasVideo = !0, this._mediaInfo.hasVideo = !0), e = this._videoMetadata = {}, e.type = "video", e.id = f.id, e.timescale = this._timescale, e.duration = this._duration);
                    var g = p.getUint8(0), y = p.getUint8(1);
                    if (p.getUint8(2), p.getUint8(3), g !== 1 || y === 0) {
                      this._onError(o.default.FORMAT_ERROR, "Flv: Invalid AVCDecoderConfigurationRecord");
                      return;
                    }
                    if (this._naluLengthSize = (p.getUint8(4) & 3) + 1, this._naluLengthSize !== 3 && this._naluLengthSize !== 4) {
                      this._onError(o.default.FORMAT_ERROR, "Flv: Strange NaluLengthSizeMinusOne: " + (this._naluLengthSize - 1));
                      return;
                    }
                    var E = p.getUint8(5) & 31;
                    if (E === 0) {
                      this._onError(o.default.FORMAT_ERROR, "Flv: Invalid AVCDecoderConfigurationRecord: No SPS");
                      return;
                    } else E > 1 && S.default.w(this.TAG, "Flv: Strange AVCDecoderConfigurationRecord: SPS Count = " + E);
                    for (var m = 6, x = 0; x < E; x++) {
                      var L = p.getUint16(m, !c);
                      if (m += 2, L !== 0) {
                        var O = new Uint8Array(t, s + m, L);
                        m += L;
                        var R = u.default.parseSPS(O);
                        if (x === 0) {
                          e.codecWidth = R.codec_size.width, e.codecHeight = R.codec_size.height, e.presentWidth = R.present_size.width, e.presentHeight = R.present_size.height, e.profile = R.profile_string, e.level = R.level_string, e.bitDepth = R.bit_depth, e.chromaFormat = R.chroma_format, e.sarRatio = R.sar_ratio, e.frameRate = R.frame_rate, (R.frame_rate.fixed === !1 || R.frame_rate.fps_num === 0 || R.frame_rate.fps_den === 0) && (e.frameRate = this._referenceFrameRate);
                          var I = e.frameRate.fps_den, U = e.frameRate.fps_num;
                          e.refSampleDuration = e.timescale * (I / U);
                          for (var j = O.subarray(1, 4), F = "avc1.", N = 0; N < 3; N++) {
                            var W = j[N].toString(16);
                            W.length < 2 && (W = "0" + W), F += W;
                          }
                          e.codec = F;
                          var w = this._mediaInfo;
                          w.width = e.codecWidth, w.height = e.codecHeight, w.fps = e.frameRate.fps, w.profile = e.profile, w.level = e.level, w.refFrames = R.ref_frames, w.chromaFormat = R.chroma_format_string, w.sarNum = e.sarRatio.width, w.sarDen = e.sarRatio.height, w.videoCodec = F, w.hasAudio ? w.audioCodec != null && (w.mimeType = 'video/x-flv; codecs="' + w.videoCodec + "," + w.audioCodec + '"') : w.mimeType = 'video/x-flv; codecs="' + w.videoCodec + '"', w.isComplete() && this._onMediaInfo(w);
                        }
                      }
                    }
                    var G = p.getUint8(m);
                    if (G === 0) {
                      this._onError(o.default.FORMAT_ERROR, "Flv: Invalid AVCDecoderConfigurationRecord: No PPS");
                      return;
                    } else G > 1 && S.default.w(this.TAG, "Flv: Strange AVCDecoderConfigurationRecord: PPS Count = " + G);
                    m++;
                    for (var x = 0; x < G; x++) {
                      var L = p.getUint16(m, !c);
                      m += 2, L !== 0 && (m += L);
                    }
                    e.avcc = new Uint8Array(n), e.avcc.set(new Uint8Array(t, s, n), 0), S.default.v(this.TAG, "Parsed AVCDecoderConfigurationRecord"), this._isInitialMetadataDispatched() ? this._dispatch && (this._audioTrack.length || this._videoTrack.length) && this._onDataAvailable(this._audioTrack, this._videoTrack) : this._videoInitialMetadataDispatched = !0, this._dispatch = !1, this._onTrackMetadata("video", e);
                  }, i.prototype._parseAVCVideoData = function(t, s, n, e, f, c, p) {
                    for (var g = this._littleEndian, y = new DataView(t, s, n), E = [], m = 0, x = 0, L = this._naluLengthSize, O = this._timestampBase + e, R = c === 1; x < n; ) {
                      if (x + 4 >= n) {
                        S.default.w(this.TAG, "Malformed Nalu near timestamp " + O + ", offset = " + x + ", dataSize = " + n);
                        break;
                      }
                      var I = y.getUint32(x, !g);
                      if (L === 3 && (I >>>= 8), I > n - L) {
                        S.default.w(this.TAG, "Malformed Nalus near timestamp " + O + ", NaluSize > DataSize!");
                        return;
                      }
                      var U = y.getUint8(x + L) & 31;
                      U === 5 && (R = !0);
                      var j = new Uint8Array(t, s + x, L + I), F = { type: U, data: j };
                      E.push(F), m += j.byteLength, x += L + I;
                    }
                    if (E.length) {
                      var N = this._videoTrack, W = {
                        units: E,
                        length: m,
                        isKeyframe: R,
                        dts: O,
                        cts: p,
                        pts: O + p
                      };
                      R && (W.fileposition = f), N.samples.push(W), N.length += m;
                    }
                  }, i;
                }()
              );
              A.default = l;
            }, "./src/demux/flv-demuxer.js")
          ),
          /***/
          "./src/demux/sps-parser.js": (
            /*!*********************************!*\
              !*** ./src/demux/sps-parser.js ***!
              \*********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ./exp-golomb.js */
                "./src/demux/exp-golomb.js"
              ), _ = (
                /** @class */
                function() {
                  function u() {
                  }
                  return d(u, "SPSParser"), u._ebsp2rbsp = function(o) {
                    for (var h = o, r = h.byteLength, a = new Uint8Array(r), l = 0, i = 0; i < r; i++)
                      i >= 2 && h[i] === 3 && h[i - 1] === 0 && h[i - 2] === 0 || (a[l] = h[i], l++);
                    return new Uint8Array(a.buffer, 0, l);
                  }, u.parseSPS = function(o) {
                    var h = u._ebsp2rbsp(o), r = new S.default(h);
                    r.readByte();
                    var a = r.readByte();
                    r.readByte();
                    var l = r.readByte();
                    r.readUEG();
                    var i = u.getProfileString(a), t = u.getLevelString(l), s = 1, n = 420, e = [0, 420, 422, 444], f = 8;
                    if ((a === 100 || a === 110 || a === 122 || a === 244 || a === 44 || a === 83 || a === 86 || a === 118 || a === 128 || a === 138 || a === 144) && (s = r.readUEG(), s === 3 && r.readBits(1), s <= 3 && (n = e[s]), f = r.readUEG() + 8, r.readUEG(), r.readBits(1), r.readBool()))
                      for (var c = s !== 3 ? 8 : 12, p = 0; p < c; p++)
                        r.readBool() && (p < 6 ? u._skipScalingList(r, 16) : u._skipScalingList(r, 64));
                    r.readUEG();
                    var g = r.readUEG();
                    if (g === 0)
                      r.readUEG();
                    else if (g === 1) {
                      r.readBits(1), r.readSEG(), r.readSEG();
                      for (var y = r.readUEG(), p = 0; p < y; p++)
                        r.readSEG();
                    }
                    var E = r.readUEG();
                    r.readBits(1);
                    var m = r.readUEG(), x = r.readUEG(), L = r.readBits(1);
                    L === 0 && r.readBits(1), r.readBits(1);
                    var O = 0, R = 0, I = 0, U = 0, j = r.readBool();
                    j && (O = r.readUEG(), R = r.readUEG(), I = r.readUEG(), U = r.readUEG());
                    var F = 1, N = 1, W = 0, w = !0, G = 0, ee = 0, K = r.readBool();
                    if (K) {
                      if (r.readBool()) {
                        var V = r.readByte(), $ = [1, 12, 10, 16, 40, 24, 20, 32, 80, 18, 15, 64, 160, 4, 3, 2], X = [1, 11, 11, 11, 33, 11, 11, 11, 33, 11, 11, 33, 99, 3, 2, 1];
                        V > 0 && V < 16 ? (F = $[V - 1], N = X[V - 1]) : V === 255 && (F = r.readByte() << 8 | r.readByte(), N = r.readByte() << 8 | r.readByte());
                      }
                      if (r.readBool() && r.readBool(), r.readBool() && (r.readBits(4), r.readBool() && r.readBits(24)), r.readBool() && (r.readUEG(), r.readUEG()), r.readBool()) {
                        var Z = r.readBits(32), ie = r.readBits(32);
                        w = r.readBool(), G = ie, ee = Z * 2, W = G / ee;
                      }
                    }
                    var z = 1;
                    (F !== 1 || N !== 1) && (z = F / N);
                    var P = 0, J = 0;
                    if (s === 0)
                      P = 1, J = 2 - L;
                    else {
                      var te = s === 3 ? 1 : 2, oe = s === 1 ? 2 : 1;
                      P = te, J = oe * (2 - L);
                    }
                    var ne = (m + 1) * 16, se = (2 - L) * ((x + 1) * 16);
                    ne -= (O + R) * P, se -= (I + U) * J;
                    var ae = Math.ceil(ne * z);
                    return r.destroy(), r = null, {
                      profile_string: i,
                      level_string: t,
                      bit_depth: f,
                      ref_frames: E,
                      chroma_format: n,
                      chroma_format_string: u.getChromaFormatString(n),
                      frame_rate: {
                        fixed: w,
                        fps: W,
                        fps_den: ee,
                        fps_num: G
                      },
                      sar_ratio: {
                        width: F,
                        height: N
                      },
                      codec_size: {
                        width: ne,
                        height: se
                      },
                      present_size: {
                        width: ae,
                        height: se
                      }
                    };
                  }, u._skipScalingList = function(o, h) {
                    for (var r = 8, a = 8, l = 0, i = 0; i < h; i++)
                      a !== 0 && (l = o.readSEG(), a = (r + l + 256) % 256), r = a === 0 ? r : a;
                  }, u.getProfileString = function(o) {
                    switch (o) {
                      case 66:
                        return "Baseline";
                      case 77:
                        return "Main";
                      case 88:
                        return "Extended";
                      case 100:
                        return "High";
                      case 110:
                        return "High10";
                      case 122:
                        return "High422";
                      case 244:
                        return "High444";
                      default:
                        return "Unknown";
                    }
                  }, u.getLevelString = function(o) {
                    return (o / 10).toFixed(1);
                  }, u.getChromaFormatString = function(o) {
                    switch (o) {
                      case 420:
                        return "4:2:0";
                      case 422:
                        return "4:2:2";
                      case 444:
                        return "4:4:4";
                      default:
                        return "Unknown";
                    }
                  }, u;
                }()
              );
              A.default = _;
            }, "./src/demux/sps-parser.js")
          ),
          /***/
          "./src/flv.js": (
            /*!********************!*\
              !*** ./src/flv.js ***!
              \********************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ./utils/polyfill.js */
                "./src/utils/polyfill.js"
              ), _ = v(
                /*! ./core/features.js */
                "./src/core/features.js"
              ), u = v(
                /*! ./io/loader.js */
                "./src/io/loader.js"
              ), o = v(
                /*! ./player/flv-player.js */
                "./src/player/flv-player.js"
              ), h = v(
                /*! ./player/native-player.js */
                "./src/player/native-player.js"
              ), r = v(
                /*! ./player/player-events.js */
                "./src/player/player-events.js"
              ), a = v(
                /*! ./player/player-errors.js */
                "./src/player/player-errors.js"
              ), l = v(
                /*! ./utils/logging-control.js */
                "./src/utils/logging-control.js"
              ), i = v(
                /*! ./utils/exception.js */
                "./src/utils/exception.js"
              );
              S.default.install();
              function t(f, c) {
                var p = f;
                if (p == null || typeof p != "object")
                  throw new i.InvalidArgumentException("MediaDataSource must be an javascript object!");
                if (!p.hasOwnProperty("type"))
                  throw new i.InvalidArgumentException("MediaDataSource must has type field to indicate video file type!");
                switch (p.type) {
                  case "flv":
                    return new o.default(p, c);
                  default:
                    return new h.default(p, c);
                }
              }
              d(t, "createPlayer");
              function s() {
                return _.default.supportMSEH264Playback();
              }
              d(s, "isSupported");
              function n() {
                return _.default.getFeatureList();
              }
              d(n, "getFeatureList");
              var e = {};
              e.createPlayer = t, e.isSupported = s, e.getFeatureList = n, e.BaseLoader = u.BaseLoader, e.LoaderStatus = u.LoaderStatus, e.LoaderErrors = u.LoaderErrors, e.Events = r.default, e.ErrorTypes = a.ErrorTypes, e.ErrorDetails = a.ErrorDetails, e.FlvPlayer = o.default, e.NativePlayer = h.default, e.LoggingControl = l.default, Object.defineProperty(e, "version", {
                enumerable: !0,
                get: /* @__PURE__ */ d(function() {
                  return "1.6.2";
                }, "get")
              }), A.default = e;
            }, "./src/flv.js")
          ),
          /***/
          "./src/index.js": (
            /*!**********************!*\
              !*** ./src/index.js ***!
              \**********************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              D.exports = v(
                /*! ./flv.js */
                "./src/flv.js"
              ).default;
            }, "./src/index.js")
          ),
          /***/
          "./src/io/fetch-stream-loader.js": (
            /*!***************************************!*\
              !*** ./src/io/fetch-stream-loader.js ***!
              \***************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ../utils/browser.js */
                "./src/utils/browser.js"
              ), _ = v(
                /*! ./loader.js */
                "./src/io/loader.js"
              ), u = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), o = /* @__PURE__ */ function() {
                var r = /* @__PURE__ */ d(function(a, l) {
                  return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
                    i.__proto__ = t;
                  } || function(i, t) {
                    for (var s in t) Object.prototype.hasOwnProperty.call(t, s) && (i[s] = t[s]);
                  }, r(a, l);
                }, "extendStatics");
                return function(a, l) {
                  if (typeof l != "function" && l !== null)
                    throw new TypeError("Class extends value " + String(l) + " is not a constructor or null");
                  r(a, l);
                  function i() {
                    this.constructor = a;
                  }
                  d(i, "__"), a.prototype = l === null ? Object.create(l) : (i.prototype = l.prototype, new i());
                };
              }(), h = (
                /** @class */
                function(r) {
                  o(a, r);
                  function a(l, i) {
                    var t = r.call(this, "fetch-stream-loader") || this;
                    return t.TAG = "FetchStreamLoader", t._seekHandler = l, t._config = i, t._needStash = !0, t._requestAbort = !1, t._contentLength = null, t._receivedLength = 0, t;
                  }
                  return d(a, "FetchStreamLoader"), a.isSupported = function() {
                    try {
                      var l = S.default.msedge && S.default.version.minor >= 15048, i = S.default.msedge ? l : !0;
                      return self.fetch && self.ReadableStream && i;
                    } catch {
                      return !1;
                    }
                  }, a.prototype.destroy = function() {
                    this.isWorking() && this.abort(), r.prototype.destroy.call(this);
                  }, a.prototype.open = function(l, i) {
                    var t = this;
                    this._dataSource = l, this._range = i;
                    var s = l.url;
                    this._config.reuseRedirectedURL && l.redirectedURL != null && (s = l.redirectedURL);
                    var n = this._seekHandler.getConfig(s, i), e = new self.Headers();
                    if (typeof n.headers == "object") {
                      var f = n.headers;
                      for (var c in f)
                        f.hasOwnProperty(c) && e.append(c, f[c]);
                    }
                    var p = {
                      method: "GET",
                      headers: e,
                      mode: "cors",
                      cache: "default",
                      // The default policy of Fetch API in the whatwg standard
                      // Safari incorrectly indicates 'no-referrer' as default policy, fuck it
                      referrerPolicy: "no-referrer-when-downgrade"
                    };
                    if (typeof this._config.headers == "object")
                      for (var c in this._config.headers)
                        e.append(c, this._config.headers[c]);
                    l.cors === !1 && (p.mode = "same-origin"), l.withCredentials && (p.credentials = "include"), l.referrerPolicy && (p.referrerPolicy = l.referrerPolicy), self.AbortController && (this._abortController = new self.AbortController(), p.signal = this._abortController.signal), this._status = _.LoaderStatus.kConnecting, self.fetch(n.url, p).then(function(g) {
                      if (t._requestAbort) {
                        t._status = _.LoaderStatus.kIdle, g.body.cancel();
                        return;
                      }
                      if (g.ok && g.status >= 200 && g.status <= 299) {
                        if (g.url !== n.url && t._onURLRedirect) {
                          var y = t._seekHandler.removeURLParameters(g.url);
                          t._onURLRedirect(y);
                        }
                        var E = g.headers.get("Content-Length");
                        return E != null && (t._contentLength = parseInt(E), t._contentLength !== 0 && t._onContentLengthKnown && t._onContentLengthKnown(t._contentLength)), t._pump.call(t, g.body.getReader());
                      } else if (t._status = _.LoaderStatus.kError, t._onError)
                        t._onError(_.LoaderErrors.HTTP_STATUS_CODE_INVALID, { code: g.status, msg: g.statusText });
                      else
                        throw new u.RuntimeException("FetchStreamLoader: Http code invalid, " + g.status + " " + g.statusText);
                    }).catch(function(g) {
                      if (!(t._abortController && t._abortController.signal.aborted))
                        if (t._status = _.LoaderStatus.kError, t._onError)
                          t._onError(_.LoaderErrors.EXCEPTION, { code: -1, msg: g.message });
                        else
                          throw g;
                    });
                  }, a.prototype.abort = function() {
                    if (this._requestAbort = !0, (this._status !== _.LoaderStatus.kBuffering || !S.default.chrome) && this._abortController)
                      try {
                        this._abortController.abort();
                      } catch {
                      }
                  }, a.prototype._pump = function(l) {
                    var i = this;
                    return l.read().then(function(t) {
                      if (t.done)
                        if (i._contentLength !== null && i._receivedLength < i._contentLength) {
                          i._status = _.LoaderStatus.kError;
                          var s = _.LoaderErrors.EARLY_EOF, n = { code: -1, msg: "Fetch stream meet Early-EOF" };
                          if (i._onError)
                            i._onError(s, n);
                          else
                            throw new u.RuntimeException(n.msg);
                        } else
                          i._status = _.LoaderStatus.kComplete, i._onComplete && i._onComplete(i._range.from, i._range.from + i._receivedLength - 1);
                      else {
                        if (i._abortController && i._abortController.signal.aborted) {
                          i._status = _.LoaderStatus.kComplete;
                          return;
                        } else if (i._requestAbort === !0)
                          return i._status = _.LoaderStatus.kComplete, l.cancel();
                        i._status = _.LoaderStatus.kBuffering;
                        var e = t.value.buffer, f = i._range.from + i._receivedLength;
                        i._receivedLength += e.byteLength, i._onDataArrival && i._onDataArrival(e, f, i._receivedLength), i._pump(l);
                      }
                    }).catch(function(t) {
                      if (i._abortController && i._abortController.signal.aborted) {
                        i._status = _.LoaderStatus.kComplete;
                        return;
                      }
                      if (!(t.code === 11 && S.default.msedge)) {
                        i._status = _.LoaderStatus.kError;
                        var s = 0, n = null;
                        if ((t.code === 19 || t.message === "network error") && // NETWORK_ERR
                        (i._contentLength === null || i._contentLength !== null && i._receivedLength < i._contentLength) ? (s = _.LoaderErrors.EARLY_EOF, n = { code: t.code, msg: "Fetch stream meet Early-EOF" }) : (s = _.LoaderErrors.EXCEPTION, n = { code: t.code, msg: t.message }), i._onError)
                          i._onError(s, n);
                        else
                          throw new u.RuntimeException(n.msg);
                      }
                    });
                  }, a;
                }(_.BaseLoader)
              );
              A.default = h;
            }, "./src/io/fetch-stream-loader.js")
          ),
          /***/
          "./src/io/io-controller.js": (
            /*!*********************************!*\
              !*** ./src/io/io-controller.js ***!
              \*********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ../utils/logger.js */
                "./src/utils/logger.js"
              ), _ = v(
                /*! ./speed-sampler.js */
                "./src/io/speed-sampler.js"
              ), u = v(
                /*! ./loader.js */
                "./src/io/loader.js"
              ), o = v(
                /*! ./fetch-stream-loader.js */
                "./src/io/fetch-stream-loader.js"
              ), h = v(
                /*! ./xhr-moz-chunked-loader.js */
                "./src/io/xhr-moz-chunked-loader.js"
              ), r = v(
                /*! ./xhr-range-loader.js */
                "./src/io/xhr-range-loader.js"
              ), a = v(
                /*! ./websocket-loader.js */
                "./src/io/websocket-loader.js"
              ), l = v(
                /*! ./range-seek-handler.js */
                "./src/io/range-seek-handler.js"
              ), i = v(
                /*! ./param-seek-handler.js */
                "./src/io/param-seek-handler.js"
              ), t = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), s = (
                /** @class */
                function() {
                  function n(e, f, c) {
                    this.TAG = "IOController", this._config = f, this._extraData = c, this._stashInitialSize = 1024 * 384, f.stashInitialSize != null && f.stashInitialSize > 0 && (this._stashInitialSize = f.stashInitialSize), this._stashUsed = 0, this._stashSize = this._stashInitialSize, this._bufferSize = 1024 * 1024 * 3, this._stashBuffer = new ArrayBuffer(this._bufferSize), this._stashByteStart = 0, this._enableStash = !0, f.enableStashBuffer === !1 && (this._enableStash = !1), this._loader = null, this._loaderClass = null, this._seekHandler = null, this._dataSource = e, this._isWebSocketURL = /wss?:\/\/(.+?)/.test(e.url), this._refTotalLength = e.filesize ? e.filesize : null, this._totalLength = this._refTotalLength, this._fullRequestFlag = !1, this._currentRange = null, this._redirectedURL = null, this._speedNormalized = 0, this._speedSampler = new _.default(), this._speedNormalizeList = [64, 128, 256, 384, 512, 768, 1024, 1536, 2048, 3072, 4096], this._isEarlyEofReconnecting = !1, this._paused = !1, this._resumeFrom = 0, this._onDataArrival = null, this._onSeeked = null, this._onError = null, this._onComplete = null, this._onRedirect = null, this._onRecoveredEarlyEof = null, this._selectSeekHandler(), this._selectLoader(), this._createLoader();
                  }
                  return d(n, "IOController"), n.prototype.destroy = function() {
                    this._loader.isWorking() && this._loader.abort(), this._loader.destroy(), this._loader = null, this._loaderClass = null, this._dataSource = null, this._stashBuffer = null, this._stashUsed = this._stashSize = this._bufferSize = this._stashByteStart = 0, this._currentRange = null, this._speedSampler = null, this._isEarlyEofReconnecting = !1, this._onDataArrival = null, this._onSeeked = null, this._onError = null, this._onComplete = null, this._onRedirect = null, this._onRecoveredEarlyEof = null, this._extraData = null;
                  }, n.prototype.isWorking = function() {
                    return this._loader && this._loader.isWorking() && !this._paused;
                  }, n.prototype.isPaused = function() {
                    return this._paused;
                  }, Object.defineProperty(n.prototype, "status", {
                    get: /* @__PURE__ */ d(function() {
                      return this._loader.status;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "extraData", {
                    get: /* @__PURE__ */ d(function() {
                      return this._extraData;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(e) {
                      this._extraData = e;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "onDataArrival", {
                    // prototype: function onDataArrival(chunks: ArrayBuffer, byteStart: number): number
                    get: /* @__PURE__ */ d(function() {
                      return this._onDataArrival;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(e) {
                      this._onDataArrival = e;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "onSeeked", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onSeeked;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(e) {
                      this._onSeeked = e;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "onError", {
                    // prototype: function onError(type: number, info: {code: number, msg: string}): void
                    get: /* @__PURE__ */ d(function() {
                      return this._onError;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(e) {
                      this._onError = e;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "onComplete", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onComplete;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(e) {
                      this._onComplete = e;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "onRedirect", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onRedirect;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(e) {
                      this._onRedirect = e;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "onRecoveredEarlyEof", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onRecoveredEarlyEof;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(e) {
                      this._onRecoveredEarlyEof = e;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "currentURL", {
                    get: /* @__PURE__ */ d(function() {
                      return this._dataSource.url;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "hasRedirect", {
                    get: /* @__PURE__ */ d(function() {
                      return this._redirectedURL != null || this._dataSource.redirectedURL != null;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "currentRedirectedURL", {
                    get: /* @__PURE__ */ d(function() {
                      return this._redirectedURL || this._dataSource.redirectedURL;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "currentSpeed", {
                    // in KB/s
                    get: /* @__PURE__ */ d(function() {
                      return this._loaderClass === r.default ? this._loader.currentSpeed : this._speedSampler.lastSecondKBps;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(n.prototype, "loaderType", {
                    get: /* @__PURE__ */ d(function() {
                      return this._loader.type;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), n.prototype._selectSeekHandler = function() {
                    var e = this._config;
                    if (e.seekType === "range")
                      this._seekHandler = new l.default(this._config.rangeLoadZeroStart);
                    else if (e.seekType === "param") {
                      var f = e.seekParamStart || "bstart", c = e.seekParamEnd || "bend";
                      this._seekHandler = new i.default(f, c);
                    } else if (e.seekType === "custom") {
                      if (typeof e.customSeekHandler != "function")
                        throw new t.InvalidArgumentException("Custom seekType specified in config but invalid customSeekHandler!");
                      this._seekHandler = new e.customSeekHandler();
                    } else
                      throw new t.InvalidArgumentException("Invalid seekType in config: " + e.seekType);
                  }, n.prototype._selectLoader = function() {
                    if (this._config.customLoader != null)
                      this._loaderClass = this._config.customLoader;
                    else if (this._isWebSocketURL)
                      this._loaderClass = a.default;
                    else if (o.default.isSupported())
                      this._loaderClass = o.default;
                    else if (h.default.isSupported())
                      this._loaderClass = h.default;
                    else if (r.default.isSupported())
                      this._loaderClass = r.default;
                    else
                      throw new t.RuntimeException("Your browser doesn't support xhr with arraybuffer responseType!");
                  }, n.prototype._createLoader = function() {
                    this._loader = new this._loaderClass(this._seekHandler, this._config), this._loader.needStashBuffer === !1 && (this._enableStash = !1), this._loader.onContentLengthKnown = this._onContentLengthKnown.bind(this), this._loader.onURLRedirect = this._onURLRedirect.bind(this), this._loader.onDataArrival = this._onLoaderChunkArrival.bind(this), this._loader.onComplete = this._onLoaderComplete.bind(this), this._loader.onError = this._onLoaderError.bind(this);
                  }, n.prototype.open = function(e) {
                    this._currentRange = { from: 0, to: -1 }, e && (this._currentRange.from = e), this._speedSampler.reset(), e || (this._fullRequestFlag = !0), this._loader.open(this._dataSource, Object.assign({}, this._currentRange));
                  }, n.prototype.abort = function() {
                    this._loader.abort(), this._paused && (this._paused = !1, this._resumeFrom = 0);
                  }, n.prototype.pause = function() {
                    this.isWorking() && (this._loader.abort(), this._stashUsed !== 0 ? (this._resumeFrom = this._stashByteStart, this._currentRange.to = this._stashByteStart - 1) : this._resumeFrom = this._currentRange.to + 1, this._stashUsed = 0, this._stashByteStart = 0, this._paused = !0);
                  }, n.prototype.resume = function() {
                    if (this._paused) {
                      this._paused = !1;
                      var e = this._resumeFrom;
                      this._resumeFrom = 0, this._internalSeek(e, !0);
                    }
                  }, n.prototype.seek = function(e) {
                    this._paused = !1, this._stashUsed = 0, this._stashByteStart = 0, this._internalSeek(e, !0);
                  }, n.prototype._internalSeek = function(e, f) {
                    this._loader.isWorking() && this._loader.abort(), this._flushStashBuffer(f), this._loader.destroy(), this._loader = null;
                    var c = { from: e, to: -1 };
                    this._currentRange = { from: c.from, to: -1 }, this._speedSampler.reset(), this._stashSize = this._stashInitialSize, this._createLoader(), this._loader.open(this._dataSource, c), this._onSeeked && this._onSeeked();
                  }, n.prototype.updateUrl = function(e) {
                    if (!e || typeof e != "string" || e.length === 0)
                      throw new t.InvalidArgumentException("Url must be a non-empty string!");
                    this._dataSource.url = e;
                  }, n.prototype._expandBuffer = function(e) {
                    for (var f = this._stashSize; f + 1024 * 1024 * 1 < e; )
                      f *= 2;
                    if (f += 1024 * 1024 * 1, f !== this._bufferSize) {
                      var c = new ArrayBuffer(f);
                      if (this._stashUsed > 0) {
                        var p = new Uint8Array(this._stashBuffer, 0, this._stashUsed), g = new Uint8Array(c, 0, f);
                        g.set(p, 0);
                      }
                      this._stashBuffer = c, this._bufferSize = f;
                    }
                  }, n.prototype._normalizeSpeed = function(e) {
                    var f = this._speedNormalizeList, c = f.length - 1, p = 0, g = 0, y = c;
                    if (e < f[0])
                      return f[0];
                    for (; g <= y; ) {
                      if (p = g + Math.floor((y - g) / 2), p === c || e >= f[p] && e < f[p + 1])
                        return f[p];
                      f[p] < e ? g = p + 1 : y = p - 1;
                    }
                  }, n.prototype._adjustStashSize = function(e) {
                    var f = 0;
                    this._config.isLive || e < 512 ? f = e : e >= 512 && e <= 1024 ? f = Math.floor(e * 1.5) : f = e * 2, f > 8192 && (f = 8192);
                    var c = f * 1024 + 1024 * 1024 * 1;
                    this._bufferSize < c && this._expandBuffer(c), this._stashSize = f * 1024;
                  }, n.prototype._dispatchChunks = function(e, f) {
                    return this._currentRange.to = f + e.byteLength - 1, this._onDataArrival(e, f);
                  }, n.prototype._onURLRedirect = function(e) {
                    this._redirectedURL = e, this._onRedirect && this._onRedirect(e);
                  }, n.prototype._onContentLengthKnown = function(e) {
                    e && this._fullRequestFlag && (this._totalLength = e, this._fullRequestFlag = !1);
                  }, n.prototype._onLoaderChunkArrival = function(e, f, c) {
                    if (!this._onDataArrival)
                      throw new t.IllegalStateException("IOController: No existing consumer (onDataArrival) callback!");
                    if (!this._paused) {
                      this._isEarlyEofReconnecting && (this._isEarlyEofReconnecting = !1, this._onRecoveredEarlyEof && this._onRecoveredEarlyEof()), this._speedSampler.addBytes(e.byteLength);
                      var p = this._speedSampler.lastSecondKBps;
                      if (p !== 0) {
                        var g = this._normalizeSpeed(p);
                        this._speedNormalized !== g && (this._speedNormalized = g, this._adjustStashSize(g));
                      }
                      if (this._enableStash)
                        if (this._stashUsed === 0 && this._stashByteStart === 0 && (this._stashByteStart = f), this._stashUsed + e.byteLength <= this._stashSize) {
                          var m = new Uint8Array(this._stashBuffer, 0, this._stashSize);
                          m.set(new Uint8Array(e), this._stashUsed), this._stashUsed += e.byteLength;
                        } else {
                          var m = new Uint8Array(this._stashBuffer, 0, this._bufferSize);
                          if (this._stashUsed > 0) {
                            var L = this._stashBuffer.slice(0, this._stashUsed), y = this._dispatchChunks(L, this._stashByteStart);
                            if (y < L.byteLength) {
                              if (y > 0) {
                                var x = new Uint8Array(L, y);
                                m.set(x, 0), this._stashUsed = x.byteLength, this._stashByteStart += y;
                              }
                            } else
                              this._stashUsed = 0, this._stashByteStart += y;
                            this._stashUsed + e.byteLength > this._bufferSize && (this._expandBuffer(this._stashUsed + e.byteLength), m = new Uint8Array(this._stashBuffer, 0, this._bufferSize)), m.set(new Uint8Array(e), this._stashUsed), this._stashUsed += e.byteLength;
                          } else {
                            var y = this._dispatchChunks(e, f);
                            if (y < e.byteLength) {
                              var E = e.byteLength - y;
                              E > this._bufferSize && (this._expandBuffer(E), m = new Uint8Array(this._stashBuffer, 0, this._bufferSize)), m.set(new Uint8Array(e, y), 0), this._stashUsed += E, this._stashByteStart = f + y;
                            }
                          }
                        }
                      else if (this._stashUsed === 0) {
                        var y = this._dispatchChunks(e, f);
                        if (y < e.byteLength) {
                          var E = e.byteLength - y;
                          E > this._bufferSize && this._expandBuffer(E);
                          var m = new Uint8Array(this._stashBuffer, 0, this._bufferSize);
                          m.set(new Uint8Array(e, y), 0), this._stashUsed += E, this._stashByteStart = f + y;
                        }
                      } else {
                        this._stashUsed + e.byteLength > this._bufferSize && this._expandBuffer(this._stashUsed + e.byteLength);
                        var m = new Uint8Array(this._stashBuffer, 0, this._bufferSize);
                        m.set(new Uint8Array(e), this._stashUsed), this._stashUsed += e.byteLength;
                        var y = this._dispatchChunks(this._stashBuffer.slice(0, this._stashUsed), this._stashByteStart);
                        if (y < this._stashUsed && y > 0) {
                          var x = new Uint8Array(this._stashBuffer, y);
                          m.set(x, 0);
                        }
                        this._stashUsed -= y, this._stashByteStart += y;
                      }
                    }
                  }, n.prototype._flushStashBuffer = function(e) {
                    if (this._stashUsed > 0) {
                      var f = this._stashBuffer.slice(0, this._stashUsed), c = this._dispatchChunks(f, this._stashByteStart), p = f.byteLength - c;
                      if (c < f.byteLength)
                        if (e)
                          S.default.w(this.TAG, p + " bytes unconsumed data remain when flush buffer, dropped");
                        else {
                          if (c > 0) {
                            var g = new Uint8Array(this._stashBuffer, 0, this._bufferSize), y = new Uint8Array(f, c);
                            g.set(y, 0), this._stashUsed = y.byteLength, this._stashByteStart += c;
                          }
                          return 0;
                        }
                      return this._stashUsed = 0, this._stashByteStart = 0, p;
                    }
                    return 0;
                  }, n.prototype._onLoaderComplete = function(e, f) {
                    this._flushStashBuffer(!0), this._onComplete && this._onComplete(this._extraData);
                  }, n.prototype._onLoaderError = function(e, f) {
                    switch (S.default.e(this.TAG, "Loader error, code = " + f.code + ", msg = " + f.msg), this._flushStashBuffer(!1), this._isEarlyEofReconnecting && (this._isEarlyEofReconnecting = !1, e = u.LoaderErrors.UNRECOVERABLE_EARLY_EOF), e) {
                      case u.LoaderErrors.EARLY_EOF: {
                        if (!this._config.isLive && this._totalLength) {
                          var c = this._currentRange.to + 1;
                          c < this._totalLength && (S.default.w(this.TAG, "Connection lost, trying reconnect..."), this._isEarlyEofReconnecting = !0, this._internalSeek(c, !1));
                          return;
                        }
                        e = u.LoaderErrors.UNRECOVERABLE_EARLY_EOF;
                        break;
                      }
                      case u.LoaderErrors.UNRECOVERABLE_EARLY_EOF:
                      case u.LoaderErrors.CONNECTING_TIMEOUT:
                      case u.LoaderErrors.HTTP_STATUS_CODE_INVALID:
                      case u.LoaderErrors.EXCEPTION:
                        break;
                    }
                    if (this._onError)
                      this._onError(e, f);
                    else
                      throw new t.RuntimeException("IOException: " + f.msg);
                  }, n;
                }()
              );
              A.default = s;
            }, "./src/io/io-controller.js")
          ),
          /***/
          "./src/io/loader.js": (
            /*!**************************!*\
              !*** ./src/io/loader.js ***!
              \**************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A), v.d(A, {
                /* harmony export */
                LoaderStatus: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    _
                  );
                }, "LoaderStatus"),
                /* harmony export */
                LoaderErrors: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    u
                  );
                }, "LoaderErrors"),
                /* harmony export */
                BaseLoader: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    o
                  );
                }, "BaseLoader")
                /* harmony export */
              });
              var S = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), _ = {
                kIdle: 0,
                kConnecting: 1,
                kBuffering: 2,
                kError: 3,
                kComplete: 4
              }, u = {
                OK: "OK",
                EXCEPTION: "Exception",
                HTTP_STATUS_CODE_INVALID: "HttpStatusCodeInvalid",
                CONNECTING_TIMEOUT: "ConnectingTimeout",
                EARLY_EOF: "EarlyEof",
                UNRECOVERABLE_EARLY_EOF: "UnrecoverableEarlyEof"
              }, o = (
                /** @class */
                function() {
                  function h(r) {
                    this._type = r || "undefined", this._status = _.kIdle, this._needStash = !1, this._onContentLengthKnown = null, this._onURLRedirect = null, this._onDataArrival = null, this._onError = null, this._onComplete = null;
                  }
                  return d(h, "BaseLoader"), h.prototype.destroy = function() {
                    this._status = _.kIdle, this._onContentLengthKnown = null, this._onURLRedirect = null, this._onDataArrival = null, this._onError = null, this._onComplete = null;
                  }, h.prototype.isWorking = function() {
                    return this._status === _.kConnecting || this._status === _.kBuffering;
                  }, Object.defineProperty(h.prototype, "type", {
                    get: /* @__PURE__ */ d(function() {
                      return this._type;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h.prototype, "status", {
                    get: /* @__PURE__ */ d(function() {
                      return this._status;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h.prototype, "needStashBuffer", {
                    get: /* @__PURE__ */ d(function() {
                      return this._needStash;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h.prototype, "onContentLengthKnown", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onContentLengthKnown;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      this._onContentLengthKnown = r;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h.prototype, "onURLRedirect", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onURLRedirect;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      this._onURLRedirect = r;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h.prototype, "onDataArrival", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onDataArrival;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      this._onDataArrival = r;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h.prototype, "onError", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onError;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      this._onError = r;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h.prototype, "onComplete", {
                    get: /* @__PURE__ */ d(function() {
                      return this._onComplete;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      this._onComplete = r;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), h.prototype.open = function(r, a) {
                    throw new S.NotImplementedException("Unimplemented abstract function!");
                  }, h.prototype.abort = function() {
                    throw new S.NotImplementedException("Unimplemented abstract function!");
                  }, h;
                }()
              );
            }, "./src/io/loader.js")
          ),
          /***/
          "./src/io/param-seek-handler.js": (
            /*!**************************************!*\
              !*** ./src/io/param-seek-handler.js ***!
              \**************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = (
                /** @class */
                function() {
                  function _(u, o) {
                    this._startName = u, this._endName = o;
                  }
                  return d(_, "ParamSeekHandler"), _.prototype.getConfig = function(u, o) {
                    var h = u;
                    if (o.from !== 0 || o.to !== -1) {
                      var r = !0;
                      h.indexOf("?") === -1 && (h += "?", r = !1), r && (h += "&"), h += this._startName + "=" + o.from.toString(), o.to !== -1 && (h += "&" + this._endName + "=" + o.to.toString());
                    }
                    return {
                      url: h,
                      headers: {}
                    };
                  }, _.prototype.removeURLParameters = function(u) {
                    var o = u.split("?")[0], h = void 0, r = u.indexOf("?");
                    r !== -1 && (h = u.substring(r + 1));
                    var a = "";
                    if (h != null && h.length > 0)
                      for (var l = h.split("&"), i = 0; i < l.length; i++) {
                        var t = l[i].split("="), s = i > 0;
                        t[0] !== this._startName && t[0] !== this._endName && (s && (a += "&"), a += l[i]);
                      }
                    return a.length === 0 ? o : o + "?" + a;
                  }, _;
                }()
              );
              A.default = S;
            }, "./src/io/param-seek-handler.js")
          ),
          /***/
          "./src/io/range-seek-handler.js": (
            /*!**************************************!*\
              !*** ./src/io/range-seek-handler.js ***!
              \**************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = (
                /** @class */
                function() {
                  function _(u) {
                    this._zeroStart = u || !1;
                  }
                  return d(_, "RangeSeekHandler"), _.prototype.getConfig = function(u, o) {
                    var h = {};
                    if (o.from !== 0 || o.to !== -1) {
                      var r = void 0;
                      o.to !== -1 ? r = "bytes=" + o.from.toString() + "-" + o.to.toString() : r = "bytes=" + o.from.toString() + "-", h.Range = r;
                    } else this._zeroStart && (h.Range = "bytes=0-");
                    return {
                      url: u,
                      headers: h
                    };
                  }, _.prototype.removeURLParameters = function(u) {
                    return u;
                  }, _;
                }()
              );
              A.default = S;
            }, "./src/io/range-seek-handler.js")
          ),
          /***/
          "./src/io/speed-sampler.js": (
            /*!*********************************!*\
              !*** ./src/io/speed-sampler.js ***!
              \*********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = (
                /** @class */
                function() {
                  function _() {
                    this._firstCheckpoint = 0, this._lastCheckpoint = 0, this._intervalBytes = 0, this._totalBytes = 0, this._lastSecondBytes = 0, self.performance && self.performance.now ? this._now = self.performance.now.bind(self.performance) : this._now = Date.now;
                  }
                  return d(_, "SpeedSampler"), _.prototype.reset = function() {
                    this._firstCheckpoint = this._lastCheckpoint = 0, this._totalBytes = this._intervalBytes = 0, this._lastSecondBytes = 0;
                  }, _.prototype.addBytes = function(u) {
                    this._firstCheckpoint === 0 ? (this._firstCheckpoint = this._now(), this._lastCheckpoint = this._firstCheckpoint, this._intervalBytes += u, this._totalBytes += u) : this._now() - this._lastCheckpoint < 1e3 ? (this._intervalBytes += u, this._totalBytes += u) : (this._lastSecondBytes = this._intervalBytes, this._intervalBytes = u, this._totalBytes += u, this._lastCheckpoint = this._now());
                  }, Object.defineProperty(_.prototype, "currentKBps", {
                    get: /* @__PURE__ */ d(function() {
                      this.addBytes(0);
                      var u = (this._now() - this._lastCheckpoint) / 1e3;
                      return u == 0 && (u = 1), this._intervalBytes / u / 1024;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(_.prototype, "lastSecondKBps", {
                    get: /* @__PURE__ */ d(function() {
                      return this.addBytes(0), this._lastSecondBytes !== 0 ? this._lastSecondBytes / 1024 : this._now() - this._lastCheckpoint >= 500 ? this.currentKBps : 0;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(_.prototype, "averageKBps", {
                    get: /* @__PURE__ */ d(function() {
                      var u = (this._now() - this._firstCheckpoint) / 1e3;
                      return this._totalBytes / u / 1024;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), _;
                }()
              );
              A.default = S;
            }, "./src/io/speed-sampler.js")
          ),
          /***/
          "./src/io/websocket-loader.js": (
            /*!************************************!*\
              !*** ./src/io/websocket-loader.js ***!
              \************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ./loader.js */
                "./src/io/loader.js"
              ), _ = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), u = /* @__PURE__ */ function() {
                var h = /* @__PURE__ */ d(function(r, a) {
                  return h = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(l, i) {
                    l.__proto__ = i;
                  } || function(l, i) {
                    for (var t in i) Object.prototype.hasOwnProperty.call(i, t) && (l[t] = i[t]);
                  }, h(r, a);
                }, "extendStatics");
                return function(r, a) {
                  if (typeof a != "function" && a !== null)
                    throw new TypeError("Class extends value " + String(a) + " is not a constructor or null");
                  h(r, a);
                  function l() {
                    this.constructor = r;
                  }
                  d(l, "__"), r.prototype = a === null ? Object.create(a) : (l.prototype = a.prototype, new l());
                };
              }(), o = (
                /** @class */
                function(h) {
                  u(r, h);
                  function r() {
                    var a = h.call(this, "websocket-loader") || this;
                    return a.TAG = "WebSocketLoader", a._needStash = !0, a._ws = null, a._requestAbort = !1, a._receivedLength = 0, a;
                  }
                  return d(r, "WebSocketLoader"), r.isSupported = function() {
                    try {
                      return typeof self.WebSocket < "u";
                    } catch {
                      return !1;
                    }
                  }, r.prototype.destroy = function() {
                    this._ws && this.abort(), h.prototype.destroy.call(this);
                  }, r.prototype.open = function(a) {
                    try {
                      var l = this._ws = new self.WebSocket(a.url);
                      l.binaryType = "arraybuffer", l.onopen = this._onWebSocketOpen.bind(this), l.onclose = this._onWebSocketClose.bind(this), l.onmessage = this._onWebSocketMessage.bind(this), l.onerror = this._onWebSocketError.bind(this), this._status = S.LoaderStatus.kConnecting;
                    } catch (t) {
                      this._status = S.LoaderStatus.kError;
                      var i = { code: t.code, msg: t.message };
                      if (this._onError)
                        this._onError(S.LoaderErrors.EXCEPTION, i);
                      else
                        throw new _.RuntimeException(i.msg);
                    }
                  }, r.prototype.abort = function() {
                    var a = this._ws;
                    a && (a.readyState === 0 || a.readyState === 1) && (this._requestAbort = !0, a.close()), this._ws = null, this._status = S.LoaderStatus.kComplete;
                  }, r.prototype._onWebSocketOpen = function(a) {
                    this._status = S.LoaderStatus.kBuffering;
                  }, r.prototype._onWebSocketClose = function(a) {
                    if (this._requestAbort === !0) {
                      this._requestAbort = !1;
                      return;
                    }
                    this._status = S.LoaderStatus.kComplete, this._onComplete && this._onComplete(0, this._receivedLength - 1);
                  }, r.prototype._onWebSocketMessage = function(a) {
                    var l = this;
                    if (a.data instanceof ArrayBuffer)
                      this._dispatchArrayBuffer(a.data);
                    else if (a.data instanceof Blob) {
                      var i = new FileReader();
                      i.onload = function() {
                        l._dispatchArrayBuffer(i.result);
                      }, i.readAsArrayBuffer(a.data);
                    } else {
                      this._status = S.LoaderStatus.kError;
                      var t = { code: -1, msg: "Unsupported WebSocket message type: " + a.data.constructor.name };
                      if (this._onError)
                        this._onError(S.LoaderErrors.EXCEPTION, t);
                      else
                        throw new _.RuntimeException(t.msg);
                    }
                  }, r.prototype._dispatchArrayBuffer = function(a) {
                    var l = a, i = this._receivedLength;
                    this._receivedLength += l.byteLength, this._onDataArrival && this._onDataArrival(l, i, this._receivedLength);
                  }, r.prototype._onWebSocketError = function(a) {
                    this._status = S.LoaderStatus.kError;
                    var l = {
                      code: a.code,
                      msg: a.message
                    };
                    if (this._onError)
                      this._onError(S.LoaderErrors.EXCEPTION, l);
                    else
                      throw new _.RuntimeException(l.msg);
                  }, r;
                }(S.BaseLoader)
              );
              A.default = o;
            }, "./src/io/websocket-loader.js")
          ),
          /***/
          "./src/io/xhr-moz-chunked-loader.js": (
            /*!******************************************!*\
              !*** ./src/io/xhr-moz-chunked-loader.js ***!
              \******************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ../utils/logger.js */
                "./src/utils/logger.js"
              ), _ = v(
                /*! ./loader.js */
                "./src/io/loader.js"
              ), u = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), o = /* @__PURE__ */ function() {
                var r = /* @__PURE__ */ d(function(a, l) {
                  return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
                    i.__proto__ = t;
                  } || function(i, t) {
                    for (var s in t) Object.prototype.hasOwnProperty.call(t, s) && (i[s] = t[s]);
                  }, r(a, l);
                }, "extendStatics");
                return function(a, l) {
                  if (typeof l != "function" && l !== null)
                    throw new TypeError("Class extends value " + String(l) + " is not a constructor or null");
                  r(a, l);
                  function i() {
                    this.constructor = a;
                  }
                  d(i, "__"), a.prototype = l === null ? Object.create(l) : (i.prototype = l.prototype, new i());
                };
              }(), h = (
                /** @class */
                function(r) {
                  o(a, r);
                  function a(l, i) {
                    var t = r.call(this, "xhr-moz-chunked-loader") || this;
                    return t.TAG = "MozChunkedLoader", t._seekHandler = l, t._config = i, t._needStash = !0, t._xhr = null, t._requestAbort = !1, t._contentLength = null, t._receivedLength = 0, t;
                  }
                  return d(a, "MozChunkedLoader"), a.isSupported = function() {
                    try {
                      var l = new XMLHttpRequest();
                      return l.open("GET", "https://example.com", !0), l.responseType = "moz-chunked-arraybuffer", l.responseType === "moz-chunked-arraybuffer";
                    } catch (i) {
                      return S.default.w("MozChunkedLoader", i.message), !1;
                    }
                  }, a.prototype.destroy = function() {
                    this.isWorking() && this.abort(), this._xhr && (this._xhr.onreadystatechange = null, this._xhr.onprogress = null, this._xhr.onloadend = null, this._xhr.onerror = null, this._xhr = null), r.prototype.destroy.call(this);
                  }, a.prototype.open = function(l, i) {
                    this._dataSource = l, this._range = i;
                    var t = l.url;
                    this._config.reuseRedirectedURL && l.redirectedURL != null && (t = l.redirectedURL);
                    var s = this._seekHandler.getConfig(t, i);
                    this._requestURL = s.url;
                    var n = this._xhr = new XMLHttpRequest();
                    if (n.open("GET", s.url, !0), n.responseType = "moz-chunked-arraybuffer", n.onreadystatechange = this._onReadyStateChange.bind(this), n.onprogress = this._onProgress.bind(this), n.onloadend = this._onLoadEnd.bind(this), n.onerror = this._onXhrError.bind(this), l.withCredentials && (n.withCredentials = !0), typeof s.headers == "object") {
                      var e = s.headers;
                      for (var f in e)
                        e.hasOwnProperty(f) && n.setRequestHeader(f, e[f]);
                    }
                    if (typeof this._config.headers == "object") {
                      var e = this._config.headers;
                      for (var f in e)
                        e.hasOwnProperty(f) && n.setRequestHeader(f, e[f]);
                    }
                    this._status = _.LoaderStatus.kConnecting, n.send();
                  }, a.prototype.abort = function() {
                    this._requestAbort = !0, this._xhr && this._xhr.abort(), this._status = _.LoaderStatus.kComplete;
                  }, a.prototype._onReadyStateChange = function(l) {
                    var i = l.target;
                    if (i.readyState === 2) {
                      if (i.responseURL != null && i.responseURL !== this._requestURL && this._onURLRedirect) {
                        var t = this._seekHandler.removeURLParameters(i.responseURL);
                        this._onURLRedirect(t);
                      }
                      if (i.status !== 0 && (i.status < 200 || i.status > 299))
                        if (this._status = _.LoaderStatus.kError, this._onError)
                          this._onError(_.LoaderErrors.HTTP_STATUS_CODE_INVALID, { code: i.status, msg: i.statusText });
                        else
                          throw new u.RuntimeException("MozChunkedLoader: Http code invalid, " + i.status + " " + i.statusText);
                      else
                        this._status = _.LoaderStatus.kBuffering;
                    }
                  }, a.prototype._onProgress = function(l) {
                    if (this._status !== _.LoaderStatus.kError) {
                      this._contentLength === null && l.total !== null && l.total !== 0 && (this._contentLength = l.total, this._onContentLengthKnown && this._onContentLengthKnown(this._contentLength));
                      var i = l.target.response, t = this._range.from + this._receivedLength;
                      this._receivedLength += i.byteLength, this._onDataArrival && this._onDataArrival(i, t, this._receivedLength);
                    }
                  }, a.prototype._onLoadEnd = function(l) {
                    if (this._requestAbort === !0) {
                      this._requestAbort = !1;
                      return;
                    } else if (this._status === _.LoaderStatus.kError)
                      return;
                    this._status = _.LoaderStatus.kComplete, this._onComplete && this._onComplete(this._range.from, this._range.from + this._receivedLength - 1);
                  }, a.prototype._onXhrError = function(l) {
                    this._status = _.LoaderStatus.kError;
                    var i = 0, t = null;
                    if (this._contentLength && l.loaded < this._contentLength ? (i = _.LoaderErrors.EARLY_EOF, t = { code: -1, msg: "Moz-Chunked stream meet Early-Eof" }) : (i = _.LoaderErrors.EXCEPTION, t = { code: -1, msg: l.constructor.name + " " + l.type }), this._onError)
                      this._onError(i, t);
                    else
                      throw new u.RuntimeException(t.msg);
                  }, a;
                }(_.BaseLoader)
              );
              A.default = h;
            }, "./src/io/xhr-moz-chunked-loader.js")
          ),
          /***/
          "./src/io/xhr-range-loader.js": (
            /*!************************************!*\
              !*** ./src/io/xhr-range-loader.js ***!
              \************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ../utils/logger.js */
                "./src/utils/logger.js"
              ), _ = v(
                /*! ./speed-sampler.js */
                "./src/io/speed-sampler.js"
              ), u = v(
                /*! ./loader.js */
                "./src/io/loader.js"
              ), o = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), h = /* @__PURE__ */ function() {
                var a = /* @__PURE__ */ d(function(l, i) {
                  return a = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(t, s) {
                    t.__proto__ = s;
                  } || function(t, s) {
                    for (var n in s) Object.prototype.hasOwnProperty.call(s, n) && (t[n] = s[n]);
                  }, a(l, i);
                }, "extendStatics");
                return function(l, i) {
                  if (typeof i != "function" && i !== null)
                    throw new TypeError("Class extends value " + String(i) + " is not a constructor or null");
                  a(l, i);
                  function t() {
                    this.constructor = l;
                  }
                  d(t, "__"), l.prototype = i === null ? Object.create(i) : (t.prototype = i.prototype, new t());
                };
              }(), r = (
                /** @class */
                function(a) {
                  h(l, a);
                  function l(i, t) {
                    var s = a.call(this, "xhr-range-loader") || this;
                    return s.TAG = "RangeLoader", s._seekHandler = i, s._config = t, s._needStash = !1, s._chunkSizeKBList = [
                      128,
                      256,
                      384,
                      512,
                      768,
                      1024,
                      1536,
                      2048,
                      3072,
                      4096,
                      5120,
                      6144,
                      7168,
                      8192
                    ], s._currentChunkSizeKB = 384, s._currentSpeedNormalized = 0, s._zeroSpeedChunkCount = 0, s._xhr = null, s._speedSampler = new _.default(), s._requestAbort = !1, s._waitForTotalLength = !1, s._totalLengthReceived = !1, s._currentRequestURL = null, s._currentRedirectedURL = null, s._currentRequestRange = null, s._totalLength = null, s._contentLength = null, s._receivedLength = 0, s._lastTimeLoaded = 0, s;
                  }
                  return d(l, "RangeLoader"), l.isSupported = function() {
                    try {
                      var i = new XMLHttpRequest();
                      return i.open("GET", "https://example.com", !0), i.responseType = "arraybuffer", i.responseType === "arraybuffer";
                    } catch (t) {
                      return S.default.w("RangeLoader", t.message), !1;
                    }
                  }, l.prototype.destroy = function() {
                    this.isWorking() && this.abort(), this._xhr && (this._xhr.onreadystatechange = null, this._xhr.onprogress = null, this._xhr.onload = null, this._xhr.onerror = null, this._xhr = null), a.prototype.destroy.call(this);
                  }, Object.defineProperty(l.prototype, "currentSpeed", {
                    get: /* @__PURE__ */ d(function() {
                      return this._speedSampler.lastSecondKBps;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), l.prototype.open = function(i, t) {
                    this._dataSource = i, this._range = t, this._status = u.LoaderStatus.kConnecting;
                    var s = !1;
                    this._dataSource.filesize != null && this._dataSource.filesize !== 0 && (s = !0, this._totalLength = this._dataSource.filesize), !this._totalLengthReceived && !s ? (this._waitForTotalLength = !0, this._internalOpen(this._dataSource, { from: 0, to: -1 })) : this._openSubRange();
                  }, l.prototype._openSubRange = function() {
                    var i = this._currentChunkSizeKB * 1024, t = this._range.from + this._receivedLength, s = t + i;
                    this._contentLength != null && s - this._range.from >= this._contentLength && (s = this._range.from + this._contentLength - 1), this._currentRequestRange = { from: t, to: s }, this._internalOpen(this._dataSource, this._currentRequestRange);
                  }, l.prototype._internalOpen = function(i, t) {
                    this._lastTimeLoaded = 0;
                    var s = i.url;
                    this._config.reuseRedirectedURL && (this._currentRedirectedURL != null ? s = this._currentRedirectedURL : i.redirectedURL != null && (s = i.redirectedURL));
                    var n = this._seekHandler.getConfig(s, t);
                    this._currentRequestURL = n.url;
                    var e = this._xhr = new XMLHttpRequest();
                    if (e.open("GET", n.url, !0), e.responseType = "arraybuffer", e.onreadystatechange = this._onReadyStateChange.bind(this), e.onprogress = this._onProgress.bind(this), e.onload = this._onLoad.bind(this), e.onerror = this._onXhrError.bind(this), i.withCredentials && (e.withCredentials = !0), typeof n.headers == "object") {
                      var f = n.headers;
                      for (var c in f)
                        f.hasOwnProperty(c) && e.setRequestHeader(c, f[c]);
                    }
                    if (typeof this._config.headers == "object") {
                      var f = this._config.headers;
                      for (var c in f)
                        f.hasOwnProperty(c) && e.setRequestHeader(c, f[c]);
                    }
                    e.send();
                  }, l.prototype.abort = function() {
                    this._requestAbort = !0, this._internalAbort(), this._status = u.LoaderStatus.kComplete;
                  }, l.prototype._internalAbort = function() {
                    this._xhr && (this._xhr.onreadystatechange = null, this._xhr.onprogress = null, this._xhr.onload = null, this._xhr.onerror = null, this._xhr.abort(), this._xhr = null);
                  }, l.prototype._onReadyStateChange = function(i) {
                    var t = i.target;
                    if (t.readyState === 2) {
                      if (t.responseURL != null) {
                        var s = this._seekHandler.removeURLParameters(t.responseURL);
                        t.responseURL !== this._currentRequestURL && s !== this._currentRedirectedURL && (this._currentRedirectedURL = s, this._onURLRedirect && this._onURLRedirect(s));
                      }
                      if (t.status >= 200 && t.status <= 299) {
                        if (this._waitForTotalLength)
                          return;
                        this._status = u.LoaderStatus.kBuffering;
                      } else if (this._status = u.LoaderStatus.kError, this._onError)
                        this._onError(u.LoaderErrors.HTTP_STATUS_CODE_INVALID, { code: t.status, msg: t.statusText });
                      else
                        throw new o.RuntimeException("RangeLoader: Http code invalid, " + t.status + " " + t.statusText);
                    }
                  }, l.prototype._onProgress = function(i) {
                    if (this._status !== u.LoaderStatus.kError) {
                      if (this._contentLength === null) {
                        var t = !1;
                        if (this._waitForTotalLength) {
                          this._waitForTotalLength = !1, this._totalLengthReceived = !0, t = !0;
                          var s = i.total;
                          this._internalAbort(), s != null & s !== 0 && (this._totalLength = s);
                        }
                        if (this._range.to === -1 ? this._contentLength = this._totalLength - this._range.from : this._contentLength = this._range.to - this._range.from + 1, t) {
                          this._openSubRange();
                          return;
                        }
                        this._onContentLengthKnown && this._onContentLengthKnown(this._contentLength);
                      }
                      var n = i.loaded - this._lastTimeLoaded;
                      this._lastTimeLoaded = i.loaded, this._speedSampler.addBytes(n);
                    }
                  }, l.prototype._normalizeSpeed = function(i) {
                    var t = this._chunkSizeKBList, s = t.length - 1, n = 0, e = 0, f = s;
                    if (i < t[0])
                      return t[0];
                    for (; e <= f; ) {
                      if (n = e + Math.floor((f - e) / 2), n === s || i >= t[n] && i < t[n + 1])
                        return t[n];
                      t[n] < i ? e = n + 1 : f = n - 1;
                    }
                  }, l.prototype._onLoad = function(i) {
                    if (this._status !== u.LoaderStatus.kError) {
                      if (this._waitForTotalLength) {
                        this._waitForTotalLength = !1;
                        return;
                      }
                      this._lastTimeLoaded = 0;
                      var t = this._speedSampler.lastSecondKBps;
                      if (t === 0 && (this._zeroSpeedChunkCount++, this._zeroSpeedChunkCount >= 3 && (t = this._speedSampler.currentKBps)), t !== 0) {
                        var s = this._normalizeSpeed(t);
                        this._currentSpeedNormalized !== s && (this._currentSpeedNormalized = s, this._currentChunkSizeKB = s);
                      }
                      var n = i.target.response, e = this._range.from + this._receivedLength;
                      this._receivedLength += n.byteLength;
                      var f = !1;
                      this._contentLength != null && this._receivedLength < this._contentLength ? this._openSubRange() : f = !0, this._onDataArrival && this._onDataArrival(n, e, this._receivedLength), f && (this._status = u.LoaderStatus.kComplete, this._onComplete && this._onComplete(this._range.from, this._range.from + this._receivedLength - 1));
                    }
                  }, l.prototype._onXhrError = function(i) {
                    this._status = u.LoaderStatus.kError;
                    var t = 0, s = null;
                    if (this._contentLength && this._receivedLength > 0 && this._receivedLength < this._contentLength ? (t = u.LoaderErrors.EARLY_EOF, s = { code: -1, msg: "RangeLoader meet Early-Eof" }) : (t = u.LoaderErrors.EXCEPTION, s = { code: -1, msg: i.constructor.name + " " + i.type }), this._onError)
                      this._onError(t, s);
                    else
                      throw new o.RuntimeException(s.msg);
                  }, l;
                }(u.BaseLoader)
              );
              A.default = r;
            }, "./src/io/xhr-range-loader.js")
          ),
          /***/
          "./src/player/flv-player.js": (
            /*!**********************************!*\
              !*** ./src/player/flv-player.js ***!
              \**********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! events */
                "./node_modules/events/events.js"
              ), _ = /* @__PURE__ */ v.n(S), u = v(
                /*! ../utils/logger.js */
                "./src/utils/logger.js"
              ), o = v(
                /*! ../utils/browser.js */
                "./src/utils/browser.js"
              ), h = v(
                /*! ./player-events.js */
                "./src/player/player-events.js"
              ), r = v(
                /*! ../core/transmuxer.js */
                "./src/core/transmuxer.js"
              ), a = v(
                /*! ../core/transmuxing-events.js */
                "./src/core/transmuxing-events.js"
              ), l = v(
                /*! ../core/mse-controller.js */
                "./src/core/mse-controller.js"
              ), i = v(
                /*! ../core/mse-events.js */
                "./src/core/mse-events.js"
              ), t = v(
                /*! ./player-errors.js */
                "./src/player/player-errors.js"
              ), s = v(
                /*! ../config.js */
                "./src/config.js"
              ), n = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), e = (
                /** @class */
                function() {
                  function f(c, p) {
                    if (this.TAG = "FlvPlayer", this._type = "FlvPlayer", this._emitter = new (_())(), this._config = (0, s.createDefaultConfig)(), typeof p == "object" && Object.assign(this._config, p), c.type.toLowerCase() !== "flv")
                      throw new n.InvalidArgumentException("FlvPlayer requires an flv MediaDataSource input!");
                    c.isLive === !0 && (this._config.isLive = !0), this.e = {
                      onvLoadedMetadata: this._onvLoadedMetadata.bind(this),
                      onvSeeking: this._onvSeeking.bind(this),
                      onvCanPlay: this._onvCanPlay.bind(this),
                      onvStalled: this._onvStalled.bind(this),
                      onvProgress: this._onvProgress.bind(this)
                    }, self.performance && self.performance.now ? this._now = self.performance.now.bind(self.performance) : this._now = Date.now, this._pendingSeekTime = null, this._requestSetTime = !1, this._seekpointRecord = null, this._progressChecker = null, this._mediaDataSource = c, this._mediaElement = null, this._msectl = null, this._transmuxer = null, this._mseSourceOpened = !1, this._hasPendingLoad = !1, this._receivedCanPlay = !1, this._mediaInfo = null, this._statisticsInfo = null;
                    var g = o.default.chrome && (o.default.version.major < 50 || o.default.version.major === 50 && o.default.version.build < 2661);
                    this._alwaysSeekKeyframe = !!(g || o.default.msedge || o.default.msie), this._alwaysSeekKeyframe && (this._config.accurateSeek = !1);
                  }
                  return d(f, "FlvPlayer"), f.prototype.destroy = function() {
                    this._progressChecker != null && (window.clearInterval(this._progressChecker), this._progressChecker = null), this._transmuxer && this.unload(), this._mediaElement && this.detachMediaElement(), this.e = null, this._mediaDataSource = null, this._emitter.removeAllListeners(), this._emitter = null;
                  }, f.prototype.on = function(c, p) {
                    var g = this;
                    c === h.default.MEDIA_INFO ? this._mediaInfo != null && Promise.resolve().then(function() {
                      g._emitter.emit(h.default.MEDIA_INFO, g.mediaInfo);
                    }) : c === h.default.STATISTICS_INFO && this._statisticsInfo != null && Promise.resolve().then(function() {
                      g._emitter.emit(h.default.STATISTICS_INFO, g.statisticsInfo);
                    }), this._emitter.addListener(c, p);
                  }, f.prototype.off = function(c, p) {
                    this._emitter.removeListener(c, p);
                  }, f.prototype.attachMediaElement = function(c) {
                    var p = this;
                    if (this._mediaElement = c, c.addEventListener("loadedmetadata", this.e.onvLoadedMetadata), c.addEventListener("seeking", this.e.onvSeeking), c.addEventListener("canplay", this.e.onvCanPlay), c.addEventListener("stalled", this.e.onvStalled), c.addEventListener("progress", this.e.onvProgress), this._msectl = new l.default(this._config), this._msectl.on(i.default.UPDATE_END, this._onmseUpdateEnd.bind(this)), this._msectl.on(i.default.BUFFER_FULL, this._onmseBufferFull.bind(this)), this._msectl.on(i.default.SOURCE_OPEN, function() {
                      p._mseSourceOpened = !0, p._hasPendingLoad && (p._hasPendingLoad = !1, p.load());
                    }), this._msectl.on(i.default.ERROR, function(g) {
                      p._emitter.emit(h.default.ERROR, t.ErrorTypes.MEDIA_ERROR, t.ErrorDetails.MEDIA_MSE_ERROR, g);
                    }), this._msectl.attachMediaElement(c), this._pendingSeekTime != null)
                      try {
                        c.currentTime = this._pendingSeekTime, this._pendingSeekTime = null;
                      } catch {
                      }
                  }, f.prototype.detachMediaElement = function() {
                    this._mediaElement && (this._msectl.detachMediaElement(), this._mediaElement.removeEventListener("loadedmetadata", this.e.onvLoadedMetadata), this._mediaElement.removeEventListener("seeking", this.e.onvSeeking), this._mediaElement.removeEventListener("canplay", this.e.onvCanPlay), this._mediaElement.removeEventListener("stalled", this.e.onvStalled), this._mediaElement.removeEventListener("progress", this.e.onvProgress), this._mediaElement = null), this._msectl && (this._msectl.destroy(), this._msectl = null);
                  }, f.prototype.load = function() {
                    var c = this;
                    if (!this._mediaElement)
                      throw new n.IllegalStateException("HTMLMediaElement must be attached before load()!");
                    if (this._transmuxer)
                      throw new n.IllegalStateException("FlvPlayer.load() has been called, please call unload() first!");
                    if (!this._hasPendingLoad) {
                      if (this._config.deferLoadAfterSourceOpen && this._mseSourceOpened === !1) {
                        this._hasPendingLoad = !0;
                        return;
                      }
                      this._mediaElement.readyState > 0 && (this._requestSetTime = !0, this._mediaElement.currentTime = 0), this._transmuxer = new r.default(this._mediaDataSource, this._config), this._transmuxer.on(a.default.INIT_SEGMENT, function(p, g) {
                        c._msectl.appendInitSegment(g);
                      }), this._transmuxer.on(a.default.MEDIA_SEGMENT, function(p, g) {
                        if (c._msectl.appendMediaSegment(g), c._config.lazyLoad && !c._config.isLive) {
                          var y = c._mediaElement.currentTime;
                          g.info.endDts >= (y + c._config.lazyLoadMaxDuration) * 1e3 && c._progressChecker == null && (u.default.v(c.TAG, "Maximum buffering duration exceeded, suspend transmuxing task"), c._suspendTransmuxer());
                        }
                      }), this._transmuxer.on(a.default.LOADING_COMPLETE, function() {
                        c._msectl.endOfStream(), c._emitter.emit(h.default.LOADING_COMPLETE);
                      }), this._transmuxer.on(a.default.RECOVERED_EARLY_EOF, function() {
                        c._emitter.emit(h.default.RECOVERED_EARLY_EOF);
                      }), this._transmuxer.on(a.default.IO_ERROR, function(p, g) {
                        c._emitter.emit(h.default.ERROR, t.ErrorTypes.NETWORK_ERROR, p, g);
                      }), this._transmuxer.on(a.default.DEMUX_ERROR, function(p, g) {
                        c._emitter.emit(h.default.ERROR, t.ErrorTypes.MEDIA_ERROR, p, { code: -1, msg: g });
                      }), this._transmuxer.on(a.default.MEDIA_INFO, function(p) {
                        c._mediaInfo = p, c._emitter.emit(h.default.MEDIA_INFO, Object.assign({}, p));
                      }), this._transmuxer.on(a.default.METADATA_ARRIVED, function(p) {
                        c._emitter.emit(h.default.METADATA_ARRIVED, p);
                      }), this._transmuxer.on(a.default.SCRIPTDATA_ARRIVED, function(p) {
                        c._emitter.emit(h.default.SCRIPTDATA_ARRIVED, p);
                      }), this._transmuxer.on(a.default.STATISTICS_INFO, function(p) {
                        c._statisticsInfo = c._fillStatisticsInfo(p), c._emitter.emit(h.default.STATISTICS_INFO, Object.assign({}, c._statisticsInfo));
                      }), this._transmuxer.on(a.default.RECOMMEND_SEEKPOINT, function(p) {
                        c._mediaElement && !c._config.accurateSeek && (c._requestSetTime = !0, c._mediaElement.currentTime = p / 1e3);
                      }), this._transmuxer.open();
                    }
                  }, f.prototype.unload = function() {
                    this._mediaElement && this._mediaElement.pause(), this._msectl && this._msectl.seek(0), this._transmuxer && (this._transmuxer.close(), this._transmuxer.destroy(), this._transmuxer = null);
                  }, f.prototype.play = function() {
                    return this._mediaElement.play();
                  }, f.prototype.pause = function() {
                    this._mediaElement.pause();
                  }, Object.defineProperty(f.prototype, "type", {
                    get: /* @__PURE__ */ d(function() {
                      return this._type;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(f.prototype, "buffered", {
                    get: /* @__PURE__ */ d(function() {
                      return this._mediaElement.buffered;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(f.prototype, "duration", {
                    get: /* @__PURE__ */ d(function() {
                      return this._mediaElement.duration;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(f.prototype, "volume", {
                    get: /* @__PURE__ */ d(function() {
                      return this._mediaElement.volume;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(c) {
                      this._mediaElement.volume = c;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(f.prototype, "muted", {
                    get: /* @__PURE__ */ d(function() {
                      return this._mediaElement.muted;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(c) {
                      this._mediaElement.muted = c;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(f.prototype, "currentTime", {
                    get: /* @__PURE__ */ d(function() {
                      return this._mediaElement ? this._mediaElement.currentTime : 0;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(c) {
                      this._mediaElement ? this._internalSeek(c) : this._pendingSeekTime = c;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(f.prototype, "mediaInfo", {
                    get: /* @__PURE__ */ d(function() {
                      return Object.assign({}, this._mediaInfo);
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(f.prototype, "statisticsInfo", {
                    get: /* @__PURE__ */ d(function() {
                      return this._statisticsInfo == null && (this._statisticsInfo = {}), this._statisticsInfo = this._fillStatisticsInfo(this._statisticsInfo), Object.assign({}, this._statisticsInfo);
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), f.prototype._fillStatisticsInfo = function(c) {
                    if (c.playerType = this._type, !(this._mediaElement instanceof HTMLVideoElement))
                      return c;
                    var p = !0, g = 0, y = 0;
                    if (this._mediaElement.getVideoPlaybackQuality) {
                      var E = this._mediaElement.getVideoPlaybackQuality();
                      g = E.totalVideoFrames, y = E.droppedVideoFrames;
                    } else this._mediaElement.webkitDecodedFrameCount != null ? (g = this._mediaElement.webkitDecodedFrameCount, y = this._mediaElement.webkitDroppedFrameCount) : p = !1;
                    return p && (c.decodedFrames = g, c.droppedFrames = y), c;
                  }, f.prototype._onmseUpdateEnd = function() {
                    if (!(!this._config.lazyLoad || this._config.isLive)) {
                      for (var c = this._mediaElement.buffered, p = this._mediaElement.currentTime, g = 0, y = 0; y < c.length; y++) {
                        var E = c.start(y), m = c.end(y);
                        if (E <= p && p < m) {
                          g = m;
                          break;
                        }
                      }
                      g >= p + this._config.lazyLoadMaxDuration && this._progressChecker == null && (u.default.v(this.TAG, "Maximum buffering duration exceeded, suspend transmuxing task"), this._suspendTransmuxer());
                    }
                  }, f.prototype._onmseBufferFull = function() {
                    u.default.v(this.TAG, "MSE SourceBuffer is full, suspend transmuxing task"), this._progressChecker == null && this._suspendTransmuxer();
                  }, f.prototype._suspendTransmuxer = function() {
                    this._transmuxer && (this._transmuxer.pause(), this._progressChecker == null && (this._progressChecker = window.setInterval(this._checkProgressAndResume.bind(this), 1e3)));
                  }, f.prototype._checkProgressAndResume = function() {
                    for (var c = this._mediaElement.currentTime, p = this._mediaElement.buffered, g = !1, y = 0; y < p.length; y++) {
                      var E = p.start(y), m = p.end(y);
                      if (c >= E && c < m) {
                        c >= m - this._config.lazyLoadRecoverDuration && (g = !0);
                        break;
                      }
                    }
                    g && (window.clearInterval(this._progressChecker), this._progressChecker = null, g && (u.default.v(this.TAG, "Continue loading from paused position"), this._transmuxer.resume()));
                  }, f.prototype._isTimepointBuffered = function(c) {
                    for (var p = this._mediaElement.buffered, g = 0; g < p.length; g++) {
                      var y = p.start(g), E = p.end(g);
                      if (c >= y && c < E)
                        return !0;
                    }
                    return !1;
                  }, f.prototype._internalSeek = function(c) {
                    var p = this._isTimepointBuffered(c), g = !1, y = 0;
                    if (c < 1 && this._mediaElement.buffered.length > 0) {
                      var E = this._mediaElement.buffered.start(0);
                      (E < 1 && c < E || o.default.safari) && (g = !0, y = o.default.safari ? 0.1 : E);
                    }
                    if (g)
                      this._requestSetTime = !0, this._mediaElement.currentTime = y;
                    else if (p) {
                      if (!this._alwaysSeekKeyframe)
                        this._requestSetTime = !0, this._mediaElement.currentTime = c;
                      else {
                        var m = this._msectl.getNearestKeyframe(Math.floor(c * 1e3));
                        this._requestSetTime = !0, m != null ? this._mediaElement.currentTime = m.dts / 1e3 : this._mediaElement.currentTime = c;
                      }
                      this._progressChecker != null && this._checkProgressAndResume();
                    } else
                      this._progressChecker != null && (window.clearInterval(this._progressChecker), this._progressChecker = null), this._msectl.seek(c), this._transmuxer.seek(Math.floor(c * 1e3)), this._config.accurateSeek && (this._requestSetTime = !0, this._mediaElement.currentTime = c);
                  }, f.prototype._checkAndApplyUnbufferedSeekpoint = function() {
                    if (this._seekpointRecord)
                      if (this._seekpointRecord.recordTime <= this._now() - 100) {
                        var c = this._mediaElement.currentTime;
                        this._seekpointRecord = null, this._isTimepointBuffered(c) || (this._progressChecker != null && (window.clearTimeout(this._progressChecker), this._progressChecker = null), this._msectl.seek(c), this._transmuxer.seek(Math.floor(c * 1e3)), this._config.accurateSeek && (this._requestSetTime = !0, this._mediaElement.currentTime = c));
                      } else
                        window.setTimeout(this._checkAndApplyUnbufferedSeekpoint.bind(this), 50);
                  }, f.prototype._checkAndResumeStuckPlayback = function(c) {
                    var p = this._mediaElement;
                    if (c || !this._receivedCanPlay || p.readyState < 2) {
                      var g = p.buffered;
                      g.length > 0 && p.currentTime < g.start(0) && (u.default.w(this.TAG, "Playback seems stuck at " + p.currentTime + ", seek to " + g.start(0)), this._requestSetTime = !0, this._mediaElement.currentTime = g.start(0), this._mediaElement.removeEventListener("progress", this.e.onvProgress));
                    } else
                      this._mediaElement.removeEventListener("progress", this.e.onvProgress);
                  }, f.prototype._onvLoadedMetadata = function(c) {
                    this._pendingSeekTime != null && (this._mediaElement.currentTime = this._pendingSeekTime, this._pendingSeekTime = null);
                  }, f.prototype._onvSeeking = function(c) {
                    var p = this._mediaElement.currentTime, g = this._mediaElement.buffered;
                    if (this._requestSetTime) {
                      this._requestSetTime = !1;
                      return;
                    }
                    if (p < 1 && g.length > 0) {
                      var y = g.start(0);
                      if (y < 1 && p < y || o.default.safari) {
                        this._requestSetTime = !0, this._mediaElement.currentTime = o.default.safari ? 0.1 : y;
                        return;
                      }
                    }
                    if (this._isTimepointBuffered(p)) {
                      if (this._alwaysSeekKeyframe) {
                        var E = this._msectl.getNearestKeyframe(Math.floor(p * 1e3));
                        E != null && (this._requestSetTime = !0, this._mediaElement.currentTime = E.dts / 1e3);
                      }
                      this._progressChecker != null && this._checkProgressAndResume();
                      return;
                    }
                    this._seekpointRecord = {
                      seekPoint: p,
                      recordTime: this._now()
                    }, window.setTimeout(this._checkAndApplyUnbufferedSeekpoint.bind(this), 50);
                  }, f.prototype._onvCanPlay = function(c) {
                    this._receivedCanPlay = !0, this._mediaElement.removeEventListener("canplay", this.e.onvCanPlay);
                  }, f.prototype._onvStalled = function(c) {
                    this._checkAndResumeStuckPlayback(!0);
                  }, f.prototype._onvProgress = function(c) {
                    this._checkAndResumeStuckPlayback();
                  }, f;
                }()
              );
              A.default = e;
            }, "./src/player/flv-player.js")
          ),
          /***/
          "./src/player/native-player.js": (
            /*!*************************************!*\
              !*** ./src/player/native-player.js ***!
              \*************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! events */
                "./node_modules/events/events.js"
              ), _ = /* @__PURE__ */ v.n(S), u = v(
                /*! ./player-events.js */
                "./src/player/player-events.js"
              ), o = v(
                /*! ../config.js */
                "./src/config.js"
              ), h = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), r = (
                /** @class */
                function() {
                  function a(l, i) {
                    if (this.TAG = "NativePlayer", this._type = "NativePlayer", this._emitter = new (_())(), this._config = (0, o.createDefaultConfig)(), typeof i == "object" && Object.assign(this._config, i), l.type.toLowerCase() === "flv")
                      throw new h.InvalidArgumentException("NativePlayer does't support flv MediaDataSource input!");
                    if (l.hasOwnProperty("segments"))
                      throw new h.InvalidArgumentException("NativePlayer(" + l.type + ") doesn't support multipart playback!");
                    this.e = {
                      onvLoadedMetadata: this._onvLoadedMetadata.bind(this)
                    }, this._pendingSeekTime = null, this._statisticsReporter = null, this._mediaDataSource = l, this._mediaElement = null;
                  }
                  return d(a, "NativePlayer"), a.prototype.destroy = function() {
                    this._mediaElement && (this.unload(), this.detachMediaElement()), this.e = null, this._mediaDataSource = null, this._emitter.removeAllListeners(), this._emitter = null;
                  }, a.prototype.on = function(l, i) {
                    var t = this;
                    l === u.default.MEDIA_INFO ? this._mediaElement != null && this._mediaElement.readyState !== 0 && Promise.resolve().then(function() {
                      t._emitter.emit(u.default.MEDIA_INFO, t.mediaInfo);
                    }) : l === u.default.STATISTICS_INFO && this._mediaElement != null && this._mediaElement.readyState !== 0 && Promise.resolve().then(function() {
                      t._emitter.emit(u.default.STATISTICS_INFO, t.statisticsInfo);
                    }), this._emitter.addListener(l, i);
                  }, a.prototype.off = function(l, i) {
                    this._emitter.removeListener(l, i);
                  }, a.prototype.attachMediaElement = function(l) {
                    if (this._mediaElement = l, l.addEventListener("loadedmetadata", this.e.onvLoadedMetadata), this._pendingSeekTime != null)
                      try {
                        l.currentTime = this._pendingSeekTime, this._pendingSeekTime = null;
                      } catch {
                      }
                  }, a.prototype.detachMediaElement = function() {
                    this._mediaElement && (this._mediaElement.src = "", this._mediaElement.removeAttribute("src"), this._mediaElement.removeEventListener("loadedmetadata", this.e.onvLoadedMetadata), this._mediaElement = null), this._statisticsReporter != null && (window.clearInterval(this._statisticsReporter), this._statisticsReporter = null);
                  }, a.prototype.load = function() {
                    if (!this._mediaElement)
                      throw new h.IllegalStateException("HTMLMediaElement must be attached before load()!");
                    this._mediaElement.src = this._mediaDataSource.url, this._mediaElement.readyState > 0 && (this._mediaElement.currentTime = 0), this._mediaElement.preload = "auto", this._mediaElement.load(), this._statisticsReporter = window.setInterval(this._reportStatisticsInfo.bind(this), this._config.statisticsInfoReportInterval);
                  }, a.prototype.unload = function() {
                    this._mediaElement && (this._mediaElement.src = "", this._mediaElement.removeAttribute("src")), this._statisticsReporter != null && (window.clearInterval(this._statisticsReporter), this._statisticsReporter = null);
                  }, a.prototype.play = function() {
                    return this._mediaElement.play();
                  }, a.prototype.pause = function() {
                    this._mediaElement.pause();
                  }, Object.defineProperty(a.prototype, "type", {
                    get: /* @__PURE__ */ d(function() {
                      return this._type;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(a.prototype, "buffered", {
                    get: /* @__PURE__ */ d(function() {
                      return this._mediaElement.buffered;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(a.prototype, "duration", {
                    get: /* @__PURE__ */ d(function() {
                      return this._mediaElement.duration;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(a.prototype, "volume", {
                    get: /* @__PURE__ */ d(function() {
                      return this._mediaElement.volume;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(l) {
                      this._mediaElement.volume = l;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(a.prototype, "muted", {
                    get: /* @__PURE__ */ d(function() {
                      return this._mediaElement.muted;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(l) {
                      this._mediaElement.muted = l;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(a.prototype, "currentTime", {
                    get: /* @__PURE__ */ d(function() {
                      return this._mediaElement ? this._mediaElement.currentTime : 0;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(l) {
                      this._mediaElement ? this._mediaElement.currentTime = l : this._pendingSeekTime = l;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(a.prototype, "mediaInfo", {
                    get: /* @__PURE__ */ d(function() {
                      var l = this._mediaElement instanceof HTMLAudioElement ? "audio/" : "video/", i = {
                        mimeType: l + this._mediaDataSource.type
                      };
                      return this._mediaElement && (i.duration = Math.floor(this._mediaElement.duration * 1e3), this._mediaElement instanceof HTMLVideoElement && (i.width = this._mediaElement.videoWidth, i.height = this._mediaElement.videoHeight)), i;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(a.prototype, "statisticsInfo", {
                    get: /* @__PURE__ */ d(function() {
                      var l = {
                        playerType: this._type,
                        url: this._mediaDataSource.url
                      };
                      if (!(this._mediaElement instanceof HTMLVideoElement))
                        return l;
                      var i = !0, t = 0, s = 0;
                      if (this._mediaElement.getVideoPlaybackQuality) {
                        var n = this._mediaElement.getVideoPlaybackQuality();
                        t = n.totalVideoFrames, s = n.droppedVideoFrames;
                      } else this._mediaElement.webkitDecodedFrameCount != null ? (t = this._mediaElement.webkitDecodedFrameCount, s = this._mediaElement.webkitDroppedFrameCount) : i = !1;
                      return i && (l.decodedFrames = t, l.droppedFrames = s), l;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), a.prototype._onvLoadedMetadata = function(l) {
                    this._pendingSeekTime != null && (this._mediaElement.currentTime = this._pendingSeekTime, this._pendingSeekTime = null), this._emitter.emit(u.default.MEDIA_INFO, this.mediaInfo);
                  }, a.prototype._reportStatisticsInfo = function() {
                    this._emitter.emit(u.default.STATISTICS_INFO, this.statisticsInfo);
                  }, a;
                }()
              );
              A.default = r;
            }, "./src/player/native-player.js")
          ),
          /***/
          "./src/player/player-errors.js": (
            /*!*************************************!*\
              !*** ./src/player/player-errors.js ***!
              \*************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A), v.d(A, {
                /* harmony export */
                ErrorTypes: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    u
                  );
                }, "ErrorTypes"),
                /* harmony export */
                ErrorDetails: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    o
                  );
                }, "ErrorDetails")
                /* harmony export */
              });
              var S = v(
                /*! ../io/loader.js */
                "./src/io/loader.js"
              ), _ = v(
                /*! ../demux/demux-errors.js */
                "./src/demux/demux-errors.js"
              ), u = {
                NETWORK_ERROR: "NetworkError",
                MEDIA_ERROR: "MediaError",
                OTHER_ERROR: "OtherError"
              }, o = {
                NETWORK_EXCEPTION: S.LoaderErrors.EXCEPTION,
                NETWORK_STATUS_CODE_INVALID: S.LoaderErrors.HTTP_STATUS_CODE_INVALID,
                NETWORK_TIMEOUT: S.LoaderErrors.CONNECTING_TIMEOUT,
                NETWORK_UNRECOVERABLE_EARLY_EOF: S.LoaderErrors.UNRECOVERABLE_EARLY_EOF,
                MEDIA_MSE_ERROR: "MediaMSEError",
                MEDIA_FORMAT_ERROR: _.default.FORMAT_ERROR,
                MEDIA_FORMAT_UNSUPPORTED: _.default.FORMAT_UNSUPPORTED,
                MEDIA_CODEC_UNSUPPORTED: _.default.CODEC_UNSUPPORTED
              };
            }, "./src/player/player-errors.js")
          ),
          /***/
          "./src/player/player-events.js": (
            /*!*************************************!*\
              !*** ./src/player/player-events.js ***!
              \*************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = {
                ERROR: "error",
                LOADING_COMPLETE: "loading_complete",
                RECOVERED_EARLY_EOF: "recovered_early_eof",
                MEDIA_INFO: "media_info",
                METADATA_ARRIVED: "metadata_arrived",
                SCRIPTDATA_ARRIVED: "scriptdata_arrived",
                STATISTICS_INFO: "statistics_info"
              };
              A.default = S;
            }, "./src/player/player-events.js")
          ),
          /***/
          "./src/remux/aac-silent.js": (
            /*!*********************************!*\
              !*** ./src/remux/aac-silent.js ***!
              \*********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = (
                /** @class */
                function() {
                  function _() {
                  }
                  return d(_, "AAC"), _.getSilentFrame = function(u, o) {
                    if (u === "mp4a.40.2") {
                      if (o === 1)
                        return new Uint8Array([0, 200, 0, 128, 35, 128]);
                      if (o === 2)
                        return new Uint8Array([33, 0, 73, 144, 2, 25, 0, 35, 128]);
                      if (o === 3)
                        return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 142]);
                      if (o === 4)
                        return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 128, 44, 128, 8, 2, 56]);
                      if (o === 5)
                        return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 130, 48, 4, 153, 0, 33, 144, 2, 56]);
                      if (o === 6)
                        return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 130, 48, 4, 153, 0, 33, 144, 2, 0, 178, 0, 32, 8, 224]);
                    } else {
                      if (o === 1)
                        return new Uint8Array([1, 64, 34, 128, 163, 78, 230, 128, 186, 8, 0, 0, 0, 28, 6, 241, 193, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
                      if (o === 2)
                        return new Uint8Array([1, 64, 34, 128, 163, 94, 230, 128, 186, 8, 0, 0, 0, 0, 149, 0, 6, 241, 161, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
                      if (o === 3)
                        return new Uint8Array([1, 64, 34, 128, 163, 94, 230, 128, 186, 8, 0, 0, 0, 0, 149, 0, 6, 241, 161, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
                    }
                    return null;
                  }, _;
                }()
              );
              A.default = S;
            }, "./src/remux/aac-silent.js")
          ),
          /***/
          "./src/remux/mp4-generator.js": (
            /*!************************************!*\
              !*** ./src/remux/mp4-generator.js ***!
              \************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = (
                /** @class */
                function() {
                  function _() {
                  }
                  return d(_, "MP4"), _.init = function() {
                    _.types = {
                      avc1: [],
                      avcC: [],
                      btrt: [],
                      dinf: [],
                      dref: [],
                      esds: [],
                      ftyp: [],
                      hdlr: [],
                      mdat: [],
                      mdhd: [],
                      mdia: [],
                      mfhd: [],
                      minf: [],
                      moof: [],
                      moov: [],
                      mp4a: [],
                      mvex: [],
                      mvhd: [],
                      sdtp: [],
                      stbl: [],
                      stco: [],
                      stsc: [],
                      stsd: [],
                      stsz: [],
                      stts: [],
                      tfdt: [],
                      tfhd: [],
                      traf: [],
                      trak: [],
                      trun: [],
                      trex: [],
                      tkhd: [],
                      vmhd: [],
                      smhd: [],
                      ".mp3": []
                    };
                    for (var u in _.types)
                      _.types.hasOwnProperty(u) && (_.types[u] = [
                        u.charCodeAt(0),
                        u.charCodeAt(1),
                        u.charCodeAt(2),
                        u.charCodeAt(3)
                      ]);
                    var o = _.constants = {};
                    o.FTYP = new Uint8Array([
                      105,
                      115,
                      111,
                      109,
                      0,
                      0,
                      0,
                      1,
                      105,
                      115,
                      111,
                      109,
                      97,
                      118,
                      99,
                      49
                      // avc1
                    ]), o.STSD_PREFIX = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1
                      // entry_count
                    ]), o.STTS = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0
                      // entry_count
                    ]), o.STSC = o.STCO = o.STTS, o.STSZ = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0
                      // sample_count
                    ]), o.HDLR_VIDEO = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      118,
                      105,
                      100,
                      101,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      86,
                      105,
                      100,
                      101,
                      111,
                      72,
                      97,
                      110,
                      100,
                      108,
                      101,
                      114,
                      0
                      // name: VideoHandler
                    ]), o.HDLR_AUDIO = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      115,
                      111,
                      117,
                      110,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      83,
                      111,
                      117,
                      110,
                      100,
                      72,
                      97,
                      110,
                      100,
                      108,
                      101,
                      114,
                      0
                      // name: SoundHandler
                    ]), o.DREF = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      12,
                      117,
                      114,
                      108,
                      32,
                      0,
                      0,
                      0,
                      1
                      // version(0) + flags
                    ]), o.SMHD = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0
                      // balance(2) + reserved(2)
                    ]), o.VMHD = new Uint8Array([
                      0,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0
                    ]);
                  }, _.box = function(u) {
                    for (var o = 8, h = null, r = Array.prototype.slice.call(arguments, 1), a = r.length, l = 0; l < a; l++)
                      o += r[l].byteLength;
                    h = new Uint8Array(o), h[0] = o >>> 24 & 255, h[1] = o >>> 16 & 255, h[2] = o >>> 8 & 255, h[3] = o & 255, h.set(u, 4);
                    for (var i = 8, l = 0; l < a; l++)
                      h.set(r[l], i), i += r[l].byteLength;
                    return h;
                  }, _.generateInitSegment = function(u) {
                    var o = _.box(_.types.ftyp, _.constants.FTYP), h = _.moov(u), r = new Uint8Array(o.byteLength + h.byteLength);
                    return r.set(o, 0), r.set(h, o.byteLength), r;
                  }, _.moov = function(u) {
                    var o = _.mvhd(u.timescale, u.duration), h = _.trak(u), r = _.mvex(u);
                    return _.box(_.types.moov, o, h, r);
                  }, _.mvhd = function(u, o) {
                    return _.box(_.types.mvhd, new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      u >>> 24 & 255,
                      u >>> 16 & 255,
                      u >>> 8 & 255,
                      u & 255,
                      o >>> 24 & 255,
                      o >>> 16 & 255,
                      o >>> 8 & 255,
                      o & 255,
                      0,
                      1,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      64,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      255,
                      255,
                      255,
                      255
                      // next_track_ID
                    ]));
                  }, _.trak = function(u) {
                    return _.box(_.types.trak, _.tkhd(u), _.mdia(u));
                  }, _.tkhd = function(u) {
                    var o = u.id, h = u.duration, r = u.presentWidth, a = u.presentHeight;
                    return _.box(_.types.tkhd, new Uint8Array([
                      0,
                      0,
                      0,
                      7,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      o >>> 24 & 255,
                      o >>> 16 & 255,
                      o >>> 8 & 255,
                      o & 255,
                      0,
                      0,
                      0,
                      0,
                      h >>> 24 & 255,
                      h >>> 16 & 255,
                      h >>> 8 & 255,
                      h & 255,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      64,
                      0,
                      0,
                      0,
                      r >>> 8 & 255,
                      r & 255,
                      0,
                      0,
                      a >>> 8 & 255,
                      a & 255,
                      0,
                      0
                    ]));
                  }, _.mdia = function(u) {
                    return _.box(_.types.mdia, _.mdhd(u), _.hdlr(u), _.minf(u));
                  }, _.mdhd = function(u) {
                    var o = u.timescale, h = u.duration;
                    return _.box(_.types.mdhd, new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      o >>> 24 & 255,
                      o >>> 16 & 255,
                      o >>> 8 & 255,
                      o & 255,
                      h >>> 24 & 255,
                      h >>> 16 & 255,
                      h >>> 8 & 255,
                      h & 255,
                      85,
                      196,
                      0,
                      0
                      // pre_defined = 0
                    ]));
                  }, _.hdlr = function(u) {
                    var o = null;
                    return u.type === "audio" ? o = _.constants.HDLR_AUDIO : o = _.constants.HDLR_VIDEO, _.box(_.types.hdlr, o);
                  }, _.minf = function(u) {
                    var o = null;
                    return u.type === "audio" ? o = _.box(_.types.smhd, _.constants.SMHD) : o = _.box(_.types.vmhd, _.constants.VMHD), _.box(_.types.minf, o, _.dinf(), _.stbl(u));
                  }, _.dinf = function() {
                    var u = _.box(_.types.dinf, _.box(_.types.dref, _.constants.DREF));
                    return u;
                  }, _.stbl = function(u) {
                    var o = _.box(
                      _.types.stbl,
                      // type: stbl
                      _.stsd(u),
                      // Sample Description Table
                      _.box(_.types.stts, _.constants.STTS),
                      // Time-To-Sample
                      _.box(_.types.stsc, _.constants.STSC),
                      // Sample-To-Chunk
                      _.box(_.types.stsz, _.constants.STSZ),
                      // Sample size
                      _.box(_.types.stco, _.constants.STCO)
                      // Chunk offset
                    );
                    return o;
                  }, _.stsd = function(u) {
                    return u.type === "audio" ? u.codec === "mp3" ? _.box(_.types.stsd, _.constants.STSD_PREFIX, _.mp3(u)) : _.box(_.types.stsd, _.constants.STSD_PREFIX, _.mp4a(u)) : _.box(_.types.stsd, _.constants.STSD_PREFIX, _.avc1(u));
                  }, _.mp3 = function(u) {
                    var o = u.channelCount, h = u.audioSampleRate, r = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      o,
                      0,
                      16,
                      0,
                      0,
                      0,
                      0,
                      h >>> 8 & 255,
                      h & 255,
                      0,
                      0
                    ]);
                    return _.box(_.types[".mp3"], r);
                  }, _.mp4a = function(u) {
                    var o = u.channelCount, h = u.audioSampleRate, r = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      o,
                      0,
                      16,
                      0,
                      0,
                      0,
                      0,
                      h >>> 8 & 255,
                      h & 255,
                      0,
                      0
                    ]);
                    return _.box(_.types.mp4a, r, _.esds(u));
                  }, _.esds = function(u) {
                    var o = u.config || [], h = o.length, r = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      3,
                      23 + h,
                      0,
                      1,
                      0,
                      4,
                      15 + h,
                      64,
                      21,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      5
                      // descriptor_type
                    ].concat([
                      h
                    ]).concat(o).concat([
                      6,
                      1,
                      2
                      // GASpecificConfig
                    ]));
                    return _.box(_.types.esds, r);
                  }, _.avc1 = function(u) {
                    var o = u.avcc, h = u.codecWidth, r = u.codecHeight, a = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      h >>> 8 & 255,
                      h & 255,
                      r >>> 8 & 255,
                      r & 255,
                      0,
                      72,
                      0,
                      0,
                      0,
                      72,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1,
                      10,
                      120,
                      113,
                      113,
                      47,
                      102,
                      108,
                      118,
                      46,
                      106,
                      115,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      24,
                      255,
                      255
                      // pre_defined = -1
                    ]);
                    return _.box(_.types.avc1, a, _.box(_.types.avcC, o));
                  }, _.mvex = function(u) {
                    return _.box(_.types.mvex, _.trex(u));
                  }, _.trex = function(u) {
                    var o = u.id, h = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      o >>> 24 & 255,
                      o >>> 16 & 255,
                      o >>> 8 & 255,
                      o & 255,
                      0,
                      0,
                      0,
                      1,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      0,
                      1,
                      0,
                      1
                      // default_sample_flags
                    ]);
                    return _.box(_.types.trex, h);
                  }, _.moof = function(u, o) {
                    return _.box(_.types.moof, _.mfhd(u.sequenceNumber), _.traf(u, o));
                  }, _.mfhd = function(u) {
                    var o = new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      u >>> 24 & 255,
                      u >>> 16 & 255,
                      u >>> 8 & 255,
                      u & 255
                    ]);
                    return _.box(_.types.mfhd, o);
                  }, _.traf = function(u, o) {
                    var h = u.id, r = _.box(_.types.tfhd, new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      h >>> 24 & 255,
                      h >>> 16 & 255,
                      h >>> 8 & 255,
                      h & 255
                    ])), a = _.box(_.types.tfdt, new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      o >>> 24 & 255,
                      o >>> 16 & 255,
                      o >>> 8 & 255,
                      o & 255
                    ])), l = _.sdtp(u), i = _.trun(u, l.byteLength + 16 + 16 + 8 + 16 + 8 + 8);
                    return _.box(_.types.traf, r, a, i, l);
                  }, _.sdtp = function(u) {
                    for (var o = u.samples || [], h = o.length, r = new Uint8Array(4 + h), a = 0; a < h; a++) {
                      var l = o[a].flags;
                      r[a + 4] = l.isLeading << 6 | l.dependsOn << 4 | l.isDependedOn << 2 | l.hasRedundancy;
                    }
                    return _.box(_.types.sdtp, r);
                  }, _.trun = function(u, o) {
                    var h = u.samples || [], r = h.length, a = 12 + 16 * r, l = new Uint8Array(a);
                    o += 8 + a, l.set([
                      0,
                      0,
                      15,
                      1,
                      r >>> 24 & 255,
                      r >>> 16 & 255,
                      r >>> 8 & 255,
                      r & 255,
                      o >>> 24 & 255,
                      o >>> 16 & 255,
                      o >>> 8 & 255,
                      o & 255
                    ], 0);
                    for (var i = 0; i < r; i++) {
                      var t = h[i].duration, s = h[i].size, n = h[i].flags, e = h[i].cts;
                      l.set([
                        t >>> 24 & 255,
                        t >>> 16 & 255,
                        t >>> 8 & 255,
                        t & 255,
                        s >>> 24 & 255,
                        s >>> 16 & 255,
                        s >>> 8 & 255,
                        s & 255,
                        n.isLeading << 2 | n.dependsOn,
                        n.isDependedOn << 6 | n.hasRedundancy << 4 | n.isNonSync,
                        0,
                        0,
                        e >>> 24 & 255,
                        e >>> 16 & 255,
                        e >>> 8 & 255,
                        e & 255
                      ], 12 + 16 * i);
                    }
                    return _.box(_.types.trun, l);
                  }, _.mdat = function(u) {
                    return _.box(_.types.mdat, u);
                  }, _;
                }()
              );
              S.init(), A.default = S;
            }, "./src/remux/mp4-generator.js")
          ),
          /***/
          "./src/remux/mp4-remuxer.js": (
            /*!**********************************!*\
              !*** ./src/remux/mp4-remuxer.js ***!
              \**********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! ../utils/logger.js */
                "./src/utils/logger.js"
              ), _ = v(
                /*! ./mp4-generator.js */
                "./src/remux/mp4-generator.js"
              ), u = v(
                /*! ./aac-silent.js */
                "./src/remux/aac-silent.js"
              ), o = v(
                /*! ../utils/browser.js */
                "./src/utils/browser.js"
              ), h = v(
                /*! ../core/media-segment-info.js */
                "./src/core/media-segment-info.js"
              ), r = v(
                /*! ../utils/exception.js */
                "./src/utils/exception.js"
              ), a = (
                /** @class */
                function() {
                  function l(i) {
                    this.TAG = "MP4Remuxer", this._config = i, this._isLive = i.isLive === !0, this._dtsBase = -1, this._dtsBaseInited = !1, this._audioDtsBase = 1 / 0, this._videoDtsBase = 1 / 0, this._audioNextDts = void 0, this._videoNextDts = void 0, this._audioStashedLastSample = null, this._videoStashedLastSample = null, this._audioMeta = null, this._videoMeta = null, this._audioSegmentInfoList = new h.MediaSegmentInfoList("audio"), this._videoSegmentInfoList = new h.MediaSegmentInfoList("video"), this._onInitSegment = null, this._onMediaSegment = null, this._forceFirstIDR = !!(o.default.chrome && (o.default.version.major < 50 || o.default.version.major === 50 && o.default.version.build < 2661)), this._fillSilentAfterSeek = o.default.msedge || o.default.msie, this._mp3UseMpegAudio = !o.default.firefox, this._fillAudioTimestampGap = this._config.fixAudioTimestampGap;
                  }
                  return d(l, "MP4Remuxer"), l.prototype.destroy = function() {
                    this._dtsBase = -1, this._dtsBaseInited = !1, this._audioMeta = null, this._videoMeta = null, this._audioSegmentInfoList.clear(), this._audioSegmentInfoList = null, this._videoSegmentInfoList.clear(), this._videoSegmentInfoList = null, this._onInitSegment = null, this._onMediaSegment = null;
                  }, l.prototype.bindDataSource = function(i) {
                    return i.onDataAvailable = this.remux.bind(this), i.onTrackMetadata = this._onTrackMetadataReceived.bind(this), this;
                  }, Object.defineProperty(l.prototype, "onInitSegment", {
                    /* prototype: function onInitSegment(type: string, initSegment: ArrayBuffer): void
                       InitSegment: {
                           type: string,
                           data: ArrayBuffer,
                           codec: string,
                           container: string
                       }
                    */
                    get: /* @__PURE__ */ d(function() {
                      return this._onInitSegment;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(i) {
                      this._onInitSegment = i;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(l.prototype, "onMediaSegment", {
                    /* prototype: function onMediaSegment(type: string, mediaSegment: MediaSegment): void
                       MediaSegment: {
                           type: string,
                           data: ArrayBuffer,
                           sampleCount: int32
                           info: MediaSegmentInfo
                       }
                    */
                    get: /* @__PURE__ */ d(function() {
                      return this._onMediaSegment;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(i) {
                      this._onMediaSegment = i;
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), l.prototype.insertDiscontinuity = function() {
                    this._audioNextDts = this._videoNextDts = void 0;
                  }, l.prototype.seek = function(i) {
                    this._audioStashedLastSample = null, this._videoStashedLastSample = null, this._videoSegmentInfoList.clear(), this._audioSegmentInfoList.clear();
                  }, l.prototype.remux = function(i, t) {
                    if (!this._onMediaSegment)
                      throw new r.IllegalStateException("MP4Remuxer: onMediaSegment callback must be specificed!");
                    this._dtsBaseInited || this._calculateDtsBase(i, t), this._remuxVideo(t), this._remuxAudio(i);
                  }, l.prototype._onTrackMetadataReceived = function(i, t) {
                    var s = null, n = "mp4", e = t.codec;
                    if (i === "audio")
                      this._audioMeta = t, t.codec === "mp3" && this._mp3UseMpegAudio ? (n = "mpeg", e = "", s = new Uint8Array()) : s = _.default.generateInitSegment(t);
                    else if (i === "video")
                      this._videoMeta = t, s = _.default.generateInitSegment(t);
                    else
                      return;
                    if (!this._onInitSegment)
                      throw new r.IllegalStateException("MP4Remuxer: onInitSegment callback must be specified!");
                    this._onInitSegment(i, {
                      type: i,
                      data: s.buffer,
                      codec: e,
                      container: i + "/" + n,
                      mediaDuration: t.duration
                      // in timescale 1000 (milliseconds)
                    });
                  }, l.prototype._calculateDtsBase = function(i, t) {
                    this._dtsBaseInited || (i.samples && i.samples.length && (this._audioDtsBase = i.samples[0].dts), t.samples && t.samples.length && (this._videoDtsBase = t.samples[0].dts), this._dtsBase = Math.min(this._audioDtsBase, this._videoDtsBase), this._dtsBaseInited = !0);
                  }, l.prototype.flushStashedSamples = function() {
                    var i = this._videoStashedLastSample, t = this._audioStashedLastSample, s = {
                      type: "video",
                      id: 1,
                      sequenceNumber: 0,
                      samples: [],
                      length: 0
                    };
                    i != null && (s.samples.push(i), s.length = i.length);
                    var n = {
                      type: "audio",
                      id: 2,
                      sequenceNumber: 0,
                      samples: [],
                      length: 0
                    };
                    t != null && (n.samples.push(t), n.length = t.length), this._videoStashedLastSample = null, this._audioStashedLastSample = null, this._remuxVideo(s, !0), this._remuxAudio(n, !0);
                  }, l.prototype._remuxAudio = function(i, t) {
                    if (this._audioMeta != null) {
                      var s = i, n = s.samples, e = void 0, f = -1, c = -1, p = this._audioMeta.refSampleDuration, g = this._audioMeta.codec === "mp3" && this._mp3UseMpegAudio, y = this._dtsBaseInited && this._audioNextDts === void 0, E = !1;
                      if (!(!n || n.length === 0) && !(n.length === 1 && !t)) {
                        var m = 0, x = null, L = 0;
                        g ? (m = 0, L = s.length) : (m = 8, L = 8 + s.length);
                        var O = null;
                        if (n.length > 1 && (O = n.pop(), L -= O.length), this._audioStashedLastSample != null) {
                          var R = this._audioStashedLastSample;
                          this._audioStashedLastSample = null, n.unshift(R), L += R.length;
                        }
                        O != null && (this._audioStashedLastSample = O);
                        var I = n[0].dts - this._dtsBase;
                        if (this._audioNextDts)
                          e = I - this._audioNextDts;
                        else if (this._audioSegmentInfoList.isEmpty())
                          e = 0, this._fillSilentAfterSeek && !this._videoSegmentInfoList.isEmpty() && this._audioMeta.originalCodec !== "mp3" && (E = !0);
                        else {
                          var U = this._audioSegmentInfoList.getLastSampleBefore(I);
                          if (U != null) {
                            var j = I - (U.originalDts + U.duration);
                            j <= 3 && (j = 0);
                            var F = U.dts + U.duration + j;
                            e = I - F;
                          } else
                            e = 0;
                        }
                        if (E) {
                          var N = I - e, W = this._videoSegmentInfoList.getLastSegmentBefore(I);
                          if (W != null && W.beginDts < N) {
                            var w = u.default.getSilentFrame(this._audioMeta.originalCodec, this._audioMeta.channelCount);
                            if (w) {
                              var G = W.beginDts, ee = N - W.beginDts;
                              S.default.v(this.TAG, "InsertPrefixSilentAudio: dts: " + G + ", duration: " + ee), n.unshift({ unit: w, dts: G, pts: G }), L += w.byteLength;
                            }
                          } else
                            E = !1;
                        }
                        for (var K = [], V = 0; V < n.length; V++) {
                          var R = n[V], $ = R.unit, X = R.dts - this._dtsBase, G = X, Z = !1, ie = null, z = 0;
                          if (!(X < -1e-3)) {
                            if (this._audioMeta.codec !== "mp3") {
                              var P = X, J = 3;
                              if (this._audioNextDts && (P = this._audioNextDts), e = X - P, e <= -J * p) {
                                S.default.w(this.TAG, "Dropping 1 audio frame (originalDts: " + X + " ms ,curRefDts: " + P + " ms)  due to dtsCorrection: " + e + " ms overlap.");
                                continue;
                              } else if (e >= J * p && this._fillAudioTimestampGap && !o.default.safari) {
                                Z = !0;
                                var te = Math.floor(e / p);
                                S.default.w(this.TAG, `Large audio timestamp gap detected, may cause AV sync to drift. Silent frames will be generated to avoid unsync.
` + ("originalDts: " + X + " ms, curRefDts: " + P + " ms, ") + ("dtsCorrection: " + Math.round(e) + " ms, generate: " + te + " frames")), G = Math.floor(P), z = Math.floor(P + p) - G;
                                var w = u.default.getSilentFrame(this._audioMeta.originalCodec, this._audioMeta.channelCount);
                                w == null && (S.default.w(this.TAG, "Unable to generate silent frame for " + (this._audioMeta.originalCodec + " with " + this._audioMeta.channelCount + " channels, repeat last frame")), w = $), ie = [];
                                for (var oe = 0; oe < te; oe++) {
                                  P = P + p;
                                  var ne = Math.floor(P), se = Math.floor(P + p) - ne, ae = {
                                    dts: ne,
                                    pts: ne,
                                    cts: 0,
                                    unit: w,
                                    size: w.byteLength,
                                    duration: se,
                                    originalDts: X,
                                    flags: {
                                      isLeading: 0,
                                      dependsOn: 1,
                                      isDependedOn: 0,
                                      hasRedundancy: 0
                                    }
                                  };
                                  ie.push(ae), L += ae.size;
                                }
                                this._audioNextDts = P + p;
                              } else
                                G = Math.floor(P), z = Math.floor(P + p) - G, this._audioNextDts = P + p;
                            } else {
                              if (G = X - e, V !== n.length - 1) {
                                var ue = n[V + 1].dts - this._dtsBase - e;
                                z = ue - G;
                              } else if (O != null) {
                                var ue = O.dts - this._dtsBase - e;
                                z = ue - G;
                              } else K.length >= 1 ? z = K[K.length - 1].duration : z = Math.floor(p);
                              this._audioNextDts = G + z;
                            }
                            f === -1 && (f = G), K.push({
                              dts: G,
                              pts: G,
                              cts: 0,
                              unit: R.unit,
                              size: R.unit.byteLength,
                              duration: z,
                              originalDts: X,
                              flags: {
                                isLeading: 0,
                                dependsOn: 1,
                                isDependedOn: 0,
                                hasRedundancy: 0
                              }
                            }), Z && K.push.apply(K, ie);
                          }
                        }
                        if (K.length === 0) {
                          s.samples = [], s.length = 0;
                          return;
                        }
                        g ? x = new Uint8Array(L) : (x = new Uint8Array(L), x[0] = L >>> 24 & 255, x[1] = L >>> 16 & 255, x[2] = L >>> 8 & 255, x[3] = L & 255, x.set(_.default.types.mdat, 4));
                        for (var V = 0; V < K.length; V++) {
                          var $ = K[V].unit;
                          x.set($, m), m += $.byteLength;
                        }
                        var re = K[K.length - 1];
                        c = re.dts + re.duration;
                        var q = new h.MediaSegmentInfo();
                        q.beginDts = f, q.endDts = c, q.beginPts = f, q.endPts = c, q.originalBeginDts = K[0].originalDts, q.originalEndDts = re.originalDts + re.duration, q.firstSample = new h.SampleInfo(K[0].dts, K[0].pts, K[0].duration, K[0].originalDts, !1), q.lastSample = new h.SampleInfo(re.dts, re.pts, re.duration, re.originalDts, !1), this._isLive || this._audioSegmentInfoList.append(q), s.samples = K, s.sequenceNumber++;
                        var fe = null;
                        g ? fe = new Uint8Array() : fe = _.default.moof(s, f), s.samples = [], s.length = 0;
                        var de = {
                          type: "audio",
                          data: this._mergeBoxes(fe, x).buffer,
                          sampleCount: K.length,
                          info: q
                        };
                        g && y && (de.timestampOffset = f), this._onMediaSegment("audio", de);
                      }
                    }
                  }, l.prototype._remuxVideo = function(i, t) {
                    if (this._videoMeta != null) {
                      var s = i, n = s.samples, e = void 0, f = -1, c = -1, p = -1, g = -1;
                      if (!(!n || n.length === 0) && !(n.length === 1 && !t)) {
                        var y = 8, E = null, m = 8 + i.length, x = null;
                        if (n.length > 1 && (x = n.pop(), m -= x.length), this._videoStashedLastSample != null) {
                          var L = this._videoStashedLastSample;
                          this._videoStashedLastSample = null, n.unshift(L), m += L.length;
                        }
                        x != null && (this._videoStashedLastSample = x);
                        var O = n[0].dts - this._dtsBase;
                        if (this._videoNextDts)
                          e = O - this._videoNextDts;
                        else if (this._videoSegmentInfoList.isEmpty())
                          e = 0;
                        else {
                          var R = this._videoSegmentInfoList.getLastSampleBefore(O);
                          if (R != null) {
                            var I = O - (R.originalDts + R.duration);
                            I <= 3 && (I = 0);
                            var U = R.dts + R.duration + I;
                            e = O - U;
                          } else
                            e = 0;
                        }
                        for (var j = new h.MediaSegmentInfo(), F = [], N = 0; N < n.length; N++) {
                          var L = n[N], W = L.dts - this._dtsBase, w = L.isKeyframe, G = W - e, ee = L.cts, K = G + ee;
                          f === -1 && (f = G, p = K);
                          var V = 0;
                          if (N !== n.length - 1) {
                            var $ = n[N + 1].dts - this._dtsBase - e;
                            V = $ - G;
                          } else if (x != null) {
                            var $ = x.dts - this._dtsBase - e;
                            V = $ - G;
                          } else F.length >= 1 ? V = F[F.length - 1].duration : V = Math.floor(this._videoMeta.refSampleDuration);
                          if (w) {
                            var X = new h.SampleInfo(G, K, V, L.dts, !0);
                            X.fileposition = L.fileposition, j.appendSyncPoint(X);
                          }
                          F.push({
                            dts: G,
                            pts: K,
                            cts: ee,
                            units: L.units,
                            size: L.length,
                            isKeyframe: w,
                            duration: V,
                            originalDts: W,
                            flags: {
                              isLeading: 0,
                              dependsOn: w ? 2 : 1,
                              isDependedOn: w ? 1 : 0,
                              hasRedundancy: 0,
                              isNonSync: w ? 0 : 1
                            }
                          });
                        }
                        E = new Uint8Array(m), E[0] = m >>> 24 & 255, E[1] = m >>> 16 & 255, E[2] = m >>> 8 & 255, E[3] = m & 255, E.set(_.default.types.mdat, 4);
                        for (var N = 0; N < F.length; N++)
                          for (var Z = F[N].units; Z.length; ) {
                            var ie = Z.shift(), z = ie.data;
                            E.set(z, y), y += z.byteLength;
                          }
                        var P = F[F.length - 1];
                        if (c = P.dts + P.duration, g = P.pts + P.duration, this._videoNextDts = c, j.beginDts = f, j.endDts = c, j.beginPts = p, j.endPts = g, j.originalBeginDts = F[0].originalDts, j.originalEndDts = P.originalDts + P.duration, j.firstSample = new h.SampleInfo(F[0].dts, F[0].pts, F[0].duration, F[0].originalDts, F[0].isKeyframe), j.lastSample = new h.SampleInfo(P.dts, P.pts, P.duration, P.originalDts, P.isKeyframe), this._isLive || this._videoSegmentInfoList.append(j), s.samples = F, s.sequenceNumber++, this._forceFirstIDR) {
                          var J = F[0].flags;
                          J.dependsOn = 2, J.isNonSync = 0;
                        }
                        var te = _.default.moof(s, f);
                        s.samples = [], s.length = 0, this._onMediaSegment("video", {
                          type: "video",
                          data: this._mergeBoxes(te, E).buffer,
                          sampleCount: F.length,
                          info: j
                        });
                      }
                    }
                  }, l.prototype._mergeBoxes = function(i, t) {
                    var s = new Uint8Array(i.byteLength + t.byteLength);
                    return s.set(i, 0), s.set(t, i.byteLength), s;
                  }, l;
                }()
              );
              A.default = a;
            }, "./src/remux/mp4-remuxer.js")
          ),
          /***/
          "./src/utils/browser.js": (
            /*!******************************!*\
              !*** ./src/utils/browser.js ***!
              \******************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = {};
              function _() {
                var u = self.navigator.userAgent.toLowerCase(), o = /(edge)\/([\w.]+)/.exec(u) || /(opr)[\/]([\w.]+)/.exec(u) || /(chrome)[ \/]([\w.]+)/.exec(u) || /(iemobile)[\/]([\w.]+)/.exec(u) || /(version)(applewebkit)[ \/]([\w.]+).*(safari)[ \/]([\w.]+)/.exec(u) || /(webkit)[ \/]([\w.]+).*(version)[ \/]([\w.]+).*(safari)[ \/]([\w.]+)/.exec(u) || /(webkit)[ \/]([\w.]+)/.exec(u) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(u) || /(msie) ([\w.]+)/.exec(u) || u.indexOf("trident") >= 0 && /(rv)(?::| )([\w.]+)/.exec(u) || u.indexOf("compatible") < 0 && /(firefox)[ \/]([\w.]+)/.exec(u) || [], h = /(ipad)/.exec(u) || /(ipod)/.exec(u) || /(windows phone)/.exec(u) || /(iphone)/.exec(u) || /(kindle)/.exec(u) || /(android)/.exec(u) || /(windows)/.exec(u) || /(mac)/.exec(u) || /(linux)/.exec(u) || /(cros)/.exec(u) || [], r = {
                  browser: o[5] || o[3] || o[1] || "",
                  version: o[2] || o[4] || "0",
                  majorVersion: o[4] || o[2] || "0",
                  platform: h[0] || ""
                }, a = {};
                if (r.browser) {
                  a[r.browser] = !0;
                  var l = r.majorVersion.split(".");
                  a.version = {
                    major: parseInt(r.majorVersion, 10),
                    string: r.version
                  }, l.length > 1 && (a.version.minor = parseInt(l[1], 10)), l.length > 2 && (a.version.build = parseInt(l[2], 10));
                }
                if (r.platform && (a[r.platform] = !0), (a.chrome || a.opr || a.safari) && (a.webkit = !0), a.rv || a.iemobile) {
                  a.rv && delete a.rv;
                  var i = "msie";
                  r.browser = i, a[i] = !0;
                }
                if (a.edge) {
                  delete a.edge;
                  var t = "msedge";
                  r.browser = t, a[t] = !0;
                }
                if (a.opr) {
                  var s = "opera";
                  r.browser = s, a[s] = !0;
                }
                if (a.safari && a.android) {
                  var n = "android";
                  r.browser = n, a[n] = !0;
                }
                a.name = r.browser, a.platform = r.platform;
                for (var e in S)
                  S.hasOwnProperty(e) && delete S[e];
                Object.assign(S, a);
              }
              d(_, "detect"), _(), A.default = S;
            }, "./src/utils/browser.js")
          ),
          /***/
          "./src/utils/exception.js": (
            /*!********************************!*\
              !*** ./src/utils/exception.js ***!
              \********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A), v.d(A, {
                /* harmony export */
                RuntimeException: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    _
                  );
                }, "RuntimeException"),
                /* harmony export */
                IllegalStateException: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    u
                  );
                }, "IllegalStateException"),
                /* harmony export */
                InvalidArgumentException: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    o
                  );
                }, "InvalidArgumentException"),
                /* harmony export */
                NotImplementedException: /* @__PURE__ */ d(function() {
                  return (
                    /* binding */
                    h
                  );
                }, "NotImplementedException")
                /* harmony export */
              });
              var S = /* @__PURE__ */ function() {
                var r = /* @__PURE__ */ d(function(a, l) {
                  return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
                    i.__proto__ = t;
                  } || function(i, t) {
                    for (var s in t) Object.prototype.hasOwnProperty.call(t, s) && (i[s] = t[s]);
                  }, r(a, l);
                }, "extendStatics");
                return function(a, l) {
                  if (typeof l != "function" && l !== null)
                    throw new TypeError("Class extends value " + String(l) + " is not a constructor or null");
                  r(a, l);
                  function i() {
                    this.constructor = a;
                  }
                  d(i, "__"), a.prototype = l === null ? Object.create(l) : (i.prototype = l.prototype, new i());
                };
              }(), _ = (
                /** @class */
                function() {
                  function r(a) {
                    this._message = a;
                  }
                  return d(r, "RuntimeException"), Object.defineProperty(r.prototype, "name", {
                    get: /* @__PURE__ */ d(function() {
                      return "RuntimeException";
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(r.prototype, "message", {
                    get: /* @__PURE__ */ d(function() {
                      return this._message;
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), r.prototype.toString = function() {
                    return this.name + ": " + this.message;
                  }, r;
                }()
              ), u = (
                /** @class */
                function(r) {
                  S(a, r);
                  function a(l) {
                    return r.call(this, l) || this;
                  }
                  return d(a, "IllegalStateException"), Object.defineProperty(a.prototype, "name", {
                    get: /* @__PURE__ */ d(function() {
                      return "IllegalStateException";
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), a;
                }(_)
              ), o = (
                /** @class */
                function(r) {
                  S(a, r);
                  function a(l) {
                    return r.call(this, l) || this;
                  }
                  return d(a, "InvalidArgumentException"), Object.defineProperty(a.prototype, "name", {
                    get: /* @__PURE__ */ d(function() {
                      return "InvalidArgumentException";
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), a;
                }(_)
              ), h = (
                /** @class */
                function(r) {
                  S(a, r);
                  function a(l) {
                    return r.call(this, l) || this;
                  }
                  return d(a, "NotImplementedException"), Object.defineProperty(a.prototype, "name", {
                    get: /* @__PURE__ */ d(function() {
                      return "NotImplementedException";
                    }, "get"),
                    enumerable: !1,
                    configurable: !0
                  }), a;
                }(_)
              );
            }, "./src/utils/exception.js")
          ),
          /***/
          "./src/utils/logger.js": (
            /*!*****************************!*\
              !*** ./src/utils/logger.js ***!
              \*****************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! events */
                "./node_modules/events/events.js"
              ), _ = /* @__PURE__ */ v.n(S), u = (
                /** @class */
                function() {
                  function o() {
                  }
                  return d(o, "Log"), o.e = function(h, r) {
                    (!h || o.FORCE_GLOBAL_TAG) && (h = o.GLOBAL_TAG);
                    var a = "[" + h + "] > " + r;
                    o.ENABLE_CALLBACK && o.emitter.emit("log", "error", a), o.ENABLE_ERROR && (console.error ? console.error(a) : console.warn && console.warn(a));
                  }, o.i = function(h, r) {
                    (!h || o.FORCE_GLOBAL_TAG) && (h = o.GLOBAL_TAG);
                    var a = "[" + h + "] > " + r;
                    o.ENABLE_CALLBACK && o.emitter.emit("log", "info", a), o.ENABLE_INFO && console.info && console.info(a);
                  }, o.w = function(h, r) {
                    (!h || o.FORCE_GLOBAL_TAG) && (h = o.GLOBAL_TAG);
                    var a = "[" + h + "] > " + r;
                    o.ENABLE_CALLBACK && o.emitter.emit("log", "warn", a), o.ENABLE_WARN && console.warn && console.warn(a);
                  }, o.d = function(h, r) {
                    (!h || o.FORCE_GLOBAL_TAG) && (h = o.GLOBAL_TAG);
                    var a = "[" + h + "] > " + r;
                    o.ENABLE_CALLBACK && o.emitter.emit("log", "debug", a), o.ENABLE_DEBUG && console.debug && console.debug(a);
                  }, o.v = function(h, r) {
                    (!h || o.FORCE_GLOBAL_TAG) && (h = o.GLOBAL_TAG);
                    var a = "[" + h + "] > " + r;
                    o.ENABLE_CALLBACK && o.emitter.emit("log", "verbose", a), o.ENABLE_VERBOSE;
                  }, o;
                }()
              );
              u.GLOBAL_TAG = "flv.js", u.FORCE_GLOBAL_TAG = !1, u.ENABLE_ERROR = !0, u.ENABLE_INFO = !0, u.ENABLE_WARN = !0, u.ENABLE_DEBUG = !0, u.ENABLE_VERBOSE = !0, u.ENABLE_CALLBACK = !1, u.emitter = new (_())(), A.default = u;
            }, "./src/utils/logger.js")
          ),
          /***/
          "./src/utils/logging-control.js": (
            /*!**************************************!*\
              !*** ./src/utils/logging-control.js ***!
              \**************************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = v(
                /*! events */
                "./node_modules/events/events.js"
              ), _ = /* @__PURE__ */ v.n(S), u = v(
                /*! ./logger.js */
                "./src/utils/logger.js"
              ), o = (
                /** @class */
                function() {
                  function h() {
                  }
                  return d(h, "LoggingControl"), Object.defineProperty(h, "forceGlobalTag", {
                    get: /* @__PURE__ */ d(function() {
                      return u.default.FORCE_GLOBAL_TAG;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      u.default.FORCE_GLOBAL_TAG = r, h._notifyChange();
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h, "globalTag", {
                    get: /* @__PURE__ */ d(function() {
                      return u.default.GLOBAL_TAG;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      u.default.GLOBAL_TAG = r, h._notifyChange();
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h, "enableAll", {
                    get: /* @__PURE__ */ d(function() {
                      return u.default.ENABLE_VERBOSE && u.default.ENABLE_DEBUG && u.default.ENABLE_INFO && u.default.ENABLE_WARN && u.default.ENABLE_ERROR;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      u.default.ENABLE_VERBOSE = r, u.default.ENABLE_DEBUG = r, u.default.ENABLE_INFO = r, u.default.ENABLE_WARN = r, u.default.ENABLE_ERROR = r, h._notifyChange();
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h, "enableDebug", {
                    get: /* @__PURE__ */ d(function() {
                      return u.default.ENABLE_DEBUG;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      u.default.ENABLE_DEBUG = r, h._notifyChange();
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h, "enableVerbose", {
                    get: /* @__PURE__ */ d(function() {
                      return u.default.ENABLE_VERBOSE;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      u.default.ENABLE_VERBOSE = r, h._notifyChange();
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h, "enableInfo", {
                    get: /* @__PURE__ */ d(function() {
                      return u.default.ENABLE_INFO;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      u.default.ENABLE_INFO = r, h._notifyChange();
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h, "enableWarn", {
                    get: /* @__PURE__ */ d(function() {
                      return u.default.ENABLE_WARN;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      u.default.ENABLE_WARN = r, h._notifyChange();
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), Object.defineProperty(h, "enableError", {
                    get: /* @__PURE__ */ d(function() {
                      return u.default.ENABLE_ERROR;
                    }, "get"),
                    set: /* @__PURE__ */ d(function(r) {
                      u.default.ENABLE_ERROR = r, h._notifyChange();
                    }, "set"),
                    enumerable: !1,
                    configurable: !0
                  }), h.getConfig = function() {
                    return {
                      globalTag: u.default.GLOBAL_TAG,
                      forceGlobalTag: u.default.FORCE_GLOBAL_TAG,
                      enableVerbose: u.default.ENABLE_VERBOSE,
                      enableDebug: u.default.ENABLE_DEBUG,
                      enableInfo: u.default.ENABLE_INFO,
                      enableWarn: u.default.ENABLE_WARN,
                      enableError: u.default.ENABLE_ERROR,
                      enableCallback: u.default.ENABLE_CALLBACK
                    };
                  }, h.applyConfig = function(r) {
                    u.default.GLOBAL_TAG = r.globalTag, u.default.FORCE_GLOBAL_TAG = r.forceGlobalTag, u.default.ENABLE_VERBOSE = r.enableVerbose, u.default.ENABLE_DEBUG = r.enableDebug, u.default.ENABLE_INFO = r.enableInfo, u.default.ENABLE_WARN = r.enableWarn, u.default.ENABLE_ERROR = r.enableError, u.default.ENABLE_CALLBACK = r.enableCallback;
                  }, h._notifyChange = function() {
                    var r = h.emitter;
                    if (r.listenerCount("change") > 0) {
                      var a = h.getConfig();
                      r.emit("change", a);
                    }
                  }, h.registerListener = function(r) {
                    h.emitter.addListener("change", r);
                  }, h.removeListener = function(r) {
                    h.emitter.removeListener("change", r);
                  }, h.addLogListener = function(r) {
                    u.default.emitter.addListener("log", r), u.default.emitter.listenerCount("log") > 0 && (u.default.ENABLE_CALLBACK = !0, h._notifyChange());
                  }, h.removeLogListener = function(r) {
                    u.default.emitter.removeListener("log", r), u.default.emitter.listenerCount("log") === 0 && (u.default.ENABLE_CALLBACK = !1, h._notifyChange());
                  }, h;
                }()
              );
              o.emitter = new (_())(), A.default = o;
            }, "./src/utils/logging-control.js")
          ),
          /***/
          "./src/utils/polyfill.js": (
            /*!*******************************!*\
              !*** ./src/utils/polyfill.js ***!
              \*******************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              var S = (
                /** @class */
                function() {
                  function _() {
                  }
                  return d(_, "Polyfill"), _.install = function() {
                    Object.setPrototypeOf = Object.setPrototypeOf || function(u, o) {
                      return u.__proto__ = o, u;
                    }, Object.assign = Object.assign || function(u) {
                      if (u == null)
                        throw new TypeError("Cannot convert undefined or null to object");
                      for (var o = Object(u), h = 1; h < arguments.length; h++) {
                        var r = arguments[h];
                        if (r != null)
                          for (var a in r)
                            r.hasOwnProperty(a) && (o[a] = r[a]);
                      }
                      return o;
                    }, typeof self.Promise != "function" && v(
                      /*! es6-promise */
                      "./node_modules/es6-promise/dist/es6-promise.js"
                    ).polyfill();
                  }, _;
                }()
              );
              S.install(), A.default = S;
            }, "./src/utils/polyfill.js")
          ),
          /***/
          "./src/utils/utf8-conv.js": (
            /*!********************************!*\
              !*** ./src/utils/utf8-conv.js ***!
              \********************************/
            /***/
            /* @__PURE__ */ d(function(D, A, v) {
              v.r(A);
              function S(u, o, h) {
                var r = u;
                if (o + h < r.length) {
                  for (; h--; )
                    if ((r[++o] & 192) !== 128)
                      return !1;
                  return !0;
                } else
                  return !1;
              }
              d(S, "checkContinuation");
              function _(u) {
                for (var o = [], h = u, r = 0, a = u.length; r < a; ) {
                  if (h[r] < 128) {
                    o.push(String.fromCharCode(h[r])), ++r;
                    continue;
                  } else if (!(h[r] < 192)) {
                    if (h[r] < 224) {
                      if (S(h, r, 1)) {
                        var l = (h[r] & 31) << 6 | h[r + 1] & 63;
                        if (l >= 128) {
                          o.push(String.fromCharCode(l & 65535)), r += 2;
                          continue;
                        }
                      }
                    } else if (h[r] < 240) {
                      if (S(h, r, 2)) {
                        var l = (h[r] & 15) << 12 | (h[r + 1] & 63) << 6 | h[r + 2] & 63;
                        if (l >= 2048 && (l & 63488) !== 55296) {
                          o.push(String.fromCharCode(l & 65535)), r += 3;
                          continue;
                        }
                      }
                    } else if (h[r] < 248 && S(h, r, 3)) {
                      var l = (h[r] & 7) << 18 | (h[r + 1] & 63) << 12 | (h[r + 2] & 63) << 6 | h[r + 3] & 63;
                      if (l > 65536 && l < 1114112) {
                        l -= 65536, o.push(String.fromCharCode(l >>> 10 | 55296)), o.push(String.fromCharCode(l & 1023 | 56320)), r += 4;
                        continue;
                      }
                    }
                  }
                  o.push("�"), ++r;
                }
                return o.join("");
              }
              d(_, "decodeUTF8"), A.default = _;
            }, "./src/utils/utf8-conv.js")
          )
          /******/
        }, pe = {};
        function Q(D) {
          var A = pe[D];
          if (A !== void 0)
            return A.exports;
          var v = pe[D] = {
            /******/
            // no module.id needed
            /******/
            // no module.loaded needed
            /******/
            exports: {}
            /******/
          };
          return ce[D].call(v.exports, v, v.exports, Q), v.exports;
        }
        d(Q, "__webpack_require__"), Q.m = ce, function() {
          Q.n = function(D) {
            var A = D && D.__esModule ? (
              /******/
              function() {
                return D.default;
              }
            ) : (
              /******/
              function() {
                return D;
              }
            );
            return Q.d(A, { a: A }), A;
          };
        }(), function() {
          Q.d = function(D, A) {
            for (var v in A)
              Q.o(A, v) && !Q.o(D, v) && Object.defineProperty(D, v, { enumerable: !0, get: A[v] });
          };
        }(), function() {
          Q.g = function() {
            if (typeof globalThis == "object") return globalThis;
            try {
              return this || new Function("return this")();
            } catch {
              if (typeof window == "object") return window;
            }
          }();
        }(), function() {
          Q.o = function(D, A) {
            return Object.prototype.hasOwnProperty.call(D, A);
          };
        }(), function() {
          Q.r = function(D) {
            typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(D, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(D, "__esModule", { value: !0 });
          };
        }();
        var Ee = Q("./src/index.js");
        return Ee;
      }()
    );
  });
})(xe);
var Oe = xe.exports;
const De = /* @__PURE__ */ Re(Oe);
export {
  De as default
};
