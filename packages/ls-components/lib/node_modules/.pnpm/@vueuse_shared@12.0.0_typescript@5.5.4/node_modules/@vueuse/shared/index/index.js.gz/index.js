var y = Object.defineProperty;
var n = (e, t) => y(e, "name", { value: t, configurable: !0 });
import { getCurrentScope as b, onScopeDispose as S, unref as v, toRef as R, readonly as g, customRef as h, ref as a, isRef as j, watch as k } from "vue";
function l(e) {
  return b() ? (S(e), !0) : !1;
}
n(l, "tryOnScopeDispose");
function O(e) {
  return typeof e == "function" ? e() : v(e);
}
n(O, "toValue");
const s = typeof window < "u" && typeof document < "u", D = typeof WorkerGlobalScope < "u" && globalThis instanceof WorkerGlobalScope, W = Object.prototype.toString, G = /* @__PURE__ */ n((e) => W.call(e) === "[object Object]", "isObject"), w = /* @__PURE__ */ n(() => {
}, "noop");
function V(...e) {
  if (e.length !== 1)
    return R(...e);
  const t = e[0];
  return typeof t == "function" ? g(h(() => ({ get: t, set: w }))) : a(t);
}
n(V, "toRef");
function x(e, t = 1e3, p = {}) {
  const {
    immediate: d = !0,
    immediateCallback: m = !1
  } = p;
  let f = null;
  const o = a(!1);
  function u() {
    f && (clearInterval(f), f = null);
  }
  n(u, "clean");
  function r() {
    o.value = !1, u();
  }
  n(r, "pause");
  function c() {
    const i = O(t);
    i <= 0 || (o.value = !0, m && e(), u(), o.value && (f = setInterval(e, i)));
  }
  if (n(c, "resume"), d && s && c(), j(t) || typeof t == "function") {
    const i = k(t, () => {
      o.value && s && c();
    });
    l(i);
  }
  return l(r), {
    isActive: o,
    pause: r,
    resume: c
  };
}
n(x, "useIntervalFn");
export {
  s as isClient,
  G as isObject,
  D as isWorker,
  w as noop,
  V as toRef,
  O as toValue,
  l as tryOnScopeDispose,
  x as useIntervalFn
};
