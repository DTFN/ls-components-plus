var M = Object.defineProperty;
var a = (e, n) => M(e, "name", { value: n, configurable: !0 });
import { isString as V, noop as T, resolveUnref as I, tryOnScopeDispose as E, isIOS as B, tryOnMounted as D, identity as z, isClient as J, isFunction as U, isDef as G } from "../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
import { createFilterWrapper as me, debounceFilter as be, debouncedRef as _e, debouncedRef as ye, throttleFilter as ge, debouncedRef as Ie, useDebounceFn as he, useThrottleFn as we, useTimeoutFn as Ee } from "../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
import { watch as _, ref as P, computed as W, getCurrentInstance as H } from "vue";
function m(e) {
  var n;
  const r = I(e);
  return (n = r == null ? void 0 : r.$el) != null ? n : r;
}
a(m, "unrefElement");
const y = J ? window : void 0;
function w(...e) {
  let n, r, t, l;
  if (V(e[0]) || Array.isArray(e[0]) ? ([r, t, l] = e, n = y) : [n, r, t, l] = e, !n)
    return T;
  Array.isArray(r) || (r = [r]), Array.isArray(t) || (t = [t]);
  const f = [], s = /* @__PURE__ */ a(() => {
    f.forEach((c) => c()), f.length = 0;
  }, "cleanup"), i = /* @__PURE__ */ a((c, v, o, u) => (c.addEventListener(v, o, u), () => c.removeEventListener(v, o, u)), "register"), d = _(() => [m(n), I(l)], ([c, v]) => {
    s(), c && f.push(...r.flatMap((o) => t.map((u) => i(c, o, u, v))));
  }, { immediate: !0, flush: "post" }), O = /* @__PURE__ */ a(() => {
    d(), s();
  }, "stop");
  return E(O), O;
}
a(w, "useEventListener");
let N = !1;
function le(e, n, r = {}) {
  const { window: t = y, ignore: l = [], capture: f = !0, detectIframe: s = !1 } = r;
  if (!t)
    return;
  B && !N && (N = !0, Array.from(t.document.body.children).forEach((o) => o.addEventListener("click", T)));
  let i = !0;
  const d = /* @__PURE__ */ a((o) => l.some((u) => {
    if (typeof u == "string")
      return Array.from(t.document.querySelectorAll(u)).some((p) => p === o.target || o.composedPath().includes(p));
    {
      const p = m(u);
      return p && (o.target === p || o.composedPath().includes(p));
    }
  }), "shouldIgnore"), c = [
    w(t, "click", /* @__PURE__ */ a((o) => {
      const u = m(e);
      if (!(!u || u === o.target || o.composedPath().includes(u))) {
        if (o.detail === 0 && (i = !d(o)), !i) {
          i = !0;
          return;
        }
        n(o);
      }
    }, "listener"), { passive: !0, capture: f }),
    w(t, "pointerdown", (o) => {
      const u = m(e);
      u && (i = !o.composedPath().includes(u) && !d(o));
    }, { passive: !0 }),
    s && w(t, "blur", (o) => {
      var u;
      const p = m(e);
      ((u = t.document.activeElement) == null ? void 0 : u.tagName) === "IFRAME" && !(p != null && p.contains(t.document.activeElement)) && n(o);
    })
  ].filter(Boolean);
  return /* @__PURE__ */ a(() => c.forEach((o) => o()), "stop");
}
a(le, "onClickOutside");
function L(e, n = !1) {
  const r = P(), t = /* @__PURE__ */ a(() => r.value = !!e(), "update");
  return t(), D(t, n), r;
}
a(L, "useSupported");
function k(e) {
  return JSON.parse(JSON.stringify(e));
}
a(k, "cloneFnJSON");
const R = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, $ = "__vueuse_ssr_handlers__";
R[$] = R[$] || {};
function ce(e, n, { window: r = y, initialValue: t = "" } = {}) {
  const l = P(t), f = W(() => {
    var s;
    return m(n) || ((s = r == null ? void 0 : r.document) == null ? void 0 : s.documentElement);
  });
  return _([f, () => I(e)], ([s, i]) => {
    var d;
    if (s && r) {
      const O = (d = r.getComputedStyle(s).getPropertyValue(i)) == null ? void 0 : d.trim();
      l.value = O || t;
    }
  }, { immediate: !0 }), _(l, (s) => {
    var i;
    (i = f.value) != null && i.style && f.value.style.setProperty(I(e), s);
  }), l;
}
a(ce, "useCssVar");
var C = Object.getOwnPropertySymbols, q = Object.prototype.hasOwnProperty, K = Object.prototype.propertyIsEnumerable, X = /* @__PURE__ */ a((e, n) => {
  var r = {};
  for (var t in e)
    q.call(e, t) && n.indexOf(t) < 0 && (r[t] = e[t]);
  if (e != null && C)
    for (var t of C(e))
      n.indexOf(t) < 0 && K.call(e, t) && (r[t] = e[t]);
  return r;
}, "__objRest$2");
function fe(e, n, r = {}) {
  const t = r, { window: l = y } = t, f = X(t, ["window"]);
  let s;
  const i = L(() => l && "ResizeObserver" in l), d = /* @__PURE__ */ a(() => {
    s && (s.disconnect(), s = void 0);
  }, "cleanup"), O = _(() => m(e), (v) => {
    d(), i.value && l && v && (s = new ResizeObserver(n), s.observe(v, f));
  }, { immediate: !0, flush: "post" }), c = /* @__PURE__ */ a(() => {
    d(), O();
  }, "stop");
  return E(c), {
    isSupported: i,
    stop: c
  };
}
a(fe, "useResizeObserver");
var j = Object.getOwnPropertySymbols, Y = Object.prototype.hasOwnProperty, Z = Object.prototype.propertyIsEnumerable, ee = /* @__PURE__ */ a((e, n) => {
  var r = {};
  for (var t in e)
    Y.call(e, t) && n.indexOf(t) < 0 && (r[t] = e[t]);
  if (e != null && j)
    for (var t of j(e))
      n.indexOf(t) < 0 && Z.call(e, t) && (r[t] = e[t]);
  return r;
}, "__objRest$1");
function de(e, n, r = {}) {
  const t = r, { window: l = y } = t, f = ee(t, ["window"]);
  let s;
  const i = L(() => l && "MutationObserver" in l), d = /* @__PURE__ */ a(() => {
    s && (s.disconnect(), s = void 0);
  }, "cleanup"), O = _(() => m(e), (v) => {
    d(), i.value && l && v && (s = new MutationObserver(n), s.observe(v, f));
  }, { immediate: !0 }), c = /* @__PURE__ */ a(() => {
    d(), O();
  }, "stop");
  return E(c), {
    isSupported: i,
    stop: c
  };
}
a(de, "useMutationObserver");
var x;
(function(e) {
  e.UP = "UP", e.RIGHT = "RIGHT", e.DOWN = "DOWN", e.LEFT = "LEFT", e.NONE = "NONE";
})(x || (x = {}));
var te = Object.defineProperty, A = Object.getOwnPropertySymbols, ne = Object.prototype.hasOwnProperty, re = Object.prototype.propertyIsEnumerable, Q = /* @__PURE__ */ a((e, n, r) => n in e ? te(e, n, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[n] = r, "__defNormalProp"), oe = /* @__PURE__ */ a((e, n) => {
  for (var r in n || (n = {}))
    ne.call(n, r) && Q(e, r, n[r]);
  if (A)
    for (var r of A(n))
      re.call(n, r) && Q(e, r, n[r]);
  return e;
}, "__spreadValues");
const se = {
  easeInSine: [0.12, 0, 0.39, 0],
  easeOutSine: [0.61, 1, 0.88, 1],
  easeInOutSine: [0.37, 0, 0.63, 1],
  easeInQuad: [0.11, 0, 0.5, 0],
  easeOutQuad: [0.5, 1, 0.89, 1],
  easeInOutQuad: [0.45, 0, 0.55, 1],
  easeInCubic: [0.32, 0, 0.67, 0],
  easeOutCubic: [0.33, 1, 0.68, 1],
  easeInOutCubic: [0.65, 0, 0.35, 1],
  easeInQuart: [0.5, 0, 0.75, 0],
  easeOutQuart: [0.25, 1, 0.5, 1],
  easeInOutQuart: [0.76, 0, 0.24, 1],
  easeInQuint: [0.64, 0, 0.78, 0],
  easeOutQuint: [0.22, 1, 0.36, 1],
  easeInOutQuint: [0.83, 0, 0.17, 1],
  easeInExpo: [0.7, 0, 0.84, 0],
  easeOutExpo: [0.16, 1, 0.3, 1],
  easeInOutExpo: [0.87, 0, 0.13, 1],
  easeInCirc: [0.55, 0, 1, 0.45],
  easeOutCirc: [0, 0.55, 0.45, 1],
  easeInOutCirc: [0.85, 0, 0.15, 1],
  easeInBack: [0.36, 0, 0.66, -0.56],
  easeOutBack: [0.34, 1.56, 0.64, 1],
  easeInOutBack: [0.68, -0.6, 0.32, 1.6]
};
oe({
  linear: z
}, se);
function pe(e, n, r, t = {}) {
  var l, f, s;
  const {
    clone: i = !1,
    passive: d = !1,
    eventName: O,
    deep: c = !1,
    defaultValue: v
  } = t, o = H(), u = (o == null ? void 0 : o.emit) || ((l = o == null ? void 0 : o.$emit) == null ? void 0 : l.bind(o)) || ((s = (f = o == null ? void 0 : o.proxy) == null ? void 0 : f.$emit) == null ? void 0 : s.bind(o == null ? void 0 : o.proxy));
  let p = O;
  p = O || p || `update:${n.toString()}`;
  const S = /* @__PURE__ */ a((b) => i ? U(i) ? i(b) : k(b) : b, "cloneFn"), F = /* @__PURE__ */ a(() => G(e[n]) ? S(e[n]) : v, "getValue");
  if (d) {
    const b = F(), h = P(b);
    return _(() => e[n], (g) => h.value = S(g)), _(h, (g) => {
      (g !== e[n] || c) && u(p, g);
    }, { deep: c }), h;
  } else
    return W({
      get() {
        return F();
      },
      set(b) {
        u(p, b);
      }
    });
}
a(pe, "useVModel");
export {
  x as SwipeDirection,
  k as cloneFnJSON,
  me as createFilterWrapper,
  be as debounceFilter,
  _e as debouncedRef,
  y as defaultWindow,
  z as identity,
  J as isClient,
  G as isDef,
  U as isFunction,
  B as isIOS,
  V as isString,
  T as noop,
  le as onClickOutside,
  ye as refDebounced,
  I as resolveUnref,
  ge as throttleFilter,
  D as tryOnMounted,
  E as tryOnScopeDispose,
  m as unrefElement,
  ce as useCssVar,
  Ie as useDebounce,
  he as useDebounceFn,
  w as useEventListener,
  de as useMutationObserver,
  fe as useResizeObserver,
  L as useSupported,
  we as useThrottleFn,
  Ee as useTimeoutFn,
  pe as useVModel
};
