var F = Object.defineProperty;
var t = (e, i) => F(e, "name", { value: i, configurable: !0 });
import { unref as b, getCurrentScope as S, onScopeDispose as C, ref as h, watch as O, getCurrentInstance as j, onMounted as A, nextTick as M, readonly as R } from "vue";
var g;
const y = typeof window < "u", V = /* @__PURE__ */ t((e) => typeof e < "u", "isDef"), k = /* @__PURE__ */ t((e) => typeof e == "function", "isFunction"), q = /* @__PURE__ */ t((e) => typeof e == "string", "isString"), m = /* @__PURE__ */ t(() => {
}, "noop"), z = y && ((g = window == null ? void 0 : window.navigator) == null ? void 0 : g.userAgent) && /iP(ad|hone|od)/.test(window.navigator.userAgent);
function p(e) {
  return typeof e == "function" ? e() : b(e);
}
t(p, "resolveUnref");
function P(e, i) {
  function u(...n) {
    return new Promise((r, o) => {
      Promise.resolve(e(() => i.apply(this, n), { fn: i, thisArg: this, args: n })).then(r).catch(o);
    });
  }
  return t(u, "wrapper"), u;
}
t(P, "createFilterWrapper");
function I(e, i = {}) {
  let u, n, r = m;
  const o = /* @__PURE__ */ t((s) => {
    clearTimeout(s), r(), r = m;
  }, "_clearTimeout");
  return /* @__PURE__ */ t((s) => {
    const l = p(e), c = p(i.maxWait);
    return u && o(u), l <= 0 || c !== void 0 && c <= 0 ? (n && (o(n), n = null), Promise.resolve(s())) : new Promise((f, w) => {
      r = i.rejectOnCancel ? w : f, c && !n && (n = setTimeout(() => {
        u && o(u), n = null, f(s());
      }, c)), u = setTimeout(() => {
        n && o(n), n = null, f(s());
      }, l);
    });
  }, "filter");
}
t(I, "debounceFilter");
function W(e, i = !0, u = !0, n = !1) {
  let r = 0, o, a = !0, s = m, l;
  const c = /* @__PURE__ */ t(() => {
    o && (clearTimeout(o), o = void 0, s(), s = m);
  }, "clear");
  return /* @__PURE__ */ t((w) => {
    const d = p(e), v = Date.now() - r, T = /* @__PURE__ */ t(() => l = w(), "invoke");
    return c(), d <= 0 ? (r = Date.now(), T()) : (v > d && (u || !a) ? (r = Date.now(), T()) : i && (l = new Promise((D, x) => {
      s = n ? x : D, o = setTimeout(() => {
        r = Date.now(), a = !0, D(T()), c();
      }, Math.max(0, d - v));
    })), !u && !o && (o = setTimeout(() => a = !0, d)), a = !1, l);
  }, "filter");
}
t(W, "throttleFilter");
function B(e) {
  return e;
}
t(B, "identity");
function _(e) {
  return S() ? (C(e), !0) : !1;
}
t(_, "tryOnScopeDispose");
function E(e, i = 200, u = {}) {
  return P(I(i, u), e);
}
t(E, "useDebounceFn");
function G(e, i = 200, u = {}) {
  const n = h(e.value), r = E(() => {
    n.value = e.value;
  }, i, u);
  return O(e, () => r()), n;
}
t(G, "refDebounced");
function H(e, i = 200, u = !1, n = !0, r = !1) {
  return P(W(i, u, n, r), e);
}
t(H, "useThrottleFn");
function J(e, i = !0) {
  j() ? A(e) : i ? e() : M(e);
}
t(J, "tryOnMounted");
function K(e, i, u = {}) {
  const {
    immediate: n = !0
  } = u, r = h(!1);
  let o = null;
  function a() {
    o && (clearTimeout(o), o = null);
  }
  t(a, "clear");
  function s() {
    r.value = !1, a();
  }
  t(s, "stop");
  function l(...c) {
    a(), r.value = !0, o = setTimeout(() => {
      r.value = !1, o = null, e(...c);
    }, p(i));
  }
  return t(l, "start"), n && (r.value = !0, y && l()), _(s), {
    isPending: R(r),
    start: l,
    stop: s
  };
}
t(K, "useTimeoutFn");
export {
  P as createFilterWrapper,
  I as debounceFilter,
  G as debouncedRef,
  B as identity,
  y as isClient,
  V as isDef,
  k as isFunction,
  z as isIOS,
  q as isString,
  m as noop,
  G as refDebounced,
  p as resolveUnref,
  W as throttleFilter,
  J as tryOnMounted,
  _ as tryOnScopeDispose,
  G as useDebounce,
  E as useDebounceFn,
  H as useThrottleFn,
  K as useTimeoutFn
};
