var L = Object.defineProperty;
var h = (f, u) => L(f, "name", { value: u, configurable: !0 });
if (!q) var q = { map: /* @__PURE__ */ h(function(f, u) {
  var m = {};
  return u ? f.map(function(g, b) {
    return m.index = b, u.call(m, g);
  }) : f.slice();
}, "map"), naturalOrder: /* @__PURE__ */ h(function(f, u) {
  return f < u ? -1 : f > u ? 1 : 0;
}, "naturalOrder"), sum: /* @__PURE__ */ h(function(f, u) {
  var m = {};
  return f.reduce(u ? function(g, b, d) {
    return m.index = d, g + u.call(m, b);
  } : function(g, b) {
    return g + b;
  }, 0);
}, "sum"), max: /* @__PURE__ */ h(function(f, u) {
  return Math.max.apply(null, u ? q.map(f, u) : f);
}, "max") };
var T = function() {
  var f = 5, u = 8 - f, m = 1e3;
  function g(r, t, n) {
    return (r << 2 * f) + (t << f) + n;
  }
  h(g, "e");
  function b(r) {
    var t = [], n = !1;
    function s() {
      t.sort(r), n = !0;
    }
    return h(s, "o"), { push: /* @__PURE__ */ h(function(e) {
      t.push(e), n = !1;
    }, "push"), peek: /* @__PURE__ */ h(function(e) {
      return n || s(), e === void 0 && (e = t.length - 1), t[e];
    }, "peek"), pop: /* @__PURE__ */ h(function() {
      return n || s(), t.pop();
    }, "pop"), size: /* @__PURE__ */ h(function() {
      return t.length;
    }, "size"), map: /* @__PURE__ */ h(function(e) {
      return t.map(e);
    }, "map"), debug: /* @__PURE__ */ h(function() {
      return n || s(), t;
    }, "debug") };
  }
  h(b, "u");
  function d(r, t, n, s, e, o, l) {
    var a = this;
    a.r1 = r, a.r2 = t, a.g1 = n, a.g2 = s, a.b1 = e, a.b2 = o, a.histo = l;
  }
  h(d, "a");
  function E() {
    this.vboxes = new b(function(r, t) {
      return q.naturalOrder(r.vbox.count() * r.vbox.volume(), t.vbox.count() * t.vbox.volume());
    });
  }
  h(E, "i");
  function I(r, t) {
    if (t.count()) {
      var n = t.r2 - t.r1 + 1, s = t.g2 - t.g1 + 1, e = q.max([n, s, t.b2 - t.b1 + 1]);
      if (t.count() == 1) return [t.copy()];
      var o, l, a, c, v = 0, p = [], w = [];
      if (e == n) for (o = t.r1; o <= t.r2; o++) {
        for (c = 0, l = t.g1; l <= t.g2; l++) for (a = t.b1; a <= t.b2; a++) c += r[g(o, l, a)] || 0;
        p[o] = v += c;
      }
      else if (e == s) for (o = t.g1; o <= t.g2; o++) {
        for (c = 0, l = t.r1; l <= t.r2; l++) for (a = t.b1; a <= t.b2; a++) c += r[g(l, o, a)] || 0;
        p[o] = v += c;
      }
      else for (o = t.b1; o <= t.b2; o++) {
        for (c = 0, l = t.r1; l <= t.r2; l++) for (a = t.g1; a <= t.g2; a++) c += r[g(l, a, o)] || 0;
        p[o] = v += c;
      }
      return p.forEach(function(x, y) {
        w[y] = v - x;
      }), function(x) {
        var y, z, C, D, _, k = x + "1", M = x + "2", P = 0;
        for (o = t[k]; o <= t[M]; o++) if (p[o] > v / 2) {
          for (C = t.copy(), D = t.copy(), _ = (y = o - t[k]) <= (z = t[M] - o) ? Math.min(t[M] - 1, ~~(o + z / 2)) : Math.max(t[k], ~~(o - 1 - y / 2)); !p[_]; ) _++;
          for (P = w[_]; !P && p[_ - 1]; ) P = w[--_];
          return C[M] = _, D[k] = C[M] + 1, [C, D];
        }
      }(e == n ? "r" : e == s ? "g" : "b");
    }
  }
  return h(I, "c"), d.prototype = { volume: /* @__PURE__ */ h(function(r) {
    var t = this;
    return t._volume && !r || (t._volume = (t.r2 - t.r1 + 1) * (t.g2 - t.g1 + 1) * (t.b2 - t.b1 + 1)), t._volume;
  }, "volume"), count: /* @__PURE__ */ h(function(r) {
    var t = this, n = t.histo;
    if (!t._count_set || r) {
      var s, e, o, l = 0;
      for (s = t.r1; s <= t.r2; s++) for (e = t.g1; e <= t.g2; e++) for (o = t.b1; o <= t.b2; o++) l += n[g(s, e, o)] || 0;
      t._count = l, t._count_set = !0;
    }
    return t._count;
  }, "count"), copy: /* @__PURE__ */ h(function() {
    var r = this;
    return new d(r.r1, r.r2, r.g1, r.g2, r.b1, r.b2, r.histo);
  }, "copy"), avg: /* @__PURE__ */ h(function(r) {
    var t = this, n = t.histo;
    if (!t._avg || r) {
      var s, e, o, l, a = 0, c = 1 << 8 - f, v = 0, p = 0, w = 0;
      for (e = t.r1; e <= t.r2; e++) for (o = t.g1; o <= t.g2; o++) for (l = t.b1; l <= t.b2; l++) a += s = n[g(e, o, l)] || 0, v += s * (e + 0.5) * c, p += s * (o + 0.5) * c, w += s * (l + 0.5) * c;
      t._avg = a ? [~~(v / a), ~~(p / a), ~~(w / a)] : [~~(c * (t.r1 + t.r2 + 1) / 2), ~~(c * (t.g1 + t.g2 + 1) / 2), ~~(c * (t.b1 + t.b2 + 1) / 2)];
    }
    return t._avg;
  }, "avg"), contains: /* @__PURE__ */ h(function(r) {
    var t = this, n = r[0] >> u;
    return gval = r[1] >> u, bval = r[2] >> u, n >= t.r1 && n <= t.r2 && gval >= t.g1 && gval <= t.g2 && bval >= t.b1 && bval <= t.b2;
  }, "contains") }, E.prototype = { push: /* @__PURE__ */ h(function(r) {
    this.vboxes.push({ vbox: r, color: r.avg() });
  }, "push"), palette: /* @__PURE__ */ h(function() {
    return this.vboxes.map(function(r) {
      return r.color;
    });
  }, "palette"), size: /* @__PURE__ */ h(function() {
    return this.vboxes.size();
  }, "size"), map: /* @__PURE__ */ h(function(r) {
    for (var t = this.vboxes, n = 0; n < t.size(); n++) if (t.peek(n).vbox.contains(r)) return t.peek(n).color;
    return this.nearest(r);
  }, "map"), nearest: /* @__PURE__ */ h(function(r) {
    for (var t, n, s, e = this.vboxes, o = 0; o < e.size(); o++) ((n = Math.sqrt(Math.pow(r[0] - e.peek(o).color[0], 2) + Math.pow(r[1] - e.peek(o).color[1], 2) + Math.pow(r[2] - e.peek(o).color[2], 2))) < t || t === void 0) && (t = n, s = e.peek(o).color);
    return s;
  }, "nearest"), forcebw: /* @__PURE__ */ h(function() {
    var r = this.vboxes;
    r.sort(function(e, o) {
      return q.naturalOrder(q.sum(e.color), q.sum(o.color));
    });
    var t = r[0].color;
    t[0] < 5 && t[1] < 5 && t[2] < 5 && (r[0].color = [0, 0, 0]);
    var n = r.length - 1, s = r[n].color;
    s[0] > 251 && s[1] > 251 && s[2] > 251 && (r[n].color = [255, 255, 255]);
  }, "forcebw") }, { quantize: /* @__PURE__ */ h(function(r, t) {
    if (!r.length || t < 2 || t > 256) return !1;
    var n = function(c) {
      var v, p = new Array(1 << 3 * f);
      return c.forEach(function(w) {
        v = g(w[0] >> u, w[1] >> u, w[2] >> u), p[v] = (p[v] || 0) + 1;
      }), p;
    }(r);
    n.forEach(function() {
    });
    var s = function(c, v) {
      var p, w, x, y = 1e6, z = 0, C = 1e6, D = 0, _ = 1e6, k = 0;
      return c.forEach(function(M) {
        (p = M[0] >> u) < y ? y = p : p > z && (z = p), (w = M[1] >> u) < C ? C = w : w > D && (D = w), (x = M[2] >> u) < _ ? _ = x : x > k && (k = x);
      }), new d(y, z, C, D, _, k, v);
    }(r, n), e = new b(function(c, v) {
      return q.naturalOrder(c.count(), v.count());
    });
    function o(c, v) {
      for (var p, w = c.size(), x = 0; x < m; ) {
        if (w >= v || x++ > m) return;
        if ((p = c.pop()).count()) {
          var y = I(n, p), z = y[0], C = y[1];
          if (!z) return;
          c.push(z), C && (c.push(C), w++);
        } else c.push(p), x++;
      }
    }
    h(o, "g"), e.push(s), o(e, 0.75 * t);
    for (var l = new b(function(c, v) {
      return q.naturalOrder(c.count() * c.volume(), v.count() * v.volume());
    }); e.size(); ) l.push(e.pop());
    o(l, t);
    for (var a = new E(); l.size(); ) a.push(l.pop());
    return a;
  }, "quantize") };
}().quantize, A = /* @__PURE__ */ h(function(f) {
  this.canvas = document.createElement("canvas"), this.context = this.canvas.getContext("2d"), this.width = this.canvas.width = f.naturalWidth, this.height = this.canvas.height = f.naturalHeight, this.context.drawImage(f, 0, 0, this.width, this.height);
}, "n");
A.prototype.getImageData = function() {
  return this.context.getImageData(0, 0, this.width, this.height);
};
var O = /* @__PURE__ */ h(function() {
}, "o");
O.prototype.getColor = function(f, u) {
  return u === void 0 && (u = 10), this.getPalette(f, 5, u)[0];
}, O.prototype.getPalette = function(f, u, m) {
  var g = function(I) {
    var r = I.colorCount, t = I.quality;
    if (r !== void 0 && Number.isInteger(r)) {
      if (r === 1) throw new Error("colorCount should be between 2 and 20. To get one color, call getColor() instead of getPalette()");
      r = Math.max(r, 2), r = Math.min(r, 20);
    } else r = 10;
    return (t === void 0 || !Number.isInteger(t) || t < 1) && (t = 10), { colorCount: r, quality: t };
  }({ colorCount: u, quality: m }), b = new A(f), d = function(I, r, t) {
    for (var n, s, e, o, l, a = I, c = [], v = 0; v < r; v += t) s = a[0 + (n = 4 * v)], e = a[n + 1], o = a[n + 2], ((l = a[n + 3]) === void 0 || l >= 125) && (s > 250 && e > 250 && o > 250 || c.push([s, e, o]));
    return c;
  }(b.getImageData().data, b.width * b.height, g.quality), E = T(d, g.colorCount);
  return E ? E.palette() : null;
}, O.prototype.getColorFromUrl = function(f, u, m) {
  var g = this, b = document.createElement("img");
  b.addEventListener("load", function() {
    var d = g.getPalette(b, 5, m);
    u(d[0], f);
  }), b.src = f;
}, O.prototype.getImageData = function(f, u) {
  var m = new XMLHttpRequest();
  m.open("GET", f, !0), m.responseType = "arraybuffer", m.onload = function() {
    if (this.status == 200) {
      var g = new Uint8Array(this.response);
      i = g.length;
      for (var b = new Array(i), d = 0; d < g.length; d++) b[d] = String.fromCharCode(g[d]);
      var E = b.join(""), I = window.btoa(E);
      u("data:image/png;base64," + I);
    }
  }, m.send();
}, O.prototype.getColorAsync = function(f, u, m) {
  var g = this;
  this.getImageData(f, function(b) {
    var d = document.createElement("img");
    d.addEventListener("load", function() {
      var E = g.getPalette(d, 5, m);
      u(E[0], this);
    }), d.src = b;
  });
};
export {
  O as default
};
