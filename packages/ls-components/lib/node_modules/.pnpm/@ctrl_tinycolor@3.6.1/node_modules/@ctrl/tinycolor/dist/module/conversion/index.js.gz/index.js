var M = Object.defineProperty;
var h = (t, a) => M(t, "name", { value: a, configurable: !0 });
import { bound01 as u, pad2 as s } from "../util/index.js";
function H(t, a, r) {
  return {
    r: u(t, 255) * 255,
    g: u(a, 255) * 255,
    b: u(r, 255) * 255
  };
}
h(H, "rgbToRgb");
function S(t, a, r) {
  t = u(t, 255), a = u(a, 255), r = u(r, 255);
  var i = Math.max(t, a, r), e = Math.min(t, a, r), n = 0, c = 0, o = (i + e) / 2;
  if (i === e)
    c = 0, n = 0;
  else {
    var f = i - e;
    switch (c = o > 0.5 ? f / (2 - i - e) : f / (i + e), i) {
      case t:
        n = (a - r) / f + (a < r ? 6 : 0);
        break;
      case a:
        n = (r - t) / f + 2;
        break;
      case r:
        n = (t - a) / f + 4;
        break;
    }
    n /= 6;
  }
  return { h: n, s: c, l: o };
}
h(S, "rgbToHsl");
function v(t, a, r) {
  return r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? t + (a - t) * (6 * r) : r < 1 / 2 ? a : r < 2 / 3 ? t + (a - t) * (2 / 3 - r) * 6 : t;
}
h(v, "hue2rgb");
function W(t, a, r) {
  var i, e, n;
  if (t = u(t, 360), a = u(a, 100), r = u(r, 100), a === 0)
    e = r, n = r, i = r;
  else {
    var c = r < 0.5 ? r * (1 + a) : r + a - r * a, o = 2 * r - c;
    i = v(o, c, t + 1 / 3), e = v(o, c, t), n = v(o, c, t - 1 / 3);
  }
  return { r: i * 255, g: e * 255, b: n * 255 };
}
h(W, "hslToRgb");
function k(t, a, r) {
  t = u(t, 255), a = u(a, 255), r = u(r, 255);
  var i = Math.max(t, a, r), e = Math.min(t, a, r), n = 0, c = i, o = i - e, f = i === 0 ? 0 : o / i;
  if (i === e)
    n = 0;
  else {
    switch (i) {
      case t:
        n = (a - r) / o + (a < r ? 6 : 0);
        break;
      case a:
        n = (r - t) / o + 2;
        break;
      case r:
        n = (t - a) / o + 4;
        break;
    }
    n /= 6;
  }
  return { h: n, s: f, v: c };
}
h(k, "rgbToHsv");
function j(t, a, r) {
  t = u(t, 360) * 6, a = u(a, 100), r = u(r, 100);
  var i = Math.floor(t), e = t - i, n = r * (1 - a), c = r * (1 - e * a), o = r * (1 - (1 - e) * a), f = i % 6, m = [r, c, n, n, o, r][f], x = [o, r, r, c, n, n][f], A = [n, n, o, r, r, c][f];
  return { r: m * 255, g: x * 255, b: A * 255 };
}
h(j, "hsvToRgb");
function I(t, a, r, i) {
  var e = [
    s(Math.round(t).toString(16)),
    s(Math.round(a).toString(16)),
    s(Math.round(r).toString(16))
  ];
  return i && e[0].startsWith(e[0].charAt(1)) && e[1].startsWith(e[1].charAt(1)) && e[2].startsWith(e[2].charAt(1)) ? e[0].charAt(0) + e[1].charAt(0) + e[2].charAt(0) : e.join("");
}
h(I, "rgbToHex");
function R(t, a, r, i, e) {
  var n = [
    s(Math.round(t).toString(16)),
    s(Math.round(a).toString(16)),
    s(Math.round(r).toString(16)),
    s(b(i))
  ];
  return e && n[0].startsWith(n[0].charAt(1)) && n[1].startsWith(n[1].charAt(1)) && n[2].startsWith(n[2].charAt(1)) && n[3].startsWith(n[3].charAt(1)) ? n[0].charAt(0) + n[1].charAt(0) + n[2].charAt(0) + n[3].charAt(0) : n.join("");
}
h(R, "rgbaToHex");
function b(t) {
  return Math.round(parseFloat(t) * 255).toString(16);
}
h(b, "convertDecimalToHex");
function p(t) {
  return T(t) / 255;
}
h(p, "convertHexToDecimal");
function T(t) {
  return parseInt(t, 16);
}
h(T, "parseIntFromHex");
function w(t) {
  return {
    r: t >> 16,
    g: (t & 65280) >> 8,
    b: t & 255
  };
}
h(w, "numberInputToObject");
export {
  b as convertDecimalToHex,
  p as convertHexToDecimal,
  W as hslToRgb,
  j as hsvToRgb,
  w as numberInputToObject,
  T as parseIntFromHex,
  I as rgbToHex,
  S as rgbToHsl,
  k as rgbToHsv,
  H as rgbToRgb,
  R as rgbaToHex
};
