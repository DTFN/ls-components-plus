var n = Object.defineProperty;
var e = (t, r) => n(t, "name", { value: r, configurable: !0 });
function s(t, r) {
  o(t) && (t = "100%");
  var i = u(t);
  return t = r === 360 ? t : Math.min(r, Math.max(0, parseFloat(t))), i && (t = parseInt(String(t * r), 10) / 100), Math.abs(t - r) < 1e-6 ? 1 : (r === 360 ? t = (t < 0 ? t % r + r : t % r) / parseFloat(String(r)) : t = t % r / parseFloat(String(r)), t);
}
e(s, "bound01");
function c(t) {
  return Math.min(1, Math.max(0, t));
}
e(c, "clamp01");
function o(t) {
  return typeof t == "string" && t.indexOf(".") !== -1 && parseFloat(t) === 1;
}
e(o, "isOnePointZero");
function u(t) {
  return typeof t == "string" && t.indexOf("%") !== -1;
}
e(u, "isPercentage");
function p(t) {
  return t = parseFloat(t), (isNaN(t) || t < 0 || t > 1) && (t = 1), t;
}
e(p, "boundAlpha");
function a(t) {
  return t <= 1 ? "".concat(Number(t) * 100, "%") : t;
}
e(a, "convertToPercentage");
function g(t) {
  return t.length === 1 ? "0" + t : String(t);
}
e(g, "pad2");
export {
  s as bound01,
  p as boundAlpha,
  c as clamp01,
  a as convertToPercentage,
  o as isOnePointZero,
  u as isPercentage,
  g as pad2
};
