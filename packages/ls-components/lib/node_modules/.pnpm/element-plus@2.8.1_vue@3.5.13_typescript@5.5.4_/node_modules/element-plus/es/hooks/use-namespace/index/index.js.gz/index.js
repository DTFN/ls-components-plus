var N = Object.defineProperty;
var a = (n, r) => N(n, "name", { value: r, configurable: !0 });
import { getCurrentInstance as V, inject as y, ref as p, computed as l, unref as B } from "vue";
const v = "el", C = "is-", u = /* @__PURE__ */ a((n, r, t, $, m) => {
  let o = `${n}-${r}`;
  return t && (o += `-${t}`), $ && (o += `__${$}`), m && (o += `--${m}`), o;
}, "_bem"), _ = Symbol("namespaceContextKey"), K = /* @__PURE__ */ a((n) => {
  const r = n || (V() ? y(_, p(v)) : p(v));
  return l(() => B(r) || v);
}, "useGetDerivedNamespace"), z = /* @__PURE__ */ a((n, r) => {
  const t = K(r);
  return {
    namespace: t,
    b: /* @__PURE__ */ a((s = "") => u(t.value, n, s, "", ""), "b"),
    e: /* @__PURE__ */ a((s) => s ? u(t.value, n, "", s, "") : "", "e"),
    m: /* @__PURE__ */ a((s) => s ? u(t.value, n, "", "", s) : "", "m"),
    be: /* @__PURE__ */ a((s, e) => s && e ? u(t.value, n, s, e, "") : "", "be"),
    em: /* @__PURE__ */ a((s, e) => s && e ? u(t.value, n, "", s, e) : "", "em"),
    bm: /* @__PURE__ */ a((s, e) => s && e ? u(t.value, n, s, "", e) : "", "bm"),
    bem: /* @__PURE__ */ a((s, e, c) => s && e && c ? u(t.value, n, s, e, c) : "", "bem"),
    is: /* @__PURE__ */ a((s, ...e) => {
      const c = e.length >= 1 ? e[0] : !0;
      return s && c ? `${C}${s}` : "";
    }, "is"),
    cssVar: /* @__PURE__ */ a((s) => {
      const e = {};
      for (const c in s)
        s[c] && (e[`--${t.value}-${c}`] = s[c]);
      return e;
    }, "cssVar"),
    cssVarName: /* @__PURE__ */ a((s) => `--${t.value}-${s}`, "cssVarName"),
    cssVarBlock: /* @__PURE__ */ a((s) => {
      const e = {};
      for (const c in s)
        s[c] && (e[`--${t.value}-${n}-${c}`] = s[c]);
      return e;
    }, "cssVarBlock"),
    cssVarBlockName: /* @__PURE__ */ a((s) => `--${t.value}-${n}-${s}`, "cssVarBlockName")
  };
}, "useNamespace");
export {
  v as defaultNamespace,
  _ as namespaceContextKey,
  K as useGetDerivedNamespace,
  z as useNamespace
};
