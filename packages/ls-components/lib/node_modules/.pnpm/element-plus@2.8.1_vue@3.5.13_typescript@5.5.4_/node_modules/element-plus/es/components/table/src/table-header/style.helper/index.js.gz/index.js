var C = Object.defineProperty;
var i = (n, t) => C(n, "name", { value: t, configurable: !0 });
import { inject as c } from "vue";
import { getFixedColumnOffset as h, ensurePosition as p, getFixedColumnsClass as y } from "../../util/index.js";
import { TABLE_INJECTION_KEY as g } from "../../tokens/index.js";
import { useNamespace as S } from "../../../../../hooks/use-namespace/index/index.js";
function E(n) {
  const t = c(g), d = S("table");
  return {
    getHeaderRowStyle: /* @__PURE__ */ i((o) => {
      const e = t == null ? void 0 : t.props.headerRowStyle;
      return typeof e == "function" ? e.call(null, { rowIndex: o }) : e;
    }, "getHeaderRowStyle"),
    getHeaderRowClass: /* @__PURE__ */ i((o) => {
      const e = [], a = t == null ? void 0 : t.props.headerRowClassName;
      return typeof a == "string" ? e.push(a) : typeof a == "function" && e.push(a.call(null, { rowIndex: o })), e.join(" ");
    }, "getHeaderRowClass"),
    getHeaderCellStyle: /* @__PURE__ */ i((o, e, a, s) => {
      var f;
      let l = (f = t == null ? void 0 : t.props.headerCellStyle) != null ? f : {};
      typeof l == "function" && (l = l.call(null, {
        rowIndex: o,
        columnIndex: e,
        row: a,
        column: s
      }));
      const r = h(e, s.fixed, n.store, a);
      return p(r, "left"), p(r, "right"), Object.assign({}, l, r);
    }, "getHeaderCellStyle"),
    getHeaderCellClass: /* @__PURE__ */ i((o, e, a, s) => {
      const f = y(d.b(), e, s.fixed, n.store, a), l = [
        s.id,
        s.order,
        s.headerAlign,
        s.className,
        s.labelClassName,
        ...f
      ];
      s.children || l.push("is-leaf"), s.sortable && l.push("is-sortable");
      const r = t == null ? void 0 : t.props.headerCellClassName;
      return typeof r == "string" ? l.push(r) : typeof r == "function" && l.push(r.call(null, {
        rowIndex: o,
        columnIndex: e,
        row: a,
        column: s
      })), l.push(d.e("cell")), l.filter((u) => !!u).join(" ");
    }, "getHeaderCellClass")
  };
}
i(E, "useStyle");
export {
  E as default
};
