var oe = Object.defineProperty;
var s = (r, p) => oe(r, "name", { value: p, configurable: !0 });
import { defineComponent as ne, ref as C, computed as P, provide as le, reactive as z, watch as $, onBeforeUpdate as te, onMounted as ae, nextTick as re, resolveComponent as se, openBlock as D, createElementBlock as F, normalizeClass as ce, Fragment as ue, renderList as de, createBlock as ie } from "vue";
import fe from "../menu/index.js";
import K from "../store/index.js";
import ve from "../node/index.js";
import { CommonProps as me, useCascaderConfig as pe } from "../config/index.js";
import { sortByOriginalOrder as he, checkNode as Ne, getMenuIndex as I } from "../utils/index.js";
import { CASCADER_PANEL_INJECTION_KEY as ge } from "../types/index.js";
import Ee from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { UPDATE_MODEL_EVENT as H, CHANGE_EVENT as U } from "../../../../constants/event/index.js";
import { useNamespace as ke } from "../../../../hooks/use-namespace/index/index.js";
import { isEmpty as G } from "../../../../utils/types/index.js";
import { unique as J, castArray as R } from "../../../../utils/arrays/index.js";
import { scrollIntoView as ye } from "../../../../utils/dom/scroll/index.js";
import { EVENT_CODE as _ } from "../../../../constants/aria/index.js";
import { focusNode as L, getSibling as Ce } from "../../../../utils/dom/aria/index.js";
import Y from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isEqual/index.js";
import _e from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/flattenDeep/index.js";
import be from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/cloneDeep/index.js";
import { isClient as we } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const xe = ne({
  name: "ElCascaderPanel",
  components: {
    ElCascaderMenu: fe
  },
  props: {
    ...me,
    border: {
      type: Boolean,
      default: !0
    },
    renderLabel: Function
  },
  emits: [H, U, "close", "expand-change"],
  setup(r, { emit: p, slots: B }) {
    let b = !1;
    const i = ke("cascader"), d = pe(r);
    let c = null;
    const g = C(!0), f = C([]), E = C(null), N = C([]), k = C(null), h = C([]), j = P(() => d.value.expandTrigger === "hover"), Q = P(() => r.renderLabel || B.default), W = /* @__PURE__ */ s(() => {
      const { options: e } = r, o = d.value;
      b = !1, c = new K(e, o), N.value = [c.getNodes()], o.lazy && G(r.options) ? (g.value = !1, x(void 0, (n) => {
        n && (c = new K(n, o), N.value = [c.getNodes()]), g.value = !0, y(!1, !0);
      })) : y(!1, !0);
    }, "initStore"), x = /* @__PURE__ */ s((e, o) => {
      const n = d.value;
      e = e || new ve({}, n, void 0, !0), e.loading = !0;
      const l = /* @__PURE__ */ s((t) => {
        const a = e, v = a.root ? null : a;
        t && (c == null || c.appendNodes(t, v)), a.loading = !1, a.loaded = !0, a.childrenData = a.childrenData || [], o && o(t);
      }, "resolve");
      n.lazyLoad(e, l);
    }, "lazyLoad"), S = /* @__PURE__ */ s((e, o) => {
      var n;
      const { level: l } = e, t = N.value.slice(0, l);
      let a;
      e.isLeaf ? a = e.pathNodes[l - 2] : (a = e, t.push(e.children)), ((n = k.value) == null ? void 0 : n.uid) !== (a == null ? void 0 : a.uid) && (k.value = e, N.value = t, !o && p("expand-change", (e == null ? void 0 : e.pathValues) || []));
    }, "expandNode"), M = /* @__PURE__ */ s((e, o, n = !0) => {
      const { checkStrictly: l, multiple: t } = d.value, a = h.value[0];
      b = !0, !t && (a == null || a.doCheck(!1)), e.doCheck(o), V(), n && !t && !l && p("close"), !n && !t && !l && T(e);
    }, "handleCheckChange"), T = /* @__PURE__ */ s((e) => {
      e && (e = e.parent, T(e), e && S(e));
    }, "expandParentNode"), q = /* @__PURE__ */ s((e) => c == null ? void 0 : c.getFlattedNodes(e), "getFlattedNodes"), O = /* @__PURE__ */ s((e) => {
      var o;
      return (o = q(e)) == null ? void 0 : o.filter((n) => n.checked !== !1);
    }, "getCheckedNodes"), X = /* @__PURE__ */ s(() => {
      h.value.forEach((e) => e.doCheck(!1)), V(), N.value = N.value.slice(0, 1), k.value = null, p("expand-change", []);
    }, "clearCheckedNodes"), V = /* @__PURE__ */ s(() => {
      var e;
      const { checkStrictly: o, multiple: n } = d.value, l = h.value, t = O(!o), a = he(l, t), v = a.map((u) => u.valueByOption);
      h.value = a, E.value = n ? v : (e = v[0]) != null ? e : null;
    }, "calculateCheckedValue"), y = /* @__PURE__ */ s((e = !1, o = !1) => {
      const { modelValue: n } = r, { lazy: l, multiple: t, checkStrictly: a } = d.value, v = !a;
      if (!(!g.value || b || !o && Y(n, E.value)))
        if (l && !e) {
          const w = J(_e(R(n))).map((m) => c == null ? void 0 : c.getNodeByValue(m)).filter((m) => !!m && !m.loaded && !m.loading);
          w.length ? w.forEach((m) => {
            x(m, () => y(!1, o));
          }) : y(!0, o);
        } else {
          const u = t ? R(n) : [n], w = J(u.map((m) => c == null ? void 0 : c.getNodeByValue(m, v)));
          Z(w, o), E.value = be(n);
        }
    }, "syncCheckedValue"), Z = /* @__PURE__ */ s((e, o = !0) => {
      const { checkStrictly: n } = d.value, l = h.value, t = e.filter((u) => !!u && (n || u.isLeaf)), a = c == null ? void 0 : c.getSameNode(k.value), v = o && a || t[0];
      v ? v.pathNodes.forEach((u) => S(u, !0)) : k.value = null, l.forEach((u) => u.doCheck(!1)), z(t).forEach((u) => u.doCheck(!0)), h.value = t, re(A);
    }, "syncMenuState"), A = /* @__PURE__ */ s(() => {
      we && f.value.forEach((e) => {
        const o = e == null ? void 0 : e.$el;
        if (o) {
          const n = o.querySelector(`.${i.namespace.value}-scrollbar__wrap`), l = o.querySelector(`.${i.b("node")}.${i.is("active")}`) || o.querySelector(`.${i.b("node")}.in-active-path`);
          ye(n, l);
        }
      });
    }, "scrollToExpandingNode"), ee = /* @__PURE__ */ s((e) => {
      const o = e.target, { code: n } = e;
      switch (n) {
        case _.up:
        case _.down: {
          e.preventDefault();
          const l = n === _.up ? -1 : 1;
          L(Ce(o, l, `.${i.b("node")}[tabindex="-1"]`));
          break;
        }
        case _.left: {
          e.preventDefault();
          const l = f.value[I(o) - 1], t = l == null ? void 0 : l.$el.querySelector(`.${i.b("node")}[aria-expanded="true"]`);
          L(t);
          break;
        }
        case _.right: {
          e.preventDefault();
          const l = f.value[I(o) + 1], t = l == null ? void 0 : l.$el.querySelector(`.${i.b("node")}[tabindex="-1"]`);
          L(t);
          break;
        }
        case _.enter:
          Ne(o);
          break;
      }
    }, "handleKeyDown");
    return le(ge, z({
      config: d,
      expandingNode: k,
      checkedNodes: h,
      isHoverMenu: j,
      initialLoaded: g,
      renderLabelFn: Q,
      lazyLoad: x,
      expandNode: S,
      handleCheckChange: M
    })), $([d, () => r.options], W, {
      deep: !0,
      immediate: !0
    }), $(() => r.modelValue, () => {
      b = !1, y();
    }, {
      deep: !0
    }), $(() => E.value, (e) => {
      Y(e, r.modelValue) || (p(H, e), p(U, e));
    }), te(() => f.value = []), ae(() => !G(r.modelValue) && y()), {
      ns: i,
      menuList: f,
      menus: N,
      checkedNodes: h,
      handleKeyDown: ee,
      handleCheckChange: M,
      getFlattedNodes: q,
      getCheckedNodes: O,
      clearCheckedNodes: X,
      calculateCheckedValue: V,
      scrollToExpandingNode: A
    };
  }
});
function Se(r, p, B, b, i, d) {
  const c = se("el-cascader-menu");
  return D(), F("div", {
    class: ce([r.ns.b("panel"), r.ns.is("bordered", r.border)]),
    onKeydown: r.handleKeyDown
  }, [
    (D(!0), F(ue, null, de(r.menus, (g, f) => (D(), ie(c, {
      key: f,
      ref_for: !0,
      ref: /* @__PURE__ */ s((E) => r.menuList[f] = E, "ref"),
      index: f,
      nodes: [...g]
    }, null, 8, ["index", "nodes"]))), 128))
  ], 42, ["onKeydown"]);
}
s(Se, "_sfc_render");
var Ye = /* @__PURE__ */ Ee(xe, [["render", Se], ["__file", "index.vue"]]);
export {
  Ye as default
};
