var l = Object.defineProperty;
var t = (r, i) => l(r, "name", { value: i, configurable: !0 });
import { buildProps as n } from "../../../../utils/vue/props/runtime/index.js";
import { useTooltipTriggerProps as p } from "../../../tooltip/src/trigger/index.js";
import { dropdownProps as o } from "../../../dropdown/src/dropdown/index.js";
import { useTooltipContentProps as e } from "../../../tooltip/src/content/index.js";
import { isBoolean as a } from "../../../../utils/types/index.js";
const y = n({
  trigger: p.trigger,
  placement: o.placement,
  disabled: p.disabled,
  visible: e.visible,
  transition: e.transition,
  popperOptions: o.popperOptions,
  tabindex: o.tabindex,
  content: e.content,
  popperStyle: e.popperStyle,
  popperClass: e.popperClass,
  enterable: {
    ...e.enterable,
    default: !0
  },
  effect: {
    ...e.effect,
    default: "light"
  },
  teleported: e.teleported,
  title: String,
  width: {
    type: [String, Number],
    default: 150
  },
  offset: {
    type: Number,
    default: void 0
  },
  showAfter: {
    type: Number,
    default: 0
  },
  hideAfter: {
    type: Number,
    default: 200
  },
  autoClose: {
    type: Number,
    default: 0
  },
  showArrow: {
    type: Boolean,
    default: !0
  },
  persistent: {
    type: Boolean,
    default: !0
  },
  "onUpdate:visible": {
    type: Function
  }
}), c = {
  "update:visible": /* @__PURE__ */ t((r) => a(r), "update:visible"),
  "before-enter": /* @__PURE__ */ t(() => !0, "before-enter"),
  "before-leave": /* @__PURE__ */ t(() => !0, "before-leave"),
  "after-enter": /* @__PURE__ */ t(() => !0, "after-enter"),
  "after-leave": /* @__PURE__ */ t(() => !0, "after-leave")
};
export {
  c as popoverEmits,
  y as popoverProps
};
