var b = Object.defineProperty;
var n = (o, i) => b(o, "name", { value: i, configurable: !0 });
import { computed as u, unref as e, shallowRef as S, ref as U, watch as f, onBeforeUnmount as g } from "vue";
import { createPopper as w } from "../../../../../../../@sxzz_popperjs-es@2.11.7/node_modules/@sxzz/popperjs-es/dist/index/index.js";
import m from "../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/fromPairs/index.js";
const j = /* @__PURE__ */ n((o, i, p = {}) => {
  const l = {
    name: "updateState",
    enabled: !0,
    phase: "write",
    fn: /* @__PURE__ */ n(({ state: t }) => {
      const a = h(t);
      Object.assign(c.value, a);
    }, "fn"),
    requires: ["computeStyles"]
  }, s = u(() => {
    const { onFirstUpdate: t, placement: a, strategy: y, modifiers: v } = e(p);
    return {
      onFirstUpdate: t,
      placement: a || "bottom",
      strategy: y || "absolute",
      modifiers: [
        ...v || [],
        l,
        { name: "applyStyles", enabled: !1 }
      ]
    };
  }), r = S(), c = U({
    styles: {
      popper: {
        position: e(s).strategy,
        left: "0",
        top: "0"
      },
      arrow: {
        position: "absolute"
      }
    },
    attributes: {}
  }), d = /* @__PURE__ */ n(() => {
    r.value && (r.value.destroy(), r.value = void 0);
  }, "destroy");
  return f(s, (t) => {
    const a = e(r);
    a && a.setOptions(t);
  }, {
    deep: !0
  }), f([o, i], ([t, a]) => {
    d(), !(!t || !a) && (r.value = w(t, a, e(s)));
  }), g(() => {
    d();
  }), {
    state: u(() => {
      var t;
      return { ...((t = e(r)) == null ? void 0 : t.state) || {} };
    }),
    styles: u(() => e(c).styles),
    attributes: u(() => e(c).attributes),
    update: /* @__PURE__ */ n(() => {
      var t;
      return (t = e(r)) == null ? void 0 : t.update();
    }, "update"),
    forceUpdate: /* @__PURE__ */ n(() => {
      var t;
      return (t = e(r)) == null ? void 0 : t.forceUpdate();
    }, "forceUpdate"),
    instanceRef: u(() => e(r))
  };
}, "usePopper");
function h(o) {
  const i = Object.keys(o.elements), p = m(i.map((s) => [s, o.styles[s] || {}])), l = m(i.map((s) => [s, o.attributes[s]]));
  return {
    styles: p,
    attributes: l
  };
}
n(h, "deriveState");
export {
  j as usePopper
};
