var x = Object.defineProperty;
var i = (e, t) => x(e, "name", { value: t, configurable: !0 });
import { isElement as E } from "../../../utils/types/index.js";
import { isClient as H } from "../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const s = /* @__PURE__ */ new Map();
if (H) {
  let e;
  document.addEventListener("mousedown", (t) => e = t), document.addEventListener("mouseup", (t) => {
    if (e) {
      for (const n of s.values())
        for (const { documentHandler: o } of n)
          o(t, e);
      e = void 0;
    }
  });
}
function l(e, t) {
  let n = [];
  return Array.isArray(t.arg) ? n = t.arg : E(t.arg) && n.push(t.arg), function(o, a) {
    const r = t.instance.popperRef, c = o.target, d = a == null ? void 0 : a.target, f = !t || !t.instance, p = !c || !d, m = e.contains(c) || e.contains(d), h = e === c, v = n.length && n.some((u) => u == null ? void 0 : u.contains(c)) || n.length && n.includes(d), g = r && (r.contains(c) || r.contains(d));
    f || p || m || h || v || g || t.value(o, a);
  };
}
i(l, "createDocumentHandler");
const B = {
  beforeMount(e, t) {
    s.has(e) || s.set(e, []), s.get(e).push({
      documentHandler: l(e, t),
      bindingFn: t.value
    });
  },
  updated(e, t) {
    s.has(e) || s.set(e, []);
    const n = s.get(e), o = n.findIndex((r) => r.bindingFn === t.oldValue), a = {
      documentHandler: l(e, t),
      bindingFn: t.value
    };
    o >= 0 ? n.splice(o, 1, a) : n.push(a);
  },
  unmounted(e) {
    s.delete(e);
  }
};
export {
  B as default
};
