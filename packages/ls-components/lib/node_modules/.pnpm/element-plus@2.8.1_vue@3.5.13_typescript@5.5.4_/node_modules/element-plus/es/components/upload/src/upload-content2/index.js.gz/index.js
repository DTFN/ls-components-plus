var H = Object.defineProperty;
var s = (h, b) => H(h, "name", { value: b, configurable: !0 });
import { defineComponent as j, shallowRef as q, openBlock as P, createElementBlock as I, normalizeClass as S, unref as r, withKeys as T, withModifiers as B, createBlock as V, withCtx as X, renderSlot as K, createElementVNode as w } from "vue";
import { isPlainObject as D, isFunction as G } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import J from "../upload-dragger2/index.js";
import { uploadContentProps as Q } from "../upload-content/index.js";
import { genFileId as W } from "../upload/index.js";
import Y from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as Z } from "../../../../hooks/use-namespace/index/index.js";
import { useFormDisabled as x } from "../../../form/src/hooks/use-form-common-props/index.js";
import { entriesOf as F } from "../../../../utils/objects/index.js";
import O from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/cloneDeep/index.js";
import ee from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isEqual/index.js";
const te = j({
  name: "ElUploadContent",
  inheritAttrs: !1
}), oe = /* @__PURE__ */ j({
  ...te,
  props: Q,
  setup(h, { expose: b }) {
    const n = h, c = Z("upload"), d = x(), u = q({}), m = q(), E = /* @__PURE__ */ s((e) => {
      if (e.length === 0)
        return;
      const { autoUpload: t, limit: o, fileList: a, multiple: l, onStart: f, onExceed: g } = n;
      if (o && a.length + e.length > o) {
        g(e, a);
        return;
      }
      l || (e = e.slice(0, 1));
      for (const v of e) {
        const p = v;
        p.uid = W(), f(p), t && R(p);
      }
    }, "uploadFiles"), R = /* @__PURE__ */ s(async (e) => {
      if (m.value.value = "", !n.beforeUpload)
        return U(e);
      let t, o = {};
      try {
        const l = n.data, f = n.beforeUpload(e);
        o = D(n.data) ? O(n.data) : n.data, t = await f, D(n.data) && ee(l, o) && (o = O(n.data));
      } catch {
        t = !1;
      }
      if (t === !1) {
        n.onRemove(e);
        return;
      }
      let a = e;
      t instanceof Blob && (t instanceof File ? a = t : a = new File([t], e.name, {
        type: e.type
      })), U(Object.assign(a, {
        uid: e.uid
      }), o);
    }, "upload"), A = /* @__PURE__ */ s(async (e, t) => G(e) ? e(t) : e, "resolveData"), U = /* @__PURE__ */ s(async (e, t) => {
      const {
        headers: o,
        data: a,
        method: l,
        withCredentials: f,
        name: g,
        action: v,
        onProgress: p,
        onSuccess: N,
        onError: $,
        httpRequest: z
      } = n;
      try {
        t = await A(t ?? a, e);
      } catch {
        n.onRemove(e);
        return;
      }
      const { uid: y } = e, C = {
        headers: o || {},
        withCredentials: f,
        file: e,
        data: t,
        method: l,
        filename: g,
        action: v,
        onProgress: /* @__PURE__ */ s((i) => {
          p(i, e);
        }, "onProgress"),
        onSuccess: /* @__PURE__ */ s((i) => {
          N(i, e), delete u.value[y];
        }, "onSuccess"),
        onError: /* @__PURE__ */ s((i) => {
          $(i, e), delete u.value[y];
        }, "onError")
      }, k = z(C);
      u.value[y] = k, k instanceof Promise && k.then(C.onSuccess, C.onError);
    }, "doUpload"), L = /* @__PURE__ */ s((e) => {
      const t = e.target.files;
      t && E(Array.from(t));
    }, "handleChange"), _ = /* @__PURE__ */ s(() => {
      d.value || (m.value.value = "", m.value.click());
    }, "handleClick"), M = /* @__PURE__ */ s(() => {
      _();
    }, "handleKeydown");
    return b({
      abort: /* @__PURE__ */ s((e) => {
        F(u.value).filter(e ? ([o]) => String(e.uid) === o : () => !0).forEach(([o, a]) => {
          a instanceof XMLHttpRequest && a.abort(), delete u.value[o];
        });
      }, "abort"),
      upload: R
    }), (e, t) => (P(), I("div", {
      class: S([
        r(c).b(),
        r(c).m(e.listType),
        r(c).is("drag", e.drag),
        r(c).is("disabled", r(d))
      ]),
      tabindex: r(d) ? "-1" : "0",
      onClick: _,
      onKeydown: T(B(M, ["self"]), ["enter", "space"])
    }, [
      e.drag ? (P(), V(J, {
        key: 0,
        disabled: r(d),
        onFile: E
      }, {
        default: X(() => [
          K(e.$slots, "default")
        ]),
        _: 3
      }, 8, ["disabled"])) : K(e.$slots, "default", { key: 1 }),
      w("input", {
        ref_key: "inputRef",
        ref: m,
        class: S(r(c).e("input")),
        name: e.name,
        disabled: r(d),
        multiple: e.multiple,
        accept: e.accept,
        type: "file",
        onChange: L,
        onClick: B(() => {
        }, ["stop"])
      }, null, 42, ["name", "disabled", "multiple", "accept", "onClick"])
    ], 42, ["tabindex", "onKeydown"]));
  }
});
var be = /* @__PURE__ */ Y(oe, [["__file", "upload-content.vue"]]);
export {
  be as default
};
