var m = Object.defineProperty;
var h = (r, t) => m(r, "name", { value: t, configurable: !0 });
import { isFirefox as u } from "../../../../utils/browser/index.js";
import { isNumber as b } from "../../../../utils/types/index.js";
let e;
const x = `
  height:0 !important;
  visibility:hidden !important;
  ${u() ? "" : "overflow:hidden !important;"}
  position:absolute !important;
  z-index:-1000 !important;
  top:0 !important;
  right:0 !important;
`, f = [
  "letter-spacing",
  "line-height",
  "padding-top",
  "padding-bottom",
  "font-family",
  "font-weight",
  "font-size",
  "text-rendering",
  "text-transform",
  "width",
  "text-indent",
  "padding-left",
  "padding-right",
  "border-width",
  "box-sizing"
];
function y(r) {
  const t = window.getComputedStyle(r), d = t.getPropertyValue("box-sizing"), l = Number.parseFloat(t.getPropertyValue("padding-bottom")) + Number.parseFloat(t.getPropertyValue("padding-top")), a = Number.parseFloat(t.getPropertyValue("border-bottom-width")) + Number.parseFloat(t.getPropertyValue("border-top-width"));
  return { contextStyle: f.map((n) => `${n}:${t.getPropertyValue(n)}`).join(";"), paddingSize: l, borderSize: a, boxSizing: d };
}
h(y, "calculateNodeStyling");
function N(r, t = 1, d) {
  var l;
  e || (e = document.createElement("textarea"), document.body.appendChild(e));
  const { paddingSize: a, borderSize: p, boxSizing: n, contextStyle: c } = y(r);
  e.setAttribute("style", `${c};${x}`), e.value = r.value || r.placeholder || "";
  let o = e.scrollHeight;
  const g = {};
  n === "border-box" ? o = o + p : n === "content-box" && (o = o - a), e.value = "";
  const s = e.scrollHeight - a;
  if (b(t)) {
    let i = s * t;
    n === "border-box" && (i = i + a + p), o = Math.max(i, o), g.minHeight = `${i}px`;
  }
  if (b(d)) {
    let i = s * d;
    n === "border-box" && (i = i + a + p), o = Math.min(i, o);
  }
  return g.height = `${o}px`, (l = e.parentNode) == null || l.removeChild(e), e = void 0, g;
}
h(N, "calcTextareaHeight");
export {
  N as calcTextareaHeight
};
