var z = Object.defineProperty;
var d = (e, v) => z(e, "name", { value: v, configurable: !0 });
import { defineComponent as H, inject as O, ref as m, getCurrentInstance as P, provide as W, watch as g, nextTick as L, resolveComponent as c, withDirectives as R, openBlock as r, createElementBlock as E, normalizeClass as C, withModifiers as i, createElementVNode as q, normalizeStyle as G, createBlock as k, withCtx as K, resolveDynamicComponent as J, createCommentVNode as D, createVNode as w, Fragment as Q, renderList as U, vShow as T } from "vue";
import { isFunction as X, isString as Y } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { ElCollapseTransition as Z } from "../../../collapse-transition/index/index.js";
import { ElCheckbox as x } from "../../../checkbox/index/index.js";
import { ElIcon as _ } from "../../../icon/index/index.js";
import { Loading as ee, CaretRight as ne } from "@element-plus/icons-vue";
import oe from "../tree-node-content/index.js";
import { getNodeKey as de, handleCurrentChange as ae } from "../model/util/index.js";
import { useNodeExpandEventBroadcast as te } from "../model/useNodeExpandEventBroadcast/index.js";
import { dragEventsKey as re } from "../model/useDragNode/index.js";
import le from "../model/node/index.js";
import ie from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as se } from "../../../../hooks/use-namespace/index/index.js";
import { debugWarn as ce } from "../../../../utils/error/index.js";
const he = H({
  name: "ElTreeNode",
  components: {
    ElCollapseTransition: Z,
    ElCheckbox: x,
    NodeContent: oe,
    ElIcon: _,
    Loading: ee
  },
  props: {
    node: {
      type: le,
      default: /* @__PURE__ */ d(() => ({}), "default")
    },
    props: {
      type: Object,
      default: /* @__PURE__ */ d(() => ({}), "default")
    },
    accordion: Boolean,
    renderContent: Function,
    renderAfterExpand: Boolean,
    showCheckbox: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["node-expand"],
  setup(e, v) {
    const S = se("tree"), { broadcastExpanded: $ } = te(e), o = O("RootTree"), h = m(!1), s = m(!1), u = m(null), p = m(null), N = m(null), f = O(re), l = P();
    W("NodeInstance", l), o || ce("Tree", "Can not find node's tree."), e.node.expanded && (h.value = !0, s.value = !0);
    const b = o.props.props.children || "children";
    g(() => {
      const n = e.node.data[b];
      return n && [...n];
    }, () => {
      e.node.updateChildren();
    }), g(() => e.node.indeterminate, (n) => {
      y(e.node.checked, n);
    }), g(() => e.node.checked, (n) => {
      y(n, e.node.indeterminate);
    }), g(() => e.node.childNodes.length, () => e.node.reInitChecked()), g(() => e.node.expanded, (n) => {
      L(() => h.value = n), n && (s.value = !0);
    });
    const F = /* @__PURE__ */ d((n) => de(o.props.nodeKey, n.data), "getNodeKey$1"), A = /* @__PURE__ */ d((n) => {
      const a = e.props.class;
      if (!a)
        return {};
      let t;
      if (X(a)) {
        const { data: j } = n;
        t = a(j, n);
      } else
        t = a;
      return Y(t) ? { [t]: !0 } : t;
    }, "getNodeClass"), y = /* @__PURE__ */ d((n, a) => {
      (u.value !== n || p.value !== a) && o.ctx.emit("check-change", e.node.data, n, a), u.value = n, p.value = a;
    }, "handleSelectChange"), M = /* @__PURE__ */ d((n) => {
      ae(o.store, o.ctx.emit, () => o.store.value.setCurrentNode(e.node)), o.currentNode.value = e.node, o.props.expandOnClickNode && B(), o.props.checkOnClickNode && !e.node.disabled && I(null, {
        target: { checked: !e.node.checked }
      }), o.ctx.emit("node-click", e.node.data, e.node, l, n);
    }, "handleClick"), V = /* @__PURE__ */ d((n) => {
      o.instance.vnode.props.onNodeContextmenu && (n.stopPropagation(), n.preventDefault()), o.ctx.emit("node-contextmenu", n, e.node.data, e.node, l);
    }, "handleContextMenu"), B = /* @__PURE__ */ d(() => {
      e.node.isLeaf || (h.value ? (o.ctx.emit("node-collapse", e.node.data, e.node, l), e.node.collapse()) : (e.node.expand(), v.emit("node-expand", e.node.data, e.node, l)));
    }, "handleExpandIconClick"), I = /* @__PURE__ */ d((n, a) => {
      e.node.setChecked(a.target.checked, !o.props.checkStrictly), L(() => {
        const t = o.store.value;
        o.ctx.emit("check", e.node.data, {
          checkedNodes: t.getCheckedNodes(),
          checkedKeys: t.getCheckedKeys(),
          halfCheckedNodes: t.getHalfCheckedNodes(),
          halfCheckedKeys: t.getHalfCheckedKeys()
        });
      });
    }, "handleCheckChange");
    return {
      ns: S,
      node$: N,
      tree: o,
      expanded: h,
      childNodeRendered: s,
      oldChecked: u,
      oldIndeterminate: p,
      getNodeKey: F,
      getNodeClass: A,
      handleSelectChange: y,
      handleClick: M,
      handleContextMenu: V,
      handleExpandIconClick: B,
      handleCheckChange: I,
      handleChildNodeExpand: /* @__PURE__ */ d((n, a, t) => {
        $(a), o.ctx.emit("node-expand", n, a, t);
      }, "handleChildNodeExpand"),
      handleDragStart: /* @__PURE__ */ d((n) => {
        o.props.draggable && f.treeNodeDragStart({ event: n, treeNode: e });
      }, "handleDragStart"),
      handleDragOver: /* @__PURE__ */ d((n) => {
        n.preventDefault(), o.props.draggable && f.treeNodeDragOver({
          event: n,
          treeNode: { $el: N.value, node: e.node }
        });
      }, "handleDragOver"),
      handleDrop: /* @__PURE__ */ d((n) => {
        n.preventDefault();
      }, "handleDrop"),
      handleDragEnd: /* @__PURE__ */ d((n) => {
        o.props.draggable && f.treeNodeDragEnd(n);
      }, "handleDragEnd"),
      CaretRight: ne
    };
  }
});
function ue(e, v, S, $, o, h) {
  const s = c("el-icon"), u = c("el-checkbox"), p = c("loading"), N = c("node-content"), f = c("el-tree-node"), l = c("el-collapse-transition");
  return R((r(), E("div", {
    ref: "node$",
    class: C([
      e.ns.b("node"),
      e.ns.is("expanded", e.expanded),
      e.ns.is("current", e.node.isCurrent),
      e.ns.is("hidden", !e.node.visible),
      e.ns.is("focusable", !e.node.disabled),
      e.ns.is("checked", !e.node.disabled && e.node.checked),
      e.getNodeClass(e.node)
    ]),
    role: "treeitem",
    tabindex: "-1",
    "aria-expanded": e.expanded,
    "aria-disabled": e.node.disabled,
    "aria-checked": e.node.checked,
    draggable: e.tree.props.draggable,
    "data-key": e.getNodeKey(e.node),
    onClick: i(e.handleClick, ["stop"]),
    onContextmenu: e.handleContextMenu,
    onDragstart: i(e.handleDragStart, ["stop"]),
    onDragover: i(e.handleDragOver, ["stop"]),
    onDragend: i(e.handleDragEnd, ["stop"]),
    onDrop: i(e.handleDrop, ["stop"])
  }, [
    q("div", {
      class: C(e.ns.be("node", "content")),
      style: G({ paddingLeft: (e.node.level - 1) * e.tree.props.indent + "px" })
    }, [
      e.tree.props.icon || e.CaretRight ? (r(), k(s, {
        key: 0,
        class: C([
          e.ns.be("node", "expand-icon"),
          e.ns.is("leaf", e.node.isLeaf),
          {
            expanded: !e.node.isLeaf && e.expanded
          }
        ]),
        onClick: i(e.handleExpandIconClick, ["stop"])
      }, {
        default: K(() => [
          (r(), k(J(e.tree.props.icon || e.CaretRight)))
        ]),
        _: 1
      }, 8, ["class", "onClick"])) : D("v-if", !0),
      e.showCheckbox ? (r(), k(u, {
        key: 1,
        "model-value": e.node.checked,
        indeterminate: e.node.indeterminate,
        disabled: !!e.node.disabled,
        onClick: i(() => {
        }, ["stop"]),
        onChange: e.handleCheckChange
      }, null, 8, ["model-value", "indeterminate", "disabled", "onClick", "onChange"])) : D("v-if", !0),
      e.node.loading ? (r(), k(s, {
        key: 2,
        class: C([e.ns.be("node", "loading-icon"), e.ns.is("loading")])
      }, {
        default: K(() => [
          w(p)
        ]),
        _: 1
      }, 8, ["class"])) : D("v-if", !0),
      w(N, {
        node: e.node,
        "render-content": e.renderContent
      }, null, 8, ["node", "render-content"])
    ], 6),
    w(l, null, {
      default: K(() => [
        !e.renderAfterExpand || e.childNodeRendered ? R((r(), E("div", {
          key: 0,
          class: C(e.ns.be("node", "children")),
          role: "group",
          "aria-expanded": e.expanded
        }, [
          (r(!0), E(Q, null, U(e.node.childNodes, (b) => (r(), k(f, {
            key: e.getNodeKey(b),
            "render-content": e.renderContent,
            "render-after-expand": e.renderAfterExpand,
            "show-checkbox": e.showCheckbox,
            node: b,
            accordion: e.accordion,
            props: e.props,
            onNodeExpand: e.handleChildNodeExpand
          }, null, 8, ["render-content", "render-after-expand", "show-checkbox", "node", "accordion", "props", "onNodeExpand"]))), 128))
        ], 10, ["aria-expanded"])), [
          [T, e.expanded]
        ]) : D("v-if", !0)
      ]),
      _: 1
    })
  ], 42, ["aria-expanded", "aria-disabled", "aria-checked", "draggable", "data-key", "onClick", "onContextmenu", "onDragstart", "onDragover", "onDragend", "onDrop"])), [
    [T, e.node.visible]
  ]);
}
d(ue, "_sfc_render");
var Re = /* @__PURE__ */ ie(he, [["render", ue], ["__file", "tree-node.vue"]]);
export {
  Re as default
};
