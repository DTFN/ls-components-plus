var y = Object.defineProperty;
var c = (u, s) => y(u, "name", { value: s, configurable: !0 });
import { inject as C } from "vue";
import { getFixedColumnOffset as d, ensurePosition as p, getFixedColumnsClass as h } from "../../util/index.js";
import { TABLE_INJECTION_KEY as m } from "../../tokens/index.js";
import { useNamespace as w } from "../../../../../hooks/use-namespace/index/index.js";
function B(u) {
  const s = C(m), f = w("table");
  return {
    getRowStyle: /* @__PURE__ */ c((n, t) => {
      const e = s == null ? void 0 : s.props.rowStyle;
      return typeof e == "function" ? e.call(null, {
        row: n,
        rowIndex: t
      }) : e || null;
    }, "getRowStyle"),
    getRowClass: /* @__PURE__ */ c((n, t) => {
      const e = [f.e("row")];
      s != null && s.props.highlightCurrentRow && n === u.store.states.currentRow.value && e.push("current-row"), u.stripe && t % 2 === 1 && e.push(f.em("row", "striped"));
      const l = s == null ? void 0 : s.props.rowClassName;
      return typeof l == "string" ? e.push(l) : typeof l == "function" && e.push(l.call(null, {
        row: n,
        rowIndex: t
      })), e;
    }, "getRowClass"),
    getCellStyle: /* @__PURE__ */ c((n, t, e, l) => {
      const o = s == null ? void 0 : s.props.cellStyle;
      let r = o ?? {};
      typeof o == "function" && (r = o.call(null, {
        rowIndex: n,
        columnIndex: t,
        row: e,
        column: l
      }));
      const i = d(t, u == null ? void 0 : u.fixed, u.store);
      return p(i, "left"), p(i, "right"), Object.assign({}, r, i);
    }, "getCellStyle"),
    getCellClass: /* @__PURE__ */ c((n, t, e, l, o) => {
      const r = h(f.b(), t, u == null ? void 0 : u.fixed, u.store, void 0, o), i = [l.id, l.align, l.className, ...r], a = s == null ? void 0 : s.props.cellClassName;
      return typeof a == "string" ? i.push(a) : typeof a == "function" && i.push(a.call(null, {
        rowIndex: n,
        columnIndex: t,
        row: e,
        column: l
      })), i.push(f.e("cell")), i.filter((g) => !!g).join(" ");
    }, "getCellClass"),
    getSpan: /* @__PURE__ */ c((n, t, e, l) => {
      let o = 1, r = 1;
      const i = s == null ? void 0 : s.props.spanMethod;
      if (typeof i == "function") {
        const a = i({
          row: n,
          column: t,
          rowIndex: e,
          columnIndex: l
        });
        Array.isArray(a) ? (o = a[0], r = a[1]) : typeof a == "object" && (o = a.rowspan, r = a.colspan);
      }
      return { rowspan: o, colspan: r };
    }, "getSpan"),
    getColspanRealWidth: /* @__PURE__ */ c((n, t, e) => {
      if (t < 1)
        return n[e].realWidth;
      const l = n.map(({ realWidth: o, width: r }) => o || r).slice(e, e + t);
      return Number(l.reduce((o, r) => Number(o) + Number(r), -1));
    }, "getColspanRealWidth")
  };
}
c(B, "useStyles");
export {
  B as default
};
