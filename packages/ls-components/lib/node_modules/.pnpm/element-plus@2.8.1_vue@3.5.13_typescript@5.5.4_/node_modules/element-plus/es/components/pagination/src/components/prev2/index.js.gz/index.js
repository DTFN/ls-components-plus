var d = Object.defineProperty;
var i = (a, r) => d(a, "name", { value: r, configurable: !0 });
import { defineComponent as s, computed as v, openBlock as t, createElementBlock as p, unref as o, toDisplayString as f, createBlock as l, withCtx as u, resolveDynamicComponent as b } from "vue";
import { ElIcon as k } from "../../../../icon/index/index.js";
import { paginationPrevProps as _, paginationPrevEmits as P } from "../prev/index.js";
import g from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as y } from "../../../../../hooks/use-locale/index/index.js";
const C = s({
  name: "ElPaginationPrev"
}), E = /* @__PURE__ */ s({
  ...C,
  props: _,
  emits: P,
  setup(a) {
    const r = a, { t: c } = y(), n = v(() => r.disabled || r.currentPage <= 1);
    return (e, B) => (t(), p("button", {
      type: "button",
      class: "btn-prev",
      disabled: o(n),
      "aria-label": e.prevText || o(c)("el.pagination.prev"),
      "aria-disabled": o(n),
      onClick: /* @__PURE__ */ i((m) => e.$emit("click", m), "onClick")
    }, [
      e.prevText ? (t(), p("span", { key: 0 }, f(e.prevText), 1)) : (t(), l(o(k), { key: 1 }, {
        default: u(() => [
          (t(), l(b(e.prevIcon)))
        ]),
        _: 1
      }))
    ], 8, ["disabled", "aria-label", "aria-disabled", "onClick"]));
  }
});
var L = /* @__PURE__ */ g(E, [["__file", "prev.vue"]]);
export {
  L as default
};
