var $ = Object.defineProperty;
var m = (e, o) => $(e, "name", { value: o, configurable: !0 });
import { defineComponent as h, getCurrentInstance as g, inject as M, toRef as N, computed as B, reactive as P, onMounted as j, onBeforeUnmount as y, resolveComponent as S, openBlock as u, createElementBlock as v, normalizeClass as I, createBlock as w, withCtx as b, renderSlot as s, createElementVNode as O, Fragment as T } from "vue";
import { ElTooltip as z } from "../../../tooltip/index/index.js";
import A from "../use-menu/index.js";
import { menuItemProps as F, menuItemEmits as R } from "../menu-item/index.js";
import U from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as k } from "../../../../hooks/use-namespace/index/index.js";
import { throwError as C } from "../../../../utils/error/index.js";
const l = "ElMenuItem", V = h({
  name: l,
  components: {
    ElTooltip: z
  },
  props: F,
  emits: R,
  setup(e, { emit: o }) {
    const a = g(), n = M("rootMenu"), c = k("menu"), d = k("menu-item");
    n || C(l, "can not inject root menu");
    const { parentMenu: i, indexPath: p } = A(a, N(e, "index")), r = M(`subMenu:${i.value.uid}`);
    r || C(l, "can not inject sub menu");
    const f = B(() => e.index === n.activeIndex), t = P({
      index: e.index,
      indexPath: p,
      active: f
    }), E = /* @__PURE__ */ m(() => {
      e.disabled || (n.handleMenuItemClick({
        index: e.index,
        indexPath: p.value,
        route: e.route
      }), o("click", t));
    }, "handleClick");
    return j(() => {
      r.addSubMenu(t), n.addMenuItem(t);
    }), y(() => {
      r.removeSubMenu(t), n.removeMenuItem(t);
    }), {
      parentMenu: i,
      rootMenu: n,
      active: f,
      nsMenu: c,
      nsMenuItem: d,
      handleClick: E
    };
  }
});
function q(e, o, a, n, c, d) {
  const i = S("el-tooltip");
  return u(), v("li", {
    class: I([
      e.nsMenuItem.b(),
      e.nsMenuItem.is("active", e.active),
      e.nsMenuItem.is("disabled", e.disabled)
    ]),
    role: "menuitem",
    tabindex: "-1",
    onClick: e.handleClick
  }, [
    e.parentMenu.type.name === "ElMenu" && e.rootMenu.props.collapse && e.$slots.title ? (u(), w(i, {
      key: 0,
      effect: e.rootMenu.props.popperEffect,
      placement: "right",
      "fallback-placements": ["left"],
      persistent: ""
    }, {
      content: b(() => [
        s(e.$slots, "title")
      ]),
      default: b(() => [
        O("div", {
          class: I(e.nsMenu.be("tooltip", "trigger"))
        }, [
          s(e.$slots, "default")
        ], 2)
      ]),
      _: 3
    }, 8, ["effect"])) : (u(), v(T, { key: 1 }, [
      s(e.$slots, "default"),
      s(e.$slots, "title")
    ], 64))
  ], 10, ["onClick"]);
}
m(q, "_sfc_render");
var X = /* @__PURE__ */ U(V, [["render", q], ["__file", "menu-item.vue"]]);
export {
  X as default
};
