var X = Object.defineProperty;
var n = (e, a) => X(e, "name", { value: a, configurable: !0 });
import { defineComponent as Z, getCurrentInstance as x, ref as s, computed as m, watch as ee, onBeforeUnmount as oe, provide as L, toRef as F, unref as ne, resolveComponent as l, openBlock as H, createElementBlock as re, normalizeClass as N, createVNode as i, createSlots as te, withCtx as t, renderSlot as k, createBlock as le, mergeProps as P, createCommentVNode as ie } from "vue";
import { ElButton as A } from "../../../button/index/index.js";
import { ElTooltip as ae } from "../../../tooltip/index/index.js";
import { ElScrollbar as de } from "../../../scrollbar/index/index.js";
import { ElIcon as se } from "../../../icon/index/index.js";
import { ArrowDown as pe } from "@element-plus/icons-vue";
import { ElCollection as ue, dropdownProps as fe } from "../dropdown/index.js";
import { DROPDOWN_INJECTION_KEY as ce } from "../tokens/index.js";
import me from "../../../../_virtual/plugin-vue_export-helper/index.js";
import ve from "../../../roving-focus-group/src/roving-focus-group2/index.js";
import { OnlyChild as ge } from "../../../slot/src/only-child/index.js";
import { useNamespace as be } from "../../../../hooks/use-namespace/index/index.js";
import { useLocale as he } from "../../../../hooks/use-locale/index/index.js";
import { EVENT_CODE as I } from "../../../../constants/aria/index.js";
import { addUnit as we } from "../../../../utils/dom/style/index.js";
import { useId as Ce } from "../../../../hooks/use-id/index/index.js";
import { useFormSize as Ee } from "../../../form/src/hooks/use-form-common-props/index.js";
import ye from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/castArray/index.js";
const { ButtonGroup: Be } = A, Te = Z({
  name: "ElDropdown",
  components: {
    ElButton: A,
    ElButtonGroup: Be,
    ElScrollbar: de,
    ElDropdownCollection: ue,
    ElTooltip: ae,
    ElRovingFocusGroup: ve,
    ElOnlyChild: ge,
    ElIcon: se,
    ArrowDown: pe
  },
  props: fe,
  emits: ["visible-change", "click", "command"],
  setup(e, { emit: a }) {
    const S = x(), C = be("dropdown"), { t: $ } = he(), p = s(), v = s(), f = s(null), d = s(null), E = s(null), c = s(null), g = s(!1), b = [I.enter, I.space, I.down], y = m(() => ({
      maxHeight: we(e.maxHeight)
    })), B = m(() => [C.m(T.value)]), h = m(() => ye(e.trigger)), K = Ce().value, R = m(() => e.id || K);
    ee([p, h], ([o, r], [u]) => {
      var z, D, O;
      (z = u == null ? void 0 : u.$el) != null && z.removeEventListener && u.$el.removeEventListener("pointerenter", w), (D = o == null ? void 0 : o.$el) != null && D.removeEventListener && o.$el.removeEventListener("pointerenter", w), (O = o == null ? void 0 : o.$el) != null && O.addEventListener && r.includes("hover") && o.$el.addEventListener("pointerenter", w);
    }, { immediate: !0 }), oe(() => {
      var o, r;
      (r = (o = p.value) == null ? void 0 : o.$el) != null && r.removeEventListener && p.value.$el.removeEventListener("pointerenter", w);
    });
    function G() {
      _();
    }
    n(G, "handleClick");
    function _() {
      var o;
      (o = f.value) == null || o.onClose();
    }
    n(_, "handleClose");
    function M() {
      var o;
      (o = f.value) == null || o.onOpen();
    }
    n(M, "handleOpen");
    const T = Ee();
    function U(...o) {
      a("command", ...o);
    }
    n(U, "commandHandler");
    function w() {
      var o, r;
      (r = (o = p.value) == null ? void 0 : o.$el) == null || r.focus();
    }
    n(w, "onAutofocusTriggerEnter");
    function V() {
    }
    n(V, "onItemEnter");
    function J() {
      const o = ne(d);
      h.value.includes("hover") && (o == null || o.focus()), c.value = null;
    }
    n(J, "onItemLeave");
    function W(o) {
      c.value = o;
    }
    n(W, "handleCurrentTabIdChange");
    function Y(o) {
      g.value || (o.preventDefault(), o.stopImmediatePropagation());
    }
    n(Y, "handleEntryFocus");
    function j() {
      a("visible-change", !0);
    }
    n(j, "handleBeforeShowTooltip");
    function q(o) {
      (o == null ? void 0 : o.type) === "keydown" && d.value.focus();
    }
    n(q, "handleShowTooltip");
    function Q() {
      a("visible-change", !1);
    }
    return n(Q, "handleBeforeHideTooltip"), L(ce, {
      contentRef: d,
      role: m(() => e.role),
      triggerId: R,
      isUsingKeyboard: g,
      onItemEnter: V,
      onItemLeave: J
    }), L("elDropdown", {
      instance: S,
      dropdownSize: T,
      handleClick: G,
      commandHandler: U,
      trigger: F(e, "trigger"),
      hideOnClick: F(e, "hideOnClick")
    }), {
      t: $,
      ns: C,
      scrollbar: E,
      wrapStyle: y,
      dropdownTriggerKls: B,
      dropdownSize: T,
      triggerId: R,
      triggerKeys: b,
      currentTabId: c,
      handleCurrentTabIdChange: W,
      handlerMainButtonClick: /* @__PURE__ */ n((o) => {
        a("click", o);
      }, "handlerMainButtonClick"),
      handleEntryFocus: Y,
      handleClose: _,
      handleOpen: M,
      handleBeforeShowTooltip: j,
      handleShowTooltip: q,
      handleBeforeHideTooltip: Q,
      onFocusAfterTrapped: /* @__PURE__ */ n((o) => {
        var r, u;
        o.preventDefault(), (u = (r = d.value) == null ? void 0 : r.focus) == null || u.call(r, {
          preventScroll: !0
        });
      }, "onFocusAfterTrapped"),
      popperRef: f,
      contentRef: d,
      triggeringElementRef: p,
      referenceElementRef: v
    };
  }
});
function ke(e, a, S, C, $, p) {
  var v;
  const f = l("el-dropdown-collection"), d = l("el-roving-focus-group"), E = l("el-scrollbar"), c = l("el-only-child"), g = l("el-tooltip"), b = l("el-button"), y = l("arrow-down"), B = l("el-icon"), h = l("el-button-group");
  return H(), re("div", {
    class: N([e.ns.b(), e.ns.is("disabled", e.disabled)])
  }, [
    i(g, {
      ref: "popperRef",
      role: e.role,
      effect: e.effect,
      "fallback-placements": ["bottom", "top"],
      "popper-options": e.popperOptions,
      "gpu-acceleration": !1,
      "hide-after": e.trigger === "hover" ? e.hideTimeout : 0,
      "manual-mode": !0,
      placement: e.placement,
      "popper-class": [e.ns.e("popper"), e.popperClass],
      "reference-element": (v = e.referenceElementRef) == null ? void 0 : v.$el,
      trigger: e.trigger,
      "trigger-keys": e.triggerKeys,
      "trigger-target-el": e.contentRef,
      "show-after": e.trigger === "hover" ? e.showTimeout : 0,
      "stop-popper-mouse-event": !1,
      "virtual-ref": e.triggeringElementRef,
      "virtual-triggering": e.splitButton,
      disabled: e.disabled,
      transition: `${e.ns.namespace.value}-zoom-in-top`,
      teleported: e.teleported,
      pure: "",
      persistent: "",
      onBeforeShow: e.handleBeforeShowTooltip,
      onShow: e.handleShowTooltip,
      onBeforeHide: e.handleBeforeHideTooltip
    }, te({
      content: t(() => [
        i(E, {
          ref: "scrollbar",
          "wrap-style": e.wrapStyle,
          tag: "div",
          "view-class": e.ns.e("list")
        }, {
          default: t(() => [
            i(d, {
              loop: e.loop,
              "current-tab-id": e.currentTabId,
              orientation: "horizontal",
              onCurrentTabIdChange: e.handleCurrentTabIdChange,
              onEntryFocus: e.handleEntryFocus
            }, {
              default: t(() => [
                i(f, null, {
                  default: t(() => [
                    k(e.$slots, "dropdown")
                  ]),
                  _: 3
                })
              ]),
              _: 3
            }, 8, ["loop", "current-tab-id", "onCurrentTabIdChange", "onEntryFocus"])
          ]),
          _: 3
        }, 8, ["wrap-style", "view-class"])
      ]),
      _: 2
    }, [
      e.splitButton ? void 0 : {
        name: "default",
        fn: t(() => [
          i(c, {
            id: e.triggerId,
            ref: "triggeringElementRef",
            role: "button",
            tabindex: e.tabindex
          }, {
            default: t(() => [
              k(e.$slots, "default")
            ]),
            _: 3
          }, 8, ["id", "tabindex"])
        ])
      }
    ]), 1032, ["role", "effect", "popper-options", "hide-after", "placement", "popper-class", "reference-element", "trigger", "trigger-keys", "trigger-target-el", "show-after", "virtual-ref", "virtual-triggering", "disabled", "transition", "teleported", "onBeforeShow", "onShow", "onBeforeHide"]),
    e.splitButton ? (H(), le(h, { key: 0 }, {
      default: t(() => [
        i(b, P({ ref: "referenceElementRef" }, e.buttonProps, {
          size: e.dropdownSize,
          type: e.type,
          disabled: e.disabled,
          tabindex: e.tabindex,
          onClick: e.handlerMainButtonClick
        }), {
          default: t(() => [
            k(e.$slots, "default")
          ]),
          _: 3
        }, 16, ["size", "type", "disabled", "tabindex", "onClick"]),
        i(b, P({
          id: e.triggerId,
          ref: "triggeringElementRef"
        }, e.buttonProps, {
          role: "button",
          size: e.dropdownSize,
          type: e.type,
          class: e.ns.e("caret-button"),
          disabled: e.disabled,
          tabindex: e.tabindex,
          "aria-label": e.t("el.dropdown.toggleDropdown")
        }), {
          default: t(() => [
            i(B, {
              class: N(e.ns.e("icon"))
            }, {
              default: t(() => [
                i(y)
              ]),
              _: 1
            }, 8, ["class"])
          ]),
          _: 1
        }, 16, ["id", "size", "type", "class", "disabled", "tabindex", "aria-label"])
      ]),
      _: 3
    })) : ie("v-if", !0)
  ], 2);
}
n(ke, "_sfc_render");
var Ye = /* @__PURE__ */ me(Te, [["render", ke], ["__file", "dropdown.vue"]]);
export {
  Ye as default
};
