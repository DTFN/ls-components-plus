import { defineComponent as E, inject as C, computed as p, onMounted as T, watch as c, onBeforeUnmount as y, openBlock as L, createBlock as P, unref as u, mergeProps as w, withCtx as x, renderSlot as R, createCommentVNode as A } from "vue";
import { unrefElement as B } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { POPPER_INJECTION_KEY as k } from "../constants/index.js";
import { popperTriggerProps as I } from "../trigger/index.js";
import M from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useForwardRef as O } from "../../../../hooks/use-forward-ref/index/index.js";
import { isElement as f } from "../../../../utils/types/index.js";
import { OnlyChild as S } from "../../../slot/src/only-child/index.js";
import $ from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
const F = E({
  name: "ElPopperTrigger",
  inheritAttrs: !1
}), G = /* @__PURE__ */ E({
  ...F,
  props: I,
  setup(_, { expose: b }) {
    const i = _, { role: s, triggerRef: t } = C(k, void 0);
    O(t);
    const m = p(() => l.value ? i.id : void 0), v = p(() => {
      if (s && s.value === "tooltip")
        return i.open && i.id ? i.id : void 0;
    }), l = p(() => {
      if (s && s.value !== "tooltip")
        return s.value;
    }), g = p(() => l.value ? `${i.open}` : void 0);
    let a;
    const h = [
      "onMouseenter",
      "onMouseleave",
      "onClick",
      "onKeydown",
      "onFocus",
      "onBlur",
      "onContextmenu"
    ];
    return T(() => {
      c(() => i.virtualRef, (e) => {
        e && (t.value = B(e));
      }, {
        immediate: !0
      }), c(t, (e, o) => {
        a == null || a(), a = void 0, f(e) && (h.forEach((r) => {
          var d;
          const n = i[r];
          n && (e.addEventListener(r.slice(2).toLowerCase(), n), (d = o == null ? void 0 : o.removeEventListener) == null || d.call(o, r.slice(2).toLowerCase(), n));
        }), a = c([m, v, l, g], (r) => {
          [
            "aria-controls",
            "aria-describedby",
            "aria-haspopup",
            "aria-expanded"
          ].forEach((d, n) => {
            $(r[n]) ? e.removeAttribute(d) : e.setAttribute(d, r[n]);
          });
        }, { immediate: !0 })), f(o) && [
          "aria-controls",
          "aria-describedby",
          "aria-haspopup",
          "aria-expanded"
        ].forEach((r) => o.removeAttribute(r));
      }, {
        immediate: !0
      });
    }), y(() => {
      if (a == null || a(), a = void 0, t.value && f(t.value)) {
        const e = t.value;
        h.forEach((o) => {
          const r = i[o];
          r && e.removeEventListener(o.slice(2).toLowerCase(), r);
        }), t.value = void 0;
      }
    }), b({
      triggerRef: t
    }), (e, o) => e.virtualTriggering ? A("v-if", !0) : (L(), P(u(S), w({ key: 0 }, e.$attrs, {
      "aria-controls": u(m),
      "aria-describedby": u(v),
      "aria-expanded": u(g),
      "aria-haspopup": u(l)
    }), {
      default: x(() => [
        R(e.$slots, "default")
      ]),
      _: 3
    }, 16, ["aria-controls", "aria-describedby", "aria-expanded", "aria-haspopup"]));
  }
});
var Y = /* @__PURE__ */ M(G, [["__file", "trigger.vue"]]);
export {
  Y as default
};
