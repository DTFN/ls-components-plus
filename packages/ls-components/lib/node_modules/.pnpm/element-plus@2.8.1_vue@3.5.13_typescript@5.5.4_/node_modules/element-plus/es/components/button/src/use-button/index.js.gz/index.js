var _ = Object.defineProperty;
var a = (t, r) => _(t, "name", { value: r, configurable: !0 });
import { computed as l, inject as h, ref as S, useSlots as x, Text as C } from "vue";
import { buttonGroupContextKey as I } from "../constants/index.js";
import { useDeprecated as k } from "../../../../hooks/use-deprecated/index/index.js";
import { useGlobalConfig as F } from "../../../config-provider/src/hooks/use-global-config/index.js";
import { useFormItem as z } from "../../../form/src/hooks/use-form-item/index.js";
import { useFormSize as D, useFormDisabled as G } from "../../../form/src/hooks/use-form-common-props/index.js";
const q = /* @__PURE__ */ a((t, r) => {
  k({
    from: "type.text",
    replacement: "link",
    version: "3.0.0",
    scope: "props",
    ref: "https://element-plus.org/en-US/component/button.html#button-attributes"
  }, l(() => t.type === "text"));
  const u = h(I, void 0), d = F("button"), { form: s } = z(), f = D(l(() => u == null ? void 0 : u.size)), i = G(), m = S(), c = x(), p = l(() => t.type || (u == null ? void 0 : u.type) || ""), v = l(() => {
    var e, o, n;
    return (n = (o = t.autoInsertSpace) != null ? o : (e = d.value) == null ? void 0 : e.autoInsertSpace) != null ? n : !1;
  }), b = l(() => t.tag === "button" ? {
    ariaDisabled: i.value || t.loading,
    disabled: i.value || t.loading,
    autofocus: t.autofocus,
    type: t.nativeType
  } : {}), g = l(() => {
    var e;
    const o = (e = c.default) == null ? void 0 : e.call(c);
    if (v.value && (o == null ? void 0 : o.length) === 1) {
      const n = o[0];
      if ((n == null ? void 0 : n.type) === C) {
        const y = n.children;
        return new RegExp("^\\p{Unified_Ideograph}{2}$", "u").test(y.trim());
      }
    }
    return !1;
  });
  return {
    _disabled: i,
    _size: f,
    _type: p,
    _ref: m,
    _props: b,
    shouldAddSpace: g,
    handleClick: /* @__PURE__ */ a((e) => {
      if (i.value || t.loading) {
        e.stopPropagation();
        return;
      }
      t.nativeType === "reset" && (s == null || s.resetFields()), r("click", e);
    }, "handleClick")
  };
}, "useButton");
export {
  q as useButton
};
