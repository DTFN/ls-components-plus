var W = Object.defineProperty;
var l = (n, c) => W(n, "name", { value: c, configurable: !0 });
import { defineComponent as X, getCurrentInstance as Y, computed as a, inject as F, ref as b, reactive as ee, watch as oe, provide as ne, onMounted as te, onBeforeUnmount as le, h as s, Fragment as ae, withDirectives as ue, vShow as re } from "vue";
import { ElCollapseTransition as se } from "../../../collapse-transition/index/index.js";
import { ElTooltip as ie } from "../../../tooltip/index/index.js";
import { ArrowDown as ce, ArrowRight as pe } from "@element-plus/icons-vue";
import { ElIcon as ve } from "../../../icon/index/index.js";
import de from "../use-menu/index.js";
import { useMenuCssVar as me } from "../use-menu-css-var/index.js";
import { buildProps as fe } from "../../../../utils/vue/props/runtime/index.js";
import { iconPropType as x } from "../../../../utils/vue/icon/index.js";
import { useNamespace as $ } from "../../../../hooks/use-namespace/index/index.js";
import { throwError as R } from "../../../../utils/error/index.js";
import { isString as be } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { useTimeoutFn as D } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const he = fe({
  index: {
    type: String,
    required: !0
  },
  showTimeout: Number,
  hideTimeout: Number,
  popperClass: String,
  disabled: Boolean,
  teleported: {
    type: Boolean,
    default: void 0
  },
  popperOffset: Number,
  expandCloseIcon: {
    type: x
  },
  expandOpenIcon: {
    type: x
  },
  collapseCloseIcon: {
    type: x
  },
  collapseOpenIcon: {
    type: x
  }
}), _ = "ElSubMenu";
var ze = X({
  name: _,
  props: he,
  setup(n, { slots: c, expose: H }) {
    const g = Y(), { indexPath: h, parentMenu: E } = de(g, a(() => n.index)), i = $("menu"), v = $("sub-menu"), o = F("rootMenu");
    o || R(_, "can not inject root menu");
    const u = F(`subMenu:${E.value.uid}`);
    u || R(_, "can not inject sub menu");
    const q = b({}), T = b({});
    let d;
    const k = b(!1), L = b(), z = b(null), N = a(() => m.value === "horizontal" && M.value ? "bottom-start" : "right-start"), O = a(() => m.value === "horizontal" && M.value || m.value === "vertical" && !o.props.collapse ? n.expandCloseIcon && n.expandOpenIcon ? p.value ? n.expandOpenIcon : n.expandCloseIcon : ce : n.collapseCloseIcon && n.collapseOpenIcon ? p.value ? n.collapseOpenIcon : n.collapseCloseIcon : pe), M = a(() => u.level === 0), S = a(() => {
      const e = n.teleported;
      return e === void 0 ? M.value : e;
    }), U = a(() => o.props.collapse ? `${i.namespace.value}-zoom-in-left` : `${i.namespace.value}-zoom-in-top`), V = a(() => m.value === "horizontal" && M.value ? [
      "bottom-start",
      "bottom-end",
      "top-start",
      "top-end",
      "right-start",
      "left-start"
    ] : [
      "right-start",
      "right",
      "right-end",
      "left-start",
      "bottom-start",
      "bottom-end",
      "top-start",
      "top-end"
    ]), p = a(() => o.openedMenus.includes(n.index)), w = a(() => {
      let e = !1;
      return Object.values(q.value).forEach((t) => {
        t.active && (e = !0);
      }), Object.values(T.value).forEach((t) => {
        t.active && (e = !0);
      }), e;
    }), m = a(() => o.props.mode), C = ee({
      index: n.index,
      indexPath: h,
      active: w
    }), A = me(o.props, u.level + 1), Z = a(() => {
      var e;
      return (e = n.popperOffset) != null ? e : o.props.popperOffset;
    }), j = a(() => {
      var e;
      return (e = n.popperClass) != null ? e : o.props.popperClass;
    }), G = a(() => {
      var e;
      return (e = n.showTimeout) != null ? e : o.props.showTimeout;
    }), J = a(() => {
      var e;
      return (e = n.hideTimeout) != null ? e : o.props.hideTimeout;
    }), K = /* @__PURE__ */ l(() => {
      var e, t, r;
      return (r = (t = (e = z.value) == null ? void 0 : e.popperRef) == null ? void 0 : t.popperInstanceRef) == null ? void 0 : r.destroy();
    }, "doDestroy"), Q = /* @__PURE__ */ l((e) => {
      e || K();
    }, "handleCollapseToggle"), B = /* @__PURE__ */ l(() => {
      o.props.menuTrigger === "hover" && o.props.mode === "horizontal" || o.props.collapse && o.props.mode === "vertical" || n.disabled || o.handleSubMenuClick({
        index: n.index,
        indexPath: h.value,
        active: w.value
      });
    }, "handleClick"), I = /* @__PURE__ */ l((e, t = G.value) => {
      var r;
      if (e.type !== "focus") {
        if (o.props.menuTrigger === "click" && o.props.mode === "horizontal" || !o.props.collapse && o.props.mode === "vertical" || n.disabled) {
          u.mouseInChild.value = !0;
          return;
        }
        u.mouseInChild.value = !0, d == null || d(), { stop: d } = D(() => {
          o.openMenu(n.index, h.value);
        }, t), S.value && ((r = E.value.vnode.el) == null || r.dispatchEvent(new MouseEvent("mouseenter")));
      }
    }, "handleMouseenter"), y = /* @__PURE__ */ l((e = !1) => {
      var t;
      if (o.props.menuTrigger === "click" && o.props.mode === "horizontal" || !o.props.collapse && o.props.mode === "vertical") {
        u.mouseInChild.value = !1;
        return;
      }
      d == null || d(), u.mouseInChild.value = !1, { stop: d } = D(() => !k.value && o.closeMenu(n.index, h.value), J.value), S.value && e && ((t = u.handleMouseleave) == null || t.call(u, !0));
    }, "handleMouseleave");
    oe(() => o.props.collapse, (e) => Q(!!e));
    {
      const e = /* @__PURE__ */ l((r) => {
        T.value[r.index] = r;
      }, "addSubMenu"), t = /* @__PURE__ */ l((r) => {
        delete T.value[r.index];
      }, "removeSubMenu");
      ne(`subMenu:${g.uid}`, {
        addSubMenu: e,
        removeSubMenu: t,
        handleMouseleave: y,
        mouseInChild: k,
        level: u.level + 1
      });
    }
    return H({
      opened: p
    }), te(() => {
      o.addSubMenu(C), u.addSubMenu(C);
    }), le(() => {
      u.removeSubMenu(C), o.removeSubMenu(C);
    }), () => {
      var e;
      const t = [
        (e = c.title) == null ? void 0 : e.call(c),
        s(ve, {
          class: v.e("icon-arrow"),
          style: {
            transform: p.value ? n.expandCloseIcon && n.expandOpenIcon || n.collapseCloseIcon && n.collapseOpenIcon && o.props.collapse ? "none" : "rotateZ(180deg)" : "none"
          }
        }, {
          default: /* @__PURE__ */ l(() => be(O.value) ? s(g.appContext.components[O.value]) : s(O.value), "default")
        })
      ], r = o.isMenuPopup ? s(ie, {
        ref: z,
        visible: p.value,
        effect: "light",
        pure: !0,
        offset: Z.value,
        showArrow: !1,
        persistent: !0,
        popperClass: j.value,
        placement: N.value,
        teleported: S.value,
        fallbackPlacements: V.value,
        transition: U.value,
        gpuAcceleration: !1
      }, {
        content: /* @__PURE__ */ l(() => {
          var f;
          return s("div", {
            class: [
              i.m(m.value),
              i.m("popup-container"),
              j.value
            ],
            onMouseenter: /* @__PURE__ */ l((P) => I(P, 100), "onMouseenter"),
            onMouseleave: /* @__PURE__ */ l(() => y(!0), "onMouseleave"),
            onFocus: /* @__PURE__ */ l((P) => I(P, 100), "onFocus")
          }, [
            s("ul", {
              class: [
                i.b(),
                i.m("popup"),
                i.m(`popup-${N.value}`)
              ],
              style: A.value
            }, [(f = c.default) == null ? void 0 : f.call(c)])
          ]);
        }, "content"),
        default: /* @__PURE__ */ l(() => s("div", {
          class: v.e("title"),
          onClick: B
        }, t), "default")
      }) : s(ae, {}, [
        s("div", {
          class: v.e("title"),
          ref: L,
          onClick: B
        }, t),
        s(se, {}, {
          default: /* @__PURE__ */ l(() => {
            var f;
            return ue(s("ul", {
              role: "menu",
              class: [i.b(), i.m("inline")],
              style: A.value
            }, [(f = c.default) == null ? void 0 : f.call(c)]), [[re, p.value]]);
          }, "default")
        })
      ]);
      return s("li", {
        class: [
          v.b(),
          v.is("active", w.value),
          v.is("opened", p.value),
          v.is("disabled", n.disabled)
        ],
        role: "menuitem",
        ariaHaspopup: !0,
        ariaExpanded: p.value,
        onMouseenter: I,
        onMouseleave: /* @__PURE__ */ l(() => y(), "onMouseleave"),
        onFocus: I
      }, [r]);
    };
  }
});
export {
  ze as default,
  he as subMenuProps
};
