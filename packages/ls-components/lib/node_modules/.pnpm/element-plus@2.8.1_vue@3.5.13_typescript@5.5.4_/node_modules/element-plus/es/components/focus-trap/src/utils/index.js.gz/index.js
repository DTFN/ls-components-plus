var p = Object.defineProperty;
var o = (e, t) => p(e, "name", { value: t, configurable: !0 });
import { ref as a, onMounted as F, onBeforeUnmount as w } from "vue";
import { FOCUSOUT_PREVENTED as T, FOCUSOUT_PREVENTED_OPTS as N } from "../tokens/index.js";
const d = a(), i = a(0), l = a(0);
let c = 0;
const y = /* @__PURE__ */ o((e) => {
  const t = [], s = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: /* @__PURE__ */ o((n) => {
      const r = n.tagName === "INPUT" && n.type === "hidden";
      return n.disabled || n.hidden || r ? NodeFilter.FILTER_SKIP : n.tabIndex >= 0 || n === document.activeElement ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }, "acceptNode")
  });
  for (; s.nextNode(); )
    t.push(s.currentNode);
  return t;
}, "obtainAllFocusableElements"), m = /* @__PURE__ */ o((e, t) => {
  for (const s of e)
    if (!S(s, t))
      return s;
}, "getVisibleElement"), S = /* @__PURE__ */ o((e, t) => {
  if (process.env.NODE_ENV === "test")
    return !1;
  if (getComputedStyle(e).visibility === "hidden")
    return !0;
  for (; e; ) {
    if (t && e === t)
      return !1;
    if (getComputedStyle(e).display === "none")
      return !0;
    e = e.parentElement;
  }
  return !1;
}, "isHidden"), C = /* @__PURE__ */ o((e) => {
  const t = y(e), s = m(t, e), n = m(t.reverse(), e);
  return [s, n];
}, "getEdges"), b = /* @__PURE__ */ o((e) => e instanceof HTMLInputElement && "select" in e, "isSelectable"), L = /* @__PURE__ */ o((e, t) => {
  if (e && e.focus) {
    const s = document.activeElement;
    e.focus({ preventScroll: !0 }), l.value = window.performance.now(), e !== s && b(e) && t && e.select();
  }
}, "tryFocus");
function v(e, t) {
  const s = [...e], n = e.indexOf(t);
  return n !== -1 && s.splice(n, 1), s;
}
o(v, "removeFromStack");
const h = /* @__PURE__ */ o(() => {
  let e = [];
  return {
    push: /* @__PURE__ */ o((n) => {
      const r = e[0];
      r && n !== r && r.pause(), e = v(e, n), e.unshift(n);
    }, "push"),
    remove: /* @__PURE__ */ o((n) => {
      var r, f;
      e = v(e, n), (f = (r = e[0]) == null ? void 0 : r.resume) == null || f.call(r);
    }, "remove")
  };
}, "createFocusableStack"), I = /* @__PURE__ */ o((e, t = !1) => {
  const s = document.activeElement;
  for (const n of e)
    if (L(n, t), document.activeElement !== s)
      return;
}, "focusFirstDescendant"), O = h(), P = /* @__PURE__ */ o(() => i.value > l.value, "isFocusCausedByUserEvent"), u = /* @__PURE__ */ o(() => {
  d.value = "pointer", i.value = window.performance.now();
}, "notifyFocusReasonPointer"), E = /* @__PURE__ */ o(() => {
  d.value = "keyboard", i.value = window.performance.now();
}, "notifyFocusReasonKeydown"), U = /* @__PURE__ */ o(() => (F(() => {
  c === 0 && (document.addEventListener("mousedown", u), document.addEventListener("touchstart", u), document.addEventListener("keydown", E)), c++;
}), w(() => {
  c--, c <= 0 && (document.removeEventListener("mousedown", u), document.removeEventListener("touchstart", u), document.removeEventListener("keydown", E));
}), {
  focusReason: d,
  lastUserFocusTimestamp: i,
  lastAutomatedFocusTimestamp: l
}), "useFocusReason"), g = /* @__PURE__ */ o((e) => new CustomEvent(T, {
  ...N,
  detail: e
}), "createFocusOutPreventedEvent");
export {
  g as createFocusOutPreventedEvent,
  I as focusFirstDescendant,
  O as focusableStack,
  C as getEdges,
  m as getVisibleElement,
  P as isFocusCausedByUserEvent,
  S as isHidden,
  y as obtainAllFocusableElements,
  L as tryFocus,
  U as useFocusReason
};
