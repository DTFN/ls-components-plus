var Y = Object.defineProperty;
var t = (u, a) => Y(u, "name", { value: a, configurable: !0 });
import { computed as o } from "vue";
const M = /* @__PURE__ */ t(({
  unlinkPanels: u,
  leftDate: a,
  rightDate: r
}) => {
  const l = /* @__PURE__ */ t(() => {
    a.value = a.value.subtract(10, "year"), u.value || (r.value = r.value.subtract(10, "year"));
  }, "leftPrevYear"), v = /* @__PURE__ */ t(() => {
    u.value || (a.value = a.value.add(10, "year")), r.value = r.value.add(10, "year");
  }, "rightNextYear"), n = /* @__PURE__ */ t(() => {
    a.value = a.value.add(10, "year");
  }, "leftNextYear"), c = /* @__PURE__ */ t(() => {
    r.value = r.value.subtract(10, "year");
  }, "rightPrevYear"), s = o(() => {
    const e = Math.floor(a.value.year() / 10) * 10;
    return `${e}-${e + 9}`;
  }), d = o(() => {
    const e = Math.floor(r.value.year() / 10) * 10;
    return `${e}-${e + 9}`;
  }), y = o(() => Math.floor(a.value.year() / 10) * 10 + 9), f = o(() => Math.floor(r.value.year() / 10) * 10);
  return {
    leftPrevYear: l,
    rightNextYear: v,
    leftNextYear: n,
    rightPrevYear: c,
    leftLabel: s,
    rightLabel: d,
    leftYear: y,
    rightYear: f
  };
}, "useYearRangeHeader");
export {
  M as useYearRangeHeader
};
