var c = Object.defineProperty;
var o = (a, s) => c(a, "name", { value: s, configurable: !0 });
import { ref as u } from "vue";
const R = /* @__PURE__ */ o((a, s) => {
  const t = u(!1), n = u();
  return {
    focusStartRef: n,
    trapped: t,
    onFocusAfterReleased: /* @__PURE__ */ o((e) => {
      var r;
      ((r = e.detail) == null ? void 0 : r.focusReason) !== "pointer" && (n.value = "first", s("blur"));
    }, "onFocusAfterReleased"),
    onFocusAfterTrapped: /* @__PURE__ */ o(() => {
      s("focus");
    }, "onFocusAfterTrapped"),
    onFocusInTrap: /* @__PURE__ */ o((e) => {
      a.visible && !t.value && (e.target && (n.value = e.target), t.value = !0);
    }, "onFocusInTrap"),
    onFocusoutPrevented: /* @__PURE__ */ o((e) => {
      a.trapping || (e.detail.focusReason === "pointer" && e.preventDefault(), t.value = !1);
    }, "onFocusoutPrevented"),
    onReleaseRequested: /* @__PURE__ */ o(() => {
      t.value = !1, s("close");
    }, "onReleaseRequested")
  };
}, "usePopperContentFocusTrap");
export {
  R as usePopperContentFocusTrap
};
