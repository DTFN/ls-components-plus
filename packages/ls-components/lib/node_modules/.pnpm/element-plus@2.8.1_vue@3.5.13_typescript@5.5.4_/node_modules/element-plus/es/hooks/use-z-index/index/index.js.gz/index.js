var l = Object.defineProperty;
var t = (n, e) => l(n, "name", { value: e, configurable: !0 });
import { ref as p, getCurrentInstance as s, inject as o, computed as u, unref as v } from "vue";
import { isNumber as Z } from "../../../utils/types/index.js";
import { debugWarn as f } from "../../../utils/error/index.js";
import { isClient as y } from "../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const d = {
  current: 0
}, I = p(0), C = 2e3, x = Symbol("elZIndexContextKey"), N = Symbol("zIndexContextKey"), K = /* @__PURE__ */ t((n) => {
  const e = s() ? o(x, d) : d, a = n || (s() ? o(N, void 0) : void 0), r = u(() => {
    const c = v(a);
    return Z(c) ? c : C;
  }), i = u(() => r.value + I.value), m = /* @__PURE__ */ t(() => (e.current++, I.value = e.current, i.value), "nextZIndex");
  return !y && !o(x) && f("ZIndexInjection", `Looks like you are using server rendering, you must provide a z-index provider to ensure the hydration process to be succeed
usage: app.provide(ZINDEX_INJECTION_KEY, { current: 0 })`), {
    initialZIndex: r,
    currentZIndex: i,
    nextZIndex: m
  };
}, "useZIndex");
export {
  x as ZINDEX_INJECTION_KEY,
  C as defaultInitialZIndex,
  K as useZIndex,
  N as zIndexContextKey
};
