var K = Object.defineProperty;
var f = (s, l) => K(s, "name", { value: l, configurable: !0 });
import { defineComponent as m, inject as O, ref as y, toRef as b, openBlock as D, createBlock as F, unref as e, normalizeClass as I, withCtx as N, renderSlot as P } from "vue";
import { TOOLTIP_INJECTION_KEY as R } from "../constants/index.js";
import { useTooltipTriggerProps as j } from "../trigger/index.js";
import { whenTrigger as i } from "../utils/index.js";
import z from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as H } from "../../../../hooks/use-namespace/index/index.js";
import { composeEventHandlers as r } from "../../../../utils/dom/event/index.js";
import J from "../../../popper/src/trigger2/index.js";
const L = m({
  name: "ElTooltipTrigger"
}), S = /* @__PURE__ */ m({
  ...L,
  props: j,
  setup(s, { expose: l }) {
    const u = s, d = H("tooltip"), { controlled: v, id: T, open: C, onOpen: g, onClose: p, onToggle: c } = O(R, void 0), _ = y(null), n = /* @__PURE__ */ f(() => {
      if (e(v) || u.disabled)
        return !0;
    }, "stopWhenControlledOrDisabled"), t = b(u, "trigger"), M = r(n, i(t, "hover", g)), h = r(n, i(t, "hover", p)), k = r(n, i(t, "click", (o) => {
      o.button === 0 && c(o);
    })), E = r(n, i(t, "focus", g)), w = r(n, i(t, "focus", p)), x = r(n, i(t, "contextmenu", (o) => {
      o.preventDefault(), c(o);
    })), B = r(n, (o) => {
      const { code: a } = o;
      u.triggerKeys.includes(a) && (o.preventDefault(), c(o));
    });
    return l({
      triggerRef: _
    }), (o, a) => (D(), F(e(J), {
      id: e(T),
      "virtual-ref": o.virtualRef,
      open: e(C),
      "virtual-triggering": o.virtualTriggering,
      class: I(e(d).e("trigger")),
      onBlur: e(w),
      onClick: e(k),
      onContextmenu: e(x),
      onFocus: e(E),
      onMouseenter: e(M),
      onMouseleave: e(h),
      onKeydown: e(B)
    }, {
      default: N(() => [
        P(o.$slots, "default")
      ]),
      _: 3
    }, 8, ["id", "virtual-ref", "open", "virtual-triggering", "class", "onBlur", "onClick", "onContextmenu", "onFocus", "onMouseenter", "onMouseleave", "onKeydown"]));
  }
});
var X = /* @__PURE__ */ z(S, [["__file", "trigger.vue"]]);
export {
  X as default
};
