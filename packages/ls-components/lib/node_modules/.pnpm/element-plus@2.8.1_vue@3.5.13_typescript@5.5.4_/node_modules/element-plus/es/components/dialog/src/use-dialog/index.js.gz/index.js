var N = Object.defineProperty;
var o = (e, l) => N(e, "name", { value: l, configurable: !0 });
import { getCurrentInstance as S, ref as f, computed as b, watch as h, nextTick as Z, onMounted as q } from "vue";
import { useZIndex as G } from "../../../../hooks/use-z-index/index/index.js";
import { useId as E } from "../../../../hooks/use-id/index/index.js";
import { useGlobalConfig as j } from "../../../config-provider/src/hooks/use-global-config/index.js";
import { defaultNamespace as B } from "../../../../hooks/use-namespace/index/index.js";
import { addUnit as H } from "../../../../utils/dom/style/index.js";
import { UPDATE_MODEL_EVENT as J } from "../../../../constants/event/index.js";
import { useLockscreen as K } from "../../../../hooks/use-lockscreen/index/index.js";
import Q from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isUndefined/index.js";
import { useTimeoutFn as F, isClient as W } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const se = /* @__PURE__ */ o((e, l) => {
  var C;
  const t = S().emit, { nextZIndex: D } = G();
  let x = "";
  const O = E(), k = E(), i = f(!1), r = f(!1), c = f(!1), d = f((C = e.zIndex) != null ? C : D());
  let a, s;
  const A = j("namespace", B), P = b(() => {
    const n = {}, u = `--${A.value}-dialog`;
    return e.fullscreen || (e.top && (n[`${u}-margin-top`] = e.top), e.width && (n[`${u}-width`] = H(e.width))), n;
  }), w = b(() => e.alignCenter ? { display: "flex" } : {});
  function L() {
    t("opened");
  }
  o(L, "afterEnter");
  function M() {
    t("closed"), t(J, !1), e.destroyOnClose && (c.value = !1);
  }
  o(M, "afterLeave");
  function _() {
    t("close");
  }
  o(_, "beforeLeave");
  function I() {
    s == null || s(), a == null || a(), e.openDelay && e.openDelay > 0 ? { stop: a } = F(() => T(), e.openDelay) : T();
  }
  o(I, "open");
  function m() {
    a == null || a(), s == null || s(), e.closeDelay && e.closeDelay > 0 ? { stop: s } = F(() => y(), e.closeDelay) : y();
  }
  o(m, "close");
  function v() {
    function n(u) {
      u || (r.value = !0, i.value = !1);
    }
    o(n, "hide"), e.beforeClose ? e.beforeClose(n) : m();
  }
  o(v, "handleClose");
  function z() {
    e.closeOnClickModal && v();
  }
  o(z, "onModalClick");
  function T() {
    W && (i.value = !0);
  }
  o(T, "doOpen");
  function y() {
    i.value = !1;
  }
  o(y, "doClose");
  function U() {
    t("openAutoFocus");
  }
  o(U, "onOpenAutoFocus");
  function V() {
    t("closeAutoFocus");
  }
  o(V, "onCloseAutoFocus");
  function $(n) {
    var u;
    ((u = n.detail) == null ? void 0 : u.focusReason) === "pointer" && n.preventDefault();
  }
  o($, "onFocusoutPrevented"), e.lockScroll && K(i);
  function g() {
    e.closeOnPressEscape && v();
  }
  return o(g, "onCloseRequested"), h(() => e.modelValue, (n) => {
    n ? (r.value = !1, I(), c.value = !0, d.value = Q(e.zIndex) ? D() : d.value++, Z(() => {
      t("open"), l.value && (l.value.scrollTop = 0);
    })) : i.value && m();
  }), h(() => e.fullscreen, (n) => {
    l.value && (n ? (x = l.value.style.transform, l.value.style.transform = "") : l.value.style.transform = x);
  }), q(() => {
    e.modelValue && (i.value = !0, c.value = !0, I());
  }), {
    afterEnter: L,
    afterLeave: M,
    beforeLeave: _,
    handleClose: v,
    onModalClick: z,
    close: m,
    doClose: y,
    onOpenAutoFocus: U,
    onCloseAutoFocus: V,
    onCloseRequested: g,
    onFocusoutPrevented: $,
    titleId: O,
    bodyId: k,
    closed: r,
    style: P,
    overlayDialogStyle: w,
    rendered: c,
    visible: i,
    zIndex: d
  };
}, "useDialog");
export {
  se as useDialog
};
