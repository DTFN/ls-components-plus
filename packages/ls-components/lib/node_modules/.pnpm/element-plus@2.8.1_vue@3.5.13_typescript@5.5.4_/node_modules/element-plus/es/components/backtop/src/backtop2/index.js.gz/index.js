import { defineComponent as n, computed as d, openBlock as a, createBlock as _, Transition as b, unref as o, withCtx as r, createElementBlock as C, normalizeStyle as h, normalizeClass as c, withModifiers as v, renderSlot as B, createVNode as s, createCommentVNode as E } from "vue";
import { ElIcon as N } from "../../../icon/index/index.js";
import { CaretTop as x } from "@element-plus/icons-vue";
import { backtopProps as T, backtopEmits as y } from "../backtop/index.js";
import { useBackTop as $ } from "../use-backtop/index.js";
import M from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as S } from "../../../../hooks/use-namespace/index/index.js";
const p = "ElBacktop", g = n({
  name: p
}), w = /* @__PURE__ */ n({
  ...g,
  props: T,
  emits: y,
  setup(i, { emit: m }) {
    const e = i, t = S("backtop"), { handleClick: l, visible: f } = $(e, m, p), k = d(() => ({
      right: `${e.right}px`,
      bottom: `${e.bottom}px`
    }));
    return (u, z) => (a(), _(b, {
      name: `${o(t).namespace.value}-fade-in`
    }, {
      default: r(() => [
        o(f) ? (a(), C("div", {
          key: 0,
          style: h(o(k)),
          class: c(o(t).b()),
          onClick: v(o(l), ["stop"])
        }, [
          B(u.$slots, "default", {}, () => [
            s(o(N), {
              class: c(o(t).e("icon"))
            }, {
              default: r(() => [
                s(o(x))
              ]),
              _: 1
            }, 8, ["class"])
          ])
        ], 14, ["onClick"])) : E("v-if", !0)
      ]),
      _: 3
    }, 8, ["name"]));
  }
});
var D = /* @__PURE__ */ M(w, [["__file", "backtop.vue"]]);
export {
  D as default
};
