import { defineComponent as m, inject as y, unref as r, openBlock as e, createElementBlock as o, Fragment as l, createElementVNode as a, renderList as p, createBlock as s, createVNode as d } from "vue";
import c from "../descriptions-cell/index.js";
import { descriptionsKey as f } from "../token/index.js";
import { descriptionsRowProps as _ } from "../descriptions-row/index.js";
import k from "../../../../_virtual/plugin-vue_export-helper/index.js";
const w = m({
  name: "ElDescriptionsRow"
}), g = /* @__PURE__ */ m({
  ...w,
  props: _,
  setup(E) {
    const u = y(f, {});
    return (i, b) => r(u).direction === "vertical" ? (e(), o(l, { key: 0 }, [
      a("tr", null, [
        (e(!0), o(l, null, p(i.row, (t, n) => (e(), s(r(c), {
          key: `tr1-${n}`,
          cell: t,
          tag: "th",
          type: "label"
        }, null, 8, ["cell"]))), 128))
      ]),
      a("tr", null, [
        (e(!0), o(l, null, p(i.row, (t, n) => (e(), s(r(c), {
          key: `tr2-${n}`,
          cell: t,
          tag: "td",
          type: "content"
        }, null, 8, ["cell"]))), 128))
      ])
    ], 64)) : (e(), o("tr", { key: 1 }, [
      (e(!0), o(l, null, p(i.row, (t, n) => (e(), o(l, {
        key: `tr3-${n}`
      }, [
        r(u).border ? (e(), o(l, { key: 0 }, [
          d(r(c), {
            cell: t,
            tag: "td",
            type: "label"
          }, null, 8, ["cell"]),
          d(r(c), {
            cell: t,
            tag: "td",
            type: "content"
          }, null, 8, ["cell"])
        ], 64)) : (e(), s(r(c), {
          key: 1,
          cell: t,
          tag: "td",
          type: "both"
        }, null, 8, ["cell"]))
      ], 64))), 128))
    ]));
  }
});
var $ = /* @__PURE__ */ k(g, [["__file", "descriptions-row.vue"]]);
export {
  $ as default
};
