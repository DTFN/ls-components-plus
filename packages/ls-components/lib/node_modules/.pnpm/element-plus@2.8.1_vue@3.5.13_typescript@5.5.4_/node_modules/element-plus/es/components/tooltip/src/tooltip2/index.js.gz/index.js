var N = Object.defineProperty;
var o = (d, g) => N(d, "name", { value: g, configurable: !0 });
import { defineComponent as P, ref as i, toRef as p, computed as z, provide as D, readonly as M, unref as s, watch as $, onDeactivated as K, openBlock as f, createBlock as C, withCtx as h, createVNode as k, renderSlot as E, createCommentVNode as R, createElementBlock as A, toDisplayString as V } from "vue";
import { ElPopper as F } from "../../../popper/index/index.js";
import { TOOLTIP_INJECTION_KEY as J } from "../constants/index.js";
import { useTooltipProps as U, tooltipEmits as Y, useTooltipModelToggle as j } from "../tooltip/index.js";
import q from "../trigger2/index.js";
import G from "../content2/index.js";
import Q from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { usePopperContainer as W } from "../../../../hooks/use-popper-container/index/index.js";
import { useId as X } from "../../../../hooks/use-id/index/index.js";
import { useDelayedToggle as Z } from "../../../../hooks/use-delayed-toggle/index/index.js";
import { isBoolean as _ } from "../../../../utils/types/index.js";
import x from "../../../popper/src/arrow2/index.js";
const ee = P({
  name: "ElTooltip"
}), oe = /* @__PURE__ */ P({
  ...ee,
  props: U,
  emits: Y,
  setup(d, { expose: g, emit: l }) {
    const r = d;
    W();
    const I = X(), u = i(), m = i(), w = /* @__PURE__ */ o(() => {
      var e;
      const n = s(u);
      n && ((e = n.popperInstanceRef) == null || e.update());
    }, "updatePopper"), t = i(!1), a = i(), { show: O, hide: c, hasUpdateHandler: B } = j({
      indicator: t,
      toggleReason: a
    }), { onOpen: v, onClose: b } = Z({
      showAfter: p(r, "showAfter"),
      hideAfter: p(r, "hideAfter"),
      autoClose: p(r, "autoClose"),
      open: O,
      close: c
    }), H = z(() => _(r.visible) && !B.value);
    D(J, {
      controlled: H,
      id: I,
      open: M(t),
      trigger: p(r, "trigger"),
      onOpen: /* @__PURE__ */ o((e) => {
        v(e);
      }, "onOpen"),
      onClose: /* @__PURE__ */ o((e) => {
        b(e);
      }, "onClose"),
      onToggle: /* @__PURE__ */ o((e) => {
        s(t) ? b(e) : v(e);
      }, "onToggle"),
      onShow: /* @__PURE__ */ o(() => {
        l("show", a.value);
      }, "onShow"),
      onHide: /* @__PURE__ */ o(() => {
        l("hide", a.value);
      }, "onHide"),
      onBeforeShow: /* @__PURE__ */ o(() => {
        l("before-show", a.value);
      }, "onBeforeShow"),
      onBeforeHide: /* @__PURE__ */ o(() => {
        l("before-hide", a.value);
      }, "onBeforeHide"),
      updatePopper: w
    }), $(() => r.disabled, (e) => {
      e && t.value && (t.value = !1);
    });
    const S = /* @__PURE__ */ o((e) => {
      var n, T;
      const y = (T = (n = m.value) == null ? void 0 : n.contentRef) == null ? void 0 : T.popperContentRef, L = (e == null ? void 0 : e.relatedTarget) || document.activeElement;
      return y && y.contains(L);
    }, "isFocusInsideContent");
    return K(() => t.value && c()), g({
      popperRef: u,
      contentRef: m,
      isFocusInsideContent: S,
      updatePopper: w,
      onOpen: v,
      onClose: b,
      hide: c
    }), (e, n) => (f(), C(s(F), {
      ref_key: "popperRef",
      ref: u,
      role: e.role
    }, {
      default: h(() => [
        k(q, {
          disabled: e.disabled,
          trigger: e.trigger,
          "trigger-keys": e.triggerKeys,
          "virtual-ref": e.virtualRef,
          "virtual-triggering": e.virtualTriggering
        }, {
          default: h(() => [
            e.$slots.default ? E(e.$slots, "default", { key: 0 }) : R("v-if", !0)
          ]),
          _: 3
        }, 8, ["disabled", "trigger", "trigger-keys", "virtual-ref", "virtual-triggering"]),
        k(G, {
          ref_key: "contentRef",
          ref: m,
          "aria-label": e.ariaLabel,
          "boundaries-padding": e.boundariesPadding,
          content: e.content,
          disabled: e.disabled,
          effect: e.effect,
          enterable: e.enterable,
          "fallback-placements": e.fallbackPlacements,
          "hide-after": e.hideAfter,
          "gpu-acceleration": e.gpuAcceleration,
          offset: e.offset,
          persistent: e.persistent,
          "popper-class": e.popperClass,
          "popper-style": e.popperStyle,
          placement: e.placement,
          "popper-options": e.popperOptions,
          pure: e.pure,
          "raw-content": e.rawContent,
          "reference-el": e.referenceEl,
          "trigger-target-el": e.triggerTargetEl,
          "show-after": e.showAfter,
          strategy: e.strategy,
          teleported: e.teleported,
          transition: e.transition,
          "virtual-triggering": e.virtualTriggering,
          "z-index": e.zIndex,
          "append-to": e.appendTo
        }, {
          default: h(() => [
            E(e.$slots, "content", {}, () => [
              e.rawContent ? (f(), A("span", {
                key: 0,
                innerHTML: e.content
              }, null, 8, ["innerHTML"])) : (f(), A("span", { key: 1 }, V(e.content), 1))
            ]),
            e.showArrow ? (f(), C(s(x), {
              key: 0,
              "arrow-offset": e.arrowOffset
            }, null, 8, ["arrow-offset"])) : R("v-if", !0)
          ]),
          _: 3
        }, 8, ["aria-label", "boundaries-padding", "content", "disabled", "effect", "enterable", "fallback-placements", "hide-after", "gpu-acceleration", "offset", "persistent", "popper-class", "popper-style", "placement", "popper-options", "pure", "raw-content", "reference-el", "trigger-target-el", "show-after", "strategy", "teleported", "transition", "virtual-triggering", "z-index", "append-to"])
      ]),
      _: 3
    }, 8, ["role"]));
  }
});
var ce = /* @__PURE__ */ Q(oe, [["__file", "tooltip.vue"]]);
export {
  ce as default
};
