var N = Object.defineProperty;
var b = (r, a) => N(r, "name", { value: a, configurable: !0 });
import { defineComponent as w, useSlots as q, computed as C, ref as u, provide as V, openBlock as h, createBlock as k, unref as e, withCtx as l, createVNode as p, Transition as O, withDirectives as j, createElementVNode as K, normalizeClass as U, normalizeStyle as G, mergeProps as H, createSlots as J, renderSlot as t, createCommentVNode as Q, vShow as W } from "vue";
import { ElOverlay as X } from "../../../overlay/index/index.js";
import { ElTeleport as Y } from "../../../teleport/index/index.js";
import Z from "../dialog-content2/index.js";
import { dialogInjectionKey as _ } from "../constants/index.js";
import { dialogProps as x, dialogEmits as ee } from "../dialog/index.js";
import { useDialog as oe } from "../use-dialog/index.js";
import le from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useDeprecated as te } from "../../../../hooks/use-deprecated/index/index.js";
import { useNamespace as re } from "../../../../hooks/use-namespace/index/index.js";
import { useSameTarget as ae } from "../../../../hooks/use-same-target/index/index.js";
import se from "../../../focus-trap/src/focus-trap/index.js";
const ne = w({
  name: "ElDialog",
  inheritAttrs: !1
}), ie = /* @__PURE__ */ w({
  ...ne,
  props: x,
  emits: ee,
  setup(r, { expose: a }) {
    const s = r, A = q();
    te({
      scope: "el-dialog",
      from: "the title slot",
      replacement: "the header slot",
      version: "3.0.0",
      ref: "https://element-plus.org/en-US/component/dialog.html#slots"
    }, C(() => !!A.title));
    const n = re("dialog"), m = u(), E = u(), i = u(), {
      visible: d,
      titleId: c,
      bodyId: v,
      style: R,
      overlayDialogStyle: F,
      rendered: g,
      zIndex: T,
      afterEnter: P,
      afterLeave: S,
      beforeLeave: $,
      handleClose: y,
      onModalClick: D,
      onOpenAutoFocus: L,
      onCloseAutoFocus: M,
      onCloseRequested: I,
      onFocusoutPrevented: z
    } = oe(s, m);
    V(_, {
      dialogRef: m,
      headerRef: E,
      bodyId: v,
      ns: n,
      rendered: g,
      style: R
    });
    const f = ae(D), B = C(() => s.draggable && !s.fullscreen);
    return a({
      visible: d,
      dialogContentRef: i,
      resetPosition: /* @__PURE__ */ b(() => {
        var o;
        (o = i.value) == null || o.resetPosition();
      }, "resetPosition")
    }), (o, fe) => (h(), k(e(Y), {
      to: o.appendTo,
      disabled: o.appendTo !== "body" ? !1 : !o.appendToBody
    }, {
      default: l(() => [
        p(O, {
          name: "dialog-fade",
          onAfterEnter: e(P),
          onAfterLeave: e(S),
          onBeforeLeave: e($),
          persisted: ""
        }, {
          default: l(() => [
            j(p(e(X), {
              "custom-mask-event": "",
              mask: o.modal,
              "overlay-class": o.modalClass,
              "z-index": e(T)
            }, {
              default: l(() => [
                K("div", {
                  role: "dialog",
                  "aria-modal": "true",
                  "aria-label": o.title || void 0,
                  "aria-labelledby": o.title ? void 0 : e(c),
                  "aria-describedby": e(v),
                  class: U(`${e(n).namespace.value}-overlay-dialog`),
                  style: G(e(F)),
                  onClick: e(f).onClick,
                  onMousedown: e(f).onMousedown,
                  onMouseup: e(f).onMouseup
                }, [
                  p(e(se), {
                    loop: "",
                    trapped: e(d),
                    "focus-start-el": "container",
                    onFocusAfterTrapped: e(L),
                    onFocusAfterReleased: e(M),
                    onFocusoutPrevented: e(z),
                    onReleaseRequested: e(I)
                  }, {
                    default: l(() => [
                      e(g) ? (h(), k(Z, H({
                        key: 0,
                        ref_key: "dialogContentRef",
                        ref: i
                      }, o.$attrs, {
                        center: o.center,
                        "align-center": o.alignCenter,
                        "close-icon": o.closeIcon,
                        draggable: e(B),
                        overflow: o.overflow,
                        fullscreen: o.fullscreen,
                        "show-close": o.showClose,
                        title: o.title,
                        "aria-level": o.headerAriaLevel,
                        onClose: e(y)
                      }), J({
                        header: l(() => [
                          o.$slots.title ? t(o.$slots, "title", { key: 1 }) : t(o.$slots, "header", {
                            key: 0,
                            close: e(y),
                            titleId: e(c),
                            titleClass: e(n).e("title")
                          })
                        ]),
                        default: l(() => [
                          t(o.$slots, "default")
                        ]),
                        _: 2
                      }, [
                        o.$slots.footer ? {
                          name: "footer",
                          fn: l(() => [
                            t(o.$slots, "footer")
                          ])
                        } : void 0
                      ]), 1040, ["center", "align-center", "close-icon", "draggable", "overflow", "fullscreen", "show-close", "title", "aria-level", "onClose"])) : Q("v-if", !0)
                    ]),
                    _: 3
                  }, 8, ["trapped", "onFocusAfterTrapped", "onFocusAfterReleased", "onFocusoutPrevented", "onReleaseRequested"])
                ], 46, ["aria-label", "aria-labelledby", "aria-describedby", "onClick", "onMousedown", "onMouseup"])
              ]),
              _: 3
            }, 8, ["mask", "overlay-class", "z-index"]), [
              [W, e(d)]
            ])
          ]),
          _: 3
        }, 8, ["onAfterEnter", "onAfterLeave", "onBeforeLeave"])
      ]),
      _: 3
    }, 8, ["to", "disabled"]));
  }
});
var Ee = /* @__PURE__ */ le(ie, [["__file", "dialog.vue"]]);
export {
  Ee as default
};
