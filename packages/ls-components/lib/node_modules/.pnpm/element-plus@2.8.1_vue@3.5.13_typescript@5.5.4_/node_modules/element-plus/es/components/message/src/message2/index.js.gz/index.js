var A = Object.defineProperty;
var a = (c, f) => A(c, "name", { value: f, configurable: !0 });
import { defineComponent as B, ref as g, computed as n, onMounted as F, watch as Z, openBlock as r, createBlock as l, Transition as G, unref as o, withCtx as C, withDirectives as P, createElementVNode as E, normalizeClass as i, normalizeStyle as U, createCommentVNode as p, resolveDynamicComponent as _, renderSlot as j, createElementBlock as M, toDisplayString as q, Fragment as J, withModifiers as K, createVNode as Q, vShow as W } from "vue";
import { useEventListener as X, useResizeObserver as Y } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { ElBadge as x } from "../../../badge/index/index.js";
import { ElIcon as w } from "../../../icon/index/index.js";
import { messageProps as ee, messageEmits as oe } from "../message/index.js";
import { getLastOffset as te, getOffsetOrSpace as se } from "../instance/index.js";
import ne from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { TypeComponentsMap as L, TypeComponents as re } from "../../../../utils/vue/icon/index.js";
import { useGlobalComponentSettings as ae } from "../../../config-provider/src/hooks/use-global-config/index.js";
import { EVENT_CODE as ie } from "../../../../constants/aria/index.js";
import { useTimeoutFn as le } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const me = B({
  name: "ElMessage"
}), ue = /* @__PURE__ */ B({
  ...me,
  props: ee,
  emits: oe,
  setup(c, { expose: f }) {
    const t = c, { Close: S } = re, { ns: s, zIndex: N } = ae("message"), { currentZIndex: O, nextZIndex: z } = N, d = g(), m = g(!1), h = g(0);
    let v;
    const I = n(() => t.type ? t.type === "error" ? "danger" : t.type : "info"), D = n(() => {
      const e = t.type;
      return { [s.bm("icon", e)]: e && L[e] };
    }), k = n(() => t.icon || L[t.type] || ""), R = n(() => te(t.id)), T = n(() => se(t.id, t.offset) + R.value), V = n(() => h.value + T.value), $ = n(() => ({
      top: `${T.value}px`,
      zIndex: O.value
    }));
    function y() {
      t.duration !== 0 && ({ stop: v } = le(() => {
        u();
      }, t.duration));
    }
    a(y, "startTimer");
    function b() {
      v == null || v();
    }
    a(b, "clearTimer");
    function u() {
      m.value = !1;
    }
    a(u, "close");
    function H({ code: e }) {
      e === ie.esc && u();
    }
    return a(H, "keydown"), F(() => {
      y(), z(), m.value = !0;
    }), Z(() => t.repeatNum, () => {
      b(), y();
    }), X(document, "keydown", H), Y(d, () => {
      h.value = d.value.getBoundingClientRect().height;
    }), f({
      visible: m,
      bottom: V,
      close: u
    }), (e, pe) => (r(), l(G, {
      name: o(s).b("fade"),
      onBeforeLeave: e.onClose,
      onAfterLeave: /* @__PURE__ */ a((ce) => e.$emit("destroy"), "onAfterLeave"),
      persisted: ""
    }, {
      default: C(() => [
        P(E("div", {
          id: e.id,
          ref_key: "messageRef",
          ref: d,
          class: i([
            o(s).b(),
            { [o(s).m(e.type)]: e.type },
            o(s).is("center", e.center),
            o(s).is("closable", e.showClose),
            o(s).is("plain", e.plain),
            e.customClass
          ]),
          style: U(o($)),
          role: "alert",
          onMouseenter: b,
          onMouseleave: y
        }, [
          e.repeatNum > 1 ? (r(), l(o(x), {
            key: 0,
            value: e.repeatNum,
            type: o(I),
            class: i(o(s).e("badge"))
          }, null, 8, ["value", "type", "class"])) : p("v-if", !0),
          o(k) ? (r(), l(o(w), {
            key: 1,
            class: i([o(s).e("icon"), o(D)])
          }, {
            default: C(() => [
              (r(), l(_(o(k))))
            ]),
            _: 1
          }, 8, ["class"])) : p("v-if", !0),
          j(e.$slots, "default", {}, () => [
            e.dangerouslyUseHTMLString ? (r(), M(J, { key: 1 }, [
              p(" Caution here, message could've been compromised, never use user's input as message "),
              E("p", {
                class: i(o(s).e("content")),
                innerHTML: e.message
              }, null, 10, ["innerHTML"])
            ], 2112)) : (r(), M("p", {
              key: 0,
              class: i(o(s).e("content"))
            }, q(e.message), 3))
          ]),
          e.showClose ? (r(), l(o(w), {
            key: 2,
            class: i(o(s).e("closeBtn")),
            onClick: K(u, ["stop"])
          }, {
            default: C(() => [
              Q(o(S))
            ]),
            _: 1
          }, 8, ["class", "onClick"])) : p("v-if", !0)
        ], 46, ["id"]), [
          [W, m.value]
        ])
      ]),
      _: 3
    }, 8, ["name", "onBeforeLeave", "onAfterLeave"]));
  }
});
var we = /* @__PURE__ */ ne(ue, [["__file", "message.vue"]]);
export {
  we as default
};
