var c = Object.defineProperty;
var u = (e, s) => c(e, "name", { value: s, configurable: !0 });
const o = /* @__PURE__ */ u((e) => {
  const s = (e || "").split(":");
  if (s.length >= 2) {
    let t = Number.parseInt(s[0], 10);
    const r = Number.parseInt(s[1], 10), n = e.toUpperCase();
    return n.includes("AM") && t === 12 ? t = 0 : n.includes("PM") && t !== 12 && (t += 12), {
      hours: t,
      minutes: r
    };
  }
  return null;
}, "parseTime"), p = /* @__PURE__ */ u((e, s) => {
  const t = o(e);
  if (!t)
    return -1;
  const r = o(s);
  if (!r)
    return -1;
  const n = t.minutes + t.hours * 60, i = r.minutes + r.hours * 60;
  return n === i ? 0 : n > i ? 1 : -1;
}, "compareTime"), m = /* @__PURE__ */ u((e) => `${e}`.padStart(2, "0"), "padTime"), a = /* @__PURE__ */ u((e) => `${m(e.hours)}:${m(e.minutes)}`, "formatTime"), h = /* @__PURE__ */ u((e, s) => {
  const t = o(e);
  if (!t)
    return "";
  const r = o(s);
  if (!r)
    return "";
  const n = {
    hours: t.hours,
    minutes: t.minutes
  };
  return n.minutes += r.minutes, n.hours += r.hours, n.hours += Math.floor(n.minutes / 60), n.minutes = n.minutes % 60, a(n);
}, "nextTime");
export {
  p as compareTime,
  a as formatTime,
  h as nextTime,
  m as padTime,
  o as parseTime
};
