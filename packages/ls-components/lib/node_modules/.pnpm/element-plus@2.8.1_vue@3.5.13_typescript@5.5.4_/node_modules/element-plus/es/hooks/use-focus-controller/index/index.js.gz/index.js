var h = Object.defineProperty;
var l = (u, c) => h(u, "name", { value: c, configurable: !0 });
import { getCurrentInstance as b, shallowRef as F, ref as _, watch as w, onMounted as x } from "vue";
import { useEventListener as o } from "../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { isFunction as m } from "../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isElement as C } from "../../../utils/types/index.js";
function y(u, {
  beforeFocus: c,
  afterFocus: i,
  beforeBlur: f,
  afterBlur: d
} = {}) {
  const p = b(), { emit: v } = p, t = F(), r = _(!1), a = /* @__PURE__ */ l((e) => {
    m(c) && c(e) || r.value || (r.value = !0, v("focus", e), i == null || i());
  }, "handleFocus"), s = /* @__PURE__ */ l((e) => {
    var n;
    m(f) && f(e) || e.relatedTarget && ((n = t.value) != null && n.contains(e.relatedTarget)) || (r.value = !1, v("blur", e), d == null || d());
  }, "handleBlur"), E = /* @__PURE__ */ l(() => {
    var e, n;
    (e = t.value) != null && e.contains(document.activeElement) && t.value !== document.activeElement || (n = u.value) == null || n.focus();
  }, "handleClick");
  return w(t, (e) => {
    e && e.setAttribute("tabindex", "-1");
  }), o(t, "focus", a, !0), o(t, "blur", s, !0), o(t, "click", E, !0), process.env.NODE_ENV === "test" && x(() => {
    const e = C(u.value) ? u.value : document.querySelector("input,textarea");
    e && (o(e, "focus", a, !0), o(e, "blur", s, !0));
  }), {
    isFocused: r,
    wrapperRef: t,
    handleFocus: a,
    handleBlur: s
  };
}
l(y, "useFocusController");
export {
  y as useFocusController
};
