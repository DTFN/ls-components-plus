var b = Object.defineProperty;
var e = (t, r) => b(t, "name", { value: r, configurable: !0 });
import { ref as f, watch as S } from "vue";
import { makeList as v } from "../../utils/index.js";
const m = /* @__PURE__ */ e((t) => {
  const r = /* @__PURE__ */ e((u, a) => u || a, "trueOrNumber"), n = /* @__PURE__ */ e((u) => u !== !0, "getNumber");
  return t.map(r).filter(n);
}, "makeAvailableArr"), V = /* @__PURE__ */ e((t, r, n) => ({
  getHoursList: /* @__PURE__ */ e((i, o) => v(24, t && (() => t == null ? void 0 : t(i, o))), "getHoursList"),
  getMinutesList: /* @__PURE__ */ e((i, o, c) => v(60, r && (() => r == null ? void 0 : r(i, o, c))), "getMinutesList"),
  getSecondsList: /* @__PURE__ */ e((i, o, c, s) => v(60, n && (() => n == null ? void 0 : n(i, o, c, s))), "getSecondsList")
}), "getTimeLists"), p = /* @__PURE__ */ e((t, r, n) => {
  const { getHoursList: u, getMinutesList: a, getSecondsList: L } = V(t, r, n);
  return {
    getAvailableHours: /* @__PURE__ */ e((s, l) => m(u(s, l)), "getAvailableHours"),
    getAvailableMinutes: /* @__PURE__ */ e((s, l, g) => m(a(s, l, g)), "getAvailableMinutes"),
    getAvailableSeconds: /* @__PURE__ */ e((s, l, g, A) => m(L(s, l, g, A)), "getAvailableSeconds")
  };
}, "buildAvailableTimeSlotGetter"), N = /* @__PURE__ */ e((t) => {
  const r = f(t.parsedValue);
  return S(() => t.visible, (n) => {
    n || (r.value = t.parsedValue);
  }), r;
}, "useOldValue");
export {
  p as buildAvailableTimeSlotGetter,
  V as getTimeLists,
  N as useOldValue
};
