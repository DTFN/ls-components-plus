var ee = Object.defineProperty;
var s = (i, n) => ee(i, "name", { value: n, configurable: !0 });
import { ref as o, watchEffect as b, watch as B, unref as z, computed as u, onMounted as te, nextTick as ie } from "vue";
import { useEventListener as F, useResizeObserver as _ } from "../../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { useFormSize as le } from "../../../../form/src/hooks/use-form-common-props/index.js";
function he(i, n, h, l) {
  const V = o(!1), Y = o(null), R = o(!1), A = /* @__PURE__ */ s((e) => {
    R.value = e;
  }, "setDragVisible"), g = o({
    width: null,
    height: null,
    headerHeight: null
  }), K = o(!1), X = {
    display: "inline-block",
    verticalAlign: "middle"
  }, y = o(), p = o(0), w = o(0), v = o(0), m = o(0), N = o(0);
  b(() => {
    n.setHeight(i.height);
  }), b(() => {
    n.setMaxHeight(i.maxHeight);
  }), B(() => [i.currentRowKey, h.states.rowKey], ([e, t]) => {
    !z(t) || !z(e) || h.setCurrentRowKey(`${e}`);
  }, {
    immediate: !0
  }), B(() => i.data, (e) => {
    l.store.commit("setData", e);
  }, {
    immediate: !0,
    deep: !0
  }), b(() => {
    i.expandRowKeys && h.setExpandRowKeysAdapter(i.expandRowKeys);
  });
  const D = /* @__PURE__ */ s(() => {
    l.store.commit("setHoverRow", null), l.hoverState && (l.hoverState = null);
  }, "handleMouseLeave"), T = /* @__PURE__ */ s((e, t) => {
    const { pixelX: r, pixelY: a } = t;
    Math.abs(r) >= Math.abs(a) && (l.refs.bodyWrapper.scrollLeft += t.pixelX / 5);
  }, "handleHeaderFooterMousewheel"), $ = u(() => i.height || i.maxHeight || h.states.fixedColumns.value.length > 0 || h.states.rightFixedColumns.value.length > 0), k = u(() => ({
    width: n.bodyWidth.value ? `${n.bodyWidth.value}px` : ""
  })), W = /* @__PURE__ */ s(() => {
    $.value && n.updateElsHeight(), n.updateColumnsWidth(), requestAnimationFrame(C);
  }, "doLayout");
  te(async () => {
    await ie(), h.updateColumns(), U(), requestAnimationFrame(W);
    const e = l.vnode.el, t = l.refs.headerWrapper;
    i.flexible && e && e.parentElement && (e.parentElement.style.minWidth = "0"), g.value = {
      width: y.value = e.offsetWidth,
      height: e.offsetHeight,
      headerHeight: i.showHeader && t ? t.offsetHeight : null
    }, h.states.columns.value.forEach((r) => {
      r.filteredValue && r.filteredValue.length && l.store.commit("filterChange", {
        column: r,
        values: r.filteredValue,
        silent: !0
      });
    }), l.$ready = !0;
  });
  const P = /* @__PURE__ */ s((e, t) => {
    if (!e)
      return;
    const r = Array.from(e.classList).filter((a) => !a.startsWith("is-scrolling-"));
    r.push(n.scrollX.value ? t : "is-scrolling-none"), e.className = r.join(" ");
  }, "setScrollClassByEl"), H = /* @__PURE__ */ s((e) => {
    const { tableWrapper: t } = l.refs;
    P(t, e);
  }, "setScrollClass"), q = /* @__PURE__ */ s((e) => {
    const { tableWrapper: t } = l.refs;
    return !!(t && t.classList.contains(e));
  }, "hasScrollClass"), C = /* @__PURE__ */ s(function() {
    if (!l.refs.scrollBarRef)
      return;
    if (!n.scrollX.value) {
      const x = "is-scrolling-none";
      q(x) || H(x);
      return;
    }
    const e = l.refs.scrollBarRef.wrapRef;
    if (!e)
      return;
    const { scrollLeft: t, offsetWidth: r, scrollWidth: a } = e, { headerWrapper: c, footerWrapper: f } = l.refs;
    c && (c.scrollLeft = t), f && (f.scrollLeft = t);
    const L = a - r - 1;
    t >= L ? H("is-scrolling-right") : H(t === 0 ? "is-scrolling-left" : "is-scrolling-middle");
  }, "syncPosition"), U = /* @__PURE__ */ s(() => {
    l.refs.scrollBarRef && (l.refs.scrollBarRef.wrapRef && F(l.refs.scrollBarRef.wrapRef, "scroll", C, {
      passive: !0
    }), i.fit ? _(l.vnode.el, S) : F(window, "resize", S), _(l.refs.bodyWrapper, () => {
      var e, t;
      S(), (t = (e = l.refs) == null ? void 0 : e.scrollBarRef) == null || t.update();
    }));
  }, "bindEvents"), S = /* @__PURE__ */ s(() => {
    var e, t, r, a;
    const c = l.vnode.el;
    if (!l.$ready || !c)
      return;
    let f = !1;
    const {
      width: L,
      height: x,
      headerHeight: Z
    } = g.value, M = y.value = c.offsetWidth;
    L !== M && (f = !0);
    const E = c.offsetHeight;
    (i.height || $.value) && x !== E && (f = !0);
    const d = i.tableLayout === "fixed" ? l.refs.headerWrapper : (e = l.refs.tableHeaderRef) == null ? void 0 : e.$el;
    i.showHeader && (d == null ? void 0 : d.offsetHeight) !== Z && (f = !0), p.value = ((t = l.refs.tableWrapper) == null ? void 0 : t.scrollHeight) || 0, v.value = (d == null ? void 0 : d.scrollHeight) || 0, m.value = ((r = l.refs.footerWrapper) == null ? void 0 : r.offsetHeight) || 0, N.value = ((a = l.refs.appendWrapper) == null ? void 0 : a.offsetHeight) || 0, w.value = p.value - v.value - m.value - N.value, f && (g.value = {
      width: M,
      height: E,
      headerHeight: i.showHeader && (d == null ? void 0 : d.offsetHeight) || 0
    }, W());
  }, "resizeListener"), j = le(), G = u(() => {
    const { bodyWidth: e, scrollY: t, gutterWidth: r } = n;
    return e.value ? `${e.value - (t.value ? r : 0)}px` : "";
  }), I = u(() => i.maxHeight ? "fixed" : i.tableLayout), O = u(() => {
    if (i.data && i.data.length)
      return null;
    let e = "100%";
    i.height && w.value && (e = `${w.value}px`);
    const t = y.value;
    return {
      width: t ? `${t}px` : "",
      height: e
    };
  }), J = u(() => i.height ? {
    height: Number.isNaN(Number(i.height)) ? i.height : `${i.height}px`
  } : i.maxHeight ? {
    maxHeight: Number.isNaN(Number(i.maxHeight)) ? i.maxHeight : `${i.maxHeight}px`
  } : {}), Q = u(() => i.height ? {
    height: "100%"
  } : i.maxHeight ? Number.isNaN(Number(i.maxHeight)) ? {
    maxHeight: `calc(${i.maxHeight} - ${v.value + m.value}px)`
  } : {
    maxHeight: `${i.maxHeight - v.value - m.value}px`
  } : {});
  return {
    isHidden: V,
    renderExpanded: Y,
    setDragVisible: A,
    isGroup: K,
    handleMouseLeave: D,
    handleHeaderFooterMousewheel: T,
    tableSize: j,
    emptyBlockStyle: O,
    handleFixedMousewheel: /* @__PURE__ */ s((e, t) => {
      const r = l.refs.bodyWrapper;
      if (Math.abs(t.spinY) > 0) {
        const a = r.scrollTop;
        t.pixelY < 0 && a !== 0 && e.preventDefault(), t.pixelY > 0 && r.scrollHeight - r.clientHeight > a && e.preventDefault(), r.scrollTop += Math.ceil(t.pixelY / 5);
      } else
        r.scrollLeft += Math.ceil(t.pixelX / 5);
    }, "handleFixedMousewheel"),
    resizeProxyVisible: R,
    bodyWidth: G,
    resizeState: g,
    doLayout: W,
    tableBodyStyles: k,
    tableLayout: I,
    scrollbarViewStyle: X,
    tableInnerStyle: J,
    scrollbarStyle: Q
  };
}
s(he, "useStyle");
export {
  he as default
};
