var g = Object.defineProperty;
var n = (r, l) => g(r, "name", { value: l, configurable: !0 });
import { computed as v } from "vue";
import { useFormDisabled as k } from "../../../form/src/hooks/use-form-common-props/index.js";
import { useNamespace as u } from "../../../../hooks/use-namespace/index/index.js";
import { TinyColor as V } from "../../../../../../../../@ctrl_tinycolor@3.6.1/node_modules/@ctrl/tinycolor/dist/module/index/index.js";
function a(r, l = 20) {
  return r.mix("#141414", l).toString();
}
n(a, "darken");
function x(r) {
  const l = k(), t = u("button");
  return v(() => {
    let e = {}, c = r.color;
    if (c) {
      const s = c.match(/var\((.*?)\)/);
      s && (c = window.getComputedStyle(window.document.documentElement).getPropertyValue(s[1]));
      const o = new V(c), i = r.dark ? o.tint(20).toString() : a(o, 20);
      if (r.plain)
        e = t.cssVarBlock({
          "bg-color": r.dark ? a(o, 90) : o.tint(90).toString(),
          "text-color": c,
          "border-color": r.dark ? a(o, 50) : o.tint(50).toString(),
          "hover-text-color": `var(${t.cssVarName("color-white")})`,
          "hover-bg-color": c,
          "hover-border-color": c,
          "active-bg-color": i,
          "active-text-color": `var(${t.cssVarName("color-white")})`,
          "active-border-color": i
        }), l.value && (e[t.cssVarBlockName("disabled-bg-color")] = r.dark ? a(o, 90) : o.tint(90).toString(), e[t.cssVarBlockName("disabled-text-color")] = r.dark ? a(o, 50) : o.tint(50).toString(), e[t.cssVarBlockName("disabled-border-color")] = r.dark ? a(o, 80) : o.tint(80).toString());
      else {
        const d = r.dark ? a(o, 30) : o.tint(30).toString(), m = o.isDark() ? `var(${t.cssVarName("color-white")})` : `var(${t.cssVarName("color-black")})`;
        if (e = t.cssVarBlock({
          "bg-color": c,
          "text-color": m,
          "border-color": c,
          "hover-bg-color": d,
          "hover-text-color": m,
          "hover-border-color": d,
          "active-bg-color": i,
          "active-border-color": i
        }), l.value) {
          const b = r.dark ? a(o, 50) : o.tint(50).toString();
          e[t.cssVarBlockName("disabled-bg-color")] = b, e[t.cssVarBlockName("disabled-text-color")] = r.dark ? "rgba(255, 255, 255, 0.5)" : `var(${t.cssVarName("color-white")})`, e[t.cssVarBlockName("disabled-border-color")] = b;
        }
      }
    }
    return e;
  });
}
n(x, "useButtonCustomStyle");
export {
  a as darken,
  x as useButtonCustomStyle
};
