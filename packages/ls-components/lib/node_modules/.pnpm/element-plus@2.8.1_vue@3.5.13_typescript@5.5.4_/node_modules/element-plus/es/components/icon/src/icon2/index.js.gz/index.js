import { defineComponent as t, computed as m, openBlock as p, createElementBlock as f, mergeProps as l, unref as r, renderSlot as a } from "vue";
import { iconProps as u } from "../icon/index.js";
import d from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as _ } from "../../../../hooks/use-namespace/index/index.js";
import { isUndefined as v } from "../../../../utils/types/index.js";
import { addUnit as h } from "../../../../utils/dom/style/index.js";
const k = t({
  name: "ElIcon",
  inheritAttrs: !1
}), y = /* @__PURE__ */ t({
  ...k,
  props: u,
  setup(n) {
    const s = n, c = _("icon"), i = m(() => {
      const { size: o, color: e } = s;
      return !o && !e ? {} : {
        fontSize: v(o) ? void 0 : h(o),
        "--color": e
      };
    });
    return (o, e) => (p(), f("i", l({
      class: r(c).b(),
      style: r(i)
    }, o.$attrs), [
      a(o.$slots, "default")
    ], 16));
  }
});
var U = /* @__PURE__ */ d(y, [["__file", "icon.vue"]]);
export {
  U as default
};
