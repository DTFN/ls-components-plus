var L = Object.defineProperty;
var u = (e, g) => L(e, "name", { value: g, configurable: !0 });
import { defineComponent as P, provide as H, reactive as K, resolveComponent as c, resolveDirective as A, withDirectives as k, openBlock as s, createElementBlock as n, normalizeClass as l, toHandlerKey as B, createVNode as m, withCtx as t, createElementVNode as i, withModifiers as d, renderSlot as r, createCommentVNode as a, Fragment as $, renderList as O, normalizeStyle as w, createTextVNode as V, toDisplayString as v, createBlock as f, withKeys as S, vModelText as U, resolveDynamicComponent as E, vShow as F } from "vue";
import { ElTooltip as G } from "../../../tooltip/index/index.js";
import { ElScrollbar as j } from "../../../scrollbar/index/index.js";
import { ElTag as q } from "../../../tag/index/index.js";
import { ElIcon as J } from "../../../icon/index/index.js";
import Q from "../option/index.js";
import W from "../select-dropdown/index.js";
import { useSelect as X } from "../useSelect/index.js";
import { selectKey as Y } from "../token/index.js";
import Z from "../options/index.js";
import { SelectProps as _ } from "../select/index.js";
import x from "../../../../_virtual/plugin-vue_export-helper/index.js";
import ee from "../../../../directives/click-outside/index/index.js";
import { UPDATE_MODEL_EVENT as le, CHANGE_EVENT as se } from "../../../../constants/event/index.js";
const M = "ElSelect", oe = P({
  name: M,
  componentName: M,
  components: {
    ElSelectMenu: W,
    ElOption: Q,
    ElOptions: Z,
    ElTag: q,
    ElScrollbar: j,
    ElTooltip: G,
    ElIcon: J
  },
  directives: { ClickOutside: ee },
  props: _,
  emits: [
    le,
    se,
    "remove-tag",
    "clear",
    "visible-change",
    "focus",
    "blur"
  ],
  setup(e, { emit: g }) {
    const p = X(e, g);
    return H(Y, K({
      props: e,
      states: p.states,
      optionsArray: p.optionsArray,
      handleOptionSelect: p.handleOptionSelect,
      onOptionCreate: p.onOptionCreate,
      onOptionDestroy: p.onOptionDestroy,
      selectRef: p.selectRef,
      setSelected: p.setSelected
    })), {
      ...p
    };
  }
});
function ne(e, g, p, te, ae, ie) {
  const y = c("el-tag"), T = c("el-tooltip"), C = c("el-icon"), R = c("el-option"), I = c("el-options"), z = c("el-scrollbar"), D = c("el-select-menu"), N = A("click-outside");
  return k((s(), n("div", {
    ref: "selectRef",
    class: l([e.nsSelect.b(), e.nsSelect.m(e.selectSize)]),
    [B(e.mouseEnterEventName)]: (b) => e.states.inputHovering = !0,
    onMouseleave: /* @__PURE__ */ u((b) => e.states.inputHovering = !1, "onMouseleave")
  }, [
    m(T, {
      ref: "tooltipRef",
      visible: e.dropdownMenuVisible,
      placement: e.placement,
      teleported: e.teleported,
      "popper-class": [e.nsSelect.e("popper"), e.popperClass],
      "popper-options": e.popperOptions,
      "fallback-placements": e.fallbackPlacements,
      effect: e.effect,
      pure: "",
      trigger: "click",
      transition: `${e.nsSelect.namespace.value}-zoom-in-top`,
      "stop-popper-mouse-event": !1,
      "gpu-acceleration": !1,
      persistent: e.persistent,
      onBeforeShow: e.handleMenuEnter,
      onHide: /* @__PURE__ */ u((b) => e.states.isBeforeHide = !1, "onHide")
    }, {
      default: t(() => {
        var b;
        return [
          i("div", {
            ref: "wrapperRef",
            class: l([
              e.nsSelect.e("wrapper"),
              e.nsSelect.is("focused", e.isFocused),
              e.nsSelect.is("hovering", e.states.inputHovering),
              e.nsSelect.is("filterable", e.filterable),
              e.nsSelect.is("disabled", e.selectDisabled)
            ]),
            onClick: d(e.toggleMenu, ["prevent"])
          }, [
            e.$slots.prefix ? (s(), n("div", {
              key: 0,
              ref: "prefixRef",
              class: l(e.nsSelect.e("prefix"))
            }, [
              r(e.$slots, "prefix")
            ], 2)) : a("v-if", !0),
            i("div", {
              ref: "selectionRef",
              class: l([
                e.nsSelect.e("selection"),
                e.nsSelect.is("near", e.multiple && !e.$slots.prefix && !!e.states.selected.length)
              ])
            }, [
              e.multiple ? r(e.$slots, "tag", { key: 0 }, () => [
                (s(!0), n($, null, O(e.showTagList, (o) => (s(), n("div", {
                  key: e.getValueKey(o),
                  class: l(e.nsSelect.e("selected-item"))
                }, [
                  m(y, {
                    closable: !e.selectDisabled && !o.isDisabled,
                    size: e.collapseTagSize,
                    type: e.tagType,
                    effect: e.tagEffect,
                    "disable-transitions": "",
                    style: w(e.tagStyle),
                    onClose: /* @__PURE__ */ u((h) => e.deleteTag(h, o), "onClose")
                  }, {
                    default: t(() => [
                      i("span", {
                        class: l(e.nsSelect.e("tags-text"))
                      }, [
                        r(e.$slots, "label", {
                          label: o.currentLabel,
                          value: o.value
                        }, () => [
                          V(v(o.currentLabel), 1)
                        ])
                      ], 2)
                    ]),
                    _: 2
                  }, 1032, ["closable", "size", "type", "effect", "style", "onClose"])
                ], 2))), 128)),
                e.collapseTags && e.states.selected.length > e.maxCollapseTags ? (s(), f(T, {
                  key: 0,
                  ref: "tagTooltipRef",
                  disabled: e.dropdownMenuVisible || !e.collapseTagsTooltip,
                  "fallback-placements": ["bottom", "top", "right", "left"],
                  effect: e.effect,
                  placement: "bottom",
                  teleported: e.teleported
                }, {
                  default: t(() => [
                    i("div", {
                      ref: "collapseItemRef",
                      class: l(e.nsSelect.e("selected-item"))
                    }, [
                      m(y, {
                        closable: !1,
                        size: e.collapseTagSize,
                        type: e.tagType,
                        effect: e.tagEffect,
                        "disable-transitions": "",
                        style: w(e.collapseTagStyle)
                      }, {
                        default: t(() => [
                          i("span", {
                            class: l(e.nsSelect.e("tags-text"))
                          }, " + " + v(e.states.selected.length - e.maxCollapseTags), 3)
                        ]),
                        _: 1
                      }, 8, ["size", "type", "effect", "style"])
                    ], 2)
                  ]),
                  content: t(() => [
                    i("div", {
                      ref: "tagMenuRef",
                      class: l(e.nsSelect.e("selection"))
                    }, [
                      (s(!0), n($, null, O(e.collapseTagList, (o) => (s(), n("div", {
                        key: e.getValueKey(o),
                        class: l(e.nsSelect.e("selected-item"))
                      }, [
                        m(y, {
                          class: "in-tooltip",
                          closable: !e.selectDisabled && !o.isDisabled,
                          size: e.collapseTagSize,
                          type: e.tagType,
                          effect: e.tagEffect,
                          "disable-transitions": "",
                          onClose: /* @__PURE__ */ u((h) => e.deleteTag(h, o), "onClose")
                        }, {
                          default: t(() => [
                            i("span", {
                              class: l(e.nsSelect.e("tags-text"))
                            }, [
                              r(e.$slots, "label", {
                                label: o.currentLabel,
                                value: o.value
                              }, () => [
                                V(v(o.currentLabel), 1)
                              ])
                            ], 2)
                          ]),
                          _: 2
                        }, 1032, ["closable", "size", "type", "effect", "onClose"])
                      ], 2))), 128))
                    ], 2)
                  ]),
                  _: 3
                }, 8, ["disabled", "effect", "teleported"])) : a("v-if", !0)
              ]) : a("v-if", !0),
              e.selectDisabled ? a("v-if", !0) : (s(), n("div", {
                key: 1,
                class: l([
                  e.nsSelect.e("selected-item"),
                  e.nsSelect.e("input-wrapper"),
                  e.nsSelect.is("hidden", !e.filterable)
                ])
              }, [
                k(i("input", {
                  id: e.inputId,
                  ref: "inputRef",
                  "onUpdate:modelValue": /* @__PURE__ */ u((o) => e.states.inputValue = o, "onUpdate:modelValue"),
                  type: "text",
                  name: e.name,
                  class: l([e.nsSelect.e("input"), e.nsSelect.is(e.selectSize)]),
                  disabled: e.selectDisabled,
                  autocomplete: e.autocomplete,
                  style: w(e.inputStyle),
                  role: "combobox",
                  readonly: !e.filterable,
                  spellcheck: "false",
                  "aria-activedescendant": ((b = e.hoverOption) == null ? void 0 : b.id) || "",
                  "aria-controls": e.contentId,
                  "aria-expanded": e.dropdownMenuVisible,
                  "aria-label": e.ariaLabel,
                  "aria-autocomplete": "none",
                  "aria-haspopup": "listbox",
                  onKeydown: [
                    S(d((o) => e.navigateOptions("next"), ["stop", "prevent"]), ["down"]),
                    S(d((o) => e.navigateOptions("prev"), ["stop", "prevent"]), ["up"]),
                    S(d(e.handleEsc, ["stop", "prevent"]), ["esc"]),
                    S(d(e.selectOption, ["stop", "prevent"]), ["enter"]),
                    S(d(e.deletePrevTag, ["stop"]), ["delete"])
                  ],
                  onCompositionstart: e.handleCompositionStart,
                  onCompositionupdate: e.handleCompositionUpdate,
                  onCompositionend: e.handleCompositionEnd,
                  onInput: e.onInput,
                  onClick: d(e.toggleMenu, ["stop"])
                }, null, 46, ["id", "onUpdate:modelValue", "name", "disabled", "autocomplete", "readonly", "aria-activedescendant", "aria-controls", "aria-expanded", "aria-label", "onKeydown", "onCompositionstart", "onCompositionupdate", "onCompositionend", "onInput", "onClick"]), [
                  [U, e.states.inputValue]
                ]),
                e.filterable ? (s(), n("span", {
                  key: 0,
                  ref: "calculatorRef",
                  "aria-hidden": "true",
                  class: l(e.nsSelect.e("input-calculator")),
                  textContent: v(e.states.inputValue)
                }, null, 10, ["textContent"])) : a("v-if", !0)
              ], 2)),
              e.shouldShowPlaceholder ? (s(), n("div", {
                key: 2,
                class: l([
                  e.nsSelect.e("selected-item"),
                  e.nsSelect.e("placeholder"),
                  e.nsSelect.is("transparent", !e.hasModelValue || e.expanded && !e.states.inputValue)
                ])
              }, [
                e.hasModelValue ? r(e.$slots, "label", {
                  key: 0,
                  label: e.currentPlaceholder,
                  value: e.modelValue
                }, () => [
                  i("span", null, v(e.currentPlaceholder), 1)
                ]) : (s(), n("span", { key: 1 }, v(e.currentPlaceholder), 1))
              ], 2)) : a("v-if", !0)
            ], 2),
            i("div", {
              ref: "suffixRef",
              class: l(e.nsSelect.e("suffix"))
            }, [
              e.iconComponent && !e.showClose ? (s(), f(C, {
                key: 0,
                class: l([e.nsSelect.e("caret"), e.nsSelect.e("icon"), e.iconReverse])
              }, {
                default: t(() => [
                  (s(), f(E(e.iconComponent)))
                ]),
                _: 1
              }, 8, ["class"])) : a("v-if", !0),
              e.showClose && e.clearIcon ? (s(), f(C, {
                key: 1,
                class: l([
                  e.nsSelect.e("caret"),
                  e.nsSelect.e("icon"),
                  e.nsSelect.e("clear")
                ]),
                onClick: e.handleClearClick
              }, {
                default: t(() => [
                  (s(), f(E(e.clearIcon)))
                ]),
                _: 1
              }, 8, ["class", "onClick"])) : a("v-if", !0),
              e.validateState && e.validateIcon ? (s(), f(C, {
                key: 2,
                class: l([e.nsInput.e("icon"), e.nsInput.e("validateIcon")])
              }, {
                default: t(() => [
                  (s(), f(E(e.validateIcon)))
                ]),
                _: 1
              }, 8, ["class"])) : a("v-if", !0)
            ], 2)
          ], 10, ["onClick"])
        ];
      }),
      content: t(() => [
        m(D, { ref: "menuRef" }, {
          default: t(() => [
            e.$slots.header ? (s(), n("div", {
              key: 0,
              class: l(e.nsSelect.be("dropdown", "header")),
              onClick: d(() => {
              }, ["stop"])
            }, [
              r(e.$slots, "header")
            ], 10, ["onClick"])) : a("v-if", !0),
            k(m(z, {
              id: e.contentId,
              ref: "scrollbarRef",
              tag: "ul",
              "wrap-class": e.nsSelect.be("dropdown", "wrap"),
              "view-class": e.nsSelect.be("dropdown", "list"),
              class: l([e.nsSelect.is("empty", e.filteredOptionsCount === 0)]),
              role: "listbox",
              "aria-label": e.ariaLabel,
              "aria-orientation": "vertical"
            }, {
              default: t(() => [
                e.showNewOption ? (s(), f(R, {
                  key: 0,
                  value: e.states.inputValue,
                  created: !0
                }, null, 8, ["value"])) : a("v-if", !0),
                m(I, null, {
                  default: t(() => [
                    r(e.$slots, "default")
                  ]),
                  _: 3
                })
              ]),
              _: 3
            }, 8, ["id", "wrap-class", "view-class", "class", "aria-label"]), [
              [F, e.states.options.size > 0 && !e.loading]
            ]),
            e.$slots.loading && e.loading ? (s(), n("div", {
              key: 1,
              class: l(e.nsSelect.be("dropdown", "loading"))
            }, [
              r(e.$slots, "loading")
            ], 2)) : e.loading || e.filteredOptionsCount === 0 ? (s(), n("div", {
              key: 2,
              class: l(e.nsSelect.be("dropdown", "empty"))
            }, [
              r(e.$slots, "empty", {}, () => [
                i("span", null, v(e.emptyText), 1)
              ])
            ], 2)) : a("v-if", !0),
            e.$slots.footer ? (s(), n("div", {
              key: 3,
              class: l(e.nsSelect.be("dropdown", "footer")),
              onClick: d(() => {
              }, ["stop"])
            }, [
              r(e.$slots, "footer")
            ], 10, ["onClick"])) : a("v-if", !0)
          ]),
          _: 3
        }, 512)
      ]),
      _: 3
    }, 8, ["visible", "placement", "teleported", "popper-class", "popper-options", "fallback-placements", "effect", "transition", "persistent", "onBeforeShow", "onHide"])
  ], 16, ["onMouseleave"])), [
    [N, e.handleClickOutside, e.popperRef]
  ]);
}
u(ne, "_sfc_render");
var we = /* @__PURE__ */ x(oe, [["render", ne], ["__file", "select.vue"]]);
export {
  we as default
};
