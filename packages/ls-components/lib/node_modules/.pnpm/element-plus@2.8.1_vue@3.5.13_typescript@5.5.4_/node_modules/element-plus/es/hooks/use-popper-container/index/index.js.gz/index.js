var s = Object.defineProperty;
var o = (t, e) => s(t, "name", { value: e, configurable: !0 });
import { onBeforeMount as p, computed as r } from "vue";
import { useGetDerivedNamespace as u } from "../../use-namespace/index/index.js";
import { useIdInjection as a } from "../../use-id/index/index.js";
import { isClient as d } from "../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
let c;
const m = /* @__PURE__ */ o(() => {
  const t = u(), e = a(), n = r(() => `${t.value}-popper-container-${e.prefix}`), i = r(() => `#${n.value}`);
  return {
    id: n,
    selector: i
  };
}, "usePopperContainerId"), l = /* @__PURE__ */ o((t) => {
  const e = document.createElement("div");
  return e.id = t, document.body.appendChild(e), e;
}, "createContainer"), E = /* @__PURE__ */ o(() => {
  const { id: t, selector: e } = m();
  return p(() => {
    d && (process.env.NODE_ENV === "test" || !c && !document.body.querySelector(e.value)) && (c = l(t.value));
  }), {
    id: t,
    selector: e
  };
}, "usePopperContainer");
export {
  E as usePopperContainer,
  m as usePopperContainerId
};
