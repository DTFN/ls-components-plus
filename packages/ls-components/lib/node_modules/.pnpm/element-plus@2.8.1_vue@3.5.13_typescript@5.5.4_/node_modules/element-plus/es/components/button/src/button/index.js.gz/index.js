var a = Object.defineProperty;
var t = (o, n) => a(o, "name", { value: n, configurable: !0 });
import { Loading as i } from "@element-plus/icons-vue";
import { buildProps as l, definePropType as r } from "../../../../utils/vue/props/runtime/index.js";
import { useSizeProp as p } from "../../../../hooks/use-size/index/index.js";
import { iconPropType as e } from "../../../../utils/vue/icon/index.js";
const u = [
  "default",
  "primary",
  "success",
  "warning",
  "info",
  "danger",
  "text",
  ""
], s = ["button", "submit", "reset"], g = l({
  size: p,
  disabled: Boolean,
  type: {
    type: String,
    values: u,
    default: ""
  },
  icon: {
    type: e
  },
  nativeType: {
    type: String,
    values: s,
    default: "button"
  },
  loading: Boolean,
  loadingIcon: {
    type: e,
    default: /* @__PURE__ */ t(() => i, "default")
  },
  plain: Boolean,
  text: Boolean,
  link: Boolean,
  bg: Boolean,
  autofocus: Boolean,
  round: Boolean,
  circle: Boolean,
  color: String,
  dark: Boolean,
  autoInsertSpace: {
    type: Boolean,
    default: void 0
  },
  tag: {
    type: r([String, Object]),
    default: "button"
  }
}), m = {
  click: /* @__PURE__ */ t((o) => o instanceof MouseEvent, "click")
};
export {
  m as buttonEmits,
  s as buttonNativeTypes,
  g as buttonProps,
  u as buttonTypes
};
