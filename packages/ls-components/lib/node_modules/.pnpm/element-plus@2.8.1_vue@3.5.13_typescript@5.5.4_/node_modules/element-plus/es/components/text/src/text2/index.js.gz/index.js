import { defineComponent as r, computed as m, openBlock as a, createBlock as i, resolveDynamicComponent as p, normalizeClass as c, unref as f, normalizeStyle as u, withCtx as d, renderSlot as _ } from "vue";
import { textProps as x } from "../text/index.js";
import C from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useFormSize as y } from "../../../form/src/hooks/use-form-common-props/index.js";
import { useNamespace as v } from "../../../../hooks/use-namespace/index/index.js";
import { isUndefined as z } from "../../../../utils/types/index.js";
const S = r({
  name: "ElText"
}), k = /* @__PURE__ */ r({
  ...S,
  props: x,
  setup(s) {
    const t = s, n = y(), e = v("text"), l = m(() => [
      e.b(),
      e.m(t.type),
      e.m(n.value),
      e.is("truncated", t.truncated),
      e.is("line-clamp", !z(t.lineClamp))
    ]);
    return (o, b) => (a(), i(p(o.tag), {
      class: c(f(l)),
      style: u({ "-webkit-line-clamp": o.lineClamp })
    }, {
      default: d(() => [
        _(o.$slots, "default")
      ]),
      _: 3
    }, 8, ["class", "style"]));
  }
});
var E = /* @__PURE__ */ C(k, [["__file", "text.vue"]]);
export {
  E as default
};
