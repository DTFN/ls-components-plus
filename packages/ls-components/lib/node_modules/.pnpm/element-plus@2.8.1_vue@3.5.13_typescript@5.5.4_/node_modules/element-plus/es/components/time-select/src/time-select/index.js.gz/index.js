var l = Object.defineProperty;
var e = (r, i) => l(r, "name", { value: i, configurable: !0 });
import { Clock as o, CircleClose as a } from "@element-plus/icons-vue";
import { buildProps as p, definePropType as t } from "../../../../utils/vue/props/runtime/index.js";
import { useSizeProp as n } from "../../../../hooks/use-size/index/index.js";
import { useEmptyValuesProps as m } from "../../../../hooks/use-empty-values/index/index.js";
const c = p({
  format: {
    type: String,
    default: "HH:mm"
  },
  modelValue: String,
  disabled: Boolean,
  editable: {
    type: Boolean,
    default: !0
  },
  effect: {
    type: t(String),
    default: "light"
  },
  clearable: {
    type: Boolean,
    default: !0
  },
  size: n,
  placeholder: String,
  start: {
    type: String,
    default: "09:00"
  },
  end: {
    type: String,
    default: "18:00"
  },
  step: {
    type: String,
    default: "00:30"
  },
  minTime: String,
  maxTime: String,
  name: String,
  prefixIcon: {
    type: t([String, Object]),
    default: /* @__PURE__ */ e(() => o, "default")
  },
  clearIcon: {
    type: t([String, Object]),
    default: /* @__PURE__ */ e(() => a, "default")
  },
  ...m
});
export {
  c as timeSelectProps
};
