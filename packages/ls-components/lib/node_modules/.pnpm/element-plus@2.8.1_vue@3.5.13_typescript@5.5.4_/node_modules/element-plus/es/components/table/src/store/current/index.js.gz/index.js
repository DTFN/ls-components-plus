var R = Object.defineProperty;
var l = (o, u) => R(o, "name", { value: u, configurable: !0 });
import { getCurrentInstance as C, ref as v, unref as y } from "vue";
import { getRowIdentity as f } from "../../util/index.js";
function I(o) {
  const u = C(), a = v(null), t = v(null), d = /* @__PURE__ */ l((e) => {
    u.store.assertRowKey(), a.value = e, s(e);
  }, "setCurrentRowKey"), i = /* @__PURE__ */ l(() => {
    a.value = null;
  }, "restoreCurrentRowKey"), s = /* @__PURE__ */ l((e) => {
    const { data: n, rowKey: r } = o;
    let c = null;
    r.value && (c = (y(n) || []).find((w) => f(w, r.value) === e)), t.value = c, u.emit("current-change", t.value, null);
  }, "setCurrentRowByKey");
  return {
    setCurrentRowKey: d,
    restoreCurrentRowKey: i,
    setCurrentRowByKey: s,
    updateCurrentRow: /* @__PURE__ */ l((e) => {
      const n = t.value;
      if (e && e !== n) {
        t.value = e, u.emit("current-change", t.value, n);
        return;
      }
      !e && n && (t.value = null, u.emit("current-change", null, n));
    }, "updateCurrentRow"),
    updateCurrentRowData: /* @__PURE__ */ l(() => {
      const e = o.rowKey.value, n = o.data.value || [], r = t.value;
      if (!n.includes(r) && r) {
        if (e) {
          const c = f(r, e);
          s(c);
        } else
          t.value = null;
        t.value === null && u.emit("current-change", null, r);
      } else a.value && (s(a.value), i());
    }, "updateCurrentRowData"),
    states: {
      _currentRowKey: a,
      currentRow: t
    }
  };
}
l(I, "useCurrent");
export {
  I as default
};
