var f = Object.defineProperty;
var n = (l, t) => f(l, "name", { value: t, configurable: !0 });
import { defineComponent as s, computed as b, provide as h, toRefs as v, watch as x, openBlock as _, createBlock as k, resolveDynamicComponent as g, unref as r, normalizeClass as I, withCtx as C, renderSlot as E, nextTick as y } from "vue";
import { checkboxGroupProps as G, checkboxGroupEmits as V } from "../checkbox-group/index.js";
import { checkboxGroupContextKey as w } from "../constants/index.js";
import B from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as D } from "../../../../hooks/use-namespace/index/index.js";
import { useFormItem as F, useFormItemInputId as L } from "../../../form/src/hooks/use-form-item/index.js";
import { UPDATE_MODEL_EVENT as T } from "../../../../constants/event/index.js";
import { debugWarn as z } from "../../../../utils/error/index.js";
import N from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/pick/index.js";
const P = s({
  name: "ElCheckboxGroup"
}), A = /* @__PURE__ */ s({
  ...P,
  props: G,
  emits: V,
  setup(l, { emit: t }) {
    const o = l, p = D("checkbox"), { formItem: a } = F(), { inputId: u, isLabeledByFormItem: m } = L(o, {
      formItemContext: a
    }), c = /* @__PURE__ */ n(async (e) => {
      t(T, e), await y(), t("change", e);
    }, "changeEvent"), d = b({
      get() {
        return o.modelValue;
      },
      set(e) {
        c(e);
      }
    });
    return h(w, {
      ...N(v(o), [
        "size",
        "min",
        "max",
        "disabled",
        "validateEvent",
        "fill",
        "textColor"
      ]),
      modelValue: d,
      changeEvent: c
    }), x(() => o.modelValue, () => {
      o.validateEvent && (a == null || a.validate("change").catch((e) => z(e)));
    }), (e, K) => {
      var i;
      return _(), k(g(e.tag), {
        id: r(u),
        class: I(r(p).b("group")),
        role: "group",
        "aria-label": r(m) ? void 0 : e.ariaLabel || "checkbox-group",
        "aria-labelledby": r(m) ? (i = r(a)) == null ? void 0 : i.labelId : void 0
      }, {
        default: C(() => [
          E(e.$slots, "default")
        ]),
        _: 3
      }, 8, ["id", "class", "aria-label", "aria-labelledby"]);
    };
  }
});
var J = /* @__PURE__ */ B(A, [["__file", "checkbox-group.vue"]]);
export {
  J as default
};
