var Q = Object.defineProperty;
var o = (d, s) => Q(d, "name", { value: s, configurable: !0 });
import { defineComponent as W, inject as X, ref as Y, computed as b, openBlock as w, createBlock as Z, Transition as ee, unref as n, withCtx as te, createElementBlock as ne, normalizeClass as i, createElementVNode as u, createVNode as oe, toDisplayString as A, createCommentVNode as se } from "vue";
import g from "../../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { panelTimePickerProps as ae } from "../../props/panel-time-picker/index.js";
import { useTimePanel as re } from "../../composables/use-time-panel/index.js";
import { useOldValue as le, buildAvailableTimeSlotGetter as ie } from "../../composables/use-time-picker/index.js";
import ce from "../basic-time-spinner/index.js";
import pe from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as ue } from "../../../../../hooks/use-namespace/index/index.js";
import { useLocale as de } from "../../../../../hooks/use-locale/index/index.js";
import { isUndefined as me } from "../../../../../utils/types/index.js";
import { EVENT_CODE as fe } from "../../../../../constants/aria/index.js";
const be = /* @__PURE__ */ W({
  __name: "panel-time-pick",
  props: ae,
  emits: ["pick", "select-range", "set-picker-option"],
  setup(d, { emit: s }) {
    const a = d, R = X("EP_PICKER_BASE"), {
      arrowControl: P,
      disabledHours: k,
      disabledMinutes: v,
      disabledSeconds: h,
      defaultValue: D
    } = R.props, { getAvailableHours: E, getAvailableMinutes: y, getAvailableSeconds: O } = ie(k, v, h), l = ue("time"), { t: S, lang: m } = de(), V = Y([0, 2]), N = le(a), B = b(() => me(a.actualVisible) ? `${l.namespace.value}-zoom-in-top` : ""), c = b(() => a.format.includes("ss")), x = b(() => a.format.includes("A") ? "A" : a.format.includes("a") ? "a" : ""), I = /* @__PURE__ */ o((e) => {
      const t = g(e).locale(m.value), r = f(t);
      return t.isSame(r);
    }, "isValidValue"), K = /* @__PURE__ */ o(() => {
      s("pick", N.value, !1);
    }, "handleCancel"), M = /* @__PURE__ */ o((e = !1, t = !1) => {
      t || s("pick", a.parsedValue, e);
    }, "handleConfirm"), U = /* @__PURE__ */ o((e) => {
      if (!a.visible)
        return;
      const t = f(e).millisecond(0);
      s("pick", t, !0);
    }, "handleChange"), j = /* @__PURE__ */ o((e, t) => {
      s("select-range", e, t), V.value = [e, t];
    }, "setSelectionRange"), z = /* @__PURE__ */ o((e) => {
      const t = [0, 3].concat(c.value ? [6] : []), r = ["hours", "minutes"].concat(c.value ? ["seconds"] : []), p = (t.indexOf(V.value[0]) + e + t.length) % t.length;
      C.start_emitSelectRange(r[p]);
    }, "changeSelectionRange"), H = /* @__PURE__ */ o((e) => {
      const t = e.code, { left: r, right: T, up: p, down: J } = fe;
      if ([r, T].includes(t)) {
        z(t === r ? -1 : 1), e.preventDefault();
        return;
      }
      if ([p, J].includes(t)) {
        const _ = t === p ? -1 : 1;
        C.start_scrollDown(_), e.preventDefault();
        return;
      }
    }, "handleKeydown"), { timePickerOptions: C, onSetOption: $, getAvailableTime: G } = re({
      getAvailableHours: E,
      getAvailableMinutes: y,
      getAvailableSeconds: O
    }), f = /* @__PURE__ */ o((e) => G(e, a.datetimeRole || "", !0), "getRangeAvailableTime"), L = /* @__PURE__ */ o((e) => e ? g(e, a.format).locale(m.value) : null, "parseUserInput"), q = /* @__PURE__ */ o((e) => e ? e.format(a.format) : null, "formatToString"), F = /* @__PURE__ */ o(() => g(D).locale(m.value), "getDefaultValue");
    return s("set-picker-option", ["isValidValue", I]), s("set-picker-option", ["formatToString", q]), s("set-picker-option", ["parseUserInput", L]), s("set-picker-option", ["handleKeydownInput", H]), s("set-picker-option", ["getRangeAvailableTime", f]), s("set-picker-option", ["getDefaultValue", F]), (e, t) => (w(), Z(ee, { name: n(B) }, {
      default: te(() => [
        e.actualVisible || e.visible ? (w(), ne("div", {
          key: 0,
          class: i(n(l).b("panel"))
        }, [
          u("div", {
            class: i([n(l).be("panel", "content"), { "has-seconds": n(c) }])
          }, [
            oe(ce, {
              ref: "spinner",
              role: e.datetimeRole || "start",
              "arrow-control": n(P),
              "show-seconds": n(c),
              "am-pm-mode": n(x),
              "spinner-date": e.parsedValue,
              "disabled-hours": n(k),
              "disabled-minutes": n(v),
              "disabled-seconds": n(h),
              onChange: U,
              onSetOption: n($),
              onSelectRange: j
            }, null, 8, ["role", "arrow-control", "show-seconds", "am-pm-mode", "spinner-date", "disabled-hours", "disabled-minutes", "disabled-seconds", "onSetOption"])
          ], 2),
          u("div", {
            class: i(n(l).be("panel", "footer"))
          }, [
            u("button", {
              type: "button",
              class: i([n(l).be("panel", "btn"), "cancel"]),
              onClick: K
            }, A(n(S)("el.datepicker.cancel")), 3),
            u("button", {
              type: "button",
              class: i([n(l).be("panel", "btn"), "confirm"]),
              onClick: /* @__PURE__ */ o((r) => M(), "onClick")
            }, A(n(S)("el.datepicker.confirm")), 11, ["onClick"])
          ], 2)
        ], 2)) : se("v-if", !0)
      ]),
      _: 1
    }, 8, ["name"]));
  }
});
var Pe = /* @__PURE__ */ pe(be, [["__file", "panel-time-pick.vue"]]);
export {
  Pe as default
};
