var g = Object.defineProperty;
var s = (l, r) => g(l, "name", { value: r, configurable: !0 });
import { ref as x, getCurrentInstance as m, computed as t, unref as c, inject as y, provide as I } from "vue";
import { configProviderContextKey as p } from "../../constants/index.js";
import { namespaceContextKey as _, useNamespace as b, defaultNamespace as z } from "../../../../../hooks/use-namespace/index/index.js";
import { localeContextKey as K, useLocale as G } from "../../../../../hooks/use-locale/index/index.js";
import { zIndexContextKey as N, useZIndex as O, defaultInitialZIndex as S } from "../../../../../hooks/use-z-index/index/index.js";
import { debugWarn as E } from "../../../../../utils/error/index.js";
import { SIZE_INJECTION_KEY as V } from "../../../../../hooks/use-size/index/index.js";
import { emptyValuesContextKey as Z } from "../../../../../hooks/use-empty-values/index/index.js";
import { keysOf as d } from "../../../../../utils/objects/index.js";
const v = x();
function C(l, r = void 0) {
  const o = m() ? y(p, v) : v;
  return l ? t(() => {
    var a, n;
    return (n = (a = o.value) == null ? void 0 : a[l]) != null ? n : r;
  }) : o;
}
s(C, "useGlobalConfig");
function A(l, r) {
  const o = C(), a = b(l, t(() => {
    var e;
    return ((e = o.value) == null ? void 0 : e.namespace) || z;
  })), n = G(t(() => {
    var e;
    return (e = o.value) == null ? void 0 : e.locale;
  })), i = O(t(() => {
    var e;
    return ((e = o.value) == null ? void 0 : e.zIndex) || S;
  })), u = t(() => {
    var e;
    return c(r) || ((e = o.value) == null ? void 0 : e.size) || "";
  });
  return j(t(() => c(o) || {})), {
    ns: a,
    locale: n,
    zIndex: i,
    size: u
  };
}
s(A, "useGlobalComponentSettings");
const j = /* @__PURE__ */ s((l, r, o = !1) => {
  var a;
  const n = !!m(), i = n ? C() : void 0, u = (a = void 0) != null ? a : n ? I : void 0;
  if (!u) {
    E("provideGlobalConfig", "provideGlobalConfig() can only be used inside setup().");
    return;
  }
  const e = t(() => {
    const f = c(l);
    return i != null && i.value ? k(i.value, f) : f;
  });
  return u(p, e), u(K, t(() => e.value.locale)), u(_, t(() => e.value.namespace)), u(N, t(() => e.value.zIndex)), u(V, {
    size: t(() => e.value.size || "")
  }), u(Z, t(() => ({
    emptyValues: e.value.emptyValues,
    valueOnClear: e.value.valueOnClear
  }))), (o || !v.value) && (v.value = e.value), e;
}, "provideGlobalConfig"), k = /* @__PURE__ */ s((l, r) => {
  const o = [.../* @__PURE__ */ new Set([...d(l), ...d(r)])], a = {};
  for (const n of o)
    a[n] = r[n] !== void 0 ? r[n] : l[n];
  return a;
}, "mergeConfig");
export {
  j as provideGlobalConfig,
  A as useGlobalComponentSettings,
  C as useGlobalConfig
};
