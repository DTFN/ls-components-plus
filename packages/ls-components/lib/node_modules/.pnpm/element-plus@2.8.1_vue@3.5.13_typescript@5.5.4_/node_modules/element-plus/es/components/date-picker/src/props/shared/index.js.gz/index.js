var o = Object.defineProperty;
var a = (t, n) => o(t, "name", { value: n, configurable: !0 });
import { buildProps as r, definePropType as e } from "../../../../../utils/vue/props/runtime/index.js";
import { datePickTypes as p } from "../../../../../constants/date/index.js";
const s = [
  "date",
  "dates",
  "year",
  "years",
  "month",
  "months",
  "week",
  "range"
], c = r({
  disabledDate: {
    type: e(Function)
  },
  date: {
    type: e(Object),
    required: !0
  },
  minDate: {
    type: e(Object)
  },
  maxDate: {
    type: e(Object)
  },
  parsedValue: {
    type: e([Object, Array])
  },
  rangeState: {
    type: e(Object),
    default: /* @__PURE__ */ a(() => ({
      endDate: null,
      selecting: !1
    }), "default")
  }
}), u = r({
  type: {
    type: e(String),
    required: !0,
    values: p
  },
  dateFormat: String,
  timeFormat: String
}), y = r({
  unlinkPanels: Boolean,
  parsedValue: {
    type: e(Array)
  }
}), m = /* @__PURE__ */ a((t) => ({
  type: String,
  values: s,
  default: t
}), "selectionModeWithDefault");
export {
  c as datePickerSharedProps,
  y as panelRangeSharedProps,
  u as panelSharedProps,
  m as selectionModeWithDefault
};
