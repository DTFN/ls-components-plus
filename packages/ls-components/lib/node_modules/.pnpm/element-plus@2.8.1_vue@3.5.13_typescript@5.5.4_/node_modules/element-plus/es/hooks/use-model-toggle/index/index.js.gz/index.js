var U = Object.defineProperty;
var o = (t, u) => U(t, "name", { value: u, configurable: !0 });
import { getCurrentInstance as _, computed as $, watch as h, onMounted as A } from "vue";
import { isFunction as p } from "../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { buildProp as w, definePropType as x } from "../../../utils/vue/props/runtime/index.js";
import { isBoolean as I } from "../../../utils/types/index.js";
import { isClient as c } from "../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const V = w({
  type: x(Boolean),
  default: null
}), j = w({
  type: x(Function)
}), k = /* @__PURE__ */ o((t) => {
  const u = `update:${t}`, g = `onUpdate:${t}`, B = [u], F = {
    [t]: V,
    [g]: j
  };
  return {
    useModelToggle: /* @__PURE__ */ o(({
      indicator: l,
      toggleReason: n,
      shouldHideWhenRouteChanges: v,
      shouldProceed: m,
      onShow: M,
      onHide: T
    }) => {
      const i = _(), { emit: a } = i, s = i.props, f = $(() => p(s[g])), b = $(() => s[t] === null), y = /* @__PURE__ */ o((e) => {
        l.value !== !0 && (l.value = !0, n && (n.value = e), p(M) && M(e));
      }, "doShow"), E = /* @__PURE__ */ o((e) => {
        l.value !== !1 && (l.value = !1, n && (n.value = e), p(T) && T(e));
      }, "doHide"), C = /* @__PURE__ */ o((e) => {
        if (s.disabled === !0 || p(m) && !m())
          return;
        const r = f.value && c;
        r && a(u, !0), (b.value || !r) && y(e);
      }, "show"), d = /* @__PURE__ */ o((e) => {
        if (s.disabled === !0 || !c)
          return;
        const r = f.value && c;
        r && a(u, !1), (b.value || !r) && E(e);
      }, "hide"), P = /* @__PURE__ */ o((e) => {
        I(e) && (s.disabled && e ? f.value && a(u, !1) : l.value !== e && (e ? y() : E()));
      }, "onChange"), K = /* @__PURE__ */ o(() => {
        l.value ? d() : C();
      }, "toggle");
      return h(() => s[t], P), v && i.appContext.config.globalProperties.$route !== void 0 && h(() => ({
        ...i.proxy.$route
      }), () => {
        v.value && l.value && d();
      }), A(() => {
        P(s[t]);
      }), {
        hide: d,
        show: C,
        toggle: K,
        hasUpdateHandler: f
      };
    }, "useModelToggle2"),
    useModelToggleProps: F,
    useModelToggleEmits: B
  };
}, "createModelToggleComposable");
k("modelValue");
export {
  k as createModelToggleComposable
};
