var se = Object.defineProperty;
var c = (V, s) => se(V, "name", { value: s, configurable: !0 });
import { defineComponent as q, inject as ie, toRef as Y, ref as j, computed as U, openBlock as m, createElementBlock as f, normalizeClass as t, unref as e, createElementVNode as o, renderSlot as v, Fragment as de, renderList as ce, toDisplayString as E, createCommentVNode as N, createVNode as r, withCtx as D } from "vue";
import R from "../../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { ElIcon as S } from "../../../../icon/index/index.js";
import { DArrowLeft as z, DArrowRight as F } from "@element-plus/icons-vue";
import { isValidRange as ue, getDefaultValue as pe } from "../../utils/index.js";
import { panelMonthRangeProps as me, panelMonthRangeEmits as fe } from "../../props/panel-month-range/index.js";
import { useMonthRangeHeader as ge } from "../../composables/use-month-range-header/index.js";
import { useRangePicker as he } from "../../composables/use-range-picker/index.js";
import H from "../basic-month-table/index.js";
import be from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as ve } from "../../../../../hooks/use-locale/index/index.js";
import { isArray as K } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
const _ = "year", ke = q({
  name: "DatePickerMonthRange"
}), Ce = /* @__PURE__ */ q({
  ...ke,
  props: me,
  emits: fe,
  setup(V, { emit: s }) {
    const g = V, { lang: h } = ve(), w = ie("EP_PICKER_BASE"), { shortcuts: $, disabledDate: x } = w.props, k = Y(w.props, "format"), M = Y(w.props, "defaultValue"), u = j(R().locale(h.value)), p = j(R().locale(h.value).add(1, _)), {
      minDate: C,
      maxDate: y,
      rangeState: A,
      ppNs: n,
      drpNs: b,
      handleChangeRange: B,
      handleRangeConfirm: G,
      handleShortcutClick: J,
      onSelect: L
    } = he(g, {
      defaultValue: M,
      leftDate: u,
      rightDate: p,
      unit: _,
      onParsedValueChanged: re
    }), I = U(() => !!$.length), {
      leftPrevYear: O,
      rightNextYear: Q,
      leftNextYear: W,
      rightPrevYear: X,
      leftLabel: Z,
      rightLabel: ee,
      leftYear: ae,
      rightYear: te
    } = ge({
      unlinkPanels: Y(g, "unlinkPanels"),
      leftDate: u,
      rightDate: p
    }), P = U(() => g.unlinkPanels && te.value > ae.value + 1), T = /* @__PURE__ */ c((a, l = !0) => {
      const i = a.minDate, d = a.maxDate;
      y.value === d && C.value === i || (s("calendar-change", [i.toDate(), d && d.toDate()]), y.value = d, C.value = i, l && G());
    }, "handleRangePick"), ne = /* @__PURE__ */ c(() => {
      u.value = pe(e(M), {
        lang: e(h),
        unit: "year",
        unlinkPanels: g.unlinkPanels
      })[0], p.value = u.value.add(1, "year"), s("pick", null);
    }, "handleClear"), le = /* @__PURE__ */ c((a) => K(a) ? a.map((l) => l.format(k.value)) : a.format(k.value), "formatToString"), oe = /* @__PURE__ */ c((a) => K(a) ? a.map((l) => R(l, k.value).locale(h.value)) : R(a, k.value).locale(h.value), "parseUserInput");
    function re(a, l) {
      if (g.unlinkPanels && l) {
        const i = (a == null ? void 0 : a.year()) || 0, d = l.year();
        p.value = i === d ? l.add(1, _) : l;
      } else
        p.value = u.value.add(1, _);
    }
    return c(re, "onParsedValueChanged"), s("set-picker-option", ["isValidValue", ue]), s("set-picker-option", ["formatToString", le]), s("set-picker-option", ["parseUserInput", oe]), s("set-picker-option", ["handleClear", ne]), (a, l) => (m(), f("div", {
      class: t([
        e(n).b(),
        e(b).b(),
        {
          "has-sidebar": !!a.$slots.sidebar || e(I)
        }
      ])
    }, [
      o("div", {
        class: t(e(n).e("body-wrapper"))
      }, [
        v(a.$slots, "sidebar", {
          class: t(e(n).e("sidebar"))
        }),
        e(I) ? (m(), f("div", {
          key: 0,
          class: t(e(n).e("sidebar"))
        }, [
          (m(!0), f(de, null, ce(e($), (i, d) => (m(), f("button", {
            key: d,
            type: "button",
            class: t(e(n).e("shortcut")),
            onClick: /* @__PURE__ */ c((ye) => e(J)(i), "onClick")
          }, E(i.text), 11, ["onClick"]))), 128))
        ], 2)) : N("v-if", !0),
        o("div", {
          class: t(e(n).e("body"))
        }, [
          o("div", {
            class: t([[e(n).e("content"), e(b).e("content")], "is-left"])
          }, [
            o("div", {
              class: t(e(b).e("header"))
            }, [
              o("button", {
                type: "button",
                class: t([e(n).e("icon-btn"), "d-arrow-left"]),
                onClick: e(O)
              }, [
                v(a.$slots, "prev-year", {}, () => [
                  r(e(S), null, {
                    default: D(() => [
                      r(e(z))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["onClick"]),
              a.unlinkPanels ? (m(), f("button", {
                key: 0,
                type: "button",
                disabled: !e(P),
                class: t([[
                  e(n).e("icon-btn"),
                  { [e(n).is("disabled")]: !e(P) }
                ], "d-arrow-right"]),
                onClick: e(W)
              }, [
                v(a.$slots, "next-year", {}, () => [
                  r(e(S), null, {
                    default: D(() => [
                      r(e(F))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["disabled", "onClick"])) : N("v-if", !0),
              o("div", null, E(e(Z)), 1)
            ], 2),
            r(H, {
              "selection-mode": "range",
              date: u.value,
              "min-date": e(C),
              "max-date": e(y),
              "range-state": e(A),
              "disabled-date": e(x),
              onChangerange: e(B),
              onPick: T,
              onSelect: e(L)
            }, null, 8, ["date", "min-date", "max-date", "range-state", "disabled-date", "onChangerange", "onSelect"])
          ], 2),
          o("div", {
            class: t([[e(n).e("content"), e(b).e("content")], "is-right"])
          }, [
            o("div", {
              class: t(e(b).e("header"))
            }, [
              a.unlinkPanels ? (m(), f("button", {
                key: 0,
                type: "button",
                disabled: !e(P),
                class: t([[e(n).e("icon-btn"), { "is-disabled": !e(P) }], "d-arrow-left"]),
                onClick: e(X)
              }, [
                v(a.$slots, "prev-year", {}, () => [
                  r(e(S), null, {
                    default: D(() => [
                      r(e(z))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["disabled", "onClick"])) : N("v-if", !0),
              o("button", {
                type: "button",
                class: t([e(n).e("icon-btn"), "d-arrow-right"]),
                onClick: e(Q)
              }, [
                v(a.$slots, "next-year", {}, () => [
                  r(e(S), null, {
                    default: D(() => [
                      r(e(F))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["onClick"]),
              o("div", null, E(e(ee)), 1)
            ], 2),
            r(H, {
              "selection-mode": "range",
              date: p.value,
              "min-date": e(C),
              "max-date": e(y),
              "range-state": e(A),
              "disabled-date": e(x),
              onChangerange: e(B),
              onPick: T,
              onSelect: e(L)
            }, null, 8, ["date", "min-date", "max-date", "range-state", "disabled-date", "onChangerange", "onSelect"])
          ], 2)
        ], 2)
      ], 2)
    ], 2));
  }
});
var Ae = /* @__PURE__ */ be(Ce, [["__file", "panel-month-range.vue"]]);
export {
  Ae as default
};
