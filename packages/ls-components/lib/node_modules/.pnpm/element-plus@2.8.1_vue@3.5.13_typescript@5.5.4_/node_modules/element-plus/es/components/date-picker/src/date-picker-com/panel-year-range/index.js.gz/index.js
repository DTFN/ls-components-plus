var pe = Object.defineProperty;
var i = (x, d) => pe(x, "name", { value: d, configurable: !0 });
import { defineComponent as X, ref as R, inject as H, computed as Y, useSlots as me, toRef as I, watch as J, openBlock as b, createElementBlock as h, normalizeClass as n, unref as a, createElementVNode as u, renderSlot as _, Fragment as ge, renderList as be, toDisplayString as K, createCommentVNode as $, createVNode as c, withCtx as N } from "vue";
import p from "../../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { DArrowLeft as q, DArrowRight as G } from "@element-plus/icons-vue";
import { ElIcon as S } from "../../../../icon/index/index.js";
import { panelYearRangeProps as he, panelYearRangeEmits as ke } from "../../props/panel-year-range/index.js";
import { useShortcut as ye } from "../../composables/use-shortcut/index.js";
import { useYearRangeHeader as Ce } from "../../composables/use-year-range-header/index.js";
import { isValidRange as M } from "../../utils/index.js";
import { ROOT_PICKER_INJECTION_KEY as De } from "../../constants/index.js";
import Q from "../basic-year-table/index.js";
import Pe from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as Re } from "../../../../../hooks/use-locale/index/index.js";
import { useNamespace as Ye } from "../../../../../hooks/use-namespace/index/index.js";
import { isArray as T } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
const W = "year", _e = X({
  name: "DatePickerYearRange"
}), we = /* @__PURE__ */ X({
  ..._e,
  props: he,
  emits: ke,
  setup(x, { emit: d }) {
    const k = x, { lang: y } = Re(), v = R(p().locale(y.value)), f = R(v.value.add(10, "year")), { pickerNs: l } = H(De), C = Ye("date-range-picker"), O = Y(() => !!F.length), Z = Y(() => [
      l.b(),
      C.b(),
      {
        "has-sidebar": !!me().sidebar || O.value
      }
    ]), E = Y(() => ({
      content: [l.e("content"), C.e("content"), "is-left"],
      arrowLeftBtn: [l.e("icon-btn"), "d-arrow-left"],
      arrowRightBtn: [
        l.e("icon-btn"),
        { [l.is("disabled")]: !w.value },
        "d-arrow-right"
      ]
    })), L = Y(() => ({
      content: [l.e("content"), C.e("content"), "is-right"],
      arrowLeftBtn: [
        l.e("icon-btn"),
        { "is-disabled": !w.value },
        "d-arrow-left"
      ],
      arrowRightBtn: [l.e("icon-btn"), "d-arrow-right"]
    })), ee = ye(y), {
      leftPrevYear: ae,
      rightNextYear: te,
      leftNextYear: ne,
      rightPrevYear: le,
      leftLabel: re,
      rightLabel: oe,
      leftYear: se,
      rightYear: ie
    } = Ce({
      unlinkPanels: I(k, "unlinkPanels"),
      leftDate: v,
      rightDate: f
    }), w = Y(() => k.unlinkPanels && ie.value > se.value + 1), o = R(), r = R(), D = R({
      endDate: null,
      selecting: !1
    }), j = /* @__PURE__ */ i((e) => {
      D.value = e;
    }, "handleChangeRange"), U = /* @__PURE__ */ i((e, t = !0) => {
      const s = e.minDate, g = e.maxDate;
      r.value === g && o.value === s || (d("calendar-change", [s.toDate(), g && g.toDate()]), r.value = g, o.value = s, t && ue());
    }, "handleRangePick"), ue = /* @__PURE__ */ i((e = !1) => {
      M([o.value, r.value]) && d("pick", [o.value, r.value], e);
    }, "handleConfirm"), z = /* @__PURE__ */ i((e) => {
      D.value.selecting = e, e || (D.value.endDate = null);
    }, "onSelect"), V = H("EP_PICKER_BASE"), { shortcuts: F, disabledDate: P } = V.props, B = I(V.props, "format"), m = I(V.props, "defaultValue"), A = /* @__PURE__ */ i(() => {
      let e;
      if (T(m.value)) {
        const t = p(m.value[0]);
        let s = p(m.value[1]);
        return k.unlinkPanels || (s = t.add(10, W)), [t, s];
      } else m.value ? e = p(m.value) : e = p();
      return e = e.locale(y.value), [e, e.add(10, W)];
    }, "getDefaultValue");
    J(() => m.value, (e) => {
      if (e) {
        const t = A();
        v.value = t[0], f.value = t[1];
      }
    }, { immediate: !0 }), J(() => k.parsedValue, (e) => {
      if (e && e.length === 2)
        if (o.value = e[0], r.value = e[1], v.value = o.value, k.unlinkPanels && r.value) {
          const t = o.value.year(), s = r.value.year();
          f.value = t === s ? r.value.add(10, "year") : r.value;
        } else
          f.value = v.value.add(10, "year");
      else {
        const t = A();
        o.value = void 0, r.value = void 0, v.value = t[0], f.value = t[1];
      }
    }, { immediate: !0 });
    const ce = /* @__PURE__ */ i((e) => T(e) ? e.map((t) => p(t, B.value).locale(y.value)) : p(e, B.value).locale(y.value), "parseUserInput"), de = /* @__PURE__ */ i((e) => T(e) ? e.map((t) => t.format(B.value)) : e.format(B.value), "formatToString"), ve = /* @__PURE__ */ i((e) => M(e) && (P ? !P(e[0].toDate()) && !P(e[1].toDate()) : !0), "isValidValue"), fe = /* @__PURE__ */ i(() => {
      const e = A();
      v.value = e[0], f.value = e[1], r.value = void 0, o.value = void 0, d("pick", null);
    }, "handleClear");
    return d("set-picker-option", ["isValidValue", ve]), d("set-picker-option", ["parseUserInput", ce]), d("set-picker-option", ["formatToString", de]), d("set-picker-option", ["handleClear", fe]), (e, t) => (b(), h("div", {
      class: n(a(Z))
    }, [
      u("div", {
        class: n(a(l).e("body-wrapper"))
      }, [
        _(e.$slots, "sidebar", {
          class: n(a(l).e("sidebar"))
        }),
        a(O) ? (b(), h("div", {
          key: 0,
          class: n(a(l).e("sidebar"))
        }, [
          (b(!0), h(ge, null, be(a(F), (s, g) => (b(), h("button", {
            key: g,
            type: "button",
            class: n(a(l).e("shortcut")),
            onClick: /* @__PURE__ */ i((Be) => a(ee)(s), "onClick")
          }, K(s.text), 11, ["onClick"]))), 128))
        ], 2)) : $("v-if", !0),
        u("div", {
          class: n(a(l).e("body"))
        }, [
          u("div", {
            class: n(a(E).content)
          }, [
            u("div", {
              class: n(a(C).e("header"))
            }, [
              u("button", {
                type: "button",
                class: n(a(E).arrowLeftBtn),
                onClick: a(ae)
              }, [
                _(e.$slots, "prev-year", {}, () => [
                  c(a(S), null, {
                    default: N(() => [
                      c(a(q))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["onClick"]),
              e.unlinkPanels ? (b(), h("button", {
                key: 0,
                type: "button",
                disabled: !a(w),
                class: n(a(E).arrowRightBtn),
                onClick: a(ne)
              }, [
                _(e.$slots, "next-year", {}, () => [
                  c(a(S), null, {
                    default: N(() => [
                      c(a(G))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["disabled", "onClick"])) : $("v-if", !0),
              u("div", null, K(a(re)), 1)
            ], 2),
            c(Q, {
              "selection-mode": "range",
              date: v.value,
              "min-date": o.value,
              "max-date": r.value,
              "range-state": D.value,
              "disabled-date": a(P),
              onChangerange: j,
              onPick: U,
              onSelect: z
            }, null, 8, ["date", "min-date", "max-date", "range-state", "disabled-date"])
          ], 2),
          u("div", {
            class: n(a(L).content)
          }, [
            u("div", {
              class: n(a(C).e("header"))
            }, [
              e.unlinkPanels ? (b(), h("button", {
                key: 0,
                type: "button",
                disabled: !a(w),
                class: n(a(L).arrowLeftBtn),
                onClick: a(le)
              }, [
                _(e.$slots, "prev-year", {}, () => [
                  c(a(S), null, {
                    default: N(() => [
                      c(a(q))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["disabled", "onClick"])) : $("v-if", !0),
              u("button", {
                type: "button",
                class: n(a(L).arrowRightBtn),
                onClick: a(te)
              }, [
                _(e.$slots, "next-year", {}, () => [
                  c(a(S), null, {
                    default: N(() => [
                      c(a(G))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["onClick"]),
              u("div", null, K(a(oe)), 1)
            ], 2),
            c(Q, {
              "selection-mode": "range",
              date: f.value,
              "min-date": o.value,
              "max-date": r.value,
              "range-state": D.value,
              "disabled-date": a(P),
              onChangerange: j,
              onPick: U,
              onSelect: z
            }, null, 8, ["date", "min-date", "max-date", "range-state", "disabled-date"])
          ], 2)
        ], 2)
      ], 2)
    ], 2));
  }
});
var Fe = /* @__PURE__ */ Pe(we, [["__file", "panel-year-range.vue"]]);
export {
  Fe as default
};
