var C = Object.defineProperty;
var l = (t, s) => C(t, "name", { value: s, configurable: !0 });
import { defineComponent as v, openBlock as V, createElementBlock as g, normalizeClass as n, unref as e, createElementVNode as d, withDirectives as y, isRef as w, withModifiers as f, vModelRadio as B, renderSlot as E, createTextVNode as N, toDisplayString as $, nextTick as z } from "vue";
import { radioProps as D, radioEmits as F } from "../radio/index.js";
import { useRadio as K } from "../use-radio/index.js";
import M from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as S } from "../../../../hooks/use-namespace/index/index.js";
const T = v({
  name: "ElRadio"
}), U = /* @__PURE__ */ v({
  ...T,
  props: D,
  emits: F,
  setup(t, { emit: s }) {
    const b = t, o = S("radio"), { radioRef: h, radioGroup: k, focus: c, size: _, disabled: u, modelValue: a, actualValue: i } = K(b, s);
    function R() {
      z(() => s("change", a.value));
    }
    return l(R, "handleChange"), (r, x) => {
      var m;
      return V(), g("label", {
        class: n([
          e(o).b(),
          e(o).is("disabled", e(u)),
          e(o).is("focus", e(c)),
          e(o).is("bordered", r.border),
          e(o).is("checked", e(a) === e(i)),
          e(o).m(e(_))
        ])
      }, [
        d("span", {
          class: n([
            e(o).e("input"),
            e(o).is("disabled", e(u)),
            e(o).is("checked", e(a) === e(i))
          ])
        }, [
          y(d("input", {
            ref_key: "radioRef",
            ref: h,
            "onUpdate:modelValue": /* @__PURE__ */ l((p) => w(a) ? a.value = p : null, "onUpdate:modelValue"),
            class: n(e(o).e("original")),
            value: e(i),
            name: r.name || ((m = e(k)) == null ? void 0 : m.name),
            disabled: e(u),
            checked: e(a) === e(i),
            type: "radio",
            onFocus: /* @__PURE__ */ l((p) => c.value = !0, "onFocus"),
            onBlur: /* @__PURE__ */ l((p) => c.value = !1, "onBlur"),
            onChange: R,
            onClick: f(() => {
            }, ["stop"])
          }, null, 42, ["onUpdate:modelValue", "value", "name", "disabled", "checked", "onFocus", "onBlur", "onClick"]), [
            [B, e(a)]
          ]),
          d("span", {
            class: n(e(o).e("inner"))
          }, null, 2)
        ], 2),
        d("span", {
          class: n(e(o).e("label")),
          onKeydown: f(() => {
          }, ["stop"])
        }, [
          E(r.$slots, "default", {}, () => [
            N($(r.label), 1)
          ])
        ], 42, ["onKeydown"])
      ], 2);
    };
  }
});
var I = /* @__PURE__ */ M(U, [["__file", "radio.vue"]]);
export {
  I as default
};
