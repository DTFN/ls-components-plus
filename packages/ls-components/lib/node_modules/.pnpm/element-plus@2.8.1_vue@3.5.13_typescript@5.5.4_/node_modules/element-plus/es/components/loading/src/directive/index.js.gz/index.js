var k = Object.defineProperty;
var a = (o, e) => k(o, "name", { value: e, configurable: !0 });
import { isRef as y, ref as V } from "vue";
import { isObject as x, hyphenate as E, isString as B } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { Loading as C } from "../service/index.js";
const u = Symbol("ElLoading"), i = /* @__PURE__ */ a((o, e) => {
  var t, n, v, f;
  const m = e.instance, c = /* @__PURE__ */ a((s) => x(e.value) ? e.value[s] : void 0, "getBindingProp"), _ = /* @__PURE__ */ a((s) => {
    const r = B(s) && (m == null ? void 0 : m[s]) || s;
    return r && V(r);
  }, "resolveExpression"), l = /* @__PURE__ */ a((s) => _(c(s) || o.getAttribute(`element-loading-${E(s)}`)), "getProp"), d = (t = c("fullscreen")) != null ? t : e.modifiers.fullscreen, p = {
    text: l("text"),
    svg: l("svg"),
    svgViewBox: l("svgViewBox"),
    spinner: l("spinner"),
    background: l("background"),
    customClass: l("customClass"),
    fullscreen: d,
    target: (n = c("target")) != null ? n : d ? void 0 : o,
    body: (v = c("body")) != null ? v : e.modifiers.body,
    lock: (f = c("lock")) != null ? f : e.modifiers.lock
  };
  o[u] = {
    options: p,
    instance: C(p)
  };
}, "createInstance"), L = /* @__PURE__ */ a((o, e) => {
  for (const t of Object.keys(e))
    y(e[t]) && (e[t].value = o[t]);
}, "updateOptions"), A = {
  mounted(o, e) {
    e.value && i(o, e);
  },
  updated(o, e) {
    const t = o[u];
    e.oldValue !== e.value && (e.value && !e.oldValue ? i(o, e) : e.value && e.oldValue ? x(e.value) && L(e.value, t.options) : t == null || t.instance.close());
  },
  unmounted(o) {
    var e;
    (e = o[u]) == null || e.instance.close(), o[u] = null;
  }
};
export {
  A as vLoading
};
