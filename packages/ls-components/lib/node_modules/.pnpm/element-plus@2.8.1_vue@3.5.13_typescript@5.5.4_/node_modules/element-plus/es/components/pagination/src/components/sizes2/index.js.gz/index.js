var v = Object.defineProperty;
var u = (r, t) => v(r, "name", { value: t, configurable: !0 });
import { defineComponent as g, ref as h, watch as c, computed as _, openBlock as l, createElementBlock as m, normalizeClass as C, unref as s, createVNode as b, withCtx as E, Fragment as P, renderList as k, createBlock as y } from "vue";
import { ElSelect as B, ElOption as N } from "../../../../select/index/index.js";
import { usePagination as A } from "../../usePagination/index.js";
import { paginationSizesProps as L } from "../sizes/index.js";
import q from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as F } from "../../../../../hooks/use-locale/index/index.js";
import { useNamespace as O } from "../../../../../hooks/use-namespace/index/index.js";
import j from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isEqual/index.js";
const w = g({
  name: "ElPaginationSizes"
}), x = /* @__PURE__ */ g({
  ...w,
  props: L,
  emits: ["page-size-change"],
  setup(r, { emit: t }) {
    const a = r, { t: d } = F(), z = O("pagination"), p = A(), n = h(a.pageSize);
    c(() => a.pageSizes, (e, i) => {
      if (!j(e, i) && Array.isArray(e)) {
        const o = e.includes(a.pageSize) ? a.pageSize : a.pageSizes[0];
        t("page-size-change", o);
      }
    }), c(() => a.pageSize, (e) => {
      n.value = e;
    });
    const f = _(() => a.pageSizes);
    function S(e) {
      var i;
      e !== n.value && (n.value = e, (i = p.handleSizeChange) == null || i.call(p, Number(e)));
    }
    return u(S, "handleChange"), (e, i) => (l(), m("span", {
      class: C(s(z).e("sizes"))
    }, [
      b(s(B), {
        "model-value": n.value,
        disabled: e.disabled,
        "popper-class": e.popperClass,
        size: e.size,
        teleported: e.teleported,
        "validate-event": !1,
        onChange: S
      }, {
        default: E(() => [
          (l(!0), m(P, null, k(s(f), (o) => (l(), y(s(N), {
            key: o,
            value: o,
            label: o + s(d)("el.pagination.pagesize")
          }, null, 8, ["value", "label"]))), 128))
        ]),
        _: 1
      }, 8, ["model-value", "disabled", "popper-class", "size", "teleported"])
    ], 2));
  }
});
var T = /* @__PURE__ */ q(x, [["__file", "sizes.vue"]]);
export {
  T as default
};
