var Le = Object.defineProperty;
var s = (p, n) => Le(p, "name", { value: n, configurable: !0 });
import { getCurrentInstance as Fe, toRefs as Oe, ref as r, watch as ke, unref as Ke } from "vue";
import { getKeysMap as b, toggleRowStatus as $, getRowIdentity as K, getColumnById as Me, getColumnByKey as De, orderBy as Ie } from "../../util/index.js";
import Pe from "../expand/index.js";
import Te from "../current/index.js";
import Be from "../tree/index.js";
import { hasOwn as je } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import Ne from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isEqual/index.js";
const qe = /* @__PURE__ */ s((p, n) => {
  const f = n.sortingColumn;
  return !f || typeof f.sortable == "string" ? p : Ie(p, n.sortProp, n.sortOrder, f.sortMethod, f.sortBy);
}, "sortData"), L = /* @__PURE__ */ s((p) => {
  const n = [];
  return p.forEach((f) => {
    f.children && f.children.length > 0 ? n.push.apply(n, L(f.children)) : n.push(f);
  }), n;
}, "doFlattenColumns");
function Ye() {
  var p;
  const n = Fe(), { size: f } = Oe((p = n.proxy) == null ? void 0 : p.$props), i = r(null), d = r([]), M = r([]), D = r(!1), h = r([]), I = r([]), S = r([]), m = r([]), R = r([]), G = r([]), J = r([]), X = r([]), Y = [], P = r(0), T = r(0), B = r(0), x = r(!1), u = r([]), Z = r(!1), j = r(!1), _ = r(null), A = r({}), F = r(null), C = r(null), O = r(null), k = r(null), ee = r(null);
  ke(d, () => n.state && z(!1), {
    deep: !0
  });
  const te = /* @__PURE__ */ s(() => {
    if (!i.value)
      throw new Error("[ElTable] prop row-key is required");
  }, "assertRowKey"), N = /* @__PURE__ */ s((e) => {
    var t;
    (t = e.children) == null || t.forEach((o) => {
      o.fixed = e.fixed, N(o);
    });
  }, "updateChildFixed"), q = /* @__PURE__ */ s(() => {
    h.value.forEach((a) => {
      N(a);
    }), m.value = h.value.filter((a) => a.fixed === !0 || a.fixed === "left"), R.value = h.value.filter((a) => a.fixed === "right"), m.value.length > 0 && h.value[0] && h.value[0].type === "selection" && !h.value[0].fixed && (h.value[0].fixed = !0, m.value.unshift(h.value[0]));
    const e = h.value.filter((a) => !a.fixed);
    I.value = [].concat(m.value).concat(e).concat(R.value);
    const t = L(e), o = L(m.value), l = L(R.value);
    P.value = t.length, T.value = o.length, B.value = l.length, S.value = [].concat(o).concat(t).concat(l), D.value = m.value.length > 0 || R.value.length > 0;
  }, "updateColumns"), z = /* @__PURE__ */ s((e, t = !1) => {
    e && q(), t ? n.state.doLayout() : n.state.debouncedUpdateLayout();
  }, "scheduleLayout"), le = /* @__PURE__ */ s((e) => u.value.some((t) => Ne(t, e)), "isSelected"), ne = /* @__PURE__ */ s(() => {
    x.value = !1;
    const e = u.value;
    u.value = [], e.length && n.emit("selection-change", []);
  }, "clearSelection"), oe = /* @__PURE__ */ s(() => {
    let e;
    if (i.value) {
      e = [];
      const t = b(u.value, i.value), o = b(d.value, i.value);
      for (const l in t)
        je(t, l) && !o[l] && e.push(t[l].row);
    } else
      e = u.value.filter((t) => !d.value.includes(t));
    if (e.length) {
      const t = u.value.filter((o) => !e.includes(o));
      u.value = t, n.emit("selection-change", t.slice());
    }
  }, "cleanSelection"), ae = /* @__PURE__ */ s(() => (u.value || []).slice(), "getSelectionRows"), se = /* @__PURE__ */ s((e, t, o = !0) => {
    var l, a, c, v;
    const y = {
      children: (a = (l = n == null ? void 0 : n.store) == null ? void 0 : l.states) == null ? void 0 : a.childrenColumnName.value,
      checkStrictly: (v = (c = n == null ? void 0 : n.store) == null ? void 0 : c.states) == null ? void 0 : v.checkStrictly.value
    };
    if ($(u.value, e, t, y)) {
      const w = (u.value || []).slice();
      o && n.emit("select", w, e), n.emit("selection-change", w);
    }
  }, "toggleRowSelection"), re = /* @__PURE__ */ s(() => {
    var e, t;
    const o = j.value ? !x.value : !(x.value || u.value.length);
    x.value = o;
    let l = !1, a = 0;
    const c = (t = (e = n == null ? void 0 : n.store) == null ? void 0 : e.states) == null ? void 0 : t.rowKey.value, { childrenColumnName: v } = n.store.states, y = {
      children: v.value,
      checkStrictly: !1
    };
    d.value.forEach((g, w) => {
      const E = w + a;
      $(u.value, g, o, y, _.value, E) && (l = !0), a += V(K(g, c));
    }), l && n.emit("selection-change", u.value ? u.value.slice() : []), n.emit("select-all", (u.value || []).slice());
  }, "_toggleAllSelection"), ue = /* @__PURE__ */ s(() => {
    const e = b(u.value, i.value);
    d.value.forEach((t) => {
      const o = K(t, i.value), l = e[o];
      l && (u.value[l.index] = t);
    });
  }, "updateSelectionByRowKey"), ce = /* @__PURE__ */ s(() => {
    var e;
    if (((e = d.value) == null ? void 0 : e.length) === 0) {
      x.value = !1;
      return;
    }
    const { childrenColumnName: t } = n.store.states, o = i.value ? b(u.value, i.value) : void 0;
    let l = 0, a = 0;
    const c = /* @__PURE__ */ s((g) => o ? !!o[K(g, i.value)] : u.value.includes(g), "isSelected2"), v = /* @__PURE__ */ s((g) => {
      var w;
      for (const E of g) {
        const be = _.value && _.value.call(null, E, l);
        if (c(E))
          a++;
        else if (!_.value || be)
          return !1;
        if (l++, (w = E[t.value]) != null && w.length && !v(E[t.value]))
          return !1;
      }
      return !0;
    }, "checkSelectedStatus"), y = v(d.value || []);
    x.value = a === 0 ? !1 : y;
  }, "updateAllSelected"), V = /* @__PURE__ */ s((e) => {
    var t;
    if (!n || !n.store)
      return 0;
    const { treeData: o } = n.store.states;
    let l = 0;
    const a = (t = o.value[e]) == null ? void 0 : t.children;
    return a && (l += a.length, a.forEach((c) => {
      l += V(c);
    })), l;
  }, "getChildrenCount"), ie = /* @__PURE__ */ s((e, t) => {
    Array.isArray(e) || (e = [e]);
    const o = {};
    return e.forEach((l) => {
      A.value[l.id] = t, o[l.columnKey || l.id] = t;
    }), o;
  }, "updateFilters"), H = /* @__PURE__ */ s((e, t, o) => {
    C.value && C.value !== e && (C.value.order = null), C.value = e, O.value = t, k.value = o;
  }, "updateSort"), Q = /* @__PURE__ */ s(() => {
    let e = Ke(M);
    Object.keys(A.value).forEach((t) => {
      const o = A.value[t];
      if (!o || o.length === 0)
        return;
      const l = Me({
        columns: S.value
      }, t);
      l && l.filterMethod && (e = e.filter((a) => o.some((c) => l.filterMethod.call(null, c, a, l))));
    }), F.value = e;
  }, "execFilter"), U = /* @__PURE__ */ s(() => {
    d.value = qe(F.value, {
      sortingColumn: C.value,
      sortProp: O.value,
      sortOrder: k.value
    });
  }, "execSort"), de = /* @__PURE__ */ s((e = void 0) => {
    e && e.filter || Q(), U();
  }, "execQuery"), ve = /* @__PURE__ */ s((e) => {
    const { tableHeaderRef: t } = n.refs;
    if (!t)
      return;
    const o = Object.assign({}, t.filterPanels), l = Object.keys(o);
    if (l.length)
      if (typeof e == "string" && (e = [e]), Array.isArray(e)) {
        const a = e.map((c) => De({
          columns: S.value
        }, c));
        l.forEach((c) => {
          const v = a.find((y) => y.id === c);
          v && (v.filteredValue = []);
        }), n.store.commit("filterChange", {
          column: a,
          values: [],
          silent: !0,
          multi: !0
        });
      } else
        l.forEach((a) => {
          const c = S.value.find((v) => v.id === a);
          c && (c.filteredValue = []);
        }), A.value = {}, n.store.commit("filterChange", {
          column: {},
          values: [],
          silent: !0
        });
  }, "clearFilter"), fe = /* @__PURE__ */ s(() => {
    C.value && (H(null, null, null), n.store.commit("changeSortCondition", {
      silent: !0
    }));
  }, "clearSort"), {
    setExpandRowKeys: he,
    toggleRowExpansion: W,
    updateExpandRows: pe,
    states: ge,
    isRowExpanded: me
  } = Pe({
    data: d,
    rowKey: i
  }), {
    updateTreeExpandKeys: xe,
    toggleTreeExpansion: Ce,
    updateTreeData: ye,
    loadOrToggle: we,
    states: Se
  } = Be({
    data: d,
    rowKey: i
  }), {
    updateCurrentRowData: Ee,
    updateCurrentRow: Re,
    setCurrentRowKey: _e,
    states: Ae
  } = Te({
    data: d,
    rowKey: i
  });
  return {
    assertRowKey: te,
    updateColumns: q,
    scheduleLayout: z,
    isSelected: le,
    clearSelection: ne,
    cleanSelection: oe,
    getSelectionRows: ae,
    toggleRowSelection: se,
    _toggleAllSelection: re,
    toggleAllSelection: null,
    updateSelectionByRowKey: ue,
    updateAllSelected: ce,
    updateFilters: ie,
    updateCurrentRow: Re,
    updateSort: H,
    execFilter: Q,
    execSort: U,
    execQuery: de,
    clearFilter: ve,
    clearSort: fe,
    toggleRowExpansion: W,
    setExpandRowKeysAdapter: /* @__PURE__ */ s((e) => {
      he(e), xe(e);
    }, "setExpandRowKeysAdapter"),
    setCurrentRowKey: _e,
    toggleRowExpansionAdapter: /* @__PURE__ */ s((e, t) => {
      S.value.some(({ type: l }) => l === "expand") ? W(e, t) : Ce(e, t);
    }, "toggleRowExpansionAdapter"),
    isRowExpanded: me,
    updateExpandRows: pe,
    updateCurrentRowData: Ee,
    loadOrToggle: we,
    updateTreeData: ye,
    states: {
      tableSize: f,
      rowKey: i,
      data: d,
      _data: M,
      isComplex: D,
      _columns: h,
      originColumns: I,
      columns: S,
      fixedColumns: m,
      rightFixedColumns: R,
      leafColumns: G,
      fixedLeafColumns: J,
      rightFixedLeafColumns: X,
      updateOrderFns: Y,
      leafColumnsLength: P,
      fixedLeafColumnsLength: T,
      rightFixedLeafColumnsLength: B,
      isAllSelected: x,
      selection: u,
      reserveSelection: Z,
      selectOnIndeterminate: j,
      selectable: _,
      filters: A,
      filteredData: F,
      sortingColumn: C,
      sortProp: O,
      sortOrder: k,
      hoverRow: ee,
      ...ge,
      ...Se,
      ...Ae
    }
  };
}
s(Ye, "useWatcher");
export {
  Ye as default
};
