var C = Object.defineProperty;
var a = (n, r) => C(n, "name", { value: r, configurable: !0 });
import { defineComponent as b, computed as R, openBlock as k, createElementBlock as V, normalizeClass as c, unref as o, withDirectives as w, createElementVNode as f, isRef as S, withModifiers as v, vModelRadio as h, normalizeStyle as x, renderSlot as $, createTextVNode as g, toDisplayString as z } from "vue";
import { useRadio as E } from "../use-radio/index.js";
import { radioButtonProps as N } from "../radio-button/index.js";
import D from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as F } from "../../../../hooks/use-namespace/index/index.js";
const K = b({
  name: "ElRadioButton"
}), M = /* @__PURE__ */ b({
  ...K,
  props: N,
  setup(n) {
    const r = n, l = F("radio"), { radioRef: _, focus: i, size: y, disabled: m, modelValue: t, radioGroup: e, actualValue: s } = E(r), B = R(() => ({
      backgroundColor: (e == null ? void 0 : e.fill) || "",
      borderColor: (e == null ? void 0 : e.fill) || "",
      boxShadow: e != null && e.fill ? `-1px 0 0 0 ${e.fill}` : "",
      color: (e == null ? void 0 : e.textColor) || ""
    }));
    return (u, U) => {
      var p;
      return k(), V("label", {
        class: c([
          o(l).b("button"),
          o(l).is("active", o(t) === o(s)),
          o(l).is("disabled", o(m)),
          o(l).is("focus", o(i)),
          o(l).bm("button", o(y))
        ])
      }, [
        w(f("input", {
          ref_key: "radioRef",
          ref: _,
          "onUpdate:modelValue": /* @__PURE__ */ a((d) => S(t) ? t.value = d : null, "onUpdate:modelValue"),
          class: c(o(l).be("button", "original-radio")),
          value: o(s),
          type: "radio",
          name: u.name || ((p = o(e)) == null ? void 0 : p.name),
          disabled: o(m),
          onFocus: /* @__PURE__ */ a((d) => i.value = !0, "onFocus"),
          onBlur: /* @__PURE__ */ a((d) => i.value = !1, "onBlur"),
          onClick: v(() => {
          }, ["stop"])
        }, null, 42, ["onUpdate:modelValue", "value", "name", "disabled", "onFocus", "onBlur", "onClick"]), [
          [h, o(t)]
        ]),
        f("span", {
          class: c(o(l).be("button", "inner")),
          style: x(o(t) === o(s) ? o(B) : {}),
          onKeydown: v(() => {
          }, ["stop"])
        }, [
          $(u.$slots, "default", {}, () => [
            g(z(u.label), 1)
          ])
        ], 46, ["onKeydown"])
      ], 2);
    };
  }
});
var H = /* @__PURE__ */ D(M, [["__file", "radio-button.vue"]]);
export {
  H as default
};
