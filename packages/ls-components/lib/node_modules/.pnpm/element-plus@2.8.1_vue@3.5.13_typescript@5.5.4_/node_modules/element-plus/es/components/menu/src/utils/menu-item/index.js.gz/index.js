var a = Object.defineProperty;
var i = (o, e) => a(o, "name", { value: e, configurable: !0 });
import d from "../submenu/index.js";
import { EVENT_CODE as s } from "../../../../../constants/aria/index.js";
import { triggerEvent as r } from "../../../../../utils/dom/aria/index.js";
const u = class u {
  constructor(e, t) {
    this.domNode = e, this.submenu = null, this.submenu = null, this.init(t);
  }
  init(e) {
    this.domNode.setAttribute("tabindex", "0");
    const t = this.domNode.querySelector(`.${e}-menu`);
    t && (this.submenu = new d(this, t)), this.addListeners();
  }
  addListeners() {
    this.domNode.addEventListener("keydown", (e) => {
      let t = !1;
      switch (e.code) {
        case s.down: {
          r(e.currentTarget, "mouseenter"), this.submenu && this.submenu.gotoSubIndex(0), t = !0;
          break;
        }
        case s.up: {
          r(e.currentTarget, "mouseenter"), this.submenu && this.submenu.gotoSubIndex(this.submenu.subMenuItems.length - 1), t = !0;
          break;
        }
        case s.tab: {
          r(e.currentTarget, "mouseleave");
          break;
        }
        case s.enter:
        case s.space: {
          t = !0, e.currentTarget.click();
          break;
        }
      }
      t && e.preventDefault();
    });
  }
};
i(u, "MenuItem");
let n = u;
export {
  n as default
};
