var g = Object.defineProperty;
var f = (e, r) => g(e, "name", { value: r, configurable: !0 });
import { getCurrentInstance as S, unref as a, nextTick as v } from "vue";
import y from "../watcher/index.js";
import { useNamespace as w } from "../../../../../hooks/use-namespace/index/index.js";
function p(e, r) {
  return e.map((s) => {
    var d;
    return s.id === r.id ? r : ((d = s.children) != null && d.length && (s.children = p(s.children, r)), s);
  });
}
f(p, "replaceColumn");
function h(e) {
  e.forEach((r) => {
    var s, d;
    r.no = (s = r.getColumnIndex) == null ? void 0 : s.call(r), (d = r.children) != null && d.length && h(r.children);
  }), e.sort((r, s) => r.no - s.no);
}
f(h, "sortColumn");
function A() {
  const e = S(), r = y();
  return {
    ns: w("table"),
    ...r,
    mutations: {
      setData(o, t) {
        const l = a(o._data) !== t;
        o.data.value = t, o._data.value = t, e.store.execQuery(), e.store.updateCurrentRowData(), e.store.updateExpandRows(), e.store.updateTreeData(e.store.states.defaultExpandAll.value), a(o.reserveSelection) ? (e.store.assertRowKey(), e.store.updateSelectionByRowKey()) : l ? e.store.clearSelection() : e.store.cleanSelection(), e.store.updateAllSelected(), e.$ready && e.store.scheduleLayout();
      },
      insertColumn(o, t, l, c) {
        const u = a(o._columns);
        let n = [];
        l ? (l && !l.children && (l.children = []), l.children.push(t), n = p(u, l)) : (u.push(t), n = u), h(n), o._columns.value = n, o.updateOrderFns.push(c), t.type === "selection" && (o.selectable.value = t.selectable, o.reserveSelection.value = t.reserveSelection), e.$ready && (e.store.updateColumns(), e.store.scheduleLayout());
      },
      updateColumnOrder(o, t) {
        var l;
        ((l = t.getColumnIndex) == null ? void 0 : l.call(t)) !== t.no && (h(o._columns.value), e.$ready && e.store.updateColumns());
      },
      removeColumn(o, t, l, c) {
        const u = a(o._columns) || [];
        if (l)
          l.children.splice(l.children.findIndex((i) => i.id === t.id), 1), v(() => {
            var i;
            ((i = l.children) == null ? void 0 : i.length) === 0 && delete l.children;
          }), o._columns.value = p(u, l);
        else {
          const i = u.indexOf(t);
          i > -1 && (u.splice(i, 1), o._columns.value = u);
        }
        const n = o.updateOrderFns.indexOf(c);
        n > -1 && o.updateOrderFns.splice(n, 1), e.$ready && (e.store.updateColumns(), e.store.scheduleLayout());
      },
      sort(o, t) {
        const { prop: l, order: c, init: u } = t;
        if (l) {
          const n = a(o.columns).find((i) => i.property === l);
          n && (n.order = c, e.store.updateSort(n, l, c), e.store.commit("changeSortCondition", { init: u }));
        }
      },
      changeSortCondition(o, t) {
        const { sortingColumn: l, sortProp: c, sortOrder: u } = o, n = a(l), i = a(c), m = a(u);
        m === null && (o.sortingColumn.value = null, o.sortProp.value = null);
        const C = { filter: !0 };
        e.store.execQuery(C), (!t || !(t.silent || t.init)) && e.emit("sort-change", {
          column: n,
          prop: i,
          order: m
        }), e.store.updateTableScrollY();
      },
      filterChange(o, t) {
        const { column: l, values: c, silent: u } = t, n = e.store.updateFilters(l, c);
        e.store.execQuery(), u || e.emit("filter-change", n), e.store.updateTableScrollY();
      },
      toggleAllSelection() {
        e.store.toggleAllSelection();
      },
      rowSelectedChanged(o, t) {
        e.store.toggleRowSelection(t), e.store.updateAllSelected();
      },
      setHoverRow(o, t) {
        o.hoverRow.value = t;
      },
      setCurrentRow(o, t) {
        e.store.updateCurrentRow(t);
      }
    },
    commit: /* @__PURE__ */ f(function(o, ...t) {
      const l = e.store.mutations;
      if (l[o])
        l[o].apply(e, [e.store.states].concat(t));
      else
        throw new Error(`Action not found: ${o}`);
    }, "commit"),
    updateTableScrollY: /* @__PURE__ */ f(function() {
      v(() => e.layout.updateScrollY.apply(e.layout));
    }, "updateTableScrollY")
  };
}
f(A, "useStore");
export {
  A as default
};
