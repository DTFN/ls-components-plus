var L = Object.defineProperty;
var n = (r, e) => L(r, "name", { value: e, configurable: !0 });
import { reactive as E } from "vue";
import { markNodeData as k, NODE_KEY as N } from "../util/index.js";
import { hasOwn as S } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
const g = /* @__PURE__ */ n((r) => {
  let e = !0, t = !0, i = !0;
  for (let s = 0, a = r.length; s < a; s++) {
    const h = r[s];
    (h.checked !== !0 || h.indeterminate) && (e = !1, h.disabled || (i = !1)), (h.checked !== !1 || h.indeterminate) && (t = !1);
  }
  return { all: e, none: t, allWithoutDisable: i, half: !e && !t };
}, "getChildState"), f = /* @__PURE__ */ n(function(r) {
  if (r.childNodes.length === 0 || r.loading)
    return;
  const { all: e, none: t, half: i } = g(r.childNodes);
  e ? (r.checked = !0, r.indeterminate = !1) : i ? (r.checked = !1, r.indeterminate = !0) : t && (r.checked = !1, r.indeterminate = !1);
  const s = r.parent;
  !s || s.level === 0 || r.store.checkStrictly || f(s);
}, "reInitChecked"), c = /* @__PURE__ */ n(function(r, e) {
  const t = r.store.props, i = r.data || {}, s = t[e];
  if (typeof s == "function")
    return s(i, r);
  if (typeof s == "string")
    return i[s];
  if (typeof s > "u") {
    const a = i[e];
    return a === void 0 ? "" : a;
  }
}, "getPropertyFromData");
let b = 0;
const d = class d {
  constructor(e) {
    this.id = b++, this.text = null, this.checked = !1, this.indeterminate = !1, this.data = null, this.expanded = !1, this.parent = null, this.visible = !0, this.isCurrent = !1, this.canFocus = !1;
    for (const t in e)
      S(e, t) && (this[t] = e[t]);
    this.level = 0, this.loaded = !1, this.childNodes = [], this.loading = !1, this.parent && (this.level = this.parent.level + 1);
  }
  initialize() {
    const e = this.store;
    if (!e)
      throw new Error("[Node]store is required!");
    e.registerNode(this);
    const t = e.props;
    if (t && typeof t.isLeaf < "u") {
      const a = c(this, "isLeaf");
      typeof a == "boolean" && (this.isLeafByUser = a);
    }
    if (e.lazy !== !0 && this.data ? (this.setData(this.data), e.defaultExpandAll && (this.expanded = !0, this.canFocus = !0)) : this.level > 0 && e.lazy && e.defaultExpandAll && !this.isLeafByUser && this.expand(), Array.isArray(this.data) || k(this, this.data), !this.data)
      return;
    const i = e.defaultExpandedKeys, s = e.key;
    s && i && i.includes(this.key) && this.expand(null, e.autoExpandParent), s && e.currentNodeKey !== void 0 && this.key === e.currentNodeKey && (e.currentNode = this, e.currentNode.isCurrent = !0), e.lazy && e._initDefaultCheckedNode(this), this.updateLeafState(), this.parent && (this.level === 1 || this.parent.expanded === !0) && (this.canFocus = !0);
  }
  setData(e) {
    Array.isArray(e) || k(this, e), this.data = e, this.childNodes = [];
    let t;
    this.level === 0 && Array.isArray(this.data) ? t = this.data : t = c(this, "children") || [];
    for (let i = 0, s = t.length; i < s; i++)
      this.insertChild({ data: t[i] });
  }
  get label() {
    return c(this, "label");
  }
  get key() {
    const e = this.store.key;
    return this.data ? this.data[e] : null;
  }
  get disabled() {
    return c(this, "disabled");
  }
  get nextSibling() {
    const e = this.parent;
    if (e) {
      const t = e.childNodes.indexOf(this);
      if (t > -1)
        return e.childNodes[t + 1];
    }
    return null;
  }
  get previousSibling() {
    const e = this.parent;
    if (e) {
      const t = e.childNodes.indexOf(this);
      if (t > -1)
        return t > 0 ? e.childNodes[t - 1] : null;
    }
    return null;
  }
  contains(e, t = !0) {
    return (this.childNodes || []).some((i) => i === e || t && i.contains(e));
  }
  remove() {
    const e = this.parent;
    e && e.removeChild(this);
  }
  insertChild(e, t, i) {
    if (!e)
      throw new Error("InsertChild error: child is required.");
    if (!(e instanceof d)) {
      if (!i) {
        const s = this.getChildren(!0);
        s.includes(e.data) || (typeof t > "u" || t < 0 ? s.push(e.data) : s.splice(t, 0, e.data));
      }
      Object.assign(e, {
        parent: this,
        store: this.store
      }), e = E(new d(e)), e instanceof d && e.initialize();
    }
    e.level = this.level + 1, typeof t > "u" || t < 0 ? this.childNodes.push(e) : this.childNodes.splice(t, 0, e), this.updateLeafState();
  }
  insertBefore(e, t) {
    let i;
    t && (i = this.childNodes.indexOf(t)), this.insertChild(e, i);
  }
  insertAfter(e, t) {
    let i;
    t && (i = this.childNodes.indexOf(t), i !== -1 && (i += 1)), this.insertChild(e, i);
  }
  removeChild(e) {
    const t = this.getChildren() || [], i = t.indexOf(e.data);
    i > -1 && t.splice(i, 1);
    const s = this.childNodes.indexOf(e);
    s > -1 && (this.store && this.store.deregisterNode(e), e.parent = null, this.childNodes.splice(s, 1)), this.updateLeafState();
  }
  removeChildByData(e) {
    let t = null;
    for (let i = 0; i < this.childNodes.length; i++)
      if (this.childNodes[i].data === e) {
        t = this.childNodes[i];
        break;
      }
    t && this.removeChild(t);
  }
  expand(e, t) {
    const i = /* @__PURE__ */ n(() => {
      if (t) {
        let s = this.parent;
        for (; s.level > 0; )
          s.expanded = !0, s = s.parent;
      }
      this.expanded = !0, e && e(), this.childNodes.forEach((s) => {
        s.canFocus = !0;
      });
    }, "done");
    this.shouldLoadData() ? this.loadData((s) => {
      Array.isArray(s) && (this.checked ? this.setChecked(!0, !0) : this.store.checkStrictly || f(this), i());
    }) : i();
  }
  doCreateChildren(e, t = {}) {
    e.forEach((i) => {
      this.insertChild(Object.assign({ data: i }, t), void 0, !0);
    });
  }
  collapse() {
    this.expanded = !1, this.childNodes.forEach((e) => {
      e.canFocus = !1;
    });
  }
  shouldLoadData() {
    return this.store.lazy === !0 && this.store.load && !this.loaded;
  }
  updateLeafState() {
    if (this.store.lazy === !0 && this.loaded !== !0 && typeof this.isLeafByUser < "u") {
      this.isLeaf = this.isLeafByUser;
      return;
    }
    const e = this.childNodes;
    if (!this.store.lazy || this.store.lazy === !0 && this.loaded === !0) {
      this.isLeaf = !e || e.length === 0;
      return;
    }
    this.isLeaf = !1;
  }
  setChecked(e, t, i, s) {
    if (this.indeterminate = e === "half", this.checked = e === !0, this.store.checkStrictly)
      return;
    if (!(this.shouldLoadData() && !this.store.checkDescendants)) {
      const { all: h, allWithoutDisable: l } = g(this.childNodes);
      !this.isLeaf && !h && l && (this.checked = !1, e = !1);
      const u = /* @__PURE__ */ n(() => {
        if (t) {
          const o = this.childNodes;
          for (let p = 0, v = o.length; p < v; p++) {
            const y = o[p];
            s = s || e !== !1;
            const D = y.disabled ? y.checked : s;
            y.setChecked(D, t, !0, s);
          }
          const { half: m, all: C } = g(o);
          C || (this.checked = C, this.indeterminate = m);
        }
      }, "handleDescendants");
      if (this.shouldLoadData()) {
        this.loadData(() => {
          u(), f(this);
        }, {
          checked: e !== !1
        });
        return;
      } else
        u();
    }
    const a = this.parent;
    !a || a.level === 0 || i || f(a);
  }
  getChildren(e = !1) {
    if (this.level === 0)
      return this.data;
    const t = this.data;
    if (!t)
      return null;
    const i = this.store.props;
    let s = "children";
    return i && (s = i.children || "children"), t[s] === void 0 && (t[s] = null), e && !t[s] && (t[s] = []), t[s];
  }
  updateChildren() {
    const e = this.getChildren() || [], t = this.childNodes.map((a) => a.data), i = {}, s = [];
    e.forEach((a, h) => {
      const l = a[N];
      !!l && t.findIndex((o) => o[N] === l) >= 0 ? i[l] = { index: h, data: a } : s.push({ index: h, data: a });
    }), this.store.lazy || t.forEach((a) => {
      i[a[N]] || this.removeChildByData(a);
    }), s.forEach(({ index: a, data: h }) => {
      this.insertChild({ data: h }, a);
    }), this.updateLeafState();
  }
  loadData(e, t = {}) {
    if (this.store.lazy === !0 && this.store.load && !this.loaded && (!this.loading || Object.keys(t).length)) {
      this.loading = !0;
      const i = /* @__PURE__ */ n((a) => {
        this.childNodes = [], this.doCreateChildren(a, t), this.loaded = !0, this.loading = !1, this.updateLeafState(), e && e.call(this, a);
      }, "resolve"), s = /* @__PURE__ */ n(() => {
        this.loading = !1;
      }, "reject");
      this.store.load(this, i, s);
    } else
      e && e.call(this);
  }
  eachNode(e) {
    const t = [this];
    for (; t.length; ) {
      const i = t.shift();
      t.unshift(...i.childNodes), e(i);
    }
  }
  reInitChecked() {
    this.store.checkStrictly || f(this);
  }
};
n(d, "Node");
let x = d;
export {
  x as default,
  g as getChildState
};
