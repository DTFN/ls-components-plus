var g = Object.defineProperty;
var a = (l, o) => g(l, "name", { value: o, configurable: !0 });
import { defineComponent as d, inject as c, ref as v, openBlock as _, createElementBlock as D, normalizeClass as C, unref as u, withModifiers as t, renderSlot as E } from "vue";
import { throwError as x } from "../../../../utils/error/index.js";
import { uploadContextKey as N } from "../constants/index.js";
import { uploadDraggerProps as b, uploadDraggerEmits as h } from "../upload-dragger/index.js";
import M from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as P } from "../../../../hooks/use-namespace/index/index.js";
import { useFormDisabled as k } from "../../../form/src/hooks/use-form-common-props/index.js";
const f = "ElUploadDrag", w = d({
  name: f
}), y = /* @__PURE__ */ d({
  ...w,
  props: b,
  emits: h,
  setup(l, { emit: o }) {
    c(N) || x(f, "usage: <el-upload><el-upload-dragger /></el-upload>");
    const n = P("upload"), e = v(!1), s = k(), i = /* @__PURE__ */ a((r) => {
      if (s.value)
        return;
      e.value = !1, r.stopPropagation();
      const p = Array.from(r.dataTransfer.files);
      o("file", p);
    }, "onDrop"), m = /* @__PURE__ */ a(() => {
      s.value || (e.value = !0);
    }, "onDragover");
    return (r, p) => (_(), D("div", {
      class: C([u(n).b("dragger"), u(n).is("dragover", e.value)]),
      onDrop: t(i, ["prevent"]),
      onDragover: t(m, ["prevent"]),
      onDragleave: t((B) => e.value = !1, ["prevent"])
    }, [
      E(r.$slots, "default")
    ], 42, ["onDrop", "onDragover", "onDragleave"]));
  }
});
var S = /* @__PURE__ */ M(y, [["__file", "upload-dragger.vue"]]);
export {
  S as default
};
