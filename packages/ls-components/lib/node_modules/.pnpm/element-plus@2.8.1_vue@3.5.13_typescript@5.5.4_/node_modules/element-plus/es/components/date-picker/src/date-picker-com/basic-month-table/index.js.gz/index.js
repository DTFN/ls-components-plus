var z = Object.defineProperty;
var u = (b, g) => z(b, "name", { value: g, configurable: !0 });
import { defineComponent as Y, ref as f, computed as q, watch as G, nextTick as H, openBlock as h, createElementBlock as D, unref as p, normalizeClass as V, createElementVNode as J, Fragment as I, renderList as R, withKeys as A, withModifiers as E, createVNode as Q } from "vue";
import M from "../../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { basicMonthTableProps as U } from "../../props/basic-month-table/index.js";
import { datesInMonth as W, getValidDateOfMonth as X } from "../../utils/index.js";
import Z from "../basic-cell-render/index.js";
import ee from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as te } from "../../../../../hooks/use-namespace/index/index.js";
import { useLocale as ae } from "../../../../../hooks/use-locale/index/index.js";
import { castArray as v } from "../../../../../utils/arrays/index.js";
import { hasClass as B } from "../../../../../utils/dom/style/index.js";
const ne = /* @__PURE__ */ Y({
  __name: "basic-month-table",
  props: U,
  emits: ["changerange", "pick", "select"],
  setup(b, { expose: g, emit: d }) {
    const e = b, P = te("month-table"), { t: w, lang: x } = ae(), N = f(), k = f(), j = f(e.date.locale("en").localeData().monthsShort().map((a) => a.toLowerCase())), K = f([
      [],
      [],
      []
    ]), C = f(), T = f(), O = q(() => {
      var a, o;
      const t = K.value, r = M().locale(x.value).startOf("month");
      for (let n = 0; n < 3; n++) {
        const i = t[n];
        for (let s = 0; s < 4; s++) {
          const c = i[s] || (i[s] = {
            row: n,
            column: s,
            type: "normal",
            inRange: !1,
            start: !1,
            end: !1,
            text: -1,
            disabled: !1
          });
          c.type = "normal";
          const y = n * 4 + s, l = e.date.startOf("year").month(y), m = e.rangeState.endDate || e.maxDate || e.rangeState.selecting && e.minDate || null;
          c.inRange = !!(e.minDate && l.isSameOrAfter(e.minDate, "month") && m && l.isSameOrBefore(m, "month")) || !!(e.minDate && l.isSameOrBefore(e.minDate, "month") && m && l.isSameOrAfter(m, "month")), (a = e.minDate) != null && a.isSameOrAfter(m) ? (c.start = !!(m && l.isSame(m, "month")), c.end = e.minDate && l.isSame(e.minDate, "month")) : (c.start = !!(e.minDate && l.isSame(e.minDate, "month")), c.end = !!(m && l.isSame(m, "month"))), r.isSame(l) && (c.type = "today"), c.text = y, c.disabled = ((o = e.disabledDate) == null ? void 0 : o.call(e, l.toDate())) || !1;
        }
      }
      return t;
    }), L = /* @__PURE__ */ u(() => {
      var a;
      (a = k.value) == null || a.focus();
    }, "focus"), F = /* @__PURE__ */ u((a) => {
      const o = {}, t = e.date.year(), r = /* @__PURE__ */ new Date(), n = a.text;
      return o.disabled = e.disabledDate ? W(t, n, x.value).every(e.disabledDate) : !1, o.current = v(e.parsedValue).findIndex((i) => M.isDayjs(i) && i.year() === t && i.month() === n) >= 0, o.today = r.getFullYear() === t && r.getMonth() === n, a.inRange && (o["in-range"] = !0, a.start && (o["start-date"] = !0), a.end && (o["end-date"] = !0)), o;
    }, "getCellStyle"), _ = /* @__PURE__ */ u((a) => {
      const o = e.date.year(), t = a.text;
      return v(e.date).findIndex((r) => r.year() === o && r.month() === t) >= 0;
    }, "isSelectedCell"), $ = /* @__PURE__ */ u((a) => {
      var o;
      if (!e.rangeState.selecting)
        return;
      let t = a.target;
      if (t.tagName === "SPAN" && (t = (o = t.parentNode) == null ? void 0 : o.parentNode), t.tagName === "DIV" && (t = t.parentNode), t.tagName !== "TD")
        return;
      const r = t.parentNode.rowIndex, n = t.cellIndex;
      O.value[r][n].disabled || (r !== C.value || n !== T.value) && (C.value = r, T.value = n, d("changerange", {
        selecting: !0,
        endDate: e.date.startOf("year").month(r * 4 + n)
      }));
    }, "handleMouseMove"), S = /* @__PURE__ */ u((a) => {
      var o;
      const t = (o = a.target) == null ? void 0 : o.closest("td");
      if ((t == null ? void 0 : t.tagName) !== "TD" || B(t, "disabled"))
        return;
      const r = t.cellIndex, i = t.parentNode.rowIndex * 4 + r, s = e.date.startOf("year").month(i);
      if (e.selectionMode === "months") {
        if (a.type === "keydown") {
          d("pick", v(e.parsedValue), !1);
          return;
        }
        const c = X(e.date.year(), i, x.value, e.disabledDate), y = B(t, "current") ? v(e.parsedValue).filter((l) => (l == null ? void 0 : l.month()) !== c.month()) : v(e.parsedValue).concat([M(c)]);
        d("pick", y);
      } else e.selectionMode === "range" ? e.rangeState.selecting ? (e.minDate && s >= e.minDate ? d("pick", { minDate: e.minDate, maxDate: s }) : d("pick", { minDate: s, maxDate: e.minDate }), d("select", !1)) : (d("pick", { minDate: s, maxDate: null }), d("select", !0)) : d("pick", i);
    }, "handleMonthTableClick");
    return G(() => e.date, async () => {
      var a, o;
      (a = N.value) != null && a.contains(document.activeElement) && (await H(), (o = k.value) == null || o.focus());
    }), g({
      focus: L
    }), (a, o) => (h(), D("table", {
      role: "grid",
      "aria-label": p(w)("el.datepicker.monthTablePrompt"),
      class: V(p(P).b()),
      onClick: S,
      onMousemove: $
    }, [
      J("tbody", {
        ref_key: "tbodyRef",
        ref: N
      }, [
        (h(!0), D(I, null, R(p(O), (t, r) => (h(), D("tr", { key: r }, [
          (h(!0), D(I, null, R(t, (n, i) => (h(), D("td", {
            key: i,
            ref_for: !0,
            ref: /* @__PURE__ */ u((s) => _(n) && (k.value = s), "ref"),
            class: V(F(n)),
            "aria-selected": `${_(n)}`,
            "aria-label": p(w)(`el.datepicker.month${+n.text + 1}`),
            tabindex: _(n) ? 0 : -1,
            onKeydown: [
              A(E(S, ["prevent", "stop"]), ["space"]),
              A(E(S, ["prevent", "stop"]), ["enter"])
            ]
          }, [
            Q(p(Z), {
              cell: {
                ...n,
                renderText: p(w)("el.datepicker.months." + j.value[n.text])
              }
            }, null, 8, ["cell"])
          ], 42, ["aria-selected", "aria-label", "tabindex", "onKeydown"]))), 128))
        ]))), 128))
      ], 512)
    ], 42, ["aria-label"]));
  }
});
var De = /* @__PURE__ */ ee(ne, [["__file", "basic-month-table.vue"]]);
export {
  De as default
};
