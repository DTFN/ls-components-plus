var u = Object.defineProperty;
var t = (e, r) => u(e, "name", { value: r, configurable: !0 });
import { buildProps as n } from "../../../../utils/vue/props/runtime/index.js";
import { useSizeProp as l } from "../../../../hooks/use-size/index/index.js";
import { isNumber as o } from "../../../../utils/types/index.js";
import { useAriaProps as m } from "../../../../hooks/use-aria/index/index.js";
import { CHANGE_EVENT as a, INPUT_EVENT as p, UPDATE_MODEL_EVENT as s } from "../../../../constants/event/index.js";
import i from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
const I = n({
  id: {
    type: String,
    default: void 0
  },
  step: {
    type: Number,
    default: 1
  },
  stepStrictly: Boolean,
  max: {
    type: Number,
    default: Number.POSITIVE_INFINITY
  },
  min: {
    type: Number,
    default: Number.NEGATIVE_INFINITY
  },
  modelValue: Number,
  readonly: Boolean,
  disabled: Boolean,
  size: l,
  controls: {
    type: Boolean,
    default: !0
  },
  controlsPosition: {
    type: String,
    default: "",
    values: ["", "right"]
  },
  valueOnClear: {
    type: [String, Number, null],
    validator: /* @__PURE__ */ t((e) => e === null || o(e) || ["min", "max"].includes(e), "validator"),
    default: null
  },
  name: String,
  placeholder: String,
  precision: {
    type: Number,
    validator: /* @__PURE__ */ t((e) => e >= 0 && e === Number.parseInt(`${e}`, 10), "validator")
  },
  validateEvent: {
    type: Boolean,
    default: !0
  },
  ...m(["ariaLabel"])
}), T = {
  [a]: (e, r) => r !== e,
  blur: /* @__PURE__ */ t((e) => e instanceof FocusEvent, "blur"),
  focus: /* @__PURE__ */ t((e) => e instanceof FocusEvent, "focus"),
  [p]: (e) => o(e) || i(e),
  [s]: (e) => o(e) || i(e)
};
export {
  T as inputNumberEmits,
  I as inputNumberProps
};
