var Y = Object.defineProperty;
var o = (t, a) => Y(t, "name", { value: a, configurable: !0 });
import { defineComponent as Z, getCurrentInstance as ee, ref as h, computed as te, watch as N, watchEffect as ne, provide as D, reactive as le, onMounted as oe, h as b, withDirectives as ue, nextTick as ae } from "vue";
import { useResizeObserver as ie } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { ElIcon as se } from "../../../icon/index/index.js";
import { More as re } from "@element-plus/icons-vue";
import ce from "../utils/menu-bar/index.js";
import de from "../menu-collapse-transition/index.js";
import me from "../sub-menu/index.js";
import { useMenuCssVar as fe } from "../use-menu-css-var/index.js";
import { buildProps as ve, definePropType as $ } from "../../../../utils/vue/props/runtime/index.js";
import { mutable as he } from "../../../../utils/typescript/index.js";
import { iconPropType as pe } from "../../../../utils/vue/icon/index.js";
import { isString as P, isObject as ge } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { useNamespace as q } from "../../../../hooks/use-namespace/index/index.js";
import { flattedChildren as Me } from "../../../../utils/vue/vnode/index.js";
import be from "../../../../directives/click-outside/index/index.js";
import V from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
const ye = ve({
  mode: {
    type: String,
    values: ["horizontal", "vertical"],
    default: "vertical"
  },
  defaultActive: {
    type: String,
    default: ""
  },
  defaultOpeneds: {
    type: $(Array),
    default: /* @__PURE__ */ o(() => he([]), "default")
  },
  uniqueOpened: Boolean,
  router: Boolean,
  menuTrigger: {
    type: String,
    values: ["hover", "click"],
    default: "hover"
  },
  collapse: Boolean,
  backgroundColor: String,
  textColor: String,
  activeTextColor: String,
  closeOnClickOutside: Boolean,
  collapseTransition: {
    type: Boolean,
    default: !0
  },
  ellipsis: {
    type: Boolean,
    default: !0
  },
  popperOffset: {
    type: Number,
    default: 6
  },
  ellipsisIcon: {
    type: pe,
    default: /* @__PURE__ */ o(() => re, "default")
  },
  popperEffect: {
    type: $(String),
    default: "dark"
  },
  popperClass: String,
  showTimeout: {
    type: Number,
    default: 300
  },
  hideTimeout: {
    type: Number,
    default: 300
  }
}), z = /* @__PURE__ */ o((t) => Array.isArray(t) && t.every((a) => P(a)), "checkIndexPath"), Se = {
  close: /* @__PURE__ */ o((t, a) => P(t) && z(a), "close"),
  open: /* @__PURE__ */ o((t, a) => P(t) && z(a), "open"),
  select: /* @__PURE__ */ o((t, a, y, S) => P(t) && z(a) && ge(y) && (S === void 0 || S instanceof Promise), "select")
};
var De = Z({
  name: "ElMenu",
  props: ye,
  emits: Se,
  setup(t, { emit: a, slots: y, expose: S }) {
    const T = ee(), E = T.appContext.config.globalProperties.$router, d = h(), I = q("menu"), A = q("sub-menu"), m = h(-1), s = h(t.defaultOpeneds && !t.collapse ? t.defaultOpeneds.slice(0) : []), r = h(t.defaultActive), f = h({}), p = h({}), j = te(() => t.mode === "horizontal" || t.mode === "vertical" && t.collapse), F = /* @__PURE__ */ o(() => {
      const e = r.value && f.value[r.value];
      if (!e || t.mode === "horizontal" || t.collapse)
        return;
      e.indexPath.forEach((l) => {
        const i = p.value[l];
        i && x(l, i.indexPath);
      });
    }, "initMenu"), x = /* @__PURE__ */ o((e, n) => {
      s.value.includes(e) || (t.uniqueOpened && (s.value = s.value.filter((l) => n.includes(l))), s.value.push(e), a("open", e, n));
    }, "openMenu"), w = /* @__PURE__ */ o((e) => {
      const n = s.value.indexOf(e);
      n !== -1 && s.value.splice(n, 1);
    }, "close"), R = /* @__PURE__ */ o((e, n) => {
      w(e), a("close", e, n);
    }, "closeMenu"), G = /* @__PURE__ */ o(({
      index: e,
      indexPath: n
    }) => {
      s.value.includes(e) ? R(e, n) : x(e, n);
    }, "handleSubMenuClick"), H = /* @__PURE__ */ o((e) => {
      (t.mode === "horizontal" || t.collapse) && (s.value = []);
      const { index: n, indexPath: l } = e;
      if (!(V(n) || V(l)))
        if (t.router && E) {
          const i = e.route || n, u = E.push(i).then((g) => (g || (r.value = n), g));
          a("select", n, l, { index: n, indexPath: l, route: i }, u);
        } else
          r.value = n, a("select", n, l, { index: n, indexPath: l });
    }, "handleMenuItemClick"), J = /* @__PURE__ */ o((e) => {
      const n = f.value, l = n[e] || r.value && n[r.value] || n[t.defaultActive];
      l ? r.value = l.index : r.value = e;
    }, "updateActiveIndex"), K = /* @__PURE__ */ o((e) => {
      const n = getComputedStyle(e), l = Number.parseInt(n.marginLeft, 10), i = Number.parseInt(n.marginRight, 10);
      return e.offsetWidth + l + i || 0;
    }, "calcMenuItemWidth"), B = /* @__PURE__ */ o(() => {
      var e, n;
      if (!d.value)
        return -1;
      const l = Array.from((n = (e = d.value) == null ? void 0 : e.childNodes) != null ? n : []).filter((M) => M.nodeName !== "#comment" && (M.nodeName !== "#text" || M.nodeValue)), i = 64, u = getComputedStyle(d.value), g = Number.parseInt(u.paddingLeft, 10), C = Number.parseInt(u.paddingRight, 10), c = d.value.clientWidth - g - C;
      let O = 0, v = 0;
      return l.forEach((M, X) => {
        O += K(M), O <= c - i && (v = X + 1);
      }), v === l.length ? -1 : v;
    }, "calcSliceIndex"), Q = /* @__PURE__ */ o((e) => p.value[e].indexPath, "getIndexPath"), U = /* @__PURE__ */ o((e, n = 33.34) => {
      let l;
      return () => {
        l && clearTimeout(l), l = setTimeout(() => {
          e();
        }, n);
      };
    }, "debounce");
    let W = !0;
    const L = /* @__PURE__ */ o(() => {
      if (m.value === B())
        return;
      const e = /* @__PURE__ */ o(() => {
        m.value = -1, ae(() => {
          m.value = B();
        });
      }, "callback");
      W ? e() : U(e)(), W = !1;
    }, "handleResize");
    N(() => t.defaultActive, (e) => {
      f.value[e] || (r.value = ""), J(e);
    }), N(() => t.collapse, (e) => {
      e && (s.value = []);
    }), N(f.value, F);
    let k;
    ne(() => {
      t.mode === "horizontal" && t.ellipsis ? k = ie(d, L).stop : k == null || k();
    });
    const _ = h(!1);
    {
      const e = /* @__PURE__ */ o((u) => {
        p.value[u.index] = u;
      }, "addSubMenu"), n = /* @__PURE__ */ o((u) => {
        delete p.value[u.index];
      }, "removeSubMenu");
      D("rootMenu", le({
        props: t,
        openedMenus: s,
        items: f,
        subMenus: p,
        activeIndex: r,
        isMenuPopup: j,
        addMenuItem: /* @__PURE__ */ o((u) => {
          f.value[u.index] = u;
        }, "addMenuItem"),
        removeMenuItem: /* @__PURE__ */ o((u) => {
          delete f.value[u.index];
        }, "removeMenuItem"),
        addSubMenu: e,
        removeSubMenu: n,
        openMenu: x,
        closeMenu: R,
        handleMenuItemClick: H,
        handleSubMenuClick: G
      })), D(`subMenu:${T.uid}`, {
        addSubMenu: e,
        removeSubMenu: n,
        mouseInChild: _,
        level: 0
      });
    }
    return oe(() => {
      t.mode === "horizontal" && new ce(T.vnode.el, I.namespace.value);
    }), S({
      open: /* @__PURE__ */ o((n) => {
        const { indexPath: l } = p.value[n];
        l.forEach((i) => x(i, l));
      }, "open"),
      close: w,
      handleResize: L
    }), () => {
      var e, n;
      let l = (n = (e = y.default) == null ? void 0 : e.call(y)) != null ? n : [];
      const i = [];
      if (t.mode === "horizontal" && d.value) {
        const c = Me(l), O = m.value === -1 ? c : c.slice(0, m.value), v = m.value === -1 ? [] : c.slice(m.value);
        v != null && v.length && t.ellipsis && (l = O, i.push(b(me, {
          index: "sub-menu-more",
          class: A.e("hide-arrow"),
          popperOffset: t.popperOffset
        }, {
          title: /* @__PURE__ */ o(() => b(se, {
            class: A.e("icon-more")
          }, {
            default: /* @__PURE__ */ o(() => b(t.ellipsisIcon), "default")
          }), "title"),
          default: /* @__PURE__ */ o(() => v, "default")
        })));
      }
      const u = fe(t, 0), g = t.closeOnClickOutside ? [
        [
          be,
          () => {
            s.value.length && (_.value || (s.value.forEach((c) => a("close", c, Q(c))), s.value = []));
          }
        ]
      ] : [], C = ue(b("ul", {
        key: String(t.collapse),
        role: "menubar",
        ref: d,
        style: u.value,
        class: {
          [I.b()]: !0,
          [I.m(t.mode)]: !0,
          [I.m("collapse")]: t.collapse
        }
      }, [...l, ...i]), g);
      return t.collapseTransition && t.mode === "vertical" ? b(de, () => C) : C;
    };
  }
});
export {
  De as default,
  Se as menuEmits,
  ye as menuProps
};
