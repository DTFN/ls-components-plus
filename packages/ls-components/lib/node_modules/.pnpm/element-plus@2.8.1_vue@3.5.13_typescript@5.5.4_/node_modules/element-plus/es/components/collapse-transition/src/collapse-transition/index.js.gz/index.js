var n = Object.defineProperty;
var s = (o, e) => n(o, "name", { value: e, configurable: !0 });
import { defineComponent as d, openBlock as r, createBlock as l, Transition as p, mergeProps as g, unref as m, toHandlers as f, withCtx as y, renderSlot as h } from "vue";
import c from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as v } from "../../../../hooks/use-namespace/index/index.js";
const x = d({
  name: "ElCollapseTransition"
}), H = /* @__PURE__ */ d({
  ...x,
  setup(o) {
    const e = v("collapse-transition"), a = /* @__PURE__ */ s((t) => {
      t.style.maxHeight = "", t.style.overflow = t.dataset.oldOverflow, t.style.paddingTop = t.dataset.oldPaddingTop, t.style.paddingBottom = t.dataset.oldPaddingBottom;
    }, "reset"), i = {
      beforeEnter(t) {
        t.dataset || (t.dataset = {}), t.dataset.oldPaddingTop = t.style.paddingTop, t.dataset.oldPaddingBottom = t.style.paddingBottom, t.style.height && (t.dataset.elExistsHeight = t.style.height), t.style.maxHeight = 0, t.style.paddingTop = 0, t.style.paddingBottom = 0;
      },
      enter(t) {
        requestAnimationFrame(() => {
          t.dataset.oldOverflow = t.style.overflow, t.dataset.elExistsHeight ? t.style.maxHeight = t.dataset.elExistsHeight : t.scrollHeight !== 0 ? t.style.maxHeight = `${t.scrollHeight}px` : t.style.maxHeight = 0, t.style.paddingTop = t.dataset.oldPaddingTop, t.style.paddingBottom = t.dataset.oldPaddingBottom, t.style.overflow = "hidden";
        });
      },
      afterEnter(t) {
        t.style.maxHeight = "", t.style.overflow = t.dataset.oldOverflow;
      },
      enterCancelled(t) {
        a(t);
      },
      beforeLeave(t) {
        t.dataset || (t.dataset = {}), t.dataset.oldPaddingTop = t.style.paddingTop, t.dataset.oldPaddingBottom = t.style.paddingBottom, t.dataset.oldOverflow = t.style.overflow, t.style.maxHeight = `${t.scrollHeight}px`, t.style.overflow = "hidden";
      },
      leave(t) {
        t.scrollHeight !== 0 && (t.style.maxHeight = 0, t.style.paddingTop = 0, t.style.paddingBottom = 0);
      },
      afterLeave(t) {
        a(t);
      },
      leaveCancelled(t) {
        a(t);
      }
    };
    return (t, _) => (r(), l(p, g({
      name: m(e).b()
    }, f(i)), {
      default: y(() => [
        h(t.$slots, "default")
      ]),
      _: 3
    }, 16, ["name"]));
  }
});
var P = /* @__PURE__ */ c(H, [["__file", "collapse-transition.vue"]]);
export {
  P as default
};
