var O = Object.defineProperty;
var n = (c, b) => O(c, "name", { value: b, configurable: !0 });
import { getCurrentInstance as X, inject as _, ref as y } from "vue";
import { TABLE_INJECTION_KEY as $ } from "../../tokens/index.js";
import { addClass as q, hasClass as L, removeClass as k } from "../../../../../utils/dom/style/index.js";
import { isElement as A } from "../../../../../utils/types/index.js";
import { isClient as P } from "../../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
function K(c, b) {
  const z = X(), a = _($), E = /* @__PURE__ */ n((t) => {
    t.stopPropagation();
  }, "handleFilterClick"), S = /* @__PURE__ */ n((t, e) => {
    !e.filters && e.sortable ? x(t, e, !1) : e.filterable && !e.sortable && E(t), a == null || a.emit("header-click", e, t);
  }, "handleHeaderClick"), T = /* @__PURE__ */ n((t, e) => {
    a == null || a.emit("header-contextmenu", e, t);
  }, "handleHeaderContextMenu"), C = y(null), h = y(!1), f = y({}), w = /* @__PURE__ */ n((t, e) => {
    if (P && !(e.children && e.children.length > 0) && C.value && c.border) {
      h.value = !0;
      const r = a;
      b("set-drag-visible", !0);
      const o = (r == null ? void 0 : r.vnode.el).getBoundingClientRect().left, s = z.vnode.el.querySelector(`th.${e.id}`), m = s.getBoundingClientRect(), u = m.left - o + 30;
      q(s, "noclick"), f.value = {
        startMouseLeft: t.clientX,
        startLeft: m.right - o,
        startColumnLeft: m.left - o,
        tableLeft: o
      };
      const g = r == null ? void 0 : r.refs.resizeProxy;
      g.style.left = `${f.value.startLeft}px`, document.onselectstart = function() {
        return !1;
      }, document.ondragstart = function() {
        return !1;
      };
      const v = /* @__PURE__ */ n((d) => {
        const p = d.clientX - f.value.startMouseLeft, M = f.value.startLeft + p;
        g.style.left = `${Math.max(u, M)}px`;
      }, "handleMouseMove2"), i = /* @__PURE__ */ n(() => {
        if (h.value) {
          const { startColumnLeft: d, startLeft: p } = f.value, N = Number.parseInt(g.style.left, 10) - d;
          e.width = e.realWidth = N, r == null || r.emit("header-dragend", e.width, p - d, e, t), requestAnimationFrame(() => {
            c.store.scheduleLayout(!1, !0);
          }), document.body.style.cursor = "", h.value = !1, C.value = null, f.value = {}, b("set-drag-visible", !1);
        }
        document.removeEventListener("mousemove", v), document.removeEventListener("mouseup", i), document.onselectstart = null, document.ondragstart = null, setTimeout(() => {
          k(s, "noclick");
        }, 0);
      }, "handleMouseUp");
      document.addEventListener("mousemove", v), document.addEventListener("mouseup", i);
    }
  }, "handleMouseDown"), B = /* @__PURE__ */ n((t, e) => {
    if (e.children && e.children.length > 0)
      return;
    const r = t.target;
    if (!A(r))
      return;
    const l = r == null ? void 0 : r.closest("th");
    if (!(!e || !e.resizable) && !h.value && c.border) {
      const o = l.getBoundingClientRect(), s = document.body.style;
      o.width > 12 && o.right - t.pageX < 8 ? (s.cursor = "col-resize", L(l, "is-sortable") && (l.style.cursor = "col-resize"), C.value = e) : h.value || (s.cursor = "", L(l, "is-sortable") && (l.style.cursor = "pointer"), C.value = null);
    }
  }, "handleMouseMove"), I = /* @__PURE__ */ n(() => {
    P && (document.body.style.cursor = "");
  }, "handleMouseOut"), R = /* @__PURE__ */ n(({ order: t, sortOrders: e }) => {
    if (t === "")
      return e[0];
    const r = e.indexOf(t || null);
    return e[r > e.length - 2 ? 0 : r + 1];
  }, "toggleOrder"), x = /* @__PURE__ */ n((t, e, r) => {
    var l;
    t.stopPropagation();
    const o = e.order === r ? null : r || R(e), s = (l = t.target) == null ? void 0 : l.closest("th");
    if (s && L(s, "noclick")) {
      k(s, "noclick");
      return;
    }
    if (!e.sortable)
      return;
    const m = t.currentTarget;
    if (["ascending", "descending"].some((d) => L(m, d) && !e.sortOrders.includes(d)))
      return;
    const u = c.store.states;
    let g = u.sortProp.value, v;
    const i = u.sortingColumn.value;
    (i !== e || i === e && i.order === null) && (i && (i.order = null), u.sortingColumn.value = e, g = e.property), o ? v = e.order = o : v = e.order = null, u.sortProp.value = g, u.sortOrder.value = v, a == null || a.store.commit("changeSortCondition");
  }, "handleSortClick");
  return {
    handleHeaderClick: S,
    handleHeaderContextMenu: T,
    handleMouseDown: w,
    handleMouseMove: B,
    handleMouseOut: I,
    handleSortClick: x,
    handleFilterClick: E
  };
}
n(K, "useEvent");
export {
  K as default
};
