var s = Object.defineProperty;
var r = (v, u) => s(v, "name", { value: u, configurable: !0 });
import { inject as t, ref as c, computed as I, onMounted as a, watch as m, toRef as h, onUnmounted as w } from "vue";
import { formContextKey as y, formItemContextKey as F } from "../../constants/index.js";
import { useId as K } from "../../../../../hooks/use-id/index/index.js";
const R = /* @__PURE__ */ r(() => {
  const v = t(y, void 0), u = t(F, void 0);
  return {
    form: v,
    formItem: u
  };
}, "useFormItem"), _ = /* @__PURE__ */ r((v, {
  formItemContext: u,
  disableIdGeneration: e,
  disableIdManagement: i
}) => {
  e || (e = c(!1)), i || (i = c(!1));
  const l = c();
  let n;
  const f = I(() => {
    var o;
    return !!(!(v.label || v.ariaLabel) && u && u.inputIds && ((o = u.inputIds) == null ? void 0 : o.length) <= 1);
  });
  return a(() => {
    n = m([h(v, "id"), e], ([o, p]) => {
      const d = o ?? (p ? void 0 : K().value);
      d !== l.value && (u != null && u.removeInputId && (l.value && u.removeInputId(l.value), !(i != null && i.value) && !p && d && u.addInputId(d)), l.value = d);
    }, { immediate: !0 });
  }), w(() => {
    n && n(), u != null && u.removeInputId && l.value && u.removeInputId(l.value);
  }), {
    isLabeledByFormItem: f,
    inputId: l
  };
}, "useFormItemInputId");
export {
  R as useFormItem,
  _ as useFormItemInputId
};
