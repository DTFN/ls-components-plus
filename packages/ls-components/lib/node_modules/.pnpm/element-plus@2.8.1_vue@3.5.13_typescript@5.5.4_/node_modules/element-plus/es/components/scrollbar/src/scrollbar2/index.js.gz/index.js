var U = Object.defineProperty;
var t = (f, m) => U(f, "name", { value: m, configurable: !0 });
import { defineComponent as g, ref as i, computed as d, watch as _, nextTick as L, provide as V, reactive as j, onActivated as D, onMounted as W, onUpdated as $, openBlock as b, createElementBlock as q, normalizeClass as h, unref as n, createElementVNode as x, normalizeStyle as k, createBlock as C, resolveDynamicComponent as F, withCtx as G, renderSlot as I, createCommentVNode as J } from "vue";
import { useResizeObserver as Q, useEventListener as X } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import Y from "../bar2/index.js";
import { scrollbarContextKey as Z } from "../constants/index.js";
import { scrollbarProps as ee, scrollbarEmits as le } from "../scrollbar/index.js";
import re from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as oe } from "../../../../hooks/use-namespace/index/index.js";
import { addUnit as E } from "../../../../utils/dom/style/index.js";
import { isObject as te } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isNumber as c } from "../../../../utils/types/index.js";
import { debugWarn as N } from "../../../../utils/error/index.js";
const w = "ElScrollbar", ae = g({
  name: w
}), se = /* @__PURE__ */ g({
  ...ae,
  props: ee,
  emits: le,
  setup(f, { expose: m, emit: O }) {
    const r = f, a = oe("scrollbar");
    let u, p, y = 0, S = 0;
    const z = i(), l = i(), T = i(), s = i(), B = d(() => {
      const e = {};
      return r.height && (e.height = E(r.height)), r.maxHeight && (e.maxHeight = E(r.maxHeight)), [r.wrapStyle, e];
    }), H = d(() => [
      r.wrapClass,
      a.e("wrap"),
      { [a.em("wrap", "hidden-default")]: !r.native }
    ]), K = d(() => [a.e("view"), r.viewClass]), R = /* @__PURE__ */ t(() => {
      var e;
      l.value && ((e = s.value) == null || e.handleScroll(l.value), y = l.value.scrollTop, S = l.value.scrollLeft, O("scroll", {
        scrollTop: l.value.scrollTop,
        scrollLeft: l.value.scrollLeft
      }));
    }, "handleScroll");
    function M(e, v) {
      te(e) ? l.value.scrollTo(e) : c(e) && c(v) && l.value.scrollTo(e, v);
    }
    t(M, "scrollTo");
    const A = /* @__PURE__ */ t((e) => {
      if (!c(e)) {
        N(w, "value must be a number");
        return;
      }
      l.value.scrollTop = e;
    }, "setScrollTop"), P = /* @__PURE__ */ t((e) => {
      if (!c(e)) {
        N(w, "value must be a number");
        return;
      }
      l.value.scrollLeft = e;
    }, "setScrollLeft"), o = /* @__PURE__ */ t(() => {
      var e;
      (e = s.value) == null || e.update();
    }, "update");
    return _(() => r.noresize, (e) => {
      e ? (u == null || u(), p == null || p()) : ({ stop: u } = Q(T, o), p = X("resize", o));
    }, { immediate: !0 }), _(() => [r.maxHeight, r.height], () => {
      r.native || L(() => {
        var e;
        o(), l.value && ((e = s.value) == null || e.handleScroll(l.value));
      });
    }), V(Z, j({
      scrollbarElement: z,
      wrapElement: l
    })), D(() => {
      l.value.scrollTop = y, l.value.scrollLeft = S;
    }), W(() => {
      r.native || L(() => {
        o();
      });
    }), $(() => o()), m({
      wrapRef: l,
      update: o,
      scrollTo: M,
      setScrollTop: A,
      setScrollLeft: P,
      handleScroll: R
    }), (e, v) => (b(), q("div", {
      ref_key: "scrollbarRef",
      ref: z,
      class: h(n(a).b())
    }, [
      x("div", {
        ref_key: "wrapRef",
        ref: l,
        class: h(n(H)),
        style: k(n(B)),
        onScroll: R
      }, [
        (b(), C(F(e.tag), {
          id: e.id,
          ref_key: "resizeRef",
          ref: T,
          class: h(n(K)),
          style: k(e.viewStyle),
          role: e.role,
          "aria-label": e.ariaLabel,
          "aria-orientation": e.ariaOrientation
        }, {
          default: G(() => [
            I(e.$slots, "default")
          ]),
          _: 3
        }, 8, ["id", "class", "style", "role", "aria-label", "aria-orientation"]))
      ], 38),
      e.native ? J("v-if", !0) : (b(), C(Y, {
        key: 0,
        ref_key: "barRef",
        ref: s,
        always: e.always,
        "min-size": e.minSize
      }, null, 8, ["always", "min-size"]))
    ], 2));
  }
});
var ye = /* @__PURE__ */ re(se, [["__file", "scrollbar.vue"]]);
export {
  ye as default
};
