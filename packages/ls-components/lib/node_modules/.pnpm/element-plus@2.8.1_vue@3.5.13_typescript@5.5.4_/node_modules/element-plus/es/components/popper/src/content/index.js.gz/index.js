var p = Object.defineProperty;
var t = (r, a) => p(r, "name", { value: a, configurable: !0 });
import { placements as n } from "../../../../../../../../@sxzz_popperjs-es@2.11.7/node_modules/@sxzz/popperjs-es/dist/index/index.js";
import { buildProps as o, definePropType as e } from "../../../../utils/vue/props/runtime/index.js";
import { useAriaProps as l } from "../../../../hooks/use-aria/index/index.js";
const s = ["fixed", "absolute"], u = o({
  boundariesPadding: {
    type: Number,
    default: 0
  },
  fallbackPlacements: {
    type: e(Array),
    default: void 0
  },
  gpuAcceleration: {
    type: Boolean,
    default: !0
  },
  offset: {
    type: Number,
    default: 12
  },
  placement: {
    type: String,
    values: n,
    default: "bottom"
  },
  popperOptions: {
    type: e(Object),
    default: /* @__PURE__ */ t(() => ({}), "default")
  },
  strategy: {
    type: String,
    values: s,
    default: "absolute"
  }
}), d = o({
  ...u,
  id: String,
  style: {
    type: e([String, Array, Object])
  },
  className: {
    type: e([String, Array, Object])
  },
  effect: {
    type: e(String),
    default: "dark"
  },
  visible: Boolean,
  enterable: {
    type: Boolean,
    default: !0
  },
  pure: Boolean,
  focusOnShow: {
    type: Boolean,
    default: !1
  },
  trapping: {
    type: Boolean,
    default: !1
  },
  popperClass: {
    type: e([String, Array, Object])
  },
  popperStyle: {
    type: e([String, Array, Object])
  },
  referenceEl: {
    type: e(Object)
  },
  triggerTargetEl: {
    type: e(Object)
  },
  stopPopperMouseEvent: {
    type: Boolean,
    default: !0
  },
  virtualTriggering: Boolean,
  zIndex: Number,
  ...l(["ariaLabel"])
}), b = {
  mouseenter: /* @__PURE__ */ t((r) => r instanceof MouseEvent, "mouseenter"),
  mouseleave: /* @__PURE__ */ t((r) => r instanceof MouseEvent, "mouseleave"),
  focus: /* @__PURE__ */ t(() => !0, "focus"),
  blur: /* @__PURE__ */ t(() => !0, "blur"),
  close: /* @__PURE__ */ t(() => !0, "close")
};
export {
  b as popperContentEmits,
  d as popperContentProps,
  u as popperCoreConfigProps
};
