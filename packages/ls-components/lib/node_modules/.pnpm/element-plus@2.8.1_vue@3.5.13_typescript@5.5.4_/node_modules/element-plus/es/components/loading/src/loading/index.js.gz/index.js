var A = Object.defineProperty;
var i = (o, s) => A(o, "name", { value: s, configurable: !0 });
import { ref as w, reactive as T, defineComponent as N, h as l, Transition as S, withCtx as _, withDirectives as $, createVNode as k, vShow as y, createApp as B, toRefs as E } from "vue";
import { removeClass as m } from "../../../../utils/dom/style/index.js";
import { useGlobalComponentSettings as I } from "../../../config-provider/src/hooks/use-global-config/index.js";
function G(o) {
  let s;
  const c = w(!1), t = T({
    ...o,
    originalPosition: "",
    originalOverflow: "",
    visible: !1
  });
  function g(e) {
    t.text = e;
  }
  i(g, "setText");
  function b() {
    const e = t.parent, r = a.ns;
    if (!e.vLoadingAddClassList) {
      let n = e.getAttribute("loading-number");
      n = Number.parseInt(n) - 1, n ? e.setAttribute("loading-number", n.toString()) : (m(e, r.bm("parent", "relative")), e.removeAttribute("loading-number")), m(e, r.bm("parent", "hidden"));
    }
    d(), v.unmount();
  }
  i(b, "destroySelf");
  function d() {
    var e, r;
    (r = (e = a.$el) == null ? void 0 : e.parentNode) == null || r.removeChild(a.$el);
  }
  i(d, "removeElLoadingChild");
  function p() {
    var e;
    o.beforeClose && !o.beforeClose() || (c.value = !0, clearTimeout(s), s = setTimeout(u, 400), t.visible = !1, (e = o.closed) == null || e.call(o));
  }
  i(p, "close");
  function u() {
    if (!c.value)
      return;
    const e = t.parent;
    c.value = !1, e.vLoadingAddClassList = void 0, b();
  }
  i(u, "handleAfterLeave");
  const C = N({
    name: "ElLoading",
    setup(e, { expose: r }) {
      const { ns: n, zIndex: x } = I("loading");
      return r({
        ns: n,
        zIndex: x
      }), () => {
        const f = t.spinner || t.svg, L = l("svg", {
          class: "circular",
          viewBox: t.svgViewBox ? t.svgViewBox : "0 0 50 50",
          ...f ? { innerHTML: f } : {}
        }, [
          l("circle", {
            class: "path",
            cx: "25",
            cy: "25",
            r: "20",
            fill: "none"
          })
        ]), h = t.text ? l("p", { class: n.b("text") }, [t.text]) : void 0;
        return l(S, {
          name: n.b("fade"),
          onAfterLeave: u
        }, {
          default: _(() => [
            $(k("div", {
              style: {
                backgroundColor: t.background || ""
              },
              class: [
                n.b("mask"),
                t.customClass,
                t.fullscreen ? "is-fullscreen" : ""
              ]
            }, [
              l("div", {
                class: n.b("spinner")
              }, [L, h])
            ]), [[y, t.visible]])
          ])
        });
      };
    }
  }), v = B(C), a = v.mount(document.createElement("div"));
  return {
    ...E(t),
    setText: g,
    removeElLoadingChild: d,
    close: p,
    handleAfterLeave: u,
    vm: a,
    get $el() {
      return a.$el;
    }
  };
}
i(G, "createLoadingComponent");
export {
  G as createLoadingComponent
};
