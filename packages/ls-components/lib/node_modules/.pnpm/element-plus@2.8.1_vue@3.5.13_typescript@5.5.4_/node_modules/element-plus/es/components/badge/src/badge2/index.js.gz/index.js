import { defineComponent as p, computed as m, openBlock as _, createElementBlock as b, normalizeClass as u, unref as o, renderSlot as h, createVNode as C, Transition as y, withCtx as $, withDirectives as D, createElementVNode as S, normalizeStyle as w, toDisplayString as B, vShow as N } from "vue";
import { badgeProps as k } from "../badge/index.js";
import x from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as z } from "../../../../hooks/use-namespace/index/index.js";
import { isNumber as d } from "../../../../utils/types/index.js";
import { addUnit as f } from "../../../../utils/dom/style/index.js";
const E = p({
  name: "ElBadge"
}), T = /* @__PURE__ */ p({
  ...E,
  props: k,
  setup(c, { expose: v }) {
    const e = c, n = z("badge"), r = m(() => e.isDot ? "" : d(e.value) && d(e.max) ? e.max < e.value ? `${e.max}+` : e.value === 0 && !e.showZero ? "" : `${e.value}` : `${e.value}`), g = m(() => {
      var t, a, s, l, i;
      return [
        {
          backgroundColor: e.color,
          marginRight: f(-((a = (t = e.offset) == null ? void 0 : t[0]) != null ? a : 0)),
          marginTop: f((l = (s = e.offset) == null ? void 0 : s[1]) != null ? l : 0)
        },
        (i = e.badgeStyle) != null ? i : {}
      ];
    });
    return v({
      content: r
    }), (t, a) => (_(), b("div", {
      class: u(o(n).b())
    }, [
      h(t.$slots, "default"),
      C(y, {
        name: `${o(n).namespace.value}-zoom-in-center`,
        persisted: ""
      }, {
        default: $(() => [
          D(S("sup", {
            class: u([
              o(n).e("content"),
              o(n).em("content", t.type),
              o(n).is("fixed", !!t.$slots.default),
              o(n).is("dot", t.isDot),
              t.badgeClass
            ]),
            style: w(o(g)),
            textContent: B(o(r))
          }, null, 14, ["textContent"]), [
            [N, !t.hidden && (o(r) || t.isDot)]
          ])
        ]),
        _: 1
      }, 8, ["name"])
    ], 2));
  }
});
var q = /* @__PURE__ */ x(T, [["__file", "badge.vue"]]);
export {
  q as default
};
