var a = Object.defineProperty;
var t = (e, r) => a(e, "name", { value: r, configurable: !0 });
import { buildProps as i, definePropType as l } from "../../../../utils/vue/props/runtime/index.js";
import { useAriaProps as o } from "../../../../hooks/use-aria/index/index.js";
import { isNumber as n } from "../../../../utils/types/index.js";
const f = i({
  height: {
    type: [String, Number],
    default: ""
  },
  maxHeight: {
    type: [String, Number],
    default: ""
  },
  native: {
    type: Boolean,
    default: !1
  },
  wrapStyle: {
    type: l([String, Object, Array]),
    default: ""
  },
  wrapClass: {
    type: [String, Array],
    default: ""
  },
  viewClass: {
    type: [String, Array],
    default: ""
  },
  viewStyle: {
    type: [String, Array, Object],
    default: ""
  },
  noresize: Boolean,
  tag: {
    type: String,
    default: "div"
  },
  always: Boolean,
  minSize: {
    type: Number,
    default: 20
  },
  id: String,
  role: String,
  ...o(["ariaLabel", "ariaOrientation"])
}), d = {
  scroll: /* @__PURE__ */ t(({
    scrollTop: e,
    scrollLeft: r
  }) => [e, r].every(n), "scroll")
};
export {
  d as scrollbarEmits,
  f as scrollbarProps
};
