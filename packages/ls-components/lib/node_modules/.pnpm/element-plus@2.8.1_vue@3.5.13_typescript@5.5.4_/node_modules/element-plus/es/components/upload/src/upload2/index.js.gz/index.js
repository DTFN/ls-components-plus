import { defineComponent as w, shallowRef as T, computed as $, onBeforeUnmount as N, provide as V, toRef as j, openBlock as d, createElementBlock as D, unref as o, createBlock as m, createSlots as c, withCtx as l, createVNode as H, mergeProps as h, renderSlot as r, createCommentVNode as s } from "vue";
import { uploadContextKey as K } from "../constants/index.js";
import k from "../upload-list2/index.js";
import R from "../upload-content2/index.js";
import { useHandlers as O } from "../use-handlers/index.js";
import { uploadProps as q } from "../upload/index.js";
import z from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useFormDisabled as A } from "../../../form/src/hooks/use-form-common-props/index.js";
const G = w({
  name: "ElUpload"
}), I = /* @__PURE__ */ w({
  ...G,
  props: q,
  setup(b, { expose: P }) {
    const t = b, v = A(), f = T(), {
      abort: C,
      submit: F,
      clearFiles: L,
      uploadFiles: i,
      handleStart: g,
      handleError: S,
      handleRemove: a,
      handleSuccess: U,
      handleProgress: E,
      revokeFileObjectURL: B
    } = O(t, f), n = $(() => t.listType === "picture-card"), y = $(() => ({
      ...t,
      fileList: i.value,
      onStart: g,
      onProgress: E,
      onSuccess: U,
      onError: S,
      onRemove: a
    }));
    return N(() => {
      i.value.forEach(B);
    }), V(K, {
      accept: j(t, "accept")
    }), P({
      abort: C,
      submit: F,
      clearFiles: L,
      handleStart: g,
      handleRemove: a
    }), (e, J) => (d(), D("div", null, [
      o(n) && e.showFileList ? (d(), m(k, {
        key: 0,
        disabled: o(v),
        "list-type": e.listType,
        files: o(i),
        crossorigin: e.crossorigin,
        "handle-preview": e.onPreview,
        onRemove: o(a)
      }, c({
        append: l(() => [
          H(R, h({
            ref_key: "uploadRef",
            ref: f
          }, o(y)), {
            default: l(() => [
              e.$slots.trigger ? r(e.$slots, "trigger", { key: 0 }) : s("v-if", !0),
              !e.$slots.trigger && e.$slots.default ? r(e.$slots, "default", { key: 1 }) : s("v-if", !0)
            ]),
            _: 3
          }, 16)
        ]),
        _: 2
      }, [
        e.$slots.file ? {
          name: "default",
          fn: l(({ file: p, index: u }) => [
            r(e.$slots, "file", {
              file: p,
              index: u
            })
          ])
        } : void 0
      ]), 1032, ["disabled", "list-type", "files", "crossorigin", "handle-preview", "onRemove"])) : s("v-if", !0),
      !o(n) || o(n) && !e.showFileList ? (d(), m(R, h({
        key: 1,
        ref_key: "uploadRef",
        ref: f
      }, o(y)), {
        default: l(() => [
          e.$slots.trigger ? r(e.$slots, "trigger", { key: 0 }) : s("v-if", !0),
          !e.$slots.trigger && e.$slots.default ? r(e.$slots, "default", { key: 1 }) : s("v-if", !0)
        ]),
        _: 3
      }, 16)) : s("v-if", !0),
      e.$slots.trigger ? r(e.$slots, "default", { key: 2 }) : s("v-if", !0),
      r(e.$slots, "tip"),
      !o(n) && e.showFileList ? (d(), m(k, {
        key: 3,
        disabled: o(v),
        "list-type": e.listType,
        files: o(i),
        crossorigin: e.crossorigin,
        "handle-preview": e.onPreview,
        onRemove: o(a)
      }, c({ _: 2 }, [
        e.$slots.file ? {
          name: "default",
          fn: l(({ file: p, index: u }) => [
            r(e.$slots, "file", {
              file: p,
              index: u
            })
          ])
        } : void 0
      ]), 1032, ["disabled", "list-type", "files", "crossorigin", "handle-preview", "onRemove"])) : s("v-if", !0)
    ]));
  }
});
var ee = /* @__PURE__ */ z(I, [["__file", "upload.vue"]]);
export {
  ee as default
};
