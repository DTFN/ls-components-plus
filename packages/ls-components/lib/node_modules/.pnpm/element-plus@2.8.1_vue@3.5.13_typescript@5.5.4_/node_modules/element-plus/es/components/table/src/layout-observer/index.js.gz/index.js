var m = Object.defineProperty;
var d = (o, s) => m(o, "name", { value: s, configurable: !0 });
import { getCurrentInstance as b, onBeforeMount as p, onMounted as y, onUpdated as C, onUnmounted as w, computed as A } from "vue";
function q(o) {
  const s = b();
  p(() => {
    l.value.addObserver(s);
  }), y(() => {
    v(l.value), h(l.value);
  }), C(() => {
    v(l.value), h(l.value);
  }), w(() => {
    l.value.removeObserver(s);
  });
  const l = A(() => {
    const t = o.layout;
    if (!t)
      throw new Error("Can not find table layout.");
    return t;
  }), v = /* @__PURE__ */ d((t) => {
    var u;
    const n = ((u = o.vnode.el) == null ? void 0 : u.querySelectorAll("colgroup > col")) || [];
    if (!n.length)
      return;
    const i = t.getFlattenColumns(), a = {};
    i.forEach((e) => {
      a[e.id] = e;
    });
    for (let e = 0, c = n.length; e < c; e++) {
      const r = n[e], f = r.getAttribute("name"), g = a[f];
      g && r.setAttribute("width", g.realWidth || g.width);
    }
  }, "onColumnsChange"), h = /* @__PURE__ */ d((t) => {
    var u, n;
    const i = ((u = o.vnode.el) == null ? void 0 : u.querySelectorAll("colgroup > col[name=gutter]")) || [];
    for (let e = 0, c = i.length; e < c; e++)
      i[e].setAttribute("width", t.scrollY.value ? t.gutterWidth : "0");
    const a = ((n = o.vnode.el) == null ? void 0 : n.querySelectorAll("th.gutter")) || [];
    for (let e = 0, c = a.length; e < c; e++) {
      const r = a[e];
      r.style.width = t.scrollY.value ? `${t.gutterWidth}px` : "0", r.style.display = t.scrollY.value ? "" : "none";
    }
  }, "onScrollableChange");
  return {
    tableLayout: l.value,
    onColumnsChange: v,
    onScrollableChange: h
  };
}
d(q, "useLayoutObserver");
export {
  q as default
};
