var n = Object.defineProperty;
var S = (E, T) => n(E, "name", { value: T, configurable: !0 });
import { isVNode as p } from "vue";
import { isArray as A, hasOwn as u, camelize as _ } from "../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { debugWarn as f } from "../../error/index.js";
const L = "utils/vue/vnode";
var m = /* @__PURE__ */ ((E) => (E[E.TEXT = 1] = "TEXT", E[E.CLASS = 2] = "CLASS", E[E.STYLE = 4] = "STYLE", E[E.PROPS = 8] = "PROPS", E[E.FULL_PROPS = 16] = "FULL_PROPS", E[E.HYDRATE_EVENTS = 32] = "HYDRATE_EVENTS", E[E.STABLE_FRAGMENT = 64] = "STABLE_FRAGMENT", E[E.KEYED_FRAGMENT = 128] = "KEYED_FRAGMENT", E[E.UNKEYED_FRAGMENT = 256] = "UNKEYED_FRAGMENT", E[E.NEED_PATCH = 512] = "NEED_PATCH", E[E.DYNAMIC_SLOTS = 1024] = "DYNAMIC_SLOTS", E[E.HOISTED = -1] = "HOISTED", E[E.BAIL = -2] = "BAIL", E))(m || {});
const i = /* @__PURE__ */ S((E) => {
  if (!p(E))
    return f(L, "[getNormalizedProps] must be a VNode"), {};
  const T = E.props || {}, e = (p(E.type) ? E.type.props : void 0) || {}, r = {};
  return Object.keys(e).forEach((o) => {
    u(e[o], "default") && (r[o] = e[o].default);
  }), Object.keys(T).forEach((o) => {
    r[_(o)] = T[o];
  }), r;
}, "getNormalizedProps"), N = /* @__PURE__ */ S((E) => {
  const T = A(E) ? E : [E], e = [];
  return T.forEach((r) => {
    var o;
    A(r) ? e.push(...N(r)) : p(r) && A(r.children) ? e.push(...N(r.children)) : (e.push(r), p(r) && ((o = r.component) != null && o.subTree) && e.push(...N(r.component.subTree)));
  }), e;
}, "flattedChildren");
export {
  m as PatchFlags,
  N as flattedChildren,
  i as getNormalizedProps
};
