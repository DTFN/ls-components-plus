var k = Object.defineProperty;
var s = (a, l) => k(a, "name", { value: l, configurable: !0 });
import { getCurrentInstance as F, ref as o, watchEffect as y, computed as b, unref as W, renderSlot as x, h as I, Comment as H } from "vue";
import { defaultRenderCell as S, treeCellPrefix as j, cellForced as M, getDefaultClassName as U } from "../../config/index.js";
import { parseWidth as V, parseMinWidth as _ } from "../../util/index.js";
import { useNamespace as q } from "../../../../../hooks/use-namespace/index/index.js";
import { debugWarn as z } from "../../../../../utils/error/index.js";
function te(a, l, m) {
  const d = F(), w = o(""), A = o(!1), u = o(), v = o(), g = q("table");
  y(() => {
    u.value = a.align ? `is-${a.align}` : null, u.value;
  }), y(() => {
    v.value = a.headerAlign ? `is-${a.headerAlign}` : u.value, v.value;
  });
  const N = b(() => {
    let e = d.vnode.vParent || d.parent;
    for (; e && !e.tableId && !e.columnId; )
      e = e.vnode.vParent || e.parent;
    return e;
  }), P = b(() => {
    const { store: e } = d.parent;
    if (!e)
      return !1;
    const { treeData: r } = e.states, t = r.value;
    return t && Object.keys(t).length > 0;
  }), C = o(V(a.width)), p = o(_(a.minWidth)), $ = /* @__PURE__ */ s((e) => (C.value && (e.width = C.value), p.value && (e.minWidth = p.value), !C.value && p.value && (e.width = void 0), e.minWidth || (e.minWidth = 80), e.realWidth = Number(e.width === void 0 ? e.minWidth : e.width), e), "setColumnWidth"), E = /* @__PURE__ */ s((e) => {
    const r = e.type, t = M[r] || {};
    Object.keys(t).forEach((i) => {
      const c = t[i];
      i !== "className" && c !== void 0 && (e[i] = c);
    });
    const n = U(r);
    if (n) {
      const i = `${W(g.namespace)}-${n}`;
      e.className = e.className ? `${e.className} ${i}` : i;
    }
    return e;
  }, "setColumnForcedProps"), O = /* @__PURE__ */ s((e) => {
    Array.isArray(e) ? e.forEach((t) => r(t)) : r(e);
    function r(t) {
      var n;
      ((n = t == null ? void 0 : t.type) == null ? void 0 : n.name) === "ElTableColumn" && (t.vParent = d);
    }
    s(r, "check");
  }, "checkSubColumn");
  return {
    columnId: w,
    realAlign: u,
    isSubColumn: A,
    realHeaderAlign: v,
    columnOrTableParent: N,
    setColumnWidth: $,
    setColumnForcedProps: E,
    setColumnRenders: /* @__PURE__ */ s((e) => {
      a.renderHeader ? z("TableColumn", "Comparing to render-header, scoped-slot header is easier to use. We recommend users to use scoped-slot header.") : e.type !== "selection" && (e.renderHeader = (t) => (d.columnConfig.value.label, x(l, "header", t, () => [e.label]))), l["filter-icon"] && (e.renderFilterIcon = (t) => x(l, "filter-icon", t));
      let r = e.renderCell;
      return e.type === "expand" ? (e.renderCell = (t) => I("div", {
        class: "cell"
      }, [r(t)]), m.value.renderExpanded = (t) => l.default ? l.default(t) : l.default) : (r = r || S, e.renderCell = (t) => {
        let n = null;
        if (l.default) {
          const h = l.default(t);
          n = h.some((T) => T.type !== H) ? h : r(t);
        } else
          n = r(t);
        const { columns: i } = m.value.store.states, c = i.value.findIndex((h) => h.type === "default"), D = P.value && t.cellIndex === c, R = j(t, D), f = {
          class: "cell",
          style: {}
        };
        return e.showOverflowTooltip && (f.class = `${f.class} ${W(g.namespace)}-tooltip`, f.style = {
          width: `${(t.column.realWidth || Number(t.column.width)) - 1}px`
        }), O(n), I("div", f, [R, n]);
      }), e;
    }, "setColumnRenders"),
    getPropsData: /* @__PURE__ */ s((...e) => e.reduce((r, t) => (Array.isArray(t) && t.forEach((n) => {
      r[n] = a[n];
    }), r), {}), "getPropsData"),
    getColumnElIndex: /* @__PURE__ */ s((e, r) => Array.prototype.indexOf.call(e, r), "getColumnElIndex"),
    updateColumnOrder: /* @__PURE__ */ s(() => {
      m.value.store.commit("updateColumnOrder", d.columnConfig.value);
    }, "updateColumnOrder")
  };
}
s(te, "useRender");
export {
  te as default
};
