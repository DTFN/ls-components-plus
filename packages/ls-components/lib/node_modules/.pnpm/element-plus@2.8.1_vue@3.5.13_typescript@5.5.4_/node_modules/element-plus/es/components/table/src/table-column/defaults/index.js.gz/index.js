var n = Object.defineProperty;
var r = (e, t) => n(e, "name", { value: t, configurable: !0 });
var i = {
  type: {
    type: String,
    default: "default"
  },
  label: String,
  className: String,
  labelClassName: String,
  property: String,
  prop: String,
  width: {
    type: [String, Number],
    default: ""
  },
  minWidth: {
    type: [String, Number],
    default: ""
  },
  renderHeader: Function,
  sortable: {
    type: [Boolean, String],
    default: !1
  },
  sortMethod: Function,
  sortBy: [String, Function, Array],
  resizable: {
    type: Boolean,
    default: !0
  },
  columnKey: String,
  align: String,
  headerAlign: String,
  showOverflowTooltip: {
    type: [Boolean, Object],
    default: void 0
  },
  fixed: [Boolean, String],
  formatter: Function,
  selectable: Function,
  reserveSelection: Boolean,
  filterMethod: Function,
  filteredValue: Array,
  filters: Array,
  filterPlacement: String,
  filterMultiple: {
    type: Boolean,
    default: !0
  },
  filterClassName: String,
  index: [Number, Function],
  sortOrders: {
    type: Array,
    default: /* @__PURE__ */ r(() => ["ascending", "descending", null], "default"),
    validator: /* @__PURE__ */ r((e) => e.every((t) => ["ascending", "descending", null].includes(t)), "validator")
  }
};
export {
  i as default
};
