var p = Object.defineProperty;
var o = (a, f) => p(a, "name", { value: f, configurable: !0 });
import { ref as g, computed as y, unref as r, watch as ee, nextTick as te } from "vue";
import E from "../../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { buildPickerTable as ae } from "../../utils/index.js";
import { useLocale as L } from "../../../../../hooks/use-locale/index/index.js";
import { castArray as S } from "../../../../../utils/arrays/index.js";
import { useNamespace as ne } from "../../../../../hooks/use-namespace/index/index.js";
import se from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/flatten/index.js";
const R = /* @__PURE__ */ o((a = "") => ["normal", "today"].includes(a), "isNormalDay"), me = /* @__PURE__ */ o((a, f) => {
  const { lang: w } = L(), b = g(), D = g(), M = g(), C = g(), x = g([[], [], [], [], [], []]);
  let v = !1;
  const k = a.date.$locale().weekStart || 7, c = a.date.locale("en").localeData().weekdaysShort().map((e) => e.toLowerCase()), i = y(() => k > 3 ? 7 - k : -k), N = y(() => {
    const e = a.date.startOf("month");
    return e.subtract(e.day() || 7, "day");
  }), _ = y(() => c.concat(c).slice(k, k + 7)), V = y(() => se(r(O)).some((e) => e.isCurrent)), K = y(() => {
    const e = a.date.startOf("month"), t = e.day() || 7, n = e.daysInMonth(), s = e.subtract(1, "month").daysInMonth();
    return {
      startOfMonthDay: t,
      dateCountOfMonth: n,
      dateCountOfLastMonth: s
    };
  }), j = y(() => a.selectionMode === "dates" ? S(a.parsedValue) : []), F = /* @__PURE__ */ o((e, { count: t, rowIndex: n, columnIndex: s }) => {
    const { startOfMonthDay: d, dateCountOfMonth: l, dateCountOfLastMonth: m } = r(K), h = r(i);
    if (n >= 0 && n <= 1) {
      const u = d + h < 0 ? 7 + d + h : d + h;
      if (s + n * 7 >= u)
        return e.text = t, !0;
      e.text = m - (u - s % 7) + 1 + n * 7, e.type = "prev-month";
    } else
      return t <= l ? e.text = t : (e.text = t - l, e.type = "next-month"), !0;
    return !1;
  }, "setDateText"), $ = /* @__PURE__ */ o((e, { columnIndex: t, rowIndex: n }, s) => {
    const { disabledDate: d, cellClassName: l } = a, m = r(j), h = F(e, { count: s, rowIndex: n, columnIndex: t }), u = e.dayjs.toDate();
    return e.selected = m.find((Z) => Z.isSame(e.dayjs, "day")), e.isSelected = !!e.selected, e.isCurrent = W(e), e.disabled = d == null ? void 0 : d(u), e.customClass = l == null ? void 0 : l(u), h;
  }, "setCellMetadata"), B = /* @__PURE__ */ o((e) => {
    if (a.selectionMode === "week") {
      const [t, n] = a.showWeekNumber ? [1, 7] : [0, 6], s = I(e[t + 1]);
      e[t].inRange = s, e[t].start = s, e[n].inRange = s, e[n].end = s;
    }
  }, "setRowMetadata"), O = y(() => {
    const { minDate: e, maxDate: t, rangeState: n, showWeekNumber: s } = a, d = r(i), l = r(x), m = "day";
    let h = 1;
    if (s)
      for (let u = 0; u < 6; u++)
        l[u][0] || (l[u][0] = {
          type: "week",
          text: r(N).add(u * 7 + 1, m).week()
        });
    return ae({ row: 6, column: 7 }, l, {
      startDate: e,
      columnIndexOffset: s ? 1 : 0,
      nextEndDate: n.endDate || t || n.selecting && e || null,
      now: E().locale(r(w)).startOf(m),
      unit: m,
      relativeDateGetter: /* @__PURE__ */ o((u) => r(N).add(u - d, m), "relativeDateGetter"),
      setCellMetadata: /* @__PURE__ */ o((...u) => {
        $(...u, h) && (h += 1);
      }, "setCellMetadata"),
      setRowMetadata: B
    }), l;
  });
  ee(() => a.date, async () => {
    var e;
    (e = r(b)) != null && e.contains(document.activeElement) && (await te(), await T());
  });
  const T = /* @__PURE__ */ o(async () => {
    var e;
    return (e = r(D)) == null ? void 0 : e.focus();
  }, "focus"), W = /* @__PURE__ */ o((e) => a.selectionMode === "date" && R(e.type) && U(e, a.parsedValue), "isCurrent"), U = /* @__PURE__ */ o((e, t) => t ? E(t).locale(r(w)).isSame(a.date.date(Number(e.text)), "day") : !1, "cellMatchesDate"), P = /* @__PURE__ */ o((e, t) => {
    const n = e * 7 + (t - (a.showWeekNumber ? 1 : 0)) - r(i);
    return r(N).add(n, "day");
  }, "getDateOfCell"), G = /* @__PURE__ */ o((e) => {
    var t;
    if (!a.rangeState.selecting)
      return;
    let n = e.target;
    if (n.tagName === "SPAN" && (n = (t = n.parentNode) == null ? void 0 : t.parentNode), n.tagName === "DIV" && (n = n.parentNode), n.tagName !== "TD")
      return;
    const s = n.parentNode.rowIndex - 1, d = n.cellIndex;
    r(O)[s][d].disabled || (s !== r(M) || d !== r(C)) && (M.value = s, C.value = d, f("changerange", {
      selecting: !0,
      endDate: P(s, d)
    }));
  }, "handleMouseMove"), q = /* @__PURE__ */ o((e) => !r(V) && (e == null ? void 0 : e.text) === 1 && e.type === "normal" || e.isCurrent, "isSelectedCell"), z = /* @__PURE__ */ o((e) => {
    v || r(V) || a.selectionMode !== "date" || A(e, !0);
  }, "handleFocus"), H = /* @__PURE__ */ o((e) => {
    e.target.closest("td") && (v = !0);
  }, "handleMouseDown"), J = /* @__PURE__ */ o((e) => {
    e.target.closest("td") && (v = !1);
  }, "handleMouseUp"), Q = /* @__PURE__ */ o((e) => {
    !a.rangeState.selecting || !a.minDate ? (f("pick", { minDate: e, maxDate: null }), f("select", !0)) : (e >= a.minDate ? f("pick", { minDate: a.minDate, maxDate: e }) : f("pick", { minDate: e, maxDate: a.minDate }), f("select", !1));
  }, "handleRangePick"), X = /* @__PURE__ */ o((e) => {
    const t = e.week(), n = `${e.year()}w${t}`;
    f("pick", {
      year: e.year(),
      week: t,
      value: n,
      date: e.startOf("week")
    });
  }, "handleWeekPick"), Y = /* @__PURE__ */ o((e, t) => {
    const n = t ? S(a.parsedValue).filter((s) => (s == null ? void 0 : s.valueOf()) !== e.valueOf()) : S(a.parsedValue).concat([e]);
    f("pick", n);
  }, "handleDatesPick"), A = /* @__PURE__ */ o((e, t = !1) => {
    const n = e.target.closest("td");
    if (!n)
      return;
    const s = n.parentNode.rowIndex - 1, d = n.cellIndex, l = r(O)[s][d];
    if (l.disabled || l.type === "week")
      return;
    const m = P(s, d);
    switch (a.selectionMode) {
      case "range": {
        Q(m);
        break;
      }
      case "date": {
        f("pick", m, t);
        break;
      }
      case "week": {
        X(m);
        break;
      }
      case "dates": {
        Y(m, !!l.selected);
        break;
      }
    }
  }, "handlePickDate"), I = /* @__PURE__ */ o((e) => {
    if (a.selectionMode !== "week")
      return !1;
    let t = a.date.startOf("day");
    if (e.type === "prev-month" && (t = t.subtract(1, "month")), e.type === "next-month" && (t = t.add(1, "month")), t = t.date(Number.parseInt(e.text, 10)), a.parsedValue && !Array.isArray(a.parsedValue)) {
      const n = (a.parsedValue.day() - k + 7) % 7 - 1;
      return a.parsedValue.subtract(n, "day").isSame(t, "day");
    }
    return !1;
  }, "isWeekActive");
  return {
    WEEKS: _,
    rows: O,
    tbodyRef: b,
    currentCellRef: D,
    focus: T,
    isCurrent: W,
    isWeekActive: I,
    isSelectedCell: q,
    handlePickDate: A,
    handleMouseUp: J,
    handleMouseDown: H,
    handleMouseMove: G,
    handleFocus: z
  };
}, "useBasicDateTable"), ye = /* @__PURE__ */ o((a, {
  isCurrent: f,
  isWeekActive: w
}) => {
  const b = ne("date-table"), { t: D } = L(), M = y(() => [
    b.b(),
    { "is-week-mode": a.selectionMode === "week" }
  ]), C = y(() => D("el.datepicker.dateTablePrompt")), x = y(() => D("el.datepicker.week"));
  return {
    tableKls: M,
    tableLabel: C,
    weekLabel: x,
    getCellClasses: /* @__PURE__ */ o((c) => {
      const i = [];
      return R(c.type) && !c.disabled ? (i.push("available"), c.type === "today" && i.push("today")) : i.push(c.type), f(c) && i.push("current"), c.inRange && (R(c.type) || a.selectionMode === "week") && (i.push("in-range"), c.start && i.push("start-date"), c.end && i.push("end-date")), c.disabled && i.push("disabled"), c.selected && i.push("selected"), c.customClass && i.push(c.customClass), i.join(" ");
    }, "getCellClasses"),
    getRowKls: /* @__PURE__ */ o((c) => [
      b.e("row"),
      { current: w(c) }
    ], "getRowKls"),
    t: D
  };
}, "useBasicDateTableDOM");
export {
  me as useBasicDateTable,
  ye as useBasicDateTableDOM
};
