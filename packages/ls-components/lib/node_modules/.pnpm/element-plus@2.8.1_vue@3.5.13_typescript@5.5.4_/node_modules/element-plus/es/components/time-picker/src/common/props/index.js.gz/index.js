var o = Object.defineProperty;
var t = (r, a) => o(r, "name", { value: a, configurable: !0 });
import { CircleClose as l } from "@element-plus/icons-vue";
import { disabledTimeListsProps as i } from "../../props/shared/index.js";
import { buildProps as p, definePropType as e } from "../../../../../utils/vue/props/runtime/index.js";
import { useSizeProp as n } from "../../../../../hooks/use-size/index/index.js";
import { useEmptyValuesProps as d } from "../../../../../hooks/use-empty-values/index/index.js";
import { useAriaProps as u } from "../../../../../hooks/use-aria/index/index.js";
const b = p({
  id: {
    type: e([Array, String])
  },
  name: {
    type: e([Array, String]),
    default: ""
  },
  popperClass: {
    type: String,
    default: ""
  },
  format: String,
  valueFormat: String,
  dateFormat: String,
  timeFormat: String,
  type: {
    type: String,
    default: ""
  },
  clearable: {
    type: Boolean,
    default: !0
  },
  clearIcon: {
    type: e([String, Object]),
    default: l
  },
  editable: {
    type: Boolean,
    default: !0
  },
  prefixIcon: {
    type: e([String, Object]),
    default: ""
  },
  size: n,
  readonly: Boolean,
  disabled: Boolean,
  placeholder: {
    type: String,
    default: ""
  },
  popperOptions: {
    type: e(Object),
    default: /* @__PURE__ */ t(() => ({}), "default")
  },
  modelValue: {
    type: e([Date, Array, String, Number]),
    default: ""
  },
  rangeSeparator: {
    type: String,
    default: "-"
  },
  startPlaceholder: String,
  endPlaceholder: String,
  defaultValue: {
    type: e([Date, Array])
  },
  defaultTime: {
    type: e([Date, Array])
  },
  isRange: Boolean,
  ...i,
  disabledDate: {
    type: Function
  },
  cellClassName: {
    type: Function
  },
  shortcuts: {
    type: Array,
    default: /* @__PURE__ */ t(() => [], "default")
  },
  arrowControl: Boolean,
  tabindex: {
    type: e([String, Number]),
    default: 0
  },
  validateEvent: {
    type: Boolean,
    default: !0
  },
  unlinkPanels: Boolean,
  ...d,
  ...u(["ariaLabel"])
});
export {
  b as timePickerDefaultProps
};
