import { defineComponent as t, inject as m, watch as c, onBeforeUnmount as _, openBlock as i, createElementBlock as u, normalizeClass as w, unref as o, normalizeStyle as E } from "vue";
import { POPPER_CONTENT_INJECTION_KEY as d } from "../constants/index.js";
import { popperArrowProps as v } from "../arrow/index.js";
import P from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as N } from "../../../../hooks/use-namespace/index/index.js";
const O = t({
  name: "ElPopperArrow",
  inheritAttrs: !1
}), y = /* @__PURE__ */ t({
  ...O,
  props: v,
  setup(p, { expose: a }) {
    const n = p, s = N("popper"), { arrowOffset: f, arrowRef: r, arrowStyle: l } = m(d, void 0);
    return c(() => n.arrowOffset, (e) => {
      f.value = e;
    }), _(() => {
      r.value = void 0;
    }), a({
      arrowRef: r
    }), (e, A) => (i(), u("span", {
      ref_key: "arrowRef",
      ref: r,
      class: w(o(s).e("arrow")),
      style: E(o(l)),
      "data-popper-arrow": ""
    }, null, 6));
  }
});
var R = /* @__PURE__ */ P(y, [["__file", "arrow.vue"]]);
export {
  R as default
};
