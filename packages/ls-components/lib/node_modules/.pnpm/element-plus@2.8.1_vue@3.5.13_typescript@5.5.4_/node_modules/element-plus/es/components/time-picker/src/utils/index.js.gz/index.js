var m = Object.defineProperty;
var s = (r, t) => m(r, "name", { value: t, configurable: !0 });
import c from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { isDate as a, isArray as l } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isEmpty as f } from "../../../../utils/types/index.js";
const g = /* @__PURE__ */ s((r, t) => [
  r > 0 ? r - 1 : void 0,
  r,
  r < t ? r + 1 : void 0
], "buildTimeList"), A = /* @__PURE__ */ s((r) => Array.from(Array.from({ length: r }).keys()), "rangeArr"), D = /* @__PURE__ */ s((r) => r.replace(/\W?m{1,2}|\W?ZZ/g, "").replace(/\W?h{1,2}|\W?s{1,3}|\W?a/gi, "").trim(), "extractDateFormat"), x = /* @__PURE__ */ s((r) => r.replace(/\W?D{1,2}|\W?Do|\W?d{1,4}|\W?M{1,4}|\W?Y{2,4}/g, "").trim(), "extractTimeFormat"), u = /* @__PURE__ */ s(function(r, t) {
  const e = a(r), n = a(t);
  return e && n ? r.getTime() === t.getTime() : !e && !n ? r === t : !1;
}, "dateEquals"), h = /* @__PURE__ */ s(function(r, t) {
  const e = l(r), n = l(t);
  return e && n ? r.length !== t.length ? !1 : r.every((i, o) => u(i, t[o])) : !e && !n ? u(r, t) : !1;
}, "valueEquals"), v = /* @__PURE__ */ s(function(r, t, e) {
  const n = f(t) || t === "x" ? c(r).locale(e) : c(r, t).locale(e);
  return n.isValid() ? n : void 0;
}, "parseDate"), I = /* @__PURE__ */ s(function(r, t, e) {
  return f(t) ? r : t === "x" ? +r : c(r).locale(e).format(t);
}, "formatter"), T = /* @__PURE__ */ s((r, t) => {
  var e;
  const n = [], i = t == null ? void 0 : t();
  for (let o = 0; o < r; o++)
    n.push((e = i == null ? void 0 : i.includes(o)) != null ? e : !1);
  return n;
}, "makeList");
export {
  g as buildTimeList,
  u as dateEquals,
  D as extractDateFormat,
  x as extractTimeFormat,
  I as formatter,
  T as makeList,
  v as parseDate,
  A as rangeArr,
  h as valueEquals
};
