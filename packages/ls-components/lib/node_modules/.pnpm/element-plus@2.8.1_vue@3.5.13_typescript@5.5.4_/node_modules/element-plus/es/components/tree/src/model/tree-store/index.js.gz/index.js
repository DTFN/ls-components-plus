var K = Object.defineProperty;
var a = (p, e) => K(p, "name", { value: e, configurable: !0 });
import k from "../node/index.js";
import { getNodeKey as v } from "../util/index.js";
import { hasOwn as C, isObject as m } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isPropAbsent as E } from "../../../../../utils/types/index.js";
const f = class f {
  constructor(e) {
    this.currentNode = null, this.currentNodeKey = null;
    for (const t in e)
      C(e, t) && (this[t] = e[t]);
    this.nodesMap = {};
  }
  initialize() {
    if (this.root = new k({
      data: this.data,
      store: this
    }), this.root.initialize(), this.lazy && this.load) {
      const e = this.load;
      e(this.root, (t) => {
        this.root.doCreateChildren(t), this._initDefaultCheckedNodes();
      });
    } else
      this._initDefaultCheckedNodes();
  }
  filter(e) {
    const t = this.filterNodeMethod, s = this.lazy, o = /* @__PURE__ */ a(function(i) {
      const c = i.root ? i.root.childNodes : i.childNodes;
      if (c.forEach((d) => {
        d.visible = t.call(d, e, d.data, d), o(d);
      }), !i.visible && c.length) {
        let d = !0;
        d = !c.some((h) => h.visible), i.root ? i.root.visible = d === !1 : i.visible = d === !1;
      }
      e && i.visible && !i.isLeaf && (!s || i.loaded) && i.expand();
    }, "traverse");
    o(this);
  }
  setData(e) {
    e !== this.root.data ? (this.nodesMap = {}, this.root.setData(e), this._initDefaultCheckedNodes()) : this.root.updateChildren();
  }
  getNode(e) {
    if (e instanceof k)
      return e;
    const t = m(e) ? v(this.key, e) : e;
    return this.nodesMap[t] || null;
  }
  insertBefore(e, t) {
    const s = this.getNode(t);
    s.parent.insertBefore({ data: e }, s);
  }
  insertAfter(e, t) {
    const s = this.getNode(t);
    s.parent.insertAfter({ data: e }, s);
  }
  remove(e) {
    const t = this.getNode(e);
    t && t.parent && (t === this.currentNode && (this.currentNode = null), t.parent.removeChild(t));
  }
  append(e, t) {
    const s = E(t) ? this.root : this.getNode(t);
    s && s.insertChild({ data: e });
  }
  _initDefaultCheckedNodes() {
    const e = this.defaultCheckedKeys || [], t = this.nodesMap;
    e.forEach((s) => {
      const o = t[s];
      o && o.setChecked(!0, !this.checkStrictly);
    });
  }
  _initDefaultCheckedNode(e) {
    (this.defaultCheckedKeys || []).includes(e.key) && e.setChecked(!0, !this.checkStrictly);
  }
  setDefaultCheckedKey(e) {
    e !== this.defaultCheckedKeys && (this.defaultCheckedKeys = e, this._initDefaultCheckedNodes());
  }
  registerNode(e) {
    const t = this.key;
    !e || !e.data || (t ? e.key !== void 0 && (this.nodesMap[e.key] = e) : this.nodesMap[e.id] = e);
  }
  deregisterNode(e) {
    !this.key || !e || !e.data || (e.childNodes.forEach((s) => {
      this.deregisterNode(s);
    }), delete this.nodesMap[e.key]);
  }
  getCheckedNodes(e = !1, t = !1) {
    const s = [], o = /* @__PURE__ */ a(function(i) {
      (i.root ? i.root.childNodes : i.childNodes).forEach((d) => {
        (d.checked || t && d.indeterminate) && (!e || e && d.isLeaf) && s.push(d.data), o(d);
      });
    }, "traverse");
    return o(this), s;
  }
  getCheckedKeys(e = !1) {
    return this.getCheckedNodes(e).map((t) => (t || {})[this.key]);
  }
  getHalfCheckedNodes() {
    const e = [], t = /* @__PURE__ */ a(function(s) {
      (s.root ? s.root.childNodes : s.childNodes).forEach((i) => {
        i.indeterminate && e.push(i.data), t(i);
      });
    }, "traverse");
    return t(this), e;
  }
  getHalfCheckedKeys() {
    return this.getHalfCheckedNodes().map((e) => (e || {})[this.key]);
  }
  _getAllNodes() {
    const e = [], t = this.nodesMap;
    for (const s in t)
      C(t, s) && e.push(t[s]);
    return e;
  }
  updateChildren(e, t) {
    const s = this.nodesMap[e];
    if (!s)
      return;
    const o = s.childNodes;
    for (let i = o.length - 1; i >= 0; i--) {
      const c = o[i];
      this.remove(c.data);
    }
    for (let i = 0, c = t.length; i < c; i++) {
      const d = t[i];
      this.append(d, s.data);
    }
  }
  _setCheckedKeys(e, t = !1, s) {
    const o = this._getAllNodes().sort((h, n) => h.level - n.level), i = /* @__PURE__ */ Object.create(null), c = Object.keys(s);
    o.forEach((h) => h.setChecked(!1, !1));
    const d = /* @__PURE__ */ a((h) => {
      h.childNodes.forEach((n) => {
        var r;
        i[n.data[e]] = !0, (r = n.childNodes) != null && r.length && d(n);
      });
    }, "cacheCheckedChild");
    for (let h = 0, n = o.length; h < n; h++) {
      const r = o[h], u = r.data[e].toString();
      if (!c.includes(u)) {
        r.checked && !i[u] && r.setChecked(!1, !1);
        continue;
      }
      if (r.childNodes.length && d(r), r.isLeaf || this.checkStrictly) {
        r.setChecked(!0, !1);
        continue;
      }
      if (r.setChecked(!0, !0), t) {
        r.setChecked(!1, !1);
        const N = /* @__PURE__ */ a(function(g) {
          g.childNodes.forEach((l) => {
            l.isLeaf || l.setChecked(!1, !1), N(l);
          });
        }, "traverse");
        N(r);
      }
    }
  }
  setCheckedNodes(e, t = !1) {
    const s = this.key, o = {};
    e.forEach((i) => {
      o[(i || {})[s]] = !0;
    }), this._setCheckedKeys(s, t, o);
  }
  setCheckedKeys(e, t = !1) {
    this.defaultCheckedKeys = e;
    const s = this.key, o = {};
    e.forEach((i) => {
      o[i] = !0;
    }), this._setCheckedKeys(s, t, o);
  }
  setDefaultExpandedKeys(e) {
    e = e || [], this.defaultExpandedKeys = e, e.forEach((t) => {
      const s = this.getNode(t);
      s && s.expand(null, this.autoExpandParent);
    });
  }
  setChecked(e, t, s) {
    const o = this.getNode(e);
    o && o.setChecked(!!t, s);
  }
  getCurrentNode() {
    return this.currentNode;
  }
  setCurrentNode(e) {
    const t = this.currentNode;
    t && (t.isCurrent = !1), this.currentNode = e, this.currentNode.isCurrent = !0;
  }
  setUserCurrentNode(e, t = !0) {
    const s = e[this.key], o = this.nodesMap[s];
    this.setCurrentNode(o), t && this.currentNode.level > 1 && this.currentNode.parent.expand(null, !0);
  }
  setCurrentNodeKey(e, t = !0) {
    if (e == null) {
      this.currentNode && (this.currentNode.isCurrent = !1), this.currentNode = null;
      return;
    }
    const s = this.getNode(e);
    s && (this.setCurrentNode(s), t && this.currentNode.level > 1 && this.currentNode.parent.expand(null, !0));
  }
};
a(f, "TreeStore");
let y = f;
export {
  y as default
};
