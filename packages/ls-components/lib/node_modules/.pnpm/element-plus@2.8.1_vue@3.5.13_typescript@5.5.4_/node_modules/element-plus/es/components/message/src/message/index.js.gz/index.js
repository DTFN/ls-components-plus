var a = Object.defineProperty;
var t = (s, n) => a(s, "name", { value: n, configurable: !0 });
import { mutable as l } from "../../../../utils/typescript/index.js";
import { buildProps as r, definePropType as o } from "../../../../utils/vue/props/runtime/index.js";
import { iconPropType as u } from "../../../../utils/vue/icon/index.js";
import { isClient as p } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const i = ["success", "info", "warning", "error"], e = l({
  customClass: "",
  center: !1,
  dangerouslyUseHTMLString: !1,
  duration: 3e3,
  icon: void 0,
  id: "",
  message: "",
  onClose: void 0,
  showClose: !1,
  type: "info",
  plain: !1,
  offset: 16,
  zIndex: 0,
  grouping: !1,
  repeatNum: 1,
  appendTo: p ? document.body : void 0
}), c = r({
  customClass: {
    type: String,
    default: e.customClass
  },
  center: {
    type: Boolean,
    default: e.center
  },
  dangerouslyUseHTMLString: {
    type: Boolean,
    default: e.dangerouslyUseHTMLString
  },
  duration: {
    type: Number,
    default: e.duration
  },
  icon: {
    type: u,
    default: e.icon
  },
  id: {
    type: String,
    default: e.id
  },
  message: {
    type: o([
      String,
      Object,
      Function
    ]),
    default: e.message
  },
  onClose: {
    type: o(Function),
    default: e.onClose
  },
  showClose: {
    type: Boolean,
    default: e.showClose
  },
  type: {
    type: String,
    values: i,
    default: e.type
  },
  plain: {
    type: Boolean,
    default: e.plain
  },
  offset: {
    type: Number,
    default: e.offset
  },
  zIndex: {
    type: Number,
    default: e.zIndex
  },
  grouping: {
    type: Boolean,
    default: e.grouping
  },
  repeatNum: {
    type: Number,
    default: e.repeatNum
  }
}), C = {
  destroy: /* @__PURE__ */ t(() => !0, "destroy")
};
export {
  e as messageDefaults,
  C as messageEmits,
  c as messageProps,
  i as messageTypes
};
