var A = Object.defineProperty;
var r = (e, i) => A(e, "name", { value: i, configurable: !0 });
import { defineComponent as B, getCurrentInstance as z, inject as D, ref as S, computed as g, resolveComponent as m, openBlock as a, createBlock as H, normalizeClass as l, withCtx as k, createElementBlock as p, Fragment as q, renderList as R, createVNode as w, createTextVNode as X, toDisplayString as I, createCommentVNode as j } from "vue";
import { ElScrollbar as F } from "../../../scrollbar/index/index.js";
import { Loading as J } from "@element-plus/icons-vue";
import { ElIcon as K } from "../../../icon/index/index.js";
import O from "../node2/index.js";
import { CASCADER_PANEL_INJECTION_KEY as P } from "../types/index.js";
import W from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as Y } from "../../../../hooks/use-namespace/index/index.js";
import { useLocale as G } from "../../../../hooks/use-locale/index/index.js";
import { useId as Q } from "../../../../hooks/use-id/index/index.js";
const U = B({
  name: "ElCascaderMenu",
  components: {
    Loading: J,
    ElIcon: K,
    ElScrollbar: F,
    ElCascaderNode: O
  },
  props: {
    nodes: {
      type: Array,
      required: !0
    },
    index: {
      type: Number,
      required: !0
    }
  },
  setup(e) {
    const i = z(), h = Y("cascader-menu"), { t: y } = G(), E = Q();
    let t = null, n = null;
    const s = D(P), o = S(null), f = g(() => !e.nodes.length), c = g(() => !s.initialLoaded), d = g(() => `${E.value}-${e.index}`), _ = /* @__PURE__ */ r((u) => {
      t = u.target;
    }, "handleExpand"), b = /* @__PURE__ */ r((u) => {
      if (!(!s.isHoverMenu || !t || !o.value))
        if (t.contains(u.target)) {
          M();
          const C = i.vnode.el, { left: Z } = C.getBoundingClientRect(), { offsetWidth: L, offsetHeight: V } = C, N = u.clientX - Z, v = t.offsetTop, T = v + t.offsetHeight;
          o.value.innerHTML = `
          <path style="pointer-events: auto;" fill="transparent" d="M${N} ${v} L${L} 0 V${v} Z" />
          <path style="pointer-events: auto;" fill="transparent" d="M${N} ${T} L${L} ${V} V${T} Z" />
        `;
        } else n || (n = window.setTimeout($, s.config.hoverThreshold));
    }, "handleMouseMove"), M = /* @__PURE__ */ r(() => {
      n && (clearTimeout(n), n = null);
    }, "clearHoverTimer"), $ = /* @__PURE__ */ r(() => {
      o.value && (o.value.innerHTML = "", M());
    }, "clearHoverZone");
    return {
      ns: h,
      panel: s,
      hoverZone: o,
      isEmpty: f,
      isLoading: c,
      menuId: d,
      t: y,
      handleExpand: _,
      handleMouseMove: b,
      clearHoverZone: $
    };
  }
});
function x(e, i, h, y, E, t) {
  const n = m("el-cascader-node"), s = m("loading"), o = m("el-icon"), f = m("el-scrollbar");
  return a(), H(f, {
    key: e.menuId,
    tag: "ul",
    role: "menu",
    class: l(e.ns.b()),
    "wrap-class": e.ns.e("wrap"),
    "view-class": [e.ns.e("list"), e.ns.is("empty", e.isEmpty)],
    onMousemove: e.handleMouseMove,
    onMouseleave: e.clearHoverZone
  }, {
    default: k(() => {
      var c;
      return [
        (a(!0), p(q, null, R(e.nodes, (d) => (a(), H(n, {
          key: d.uid,
          node: d,
          "menu-id": e.menuId,
          onExpand: e.handleExpand
        }, null, 8, ["node", "menu-id", "onExpand"]))), 128)),
        e.isLoading ? (a(), p("div", {
          key: 0,
          class: l(e.ns.e("empty-text"))
        }, [
          w(o, {
            size: "14",
            class: l(e.ns.is("loading"))
          }, {
            default: k(() => [
              w(s)
            ]),
            _: 1
          }, 8, ["class"]),
          X(" " + I(e.t("el.cascader.loading")), 1)
        ], 2)) : e.isEmpty ? (a(), p("div", {
          key: 1,
          class: l(e.ns.e("empty-text"))
        }, I(e.t("el.cascader.noData")), 3)) : (c = e.panel) != null && c.isHoverMenu ? (a(), p("svg", {
          key: 2,
          ref: "hoverZone",
          class: l(e.ns.e("hover-zone"))
        }, null, 2)) : j("v-if", !0)
      ];
    }),
    _: 1
  }, 8, ["class", "wrap-class", "view-class", "onMousemove", "onMouseleave"]);
}
r(x, "_sfc_render");
var ue = /* @__PURE__ */ W(U, [["render", x], ["__file", "menu.vue"]]);
export {
  ue as default
};
