var l = Object.defineProperty;
var t = (e, a) => l(e, "name", { value: a, configurable: !0 });
import { placements as p } from "../../../../../../../../@sxzz_popperjs-es@2.11.7/node_modules/@sxzz/popperjs-es/dist/index/index.js";
import { buildProps as s, definePropType as o } from "../../../../utils/vue/props/runtime/index.js";
import { CommonProps as n } from "../../../cascader-panel/src/config/index.js";
import { useSizeProp as f } from "../../../../hooks/use-size/index/index.js";
import { useTooltipContentProps as i } from "../../../tooltip/src/content/index.js";
import { tagProps as r } from "../../../tag/src/tag/index.js";
import { useEmptyValuesProps as u } from "../../../../hooks/use-empty-values/index/index.js";
import { UPDATE_MODEL_EVENT as m, CHANGE_EVENT as d } from "../../../../constants/event/index.js";
import { isBoolean as c } from "../../../../utils/types/index.js";
const F = s({
  ...n,
  size: f,
  placeholder: String,
  disabled: Boolean,
  clearable: Boolean,
  filterable: Boolean,
  filterMethod: {
    type: o(Function),
    default: /* @__PURE__ */ t((e, a) => e.text.includes(a), "default")
  },
  separator: {
    type: String,
    default: " / "
  },
  showAllLevels: {
    type: Boolean,
    default: !0
  },
  collapseTags: Boolean,
  maxCollapseTags: {
    type: Number,
    default: 1
  },
  collapseTagsTooltip: {
    type: Boolean,
    default: !1
  },
  debounce: {
    type: Number,
    default: 300
  },
  beforeFilter: {
    type: o(Function),
    default: /* @__PURE__ */ t(() => !0, "default")
  },
  placement: {
    type: o(String),
    values: p,
    default: "bottom-start"
  },
  fallbackPlacements: {
    type: o(Array),
    default: ["bottom-start", "bottom", "top-start", "top", "right", "left"]
  },
  popperClass: {
    type: String,
    default: ""
  },
  teleported: i.teleported,
  tagType: { ...r.type, default: "info" },
  tagEffect: { ...r.effect, default: "light" },
  validateEvent: {
    type: Boolean,
    default: !0
  },
  persistent: {
    type: Boolean,
    default: !0
  },
  ...u
}), N = {
  [m]: (e) => !0,
  [d]: (e) => !0,
  focus: /* @__PURE__ */ t((e) => e instanceof FocusEvent, "focus"),
  blur: /* @__PURE__ */ t((e) => e instanceof FocusEvent, "blur"),
  clear: /* @__PURE__ */ t(() => !0, "clear"),
  visibleChange: /* @__PURE__ */ t((e) => c(e), "visibleChange"),
  expandChange: /* @__PURE__ */ t((e) => !!e, "expandChange"),
  removeTag: /* @__PURE__ */ t((e) => !!e, "removeTag")
};
export {
  N as cascaderEmits,
  F as cascaderProps
};
