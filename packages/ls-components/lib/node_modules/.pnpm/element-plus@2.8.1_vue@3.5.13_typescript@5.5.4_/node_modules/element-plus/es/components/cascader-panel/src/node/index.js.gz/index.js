var b = Object.defineProperty;
var u = (c, t) => b(c, "name", { value: t, configurable: !0 });
import { isFunction as f } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isEmpty as k, isUndefined as y } from "../../../../utils/types/index.js";
import { capitalize as m } from "../../../../utils/strings/index.js";
let C = 0;
const v = /* @__PURE__ */ u((c) => {
  const t = [c];
  let { parent: e } = c;
  for (; e; )
    t.unshift(e), e = e.parent;
  return t;
}, "calculatePathNodes"), n = class n {
  constructor(t, e, s, i = !1) {
    this.data = t, this.config = e, this.parent = s, this.root = i, this.uid = C++, this.checked = !1, this.indeterminate = !1, this.loading = !1;
    const { value: h, label: a, children: r } = e, d = t[r], o = v(this);
    this.level = i ? 0 : s ? s.level + 1 : 1, this.value = t[h], this.label = t[a], this.pathNodes = o, this.pathValues = o.map((l) => l.value), this.pathLabels = o.map((l) => l.label), this.childrenData = d, this.children = (d || []).map((l) => new n(l, e, this)), this.loaded = !e.lazy || this.isLeaf || !k(d);
  }
  get isDisabled() {
    const { data: t, parent: e, config: s } = this, { disabled: i, checkStrictly: h } = s;
    return (f(i) ? i(t, this) : !!t[i]) || !h && (e == null ? void 0 : e.isDisabled);
  }
  get isLeaf() {
    const { data: t, config: e, childrenData: s, loaded: i } = this, { lazy: h, leaf: a } = e, r = f(a) ? a(t, this) : t[a];
    return y(r) ? h && !i ? !1 : !(Array.isArray(s) && s.length) : !!r;
  }
  get valueByOption() {
    return this.config.emitPath ? this.pathValues : this.value;
  }
  appendChild(t) {
    const { childrenData: e, children: s } = this, i = new n(t, this.config, this);
    return Array.isArray(e) ? e.push(t) : this.childrenData = [t], s.push(i), i;
  }
  calcText(t, e) {
    const s = t ? this.pathLabels.join(e) : this.label;
    return this.text = s, s;
  }
  broadcast(t, ...e) {
    const s = `onParent${m(t)}`;
    this.children.forEach((i) => {
      i && (i.broadcast(t, ...e), i[s] && i[s](...e));
    });
  }
  emit(t, ...e) {
    const { parent: s } = this, i = `onChild${m(t)}`;
    s && (s[i] && s[i](...e), s.emit(t, ...e));
  }
  onParentCheck(t) {
    this.isDisabled || this.setCheckState(t);
  }
  onChildCheck() {
    const { children: t } = this, e = t.filter((i) => !i.isDisabled), s = e.length ? e.every((i) => i.checked) : !1;
    this.setCheckState(s);
  }
  setCheckState(t) {
    const e = this.children.length, s = this.children.reduce((i, h) => {
      const a = h.checked ? 1 : h.indeterminate ? 0.5 : 0;
      return i + a;
    }, 0);
    this.checked = this.loaded && this.children.filter((i) => !i.isDisabled).every((i) => i.loaded && i.checked) && t, this.indeterminate = this.loaded && s !== e && s > 0;
  }
  doCheck(t) {
    if (this.checked === t)
      return;
    const { checkStrictly: e, multiple: s } = this.config;
    e || !s ? this.checked = t : (this.broadcast("check", t), this.setCheckState(t), this.emit("check"));
  }
};
u(n, "Node");
let p = n;
export {
  p as default
};
