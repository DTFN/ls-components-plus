var W = Object.defineProperty;
var o = (a, t) => W(a, "name", { value: t, configurable: !0 });
import { getCurrentInstance as p, watch as h } from "vue";
import { parseWidth as C, parseMinWidth as A } from "../../util/index.js";
import { hasOwn as m } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
function d(a, t) {
  return a.reduce((r, c) => (r[c] = c, r), t);
}
o(d, "getAllAliases");
function M(a, t) {
  const r = p();
  return {
    registerComplexWatchers: /* @__PURE__ */ o(() => {
      const u = ["fixed"], i = {
        realWidth: "width",
        realMinWidth: "minWidth"
      }, f = d(u, i);
      Object.keys(f).forEach((l) => {
        const e = i[l];
        m(t, e) && h(() => t[e], (s) => {
          let n = s;
          e === "width" && l === "realWidth" && (n = C(s)), e === "minWidth" && l === "realMinWidth" && (n = A(s)), r.columnConfig.value[e] = n, r.columnConfig.value[l] = n;
          const g = e === "fixed";
          a.value.store.scheduleLayout(g);
        });
      });
    }, "registerComplexWatchers"),
    registerNormalWatchers: /* @__PURE__ */ o(() => {
      const u = [
        "label",
        "filters",
        "filterMultiple",
        "filteredValue",
        "sortable",
        "index",
        "formatter",
        "className",
        "labelClassName",
        "filterClassName",
        "showOverflowTooltip"
      ], i = {
        property: "prop",
        align: "realAlign",
        headerAlign: "realHeaderAlign"
      }, f = d(u, i);
      Object.keys(f).forEach((l) => {
        const e = i[l];
        m(t, e) && h(() => t[e], (s) => {
          r.columnConfig.value[l] = s;
        });
      });
    }, "registerNormalWatchers")
  };
}
o(M, "useWatcher");
export {
  M as default
};
