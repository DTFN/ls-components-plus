var ge = Object.defineProperty;
var a = (V, l) => ge(V, "name", { value: l, configurable: !0 });
import { defineComponent as ve, inject as ke, computed as f, ref as he, openBlock as Se, createElementBlock as Ce, normalizeClass as u, unref as t, createElementVNode as m, toDisplayString as T, createVNode as L, createCommentVNode as De } from "vue";
import C from "../../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { panelTimeRangeProps as _e } from "../../props/panel-time-range/index.js";
import { useTimePanel as we } from "../../composables/use-time-panel/index.js";
import { useOldValue as Te, buildAvailableTimeSlotGetter as Ve } from "../../composables/use-time-picker/index.js";
import q from "../basic-time-spinner/index.js";
import Re from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as xe } from "../../../../../hooks/use-locale/index/index.js";
import { useNamespace as F } from "../../../../../hooks/use-namespace/index/index.js";
import { EVENT_CODE as Ae } from "../../../../../constants/aria/index.js";
import { isArray as P } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import H from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/union/index.js";
const Me = /* @__PURE__ */ ve({
  __name: "panel-time-range",
  props: _e,
  emits: ["pick", "select-range", "set-picker-option"],
  setup(V, { emit: l }) {
    const p = V, k = /* @__PURE__ */ a((e, n) => {
      const o = [];
      for (let s = e; s <= n; s++)
        o.push(s);
      return o;
    }, "makeSelectRange"), { t: D, lang: S } = xe(), r = F("time"), J = F("picker"), Q = ke("EP_PICKER_BASE"), {
      arrowControl: _,
      disabledHours: y,
      disabledMinutes: K,
      disabledSeconds: N,
      defaultValue: R
    } = Q.props, W = f(() => [
      r.be("range-picker", "body"),
      r.be("panel", "content"),
      r.is("arrow", _),
      v.value ? "has-seconds" : ""
    ]), X = f(() => [
      r.be("range-picker", "body"),
      r.be("panel", "content"),
      r.is("arrow", _),
      v.value ? "has-seconds" : ""
    ]), b = f(() => p.parsedValue[0]), g = f(() => p.parsedValue[1]), Y = Te(p), Z = /* @__PURE__ */ a(() => {
      l("pick", Y.value, !1);
    }, "handleCancel"), v = f(() => p.format.includes("ss")), B = f(() => p.format.includes("A") ? "A" : p.format.includes("a") ? "a" : ""), ee = /* @__PURE__ */ a((e = !1) => {
      l("pick", [b.value, g.value], e);
    }, "handleConfirm"), ne = /* @__PURE__ */ a((e) => {
      I(e.millisecond(0), g.value);
    }, "handleMinChange"), te = /* @__PURE__ */ a((e) => {
      I(b.value, e.millisecond(0));
    }, "handleMaxChange"), oe = /* @__PURE__ */ a((e) => {
      const n = e.map((s) => C(s).locale(S.value)), o = j(n);
      return n[0].isSame(o[0]) && n[1].isSame(o[1]);
    }, "isValidValue"), I = /* @__PURE__ */ a((e, n) => {
      l("pick", [e, n], !0);
    }, "handleChange"), ae = f(() => b.value > g.value), w = he([0, 2]), se = /* @__PURE__ */ a((e, n) => {
      l("select-range", e, n, "min"), w.value = [e, n];
    }, "setMinSelectionRange"), $ = f(() => v.value ? 11 : 8), re = /* @__PURE__ */ a((e, n) => {
      l("select-range", e, n, "max");
      const o = t($);
      w.value = [e + o, n + o];
    }, "setMaxSelectionRange"), le = /* @__PURE__ */ a((e) => {
      const n = v.value ? [0, 3, 6, 11, 14, 17] : [0, 3, 8, 11], o = ["hours", "minutes"].concat(v.value ? ["seconds"] : []), c = (n.indexOf(w.value[0]) + e + n.length) % n.length, i = n.length / 2;
      c < i ? O.start_emitSelectRange(o[c]) : O.end_emitSelectRange(o[c - i]);
    }, "changeSelectionRange"), ce = /* @__PURE__ */ a((e) => {
      const n = e.code, { left: o, right: s, up: c, down: i } = Ae;
      if ([o, s].includes(n)) {
        le(n === o ? -1 : 1), e.preventDefault();
        return;
      }
      if ([c, i].includes(n)) {
        const d = n === c ? -1 : 1, h = w.value[0] < $.value ? "start" : "end";
        O[`${h}_scrollDown`](d), e.preventDefault();
        return;
      }
    }, "handleKeydown"), x = /* @__PURE__ */ a((e, n) => {
      const o = y ? y(e) : [], s = e === "start", i = (n || (s ? g.value : b.value)).hour(), d = s ? k(i + 1, 23) : k(0, i - 1);
      return H(o, d);
    }, "disabledHours_"), A = /* @__PURE__ */ a((e, n, o) => {
      const s = K ? K(e, n) : [], c = n === "start", i = o || (c ? g.value : b.value), d = i.hour();
      if (e !== d)
        return s;
      const h = i.minute(), E = c ? k(h + 1, 59) : k(0, h - 1);
      return H(s, E);
    }, "disabledMinutes_"), M = /* @__PURE__ */ a((e, n, o, s) => {
      const c = N ? N(e, n, o) : [], i = o === "start", d = s || (i ? g.value : b.value), h = d.hour(), E = d.minute();
      if (e !== h || n !== E)
        return c;
      const G = d.second(), be = i ? k(G + 1, 59) : k(0, G - 1);
      return H(c, be);
    }, "disabledSeconds_"), j = /* @__PURE__ */ a(([e, n]) => [
      U(e, "start", !0, n),
      U(n, "end", !1, e)
    ], "getRangeAvailableTime"), { getAvailableHours: ie, getAvailableMinutes: ue, getAvailableSeconds: pe } = Ve(x, A, M), {
      timePickerOptions: O,
      getAvailableTime: U,
      onSetOption: z
    } = we({
      getAvailableHours: ie,
      getAvailableMinutes: ue,
      getAvailableSeconds: pe
    }), de = /* @__PURE__ */ a((e) => e ? P(e) ? e.map((n) => C(n, p.format).locale(S.value)) : C(e, p.format).locale(S.value) : null, "parseUserInput"), me = /* @__PURE__ */ a((e) => e ? P(e) ? e.map((n) => n.format(p.format)) : e.format(p.format) : null, "formatToString"), fe = /* @__PURE__ */ a(() => {
      if (P(R))
        return R.map((n) => C(n).locale(S.value));
      const e = C(R).locale(S.value);
      return [e, e.add(60, "m")];
    }, "getDefaultValue");
    return l("set-picker-option", ["formatToString", me]), l("set-picker-option", ["parseUserInput", de]), l("set-picker-option", ["isValidValue", oe]), l("set-picker-option", ["handleKeydownInput", ce]), l("set-picker-option", ["getDefaultValue", fe]), l("set-picker-option", ["getRangeAvailableTime", j]), (e, n) => e.actualVisible ? (Se(), Ce("div", {
      key: 0,
      class: u([t(r).b("range-picker"), t(J).b("panel")])
    }, [
      m("div", {
        class: u(t(r).be("range-picker", "content"))
      }, [
        m("div", {
          class: u(t(r).be("range-picker", "cell"))
        }, [
          m("div", {
            class: u(t(r).be("range-picker", "header"))
          }, T(t(D)("el.datepicker.startTime")), 3),
          m("div", {
            class: u(t(W))
          }, [
            L(q, {
              ref: "minSpinner",
              role: "start",
              "show-seconds": t(v),
              "am-pm-mode": t(B),
              "arrow-control": t(_),
              "spinner-date": t(b),
              "disabled-hours": x,
              "disabled-minutes": A,
              "disabled-seconds": M,
              onChange: ne,
              onSetOption: t(z),
              onSelectRange: se
            }, null, 8, ["show-seconds", "am-pm-mode", "arrow-control", "spinner-date", "onSetOption"])
          ], 2)
        ], 2),
        m("div", {
          class: u(t(r).be("range-picker", "cell"))
        }, [
          m("div", {
            class: u(t(r).be("range-picker", "header"))
          }, T(t(D)("el.datepicker.endTime")), 3),
          m("div", {
            class: u(t(X))
          }, [
            L(q, {
              ref: "maxSpinner",
              role: "end",
              "show-seconds": t(v),
              "am-pm-mode": t(B),
              "arrow-control": t(_),
              "spinner-date": t(g),
              "disabled-hours": x,
              "disabled-minutes": A,
              "disabled-seconds": M,
              onChange: te,
              onSetOption: t(z),
              onSelectRange: re
            }, null, 8, ["show-seconds", "am-pm-mode", "arrow-control", "spinner-date", "onSetOption"])
          ], 2)
        ], 2)
      ], 2),
      m("div", {
        class: u(t(r).be("panel", "footer"))
      }, [
        m("button", {
          type: "button",
          class: u([t(r).be("panel", "btn"), "cancel"]),
          onClick: /* @__PURE__ */ a((o) => Z(), "onClick")
        }, T(t(D)("el.datepicker.cancel")), 11, ["onClick"]),
        m("button", {
          type: "button",
          class: u([t(r).be("panel", "btn"), "confirm"]),
          disabled: t(ae),
          onClick: /* @__PURE__ */ a((o) => ee(), "onClick")
        }, T(t(D)("el.datepicker.confirm")), 11, ["disabled", "onClick"])
      ], 2)
    ], 2)) : De("v-if", !0);
  }
});
var Ge = /* @__PURE__ */ Re(Me, [["__file", "panel-time-range.vue"]]);
export {
  Ge as default
};
