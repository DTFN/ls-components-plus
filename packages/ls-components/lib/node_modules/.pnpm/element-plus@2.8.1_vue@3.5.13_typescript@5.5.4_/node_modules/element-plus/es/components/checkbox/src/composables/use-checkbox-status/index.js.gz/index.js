var p = Object.defineProperty;
var n = (r, l) => p(r, "name", { value: l, configurable: !0 });
import { inject as x, ref as k, computed as u, toRaw as a } from "vue";
import { checkboxGroupContextKey as z } from "../../constants/index.js";
import { isPropAbsent as i, isBoolean as S } from "../../../../../utils/types/index.js";
import { isArray as C, isObject as j } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { useFormSize as s } from "../../../../form/src/hooks/use-form-common-props/index.js";
import w from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isEqual/index.js";
const V = /* @__PURE__ */ n((r, l, { model: c }) => {
  const o = x(z, void 0), v = k(!1), t = u(() => i(r.value) ? r.label : r.value), m = u(() => {
    const e = c.value;
    return S(e) ? e : C(e) ? j(t.value) ? e.map(a).some((h) => w(h, t.value)) : e.map(a).includes(t.value) : e != null ? e === r.trueValue || e === r.trueLabel : !!e;
  }), f = s(u(() => {
    var e;
    return (e = o == null ? void 0 : o.size) == null ? void 0 : e.value;
  }), {
    prop: !0
  }), d = s(u(() => {
    var e;
    return (e = o == null ? void 0 : o.size) == null ? void 0 : e.value;
  })), b = u(() => !!l.default || !i(t.value));
  return {
    checkboxButtonSize: f,
    isChecked: m,
    isFocused: v,
    checkboxSize: d,
    hasOwnLabel: b,
    actualValue: t
  };
}, "useCheckboxStatus");
export {
  V as useCheckboxStatus
};
