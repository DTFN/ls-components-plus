var b = Object.defineProperty;
var a = (u, e) => b(u, "name", { value: e, configurable: !0 });
import { computed as v } from "vue";
import { useLocale as m } from "../../../../../hooks/use-locale/index/index.js";
const L = /* @__PURE__ */ a(({
  unlinkPanels: u,
  leftDate: e,
  rightDate: r
}) => {
  const { t: l } = m(), o = /* @__PURE__ */ a(() => {
    e.value = e.value.subtract(1, "year"), u.value || (r.value = r.value.subtract(1, "year"));
  }, "leftPrevYear"), c = /* @__PURE__ */ a(() => {
    u.value || (e.value = e.value.add(1, "year")), r.value = r.value.add(1, "year");
  }, "rightNextYear"), y = /* @__PURE__ */ a(() => {
    e.value = e.value.add(1, "year");
  }, "leftNextYear"), n = /* @__PURE__ */ a(() => {
    r.value = r.value.subtract(1, "year");
  }, "rightPrevYear"), s = v(() => `${e.value.year()} ${l("el.datepicker.year")}`), d = v(() => `${r.value.year()} ${l("el.datepicker.year")}`), p = v(() => e.value.year()), Y = v(() => r.value.year() === e.value.year() ? e.value.year() + 1 : r.value.year());
  return {
    leftPrevYear: o,
    rightNextYear: c,
    leftNextYear: y,
    rightPrevYear: n,
    leftLabel: s,
    rightLabel: d,
    leftYear: p,
    rightYear: Y
  };
}, "useMonthRangeHeader");
export {
  L as useMonthRangeHeader
};
