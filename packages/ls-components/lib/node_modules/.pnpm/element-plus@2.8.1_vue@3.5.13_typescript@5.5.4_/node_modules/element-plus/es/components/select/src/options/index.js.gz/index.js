var O = Object.defineProperty;
var E = (t, n) => O(t, "name", { value: n, configurable: !0 });
import { defineComponent as m, inject as y } from "vue";
import { isArray as r, isString as b, isFunction as g } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { selectKey as L } from "../token/index.js";
import V from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isEqual/index.js";
var F = m({
  name: "ElOptions",
  setup(t, { slots: n }) {
    const u = y(L);
    let a = [];
    return () => {
      var c, d;
      const e = (c = n.default) == null ? void 0 : c.call(n), i = [];
      function o(s) {
        r(s) && s.forEach((l) => {
          var f, p, h, v;
          const _ = (f = (l == null ? void 0 : l.type) || {}) == null ? void 0 : f.name;
          _ === "ElOptionGroup" ? o(!b(l.children) && !r(l.children) && g((p = l.children) == null ? void 0 : p.default) ? (h = l.children) == null ? void 0 : h.default() : l.children) : _ === "ElOption" ? i.push((v = l.props) == null ? void 0 : v.value) : r(l.children) && o(l.children);
        });
      }
      return E(o, "filterOptions"), e.length && o((d = e[0]) == null ? void 0 : d.children), V(i, a) || (a = i, u && (u.states.optionValues = i)), e;
    };
  }
});
export {
  F as default
};
