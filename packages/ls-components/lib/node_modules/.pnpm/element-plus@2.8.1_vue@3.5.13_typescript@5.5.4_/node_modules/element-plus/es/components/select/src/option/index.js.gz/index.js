var C = Object.defineProperty;
var l = (e, t) => C(e, "name", { value: t, configurable: !0 });
import { defineComponent as g, computed as B, unref as a, reactive as D, toRefs as y, getCurrentInstance as N, onBeforeUnmount as $, nextTick as w, withDirectives as E, openBlock as I, createElementBlock as M, normalizeClass as K, withModifiers as L, renderSlot as j, createElementVNode as q, toDisplayString as z, vShow as R } from "vue";
import { useOption as T } from "../useOption/index.js";
import U from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as V } from "../../../../hooks/use-namespace/index/index.js";
import { useId as _ } from "../../../../hooks/use-id/index/index.js";
const A = g({
  name: "ElOption",
  componentName: "ElOption",
  props: {
    value: {
      required: !0,
      type: [String, Number, Boolean, Object]
    },
    label: [String, Number],
    created: Boolean,
    disabled: Boolean
  },
  setup(e) {
    const t = V("select"), c = _(), d = B(() => [
      t.be("dropdown", "item"),
      t.is("disabled", a(i)),
      t.is("selected", a(u)),
      t.is("hovering", a(m))
    ]), n = D({
      index: -1,
      groupDisabled: !1,
      visible: !0,
      hover: !1
    }), {
      currentLabel: p,
      itemSelected: u,
      isDisabled: i,
      select: o,
      hoverItem: v,
      updateOption: b
    } = T(e, n), { visible: O, hover: m } = y(n), s = N().proxy;
    o.onOptionCreate(s), $(() => {
      const r = s.value, { selected: f } = o.states, S = (o.props.multiple ? f : [f]).some((k) => k.value === s.value);
      w(() => {
        o.states.cachedOptions.get(r) === s && !S && o.states.cachedOptions.delete(r);
      }), o.onOptionDestroy(r, s);
    });
    function h() {
      i.value || o.handleOptionSelect(s);
    }
    return l(h, "selectOptionClick"), {
      ns: t,
      id: c,
      containerKls: d,
      currentLabel: p,
      itemSelected: u,
      isDisabled: i,
      select: o,
      hoverItem: v,
      updateOption: b,
      visible: O,
      hover: m,
      selectOptionClick: h,
      states: n
    };
  }
});
function F(e, t, c, d, n, p) {
  return E((I(), M("li", {
    id: e.id,
    class: K(e.containerKls),
    role: "option",
    "aria-disabled": e.isDisabled || void 0,
    "aria-selected": e.itemSelected,
    onMouseenter: e.hoverItem,
    onClick: L(e.selectOptionClick, ["stop"])
  }, [
    j(e.$slots, "default", {}, () => [
      q("span", null, z(e.currentLabel), 1)
    ])
  ], 42, ["id", "aria-disabled", "aria-selected", "onMouseenter", "onClick"])), [
    [R, e.visible]
  ]);
}
l(F, "_sfc_render");
var Y = /* @__PURE__ */ U(A, [["render", F], ["__file", "option.vue"]]);
export {
  Y as default
};
