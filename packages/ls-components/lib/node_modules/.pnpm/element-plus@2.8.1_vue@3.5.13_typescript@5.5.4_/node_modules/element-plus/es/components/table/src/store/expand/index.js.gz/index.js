var x = Object.defineProperty;
var t = (s, d) => x(s, "name", { value: d, configurable: !0 });
import { getCurrentInstance as v, ref as f } from "vue";
import { getKeysMap as r, getRowIdentity as w, toggleRowStatus as R } from "../../util/index.js";
function h(s) {
  const d = v(), i = f(!1), n = f([]);
  return {
    updateExpandRows: /* @__PURE__ */ t(() => {
      const o = s.data.value || [], e = s.rowKey.value;
      if (i.value)
        n.value = o.slice();
      else if (e) {
        const a = r(n.value, e);
        n.value = o.reduce((l, u) => {
          const c = w(u, e);
          return a[c] && l.push(u), l;
        }, []);
      } else
        n.value = [];
    }, "updateExpandRows"),
    toggleRowExpansion: /* @__PURE__ */ t((o, e) => {
      R(n.value, o, e) && d.emit("expand-change", o, n.value.slice());
    }, "toggleRowExpansion"),
    setExpandRowKeys: /* @__PURE__ */ t((o) => {
      d.store.assertRowKey();
      const e = s.data.value || [], a = s.rowKey.value, l = r(e, a);
      n.value = o.reduce((u, c) => {
        const p = l[c];
        return p && u.push(p.row), u;
      }, []);
    }, "setExpandRowKeys"),
    isRowExpanded: /* @__PURE__ */ t((o) => {
      const e = s.rowKey.value;
      return e ? !!r(n.value, e)[w(o, e)] : n.value.includes(o);
    }, "isRowExpanded"),
    states: {
      expandRows: n,
      defaultExpandAll: i
    }
  };
}
t(h, "useExpand");
export {
  h as default
};
