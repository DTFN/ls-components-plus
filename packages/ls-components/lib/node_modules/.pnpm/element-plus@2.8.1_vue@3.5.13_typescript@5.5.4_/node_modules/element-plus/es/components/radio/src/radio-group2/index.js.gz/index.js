var I = Object.defineProperty;
var l = (i, a) => I(i, "name", { value: a, configurable: !0 });
import { defineComponent as s, ref as _, onMounted as g, computed as E, provide as y, reactive as h, toRefs as G, watch as k, openBlock as R, createElementBlock as x, unref as r, normalizeClass as L, renderSlot as A, nextTick as B } from "vue";
import { radioGroupProps as C, radioGroupEmits as F } from "../radio-group/index.js";
import { radioGroupKey as T } from "../constants/index.js";
import D from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as M } from "../../../../hooks/use-namespace/index/index.js";
import { useId as N } from "../../../../hooks/use-id/index/index.js";
import { useFormItem as P, useFormItemInputId as S } from "../../../form/src/hooks/use-form-item/index.js";
import { UPDATE_MODEL_EVENT as V } from "../../../../constants/event/index.js";
import { debugWarn as q } from "../../../../utils/error/index.js";
const w = s({
  name: "ElRadioGroup"
}), z = /* @__PURE__ */ s({
  ...w,
  props: C,
  emits: F,
  setup(i, { emit: a }) {
    const e = i, p = M("radio"), u = N(), n = _(), { formItem: t } = P(), { inputId: c, isLabeledByFormItem: m } = S(e, {
      formItemContext: t
    }), f = /* @__PURE__ */ l((o) => {
      a(V, o), B(() => a("change", o));
    }, "changeEvent");
    g(() => {
      const o = n.value.querySelectorAll("[type=radio]"), d = o[0];
      !Array.from(o).some((v) => v.checked) && d && (d.tabIndex = 0);
    });
    const b = E(() => e.name || u.value);
    return y(T, h({
      ...G(e),
      changeEvent: f,
      name: b
    })), k(() => e.modelValue, () => {
      e.validateEvent && (t == null || t.validate("change").catch((o) => q(o)));
    }), (o, d) => (R(), x("div", {
      id: r(c),
      ref_key: "radioGroupRef",
      ref: n,
      class: L(r(p).b("group")),
      role: "radiogroup",
      "aria-label": r(m) ? void 0 : o.ariaLabel || "radio-group",
      "aria-labelledby": r(m) ? r(t).labelId : void 0
    }, [
      A(o.$slots, "default")
    ], 10, ["id", "aria-label", "aria-labelledby"]));
  }
});
var Y = /* @__PURE__ */ D(z, [["__file", "radio-group.vue"]]);
export {
  Y as default
};
