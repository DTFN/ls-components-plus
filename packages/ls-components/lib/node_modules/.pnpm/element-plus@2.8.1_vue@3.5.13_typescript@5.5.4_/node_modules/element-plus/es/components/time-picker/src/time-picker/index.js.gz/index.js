var d = Object.defineProperty;
var a = (l, t) => d(l, "name", { value: t, configurable: !0 });
import { defineComponent as s, ref as f, provide as v, createVNode as n, mergeProps as c } from "vue";
import P from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import T from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/plugin/customParseFormat/index.js";
import { DEFAULT_FORMATS_TIME as _ } from "../constants/index.js";
import h from "../common/picker/index.js";
import k from "../time-picker-com/panel-time-pick/index.js";
import g from "../time-picker-com/panel-time-range/index.js";
import { timePickerDefaultProps as O } from "../common/props/index.js";
P.extend(T);
var A = s({
  name: "ElTimePicker",
  install: null,
  props: {
    ...O,
    isRange: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["update:modelValue"],
  setup(l, t) {
    const r = f(), [m, i] = l.isRange ? ["timerange", g] : ["time", k], u = /* @__PURE__ */ a((e) => t.emit("update:modelValue", e), "modelUpdater");
    return v("ElPopperOptions", l.popperOptions), t.expose({
      focus: /* @__PURE__ */ a((e) => {
        var o;
        (o = r.value) == null || o.handleFocusInput(e);
      }, "focus"),
      blur: /* @__PURE__ */ a((e) => {
        var o;
        (o = r.value) == null || o.handleBlurInput(e);
      }, "blur"),
      handleOpen: /* @__PURE__ */ a(() => {
        var e;
        (e = r.value) == null || e.handleOpen();
      }, "handleOpen"),
      handleClose: /* @__PURE__ */ a(() => {
        var e;
        (e = r.value) == null || e.handleClose();
      }, "handleClose")
    }), () => {
      var e;
      const o = (e = l.format) != null ? e : _;
      return n(h, c(l, {
        ref: r,
        type: m,
        format: o,
        "onUpdate:modelValue": u
      }), {
        default: /* @__PURE__ */ a((p) => n(i, p, null), "default")
      });
    };
  }
});
export {
  A as default
};
