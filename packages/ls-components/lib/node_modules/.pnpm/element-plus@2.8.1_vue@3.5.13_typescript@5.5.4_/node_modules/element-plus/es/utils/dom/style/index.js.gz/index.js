var u = Object.defineProperty;
var s = (t, r) => u(t, "name", { value: r, configurable: !0 });
import { isNumber as c, isStringNumber as m } from "../../types/index.js";
import { debugWarn as f } from "../../error/index.js";
import { isString as d, camelize as l } from "../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isClient as p } from "../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const y = "utils/dom/style", a = /* @__PURE__ */ s((t = "") => t.split(" ").filter((r) => !!r.trim()), "classNameToArray"), w = /* @__PURE__ */ s((t, r) => {
  if (!t || !r)
    return !1;
  if (r.includes(" "))
    throw new Error("className should not contain space.");
  return t.classList.contains(r);
}, "hasClass"), L = /* @__PURE__ */ s((t, r) => {
  !t || !r.trim() || t.classList.add(...a(r));
}, "addClass"), N = /* @__PURE__ */ s((t, r) => {
  !t || !r.trim() || t.classList.remove(...a(r));
}, "removeClass"), x = /* @__PURE__ */ s((t, r) => {
  var o;
  if (!p || !t || !r)
    return "";
  let i = l(r);
  i === "float" && (i = "cssFloat");
  try {
    const n = t.style[i];
    if (n)
      return n;
    const e = (o = document.defaultView) == null ? void 0 : o.getComputedStyle(t, "");
    return e ? e[i] : "";
  } catch {
    return t.style[i];
  }
}, "getStyle");
function E(t, r = "px") {
  if (!t)
    return "";
  if (c(t) || m(t))
    return `${t}${r}`;
  if (d(t))
    return t;
  f(y, "binding value must be a string or number");
}
s(E, "addUnit");
export {
  L as addClass,
  E as addUnit,
  a as classNameToArray,
  x as getStyle,
  w as hasClass,
  N as removeClass
};
