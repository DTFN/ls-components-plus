var U = Object.defineProperty;
var a = (i, u) => U(i, "name", { value: u, configurable: !0 });
import { defineComponent as I, inject as V, ref as W, provide as F, onMounted as Y, watch as c, unref as e, onBeforeUnmount as Z, openBlock as z, createElementBlock as G, mergeProps as H, createVNode as Q, withCtx as X, renderSlot as ee } from "vue";
import { NOOP as _ } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { POPPER_CONTENT_INJECTION_KEY as oe } from "../constants/index.js";
import { popperContentProps as te, popperContentEmits as re } from "../content/index.js";
import ne from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { usePopperContentFocusTrap as se } from "../composables/use-focus-trap/index.js";
import { usePopperContent as ae } from "../composables/use-content/index.js";
import { usePopperContentDOM as pe } from "../composables/use-content-dom/index.js";
import { formItemContextKey as A } from "../../../form/src/constants/index.js";
import { isElement as b } from "../../../../utils/types/index.js";
import ie from "../../../focus-trap/src/focus-trap/index.js";
import ue from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
const le = I({
  name: "ElPopperContent"
}), fe = /* @__PURE__ */ I({
  ...le,
  props: te,
  emits: re,
  setup(i, { expose: u, emit: T }) {
    const o = i, {
      focusStartRef: g,
      trapped: l,
      onFocusAfterReleased: O,
      onFocusAfterTrapped: M,
      onFocusInTrap: N,
      onFocusoutPrevented: h,
      onReleaseRequested: S
    } = se(o, T), { attributes: w, arrowRef: y, contentRef: s, styles: x, instanceRef: q, role: m, update: B } = ae(o), {
      ariaModal: $,
      arrowStyle: k,
      contentAttrs: K,
      contentClass: j,
      contentStyle: d,
      updateZIndex: D
    } = pe(o, {
      styles: x,
      attributes: w,
      role: m
    }), v = V(A, void 0), J = W();
    F(oe, {
      arrowStyle: k,
      arrowRef: y,
      arrowOffset: J
    }), v && F(A, {
      ...v,
      addInputId: _,
      removeInputId: _
    });
    let r;
    const R = /* @__PURE__ */ a((n = !0) => {
      B(), n && D();
    }, "updatePopper"), L = /* @__PURE__ */ a(() => {
      R(!1), o.visible && o.focusOnShow ? l.value = !0 : o.visible === !1 && (l.value = !1);
    }, "togglePopperAlive");
    return Y(() => {
      c(() => o.triggerTargetEl, (n, P) => {
        r == null || r(), r = void 0;
        const t = e(n || s.value), f = e(P || s.value);
        b(t) && (r = c([m, () => o.ariaLabel, $, () => o.id], (p) => {
          ["role", "aria-label", "aria-modal", "id"].forEach((C, E) => {
            ue(p[E]) ? t.removeAttribute(C) : t.setAttribute(C, p[E]);
          });
        }, { immediate: !0 })), f !== t && b(f) && ["role", "aria-label", "aria-modal", "id"].forEach((p) => {
          f.removeAttribute(p);
        });
      }, { immediate: !0 }), c(() => o.visible, L, { immediate: !0 });
    }), Z(() => {
      r == null || r(), r = void 0;
    }), u({
      popperContentRef: s,
      popperInstanceRef: q,
      updatePopper: R,
      contentStyle: d
    }), (n, P) => (z(), G("div", H({
      ref_key: "contentRef",
      ref: s
    }, e(K), {
      style: e(d),
      class: e(j),
      tabindex: "-1",
      onMouseenter: /* @__PURE__ */ a((t) => n.$emit("mouseenter", t), "onMouseenter"),
      onMouseleave: /* @__PURE__ */ a((t) => n.$emit("mouseleave", t), "onMouseleave")
    }), [
      Q(e(ie), {
        trapped: e(l),
        "trap-on-focus-in": !0,
        "focus-trap-el": e(s),
        "focus-start-el": e(g),
        onFocusAfterTrapped: e(M),
        onFocusAfterReleased: e(O),
        onFocusin: e(N),
        onFocusoutPrevented: e(h),
        onReleaseRequested: e(S)
      }, {
        default: X(() => [
          ee(n.$slots, "default")
        ]),
        _: 3
      }, 8, ["trapped", "focus-trap-el", "focus-start-el", "onFocusAfterTrapped", "onFocusAfterReleased", "onFocusin", "onFocusoutPrevented", "onReleaseRequested"])
    ], 16, ["onMouseenter", "onMouseleave"]));
  }
});
var Te = /* @__PURE__ */ ne(fe, [["__file", "content.vue"]]);
export {
  Te as default
};
