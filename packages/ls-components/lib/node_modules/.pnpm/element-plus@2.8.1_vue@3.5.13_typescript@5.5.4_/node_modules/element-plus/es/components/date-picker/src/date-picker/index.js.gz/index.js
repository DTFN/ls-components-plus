var s = Object.defineProperty;
var a = (r, p) => s(r, "name", { value: p, configurable: !0 });
import { defineComponent as P, provide as i, reactive as x, toRef as O, ref as _, createVNode as d, mergeProps as y } from "vue";
import o from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import E from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/plugin/customParseFormat/index.js";
import k from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/plugin/advancedFormat/index.js";
import h from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/plugin/localeData/index.js";
import C from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/plugin/weekOfYear/index.js";
import T from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/plugin/weekYear/index.js";
import A from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/plugin/dayOfYear/index.js";
import D from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/plugin/isSameOrAfter/index.js";
import F from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/plugin/isSameOrBefore/index.js";
import { ROOT_PICKER_INJECTION_KEY as R } from "../constants/index.js";
import { datePickerProps as N } from "../props/date-picker/index.js";
import { getPanel as V } from "../panel-utils/index.js";
import { useNamespace as g } from "../../../../hooks/use-namespace/index/index.js";
import { DEFAULT_FORMATS_DATEPICKER as I, DEFAULT_FORMATS_DATE as S } from "../../../time-picker/src/constants/index.js";
import U from "../../../time-picker/src/common/picker/index.js";
o.extend(h);
o.extend(k);
o.extend(E);
o.extend(C);
o.extend(T);
o.extend(A);
o.extend(D);
o.extend(F);
var ee = P({
  name: "ElDatePicker",
  install: null,
  props: N,
  emits: ["update:modelValue"],
  setup(r, {
    expose: p,
    emit: f,
    slots: t
  }) {
    const l = g("picker-panel");
    i("ElPopperOptions", x(O(r, "popperOptions"))), i(R, {
      slots: t,
      pickerNs: l
    });
    const m = _();
    p({
      focus: /* @__PURE__ */ a((e = !0) => {
        var n;
        (n = m.value) == null || n.focus(e);
      }, "focus"),
      handleOpen: /* @__PURE__ */ a(() => {
        var e;
        (e = m.value) == null || e.handleOpen();
      }, "handleOpen"),
      handleClose: /* @__PURE__ */ a(() => {
        var e;
        (e = m.value) == null || e.handleClose();
      }, "handleClose")
    });
    const u = /* @__PURE__ */ a((e) => {
      f("update:modelValue", e);
    }, "onModelValueUpdated");
    return () => {
      var e;
      const n = (e = r.format) != null ? e : I[r.type] || S, c = V(r.type);
      return d(U, y(r, {
        format: n,
        type: r.type,
        ref: m,
        "onUpdate:modelValue": u
      }), {
        default: /* @__PURE__ */ a((v) => d(c, v, {
          "prev-month": t["prev-month"],
          "next-month": t["next-month"],
          "prev-year": t["prev-year"],
          "next-year": t["next-year"]
        }), "default"),
        "range-separator": t["range-separator"]
      });
    };
  }
});
export {
  ee as default
};
