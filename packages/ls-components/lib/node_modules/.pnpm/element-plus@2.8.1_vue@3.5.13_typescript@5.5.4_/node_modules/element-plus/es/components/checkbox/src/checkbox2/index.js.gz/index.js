var z = Object.defineProperty;
var o = (m, i) => z(m, "name", { value: i, configurable: !0 });
import { defineComponent as $, useSlots as I, computed as C, openBlock as u, createBlock as K, resolveDynamicComponent as M, unref as a, normalizeClass as t, withCtx as R, createElementVNode as V, withDirectives as g, createElementBlock as c, isRef as y, withModifiers as B, vModelCheckbox as F, renderSlot as O, Fragment as P, createTextVNode as T, toDisplayString as j, createCommentVNode as L } from "vue";
import { checkboxProps as q, checkboxEmits as A } from "../checkbox/index.js";
import G from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useCheckbox as H } from "../composables/use-checkbox/index.js";
import { useNamespace as J } from "../../../../hooks/use-namespace/index/index.js";
const Q = $({
  name: "ElCheckbox"
}), W = /* @__PURE__ */ $({
  ...Q,
  props: q,
  emits: A,
  setup(m) {
    const i = m, w = I(), {
      inputId: b,
      isLabeledByFormItem: D,
      isChecked: p,
      isDisabled: d,
      isFocused: r,
      checkboxSize: E,
      hasOwnLabel: v,
      model: s,
      actualValue: N,
      handleChange: f,
      onClickRoot: S
    } = H(i, w), l = J("checkbox"), U = C(() => [
      l.b(),
      l.m(E.value),
      l.is("disabled", d.value),
      l.is("bordered", i.border),
      l.is("checked", p.value)
    ]), x = C(() => [
      l.e("input"),
      l.is("disabled", d.value),
      l.is("checked", p.value),
      l.is("indeterminate", i.indeterminate),
      l.is("focus", r.value)
    ]);
    return (e, X) => (u(), K(M(!a(v) && a(D) ? "span" : "label"), {
      class: t(a(U)),
      "aria-controls": e.indeterminate ? e.ariaControls : null,
      onClick: a(S)
    }, {
      default: R(() => {
        var k, h;
        return [
          V("span", {
            class: t(a(x))
          }, [
            e.trueValue || e.falseValue || e.trueLabel || e.falseLabel ? g((u(), c("input", {
              key: 0,
              id: a(b),
              "onUpdate:modelValue": /* @__PURE__ */ o((n) => y(s) ? s.value = n : null, "onUpdate:modelValue"),
              class: t(a(l).e("original")),
              type: "checkbox",
              indeterminate: e.indeterminate,
              name: e.name,
              tabindex: e.tabindex,
              disabled: a(d),
              "true-value": (k = e.trueValue) != null ? k : e.trueLabel,
              "false-value": (h = e.falseValue) != null ? h : e.falseLabel,
              onChange: a(f),
              onFocus: /* @__PURE__ */ o((n) => r.value = !0, "onFocus"),
              onBlur: /* @__PURE__ */ o((n) => r.value = !1, "onBlur"),
              onClick: B(() => {
              }, ["stop"])
            }, null, 42, ["id", "onUpdate:modelValue", "indeterminate", "name", "tabindex", "disabled", "true-value", "false-value", "onChange", "onFocus", "onBlur", "onClick"])), [
              [F, a(s)]
            ]) : g((u(), c("input", {
              key: 1,
              id: a(b),
              "onUpdate:modelValue": /* @__PURE__ */ o((n) => y(s) ? s.value = n : null, "onUpdate:modelValue"),
              class: t(a(l).e("original")),
              type: "checkbox",
              indeterminate: e.indeterminate,
              disabled: a(d),
              value: a(N),
              name: e.name,
              tabindex: e.tabindex,
              onChange: a(f),
              onFocus: /* @__PURE__ */ o((n) => r.value = !0, "onFocus"),
              onBlur: /* @__PURE__ */ o((n) => r.value = !1, "onBlur"),
              onClick: B(() => {
              }, ["stop"])
            }, null, 42, ["id", "onUpdate:modelValue", "indeterminate", "disabled", "value", "name", "tabindex", "onChange", "onFocus", "onBlur", "onClick"])), [
              [F, a(s)]
            ]),
            V("span", {
              class: t(a(l).e("inner"))
            }, null, 2)
          ], 2),
          a(v) ? (u(), c("span", {
            key: 0,
            class: t(a(l).e("label"))
          }, [
            O(e.$slots, "default"),
            e.$slots.default ? L("v-if", !0) : (u(), c(P, { key: 0 }, [
              T(j(e.label), 1)
            ], 64))
          ], 2)) : L("v-if", !0)
        ];
      }),
      _: 3
    }, 8, ["class", "aria-controls", "onClick"]));
  }
});
var ne = /* @__PURE__ */ G(W, [["__file", "checkbox.vue"]]);
export {
  ne as default
};
