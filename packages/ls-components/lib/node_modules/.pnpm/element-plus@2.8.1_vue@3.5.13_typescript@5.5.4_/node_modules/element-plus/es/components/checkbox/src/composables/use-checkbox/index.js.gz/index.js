var L = Object.defineProperty;
var o = (e, l) => L(e, "name", { value: l, configurable: !0 });
import { computed as m } from "vue";
import { useCheckboxDisabled as g } from "../use-checkbox-disabled/index.js";
import { useCheckboxEvent as F } from "../use-checkbox-event/index.js";
import { useCheckboxModel as V } from "../use-checkbox-model/index.js";
import { useCheckboxStatus as D } from "../use-checkbox-status/index.js";
import { useFormItem as U, useFormItemInputId as y } from "../../../../form/src/hooks/use-form-item/index.js";
import { isArray as z } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { useDeprecated as r } from "../../../../../hooks/use-deprecated/index/index.js";
import { isPropAbsent as A } from "../../../../../utils/types/index.js";
const q = /* @__PURE__ */ o((e, l) => {
  const { formItem: d } = U(), { model: t, isGroup: u, isLimitExceeded: f } = V(e), {
    isFocused: v,
    isChecked: n,
    checkboxButtonSize: k,
    checkboxSize: x,
    hasOwnLabel: a,
    actualValue: c
  } = D(e, l, { model: t }), { isDisabled: s } = g({ model: t, isChecked: n }), { inputId: p, isLabeledByFormItem: i } = y(e, {
    formItemContext: d,
    disableIdGeneration: a,
    disableIdManagement: u
  }), { handleChange: I, onClickRoot: C } = F(e, {
    model: t,
    isLimitExceeded: f,
    hasOwnLabel: a,
    isDisabled: s,
    isLabeledByFormItem: i
  });
  return (/* @__PURE__ */ o(() => {
    function S() {
      var b, h;
      z(t.value) && !t.value.includes(c.value) ? t.value.push(c.value) : t.value = (h = (b = e.trueValue) != null ? b : e.trueLabel) != null ? h : !0;
    }
    o(S, "addToStore"), e.checked && S();
  }, "setStoreValue"))(), r({
    from: "label act as value",
    replacement: "value",
    version: "3.0.0",
    scope: "el-checkbox",
    ref: "https://element-plus.org/en-US/component/checkbox.html"
  }, m(() => u.value && A(e.value))), r({
    from: "true-label",
    replacement: "true-value",
    version: "3.0.0",
    scope: "el-checkbox",
    ref: "https://element-plus.org/en-US/component/checkbox.html"
  }, m(() => !!e.trueLabel)), r({
    from: "false-label",
    replacement: "false-value",
    version: "3.0.0",
    scope: "el-checkbox",
    ref: "https://element-plus.org/en-US/component/checkbox.html"
  }, m(() => !!e.falseLabel)), {
    inputId: p,
    isLabeledByFormItem: i,
    isChecked: n,
    isDisabled: s,
    isFocused: v,
    checkboxButtonSize: k,
    checkboxSize: x,
    hasOwnLabel: a,
    model: t,
    actualValue: c,
    handleChange: I,
    onClickRoot: C
  };
}, "useCheckbox");
export {
  q as useCheckbox
};
