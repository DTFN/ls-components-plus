var A = Object.defineProperty;
var C = (e, s) => A(e, "name", { value: s, configurable: !0 });
import { defineComponent as E, getCurrentInstance as M, ref as N, computed as S, onBeforeMount as _, onMounted as F, onBeforeUnmount as W, Fragment as $, h as g } from "vue";
import { ElCheckbox as B } from "../../../../checkbox/index/index.js";
import { cellStarts as k } from "../../config/index.js";
import { mergeOptions as D, compose as H } from "../../util/index.js";
import K from "../watcher-helper/index.js";
import R from "../render-helper/index.js";
import U from "../defaults/index.js";
import { isUndefined as V } from "../../../../../utils/types/index.js";
import { isString as z } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
let G = 1;
var ae = E({
  name: "ElTableColumn",
  components: {
    ElCheckbox: B
  },
  props: U,
  setup(e, { slots: s }) {
    const r = M(), o = N({}), t = S(() => {
      let l = r.parent;
      for (; l && !l.tableId; )
        l = l.parent;
      return l;
    }), { registerNormalWatchers: p, registerComplexWatchers: a } = K(t, e), {
      columnId: n,
      isSubColumn: m,
      realHeaderAlign: b,
      columnOrTableParent: v,
      setColumnWidth: y,
      setColumnForcedProps: x,
      setColumnRenders: I,
      getPropsData: P,
      getColumnElIndex: w,
      realAlign: O,
      updateColumnOrder: h
    } = R(e, s, t), i = v.value;
    n.value = `${i.tableId || i.columnId}_column_${G++}`, _(() => {
      m.value = t.value !== i;
      const l = e.type || "default", u = e.sortable === "" ? !0 : e.sortable, f = V(e.showOverflowTooltip) ? i.props.showOverflowTooltip : e.showOverflowTooltip, d = {
        ...k[l],
        id: n.value,
        type: l,
        property: e.prop || e.property,
        align: O,
        headerAlign: b,
        showOverflowTooltip: f,
        filterable: e.filters || e.filterMethod,
        filteredValue: [],
        filterPlacement: "",
        filterClassName: "",
        isColumnGroup: !1,
        isSubColumn: !1,
        filterOpened: !1,
        sortable: u,
        index: e.index,
        rawColumnKey: r.vnode.key
      };
      let c = P([
        "columnKey",
        "label",
        "className",
        "labelClassName",
        "type",
        "renderHeader",
        "formatter",
        "fixed",
        "resizable"
      ], ["sortMethod", "sortBy", "sortOrders"], ["selectable", "reserveSelection"], [
        "filterMethod",
        "filters",
        "filterMultiple",
        "filterOpened",
        "filteredValue",
        "filterPlacement",
        "filterClassName"
      ]);
      c = D(d, c), c = H(I, y, x)(c), o.value = c, p(), a();
    }), F(() => {
      var l;
      const u = v.value, f = m.value ? u.vnode.el.children : (l = u.refs.hiddenColumns) == null ? void 0 : l.children, d = /* @__PURE__ */ C(() => w(f || [], r.vnode.el), "getColumnIndex");
      o.value.getColumnIndex = d, d() > -1 && t.value.store.commit("insertColumn", o.value, m.value ? u.columnConfig.value : null, h);
    }), W(() => {
      o.value.getColumnIndex() > -1 && t.value.store.commit("removeColumn", o.value, m.value ? i.columnConfig.value : null, h);
    }), r.columnId = n.value, r.columnConfig = o;
  },
  render() {
    var e, s, r;
    try {
      const o = (s = (e = this.$slots).default) == null ? void 0 : s.call(e, {
        row: {},
        column: {},
        $index: -1
      }), t = [];
      if (Array.isArray(o))
        for (const a of o)
          ((r = a.type) == null ? void 0 : r.name) === "ElTableColumn" || a.shapeFlag & 2 ? t.push(a) : a.type === $ && Array.isArray(a.children) && a.children.forEach((n) => {
            (n == null ? void 0 : n.patchFlag) !== 1024 && !z(n == null ? void 0 : n.children) && t.push(n);
          });
      return g("div", t);
    } catch {
      return g("div", []);
    }
  }
});
export {
  ae as default
};
