var E = Object.defineProperty;
var C = (o, r) => E(o, "name", { value: r, configurable: !0 });
import { defineComponent as g, getCurrentInstance as D, ref as A, computed as P, unref as $, inject as N, resolveComponent as m, openBlock as O, createBlock as L, withCtx as c, createVNode as w, mergeProps as M, renderSlot as R } from "vue";
import y from "../dropdown-item-impl/index.js";
import { useDropdown as B } from "../useDropdown/index.js";
import { ElCollectionItem as H, dropdownItemProps as T } from "../dropdown/index.js";
import { DROPDOWN_INJECTION_KEY as V } from "../tokens/index.js";
import j from "../../../../_virtual/plugin-vue_export-helper/index.js";
import x from "../../../roving-focus-group/src/roving-focus-item/index.js";
import { composeEventHandlers as s, whenMouse as I } from "../../../../utils/dom/event/index.js";
const F = g({
  name: "ElDropdownItem",
  components: {
    ElDropdownCollectionItem: H,
    ElRovingFocusItem: x,
    ElDropdownItemImpl: y
  },
  inheritAttrs: !1,
  props: T,
  emits: ["pointermove", "pointerleave", "click"],
  setup(o, { emit: r, attrs: u }) {
    const { elDropdown: t } = B(), p = D(), v = A(null), l = P(() => {
      var e, n;
      return (n = (e = $(v)) == null ? void 0 : e.textContent) != null ? n : "";
    }), { onItemEnter: d, onItemLeave: i } = N(V, void 0), a = s((e) => (r("pointermove", e), e.defaultPrevented), I((e) => {
      if (o.disabled) {
        i(e);
        return;
      }
      const n = e.currentTarget;
      n === document.activeElement || n.contains(document.activeElement) || (d(e), e.defaultPrevented || n == null || n.focus());
    })), h = s((e) => (r("pointerleave", e), e.defaultPrevented), I(i)), b = s((e) => {
      if (!o.disabled)
        return r("click", e), e.type !== "keydown" && e.defaultPrevented;
    }, (e) => {
      var n, f, _;
      if (o.disabled) {
        e.stopImmediatePropagation();
        return;
      }
      (n = t == null ? void 0 : t.hideOnClick) != null && n.value && ((f = t.handleClick) == null || f.call(t)), (_ = t.commandHandler) == null || _.call(t, o.command, p, e);
    }), k = P(() => ({ ...o, ...u }));
    return {
      handleClick: b,
      handlePointerMove: a,
      handlePointerLeave: h,
      textContent: l,
      propsAndAttrs: k
    };
  }
});
function J(o, r, u, t, p, v) {
  var l;
  const d = m("el-dropdown-item-impl"), i = m("el-roving-focus-item"), a = m("el-dropdown-collection-item");
  return O(), L(a, {
    disabled: o.disabled,
    "text-value": (l = o.textValue) != null ? l : o.textContent
  }, {
    default: c(() => [
      w(i, {
        focusable: !o.disabled
      }, {
        default: c(() => [
          w(d, M(o.propsAndAttrs, {
            onPointerleave: o.handlePointerLeave,
            onPointermove: o.handlePointerMove,
            onClickimpl: o.handleClick
          }), {
            default: c(() => [
              R(o.$slots, "default")
            ]),
            _: 3
          }, 16, ["onPointerleave", "onPointermove", "onClickimpl"])
        ]),
        _: 3
      }, 8, ["focusable"])
    ]),
    _: 3
  }, 8, ["disabled", "text-value"]);
}
C(J, "_sfc_render");
var X = /* @__PURE__ */ j(F, [["render", J], ["__file", "dropdown-item.vue"]]);
export {
  X as default
};
