var L = Object.defineProperty;
var f = (t, e) => L(t, "name", { value: e, configurable: !0 });
import { nextTick as E } from "vue";
import { isFunction as N } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { getOffsetTopDistance as w } from "../../../../utils/dom/position/index.js";
import { throwError as A } from "../../../../utils/error/index.js";
import { getScrollContainer as O } from "../../../../utils/dom/scroll/index.js";
import g from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/throttle/index.js";
const r = "ElInfiniteScroll", C = 50, D = 200, _ = 0, F = {
  delay: {
    type: Number,
    default: D
  },
  distance: {
    type: Number,
    default: _
  },
  disabled: {
    type: Boolean,
    default: !1
  },
  immediate: {
    type: Boolean,
    default: !0
  }
}, v = /* @__PURE__ */ f((t, e) => Object.entries(F).reduce((o, [n, c]) => {
  var u, i;
  const { type: d, default: s } = c, a = t.getAttribute(`infinite-scroll-${n}`);
  let l = (i = (u = e[a]) != null ? u : a) != null ? i : s;
  return l = l === "false" ? !1 : l, l = d(l), o[n] = Number.isNaN(l) ? s : l, o;
}, {}), "getScrollOptions"), h = /* @__PURE__ */ f((t) => {
  const { observer: e } = t[r];
  e && (e.disconnect(), delete t[r].observer);
}, "destroyObserver"), I = /* @__PURE__ */ f((t, e) => {
  const { container: o, containerEl: n, instance: c, observer: u, lastScrollTop: i } = t[r], { disabled: d, distance: s } = v(t, c), { clientHeight: a, scrollHeight: l, scrollTop: b } = n, T = b - i;
  if (t[r].lastScrollTop = b, u || d || T < 0)
    return;
  let m = !1;
  if (o === t)
    m = l - (a + b) <= s;
  else {
    const { clientTop: S, scrollHeight: y } = t, H = w(t, n);
    m = b + a >= H + S + y - s;
  }
  m && e.call(c);
}, "handleScroll");
function p(t, e) {
  const { containerEl: o, instance: n } = t[r], { disabled: c } = v(t, n);
  c || o.clientHeight === 0 || (o.scrollHeight <= o.clientHeight ? e.call(n) : h(t));
}
f(p, "checkFull");
const M = {
  async mounted(t, e) {
    const { instance: o, value: n } = e;
    N(n) || A(r, "'v-infinite-scroll' binding value must be a function"), await E();
    const { delay: c, immediate: u } = v(t, o), i = O(t, !0), d = i === window ? document.documentElement : i, s = g(I.bind(null, t, n), c);
    if (i) {
      if (t[r] = {
        instance: o,
        container: i,
        containerEl: d,
        delay: c,
        cb: n,
        onScroll: s,
        lastScrollTop: d.scrollTop
      }, u) {
        const a = new MutationObserver(g(p.bind(null, t, n), C));
        t[r].observer = a, a.observe(t, { childList: !0, subtree: !0 }), p(t, n);
      }
      i.addEventListener("scroll", s);
    }
  },
  unmounted(t) {
    if (!t[r])
      return;
    const { container: e, onScroll: o } = t[r];
    e == null || e.removeEventListener("scroll", o), h(t);
  },
  async updated(t) {
    if (!t[r])
      await E();
    else {
      const { containerEl: e, cb: o, observer: n } = t[r];
      e.clientHeight && n && p(t, o);
    }
  }
};
export {
  C as CHECK_INTERVAL,
  D as DEFAULT_DELAY,
  _ as DEFAULT_DISTANCE,
  r as SCOPE,
  M as default
};
