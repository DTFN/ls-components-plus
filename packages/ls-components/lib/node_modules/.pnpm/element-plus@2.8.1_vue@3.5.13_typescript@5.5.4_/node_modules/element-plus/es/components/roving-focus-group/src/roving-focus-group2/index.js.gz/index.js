var p = Object.defineProperty;
var r = (o, e) => p(o, "name", { value: e, configurable: !0 });
import { defineComponent as u, resolveComponent as n, openBlock as s, createBlock as i, withCtx as t, createVNode as _, normalizeProps as f, guardReactiveProps as m, renderSlot as a } from "vue";
import g from "../roving-focus-group-impl/index.js";
import { ElCollection as d } from "../roving-focus-group/index.js";
import v from "../../../../_virtual/plugin-vue_export-helper/index.js";
const $ = u({
  name: "ElRovingFocusGroup",
  components: {
    ElFocusGroupCollection: d,
    ElRovingFocusGroupImpl: g
  }
});
function C(o, e, E, F, G, R) {
  const l = n("el-roving-focus-group-impl"), c = n("el-focus-group-collection");
  return s(), i(c, null, {
    default: t(() => [
      _(l, f(m(o.$attrs)), {
        default: t(() => [
          a(o.$slots, "default")
        ]),
        _: 3
      }, 16)
    ]),
    _: 3
  });
}
r(C, "_sfc_render");
var w = /* @__PURE__ */ v($, [["render", C], ["__file", "roving-focus-group.vue"]]);
export {
  w as default
};
