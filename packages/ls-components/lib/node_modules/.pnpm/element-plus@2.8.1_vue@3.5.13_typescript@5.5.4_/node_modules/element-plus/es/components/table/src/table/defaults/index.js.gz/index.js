var n = Object.defineProperty;
var e = (t, o) => n(t, "name", { value: o, configurable: !0 });
import { useSizeProp as l } from "../../../../../hooks/use-size/index/index.js";
var i = {
  data: {
    type: Array,
    default: /* @__PURE__ */ e(() => [], "default")
  },
  size: l,
  width: [String, Number],
  height: [String, Number],
  maxHeight: [String, Number],
  fit: {
    type: Boolean,
    default: !0
  },
  stripe: Boolean,
  border: Boolean,
  rowKey: [String, Function],
  showHeader: {
    type: Boolean,
    default: !0
  },
  showSummary: Boolean,
  sumText: String,
  summaryMethod: Function,
  rowClassName: [String, Function],
  rowStyle: [Object, Function],
  cellClassName: [String, Function],
  cellStyle: [Object, Function],
  headerRowClassName: [String, Function],
  headerRowStyle: [Object, Function],
  headerCellClassName: [String, Function],
  headerCellStyle: [Object, Function],
  highlightCurrentRow: Boolean,
  currentRowKey: [String, Number],
  emptyText: String,
  expandRowKeys: Array,
  defaultExpandAll: Boolean,
  defaultSort: Object,
  tooltipEffect: String,
  tooltipOptions: Object,
  spanMethod: Function,
  selectOnIndeterminate: {
    type: Boolean,
    default: !0
  },
  indent: {
    type: Number,
    default: 16
  },
  treeProps: {
    type: Object,
    default: /* @__PURE__ */ e(() => ({
      hasChildren: "hasChildren",
      children: "children",
      checkStrictly: !1
    }), "default")
  },
  lazy: Boolean,
  load: Function,
  style: {
    type: Object,
    default: /* @__PURE__ */ e(() => ({}), "default")
  },
  className: {
    type: String,
    default: ""
  },
  tableLayout: {
    type: String,
    default: "fixed"
  },
  scrollbarAlwaysOn: Boolean,
  flexible: Boolean,
  showOverflowTooltip: [Boolean, Object]
};
export {
  i as default
};
