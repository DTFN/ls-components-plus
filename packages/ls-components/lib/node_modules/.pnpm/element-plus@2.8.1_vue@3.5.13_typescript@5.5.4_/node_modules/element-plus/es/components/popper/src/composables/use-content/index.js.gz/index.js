var M = Object.defineProperty;
var i = (n, o) => M(n, "name", { value: o, configurable: !0 });
import { inject as U, ref as d, computed as r, unref as t, watch as l, onMounted as C } from "vue";
import { POPPER_INJECTION_KEY as I } from "../../constants/index.js";
import { buildPopperOptions as L, unwrapMeasurableEl as T } from "../../utils/index.js";
import { usePopper as A } from "../../../../../hooks/use-popper/index/index.js";
import N from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isUndefined/index.js";
const h = 0, K = /* @__PURE__ */ i((n) => {
  const { popperInstanceRef: o, contentRef: a, triggerRef: m, role: R } = U(I, void 0), c = d(), v = d(), E = r(() => ({
    name: "eventListeners",
    enabled: !!n.visible
  })), w = r(() => {
    var e;
    const u = t(c), F = (e = t(v)) != null ? e : h;
    return {
      name: "arrow",
      enabled: !N(u),
      options: {
        element: u,
        padding: F
      }
    };
  }), b = r(() => ({
    onFirstUpdate: /* @__PURE__ */ i(() => {
      s();
    }, "onFirstUpdate"),
    ...L(n, [
      t(w),
      t(E)
    ])
  })), f = r(() => T(n.referenceEl) || t(m)), { attributes: O, state: P, styles: _, update: s, forceUpdate: g, instanceRef: p } = A(f, a, b);
  return l(p, (e) => o.value = e), C(() => {
    l(() => {
      var e;
      return (e = t(f)) == null ? void 0 : e.getBoundingClientRect();
    }, () => {
      s();
    });
  }), {
    attributes: O,
    arrowRef: c,
    contentRef: a,
    instanceRef: p,
    state: P,
    styles: _,
    role: R,
    forceUpdate: g,
    update: s
  };
}, "usePopperContent");
export {
  K as usePopperContent
};
