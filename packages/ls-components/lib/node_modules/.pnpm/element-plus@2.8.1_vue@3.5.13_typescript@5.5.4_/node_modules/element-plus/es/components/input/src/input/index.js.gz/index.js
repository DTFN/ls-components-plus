var a = Object.defineProperty;
var t = (e, r) => a(e, "name", { value: r, configurable: !0 });
import { isString as o } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { buildProps as p, definePropType as n } from "../../../../utils/vue/props/runtime/index.js";
import { useSizeProp as s } from "../../../../hooks/use-size/index/index.js";
import { iconPropType as i } from "../../../../utils/vue/icon/index.js";
import { mutable as u } from "../../../../utils/typescript/index.js";
import { useAriaProps as l } from "../../../../hooks/use-aria/index/index.js";
import { UPDATE_MODEL_EVENT as f } from "../../../../constants/event/index.js";
const E = p({
  id: {
    type: String,
    default: void 0
  },
  size: s,
  disabled: Boolean,
  modelValue: {
    type: n([
      String,
      Number,
      Object
    ]),
    default: ""
  },
  maxlength: {
    type: [String, Number]
  },
  minlength: {
    type: [String, Number]
  },
  type: {
    type: String,
    default: "text"
  },
  resize: {
    type: String,
    values: ["none", "both", "horizontal", "vertical"]
  },
  autosize: {
    type: n([Boolean, Object]),
    default: !1
  },
  autocomplete: {
    type: String,
    default: "off"
  },
  formatter: {
    type: Function
  },
  parser: {
    type: Function
  },
  placeholder: {
    type: String
  },
  form: {
    type: String
  },
  readonly: Boolean,
  clearable: Boolean,
  showPassword: Boolean,
  showWordLimit: Boolean,
  suffixIcon: {
    type: i
  },
  prefixIcon: {
    type: i
  },
  containerRole: {
    type: String,
    default: void 0
  },
  tabindex: {
    type: [String, Number],
    default: 0
  },
  validateEvent: {
    type: Boolean,
    default: !0
  },
  inputStyle: {
    type: n([Object, Array, String]),
    default: /* @__PURE__ */ t(() => u({}), "default")
  },
  autofocus: Boolean,
  rows: {
    type: Number,
    default: 2
  },
  ...l(["ariaLabel"])
}), h = {
  [f]: (e) => o(e),
  input: /* @__PURE__ */ t((e) => o(e), "input"),
  change: /* @__PURE__ */ t((e) => o(e), "change"),
  focus: /* @__PURE__ */ t((e) => e instanceof FocusEvent, "focus"),
  blur: /* @__PURE__ */ t((e) => e instanceof FocusEvent, "blur"),
  clear: /* @__PURE__ */ t(() => !0, "clear"),
  mouseleave: /* @__PURE__ */ t((e) => e instanceof MouseEvent, "mouseleave"),
  mouseenter: /* @__PURE__ */ t((e) => e instanceof MouseEvent, "mouseenter"),
  keydown: /* @__PURE__ */ t((e) => e instanceof Event, "keydown"),
  compositionstart: /* @__PURE__ */ t((e) => e instanceof CompositionEvent, "compositionstart"),
  compositionupdate: /* @__PURE__ */ t((e) => e instanceof CompositionEvent, "compositionupdate"),
  compositionend: /* @__PURE__ */ t((e) => e instanceof CompositionEvent, "compositionend")
};
export {
  h as inputEmits,
  E as inputProps
};
