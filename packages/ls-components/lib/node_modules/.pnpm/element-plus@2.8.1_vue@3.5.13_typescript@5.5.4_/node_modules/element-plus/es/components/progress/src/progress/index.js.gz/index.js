var a = Object.defineProperty;
var t = (e, o) => a(e, "name", { value: o, configurable: !0 });
import { buildProps as n, definePropType as r } from "../../../../utils/vue/props/runtime/index.js";
const d = n({
  type: {
    type: String,
    default: "line",
    values: ["line", "circle", "dashboard"]
  },
  percentage: {
    type: Number,
    default: 0,
    validator: /* @__PURE__ */ t((e) => e >= 0 && e <= 100, "validator")
  },
  status: {
    type: String,
    default: "",
    values: ["", "success", "exception", "warning"]
  },
  indeterminate: Boolean,
  duration: {
    type: Number,
    default: 3
  },
  strokeWidth: {
    type: Number,
    default: 6
  },
  strokeLinecap: {
    type: r(String),
    default: "round"
  },
  textInside: Boolean,
  width: {
    type: Number,
    default: 126
  },
  showText: {
    type: Boolean,
    default: !0
  },
  color: {
    type: r([
      String,
      Array,
      Function
    ]),
    default: ""
  },
  striped: Boolean,
  stripedFlow: Boolean,
  format: {
    type: r(Function),
    default: /* @__PURE__ */ t((e) => `${e}%`, "default")
  }
});
export {
  d as progressProps
};
