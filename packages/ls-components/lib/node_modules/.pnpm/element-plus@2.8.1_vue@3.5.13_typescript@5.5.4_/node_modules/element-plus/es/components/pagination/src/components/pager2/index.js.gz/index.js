var V = Object.defineProperty;
var o = (M, C) => V(M, "name", { value: C, configurable: !0 });
import { defineComponent as z, ref as d, computed as k, watchEffect as j, openBlock as u, createElementBlock as p, normalizeClass as b, unref as r, withKeys as G, createCommentVNode as N, createBlock as h, Fragment as J, renderList as Q, toDisplayString as A } from "vue";
import { DArrowLeft as T, MoreFilled as D, DArrowRight as U } from "@element-plus/icons-vue";
import { paginationPagerProps as W } from "../pager/index.js";
import X from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as H } from "../../../../../hooks/use-namespace/index/index.js";
import { useLocale as Y } from "../../../../../hooks/use-locale/index/index.js";
const Z = z({
  name: "ElPaginationPager"
}), _ = /* @__PURE__ */ z({
  ...Z,
  props: W,
  emits: ["change"],
  setup(M, { emit: C }) {
    const n = M, i = H("pager"), B = H("icon"), { t: v } = Y(), y = d(!1), w = d(!1), F = d(!1), q = d(!1), L = d(!1), $ = d(!1), I = k(() => {
      const e = n.pagerCount, t = (e - 1) / 2, a = Number(n.currentPage), l = Number(n.pageCount);
      let c = !1, f = !1;
      l > e && (a > e - t && (c = !0), a < l - t && (f = !0));
      const P = [];
      if (c && !f) {
        const s = l - (e - 2);
        for (let g = s; g < l; g++)
          P.push(g);
      } else if (!c && f)
        for (let s = 2; s < e; s++)
          P.push(s);
      else if (c && f) {
        const s = Math.floor(e / 2) - 1;
        for (let g = a - s; g <= a + s; g++)
          P.push(g);
      } else
        for (let s = 2; s < l; s++)
          P.push(s);
      return P;
    }), O = k(() => [
      "more",
      "btn-quickprev",
      B.b(),
      i.is("disabled", n.disabled)
    ]), R = k(() => [
      "more",
      "btn-quicknext",
      B.b(),
      i.is("disabled", n.disabled)
    ]), m = k(() => n.disabled ? -1 : 0);
    j(() => {
      const e = (n.pagerCount - 1) / 2;
      y.value = !1, w.value = !1, n.pageCount > n.pagerCount && (n.currentPage > n.pagerCount - e && (y.value = !0), n.currentPage < n.pageCount - e && (w.value = !0));
    });
    function x(e = !1) {
      n.disabled || (e ? F.value = !0 : q.value = !0);
    }
    o(x, "onMouseEnter");
    function E(e = !1) {
      e ? L.value = !0 : $.value = !0;
    }
    o(E, "onFocus");
    function S(e) {
      const t = e.target;
      if (t.tagName.toLowerCase() === "li" && Array.from(t.classList).includes("number")) {
        const a = Number(t.textContent);
        a !== n.currentPage && C("change", a);
      } else t.tagName.toLowerCase() === "li" && Array.from(t.classList).includes("more") && K(e);
    }
    o(S, "onEnter");
    function K(e) {
      const t = e.target;
      if (t.tagName.toLowerCase() === "ul" || n.disabled)
        return;
      let a = Number(t.textContent);
      const l = n.pageCount, c = n.currentPage, f = n.pagerCount - 2;
      t.className.includes("more") && (t.className.includes("quickprev") ? a = c - f : t.className.includes("quicknext") && (a = c + f)), Number.isNaN(+a) || (a < 1 && (a = 1), a > l && (a = l)), a !== c && C("change", a);
    }
    return o(K, "onPagerClick"), (e, t) => (u(), p("ul", {
      class: b(r(i).b()),
      onClick: K,
      onKeyup: G(S, ["enter"])
    }, [
      e.pageCount > 0 ? (u(), p("li", {
        key: 0,
        class: b([[
          r(i).is("active", e.currentPage === 1),
          r(i).is("disabled", e.disabled)
        ], "number"]),
        "aria-current": e.currentPage === 1,
        "aria-label": r(v)("el.pagination.currentPage", { pager: 1 }),
        tabindex: r(m)
      }, " 1 ", 10, ["aria-current", "aria-label", "tabindex"])) : N("v-if", !0),
      y.value ? (u(), p("li", {
        key: 1,
        class: b(r(O)),
        tabindex: r(m),
        "aria-label": r(v)("el.pagination.prevPages", { pager: e.pagerCount - 2 }),
        onMouseenter: /* @__PURE__ */ o((a) => x(!0), "onMouseenter"),
        onMouseleave: /* @__PURE__ */ o((a) => F.value = !1, "onMouseleave"),
        onFocus: /* @__PURE__ */ o((a) => E(!0), "onFocus"),
        onBlur: /* @__PURE__ */ o((a) => L.value = !1, "onBlur")
      }, [
        (F.value || L.value) && !e.disabled ? (u(), h(r(T), { key: 0 })) : (u(), h(r(D), { key: 1 }))
      ], 42, ["tabindex", "aria-label", "onMouseenter", "onMouseleave", "onFocus", "onBlur"])) : N("v-if", !0),
      (u(!0), p(J, null, Q(r(I), (a) => (u(), p("li", {
        key: a,
        class: b([[
          r(i).is("active", e.currentPage === a),
          r(i).is("disabled", e.disabled)
        ], "number"]),
        "aria-current": e.currentPage === a,
        "aria-label": r(v)("el.pagination.currentPage", { pager: a }),
        tabindex: r(m)
      }, A(a), 11, ["aria-current", "aria-label", "tabindex"]))), 128)),
      w.value ? (u(), p("li", {
        key: 2,
        class: b(r(R)),
        tabindex: r(m),
        "aria-label": r(v)("el.pagination.nextPages", { pager: e.pagerCount - 2 }),
        onMouseenter: /* @__PURE__ */ o((a) => x(), "onMouseenter"),
        onMouseleave: /* @__PURE__ */ o((a) => q.value = !1, "onMouseleave"),
        onFocus: /* @__PURE__ */ o((a) => E(), "onFocus"),
        onBlur: /* @__PURE__ */ o((a) => $.value = !1, "onBlur")
      }, [
        (q.value || $.value) && !e.disabled ? (u(), h(r(U), { key: 0 })) : (u(), h(r(D), { key: 1 }))
      ], 42, ["tabindex", "aria-label", "onMouseenter", "onMouseleave", "onFocus", "onBlur"])) : N("v-if", !0),
      e.pageCount > 1 ? (u(), p("li", {
        key: 3,
        class: b([[
          r(i).is("active", e.currentPage === e.pageCount),
          r(i).is("disabled", e.disabled)
        ], "number"]),
        "aria-current": e.currentPage === e.pageCount,
        "aria-label": r(v)("el.pagination.currentPage", { pager: e.pageCount }),
        tabindex: r(m)
      }, A(e.pageCount), 11, ["aria-current", "aria-label", "tabindex"])) : N("v-if", !0)
    ], 42, ["onKeyup"]));
  }
});
var ue = /* @__PURE__ */ X(_, [["__file", "pager.vue"]]);
export {
  ue as default
};
