var _ = Object.defineProperty;
var n = (e, s) => _(e, "name", { value: s, configurable: !0 });
import { defineComponent as y, ref as g, getCurrentInstance as E, provide as O, reactive as C, toRefs as $, computed as G, onMounted as N, withDirectives as S, openBlock as w, createElementBlock as B, normalizeClass as a, createElementVNode as c, toDisplayString as R, renderSlot as T, vShow as k } from "vue";
import { useMutationObserver as D } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { selectGroupKey as M } from "../token/index.js";
import z from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as A } from "../../../../hooks/use-namespace/index/index.js";
import I from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/castArray/index.js";
const K = y({
  name: "ElOptionGroup",
  componentName: "ElOptionGroup",
  props: {
    label: String,
    disabled: Boolean
  },
  setup(e) {
    const s = A("select"), i = g(null), m = E(), p = g([]);
    O(M, C({
      ...$(e)
    }));
    const f = G(() => p.value.some((r) => r.visible === !0)), h = /* @__PURE__ */ n((r) => {
      var l, o;
      return ((l = r.type) == null ? void 0 : l.name) === "ElOption" && !!((o = r.component) != null && o.proxy);
    }, "isOption"), u = /* @__PURE__ */ n((r) => {
      const l = I(r), o = [];
      return l.forEach((t) => {
        var v, b;
        h(t) ? o.push(t.component.proxy) : (v = t.children) != null && v.length ? o.push(...u(t.children)) : (b = t.component) != null && b.subTree && o.push(...u(t.component.subTree));
      }), o;
    }, "flattedChildren"), d = /* @__PURE__ */ n(() => {
      p.value = u(m.subTree);
    }, "updateChildren");
    return N(() => {
      d();
    }), D(i, d, {
      attributes: !0,
      subtree: !0,
      childList: !0
    }), {
      groupRef: i,
      visible: f,
      ns: s
    };
  }
});
function L(e, s, i, m, p, f) {
  return S((w(), B("ul", {
    ref: "groupRef",
    class: a(e.ns.be("group", "wrap"))
  }, [
    c("li", {
      class: a(e.ns.be("group", "title"))
    }, R(e.label), 3),
    c("li", null, [
      c("ul", {
        class: a(e.ns.b("group"))
      }, [
        T(e.$slots, "default")
      ], 2)
    ])
  ], 2)), [
    [k, e.visible]
  ]);
}
n(L, "_sfc_render");
var Q = /* @__PURE__ */ z(K, [["render", L], ["__file", "option-group.vue"]]);
export {
  Q as default
};
