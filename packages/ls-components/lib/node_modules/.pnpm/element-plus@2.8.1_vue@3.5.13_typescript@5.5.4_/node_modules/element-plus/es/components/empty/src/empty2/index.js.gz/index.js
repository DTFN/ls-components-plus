import { defineComponent as n, computed as p, openBlock as s, createElementBlock as r, normalizeClass as m, unref as t, createElementVNode as l, normalizeStyle as u, renderSlot as i, createVNode as g, toDisplayString as k, createCommentVNode as v } from "vue";
import E from "../img-empty/index.js";
import { emptyProps as S } from "../empty/index.js";
import _ from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as $ } from "../../../../hooks/use-locale/index/index.js";
import { useNamespace as N } from "../../../../hooks/use-namespace/index/index.js";
import { addUnit as b } from "../../../../utils/dom/style/index.js";
const z = n({
  name: "ElEmpty"
}), C = /* @__PURE__ */ n({
  ...z,
  props: S,
  setup(c) {
    const a = c, { t: d } = $(), o = N("empty"), f = p(() => a.description || d("el.table.emptyText")), y = p(() => ({
      width: b(a.imageSize)
    }));
    return (e, V) => (s(), r("div", {
      class: m(t(o).b())
    }, [
      l("div", {
        class: m(t(o).e("image")),
        style: u(t(y))
      }, [
        e.image ? (s(), r("img", {
          key: 0,
          src: e.image,
          ondragstart: "return false"
        }, null, 8, ["src"])) : i(e.$slots, "image", { key: 1 }, () => [
          g(E)
        ])
      ], 6),
      l("div", {
        class: m(t(o).e("description"))
      }, [
        e.$slots.description ? i(e.$slots, "description", { key: 0 }) : (s(), r("p", { key: 1 }, k(t(f)), 1))
      ], 2),
      e.$slots.default ? (s(), r("div", {
        key: 0,
        class: m(t(o).e("bottom"))
      }, [
        i(e.$slots, "default")
      ], 2)) : v("v-if", !0)
    ], 2));
  }
});
var T = /* @__PURE__ */ _(C, [["__file", "empty.vue"]]);
export {
  T as default
};
