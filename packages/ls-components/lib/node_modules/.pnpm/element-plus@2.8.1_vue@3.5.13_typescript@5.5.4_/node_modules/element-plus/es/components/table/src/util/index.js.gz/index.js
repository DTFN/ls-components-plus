var S = Object.defineProperty;
var u = (n, e) => S(n, "name", { value: e, configurable: !0 });
import { createVNode as F, render as v } from "vue";
import { ElTooltip as R } from "../../../tooltip/index/index.js";
import { hasOwn as _, isArray as x, isObject as N } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { throwError as A } from "../../../../utils/error/index.js";
import { isBoolean as I } from "../../../../utils/types/index.js";
import q from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/flatMap/index.js";
import L from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/get/index.js";
const W = /* @__PURE__ */ u(function(n) {
  var e;
  return (e = n.target) == null ? void 0 : e.closest("td");
}, "getCell"), B = /* @__PURE__ */ u(function(n, e, r, t, l) {
  if (!e && !t && (!l || Array.isArray(l) && !l.length))
    return n;
  typeof r == "string" ? r = r === "descending" ? -1 : 1 : r = r && r < 0 ? -1 : 1;
  const s = t ? null : function(i, c) {
    return l ? (Array.isArray(l) || (l = [l]), l.map((o) => typeof o == "string" ? L(i, o) : o(i, c, n))) : (e !== "$key" && N(i) && "$value" in i && (i = i.$value), [N(i) ? L(i, e) : i]);
  }, f = /* @__PURE__ */ u(function(i, c) {
    if (t)
      return t(i.value, c.value);
    for (let o = 0, d = i.key.length; o < d; o++) {
      if (i.key[o] < c.key[o])
        return -1;
      if (i.key[o] > c.key[o])
        return 1;
    }
    return 0;
  }, "compare");
  return n.map((i, c) => ({
    value: i,
    index: c,
    key: s ? s(i, c) : null
  })).sort((i, c) => {
    let o = f(i, c);
    return o || (o = i.index - c.index), o * +r;
  }).map((i) => i.value);
}, "orderBy"), H = /* @__PURE__ */ u(function(n, e) {
  let r = null;
  return n.columns.forEach((t) => {
    t.id === e && (r = t);
  }), r;
}, "getColumnById"), T = /* @__PURE__ */ u(function(n, e) {
  let r = null;
  for (let t = 0; t < n.columns.length; t++) {
    const l = n.columns[t];
    if (l.columnKey === e) {
      r = l;
      break;
    }
  }
  return r || A("ElTable", `No column matching with column-key: ${e}`), r;
}, "getColumnByKey"), V = /* @__PURE__ */ u(function(n, e, r) {
  const t = (e.className || "").match(new RegExp(`${r}-table_[^\\s]+`, "gm"));
  return t ? H(n, t[0]) : null;
}, "getColumnByCell"), j = /* @__PURE__ */ u((n, e) => {
  if (!n)
    throw new Error("Row is required when get row identity");
  if (typeof e == "string") {
    if (!e.includes("."))
      return `${n[e]}`;
    const r = e.split(".");
    let t = n;
    for (const l of r)
      t = t[l];
    return `${t}`;
  } else if (typeof e == "function")
    return e.call(null, n);
}, "getRowIdentity"), b = /* @__PURE__ */ u(function(n, e) {
  const r = {};
  return (n || []).forEach((t, l) => {
    r[j(t, e)] = { row: t, index: l };
  }), r;
}, "getKeysMap");
function K(n, e) {
  const r = {};
  let t;
  for (t in n)
    r[t] = n[t];
  for (t in e)
    if (_(e, t)) {
      const l = e[t];
      typeof l < "u" && (r[t] = l);
    }
  return r;
}
u(K, "mergeOptions");
function M(n) {
  return n === "" || n !== void 0 && (n = Number.parseInt(n, 10), Number.isNaN(n) && (n = "")), n;
}
u(M, "parseWidth");
function P(n) {
  return n === "" || n !== void 0 && (n = M(n), Number.isNaN(n) && (n = 80)), n;
}
u(P, "parseMinWidth");
function w(n) {
  return typeof n == "number" ? n : typeof n == "string" ? /^\d+(?:px)?$/.test(n) ? Number.parseInt(n, 10) : n : null;
}
u(w, "parseHeight");
function nn(...n) {
  return n.length === 0 ? (e) => e : n.length === 1 ? n[0] : n.reduce((e, r) => (...t) => e(r(...t)));
}
u(nn, "compose");
function D(n, e, r, t, l, s) {
  let f = s ?? 0, i = !1;
  const c = n.indexOf(e), o = c !== -1, d = l == null ? void 0 : l.call(null, e, s), m = /* @__PURE__ */ u((p) => {
    p === "add" ? n.push(e) : n.splice(c, 1), i = !0;
  }, "toggleStatus"), C = /* @__PURE__ */ u((p) => {
    let h = 0;
    const g = (t == null ? void 0 : t.children) && p[t.children];
    return g && x(g) && (h += g.length, g.forEach((O) => {
      h += C(O);
    })), h;
  }, "getChildrenCount");
  return (!l || d) && (I(r) ? r && !o ? m("add") : !r && o && m("remove") : m(o ? "remove" : "add")), !(t != null && t.checkStrictly) && (t != null && t.children) && x(e[t.children]) && e[t.children].forEach((p) => {
    D(n, p, r ?? !o, t, l, f + 1), f += C(p) + 1;
  }), i;
}
u(D, "toggleRowStatus");
function en(n, e, r = "children", t = "hasChildren") {
  const l = /* @__PURE__ */ u((f) => !(Array.isArray(f) && f.length), "isNil");
  function s(f, i, c) {
    e(f, i, c), i.forEach((o) => {
      if (o[t]) {
        e(o, null, c + 1);
        return;
      }
      const d = o[r];
      l(d) || s(o, d, c + 1);
    });
  }
  u(s, "_walker"), n.forEach((f) => {
    if (f[t]) {
      e(f, null, 0);
      return;
    }
    const i = f[r];
    l(i) || s(f, i, 0);
  });
}
u(en, "walkTreeNode");
let a = null;
function tn(n, e, r, t) {
  if ((a == null ? void 0 : a.trigger) === r)
    return;
  a == null || a();
  const l = t == null ? void 0 : t.refs.tableWrapper, s = l == null ? void 0 : l.dataset.prefix, f = {
    strategy: "fixed",
    ...n.popperOptions
  }, i = F(R, {
    content: e,
    virtualTriggering: !0,
    virtualRef: r,
    appendTo: l,
    placement: "top",
    transition: "none",
    offset: 0,
    hideAfter: 0,
    ...n,
    popperOptions: f,
    onHide: /* @__PURE__ */ u(() => {
      a == null || a();
    }, "onHide")
  });
  i.appContext = { ...t.appContext, ...t };
  const c = document.createElement("div");
  v(i, c), i.component.exposed.onOpen();
  const o = l == null ? void 0 : l.querySelector(`.${s}-scrollbar__wrap`);
  a = /* @__PURE__ */ u(() => {
    v(null, c), o == null || o.removeEventListener("scroll", a), a = null;
  }, "removePopper"), a.trigger = r, o == null || o.addEventListener("scroll", a);
}
u(tn, "createTablePopper");
function y(n) {
  return n.children ? q(n.children, y) : [n];
}
u(y, "getCurrentColumns");
function k(n, e) {
  return n + e.colSpan;
}
u(k, "getColSpan");
const $ = /* @__PURE__ */ u((n, e, r, t) => {
  let l = 0, s = n;
  const f = r.states.columns.value;
  if (t) {
    const c = y(t[n]);
    l = f.slice(0, f.indexOf(c[0])).reduce(k, 0), s = l + c.reduce(k, 0) - 1;
  } else
    l = n;
  let i;
  switch (e) {
    case "left":
      s < r.states.fixedLeafColumnsLength.value && (i = "left");
      break;
    case "right":
      l >= f.length - r.states.rightFixedLeafColumnsLength.value && (i = "right");
      break;
    default:
      s < r.states.fixedLeafColumnsLength.value ? i = "left" : l >= f.length - r.states.rightFixedLeafColumnsLength.value && (i = "right");
  }
  return i ? {
    direction: i,
    start: l,
    after: s
  } : {};
}, "isFixedColumn"), rn = /* @__PURE__ */ u((n, e, r, t, l, s = 0) => {
  const f = [], { direction: i, start: c, after: o } = $(e, r, t, l);
  if (i) {
    const d = i === "left";
    f.push(`${n}-fixed-column--${i}`), d && o + s === t.states.fixedLeafColumnsLength.value - 1 ? f.push("is-last-column") : !d && c - s === t.states.columns.value.length - t.states.rightFixedLeafColumnsLength.value && f.push("is-first-column");
  }
  return f;
}, "getFixedColumnsClass");
function E(n, e) {
  return n + (e.realWidth === null || Number.isNaN(e.realWidth) ? Number(e.width) : e.realWidth);
}
u(E, "getOffset");
const ln = /* @__PURE__ */ u((n, e, r, t) => {
  const {
    direction: l,
    start: s = 0,
    after: f = 0
  } = $(n, e, r, t);
  if (!l)
    return;
  const i = {}, c = l === "left", o = r.states.columns.value;
  return c ? i.left = o.slice(0, s).reduce(E, 0) : i.right = o.slice(f + 1).reverse().reduce(E, 0), i;
}, "getFixedColumnOffset"), on = /* @__PURE__ */ u((n, e) => {
  n && (Number.isNaN(n[e]) || (n[e] = `${n[e]}px`));
}, "ensurePosition");
export {
  nn as compose,
  tn as createTablePopper,
  on as ensurePosition,
  W as getCell,
  V as getColumnByCell,
  H as getColumnById,
  T as getColumnByKey,
  ln as getFixedColumnOffset,
  rn as getFixedColumnsClass,
  b as getKeysMap,
  j as getRowIdentity,
  $ as isFixedColumn,
  K as mergeOptions,
  B as orderBy,
  w as parseHeight,
  P as parseMinWidth,
  M as parseWidth,
  a as removePopper,
  D as toggleRowStatus,
  en as walkTreeNode
};
