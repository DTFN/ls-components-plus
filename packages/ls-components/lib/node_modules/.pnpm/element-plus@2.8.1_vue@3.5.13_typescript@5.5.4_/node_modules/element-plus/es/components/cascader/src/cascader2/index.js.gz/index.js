var Je = Object.defineProperty;
var o = (U, W) => Je(U, "name", { value: W, configurable: !0 });
import { defineComponent as $e, useAttrs as Qe, ref as u, computed as i, watch as I, nextTick as D, onMounted as Xe, openBlock as c, createBlock as w, unref as a, withCtx as f, withDirectives as H, createElementBlock as k, normalizeClass as v, normalizeStyle as Ye, createVNode as z, withModifiers as re, Fragment as ie, renderList as ce, toDisplayString as M, createElementVNode as F, withKeys as Ze, vModelText as et, createCommentVNode as L, isRef as tt, vShow as _e, renderSlot as lt } from "vue";
import { isPromise as at } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { useResizeObserver as ot, useCssVar as st } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { ElCascaderPanel as nt } from "../../../cascader-panel/index/index.js";
import { ElInput as rt } from "../../../input/index/index.js";
import { ElTooltip as Se } from "../../../tooltip/index/index.js";
import { ElScrollbar as it } from "../../../scrollbar/index/index.js";
import { ElTag as Ve } from "../../../tag/index/index.js";
import { ElIcon as ue } from "../../../icon/index/index.js";
import { CircleClose as ct, ArrowDown as ut, Check as pt } from "@element-plus/icons-vue";
import { cascaderProps as dt, cascaderEmits as ft } from "../cascader/index.js";
import vt from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as Ne } from "../../../../hooks/use-namespace/index/index.js";
import { useLocale as mt } from "../../../../hooks/use-locale/index/index.js";
import { useFormItem as ht } from "../../../form/src/hooks/use-form-item/index.js";
import { useEmptyValues as gt } from "../../../../hooks/use-empty-values/index/index.js";
import { useComposition as Ct } from "../../../../hooks/use-composition/index/index.js";
import { useFormSize as kt } from "../../../form/src/hooks/use-form-common-props/index.js";
import { UPDATE_MODEL_EVENT as bt, CHANGE_EVENT as yt } from "../../../../constants/event/index.js";
import { debugWarn as Tt } from "../../../../utils/error/index.js";
import { EVENT_CODE as _ } from "../../../../constants/aria/index.js";
import { focusNode as Et, getSibling as wt } from "../../../../utils/dom/aria/index.js";
import _t from "../../../../directives/click-outside/index/index.js";
import St from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/cloneDeep/index.js";
import Vt from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/debounce/index.js";
import { isClient as Nt } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const $t = "ElCascader", Pt = $e({
  name: $t
}), xt = /* @__PURE__ */ $e({
  ...Pt,
  props: dt,
  emits: ft,
  setup(U, { expose: W, emit: b }) {
    const n = U, Pe = {
      modifiers: [
        {
          name: "arrowPosition",
          enabled: !0,
          phase: "main",
          fn: /* @__PURE__ */ o(({ state: e }) => {
            const { modifiersData: t, placement: l } = e;
            ["right", "left", "bottom", "top"].includes(l) || (t.arrow.x = 35);
          }, "fn"),
          requires: ["arrow"]
        }
      ]
    }, pe = Qe();
    let $ = 0, q = 0;
    const r = Ne("cascader"), G = Ne("input"), { t: de } = mt(), { form: fe, formItem: K } = ht(), { valueOnClear: xe } = gt(n), { isComposing: ve, handleComposition: N } = Ct({
      afterComposition(e) {
        var t;
        const l = (t = e.target) == null ? void 0 : t.value;
        ne(l);
      }
    }), j = u(null), P = u(null), me = u(null), d = u(null), A = u(null), m = u(!1), J = u(!1), y = u(!1), Q = u(!1), B = u(""), S = u(""), V = u([]), X = u([]), Y = u([]), Ie = i(() => pe.style), T = i(() => n.disabled || (fe == null ? void 0 : fe.disabled)), he = i(() => n.placeholder || de("el.cascader.placeholder")), De = i(() => S.value || V.value.length > 0 || ve.value ? "" : he.value), O = kt(), ge = i(() => ["small"].includes(O.value) ? "small" : "default"), E = i(() => !!n.props.multiple), Ce = i(() => !n.filterable || E.value), ke = i(() => E.value ? S.value : B.value), R = i(() => {
      var e;
      return ((e = d.value) == null ? void 0 : e.checkedNodes) || [];
    }), ze = i(() => !n.clearable || T.value || y.value || !J.value ? !1 : !!R.value.length), Z = i(() => {
      const { showAllLevels: e, separator: t } = n, l = R.value;
      return l.length ? E.value ? "" : l[0].calcText(e, t) : "";
    }), Me = i(() => (K == null ? void 0 : K.validateState) || ""), ee = i({
      get() {
        return St(n.modelValue);
      },
      set(e) {
        const t = e ?? xe.value;
        b(bt, t), b(yt, t), n.validateEvent && (K == null || K.validate("change").catch((l) => Tt(l)));
      }
    }), Fe = i(() => [
      r.b(),
      r.m(O.value),
      r.is("disabled", T.value),
      pe.class
    ]), Ke = i(() => [
      G.e("icon"),
      "icon-arrow-down",
      r.is("reverse", m.value)
    ]), Ae = i(() => r.is("focus", m.value || Q.value)), be = i(() => {
      var e, t;
      return (t = (e = j.value) == null ? void 0 : e.popperRef) == null ? void 0 : t.contentRef;
    }), p = /* @__PURE__ */ o((e) => {
      var t, l, s;
      T.value || (e = e ?? !m.value, e !== m.value && (m.value = e, (l = (t = P.value) == null ? void 0 : t.input) == null || l.setAttribute("aria-expanded", `${e}`), e ? (x(), D((s = d.value) == null ? void 0 : s.scrollToExpandingNode)) : n.filterable && se(), b("visibleChange", e)));
    }, "togglePopperVisible"), x = /* @__PURE__ */ o(() => {
      D(() => {
        var e;
        (e = j.value) == null || e.updatePopper();
      });
    }, "updatePopperPosition"), te = /* @__PURE__ */ o(() => {
      y.value = !1;
    }, "hideSuggestionPanel"), le = /* @__PURE__ */ o((e) => {
      const { showAllLevels: t, separator: l } = n;
      return {
        node: e,
        key: e.uid,
        text: e.calcText(t, l),
        hitState: !1,
        closable: !T.value && !e.isDisabled,
        isCollapseTag: !1
      };
    }, "genTag"), ae = /* @__PURE__ */ o((e) => {
      var t;
      const l = e.node;
      l.doCheck(!1), (t = d.value) == null || t.calculateCheckedValue(), b("removeTag", l.valueByOption);
    }, "deleteTag"), Be = /* @__PURE__ */ o(() => {
      if (!E.value)
        return;
      const e = R.value, t = [], l = [];
      if (e.forEach((s) => l.push(le(s))), X.value = l, e.length) {
        e.slice(0, n.maxCollapseTags).forEach((h) => t.push(le(h)));
        const s = e.slice(n.maxCollapseTags), g = s.length;
        g && (n.collapseTags ? t.push({
          key: -1,
          text: `+ ${g}`,
          closable: !1,
          isCollapseTag: !0
        }) : s.forEach((h) => t.push(le(h))));
      }
      V.value = t;
    }, "calculatePresentTags"), ye = /* @__PURE__ */ o(() => {
      var e, t;
      const { filterMethod: l, showAllLevels: s, separator: g } = n, h = (t = (e = d.value) == null ? void 0 : e.getFlattedNodes(!n.props.checkStrictly)) == null ? void 0 : t.filter((C) => C.isDisabled ? !1 : (C.calcText(s, g), l(C, ke.value)));
      E.value && (V.value.forEach((C) => {
        C.hitState = !1;
      }), X.value.forEach((C) => {
        C.hitState = !1;
      })), y.value = !0, Y.value = h, x();
    }, "calculateSuggestions"), Oe = /* @__PURE__ */ o(() => {
      var e;
      let t;
      y.value && A.value ? t = A.value.$el.querySelector(`.${r.e("suggestion-item")}`) : t = (e = d.value) == null ? void 0 : e.$el.querySelector(`.${r.b("node")}[tabindex="-1"]`), t && (t.focus(), !y.value && t.click());
    }, "focusFirstNode"), oe = /* @__PURE__ */ o(() => {
      var e, t;
      const l = (e = P.value) == null ? void 0 : e.input, s = me.value, g = (t = A.value) == null ? void 0 : t.$el;
      if (!(!Nt || !l)) {
        if (g) {
          const h = g.querySelector(`.${r.e("suggestion-list")}`);
          h.style.minWidth = `${l.offsetWidth}px`;
        }
        if (s) {
          const { offsetHeight: h } = s, C = V.value.length > 0 ? `${Math.max(h + 6, $)}px` : `${$}px`;
          l.style.height = C, x();
        }
      }
    }, "updateStyle"), Re = /* @__PURE__ */ o((e) => {
      var t;
      return (t = d.value) == null ? void 0 : t.getCheckedNodes(e);
    }, "getCheckedNodes"), He = /* @__PURE__ */ o((e) => {
      x(), b("expandChange", e);
    }, "handleExpandChange"), Le = /* @__PURE__ */ o((e) => {
      if (!ve.value)
        switch (e.code) {
          case _.enter:
            p();
            break;
          case _.down:
            p(!0), D(Oe), e.preventDefault();
            break;
          case _.esc:
            m.value === !0 && (e.preventDefault(), e.stopPropagation(), p(!1));
            break;
          case _.tab:
            p(!1);
            break;
        }
    }, "handleKeyDown"), Ue = /* @__PURE__ */ o(() => {
      var e;
      (e = d.value) == null || e.clearCheckedNodes(), !m.value && n.filterable && se(), p(!1), b("clear");
    }, "handleClear"), se = /* @__PURE__ */ o(() => {
      const { value: e } = Z;
      B.value = e, S.value = e;
    }, "syncPresentTextValue"), We = /* @__PURE__ */ o((e) => {
      var t, l;
      const { checked: s } = e;
      E.value ? (t = d.value) == null || t.handleCheckChange(e, !s, !1) : (!s && ((l = d.value) == null || l.handleCheckChange(e, !0, !1)), p(!1));
    }, "handleSuggestionClick"), qe = /* @__PURE__ */ o((e) => {
      const t = e.target, { code: l } = e;
      switch (l) {
        case _.up:
        case _.down: {
          const s = l === _.up ? -1 : 1;
          Et(wt(t, s, `.${r.e("suggestion-item")}[tabindex="-1"]`));
          break;
        }
        case _.enter:
          t.click();
          break;
      }
    }, "handleSuggestionKeyDown"), Ge = /* @__PURE__ */ o(() => {
      const e = V.value, t = e[e.length - 1];
      q = S.value ? 0 : q + 1, !(!t || !q || n.collapseTags && e.length > 1) && (t.hitState ? ae(t) : t.hitState = !0);
    }, "handleDelete"), Te = /* @__PURE__ */ o((e) => {
      const t = e.target, l = r.e("search-input");
      t.className === l && (Q.value = !0), b("focus", e);
    }, "handleFocus"), Ee = /* @__PURE__ */ o((e) => {
      Q.value = !1, b("blur", e);
    }, "handleBlur"), je = Vt(() => {
      const { value: e } = ke;
      if (!e)
        return;
      const t = n.beforeFilter(e);
      at(t) ? t.then(ye).catch(() => {
      }) : t !== !1 ? ye() : te();
    }, n.debounce), ne = /* @__PURE__ */ o((e, t) => {
      !m.value && p(!0), !(t != null && t.isComposing) && (e ? je() : te());
    }, "handleInput"), we = /* @__PURE__ */ o((e) => Number.parseFloat(st(G.cssVarName("input-height"), e).value) - 2, "getInputInnerHeight");
    return I(y, x), I([R, T, () => n.collapseTags], Be), I(V, () => {
      D(() => oe());
    }), I(O, async () => {
      await D();
      const e = P.value.input;
      $ = we(e) || $, oe();
    }), I(Z, se, { immediate: !0 }), Xe(() => {
      const e = P.value.input, t = we(e);
      $ = e.offsetHeight || t, ot(e, oe);
    }), W({
      getCheckedNodes: Re,
      cascaderPanelRef: d,
      togglePopperVisible: p,
      contentRef: be
    }), (e, t) => (c(), w(a(Se), {
      ref_key: "tooltipRef",
      ref: j,
      visible: m.value,
      teleported: e.teleported,
      "popper-class": [a(r).e("dropdown"), e.popperClass],
      "popper-options": Pe,
      "fallback-placements": e.fallbackPlacements,
      "stop-popper-mouse-event": !1,
      "gpu-acceleration": !1,
      placement: e.placement,
      transition: `${a(r).namespace.value}-zoom-in-top`,
      effect: "light",
      pure: "",
      persistent: e.persistent,
      onHide: te
    }, {
      default: f(() => [
        H((c(), k("div", {
          class: v(a(Fe)),
          style: Ye(a(Ie)),
          onClick: /* @__PURE__ */ o(() => p(a(Ce) ? void 0 : !0), "onClick"),
          onKeydown: Le,
          onMouseenter: /* @__PURE__ */ o((l) => J.value = !0, "onMouseenter"),
          onMouseleave: /* @__PURE__ */ o((l) => J.value = !1, "onMouseleave")
        }, [
          z(a(rt), {
            ref_key: "input",
            ref: P,
            modelValue: B.value,
            "onUpdate:modelValue": /* @__PURE__ */ o((l) => B.value = l, "onUpdate:modelValue"),
            placeholder: a(De),
            readonly: a(Ce),
            disabled: a(T),
            "validate-event": !1,
            size: a(O),
            class: v(a(Ae)),
            tabindex: a(E) && e.filterable && !a(T) ? -1 : void 0,
            onCompositionstart: a(N),
            onCompositionupdate: a(N),
            onCompositionend: a(N),
            onFocus: Te,
            onBlur: Ee,
            onInput: ne
          }, {
            suffix: f(() => [
              a(ze) ? (c(), w(a(ue), {
                key: "clear",
                class: v([a(G).e("icon"), "icon-circle-close"]),
                onClick: re(Ue, ["stop"])
              }, {
                default: f(() => [
                  z(a(ct))
                ]),
                _: 1
              }, 8, ["class", "onClick"])) : (c(), w(a(ue), {
                key: "arrow-down",
                class: v(a(Ke)),
                onClick: re((l) => p(), ["stop"])
              }, {
                default: f(() => [
                  z(a(ut))
                ]),
                _: 1
              }, 8, ["class", "onClick"]))
            ]),
            _: 1
          }, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "readonly", "disabled", "size", "class", "tabindex", "onCompositionstart", "onCompositionupdate", "onCompositionend"]),
          a(E) ? (c(), k("div", {
            key: 0,
            ref_key: "tagWrapper",
            ref: me,
            class: v([
              a(r).e("tags"),
              a(r).is("validate", !!a(Me))
            ])
          }, [
            (c(!0), k(ie, null, ce(V.value, (l) => (c(), w(a(Ve), {
              key: l.key,
              type: e.tagType,
              size: a(ge),
              effect: e.tagEffect,
              hit: l.hitState,
              closable: l.closable,
              "disable-transitions": "",
              onClose: /* @__PURE__ */ o((s) => ae(l), "onClose")
            }, {
              default: f(() => [
                l.isCollapseTag === !1 ? (c(), k("span", { key: 0 }, M(l.text), 1)) : (c(), w(a(Se), {
                  key: 1,
                  disabled: m.value || !e.collapseTagsTooltip,
                  "fallback-placements": ["bottom", "top", "right", "left"],
                  placement: "bottom",
                  effect: "light"
                }, {
                  default: f(() => [
                    F("span", null, M(l.text), 1)
                  ]),
                  content: f(() => [
                    F("div", {
                      class: v(a(r).e("collapse-tags"))
                    }, [
                      (c(!0), k(ie, null, ce(X.value.slice(e.maxCollapseTags), (s, g) => (c(), k("div", {
                        key: g,
                        class: v(a(r).e("collapse-tag"))
                      }, [
                        (c(), w(a(Ve), {
                          key: s.key,
                          class: "in-tooltip",
                          type: e.tagType,
                          size: a(ge),
                          effect: e.tagEffect,
                          hit: s.hitState,
                          closable: s.closable,
                          "disable-transitions": "",
                          onClose: /* @__PURE__ */ o((h) => ae(s), "onClose")
                        }, {
                          default: f(() => [
                            F("span", null, M(s.text), 1)
                          ]),
                          _: 2
                        }, 1032, ["type", "size", "effect", "hit", "closable", "onClose"]))
                      ], 2))), 128))
                    ], 2)
                  ]),
                  _: 2
                }, 1032, ["disabled"]))
              ]),
              _: 2
            }, 1032, ["type", "size", "effect", "hit", "closable", "onClose"]))), 128)),
            e.filterable && !a(T) ? H((c(), k("input", {
              key: 0,
              "onUpdate:modelValue": /* @__PURE__ */ o((l) => S.value = l, "onUpdate:modelValue"),
              type: "text",
              class: v(a(r).e("search-input")),
              placeholder: a(Z) ? "" : a(he),
              onInput: /* @__PURE__ */ o((l) => ne(S.value, l), "onInput"),
              onClick: re((l) => p(!0), ["stop"]),
              onKeydown: Ze(Ge, ["delete"]),
              onCompositionstart: a(N),
              onCompositionupdate: a(N),
              onCompositionend: a(N),
              onFocus: Te,
              onBlur: Ee
            }, null, 42, ["onUpdate:modelValue", "placeholder", "onInput", "onClick", "onKeydown", "onCompositionstart", "onCompositionupdate", "onCompositionend"])), [
              [et, S.value]
            ]) : L("v-if", !0)
          ], 2)) : L("v-if", !0)
        ], 46, ["onClick", "onMouseenter", "onMouseleave"])), [
          [a(_t), () => p(!1), a(be)]
        ])
      ]),
      content: f(() => [
        H(z(a(nt), {
          ref_key: "cascaderPanelRef",
          ref: d,
          modelValue: a(ee),
          "onUpdate:modelValue": /* @__PURE__ */ o((l) => tt(ee) ? ee.value = l : null, "onUpdate:modelValue"),
          options: e.options,
          props: n.props,
          border: !1,
          "render-label": e.$slots.default,
          onExpandChange: He,
          onClose: /* @__PURE__ */ o((l) => e.$nextTick(() => p(!1)), "onClose")
        }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "props", "render-label", "onClose"]), [
          [_e, !y.value]
        ]),
        e.filterable ? H((c(), w(a(it), {
          key: 0,
          ref_key: "suggestionPanel",
          ref: A,
          tag: "ul",
          class: v(a(r).e("suggestion-panel")),
          "view-class": a(r).e("suggestion-list"),
          onKeydown: qe
        }, {
          default: f(() => [
            Y.value.length ? (c(!0), k(ie, { key: 0 }, ce(Y.value, (l) => (c(), k("li", {
              key: l.uid,
              class: v([
                a(r).e("suggestion-item"),
                a(r).is("checked", l.checked)
              ]),
              tabindex: -1,
              onClick: /* @__PURE__ */ o((s) => We(l), "onClick")
            }, [
              F("span", null, M(l.text), 1),
              l.checked ? (c(), w(a(ue), { key: 0 }, {
                default: f(() => [
                  z(a(pt))
                ]),
                _: 1
              })) : L("v-if", !0)
            ], 10, ["onClick"]))), 128)) : lt(e.$slots, "empty", { key: 1 }, () => [
              F("li", {
                class: v(a(r).e("empty-text"))
              }, M(a(de)("el.cascader.noMatch")), 3)
            ])
          ]),
          _: 3
        }, 8, ["class", "view-class"])), [
          [_e, y.value]
        ]) : L("v-if", !0)
      ]),
      _: 3
    }, 8, ["visible", "teleported", "popper-class", "fallback-placements", "placement", "transition", "persistent"]));
  }
});
var sl = /* @__PURE__ */ vt(xt, [["__file", "cascader.vue"]]);
export {
  sl as default
};
