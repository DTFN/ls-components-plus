var l = Object.defineProperty;
var t = (e, a) => l(e, "name", { value: a, configurable: !0 });
import { useSizeProp as n } from "../../../../hooks/use-size/index/index.js";
import { useAriaProps as d } from "../../../../hooks/use-aria/index/index.js";
import { UPDATE_MODEL_EVENT as u } from "../../../../constants/event/index.js";
import { isString as o } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isNumber as r, isBoolean as i } from "../../../../utils/types/index.js";
const S = {
  modelValue: {
    type: [Number, String, Boolean],
    default: void 0
  },
  label: {
    type: [String, Boolean, Number, Object],
    default: void 0
  },
  value: {
    type: [String, Boolean, Number, Object],
    default: void 0
  },
  indeterminate: Boolean,
  disabled: Boolean,
  checked: Boolean,
  name: {
    type: String,
    default: void 0
  },
  trueValue: {
    type: [String, Number],
    default: void 0
  },
  falseValue: {
    type: [String, Number],
    default: void 0
  },
  trueLabel: {
    type: [String, Number],
    default: void 0
  },
  falseLabel: {
    type: [String, Number],
    default: void 0
  },
  id: {
    type: String,
    default: void 0
  },
  border: Boolean,
  size: n,
  tabindex: [String, Number],
  validateEvent: {
    type: Boolean,
    default: !0
  },
  ...d(["ariaControls"])
}, c = {
  [u]: (e) => o(e) || r(e) || i(e),
  change: /* @__PURE__ */ t((e) => o(e) || r(e) || i(e), "change")
};
export {
  c as checkboxEmits,
  S as checkboxProps
};
