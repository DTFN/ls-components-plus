var p = Object.defineProperty;
var n = (o, d) => p(o, "name", { value: d, configurable: !0 });
import { isRef as f, computed as y, watch as h, onScopeDispose as b } from "vue";
import { useNamespace as v } from "../../use-namespace/index/index.js";
import { throwError as w } from "../../../utils/error/index.js";
import { hasClass as m, getStyle as C, addClass as H, removeClass as S } from "../../../utils/dom/style/index.js";
import { getScrollBarWidth as W } from "../../../utils/dom/scroll/index.js";
import { isClient as Y } from "../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const D = /* @__PURE__ */ n((o, d = {}) => {
  f(o) || w("[useLockscreen]", "You need to pass a ref param to this function");
  const c = d.ns || v("popup"), e = y(() => c.bm("parent", "hidden"));
  if (!Y || m(document.body, e.value))
    return;
  let s = 0, t = !1, l = "0";
  const r = /* @__PURE__ */ n(() => {
    setTimeout(() => {
      S(document == null ? void 0 : document.body, e.value), t && document && (document.body.style.width = l);
    }, 200);
  }, "cleanup");
  h(o, (i) => {
    if (!i) {
      r();
      return;
    }
    t = !m(document.body, e.value), t && (l = document.body.style.width), s = W(c.namespace.value);
    const u = document.documentElement.clientHeight < document.body.scrollHeight, a = C(document.body, "overflowY");
    s > 0 && (u || a === "scroll") && t && (document.body.style.width = `calc(100% - ${s}px)`), H(document.body, e.value);
  }), b(() => r());
}, "useLockscreen");
export {
  D as useLockscreen
};
