var C = Object.defineProperty;
var n = (e, l) => C(e, "name", { value: l, configurable: !0 });
import { inject as V, getCurrentInstance as x, computed as E, watch as _, nextTick as I } from "vue";
import { checkboxGroupContextKey as T } from "../../constants/index.js";
import { useFormItem as w } from "../../../../form/src/hooks/use-form-item/index.js";
import { debugWarn as y } from "../../../../../utils/error/index.js";
const K = /* @__PURE__ */ n((e, {
  model: l,
  isLimitExceeded: r,
  hasOwnLabel: s,
  isDisabled: h,
  isLabeledByFormItem: d
}) => {
  const i = V(T, void 0), { formItem: v } = w(), { emit: f } = x();
  function c(t) {
    var a, o, u, m;
    return [!0, e.trueValue, e.trueLabel].includes(t) ? (o = (a = e.trueValue) != null ? a : e.trueLabel) != null ? o : !0 : (m = (u = e.falseValue) != null ? u : e.falseLabel) != null ? m : !1;
  }
  n(c, "getLabeledValue");
  function g(t, a) {
    f("change", c(t), a);
  }
  n(g, "emitChangeEvent");
  function b(t) {
    if (r.value)
      return;
    const a = t.target;
    f("change", c(a.checked), t);
  }
  n(b, "handleChange");
  async function L(t) {
    r.value || !s.value && !h.value && d.value && (t.composedPath().some((u) => u.tagName === "LABEL") || (l.value = c([!1, e.falseValue, e.falseLabel].includes(l.value)), await I(), g(l.value, t)));
  }
  n(L, "onClickRoot");
  const k = E(() => (i == null ? void 0 : i.validateEvent) || e.validateEvent);
  return _(() => e.modelValue, () => {
    k.value && (v == null || v.validate("change").catch((t) => y(t)));
  }), {
    handleChange: b,
    onClickRoot: L
  };
}, "useCheckboxEvent");
export {
  K as useCheckboxEvent
};
