var B = Object.defineProperty;
var r = (n, l) => B(n, "name", { value: l, configurable: !0 });
import { defineComponent as v, computed as V, openBlock as a, createElementBlock as $, normalizeClass as t, unref as s, normalizeStyle as k, createElementVNode as c, renderSlot as C, createBlock as i, withModifiers as g, withCtx as m, createVNode as y, createCommentVNode as b, Transition as w } from "vue";
import { ElIcon as _ } from "../../../icon/index/index.js";
import { Close as h } from "@element-plus/icons-vue";
import { tagProps as F, tagEmits as I } from "../tag/index.js";
import K from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useFormSize as M } from "../../../form/src/hooks/use-form-common-props/index.js";
import { useNamespace as P } from "../../../../hooks/use-namespace/index/index.js";
const j = v({
  name: "ElTag"
}), q = /* @__PURE__ */ v({
  ...j,
  props: F,
  emits: I,
  setup(n, { emit: l }) {
    const z = n, E = M(), o = P("tag"), p = V(() => {
      const { type: e, hit: d, effect: N, closable: S, round: T } = z;
      return [
        o.b(),
        o.is("closable", S),
        o.m(e || "primary"),
        o.m(E.value),
        o.m(N),
        o.is("hit", d),
        o.is("round", T)
      ];
    }), f = /* @__PURE__ */ r((e) => {
      l("close", e);
    }, "handleClose"), u = /* @__PURE__ */ r((e) => {
      l("click", e);
    }, "handleClick");
    return (e, d) => e.disableTransitions ? (a(), $("span", {
      key: 0,
      class: t(s(p)),
      style: k({ backgroundColor: e.color }),
      onClick: u
    }, [
      c("span", {
        class: t(s(o).e("content"))
      }, [
        C(e.$slots, "default")
      ], 2),
      e.closable ? (a(), i(s(_), {
        key: 0,
        class: t(s(o).e("close")),
        onClick: g(f, ["stop"])
      }, {
        default: m(() => [
          y(s(h))
        ]),
        _: 1
      }, 8, ["class", "onClick"])) : b("v-if", !0)
    ], 6)) : (a(), i(w, {
      key: 1,
      name: `${s(o).namespace.value}-zoom-in-center`,
      appear: ""
    }, {
      default: m(() => [
        c("span", {
          class: t(s(p)),
          style: k({ backgroundColor: e.color }),
          onClick: u
        }, [
          c("span", {
            class: t(s(o).e("content"))
          }, [
            C(e.$slots, "default")
          ], 2),
          e.closable ? (a(), i(s(_), {
            key: 0,
            class: t(s(o).e("close")),
            onClick: g(f, ["stop"])
          }, {
            default: m(() => [
              y(s(h))
            ]),
            _: 1
          }, 8, ["class", "onClick"])) : b("v-if", !0)
        ], 6)
      ]),
      _: 3
    }, 8, ["name"]));
  }
});
var R = /* @__PURE__ */ K(q, [["__file", "tag.vue"]]);
export {
  R as default
};
