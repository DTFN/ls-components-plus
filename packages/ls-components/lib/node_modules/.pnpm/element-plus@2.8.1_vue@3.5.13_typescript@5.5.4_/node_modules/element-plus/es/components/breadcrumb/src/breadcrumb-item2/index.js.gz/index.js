var C = Object.defineProperty;
var i = (a, r) => C(a, "name", { value: r, configurable: !0 });
import { defineComponent as d, getCurrentInstance as v, inject as I, ref as y, openBlock as t, createElementBlock as u, normalizeClass as n, unref as e, createElementVNode as B, renderSlot as g, createBlock as f, withCtx as x, resolveDynamicComponent as E, toDisplayString as h } from "vue";
import { ElIcon as D } from "../../../icon/index/index.js";
import { breadcrumbKey as N } from "../constants/index.js";
import { breadcrumbItemProps as P } from "../breadcrumb-item/index.js";
import S from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as $ } from "../../../../hooks/use-namespace/index/index.js";
const j = d({
  name: "ElBreadcrumbItem"
}), w = /* @__PURE__ */ d({
  ...j,
  props: P,
  setup(a) {
    const r = a, b = v(), s = I(N, void 0), o = $("breadcrumb"), c = b.appContext.config.globalProperties.$router, _ = y(), k = /* @__PURE__ */ i(() => {
      !r.to || !c || (r.replace ? c.replace(r.to) : c.push(r.to));
    }, "onClick");
    return (l, z) => {
      var p, m;
      return t(), u("span", {
        class: n(e(o).e("item"))
      }, [
        B("span", {
          ref_key: "link",
          ref: _,
          class: n([e(o).e("inner"), e(o).is("link", !!l.to)]),
          role: "link",
          onClick: k
        }, [
          g(l.$slots, "default")
        ], 2),
        (p = e(s)) != null && p.separatorIcon ? (t(), f(e(D), {
          key: 0,
          class: n(e(o).e("separator"))
        }, {
          default: x(() => [
            (t(), f(E(e(s).separatorIcon)))
          ]),
          _: 1
        }, 8, ["class"])) : (t(), u("span", {
          key: 1,
          class: n(e(o).e("separator")),
          role: "presentation"
        }, h((m = e(s)) == null ? void 0 : m.separator), 3))
      ], 2);
    };
  }
});
var J = /* @__PURE__ */ S(w, [["__file", "breadcrumb-item.vue"]]);
export {
  J as default
};
