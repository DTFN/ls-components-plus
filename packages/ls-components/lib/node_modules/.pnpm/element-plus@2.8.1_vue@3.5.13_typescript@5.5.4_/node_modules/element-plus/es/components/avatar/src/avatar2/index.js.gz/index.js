var z = Object.defineProperty;
var p = (n, i) => z(n, "name", { value: i, configurable: !0 });
import { defineComponent as h, ref as C, computed as l, watch as _, openBlock as o, createElementBlock as u, normalizeClass as B, unref as a, normalizeStyle as v, createBlock as d, withCtx as b, resolveDynamicComponent as g, renderSlot as w } from "vue";
import { ElIcon as A } from "../../../icon/index/index.js";
import { avatarProps as L, avatarEmits as N } from "../avatar/index.js";
import j from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as D } from "../../../../hooks/use-namespace/index/index.js";
import { isString as F } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isNumber as I } from "../../../../utils/types/index.js";
import { addUnit as P } from "../../../../utils/dom/style/index.js";
const U = h({
  name: "ElAvatar"
}), V = /* @__PURE__ */ h({
  ...U,
  props: L,
  emits: N,
  setup(n, { emit: i }) {
    const s = n, e = D("avatar"), c = C(!1), y = l(() => {
      const { size: r, icon: m, shape: f } = s, t = [e.b()];
      return F(r) && t.push(e.m(r)), m && t.push(e.m("icon")), f && t.push(e.m(f)), t;
    }), k = l(() => {
      const { size: r } = s;
      return I(r) ? e.cssVarBlock({
        size: P(r) || ""
      }) : void 0;
    }), E = l(() => ({
      objectFit: s.fit
    }));
    _(() => s.src, () => c.value = !1);
    function S(r) {
      c.value = !0, i("error", r);
    }
    return p(S, "handleError"), (r, m) => (o(), u("span", {
      class: B(a(y)),
      style: v(a(k))
    }, [
      (r.src || r.srcSet) && !c.value ? (o(), u("img", {
        key: 0,
        src: r.src,
        alt: r.alt,
        srcset: r.srcSet,
        style: v(a(E)),
        onError: S
      }, null, 44, ["src", "alt", "srcset"])) : r.icon ? (o(), d(a(A), { key: 1 }, {
        default: b(() => [
          (o(), d(g(r.icon)))
        ]),
        _: 1
      })) : w(r.$slots, "default", { key: 2 })
    ], 6));
  }
});
var R = /* @__PURE__ */ j(V, [["__file", "avatar.vue"]]);
export {
  R as default
};
