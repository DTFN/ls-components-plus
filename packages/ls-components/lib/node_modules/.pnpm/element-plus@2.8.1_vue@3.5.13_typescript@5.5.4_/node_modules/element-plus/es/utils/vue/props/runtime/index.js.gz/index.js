var w = Object.defineProperty;
var a = (e, t) => w(e, "name", { value: t, configurable: !0 });
import { warn as y } from "vue";
import { isObject as u, hasOwn as d } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import O from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/fromPairs/index.js";
const p = "__epPropKey", S = /* @__PURE__ */ a((e) => e, "definePropType"), b = /* @__PURE__ */ a((e) => u(e) && !!e[p], "isEpProp"), g = /* @__PURE__ */ a((e, t) => {
  if (!u(e) || b(e))
    return e;
  const { values: o, required: c, default: f, type: m, validator: l } = e, s = {
    type: m,
    required: !!c,
    validator: o || l ? (n) => {
      let r = !1, i = [];
      if (o && (i = Array.from(o), d(e, "default") && i.push(f), r || (r = i.includes(n))), l && (r || (r = l(n))), !r && i.length > 0) {
        const P = [...new Set(i)].map((v) => JSON.stringify(v)).join(", ");
        y(`Invalid prop: validation failed${t ? ` for prop "${t}"` : ""}. Expected one of [${P}], got value ${JSON.stringify(n)}.`);
      }
      return r;
    } : void 0,
    [p]: !0
  };
  return d(e, "default") && (s.default = f), s;
}, "buildProp"), V = /* @__PURE__ */ a((e) => O(Object.entries(e).map(([t, o]) => [
  t,
  g(o, t)
])), "buildProps");
export {
  g as buildProp,
  V as buildProps,
  S as definePropType,
  p as epPropKey,
  b as isEpProp
};
