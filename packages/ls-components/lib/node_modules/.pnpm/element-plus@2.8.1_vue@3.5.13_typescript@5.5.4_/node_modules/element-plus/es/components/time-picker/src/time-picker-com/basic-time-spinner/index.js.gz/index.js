var ue = Object.defineProperty;
var t = (T, h) => ue(T, "name", { value: h, configurable: !0 });
import { defineComponent as me, ref as C, computed as D, unref as n, onMounted as de, nextTick as q, watch as pe, openBlock as l, createElementBlock as u, normalizeClass as d, Fragment as m, renderList as $, createBlock as E, withCtx as H, createTextVNode as _, toDisplayString as w, createCommentVNode as F, withDirectives as z, createVNode as G, createElementVNode as fe } from "vue";
import { ElScrollbar as he } from "../../../../scrollbar/index/index.js";
import { ElIcon as J } from "../../../../icon/index/index.js";
import { ArrowUp as be, ArrowDown as we } from "@element-plus/icons-vue";
import { timeUnits as K } from "../../constants/index.js";
import { buildTimeList as I } from "../../utils/index.js";
import { basicTimeSpinnerProps as ge } from "../../props/basic-time-spinner/index.js";
import { getTimeLists as ve } from "../../composables/use-time-picker/index.js";
import Se from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as Me } from "../../../../../hooks/use-namespace/index/index.js";
import { getStyle as ke } from "../../../../../utils/dom/style/index.js";
import { vRepeatClick as O } from "../../../../../directives/repeat-click/index/index.js";
import Ce from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/debounce/index.js";
const De = /* @__PURE__ */ me({
  __name: "basic-time-spinner",
  props: ge,
  emits: ["change", "select-range", "set-option"],
  setup(T, { emit: h }) {
    const i = T, a = Me("time"), { getHoursList: Q, getMinutesList: W, getSecondsList: X } = ve(i.disabledHours, i.disabledMinutes, i.disabledSeconds);
    let P = !1;
    const S = C(), Y = C(), Z = C(), y = C(), b = {
      hours: Y,
      minutes: Z,
      seconds: y
    }, B = D(() => i.showSeconds ? K : K.slice(0, 2)), p = D(() => {
      const { spinnerDate: e } = i, o = e.hour(), s = e.minute(), r = e.second();
      return { hours: o, minutes: s, seconds: r };
    }), M = D(() => {
      const { hours: e, minutes: o } = n(p);
      return {
        hours: Q(i.role),
        minutes: W(e, i.role),
        seconds: X(e, o, i.role)
      };
    }), ee = D(() => {
      const { hours: e, minutes: o, seconds: s } = n(p);
      return {
        hours: I(e, 23),
        minutes: I(o, 59),
        seconds: I(s, 59)
      };
    }), se = Ce((e) => {
      P = !1, g(e);
    }, 200), U = /* @__PURE__ */ t((e) => {
      if (!!!i.amPmMode)
        return "";
      const s = i.amPmMode === "A";
      let r = e < 12 ? " am" : " pm";
      return s && (r = r.toUpperCase()), r;
    }, "getAmPmFlag"), f = /* @__PURE__ */ t((e) => {
      let o;
      switch (e) {
        case "hours":
          o = [0, 2];
          break;
        case "minutes":
          o = [3, 5];
          break;
        case "seconds":
          o = [6, 8];
          break;
      }
      const [s, r] = o;
      h("select-range", s, r), S.value = e;
    }, "emitSelectRange"), g = /* @__PURE__ */ t((e) => {
      L(e, n(p)[e]);
    }, "adjustCurrentSpinner"), V = /* @__PURE__ */ t(() => {
      g("hours"), g("minutes"), g("seconds");
    }, "adjustSpinners"), R = /* @__PURE__ */ t((e) => e.querySelector(`.${a.namespace.value}-scrollbar__wrap`), "getScrollbarElement"), L = /* @__PURE__ */ t((e, o) => {
      if (i.arrowControl)
        return;
      const s = n(b[e]);
      s && s.$el && (R(s.$el).scrollTop = Math.max(0, o * N(e)));
    }, "adjustSpinner"), N = /* @__PURE__ */ t((e) => {
      const o = n(b[e]), s = o == null ? void 0 : o.$el.querySelector("li");
      return s && Number.parseFloat(ke(s, "height")) || 0;
    }, "typeItemHeight"), oe = /* @__PURE__ */ t(() => {
      x(1);
    }, "onIncrement"), ne = /* @__PURE__ */ t(() => {
      x(-1);
    }, "onDecrement"), x = /* @__PURE__ */ t((e) => {
      S.value || f("hours");
      const o = S.value, s = n(p)[o], r = S.value === "hours" ? 24 : 60, c = re(o, s, e, r);
      A(o, c), L(o, c), q(() => f(o));
    }, "scrollDown"), re = /* @__PURE__ */ t((e, o, s, r) => {
      let c = (o + s + r) % r;
      const v = n(M)[e];
      for (; v[c] && c !== o; )
        c = (c + s + r) % r;
      return c;
    }, "findNextUnDisabled"), A = /* @__PURE__ */ t((e, o) => {
      if (n(M)[e][o])
        return;
      const { hours: c, minutes: v, seconds: j } = n(p);
      let k;
      switch (e) {
        case "hours":
          k = i.spinnerDate.hour(o).minute(v).second(j);
          break;
        case "minutes":
          k = i.spinnerDate.hour(c).minute(o).second(j);
          break;
        case "seconds":
          k = i.spinnerDate.hour(c).minute(v).second(o);
          break;
      }
      h("change", k);
    }, "modifyDateField"), te = /* @__PURE__ */ t((e, { value: o, disabled: s }) => {
      s || (A(e, o), f(e), L(e, o));
    }, "handleClick"), ce = /* @__PURE__ */ t((e) => {
      P = !0, se(e);
      const o = Math.min(Math.round((R(n(b[e]).$el).scrollTop - (ie(e) * 0.5 - 10) / N(e) + 3) / N(e)), e === "hours" ? 23 : 59);
      A(e, o);
    }, "handleScroll"), ie = /* @__PURE__ */ t((e) => n(b[e]).$el.offsetHeight, "scrollBarHeight"), le = /* @__PURE__ */ t(() => {
      const e = /* @__PURE__ */ t((o) => {
        const s = n(b[o]);
        s && s.$el && (R(s.$el).onscroll = () => {
          ce(o);
        });
      }, "bindFunction");
      e("hours"), e("minutes"), e("seconds");
    }, "bindScrollEvent");
    de(() => {
      q(() => {
        !i.arrowControl && le(), V(), i.role === "start" && f("hours");
      });
    });
    const ae = /* @__PURE__ */ t((e, o) => {
      b[o].value = e;
    }, "setRef");
    return h("set-option", [`${i.role}_scrollDown`, x]), h("set-option", [`${i.role}_emitSelectRange`, f]), pe(() => i.spinnerDate, () => {
      P || V();
    }), (e, o) => (l(), u("div", {
      class: d([n(a).b("spinner"), { "has-seconds": e.showSeconds }])
    }, [
      e.arrowControl ? F("v-if", !0) : (l(!0), u(m, { key: 0 }, $(n(B), (s) => (l(), E(n(he), {
        key: s,
        ref_for: !0,
        ref: /* @__PURE__ */ t((r) => ae(r, s), "ref"),
        class: d(n(a).be("spinner", "wrapper")),
        "wrap-style": "max-height: inherit;",
        "view-class": n(a).be("spinner", "list"),
        noresize: "",
        tag: "ul",
        onMouseenter: /* @__PURE__ */ t((r) => f(s), "onMouseenter"),
        onMousemove: /* @__PURE__ */ t((r) => g(s), "onMousemove")
      }, {
        default: H(() => [
          (l(!0), u(m, null, $(n(M)[s], (r, c) => (l(), u("li", {
            key: c,
            class: d([
              n(a).be("spinner", "item"),
              n(a).is("active", c === n(p)[s]),
              n(a).is("disabled", r)
            ]),
            onClick: /* @__PURE__ */ t((v) => te(s, { value: c, disabled: r }), "onClick")
          }, [
            s === "hours" ? (l(), u(m, { key: 0 }, [
              _(w(("0" + (e.amPmMode ? c % 12 || 12 : c)).slice(-2)) + w(U(c)), 1)
            ], 64)) : (l(), u(m, { key: 1 }, [
              _(w(("0" + c).slice(-2)), 1)
            ], 64))
          ], 10, ["onClick"]))), 128))
        ]),
        _: 2
      }, 1032, ["class", "view-class", "onMouseenter", "onMousemove"]))), 128)),
      e.arrowControl ? (l(!0), u(m, { key: 1 }, $(n(B), (s) => (l(), u("div", {
        key: s,
        class: d([n(a).be("spinner", "wrapper"), n(a).is("arrow")]),
        onMouseenter: /* @__PURE__ */ t((r) => f(s), "onMouseenter")
      }, [
        z((l(), E(n(J), {
          class: d(["arrow-up", n(a).be("spinner", "arrow")])
        }, {
          default: H(() => [
            G(n(be))
          ]),
          _: 1
        }, 8, ["class"])), [
          [n(O), ne]
        ]),
        z((l(), E(n(J), {
          class: d(["arrow-down", n(a).be("spinner", "arrow")])
        }, {
          default: H(() => [
            G(n(we))
          ]),
          _: 1
        }, 8, ["class"])), [
          [n(O), oe]
        ]),
        fe("ul", {
          class: d(n(a).be("spinner", "list"))
        }, [
          (l(!0), u(m, null, $(n(ee)[s], (r, c) => (l(), u("li", {
            key: c,
            class: d([
              n(a).be("spinner", "item"),
              n(a).is("active", r === n(p)[s]),
              n(a).is("disabled", n(M)[s][r])
            ])
          }, [
            typeof r == "number" ? (l(), u(m, { key: 0 }, [
              s === "hours" ? (l(), u(m, { key: 0 }, [
                _(w(("0" + (e.amPmMode ? r % 12 || 12 : r)).slice(-2)) + w(U(r)), 1)
              ], 64)) : (l(), u(m, { key: 1 }, [
                _(w(("0" + r).slice(-2)), 1)
              ], 64))
            ], 64)) : F("v-if", !0)
          ], 2))), 128))
        ], 2)
      ], 42, ["onMouseenter"]))), 128)) : F("v-if", !0)
    ], 2));
  }
});
var Ue = /* @__PURE__ */ Se(De, [["__file", "basic-time-spinner.vue"]]);
export {
  Ue as default
};
