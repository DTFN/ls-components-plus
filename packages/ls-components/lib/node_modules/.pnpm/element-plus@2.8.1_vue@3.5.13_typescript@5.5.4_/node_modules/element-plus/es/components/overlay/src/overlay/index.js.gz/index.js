var p = Object.defineProperty;
var t = (e, o) => p(e, "name", { value: o, configurable: !0 });
import { defineComponent as v, createVNode as y, renderSlot as s, h as f } from "vue";
import { buildProps as x, definePropType as a } from "../../../../utils/vue/props/runtime/index.js";
import { useNamespace as k } from "../../../../hooks/use-namespace/index/index.js";
import { useSameTarget as C } from "../../../../hooks/use-same-target/index/index.js";
import { PatchFlags as n } from "../../../../utils/vue/vnode/index.js";
const M = x({
  mask: {
    type: Boolean,
    default: !0
  },
  customMaskEvent: Boolean,
  overlayClass: {
    type: a([
      String,
      Array,
      Object
    ])
  },
  zIndex: {
    type: a([String, Number])
  }
}), S = {
  click: /* @__PURE__ */ t((e) => e instanceof MouseEvent, "click")
}, E = "overlay";
var h = v({
  name: "ElOverlay",
  props: M,
  emits: S,
  setup(e, { slots: o, emit: r }) {
    const l = k(E), i = /* @__PURE__ */ t((d) => {
      r("click", d);
    }, "onMaskClick"), { onClick: c, onMousedown: m, onMouseup: u } = C(e.customMaskEvent ? void 0 : i);
    return () => e.mask ? y("div", {
      class: [l.b(), e.overlayClass],
      style: {
        zIndex: e.zIndex
      },
      onClick: c,
      onMousedown: m,
      onMouseup: u
    }, [s(o, "default")], n.STYLE | n.CLASS | n.PROPS, ["onClick", "onMouseup", "onMousedown"]) : f("div", {
      class: e.overlayClass,
      style: {
        zIndex: e.zIndex,
        position: "fixed",
        top: "0px",
        right: "0px",
        bottom: "0px",
        left: "0px"
      }
    }, [s(o, "default")]);
  }
});
export {
  h as default,
  S as overlayEmits,
  M as overlayProps
};
