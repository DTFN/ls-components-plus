var p = Object.defineProperty;
var o = (i, l) => p(i, "name", { value: l, configurable: !0 });
import { NOOP as t } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { ajaxUpload as u } from "../ajax/index.js";
import { buildProps as a, definePropType as e } from "../../../../utils/vue/props/runtime/index.js";
import { mutable as n } from "../../../../utils/typescript/index.js";
const r = ["text", "picture", "picture-card"];
let d = 1;
const g = /* @__PURE__ */ o(() => Date.now() + d++, "genFileId"), f = a({
  action: {
    type: String,
    default: "#"
  },
  headers: {
    type: e(Object)
  },
  method: {
    type: String,
    default: "post"
  },
  data: {
    type: e([Object, Function, Promise]),
    default: /* @__PURE__ */ o(() => n({}), "default")
  },
  multiple: Boolean,
  name: {
    type: String,
    default: "file"
  },
  drag: Boolean,
  withCredentials: Boolean,
  showFileList: {
    type: Boolean,
    default: !0
  },
  accept: {
    type: String,
    default: ""
  },
  fileList: {
    type: e(Array),
    default: /* @__PURE__ */ o(() => n([]), "default")
  },
  autoUpload: {
    type: Boolean,
    default: !0
  },
  listType: {
    type: String,
    values: r,
    default: "text"
  },
  httpRequest: {
    type: e(Function),
    default: u
  },
  disabled: Boolean,
  limit: Number
}), b = a({
  ...f,
  beforeUpload: {
    type: e(Function),
    default: t
  },
  beforeRemove: {
    type: e(Function)
  },
  onRemove: {
    type: e(Function),
    default: t
  },
  onChange: {
    type: e(Function),
    default: t
  },
  onPreview: {
    type: e(Function),
    default: t
  },
  onSuccess: {
    type: e(Function),
    default: t
  },
  onProgress: {
    type: e(Function),
    default: t
  },
  onError: {
    type: e(Function),
    default: t
  },
  onExceed: {
    type: e(Function),
    default: t
  },
  crossorigin: {
    type: e(String)
  }
});
export {
  g as genFileId,
  f as uploadBaseProps,
  r as uploadListTypes,
  b as uploadProps
};
