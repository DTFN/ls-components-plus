var se = Object.defineProperty;
var i = (A, P) => se(A, "name", { value: P, configurable: !0 });
import { defineComponent as ee, ref as ce, reactive as me, computed as N, watch as de, onMounted as pe, onUpdated as fe, openBlock as p, createElementBlock as x, normalizeClass as K, unref as t, withModifiers as T, withDirectives as q, withKeys as y, renderSlot as J, createVNode as z, withCtx as Q, createBlock as I, createCommentVNode as X } from "vue";
import { ElInput as be } from "../../../input/index/index.js";
import { ElIcon as Y } from "../../../icon/index/index.js";
import { ArrowDown as ve, Minus as Ve, ArrowUp as Ne, Plus as he } from "@element-plus/icons-vue";
import { inputNumberProps as we, inputNumberEmits as ge } from "../input-number/index.js";
import ye from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as Ie } from "../../../../hooks/use-locale/index/index.js";
import { useNamespace as Ee } from "../../../../hooks/use-namespace/index/index.js";
import { useFormItem as _e } from "../../../form/src/hooks/use-form-item/index.js";
import { isNumber as b, isUndefined as E } from "../../../../utils/types/index.js";
import { debugWarn as B, throwError as Ae } from "../../../../utils/error/index.js";
import { useFormSize as Pe, useFormDisabled as Se } from "../../../form/src/hooks/use-form-common-props/index.js";
import { UPDATE_MODEL_EVENT as _, INPUT_EVENT as U, CHANGE_EVENT as ke } from "../../../../constants/event/index.js";
import { isString as Ce } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { vRepeatClick as Z } from "../../../../directives/repeat-click/index/index.js";
import L from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
const De = ee({
  name: "ElInputNumber"
}), Fe = /* @__PURE__ */ ee({
  ...De,
  props: we,
  emits: ge,
  setup(A, { expose: P, emit: c }) {
    const l = A, { t: O } = Ie(), d = Ee("input-number"), v = ce(), u = me({
      currentValue: l.modelValue,
      userInput: null
    }), { formItem: f } = _e(), $ = N(() => b(l.modelValue) && l.modelValue <= l.min), R = N(() => b(l.modelValue) && l.modelValue >= l.max), ne = N(() => {
      const e = G(l.step);
      return E(l.precision) ? Math.max(G(l.modelValue), e) : (e > l.precision && B("InputNumber", "precision should not be less than the decimal places of step"), l.precision);
    }), S = N(() => l.controls && l.controlsPosition === "right"), W = Pe(), V = Se(), k = N(() => {
      if (u.userInput !== null)
        return u.userInput;
      let e = u.currentValue;
      if (L(e))
        return "";
      if (b(e)) {
        if (Number.isNaN(e))
          return "";
        E(l.precision) || (e = e.toFixed(l.precision));
      }
      return e;
    }), C = /* @__PURE__ */ i((e, n) => {
      if (E(n) && (n = ne.value), n === 0)
        return Math.round(e);
      let r = String(e);
      const a = r.indexOf(".");
      if (a === -1 || !r.replace(".", "").split("")[a + n])
        return e;
      const w = r.length;
      return r.charAt(w - 1) === "5" && (r = `${r.slice(0, Math.max(0, w - 1))}6`), Number.parseFloat(Number(r).toFixed(n));
    }, "toPrecision"), G = /* @__PURE__ */ i((e) => {
      if (L(e))
        return 0;
      const n = e.toString(), r = n.indexOf(".");
      let a = 0;
      return r !== -1 && (a = n.length - r - 1), a;
    }, "getPrecision"), H = /* @__PURE__ */ i((e, n = 1) => b(e) ? C(e + l.step * n) : u.currentValue, "ensurePrecision"), D = /* @__PURE__ */ i(() => {
      if (l.readonly || V.value || R.value)
        return;
      const e = Number(k.value) || 0, n = H(e);
      h(n), c(U, u.currentValue), M();
    }, "increase"), F = /* @__PURE__ */ i(() => {
      if (l.readonly || V.value || $.value)
        return;
      const e = Number(k.value) || 0, n = H(e, -1);
      h(n), c(U, u.currentValue), M();
    }, "decrease"), j = /* @__PURE__ */ i((e, n) => {
      const { max: r, min: a, step: o, precision: m, stepStrictly: w, valueOnClear: g } = l;
      r < a && Ae("InputNumber", "min should not be greater than max.");
      let s = Number(e);
      if (L(e) || Number.isNaN(s))
        return null;
      if (e === "") {
        if (g === null)
          return null;
        s = Ce(g) ? { min: a, max: r }[g] : g;
      }
      return w && (s = C(Math.round(s / o) * o, m)), E(m) || (s = C(s, m)), (s > r || s < a) && (s = s > r ? r : a, n && c(_, s)), s;
    }, "verifyValue"), h = /* @__PURE__ */ i((e, n = !0) => {
      var r;
      const a = u.currentValue, o = j(e);
      if (!n) {
        c(_, o);
        return;
      }
      a === o && e || (u.userInput = null, c(_, o), a !== o && c(ke, o, a), l.validateEvent && ((r = f == null ? void 0 : f.validate) == null || r.call(f, "change").catch((m) => B(m))), u.currentValue = o);
    }, "setCurrentValue"), re = /* @__PURE__ */ i((e) => {
      u.userInput = e;
      const n = e === "" ? null : Number(e);
      c(U, n), h(n, !1);
    }, "handleInput"), te = /* @__PURE__ */ i((e) => {
      const n = e !== "" ? Number(e) : "";
      (b(n) && !Number.isNaN(n) || e === "") && h(n), M(), u.userInput = null;
    }, "handleInputChange"), le = /* @__PURE__ */ i(() => {
      var e, n;
      (n = (e = v.value) == null ? void 0 : e.focus) == null || n.call(e);
    }, "focus"), ue = /* @__PURE__ */ i(() => {
      var e, n;
      (n = (e = v.value) == null ? void 0 : e.blur) == null || n.call(e);
    }, "blur"), oe = /* @__PURE__ */ i((e) => {
      c("focus", e);
    }, "handleFocus"), ae = /* @__PURE__ */ i((e) => {
      var n;
      u.userInput = null, c("blur", e), l.validateEvent && ((n = f == null ? void 0 : f.validate) == null || n.call(f, "blur").catch((r) => B(r)));
    }, "handleBlur"), M = /* @__PURE__ */ i(() => {
      u.currentValue !== l.modelValue && (u.currentValue = l.modelValue);
    }, "setCurrentValueToModelValue"), ie = /* @__PURE__ */ i((e) => {
      document.activeElement === e.target && e.preventDefault();
    }, "handleWheel");
    return de(() => l.modelValue, (e, n) => {
      const r = j(e, !0);
      u.userInput === null && r !== n && (u.currentValue = r);
    }, { immediate: !0 }), pe(() => {
      var e;
      const { min: n, max: r, modelValue: a } = l, o = (e = v.value) == null ? void 0 : e.input;
      if (o.setAttribute("role", "spinbutton"), Number.isFinite(r) ? o.setAttribute("aria-valuemax", String(r)) : o.removeAttribute("aria-valuemax"), Number.isFinite(n) ? o.setAttribute("aria-valuemin", String(n)) : o.removeAttribute("aria-valuemin"), o.setAttribute("aria-valuenow", u.currentValue || u.currentValue === 0 ? String(u.currentValue) : ""), o.setAttribute("aria-disabled", String(V.value)), !b(a) && a != null) {
        let m = Number(a);
        Number.isNaN(m) && (m = null), c(_, m);
      }
      o.addEventListener("wheel", ie, { passive: !1 });
    }), fe(() => {
      var e, n;
      const r = (e = v.value) == null ? void 0 : e.input;
      r == null || r.setAttribute("aria-valuenow", `${(n = u.currentValue) != null ? n : ""}`);
    }), P({
      focus: le,
      blur: ue
    }), (e, n) => (p(), x("div", {
      class: K([
        t(d).b(),
        t(d).m(t(W)),
        t(d).is("disabled", t(V)),
        t(d).is("without-controls", !e.controls),
        t(d).is("controls-right", t(S))
      ]),
      onDragstart: T(() => {
      }, ["prevent"])
    }, [
      e.controls ? q((p(), x("span", {
        key: 0,
        role: "button",
        "aria-label": t(O)("el.inputNumber.decrease"),
        class: K([t(d).e("decrease"), t(d).is("disabled", t($))]),
        onKeydown: y(F, ["enter"])
      }, [
        J(e.$slots, "decrease-icon", {}, () => [
          z(t(Y), null, {
            default: Q(() => [
              t(S) ? (p(), I(t(ve), { key: 0 })) : (p(), I(t(Ve), { key: 1 }))
            ]),
            _: 1
          })
        ])
      ], 42, ["aria-label", "onKeydown"])), [
        [t(Z), F]
      ]) : X("v-if", !0),
      e.controls ? q((p(), x("span", {
        key: 1,
        role: "button",
        "aria-label": t(O)("el.inputNumber.increase"),
        class: K([t(d).e("increase"), t(d).is("disabled", t(R))]),
        onKeydown: y(D, ["enter"])
      }, [
        J(e.$slots, "increase-icon", {}, () => [
          z(t(Y), null, {
            default: Q(() => [
              t(S) ? (p(), I(t(Ne), { key: 0 })) : (p(), I(t(he), { key: 1 }))
            ]),
            _: 1
          })
        ])
      ], 42, ["aria-label", "onKeydown"])), [
        [t(Z), D]
      ]) : X("v-if", !0),
      z(t(be), {
        id: e.id,
        ref_key: "input",
        ref: v,
        type: "number",
        step: e.step,
        "model-value": t(k),
        placeholder: e.placeholder,
        readonly: e.readonly,
        disabled: t(V),
        size: t(W),
        max: e.max,
        min: e.min,
        name: e.name,
        "aria-label": e.ariaLabel,
        "validate-event": !1,
        onKeydown: [
          y(T(D, ["prevent"]), ["up"]),
          y(T(F, ["prevent"]), ["down"])
        ],
        onBlur: ae,
        onFocus: oe,
        onInput: re,
        onChange: te
      }, null, 8, ["id", "step", "model-value", "placeholder", "readonly", "disabled", "size", "max", "min", "name", "aria-label", "onKeydown"])
    ], 42, ["onDragstart"]));
  }
});
var Qe = /* @__PURE__ */ ye(Fe, [["__file", "input-number.vue"]]);
export {
  Qe as default
};
