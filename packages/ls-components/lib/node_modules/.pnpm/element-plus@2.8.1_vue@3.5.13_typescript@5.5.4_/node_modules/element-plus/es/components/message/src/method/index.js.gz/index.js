var C = Object.defineProperty;
var t = (e, n) => C(e, "name", { value: n, configurable: !0 });
import { isVNode as v, render as f, createVNode as T } from "vue";
import b from "../message2/index.js";
import { messageTypes as y, messageDefaults as E } from "../message/index.js";
import { instances as l } from "../instance/index.js";
import { isString as g, isFunction as d } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isNumber as M, isElement as z } from "../../../../utils/types/index.js";
import { debugWarn as N } from "../../../../utils/error/index.js";
import { messageConfig as h } from "../../../config-provider/src/config-provider/index.js";
import { isClient as _ } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
let O = 1;
const x = /* @__PURE__ */ t((e) => {
  const n = !e || g(e) || v(e) || d(e) ? { message: e } : e, o = {
    ...E,
    ...n
  };
  if (!o.appendTo)
    o.appendTo = document.body;
  else if (g(o.appendTo)) {
    let s = document.querySelector(o.appendTo);
    z(s) || (N("ElMessage", "the appendTo option is not an HTMLElement. Falling back to document.body."), s = document.body), o.appendTo = s;
  }
  return o;
}, "normalizeOptions"), A = /* @__PURE__ */ t((e) => {
  const n = l.indexOf(e);
  if (n === -1)
    return;
  l.splice(n, 1);
  const { handler: o } = e;
  o.close();
}, "closeMessage"), D = /* @__PURE__ */ t(({ appendTo: e, ...n }, o) => {
  const s = `message_${O++}`, i = n.onClose, c = document.createElement("div"), r = {
    ...n,
    id: s,
    onClose: /* @__PURE__ */ t(() => {
      i == null || i(), A(u);
    }, "onClose"),
    onDestroy: /* @__PURE__ */ t(() => {
      f(null, c);
    }, "onDestroy")
  }, a = T(b, r, d(r.message) || v(r.message) ? {
    default: d(r.message) ? r.message : () => r.message
  } : null);
  a.appContext = o || p._context, f(a, c), e.appendChild(c.firstElementChild);
  const m = a.component, u = {
    id: s,
    vnode: a,
    vm: m,
    handler: {
      close: /* @__PURE__ */ t(() => {
        m.exposed.visible.value = !1;
      }, "close")
    },
    props: a.component.props
  };
  return u;
}, "createMessage"), p = /* @__PURE__ */ t((e = {}, n) => {
  if (!_)
    return { close: /* @__PURE__ */ t(() => {
    }, "close") };
  if (M(h.max) && l.length >= h.max)
    return { close: /* @__PURE__ */ t(() => {
    }, "close") };
  const o = x(e);
  if (o.grouping && l.length) {
    const i = l.find(({ vnode: c }) => {
      var r;
      return ((r = c.props) == null ? void 0 : r.message) === o.message;
    });
    if (i)
      return i.props.repeatNum += 1, i.props.type = o.type, i.handler;
  }
  const s = D(o, n);
  return l.push(s), s.handler;
}, "message");
y.forEach((e) => {
  p[e] = (n = {}, o) => {
    const s = x(n);
    return p({ ...s, type: e }, o);
  };
});
function F(e) {
  for (const n of l)
    (!e || e === n.props.type) && n.handler.close();
}
t(F, "closeAll");
p.closeAll = F;
p._context = null;
export {
  F as closeAll,
  p as default
};
