var W = Object.defineProperty;
var v = (r, n) => W(r, "name", { value: n, configurable: !0 });
import { defineComponent as b, inject as x, ref as a, openBlock as w, createElementBlock as S, Fragment as B, createVNode as y } from "vue";
import { GAP as l } from "../util/index.js";
import H from "../thumb2/index.js";
import { barProps as k } from "../bar/index.js";
import { scrollbarContextKey as C } from "../constants/index.js";
import E from "../../../../_virtual/plugin-vue_export-helper/index.js";
const M = /* @__PURE__ */ b({
  __name: "bar",
  props: k,
  setup(r, { expose: n }) {
    const h = r, p = x(C), d = a(0), g = a(0), z = a(""), _ = a(""), c = a(1), f = a(1);
    return n({
      handleScroll: /* @__PURE__ */ v((e) => {
        if (e) {
          const t = e.offsetHeight - l, o = e.offsetWidth - l;
          g.value = e.scrollTop * 100 / t * c.value, d.value = e.scrollLeft * 100 / o * f.value;
        }
      }, "handleScroll"),
      update: /* @__PURE__ */ v(() => {
        const e = p == null ? void 0 : p.wrapElement;
        if (!e)
          return;
        const t = e.offsetHeight - l, o = e.offsetWidth - l, m = t ** 2 / e.scrollHeight, u = o ** 2 / e.scrollWidth, s = Math.max(m, h.minSize), i = Math.max(u, h.minSize);
        c.value = m / (t - m) / (s / (t - s)), f.value = u / (o - u) / (i / (o - i)), _.value = s + l < t ? `${s}px` : "", z.value = i + l < o ? `${i}px` : "";
      }, "update")
    }), (e, t) => (w(), S(B, null, [
      y(H, {
        move: d.value,
        ratio: f.value,
        size: z.value,
        always: e.always
      }, null, 8, ["move", "ratio", "size", "always"]),
      y(H, {
        move: g.value,
        ratio: c.value,
        size: _.value,
        vertical: "",
        always: e.always
      }, null, 8, ["move", "ratio", "size", "always"])
    ], 64));
  }
});
var K = /* @__PURE__ */ E(M, [["__file", "bar.vue"]]);
export {
  K as default
};
