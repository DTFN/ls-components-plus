var x = Object.defineProperty;
var v = (m, r) => x(m, "name", { value: r, configurable: !0 });
import { defineComponent as F, computed as a, openBlock as i, createElementBlock as c, normalizeClass as l, unref as t, createElementVNode as h, normalizeStyle as d, renderSlot as D, toDisplayString as P, createCommentVNode as I, createBlock as T, withCtx as A, resolveDynamicComponent as O } from "vue";
import { ElIcon as R } from "../../../icon/index/index.js";
import { WarningFilled as U, CircleCheck as j, CircleClose as q, Check as G, Close as H } from "@element-plus/icons-vue";
import { progressProps as J } from "../progress/index.js";
import K from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as Q } from "../../../../hooks/use-namespace/index/index.js";
import { isFunction as X, isString as N } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
const Y = F({
  name: "ElProgress"
}), Z = /* @__PURE__ */ F({
  ...Y,
  props: J,
  setup(m) {
    const r = m, y = {
      success: "#13ce66",
      exception: "#ff4949",
      warning: "#e6a23c",
      default: "#20a0ff"
    }, s = Q("progress"), W = a(() => {
      const e = {
        width: `${r.percentage}%`,
        animationDuration: `${r.duration}s`
      }, o = S(r.percentage);
      return o.includes("gradient") ? e.background = o : e.backgroundColor = o, e;
    }), k = a(() => (r.strokeWidth / r.width * 100).toFixed(1)), b = a(() => ["circle", "dashboard"].includes(r.type) ? Number.parseInt(`${50 - Number.parseFloat(k.value) / 2}`, 10) : 0), $ = a(() => {
      const e = b.value, o = r.type === "dashboard";
      return `
          M 50 50
          m 0 ${o ? "" : "-"}${e}
          a ${e} ${e} 0 1 1 0 ${o ? "-" : ""}${e * 2}
          a ${e} ${e} 0 1 1 0 ${o ? "" : "-"}${e * 2}
          `;
    }), f = a(() => 2 * Math.PI * b.value), g = a(() => r.type === "dashboard" ? 0.75 : 1), w = a(() => `${-1 * f.value * (1 - g.value) / 2}px`), z = a(() => ({
      strokeDasharray: `${f.value * g.value}px, ${f.value}px`,
      strokeDashoffset: w.value
    })), B = a(() => ({
      strokeDasharray: `${f.value * g.value * (r.percentage / 100)}px, ${f.value}px`,
      strokeDashoffset: w.value,
      transition: "stroke-dasharray 0.6s ease 0s, stroke 0.6s ease, opacity ease 0.6s"
    })), E = a(() => {
      let e;
      return r.color ? e = S(r.percentage) : e = y[r.status] || y.default, e;
    }), L = a(() => r.status === "warning" ? U : r.type === "line" ? r.status === "success" ? j : q : r.status === "success" ? G : H), M = a(() => r.type === "line" ? 12 + r.strokeWidth * 0.4 : r.width * 0.111111 + 2), C = a(() => r.format(r.percentage));
    function V(e) {
      const o = 100 / e.length;
      return e.map((n, u) => N(n) ? {
        color: n,
        percentage: (u + 1) * o
      } : n).sort((n, u) => n.percentage - u.percentage);
    }
    v(V, "getColors");
    const S = /* @__PURE__ */ v((e) => {
      var o;
      const { color: p } = r;
      if (X(p))
        return p(e);
      if (N(p))
        return p;
      {
        const n = V(p);
        for (const u of n)
          if (u.percentage > e)
            return u.color;
        return (o = n[n.length - 1]) == null ? void 0 : o.color;
      }
    }, "getCurrentColor");
    return (e, o) => (i(), c("div", {
      class: l([
        t(s).b(),
        t(s).m(e.type),
        t(s).is(e.status),
        {
          [t(s).m("without-text")]: !e.showText,
          [t(s).m("text-inside")]: e.textInside
        }
      ]),
      role: "progressbar",
      "aria-valuenow": e.percentage,
      "aria-valuemin": "0",
      "aria-valuemax": "100"
    }, [
      e.type === "line" ? (i(), c("div", {
        key: 0,
        class: l(t(s).b("bar"))
      }, [
        h("div", {
          class: l(t(s).be("bar", "outer")),
          style: d({ height: `${e.strokeWidth}px` })
        }, [
          h("div", {
            class: l([
              t(s).be("bar", "inner"),
              { [t(s).bem("bar", "inner", "indeterminate")]: e.indeterminate },
              { [t(s).bem("bar", "inner", "striped")]: e.striped },
              { [t(s).bem("bar", "inner", "striped-flow")]: e.stripedFlow }
            ]),
            style: d(t(W))
          }, [
            (e.showText || e.$slots.default) && e.textInside ? (i(), c("div", {
              key: 0,
              class: l(t(s).be("bar", "innerText"))
            }, [
              D(e.$slots, "default", { percentage: e.percentage }, () => [
                h("span", null, P(t(C)), 1)
              ])
            ], 2)) : I("v-if", !0)
          ], 6)
        ], 6)
      ], 2)) : (i(), c("div", {
        key: 1,
        class: l(t(s).b("circle")),
        style: d({ height: `${e.width}px`, width: `${e.width}px` })
      }, [
        (i(), c("svg", { viewBox: "0 0 100 100" }, [
          h("path", {
            class: l(t(s).be("circle", "track")),
            d: t($),
            stroke: `var(${t(s).cssVarName("fill-color-light")}, #e5e9f2)`,
            "stroke-linecap": e.strokeLinecap,
            "stroke-width": t(k),
            fill: "none",
            style: d(t(z))
          }, null, 14, ["d", "stroke", "stroke-linecap", "stroke-width"]),
          h("path", {
            class: l(t(s).be("circle", "path")),
            d: t($),
            stroke: t(E),
            fill: "none",
            opacity: e.percentage ? 1 : 0,
            "stroke-linecap": e.strokeLinecap,
            "stroke-width": t(k),
            style: d(t(B))
          }, null, 14, ["d", "stroke", "opacity", "stroke-linecap", "stroke-width"])
        ]))
      ], 6)),
      (e.showText || e.$slots.default) && !e.textInside ? (i(), c("div", {
        key: 2,
        class: l(t(s).e("text")),
        style: d({ fontSize: `${t(M)}px` })
      }, [
        D(e.$slots, "default", { percentage: e.percentage }, () => [
          e.status ? (i(), T(t(R), { key: 1 }, {
            default: A(() => [
              (i(), T(O(t(L))))
            ]),
            _: 1
          })) : (i(), c("span", { key: 0 }, P(t(C)), 1))
        ])
      ], 6)) : I("v-if", !0)
    ], 10, ["aria-valuenow"]));
  }
});
var ie = /* @__PURE__ */ K(Z, [["__file", "progress.vue"]]);
export {
  ie as default
};
