var K = Object.defineProperty;
var m = (s, n) => K(s, "name", { value: n, configurable: !0 });
import { defineComponent as $, openBlock as t, createElementBlock as a, unref as e, normalizeClass as i, withModifiers as z, createElementVNode as f, toDisplayString as k, createCommentVNode as A, Fragment as u, renderList as c, createVNode as O } from "vue";
import { basicDateTableProps as U, basicDateTableEmits as j } from "../../props/basic-date-table/index.js";
import { useBasicDateTable as q, useBasicDateTableDOM as G } from "../../composables/use-basic-date-table/index.js";
import H from "../basic-cell-render/index.js";
import I from "../../../../../_virtual/plugin-vue_export-helper/index.js";
const J = /* @__PURE__ */ $({
  __name: "basic-date-table",
  props: U,
  emits: j,
  setup(s, { expose: n, emit: C }) {
    const d = s, {
      WEEKS: M,
      rows: _,
      tbodyRef: h,
      currentCellRef: v,
      focus: D,
      isCurrent: g,
      isWeekActive: w,
      isSelectedCell: b,
      handlePickDate: y,
      handleMouseUp: E,
      handleMouseDown: F,
      handleMouseMove: T,
      handleFocus: x
    } = q(d, C), { tableLabel: B, tableKls: N, weekLabel: R, getCellClasses: L, getRowKls: P, t: p } = G(d, {
      isCurrent: g,
      isWeekActive: w
    });
    return n({
      focus: D
    }), (S, Q) => (t(), a("table", {
      "aria-label": e(B),
      class: i(e(N)),
      cellspacing: "0",
      cellpadding: "0",
      role: "grid",
      onClick: e(y),
      onMousemove: e(T),
      onMousedown: z(e(F), ["prevent"]),
      onMouseup: e(E)
    }, [
      f("tbody", {
        ref_key: "tbodyRef",
        ref: h
      }, [
        f("tr", null, [
          S.showWeekNumber ? (t(), a("th", {
            key: 0,
            scope: "col"
          }, k(e(R)), 1)) : A("v-if", !0),
          (t(!0), a(u, null, c(e(M), (o, l) => (t(), a("th", {
            key: l,
            "aria-label": e(p)("el.datepicker.weeksFull." + o),
            scope: "col"
          }, k(e(p)("el.datepicker.weeks." + o)), 9, ["aria-label"]))), 128))
        ]),
        (t(!0), a(u, null, c(e(_), (o, l) => (t(), a("tr", {
          key: l,
          class: i(e(P)(o[1]))
        }, [
          (t(!0), a(u, null, c(o, (r, V) => (t(), a("td", {
            key: `${l}.${V}`,
            ref_for: !0,
            ref: /* @__PURE__ */ m((W) => e(b)(r) && (v.value = W), "ref"),
            class: i(e(L)(r)),
            "aria-current": r.isCurrent ? "date" : void 0,
            "aria-selected": r.isCurrent,
            tabindex: e(b)(r) ? 0 : -1,
            onFocus: e(x)
          }, [
            O(e(H), { cell: r }, null, 8, ["cell"])
          ], 42, ["aria-current", "aria-selected", "tabindex", "onFocus"]))), 128))
        ], 2))), 128))
      ], 512)
    ], 42, ["aria-label", "onClick", "onMousemove", "onMousedown", "onMouseup"]));
  }
});
var re = /* @__PURE__ */ I(J, [["__file", "basic-date-table.vue"]]);
export {
  re as default
};
