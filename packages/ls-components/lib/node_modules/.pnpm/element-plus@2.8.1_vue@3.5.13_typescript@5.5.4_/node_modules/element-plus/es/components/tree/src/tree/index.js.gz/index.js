var J = Object.defineProperty;
var o = (e, d) => J(e, "name", { value: d, configurable: !0 });
import { defineComponent as Q, inject as W, ref as i, computed as X, watch as u, provide as v, getCurrentInstance as Y, resolveComponent as Z, openBlock as y, createElementBlock as p, normalizeClass as h, Fragment as _, renderList as ee, createBlock as te, renderSlot as ne, createElementVNode as E, toDisplayString as re, createCommentVNode as oe, withDirectives as de, vShow as ae } from "vue";
import { selectKey as le } from "../../../select/src/token/index.js";
import se from "../model/tree-store/index.js";
import { getNodeKey as ce, handleCurrentChange as w } from "../model/util/index.js";
import ie from "../tree-node/index.js";
import { useNodeExpandEventBroadcast as ue } from "../model/useNodeExpandEventBroadcast/index.js";
import { useDragNodeHandler as ye } from "../model/useDragNode/index.js";
import { useKeydown as he } from "../model/useKeydown/index.js";
import fe from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { iconPropType as me } from "../../../../utils/vue/icon/index.js";
import { useLocale as ge } from "../../../../hooks/use-locale/index/index.js";
import { useNamespace as pe } from "../../../../hooks/use-namespace/index/index.js";
import { formItemContextKey as Ke } from "../../../form/src/constants/index.js";
const Ne = Q({
  name: "ElTree",
  components: { ElTreeNode: ie },
  props: {
    data: {
      type: Array,
      default: /* @__PURE__ */ o(() => [], "default")
    },
    emptyText: {
      type: String
    },
    renderAfterExpand: {
      type: Boolean,
      default: !0
    },
    nodeKey: String,
    checkStrictly: Boolean,
    defaultExpandAll: Boolean,
    expandOnClickNode: {
      type: Boolean,
      default: !0
    },
    checkOnClickNode: Boolean,
    checkDescendants: {
      type: Boolean,
      default: !1
    },
    autoExpandParent: {
      type: Boolean,
      default: !0
    },
    defaultCheckedKeys: Array,
    defaultExpandedKeys: Array,
    currentNodeKey: [String, Number],
    renderContent: Function,
    showCheckbox: {
      type: Boolean,
      default: !1
    },
    draggable: {
      type: Boolean,
      default: !1
    },
    allowDrag: Function,
    allowDrop: Function,
    props: {
      type: Object,
      default: /* @__PURE__ */ o(() => ({
        children: "children",
        label: "label",
        disabled: "disabled"
      }), "default")
    },
    lazy: {
      type: Boolean,
      default: !1
    },
    highlightCurrent: Boolean,
    load: Function,
    filterNodeMethod: Function,
    accordion: Boolean,
    indent: {
      type: Number,
      default: 18
    },
    icon: {
      type: me
    }
  },
  emits: [
    "check-change",
    "current-change",
    "node-click",
    "node-contextmenu",
    "node-collapse",
    "node-expand",
    "check",
    "node-drag-start",
    "node-drag-end",
    "node-drop",
    "node-drag-leave",
    "node-drag-enter",
    "node-drag-over"
  ],
  setup(e, d) {
    const { t: K } = ge(), N = pe("tree"), f = W(le, null), n = i(new se({
      key: e.nodeKey,
      data: e.data,
      lazy: e.lazy,
      props: e.props,
      load: e.load,
      currentNodeKey: e.currentNodeKey,
      checkStrictly: e.checkStrictly,
      checkDescendants: e.checkDescendants,
      defaultCheckedKeys: e.defaultCheckedKeys,
      defaultExpandedKeys: e.defaultExpandedKeys,
      autoExpandParent: e.autoExpandParent,
      defaultExpandAll: e.defaultExpandAll,
      filterNodeMethod: e.filterNodeMethod
    }));
    n.value.initialize();
    const s = i(n.value.root), a = i(null), m = i(null), C = i(null), { broadcastExpanded: g } = ue(e), { dragState: B } = ye({
      props: e,
      ctx: d,
      el$: m,
      dropIndicator$: C,
      store: n
    });
    he({ el$: m }, n);
    const T = X(() => {
      const { childNodes: t } = s.value, r = f ? f.hasFilteredOptions !== 0 : !1;
      return (!t || t.length === 0 || t.every(({ visible: l }) => !l)) && !r;
    });
    u(() => e.currentNodeKey, (t) => {
      n.value.setCurrentNodeKey(t);
    }), u(() => e.defaultCheckedKeys, (t) => {
      n.value.setDefaultCheckedKey(t);
    }), u(() => e.defaultExpandedKeys, (t) => {
      n.value.setDefaultExpandedKeys(t);
    }), u(() => e.data, (t) => {
      n.value.setData(t);
    }, { deep: !0 }), u(() => e.checkStrictly, (t) => {
      n.value.checkStrictly = t;
    });
    const S = /* @__PURE__ */ o((t) => {
      if (!e.filterNodeMethod)
        throw new Error("[Tree] filterNodeMethod is required when filter");
      n.value.filter(t);
    }, "filter"), b = /* @__PURE__ */ o((t) => ce(e.nodeKey, t.data), "getNodeKey$1"), D = /* @__PURE__ */ o((t) => {
      if (!e.nodeKey)
        throw new Error("[Tree] nodeKey is required in getNodePath");
      const r = n.value.getNode(t);
      if (!r)
        return [];
      const l = [r.data];
      let c = r.parent;
      for (; c && c !== s.value; )
        l.push(c.data), c = c.parent;
      return l.reverse();
    }, "getNodePath"), A = /* @__PURE__ */ o((t, r) => n.value.getCheckedNodes(t, r), "getCheckedNodes"), $ = /* @__PURE__ */ o((t) => n.value.getCheckedKeys(t), "getCheckedKeys"), k = /* @__PURE__ */ o(() => {
      const t = n.value.getCurrentNode();
      return t ? t.data : null;
    }, "getCurrentNode"), q = /* @__PURE__ */ o(() => {
      if (!e.nodeKey)
        throw new Error("[Tree] nodeKey is required in getCurrentKey");
      const t = k();
      return t ? t[e.nodeKey] : null;
    }, "getCurrentKey"), x = /* @__PURE__ */ o((t, r) => {
      if (!e.nodeKey)
        throw new Error("[Tree] nodeKey is required in setCheckedNodes");
      n.value.setCheckedNodes(t, r);
    }, "setCheckedNodes"), F = /* @__PURE__ */ o((t, r) => {
      if (!e.nodeKey)
        throw new Error("[Tree] nodeKey is required in setCheckedKeys");
      n.value.setCheckedKeys(t, r);
    }, "setCheckedKeys"), I = /* @__PURE__ */ o((t, r, l) => {
      n.value.setChecked(t, r, l);
    }, "setChecked"), P = /* @__PURE__ */ o(() => n.value.getHalfCheckedNodes(), "getHalfCheckedNodes"), z = /* @__PURE__ */ o(() => n.value.getHalfCheckedKeys(), "getHalfCheckedKeys"), H = /* @__PURE__ */ o((t, r = !0) => {
      if (!e.nodeKey)
        throw new Error("[Tree] nodeKey is required in setCurrentNode");
      w(n, d.emit, () => {
        g(t), n.value.setUserCurrentNode(t, r);
      });
    }, "setCurrentNode"), M = /* @__PURE__ */ o((t, r = !0) => {
      if (!e.nodeKey)
        throw new Error("[Tree] nodeKey is required in setCurrentKey");
      w(n, d.emit, () => {
        g(), n.value.setCurrentNodeKey(t, r);
      });
    }, "setCurrentKey"), O = /* @__PURE__ */ o((t) => n.value.getNode(t), "getNode"), j = /* @__PURE__ */ o((t) => {
      n.value.remove(t);
    }, "remove"), L = /* @__PURE__ */ o((t, r) => {
      n.value.append(t, r);
    }, "append"), V = /* @__PURE__ */ o((t, r) => {
      n.value.insertBefore(t, r);
    }, "insertBefore"), R = /* @__PURE__ */ o((t, r) => {
      n.value.insertAfter(t, r);
    }, "insertAfter"), U = /* @__PURE__ */ o((t, r, l) => {
      g(r), d.emit("node-expand", t, r, l);
    }, "handleNodeExpand"), G = /* @__PURE__ */ o((t, r) => {
      if (!e.nodeKey)
        throw new Error("[Tree] nodeKey is required in updateKeyChild");
      n.value.updateChildren(t, r);
    }, "updateKeyChildren");
    return v("RootTree", {
      ctx: d,
      props: e,
      store: n,
      root: s,
      currentNode: a,
      instance: Y()
    }), v(Ke, void 0), {
      ns: N,
      store: n,
      root: s,
      currentNode: a,
      dragState: B,
      el$: m,
      dropIndicator$: C,
      isEmpty: T,
      filter: S,
      getNodeKey: b,
      getNodePath: D,
      getCheckedNodes: A,
      getCheckedKeys: $,
      getCurrentNode: k,
      getCurrentKey: q,
      setCheckedNodes: x,
      setCheckedKeys: F,
      setChecked: I,
      getHalfCheckedNodes: P,
      getHalfCheckedKeys: z,
      setCurrentNode: H,
      setCurrentKey: M,
      t: K,
      getNode: O,
      remove: j,
      append: L,
      insertBefore: V,
      insertAfter: R,
      handleNodeExpand: U,
      updateKeyChildren: G
    };
  }
});
function Ce(e, d, K, N, f, n) {
  const s = Z("el-tree-node");
  return y(), p("div", {
    ref: "el$",
    class: h([
      e.ns.b(),
      e.ns.is("dragging", !!e.dragState.draggingNode),
      e.ns.is("drop-not-allow", !e.dragState.allowDrop),
      e.ns.is("drop-inner", e.dragState.dropType === "inner"),
      { [e.ns.m("highlight-current")]: e.highlightCurrent }
    ]),
    role: "tree"
  }, [
    (y(!0), p(_, null, ee(e.root.childNodes, (a) => (y(), te(s, {
      key: e.getNodeKey(a),
      node: a,
      props: e.props,
      accordion: e.accordion,
      "render-after-expand": e.renderAfterExpand,
      "show-checkbox": e.showCheckbox,
      "render-content": e.renderContent,
      onNodeExpand: e.handleNodeExpand
    }, null, 8, ["node", "props", "accordion", "render-after-expand", "show-checkbox", "render-content", "onNodeExpand"]))), 128)),
    e.isEmpty ? (y(), p("div", {
      key: 0,
      class: h(e.ns.e("empty-block"))
    }, [
      ne(e.$slots, "empty", {}, () => {
        var a;
        return [
          E("span", {
            class: h(e.ns.e("empty-text"))
          }, re((a = e.emptyText) != null ? a : e.t("el.tree.emptyText")), 3)
        ];
      })
    ], 2)) : oe("v-if", !0),
    de(E("div", {
      ref: "dropIndicator$",
      class: h(e.ns.e("drop-indicator"))
    }, null, 2), [
      [ae, e.dragState.showDropIndicator]
    ])
  ], 2);
}
o(Ce, "_sfc_render");
var Ie = /* @__PURE__ */ fe(Ne, [["render", Ce], ["__file", "tree.vue"]]);
export {
  Ie as default
};
