var N = Object.defineProperty;
var c = (b, g) => N(b, "name", { value: g, configurable: !0 });
import { defineComponent as L, ref as K, computed as P, openBlock as a, createBlock as v, TransitionGroup as _, normalizeClass as t, unref as e, withCtx as p, createElementBlock as m, Fragment as z, renderList as I, withKeys as S, renderSlot as w, createCommentVNode as o, createElementVNode as k, withModifiers as U, createVNode as r, toDisplayString as $, normalizeStyle as V } from "vue";
import { ElIcon as d } from "../../../icon/index/index.js";
import { Document as O, CircleCheck as G, Check as M, Close as R, ZoomIn as Z, Delete as j } from "@element-plus/icons-vue";
import { ElProgress as q } from "../../../progress/index/index.js";
import { uploadListProps as A, uploadListEmits as H } from "../upload-list/index.js";
import J from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as Q } from "../../../../hooks/use-locale/index/index.js";
import { useNamespace as C } from "../../../../hooks/use-namespace/index/index.js";
import { useFormDisabled as W } from "../../../form/src/hooks/use-form-common-props/index.js";
const X = L({
  name: "ElUploadList"
}), Y = /* @__PURE__ */ L({
  ...X,
  props: A,
  emits: H,
  setup(b, { emit: g }) {
    const T = b, { t: D } = Q(), i = C("upload"), n = C("icon"), E = C("list"), y = W(), f = K(!1), B = P(() => [
      i.b("list"),
      i.bm("list", T.listType),
      i.is("disabled", T.disabled)
    ]), h = /* @__PURE__ */ c((s) => {
      g("remove", s);
    }, "handleRemove");
    return (s, x) => (a(), v(_, {
      tag: "ul",
      class: t(e(B)),
      name: e(E).b()
    }, {
      default: p(() => [
        (a(!0), m(z, null, I(s.files, (l, F) => (a(), m("li", {
          key: l.uid || l.name,
          class: t([
            e(i).be("list", "item"),
            e(i).is(l.status),
            { focusing: f.value }
          ]),
          tabindex: "0",
          onKeydown: S((u) => !e(y) && h(l), ["delete"]),
          onFocus: /* @__PURE__ */ c((u) => f.value = !0, "onFocus"),
          onBlur: /* @__PURE__ */ c((u) => f.value = !1, "onBlur"),
          onClick: /* @__PURE__ */ c((u) => f.value = !1, "onClick")
        }, [
          w(s.$slots, "default", {
            file: l,
            index: F
          }, () => [
            s.listType === "picture" || l.status !== "uploading" && s.listType === "picture-card" ? (a(), m("img", {
              key: 0,
              class: t(e(i).be("list", "item-thumbnail")),
              src: l.url,
              crossorigin: s.crossorigin,
              alt: ""
            }, null, 10, ["src", "crossorigin"])) : o("v-if", !0),
            l.status === "uploading" || s.listType !== "picture-card" ? (a(), m("div", {
              key: 1,
              class: t(e(i).be("list", "item-info"))
            }, [
              k("a", {
                class: t(e(i).be("list", "item-name")),
                onClick: U((u) => s.handlePreview(l), ["prevent"])
              }, [
                r(e(d), {
                  class: t(e(n).m("document"))
                }, {
                  default: p(() => [
                    r(e(O))
                  ]),
                  _: 1
                }, 8, ["class"]),
                k("span", {
                  class: t(e(i).be("list", "item-file-name")),
                  title: l.name
                }, $(l.name), 11, ["title"])
              ], 10, ["onClick"]),
              l.status === "uploading" ? (a(), v(e(q), {
                key: 0,
                type: s.listType === "picture-card" ? "circle" : "line",
                "stroke-width": s.listType === "picture-card" ? 6 : 2,
                percentage: Number(l.percentage),
                style: V(s.listType === "picture-card" ? "" : "margin-top: 0.5rem")
              }, null, 8, ["type", "stroke-width", "percentage", "style"])) : o("v-if", !0)
            ], 2)) : o("v-if", !0),
            k("label", {
              class: t(e(i).be("list", "item-status-label"))
            }, [
              s.listType === "text" ? (a(), v(e(d), {
                key: 0,
                class: t([e(n).m("upload-success"), e(n).m("circle-check")])
              }, {
                default: p(() => [
                  r(e(G))
                ]),
                _: 1
              }, 8, ["class"])) : ["picture-card", "picture"].includes(s.listType) ? (a(), v(e(d), {
                key: 1,
                class: t([e(n).m("upload-success"), e(n).m("check")])
              }, {
                default: p(() => [
                  r(e(M))
                ]),
                _: 1
              }, 8, ["class"])) : o("v-if", !0)
            ], 2),
            e(y) ? o("v-if", !0) : (a(), v(e(d), {
              key: 2,
              class: t(e(n).m("close")),
              onClick: /* @__PURE__ */ c((u) => h(l), "onClick")
            }, {
              default: p(() => [
                r(e(R))
              ]),
              _: 2
            }, 1032, ["class", "onClick"])),
            o(" Due to close btn only appears when li gets focused disappears after li gets blurred, thus keyboard navigation can never reach close btn"),
            o(" This is a bug which needs to be fixed "),
            o(" TODO: Fix the incorrect navigation interaction "),
            e(y) ? o("v-if", !0) : (a(), m("i", {
              key: 3,
              class: t(e(n).m("close-tip"))
            }, $(e(D)("el.upload.deleteTip")), 3)),
            s.listType === "picture-card" ? (a(), m("span", {
              key: 4,
              class: t(e(i).be("list", "item-actions"))
            }, [
              k("span", {
                class: t(e(i).be("list", "item-preview")),
                onClick: /* @__PURE__ */ c((u) => s.handlePreview(l), "onClick")
              }, [
                r(e(d), {
                  class: t(e(n).m("zoom-in"))
                }, {
                  default: p(() => [
                    r(e(Z))
                  ]),
                  _: 1
                }, 8, ["class"])
              ], 10, ["onClick"]),
              e(y) ? o("v-if", !0) : (a(), m("span", {
                key: 0,
                class: t(e(i).be("list", "item-delete")),
                onClick: /* @__PURE__ */ c((u) => h(l), "onClick")
              }, [
                r(e(d), {
                  class: t(e(n).m("delete"))
                }, {
                  default: p(() => [
                    r(e(j))
                  ]),
                  _: 1
                }, 8, ["class"])
              ], 10, ["onClick"]))
            ], 2)) : o("v-if", !0)
          ])
        ], 42, ["onKeydown", "onFocus", "onBlur", "onClick"]))), 128)),
        w(s.$slots, "append")
      ]),
      _: 3
    }, 8, ["class", "name"]));
  }
});
var ue = /* @__PURE__ */ J(Y, [["__file", "upload-list.vue"]]);
export {
  ue as default
};
