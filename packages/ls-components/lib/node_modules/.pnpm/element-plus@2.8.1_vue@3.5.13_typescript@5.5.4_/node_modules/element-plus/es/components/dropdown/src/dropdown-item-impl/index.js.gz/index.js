var R = Object.defineProperty;
var n = (e, t) => R(e, "name", { value: t, configurable: !0 });
import { defineComponent as b, inject as i, computed as k, resolveComponent as K, openBlock as m, createElementBlock as I, Fragment as h, mergeProps as u, createCommentVNode as f, createElementVNode as M, withModifiers as $, createBlock as E, withCtx as L, resolveDynamicComponent as P, renderSlot as y } from "vue";
import { ElIcon as D } from "../../../icon/index/index.js";
import { dropdownItemProps as F, DROPDOWN_COLLECTION_ITEM_INJECTION_KEY as g } from "../dropdown/index.js";
import { DROPDOWN_INJECTION_KEY as J } from "../tokens/index.js";
import Y from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as G } from "../../../../hooks/use-namespace/index/index.js";
import { ROVING_FOCUS_ITEM_COLLECTION_INJECTION_KEY as V } from "../../../roving-focus-group/src/roving-focus-group/index.js";
import { ROVING_FOCUS_GROUP_ITEM_INJECTION_KEY as S } from "../../../roving-focus-group/src/tokens/index.js";
import { composeRefs as B } from "../../../../utils/vue/refs/index.js";
import { composeEventHandlers as U } from "../../../../utils/dom/event/index.js";
import { EVENT_CODE as C } from "../../../../constants/aria/index.js";
import { COLLECTION_ITEM_SIGN as W } from "../../../collection/src/collection/index.js";
const j = b({
  name: "DropdownItemImpl",
  components: {
    ElIcon: D
  },
  props: F,
  emits: ["pointermove", "pointerleave", "click", "clickimpl"],
  setup(e, { emit: t }) {
    const d = G("dropdown"), { role: l } = i(J, void 0), { collectionItemRef: a } = i(g, void 0), { collectionItemRef: p } = i(V, void 0), {
      rovingFocusGroupItemRef: s,
      tabIndex: o,
      handleFocus: v,
      handleKeydown: N,
      handleMousedown: O
    } = i(S, void 0), _ = B(a, p, s), w = k(() => l.value === "menu" ? "menuitem" : l.value === "navigation" ? "link" : "button"), T = U((r) => {
      const { code: c } = r;
      if (c === C.enter || c === C.space)
        return r.preventDefault(), r.stopImmediatePropagation(), t("clickimpl", r), !0;
    }, N);
    return {
      ns: d,
      itemRef: _,
      dataset: {
        [W]: ""
      },
      role: w,
      tabIndex: o,
      handleFocus: v,
      handleKeydown: T,
      handleMousedown: O
    };
  }
});
function H(e, t, d, l, a, p) {
  const s = K("el-icon");
  return m(), I(h, null, [
    e.divided ? (m(), I("li", u({
      key: 0,
      role: "separator",
      class: e.ns.bem("menu", "item", "divided")
    }, e.$attrs), null, 16)) : f("v-if", !0),
    M("li", u({ ref: e.itemRef }, { ...e.dataset, ...e.$attrs }, {
      "aria-disabled": e.disabled,
      class: [e.ns.be("menu", "item"), e.ns.is("disabled", e.disabled)],
      tabindex: e.tabIndex,
      role: e.role,
      onClick: /* @__PURE__ */ n((o) => e.$emit("clickimpl", o), "onClick"),
      onFocus: e.handleFocus,
      onKeydown: $(e.handleKeydown, ["self"]),
      onMousedown: e.handleMousedown,
      onPointermove: /* @__PURE__ */ n((o) => e.$emit("pointermove", o), "onPointermove"),
      onPointerleave: /* @__PURE__ */ n((o) => e.$emit("pointerleave", o), "onPointerleave")
    }), [
      e.icon ? (m(), E(s, { key: 0 }, {
        default: L(() => [
          (m(), E(P(e.icon)))
        ]),
        _: 1
      })) : f("v-if", !0),
      y(e.$slots, "default")
    ], 16, ["aria-disabled", "tabindex", "role", "onClick", "onFocus", "onKeydown", "onMousedown", "onPointermove", "onPointerleave"])
  ], 64);
}
n(H, "_sfc_render");
var me = /* @__PURE__ */ Y(j, [["render", H], ["__file", "dropdown-item-impl.vue"]]);
export {
  me as default
};
