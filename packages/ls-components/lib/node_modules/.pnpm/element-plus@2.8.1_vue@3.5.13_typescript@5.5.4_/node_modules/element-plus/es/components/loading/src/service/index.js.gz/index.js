var b = Object.defineProperty;
var d = (t, e) => b(t, "name", { value: e, configurable: !0 });
import { nextTick as f } from "vue";
import { createLoadingComponent as v } from "../loading/index.js";
import { isString as g } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { getStyle as s, addClass as u, removeClass as c } from "../../../../utils/dom/style/index.js";
import { isClient as y } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
let a;
const L = /* @__PURE__ */ d(function(t = {}) {
  if (!y)
    return;
  const e = p(t);
  if (e.fullscreen && a)
    return a;
  const l = v({
    ...e,
    closed: /* @__PURE__ */ d(() => {
      var n;
      (n = e.closed) == null || n.call(e), e.fullscreen && (a = void 0);
    }, "closed")
  });
  x(e, e.parent, l), m(e, e.parent, l), e.parent.vLoadingAddClassList = () => m(e, e.parent, l);
  let r = e.parent.getAttribute("loading-number");
  return r ? r = `${Number.parseInt(r) + 1}` : r = "1", e.parent.setAttribute("loading-number", r), e.parent.appendChild(l.$el), f(() => l.visible.value = e.visible), e.fullscreen && (a = l), l;
}, "Loading"), p = /* @__PURE__ */ d((t) => {
  var e, l, r, n;
  let o;
  return g(t.target) ? o = (e = document.querySelector(t.target)) != null ? e : document.body : o = t.target || document.body, {
    parent: o === document.body || t.body ? document.body : o,
    background: t.background || "",
    svg: t.svg || "",
    svgViewBox: t.svgViewBox || "",
    spinner: t.spinner || !1,
    text: t.text || "",
    fullscreen: o === document.body && ((l = t.fullscreen) != null ? l : !0),
    lock: (r = t.lock) != null ? r : !1,
    customClass: t.customClass || "",
    visible: (n = t.visible) != null ? n : !0,
    beforeClose: t.beforeClose,
    closed: t.closed,
    target: o
  };
}, "resolveOptions"), x = /* @__PURE__ */ d(async (t, e, l) => {
  const { nextZIndex: r } = l.vm.zIndex || l.vm._.exposed.zIndex, n = {};
  if (t.fullscreen)
    l.originalPosition.value = s(document.body, "position"), l.originalOverflow.value = s(document.body, "overflow"), n.zIndex = r();
  else if (t.parent === document.body) {
    l.originalPosition.value = s(document.body, "position"), await f();
    for (const o of ["top", "left"]) {
      const i = o === "top" ? "scrollTop" : "scrollLeft";
      n[o] = `${t.target.getBoundingClientRect()[o] + document.body[i] + document.documentElement[i] - Number.parseInt(s(document.body, `margin-${o}`), 10)}px`;
    }
    for (const o of ["height", "width"])
      n[o] = `${t.target.getBoundingClientRect()[o]}px`;
  } else
    l.originalPosition.value = s(e, "position");
  for (const [o, i] of Object.entries(n))
    l.$el.style[o] = i;
}, "addStyle"), m = /* @__PURE__ */ d((t, e, l) => {
  const r = l.vm.ns || l.vm._.exposed.ns;
  ["absolute", "fixed", "sticky"].includes(l.originalPosition.value) ? c(e, r.bm("parent", "relative")) : u(e, r.bm("parent", "relative")), t.fullscreen && t.lock ? u(e, r.bm("parent", "hidden")) : c(e, r.bm("parent", "hidden"));
}, "addClassList");
export {
  L as Loading
};
