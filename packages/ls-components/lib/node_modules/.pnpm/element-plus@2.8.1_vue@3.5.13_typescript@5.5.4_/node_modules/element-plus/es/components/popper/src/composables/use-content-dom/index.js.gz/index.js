var l = Object.defineProperty;
var d = (e, o) => l(e, "name", { value: o, configurable: !0 });
import { computed as t, unref as n, ref as z } from "vue";
import { useZIndex as Z } from "../../../../../hooks/use-z-index/index/index.js";
import { useNamespace as v } from "../../../../../hooks/use-namespace/index/index.js";
import { isNumber as p } from "../../../../../utils/types/index.js";
const N = /* @__PURE__ */ d((e, {
  attributes: o,
  styles: a,
  role: u
}) => {
  const { nextZIndex: s } = Z(), r = v("popper"), x = t(() => n(o).popper), c = z(p(e.zIndex) ? e.zIndex : s()), m = t(() => [
    r.b(),
    r.is("pure", e.pure),
    r.is(e.effect),
    e.popperClass
  ]), i = t(() => [
    { zIndex: n(c) },
    n(a).popper,
    e.popperStyle || {}
  ]), I = t(() => u.value === "dialog" ? "false" : void 0), f = t(() => n(a).arrow || {});
  return {
    ariaModal: I,
    arrowStyle: f,
    contentAttrs: x,
    contentClass: m,
    contentStyle: i,
    contentZIndex: c,
    updateZIndex: /* @__PURE__ */ d(() => {
      c.value = p(e.zIndex) ? e.zIndex : s();
    }, "updateZIndex")
  };
}, "usePopperContentDOM");
export {
  N as usePopperContentDOM
};
