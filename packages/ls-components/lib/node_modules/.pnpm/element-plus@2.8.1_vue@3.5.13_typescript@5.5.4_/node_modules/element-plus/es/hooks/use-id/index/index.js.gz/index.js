var i = Object.defineProperty;
var n = (r, e) => i(r, "name", { value: e, configurable: !0 });
import { computed as c, unref as s, getCurrentInstance as u, inject as d } from "vue";
import { useGetDerivedNamespace as p } from "../../use-namespace/index/index.js";
import { debugWarn as I } from "../../../utils/error/index.js";
import { isClient as a } from "../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const o = {
  prefix: Math.floor(Math.random() * 1e4),
  current: 0
}, m = Symbol("elIdInjection"), f = /* @__PURE__ */ n(() => u() ? d(m, o) : o, "useIdInjection"), h = /* @__PURE__ */ n((r) => {
  const e = f();
  !a && e === o && I("IdInjection", `Looks like you are using server rendering, you must provide a id provider to ensure the hydration process to be succeed
usage: app.provide(ID_INJECTION_KEY, {
  prefix: number,
  current: number,
})`);
  const t = p();
  return c(() => s(r) || `${t.value}-id-${e.prefix}-${e.current++}`);
}, "useId");
export {
  m as ID_INJECTION_KEY,
  h as useId,
  f as useIdInjection
};
