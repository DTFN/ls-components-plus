var n = Object.defineProperty;
var t = (e, c) => n(e, "name", { value: c, configurable: !0 });
function m(e) {
  return {
    setCurrentRow: /* @__PURE__ */ t((o) => {
      e.commit("setCurrentRow", o);
    }, "setCurrentRow"),
    getSelectionRows: /* @__PURE__ */ t(() => e.getSelectionRows(), "getSelectionRows"),
    toggleRowSelection: /* @__PURE__ */ t((o, l) => {
      e.toggleRowSelection(o, l, !1), e.updateAllSelected();
    }, "toggleRowSelection"),
    clearSelection: /* @__PURE__ */ t(() => {
      e.clearSelection();
    }, "clearSelection"),
    clearFilter: /* @__PURE__ */ t((o) => {
      e.clearFilter(o);
    }, "clearFilter"),
    toggleAllSelection: /* @__PURE__ */ t(() => {
      e.commit("toggleAllSelection");
    }, "toggleAllSelection"),
    toggleRowExpansion: /* @__PURE__ */ t((o, l) => {
      e.toggleRowExpansionAdapter(o, l);
    }, "toggleRowExpansion"),
    clearSort: /* @__PURE__ */ t(() => {
      e.clearSort();
    }, "clearSort"),
    sort: /* @__PURE__ */ t((o, l) => {
      e.commit("sort", { prop: o, order: l });
    }, "sort")
  };
}
t(m, "useUtils");
export {
  m as default
};
