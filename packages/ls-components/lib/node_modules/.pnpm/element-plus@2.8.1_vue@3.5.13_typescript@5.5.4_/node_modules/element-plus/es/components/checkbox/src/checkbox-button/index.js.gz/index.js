var w = Object.defineProperty;
var n = (v, m) => w(v, "name", { value: m, configurable: !0 });
import { defineComponent as B, useSlots as z, inject as D, computed as C, openBlock as c, createElementBlock as d, normalizeClass as b, unref as l, withDirectives as V, isRef as x, withModifiers as y, vModelCheckbox as g, normalizeStyle as E, renderSlot as N, createTextVNode as G, toDisplayString as K, createCommentVNode as M } from "vue";
import { checkboxGroupContextKey as _ } from "../constants/index.js";
import { checkboxProps as j, checkboxEmits as P } from "../checkbox/index.js";
import R from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useCheckbox as T } from "../composables/use-checkbox/index.js";
import { useNamespace as q } from "../../../../hooks/use-namespace/index/index.js";
const A = B({
  name: "ElCheckboxButton"
}), H = /* @__PURE__ */ B({
  ...A,
  props: j,
  emits: P,
  setup(v) {
    const m = v, S = z(), {
      isFocused: u,
      isChecked: h,
      isDisabled: p,
      checkboxButtonSize: $,
      model: t,
      actualValue: F,
      handleChange: k
    } = T(m, S), r = D(_, void 0), a = q("checkbox"), L = C(() => {
      var e, f, s, i;
      const o = (f = (e = r == null ? void 0 : r.fill) == null ? void 0 : e.value) != null ? f : "";
      return {
        backgroundColor: o,
        borderColor: o,
        color: (i = (s = r == null ? void 0 : r.textColor) == null ? void 0 : s.value) != null ? i : "",
        boxShadow: o ? `-1px 0 0 0 ${o}` : void 0
      };
    }), U = C(() => [
      a.b("button"),
      a.bm("button", $.value),
      a.is("disabled", p.value),
      a.is("checked", h.value),
      a.is("focus", u.value)
    ]);
    return (e, f) => {
      var s, i;
      return c(), d("label", {
        class: b(l(U))
      }, [
        e.trueValue || e.falseValue || e.trueLabel || e.falseLabel ? V((c(), d("input", {
          key: 0,
          "onUpdate:modelValue": /* @__PURE__ */ n((o) => x(t) ? t.value = o : null, "onUpdate:modelValue"),
          class: b(l(a).be("button", "original")),
          type: "checkbox",
          name: e.name,
          tabindex: e.tabindex,
          disabled: l(p),
          "true-value": (s = e.trueValue) != null ? s : e.trueLabel,
          "false-value": (i = e.falseValue) != null ? i : e.falseLabel,
          onChange: l(k),
          onFocus: /* @__PURE__ */ n((o) => u.value = !0, "onFocus"),
          onBlur: /* @__PURE__ */ n((o) => u.value = !1, "onBlur"),
          onClick: y(() => {
          }, ["stop"])
        }, null, 42, ["onUpdate:modelValue", "name", "tabindex", "disabled", "true-value", "false-value", "onChange", "onFocus", "onBlur", "onClick"])), [
          [g, l(t)]
        ]) : V((c(), d("input", {
          key: 1,
          "onUpdate:modelValue": /* @__PURE__ */ n((o) => x(t) ? t.value = o : null, "onUpdate:modelValue"),
          class: b(l(a).be("button", "original")),
          type: "checkbox",
          name: e.name,
          tabindex: e.tabindex,
          disabled: l(p),
          value: l(F),
          onChange: l(k),
          onFocus: /* @__PURE__ */ n((o) => u.value = !0, "onFocus"),
          onBlur: /* @__PURE__ */ n((o) => u.value = !1, "onBlur"),
          onClick: y(() => {
          }, ["stop"])
        }, null, 42, ["onUpdate:modelValue", "name", "tabindex", "disabled", "value", "onChange", "onFocus", "onBlur", "onClick"])), [
          [g, l(t)]
        ]),
        e.$slots.default || e.label ? (c(), d("span", {
          key: 2,
          class: b(l(a).be("button", "inner")),
          style: E(l(h) ? l(L) : void 0)
        }, [
          N(e.$slots, "default", {}, () => [
            G(K(e.label), 1)
          ])
        ], 6)) : M("v-if", !0)
      ], 2);
    };
  }
});
var Z = /* @__PURE__ */ R(H, [["__file", "checkbox-button.vue"]]);
export {
  Z as default
};
