var U = Object.defineProperty;
var o = (u, n) => U(u, "name", { value: n, configurable: !0 });
import { watch as d } from "vue";
import { useVModel as O } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { genFileId as v } from "../upload/index.js";
import { debugWarn as j, throwError as w } from "../../../../utils/error/index.js";
import C from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
const f = "ElUpload", m = /* @__PURE__ */ o((u) => {
  var n;
  (n = u.url) != null && n.startsWith("blob:") && URL.revokeObjectURL(u.url);
}, "revokeFileObjectURL"), M = /* @__PURE__ */ o((u, n) => {
  const a = O(u, "fileList", void 0, { passive: !0 }), s = /* @__PURE__ */ o((e) => a.value.find((t) => t.uid === e.uid), "getFile");
  function i(e) {
    var t;
    (t = n.value) == null || t.abort(e);
  }
  o(i, "abort");
  function b(e = ["ready", "uploading", "success", "fail"]) {
    a.value = a.value.filter((t) => !e.includes(t.status));
  }
  o(b, "clearFiles");
  function c(e) {
    a.value = a.value.filter((t) => t !== e);
  }
  o(c, "removeFile");
  const h = /* @__PURE__ */ o((e, t) => {
    const r = s(t);
    r && (console.error(e), r.status = "fail", c(r), u.onError(e, r, a.value), u.onChange(r, a.value));
  }, "handleError"), g = /* @__PURE__ */ o((e, t) => {
    const r = s(t);
    r && (u.onProgress(e, r, a.value), r.status = "uploading", r.percentage = Math.round(e.percent));
  }, "handleProgress"), R = /* @__PURE__ */ o((e, t) => {
    const r = s(t);
    r && (r.status = "success", r.response = e, u.onSuccess(e, r, a.value), u.onChange(r, a.value));
  }, "handleSuccess"), y = /* @__PURE__ */ o((e) => {
    C(e.uid) && (e.uid = v());
    const t = {
      name: e.name,
      percentage: 0,
      status: "ready",
      size: e.size,
      raw: e,
      uid: e.uid
    };
    if (u.listType === "picture-card" || u.listType === "picture")
      try {
        t.url = URL.createObjectURL(e);
      } catch (r) {
        j(f, r.message), u.onError(r, t, a.value);
      }
    a.value = [...a.value, t], u.onChange(t, a.value);
  }, "handleStart"), F = /* @__PURE__ */ o(async (e) => {
    const t = e instanceof File ? s(e) : e;
    t || w(f, "file to be removed not found");
    const r = /* @__PURE__ */ o((l) => {
      i(l), c(l), u.onRemove(l, a.value), m(l);
    }, "doRemove");
    u.beforeRemove ? await u.beforeRemove(t, a.value) !== !1 && r(t) : r(t);
  }, "handleRemove");
  function E() {
    a.value.filter(({ status: e }) => e === "ready").forEach(({ raw: e }) => {
      var t;
      return e && ((t = n.value) == null ? void 0 : t.upload(e));
    });
  }
  return o(E, "submit"), d(() => u.listType, (e) => {
    e !== "picture-card" && e !== "picture" || (a.value = a.value.map((t) => {
      const { raw: r, url: l } = t;
      if (!l && r)
        try {
          t.url = URL.createObjectURL(r);
        } catch (L) {
          u.onError(L, t, a.value);
        }
      return t;
    }));
  }), d(a, (e) => {
    for (const t of e)
      t.uid || (t.uid = v()), t.status || (t.status = "success");
  }, { immediate: !0, deep: !0 }), {
    uploadFiles: a,
    abort: i,
    clearFiles: b,
    handleError: h,
    handleProgress: g,
    handleStart: y,
    handleSuccess: R,
    handleRemove: F,
    submit: E,
    revokeFileObjectURL: m
  };
}, "useHandlers");
export {
  M as useHandlers
};
