var x = Object.defineProperty;
var n = (r, i) => x(r, "name", { value: i, configurable: !0 });
import { getCurrentInstance as E, inject as O, ref as u, watch as p, unref as a } from "vue";
import { isValidRange as K, getDefaultValue as T } from "../../utils/index.js";
import { ROOT_PICKER_INJECTION_KEY as j } from "../../constants/index.js";
import { useShortcut as w } from "../use-shortcut/index.js";
import { useNamespace as y } from "../../../../../hooks/use-namespace/index/index.js";
import { useLocale as A } from "../../../../../hooks/use-locale/index/index.js";
import { isArray as J } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
const H = /* @__PURE__ */ n((r, {
  defaultValue: i,
  leftDate: f,
  rightDate: v,
  unit: h,
  onParsedValueChanged: k
}) => {
  const { emit: D } = E(), { pickerNs: R } = O(j), C = y("date-range-picker"), { t: N, lang: m } = A(), _ = w(m), o = u(), s = u(), c = u({
    endDate: null,
    selecting: !1
  }), I = /* @__PURE__ */ n((e) => {
    c.value = e;
  }, "handleChangeRange"), P = /* @__PURE__ */ n((e = !1) => {
    const t = a(o), l = a(s);
    K([t, l]) && D("pick", [t, l], e);
  }, "handleRangeConfirm"), S = /* @__PURE__ */ n((e) => {
    c.value.selecting = e, e || (c.value.endDate = null);
  }, "onSelect"), g = /* @__PURE__ */ n((e) => {
    if (J(e) && e.length === 2) {
      const [t, l] = e;
      o.value = t, f.value = t, s.value = l, k(a(o), a(s));
    } else
      d();
  }, "onReset"), d = /* @__PURE__ */ n(() => {
    const [e, t] = T(a(i), {
      lang: a(m),
      unit: h,
      unlinkPanels: r.unlinkPanels
    });
    o.value = void 0, s.value = void 0, f.value = e, v.value = t;
  }, "restoreDefault");
  return p(i, (e) => {
    e && d();
  }, { immediate: !0 }), p(() => r.parsedValue, g, { immediate: !0 }), {
    minDate: o,
    maxDate: s,
    rangeState: c,
    lang: m,
    ppNs: R,
    drpNs: C,
    handleChangeRange: I,
    handleRangeConfirm: P,
    handleShortcutClick: _,
    onSelect: S,
    onReset: g,
    t: N
  };
}, "useRangePicker");
export {
  H as useRangePicker
};
