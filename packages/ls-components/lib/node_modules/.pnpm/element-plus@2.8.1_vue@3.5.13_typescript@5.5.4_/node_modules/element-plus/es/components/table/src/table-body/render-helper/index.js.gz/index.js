var X = Object.defineProperty;
var s = (a, y) => X(a, "name", { value: y, configurable: !0 });
import { inject as Z, computed as I, h as M } from "vue";
import { getRowIdentity as O } from "../../util/index.js";
import { TABLE_INJECTION_KEY as D } from "../../tokens/index.js";
import $ from "../events-helper/index.js";
import ee from "../styles-helper/index.js";
import { useNamespace as le } from "../../../../../hooks/use-namespace/index/index.js";
import ne from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/merge/index.js";
function pe(a) {
  const y = Z(D), z = le("table"), {
    handleDoubleClick: S,
    handleClick: _,
    handleContextMenu: R,
    handleMouseEnter: j,
    handleMouseLeave: q,
    handleCellMouseEnter: W,
    handleCellMouseLeave: A,
    tooltipContent: B,
    tooltipTrigger: F
  } = $(a), {
    getRowStyle: J,
    getRowClass: Y,
    getCellStyle: w,
    getCellClass: G,
    getSpan: H,
    getColspanRealWidth: P
  } = ee(a), Q = I(() => a.store.states.columns.value.findIndex(({ type: l }) => l === "default")), T = /* @__PURE__ */ s((l, t) => {
    const n = y.props.rowKey;
    return n ? O(l, n) : t;
  }, "getKeyOfRow"), b = /* @__PURE__ */ s((l, t, n, L = !1) => {
    const { tooltipEffect: N, tooltipOptions: v, store: k } = a, { indent: K, columns: h } = k.states, m = Y(l, t);
    let x = !0;
    return n && (m.push(z.em("row", `level-${n.level}`)), x = n.display), M("tr", {
      style: [x ? null : {
        display: "none"
      }, J(l, t)],
      class: m,
      key: T(l, t),
      onDblclick: /* @__PURE__ */ s((e) => S(e, l), "onDblclick"),
      onClick: /* @__PURE__ */ s((e) => _(e, l), "onClick"),
      onContextmenu: /* @__PURE__ */ s((e) => R(e, l), "onContextmenu"),
      onMouseenter: /* @__PURE__ */ s(() => j(t), "onMouseenter"),
      onMouseleave: q
    }, h.value.map((e, o) => {
      const { rowspan: C, colspan: i } = H(l, e, t, o);
      if (!C || !i)
        return null;
      const u = Object.assign({}, e);
      u.realWidth = P(h.value, i, o);
      const c = {
        store: a.store,
        _self: a.context || y,
        column: u,
        row: l,
        $index: t,
        cellIndex: o,
        expanded: L
      };
      o === Q.value && n && (c.treeNode = {
        indent: n.level * K.value,
        level: n.level
      }, typeof n.expanded == "boolean" && (c.treeNode.expanded = n.expanded, "loading" in n && (c.treeNode.loading = n.loading), "noLazyChildren" in n && (c.treeNode.noLazyChildren = n.noLazyChildren)));
      const g = `${T(l, t)},${o}`, p = u.columnKey || u.rawColumnKey || "", E = U(o, e, c), r = e.showOverflowTooltip && ne({
        effect: N
      }, v, e.showOverflowTooltip);
      return M("td", {
        style: w(t, o, l, e),
        class: G(t, o, l, e, i - 1),
        key: `${p}${g}`,
        rowspan: C,
        colspan: i,
        onMouseenter: /* @__PURE__ */ s((f) => W(f, l, r), "onMouseenter"),
        onMouseleave: A
      }, [E]);
    }));
  }, "rowRender"), U = /* @__PURE__ */ s((l, t, n) => t.renderCell(n), "cellChildren");
  return {
    wrappedRowRender: /* @__PURE__ */ s((l, t) => {
      const n = a.store, { isRowExpanded: L, assertRowKey: N } = n, { treeData: v, lazyTreeNodeMap: k, childrenColumnName: K, rowKey: h } = n.states, m = n.states.columns.value;
      if (m.some(({ type: d }) => d === "expand")) {
        const d = L(l), e = b(l, t, void 0, d), o = y.renderExpanded;
        return d ? o ? [
          [
            e,
            M("tr", {
              key: `expanded-row__${e.key}`
            }, [
              M("td", {
                colspan: m.length,
                class: `${z.e("cell")} ${z.e("expanded-cell")}`
              }, [o({ row: l, $index: t, store: n, expanded: d })])
            ])
          ]
        ] : (console.error("[Element Error]renderExpanded is required."), e) : [[e]];
      } else if (Object.keys(v.value).length) {
        N();
        const d = O(l, h.value);
        let e = v.value[d], o = null;
        e && (o = {
          expanded: e.expanded,
          level: e.level,
          display: !0
        }, typeof e.lazy == "boolean" && (typeof e.loaded == "boolean" && e.loaded && (o.noLazyChildren = !(e.children && e.children.length)), o.loading = e.loading));
        const C = [b(l, t, o)];
        if (e) {
          let i = 0;
          const u = /* @__PURE__ */ s((g, p) => {
            g && g.length && p && g.forEach((E) => {
              const r = {
                display: p.display && p.expanded,
                level: p.level + 1,
                expanded: !1,
                noLazyChildren: !1,
                loading: !1
              }, f = O(E, h.value);
              if (f == null)
                throw new Error("For nested data item, row-key is required.");
              if (e = { ...v.value[f] }, e && (r.expanded = e.expanded, e.level = e.level || r.level, e.display = !!(e.expanded && r.display), typeof e.lazy == "boolean" && (typeof e.loaded == "boolean" && e.loaded && (r.noLazyChildren = !(e.children && e.children.length)), r.loading = e.loading)), i++, C.push(b(E, t + i, r)), e) {
                const V = k.value[f] || E[K.value];
                u(V, e);
              }
            });
          }, "traverse");
          e.display = !0;
          const c = k.value[d] || l[K.value];
          u(c, e);
        }
        return C;
      } else
        return b(l, t, void 0);
    }, "wrappedRowRender"),
    tooltipContent: B,
    tooltipTrigger: F
  };
}
s(pe, "useRender");
export {
  pe as default
};
