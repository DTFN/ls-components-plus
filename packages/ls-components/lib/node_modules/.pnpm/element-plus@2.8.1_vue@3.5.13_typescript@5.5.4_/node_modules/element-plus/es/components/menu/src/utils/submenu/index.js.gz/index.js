var h = Object.defineProperty;
var i = (u, e) => h(u, "name", { value: e, configurable: !0 });
import { EVENT_CODE as t } from "../../../../../constants/aria/index.js";
import { triggerEvent as d } from "../../../../../utils/dom/aria/index.js";
const a = class a {
  constructor(e, o) {
    this.parent = e, this.domNode = o, this.subIndex = 0, this.subIndex = 0, this.init();
  }
  init() {
    this.subMenuItems = this.domNode.querySelectorAll("li"), this.addListeners();
  }
  gotoSubIndex(e) {
    e === this.subMenuItems.length ? e = 0 : e < 0 && (e = this.subMenuItems.length - 1), this.subMenuItems[e].focus(), this.subIndex = e;
  }
  addListeners() {
    const e = this.parent.domNode;
    Array.prototype.forEach.call(this.subMenuItems, (o) => {
      o.addEventListener("keydown", (s) => {
        let r = !1;
        switch (s.code) {
          case t.down: {
            this.gotoSubIndex(this.subIndex + 1), r = !0;
            break;
          }
          case t.up: {
            this.gotoSubIndex(this.subIndex - 1), r = !0;
            break;
          }
          case t.tab: {
            d(e, "mouseleave");
            break;
          }
          case t.enter:
          case t.space: {
            r = !0, s.currentTarget.click();
            break;
          }
        }
        return r && (s.preventDefault(), s.stopPropagation()), !1;
      });
    });
  }
};
i(a, "SubMenu");
let n = a;
export {
  n as default
};
