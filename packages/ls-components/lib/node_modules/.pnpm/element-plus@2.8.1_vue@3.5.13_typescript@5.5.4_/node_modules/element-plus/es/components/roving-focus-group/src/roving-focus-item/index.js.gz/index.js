var h = Object.defineProperty;
var C = (o, n) => h(o, "name", { value: n, configurable: !0 });
import { defineComponent as k, inject as E, ref as w, computed as O, unref as c, provide as y, resolveComponent as R, openBlock as G, createBlock as K, withCtx as x, renderSlot as S, nextTick as U } from "vue";
import { ElCollectionItem as $, ROVING_FOCUS_COLLECTION_INJECTION_KEY as B } from "../roving-focus-group/index.js";
import { ROVING_FOCUS_GROUP_INJECTION_KEY as J, ROVING_FOCUS_GROUP_ITEM_INJECTION_KEY as L } from "../tokens/index.js";
import { getFocusIntent as V, reorderArray as Y, focusFirst as D } from "../utils/index.js";
import M from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useId as P } from "../../../../hooks/use-id/index/index.js";
import { composeEventHandlers as u } from "../../../../utils/dom/event/index.js";
import { EVENT_CODE as j } from "../../../../constants/aria/index.js";
const A = k({
  components: {
    ElRovingFocusCollectionItem: $
  },
  props: {
    focusable: {
      type: Boolean,
      default: !0
    },
    active: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["mousedown", "focus", "keydown"],
  setup(o, { emit: n }) {
    const { currentTabbedId: f, loop: m, onItemFocus: i, onItemShiftTab: d } = E(J, void 0), { getItems: l } = E(B, void 0), s = P(), b = w(null), p = u((e) => {
      n("mousedown", e);
    }, (e) => {
      o.focusable ? i(c(s)) : e.preventDefault();
    }), _ = u((e) => {
      n("focus", e);
    }, () => {
      i(c(s));
    }), I = u((e) => {
      n("keydown", e);
    }, (e) => {
      const { key: T, shiftKey: g, target: F, currentTarget: v } = e;
      if (T === j.tab && g) {
        d();
        return;
      }
      if (F !== v)
        return;
      const a = V(e);
      if (a) {
        e.preventDefault();
        let t = l().filter((r) => r.focusable).map((r) => r.ref);
        switch (a) {
          case "last": {
            t.reverse();
            break;
          }
          case "prev":
          case "next": {
            a === "prev" && t.reverse();
            const r = t.indexOf(v);
            t = m.value ? Y(t, r + 1) : t.slice(r + 1);
            break;
          }
        }
        U(() => {
          D(t);
        });
      }
    }), N = O(() => f.value === c(s));
    return y(L, {
      rovingFocusGroupItemRef: b,
      tabIndex: O(() => c(N) ? 0 : -1),
      handleMousedown: p,
      handleFocus: _,
      handleKeydown: I
    }), {
      id: s,
      handleKeydown: I,
      handleFocus: _,
      handleMousedown: p
    };
  }
});
function H(o, n, f, m, i, d) {
  const l = R("el-roving-focus-collection-item");
  return G(), K(l, {
    id: o.id,
    focusable: o.focusable,
    active: o.active
  }, {
    default: x(() => [
      S(o.$slots, "default")
    ]),
    _: 3
  }, 8, ["id", "focusable", "active"]);
}
C(H, "_sfc_render");
var re = /* @__PURE__ */ M(A, [["render", H], ["__file", "roving-focus-item.vue"]]);
export {
  re as default
};
