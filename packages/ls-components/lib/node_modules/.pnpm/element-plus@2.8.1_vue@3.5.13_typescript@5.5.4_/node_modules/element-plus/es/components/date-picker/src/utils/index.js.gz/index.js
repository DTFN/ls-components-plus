var j = Object.defineProperty;
var y = (r, f) => j(r, "name", { value: f, configurable: !0 });
import n from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { isArray as A } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { rangeArr as w } from "../../../time-picker/src/utils/index.js";
const g = /* @__PURE__ */ y((r) => {
  if (!A(r))
    return !1;
  const [f, s] = r;
  return n.isDayjs(f) && n.isDayjs(s) && f.isSameOrBefore(s);
}, "isValidRange"), k = /* @__PURE__ */ y((r, { lang: f, unit: s, unlinkPanels: o }) => {
  let e;
  if (A(r)) {
    let [i, m] = r.map((a) => n(a).locale(f));
    return o || (m = i.add(1, s)), [i, m];
  } else r ? e = n(r) : e = n();
  return e = e.locale(f), [e, e.add(1, s)];
}, "getDefaultValue"), M = /* @__PURE__ */ y((r, f, {
  columnIndexOffset: s,
  startDate: o,
  nextEndDate: e,
  now: i,
  unit: m,
  relativeDateGetter: a,
  setCellMetadata: p,
  setRowMetadata: u
}) => {
  for (let S = 0; S < r.row; S++) {
    const O = f[S];
    for (let t = 0; t < r.column; t++) {
      let c = O[t + s];
      c || (c = {
        row: S,
        column: t,
        type: "normal",
        inRange: !1,
        start: !1,
        end: !1
      });
      const d = S * r.column + t, l = a(d);
      c.dayjs = l, c.date = l.toDate(), c.timestamp = l.valueOf(), c.type = "normal", c.inRange = !!(o && l.isSameOrAfter(o, m) && e && l.isSameOrBefore(e, m)) || !!(o && l.isSameOrBefore(o, m) && e && l.isSameOrAfter(e, m)), o != null && o.isSameOrAfter(e) ? (c.start = !!e && l.isSame(e, m), c.end = o && l.isSame(o, m)) : (c.start = !!o && l.isSame(o, m), c.end = !!e && l.isSame(e, m)), l.isSame(i, m) && (c.type = "today"), p == null || p(c, { rowIndex: S, columnIndex: t }), O[t + s] = c;
    }
    u == null || u(O);
  }
}, "buildPickerTable"), h = /* @__PURE__ */ y((r, f, s) => {
  const o = n().locale(s).startOf("month").month(f).year(r), e = o.daysInMonth();
  return w(e).map((i) => o.add(i, "day").toDate());
}, "datesInMonth"), v = /* @__PURE__ */ y((r, f, s, o) => {
  const e = n().year(r).month(f).startOf("month"), i = h(r, f, s).find((m) => !(o != null && o(m)));
  return i ? n(i).locale(s) : e.locale(s);
}, "getValidDateOfMonth"), P = /* @__PURE__ */ y((r, f, s) => {
  const o = r.year();
  if (!(s != null && s(r.toDate())))
    return r.locale(f);
  const e = r.month();
  if (!h(o, e, f).every(s))
    return v(o, e, f, s);
  for (let i = 0; i < 12; i++)
    if (!h(o, i, f).every(s))
      return v(o, i, f, s);
  return r;
}, "getValidDateOfYear");
export {
  M as buildPickerTable,
  h as datesInMonth,
  k as getDefaultValue,
  v as getValidDateOfMonth,
  P as getValidDateOfYear,
  g as isValidRange
};
