import { defineComponent as g, computed as S, openBlock as n, createBlock as l, resolveDynamicComponent as i, mergeProps as z, unref as s, withCtx as a, createElementBlock as f, Fragment as I, renderSlot as r, normalizeClass as k, createCommentVNode as y } from "vue";
import { ElIcon as b } from "../../../icon/index/index.js";
import { useButton as N } from "../use-button/index.js";
import { buttonProps as P, buttonEmits as w } from "../button/index.js";
import { useButtonCustomStyle as A } from "../button-custom/index.js";
import D from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as F } from "../../../../hooks/use-namespace/index/index.js";
const K = g({
  name: "ElButton"
}), V = /* @__PURE__ */ g({
  ...K,
  props: P,
  emits: w,
  setup(_, { expose: C, emit: v }) {
    const t = _, B = A(t), e = F("button"), { _ref: u, _size: m, _type: d, _disabled: p, _props: $, shouldAddSpace: c, handleClick: h } = N(t, v), E = S(() => [
      e.b(),
      e.m(d.value),
      e.m(m.value),
      e.is("disabled", p.value),
      e.is("loading", t.loading),
      e.is("plain", t.plain),
      e.is("round", t.round),
      e.is("circle", t.circle),
      e.is("text", t.text),
      e.is("link", t.link),
      e.is("has-bg", t.bg)
    ]);
    return C({
      ref: u,
      size: m,
      type: d,
      disabled: p,
      shouldAddSpace: c
    }), (o, j) => (n(), l(i(o.tag), z({
      ref_key: "_ref",
      ref: u
    }, s($), {
      class: s(E),
      style: s(B),
      onClick: s(h)
    }), {
      default: a(() => [
        o.loading ? (n(), f(I, { key: 0 }, [
          o.$slots.loading ? r(o.$slots, "loading", { key: 0 }) : (n(), l(s(b), {
            key: 1,
            class: k(s(e).is("loading"))
          }, {
            default: a(() => [
              (n(), l(i(o.loadingIcon)))
            ]),
            _: 1
          }, 8, ["class"]))
        ], 64)) : o.icon || o.$slots.icon ? (n(), l(s(b), { key: 1 }, {
          default: a(() => [
            o.icon ? (n(), l(i(o.icon), { key: 0 })) : r(o.$slots, "icon", { key: 1 })
          ]),
          _: 3
        })) : y("v-if", !0),
        o.$slots.default ? (n(), f("span", {
          key: 2,
          class: k({ [s(e).em("text", "expand")]: s(c) })
        }, [
          r(o.$slots, "default")
        ], 2)) : y("v-if", !0)
      ]),
      _: 3
    }, 16, ["class", "style", "onClick"]));
  }
});
var Q = /* @__PURE__ */ D(V, [["__file", "button.vue"]]);
export {
  Q as default
};
