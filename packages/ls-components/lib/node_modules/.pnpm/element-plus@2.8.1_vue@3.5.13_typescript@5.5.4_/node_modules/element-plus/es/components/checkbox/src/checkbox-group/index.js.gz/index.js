var i = Object.defineProperty;
var e = (r, t) => i(r, "name", { value: t, configurable: !0 });
import { buildProps as a, definePropType as p } from "../../../../utils/vue/props/runtime/index.js";
import { useSizeProp as m } from "../../../../hooks/use-size/index/index.js";
import { useAriaProps as l } from "../../../../hooks/use-aria/index/index.js";
import { UPDATE_MODEL_EVENT as u } from "../../../../constants/event/index.js";
import { isArray as o } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
const y = a({
  modelValue: {
    type: p(Array),
    default: /* @__PURE__ */ e(() => [], "default")
  },
  disabled: Boolean,
  min: Number,
  max: Number,
  size: m,
  fill: String,
  textColor: String,
  tag: {
    type: String,
    default: "div"
  },
  validateEvent: {
    type: Boolean,
    default: !0
  },
  ...l(["ariaLabel"])
}), E = {
  [u]: (r) => o(r),
  change: /* @__PURE__ */ e((r) => o(r), "change")
};
export {
  E as checkboxGroupEmits,
  y as checkboxGroupProps
};
