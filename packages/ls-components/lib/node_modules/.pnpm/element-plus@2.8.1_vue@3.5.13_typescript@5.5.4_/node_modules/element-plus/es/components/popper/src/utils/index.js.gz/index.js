var f = Object.defineProperty;
var n = (e, t) => f(e, "name", { value: t, configurable: !0 });
import { unrefElement as p } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { isClient as l } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const g = /* @__PURE__ */ n((e, t = []) => {
  const { placement: o, strategy: i, popperOptions: r } = e, s = {
    placement: o,
    strategy: i,
    ...r,
    modifiers: [...a(e), ...t]
  };
  return m(s, r == null ? void 0 : r.modifiers), s;
}, "buildPopperOptions"), b = /* @__PURE__ */ n((e) => {
  if (l)
    return p(e);
}, "unwrapMeasurableEl");
function a(e) {
  const { offset: t, gpuAcceleration: o, fallbackPlacements: i } = e;
  return [
    {
      name: "offset",
      options: {
        offset: [0, t ?? 12]
      }
    },
    {
      name: "preventOverflow",
      options: {
        padding: {
          top: 2,
          bottom: 2,
          left: 5,
          right: 5
        }
      }
    },
    {
      name: "flip",
      options: {
        padding: 5,
        fallbackPlacements: i
      }
    },
    {
      name: "computeStyles",
      options: {
        gpuAcceleration: o
      }
    }
  ];
}
n(a, "genModifiers");
function m(e, t) {
  t && (e.modifiers = [...e.modifiers, ...t ?? []]);
}
n(m, "deriveExtraModifiers");
export {
  g as buildPopperOptions,
  b as unwrapMeasurableEl
};
