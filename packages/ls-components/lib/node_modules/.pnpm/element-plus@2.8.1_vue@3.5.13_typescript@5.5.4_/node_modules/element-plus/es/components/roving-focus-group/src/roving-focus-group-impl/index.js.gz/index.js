var U = Object.defineProperty;
var u = (o, r) => U(o, "name", { value: r, configurable: !0 });
import { defineComponent as V, ref as l, inject as $, computed as F, provide as w, readonly as K, toRef as _, unref as i, watch as P, renderSlot as Y } from "vue";
import { useEventListener as x } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { rovingFocusGroupProps as A, ROVING_FOCUS_COLLECTION_INJECTION_KEY as J } from "../roving-focus-group/index.js";
import { ROVING_FOCUS_GROUP_INJECTION_KEY as k } from "../tokens/index.js";
import { focusFirst as H } from "../utils/index.js";
import M from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { composeEventHandlers as m } from "../../../../utils/dom/event/index.js";
const T = "currentTabIdChange", b = "rovingFocusGroup.entryFocus", j = { bubbles: !1, cancelable: !0 }, D = V({
  name: "ElRovingFocusGroupImpl",
  inheritAttrs: !1,
  props: A,
  emits: [T, "entryFocus"],
  setup(o, { emit: r }) {
    var d;
    const s = l((d = o.currentTabId || o.defaultCurrentTabId) != null ? d : null), c = l(!1), a = l(!1), I = l(null), { getItems: C } = $(J, void 0), O = F(() => [
      {
        outline: "none"
      },
      o.style
    ]), N = /* @__PURE__ */ u((e) => {
      r(T, e);
    }, "onItemFocus"), g = /* @__PURE__ */ u(() => {
      c.value = !0;
    }, "onItemShiftTab"), p = m((e) => {
      var t;
      (t = o.onMousedown) == null || t.call(o, e);
    }, () => {
      a.value = !0;
    }), R = m((e) => {
      var t;
      (t = o.onFocus) == null || t.call(o, e);
    }, (e) => {
      const t = !i(a), { target: h, currentTarget: f } = e;
      if (h === f && t && !i(c)) {
        const E = new Event(b, j);
        if (f == null || f.dispatchEvent(E), !E.defaultPrevented) {
          const v = C().filter((n) => n.focusable), S = v.find((n) => n.active), B = v.find((n) => n.id === i(s)), L = [S, B, ...v].filter(Boolean).map((n) => n.ref);
          H(L);
        }
      }
      a.value = !1;
    }), G = m((e) => {
      var t;
      (t = o.onBlur) == null || t.call(o, e);
    }, () => {
      c.value = !1;
    }), y = /* @__PURE__ */ u((...e) => {
      r("entryFocus", ...e);
    }, "handleEntryFocus");
    w(k, {
      currentTabbedId: K(s),
      loop: _(o, "loop"),
      tabIndex: F(() => i(c) ? -1 : 0),
      rovingFocusGroupRef: I,
      rovingFocusGroupRootStyle: O,
      orientation: _(o, "orientation"),
      dir: _(o, "dir"),
      onItemFocus: N,
      onItemShiftTab: g,
      onBlur: G,
      onFocus: R,
      onMousedown: p
    }), P(() => o.currentTabId, (e) => {
      s.value = e ?? null;
    }), x(I, b, y);
  }
});
function q(o, r, d, s, c, a) {
  return Y(o.$slots, "default");
}
u(q, "_sfc_render");
var ro = /* @__PURE__ */ M(D, [["render", q], ["__file", "roving-focus-group-impl.vue"]]);
export {
  ro as default
};
