import { defineComponent as a, ref as n, provide as s, onMounted as u, openBlock as b, createElementBlock as i, normalizeClass as p, unref as t, renderSlot as f } from "vue";
import { breadcrumbKey as d } from "../constants/index.js";
import { breadcrumbProps as _ } from "../breadcrumb/index.js";
import v from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as g } from "../../../../hooks/use-locale/index/index.js";
import { useNamespace as B } from "../../../../hooks/use-namespace/index/index.js";
const h = a({
  name: "ElBreadcrumb"
}), k = /* @__PURE__ */ a({
  ...h,
  props: _,
  setup(m) {
    const c = m, { t: l } = g(), r = B("breadcrumb"), o = n();
    return s(d, c), u(() => {
      const e = o.value.querySelectorAll(`.${r.e("item")}`);
      e.length && e[e.length - 1].setAttribute("aria-current", "page");
    }), (e, y) => (b(), i("div", {
      ref_key: "breadcrumb",
      ref: o,
      class: p(t(r).b()),
      "aria-label": t(l)("el.breadcrumb.label"),
      role: "navigation"
    }, [
      f(e.$slots, "default")
    ], 10, ["aria-label"]));
  }
});
var q = /* @__PURE__ */ v(k, [["__file", "breadcrumb.vue"]]);
export {
  q as default
};
