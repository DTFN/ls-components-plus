var j = Object.defineProperty;
var t = (e, u) => j(e, "name", { value: u, configurable: !0 });
import { defineComponent as G, getCurrentInstance as I, ref as D, computed as c, watch as L, resolveComponent as s, resolveDirective as z, openBlock as a, createBlock as w, withCtx as m, createElementBlock as f, createElementVNode as v, normalizeClass as i, createVNode as $, Fragment as R, renderList as _, createTextVNode as M, toDisplayString as b, withDirectives as q, renderSlot as H } from "vue";
import { ElCheckbox as A } from "../../../checkbox/index/index.js";
import { ElIcon as J } from "../../../icon/index/index.js";
import { ArrowDown as K, ArrowUp as Q } from "@element-plus/icons-vue";
import { ElTooltip as W } from "../../../tooltip/index/index.js";
import { ElScrollbar as X } from "../../../scrollbar/index/index.js";
import Y from "../../../../_virtual/plugin-vue_export-helper/index.js";
import Z from "../../../../directives/click-outside/index/index.js";
import { useLocale as x } from "../../../../hooks/use-locale/index/index.js";
import { useNamespace as ee } from "../../../../hooks/use-namespace/index/index.js";
const { CheckboxGroup: le } = A, te = G({
  name: "ElTableFilterPanel",
  components: {
    ElCheckbox: A,
    ElCheckboxGroup: le,
    ElScrollbar: X,
    ElTooltip: W,
    ElIcon: J,
    ArrowDown: K,
    ArrowUp: Q
  },
  directives: { ClickOutside: Z },
  props: {
    placement: {
      type: String,
      default: "bottom-start"
    },
    store: {
      type: Object
    },
    column: {
      type: Object
    },
    upDataColumn: {
      type: Function
    }
  },
  setup(e) {
    const u = I(), { t: E } = x(), k = ee("table-filter"), V = u == null ? void 0 : u.parent;
    V.filterPanels.value[e.column.id] || (V.filterPanels.value[e.column.id] = u);
    const r = D(!1), h = D(null), g = c(() => e.column && e.column.filters), y = c(() => e.column.filterClassName ? `${k.b()} ${e.column.filterClassName}` : k.b()), d = c({
      get: /* @__PURE__ */ t(() => {
        var l;
        return (((l = e.column) == null ? void 0 : l.filteredValue) || [])[0];
      }, "get"),
      set: /* @__PURE__ */ t((l) => {
        o.value && (typeof l < "u" && l !== null ? o.value.splice(0, 1, l) : o.value.splice(0, 1));
      }, "set")
    }), o = c({
      get() {
        return e.column ? e.column.filteredValue || [] : [];
      },
      set(l) {
        e.column && e.upDataColumn("filteredValue", l);
      }
    }), F = c(() => e.column ? e.column.filterMultiple : !0), P = /* @__PURE__ */ t((l) => l.value === d.value, "isActive"), p = /* @__PURE__ */ t(() => {
      r.value = !1;
    }, "hidden"), n = /* @__PURE__ */ t((l) => {
      l.stopPropagation(), r.value = !r.value;
    }, "showFilterPanel"), N = /* @__PURE__ */ t(() => {
      r.value = !1;
    }, "hideFilterPanel"), O = /* @__PURE__ */ t(() => {
      C(o.value), p();
    }, "handleConfirm"), B = /* @__PURE__ */ t(() => {
      o.value = [], C(o.value), p();
    }, "handleReset"), T = /* @__PURE__ */ t((l) => {
      d.value = l, C(typeof l < "u" && l !== null ? o.value : []), p();
    }, "handleSelect"), C = /* @__PURE__ */ t((l) => {
      e.store.commit("filterChange", {
        column: e.column,
        values: l
      }), e.store.updateAllSelected();
    }, "confirmFilter");
    L(r, (l) => {
      e.column && e.upDataColumn("filterOpened", l);
    }, {
      immediate: !0
    });
    const U = c(() => {
      var l, S;
      return (S = (l = h.value) == null ? void 0 : l.popperRef) == null ? void 0 : S.contentRef;
    });
    return {
      tooltipVisible: r,
      multiple: F,
      filterClassName: y,
      filteredValue: o,
      filterValue: d,
      filters: g,
      handleConfirm: O,
      handleReset: B,
      handleSelect: T,
      isActive: P,
      t: E,
      ns: k,
      showFilterPanel: n,
      hideFilterPanel: N,
      popperPaneRef: U,
      tooltip: h
    };
  }
});
function ne(e, u, E, k, V, r) {
  const h = s("el-checkbox"), g = s("el-checkbox-group"), y = s("el-scrollbar"), d = s("arrow-up"), o = s("arrow-down"), F = s("el-icon"), P = s("el-tooltip"), p = z("click-outside");
  return a(), w(P, {
    ref: "tooltip",
    visible: e.tooltipVisible,
    offset: 0,
    placement: e.placement,
    "show-arrow": !1,
    "stop-popper-mouse-event": !1,
    teleported: "",
    effect: "light",
    pure: "",
    "popper-class": e.filterClassName,
    persistent: ""
  }, {
    content: m(() => [
      e.multiple ? (a(), f("div", { key: 0 }, [
        v("div", {
          class: i(e.ns.e("content"))
        }, [
          $(y, {
            "wrap-class": e.ns.e("wrap")
          }, {
            default: m(() => [
              $(g, {
                modelValue: e.filteredValue,
                "onUpdate:modelValue": /* @__PURE__ */ t((n) => e.filteredValue = n, "onUpdate:modelValue"),
                class: i(e.ns.e("checkbox-group"))
              }, {
                default: m(() => [
                  (a(!0), f(R, null, _(e.filters, (n) => (a(), w(h, {
                    key: n.value,
                    value: n.value
                  }, {
                    default: m(() => [
                      M(b(n.text), 1)
                    ]),
                    _: 2
                  }, 1032, ["value"]))), 128))
                ]),
                _: 1
              }, 8, ["modelValue", "onUpdate:modelValue", "class"])
            ]),
            _: 1
          }, 8, ["wrap-class"])
        ], 2),
        v("div", {
          class: i(e.ns.e("bottom"))
        }, [
          v("button", {
            class: i({ [e.ns.is("disabled")]: e.filteredValue.length === 0 }),
            disabled: e.filteredValue.length === 0,
            type: "button",
            onClick: e.handleConfirm
          }, b(e.t("el.table.confirmFilter")), 11, ["disabled", "onClick"]),
          v("button", {
            type: "button",
            onClick: e.handleReset
          }, b(e.t("el.table.resetFilter")), 9, ["onClick"])
        ], 2)
      ])) : (a(), f("ul", {
        key: 1,
        class: i(e.ns.e("list"))
      }, [
        v("li", {
          class: i([
            e.ns.e("list-item"),
            {
              [e.ns.is("active")]: e.filterValue === void 0 || e.filterValue === null
            }
          ]),
          onClick: /* @__PURE__ */ t((n) => e.handleSelect(null), "onClick")
        }, b(e.t("el.table.clearFilter")), 11, ["onClick"]),
        (a(!0), f(R, null, _(e.filters, (n) => (a(), f("li", {
          key: n.value,
          class: i([e.ns.e("list-item"), e.ns.is("active", e.isActive(n))]),
          label: n.value,
          onClick: /* @__PURE__ */ t((N) => e.handleSelect(n.value), "onClick")
        }, b(n.text), 11, ["label", "onClick"]))), 128))
      ], 2))
    ]),
    default: m(() => [
      q((a(), f("span", {
        class: i([
          `${e.ns.namespace.value}-table__column-filter-trigger`,
          `${e.ns.namespace.value}-none-outline`
        ]),
        onClick: e.showFilterPanel
      }, [
        $(F, null, {
          default: m(() => [
            H(e.$slots, "filter-icon", {}, () => [
              e.column.filterOpened ? (a(), w(d, { key: 0 })) : (a(), w(o, { key: 1 }))
            ])
          ]),
          _: 3
        })
      ], 10, ["onClick"])), [
        [p, e.hideFilterPanel, e.popperPaneRef]
      ])
    ]),
    _: 3
  }, 8, ["visible", "placement", "popper-class"]);
}
t(ne, "_sfc_render");
var ve = /* @__PURE__ */ Y(te, [["render", ne], ["__file", "filter-panel.vue"]]);
export {
  ve as default
};
