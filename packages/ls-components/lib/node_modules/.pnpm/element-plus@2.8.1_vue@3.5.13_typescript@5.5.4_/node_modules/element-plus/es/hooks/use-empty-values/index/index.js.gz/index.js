var m = Object.defineProperty;
var t = (e, u) => m(e, "name", { value: u, configurable: !0 });
import { getCurrentInstance as c, inject as y, ref as o, computed as s } from "vue";
import { buildProps as C } from "../../../utils/vue/props/runtime/index.js";
import { isFunction as n } from "../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { debugWarn as d } from "../../../utils/error/index.js";
const f = Symbol("emptyValuesContextKey"), p = "use-empty-values", O = ["", void 0, null], E = void 0, g = C({
  emptyValues: Array,
  valueOnClear: {
    type: [String, Number, Boolean, Function],
    default: void 0,
    validator: /* @__PURE__ */ t((e) => n(e) ? !e() : !e, "validator")
  }
}), F = /* @__PURE__ */ t((e, u) => {
  const l = c() ? y(f, o({})) : o({}), a = s(() => e.emptyValues || l.value.emptyValues || O), r = s(() => n(e.valueOnClear) ? e.valueOnClear() : e.valueOnClear !== void 0 ? e.valueOnClear : n(l.value.valueOnClear) ? l.value.valueOnClear() : l.value.valueOnClear !== void 0 ? l.value.valueOnClear : u !== void 0 ? u : E), v = /* @__PURE__ */ t((i) => a.value.includes(i), "isEmptyValue");
  return a.value.includes(r.value) || d(p, "value-on-clear should be a value of empty-values"), {
    emptyValues: a,
    valueOnClear: r,
    isEmptyValue: v
  };
}, "useEmptyValues");
export {
  O as DEFAULT_EMPTY_VALUES,
  E as DEFAULT_VALUE_ON_CLEAR,
  p as SCOPE,
  f as emptyValuesContextKey,
  F as useEmptyValues,
  g as useEmptyValuesProps
};
