var V = Object.defineProperty;
var c = (n, s) => V(n, "name", { value: s, configurable: !0 });
import { defineComponent as j, ref as q, provide as x, watch as b, unref as T, onMounted as J, onBeforeUnmount as M, nextTick as U, renderSlot as Y } from "vue";
import { useFocusReason as z, tryFocus as l, createFocusOutPreventedEvent as F, getEdges as G, focusableStack as k, focusFirstDescendant as H, obtainAllFocusableElements as Q, isFocusCausedByUserEvent as W } from "../utils/index.js";
import { ON_TRAP_FOCUS_EVT as w, ON_RELEASE_FOCUS_EVT as N, FOCUS_TRAP_INJECTION_KEY as X, FOCUS_AFTER_TRAPPED as L, FOCUS_AFTER_TRAPPED_OPTS as B, FOCUS_AFTER_RELEASED as S } from "../tokens/index.js";
import Z from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useEscapeKeydown as ee } from "../../../../hooks/use-escape-keydown/index/index.js";
import { EVENT_CODE as te } from "../../../../constants/aria/index.js";
import { isString as ne } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import oe from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
const se = j({
  name: "ElFocusTrap",
  inheritAttrs: !1,
  props: {
    loop: Boolean,
    trapped: Boolean,
    focusTrapEl: Object,
    focusStartEl: {
      type: [Object, String],
      default: "first"
    }
  },
  emits: [
    w,
    N,
    "focusin",
    "focusout",
    "focusout-prevented",
    "release-requested"
  ],
  setup(n, { emit: s }) {
    const o = q();
    let v, E;
    const { focusReason: f } = z();
    ee((e) => {
      n.trapped && !d.paused && s("release-requested", e);
    });
    const d = {
      paused: !1,
      pause() {
        this.paused = !0;
      },
      resume() {
        this.paused = !1;
      }
    }, p = /* @__PURE__ */ c((e) => {
      if (!n.loop && !n.trapped || d.paused)
        return;
      const { key: t, altKey: r, ctrlKey: a, metaKey: u, currentTarget: K, shiftKey: D } = e, { loop: I } = n, $ = t === te.tab && !r && !a && !u, m = document.activeElement;
      if ($ && m) {
        const y = K, [C, O] = G(y);
        if (C && O) {
          if (!D && m === O) {
            const i = F({
              focusReason: f.value
            });
            s("focusout-prevented", i), i.defaultPrevented || (e.preventDefault(), I && l(C, !0));
          } else if (D && [C, y].includes(m)) {
            const i = F({
              focusReason: f.value
            });
            s("focusout-prevented", i), i.defaultPrevented || (e.preventDefault(), I && l(O, !0));
          }
        } else if (m === y) {
          const i = F({
            focusReason: f.value
          });
          s("focusout-prevented", i), i.defaultPrevented || e.preventDefault();
        }
      }
    }, "onKeydown");
    x(X, {
      focusTrapRef: o,
      onKeydown: p
    }), b(() => n.focusTrapEl, (e) => {
      e && (o.value = e);
    }, { immediate: !0 }), b([o], ([e], [t]) => {
      e && (e.addEventListener("keydown", p), e.addEventListener("focusin", _), e.addEventListener("focusout", P)), t && (t.removeEventListener("keydown", p), t.removeEventListener("focusin", _), t.removeEventListener("focusout", P));
    });
    const g = /* @__PURE__ */ c((e) => {
      s(w, e);
    }, "trapOnFocus"), A = /* @__PURE__ */ c((e) => s(N, e), "releaseOnFocus"), _ = /* @__PURE__ */ c((e) => {
      const t = T(o);
      if (!t)
        return;
      const r = e.target, a = e.relatedTarget, u = r && t.contains(r);
      n.trapped || a && t.contains(a) || (v = a), u && s("focusin", e), !d.paused && n.trapped && (u ? E = r : l(E, !0));
    }, "onFocusIn"), P = /* @__PURE__ */ c((e) => {
      const t = T(o);
      if (!(d.paused || !t))
        if (n.trapped) {
          const r = e.relatedTarget;
          !oe(r) && !t.contains(r) && setTimeout(() => {
            if (!d.paused && n.trapped) {
              const a = F({
                focusReason: f.value
              });
              s("focusout-prevented", a), a.defaultPrevented || l(E, !0);
            }
          }, 0);
        } else {
          const r = e.target;
          r && t.contains(r) || s("focusout", e);
        }
    }, "onFocusOut");
    async function R() {
      await U();
      const e = T(o);
      if (e) {
        k.push(d);
        const t = e.contains(document.activeElement) ? v : document.activeElement;
        if (v = t, !e.contains(t)) {
          const a = new Event(L, B);
          e.addEventListener(L, g), e.dispatchEvent(a), a.defaultPrevented || U(() => {
            let u = n.focusStartEl;
            ne(u) || (l(u), document.activeElement !== u && (u = "first")), u === "first" && H(Q(e), !0), (document.activeElement === t || u === "container") && l(e);
          });
        }
      }
    }
    c(R, "startTrap");
    function h() {
      const e = T(o);
      if (e) {
        e.removeEventListener(L, g);
        const t = new CustomEvent(S, {
          ...B,
          detail: {
            focusReason: f.value
          }
        });
        e.addEventListener(S, A), e.dispatchEvent(t), !t.defaultPrevented && (f.value == "keyboard" || !W() || e.contains(document.activeElement)) && l(v ?? document.body), e.removeEventListener(S, A), k.remove(d);
      }
    }
    return c(h, "stopTrap"), J(() => {
      n.trapped && R(), b(() => n.trapped, (e) => {
        e ? R() : h();
      });
    }), M(() => {
      n.trapped && h(), o.value && (o.value.removeEventListener("keydown", p), o.value.removeEventListener("focusin", _), o.value.removeEventListener("focusout", P), o.value = void 0);
    }), {
      onKeydown: p
    };
  }
});
function re(n, s, o, v, E, f) {
  return Y(n.$slots, "default", { handleKeydown: n.onKeydown });
}
c(re, "_sfc_render");
var me = /* @__PURE__ */ Z(se, [["render", re], ["__file", "focus-trap.vue"]]);
export {
  me as default
};
