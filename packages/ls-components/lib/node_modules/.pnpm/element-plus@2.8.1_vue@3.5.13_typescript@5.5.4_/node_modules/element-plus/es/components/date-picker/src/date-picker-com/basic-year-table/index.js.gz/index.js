var q = Object.defineProperty;
var u = (x, k) => q(x, "name", { value: k, configurable: !0 });
import { defineComponent as G, ref as m, computed as T, watch as H, nextTick as J, openBlock as y, createElementBlock as p, unref as g, normalizeClass as V, createElementVNode as Q, Fragment as I, renderList as M, withKeys as A, withModifiers as E, createVNode as U } from "vue";
import f from "../../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { basicYearTableProps as W } from "../../props/basic-year-table/index.js";
import { getValidDateOfYear as X } from "../../utils/index.js";
import Z from "../basic-cell-render/index.js";
import ee from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { rangeArr as ae } from "../../../../time-picker/src/utils/index.js";
import { useNamespace as te } from "../../../../../hooks/use-namespace/index/index.js";
import { useLocale as re } from "../../../../../hooks/use-locale/index/index.js";
import { castArray as D } from "../../../../../utils/arrays/index.js";
import { hasClass as N } from "../../../../../utils/dom/style/index.js";
const ne = /* @__PURE__ */ G({
  __name: "basic-year-table",
  props: W,
  emits: ["changerange", "pick", "select"],
  setup(x, { expose: k, emit: d }) {
    const e = x, B = /* @__PURE__ */ u((t, a) => {
      const r = f(String(t)).locale(a).startOf("year"), o = r.endOf("year").dayOfYear();
      return ae(o).map((l) => r.add(l, "day").toDate());
    }, "datesInYear"), K = te("year-table"), { t: P, lang: v } = re(), C = m(), w = m(), _ = T(() => Math.floor(e.date.year() / 10) * 10), j = m([[], [], []]), h = m(), Y = m(), R = T(() => {
      var t;
      const a = j.value, r = f().locale(v.value).startOf("year");
      for (let n = 0; n < 3; n++) {
        const o = a[n];
        for (let l = 0; l < 4 && !(n * 4 + l >= 10); l++) {
          let s = o[l];
          s || (s = {
            row: n,
            column: l,
            type: "normal",
            inRange: !1,
            start: !1,
            end: !1,
            text: -1,
            disabled: !1
          }), s.type = "normal";
          const b = n * 4 + l + _.value, i = f().year(b), c = e.rangeState.endDate || e.maxDate || e.rangeState.selecting && e.minDate || null;
          s.inRange = !!(e.minDate && i.isSameOrAfter(e.minDate, "year") && c && i.isSameOrBefore(c, "year")) || !!(e.minDate && i.isSameOrBefore(e.minDate, "year") && c && i.isSameOrAfter(c, "year")), (t = e.minDate) != null && t.isSameOrAfter(c) ? (s.start = !!(c && i.isSame(c, "year")), s.end = !!(e.minDate && i.isSame(e.minDate, "year"))) : (s.start = !!(e.minDate && i.isSame(e.minDate, "year")), s.end = !!(c && i.isSame(c, "year"))), r.isSame(i) && (s.type = "today"), s.text = b;
          const F = i.toDate();
          s.disabled = e.disabledDate && e.disabledDate(F) || !1, o[l] = s;
        }
      }
      return a;
    }), L = /* @__PURE__ */ u(() => {
      var t;
      (t = w.value) == null || t.focus();
    }, "focus"), $ = /* @__PURE__ */ u((t) => {
      const a = {}, r = f().locale(v.value), n = t.text;
      return a.disabled = e.disabledDate ? B(n, v.value).every(e.disabledDate) : !1, a.today = r.year() === n, a.current = D(e.parsedValue).findIndex((o) => o.year() === n) >= 0, t.inRange && (a["in-range"] = !0, t.start && (a["start-date"] = !0), t.end && (a["end-date"] = !0)), a;
    }, "getCellKls"), S = /* @__PURE__ */ u((t) => {
      const a = t.text;
      return D(e.date).findIndex((r) => r.year() === a) >= 0;
    }, "isSelectedCell"), O = /* @__PURE__ */ u((t) => {
      var a;
      const r = (a = t.target) == null ? void 0 : a.closest("td");
      if (!r || !r.textContent || N(r, "disabled"))
        return;
      const n = r.cellIndex, l = r.parentNode.rowIndex * 4 + n + _.value, s = f().year(l);
      if (e.selectionMode === "range")
        e.rangeState.selecting ? (e.minDate && s >= e.minDate ? d("pick", { minDate: e.minDate, maxDate: s }) : d("pick", { minDate: s, maxDate: e.minDate }), d("select", !1)) : (d("pick", { minDate: s, maxDate: null }), d("select", !0));
      else if (e.selectionMode === "years") {
        if (t.type === "keydown") {
          d("pick", D(e.parsedValue), !1);
          return;
        }
        const b = X(s.startOf("year"), v.value, e.disabledDate), i = N(r, "current") ? D(e.parsedValue).filter((c) => (c == null ? void 0 : c.year()) !== l) : D(e.parsedValue).concat([b]);
        d("pick", i);
      } else
        d("pick", l);
    }, "handleYearTableClick"), z = /* @__PURE__ */ u((t) => {
      var a;
      if (!e.rangeState.selecting)
        return;
      const r = (a = t.target) == null ? void 0 : a.closest("td");
      if (!r)
        return;
      const n = r.parentNode.rowIndex, o = r.cellIndex;
      R.value[n][o].disabled || (n !== h.value || o !== Y.value) && (h.value = n, Y.value = o, d("changerange", {
        selecting: !0,
        endDate: f().year(_.value).add(n * 4 + o, "year")
      }));
    }, "handleMouseMove");
    return H(() => e.date, async () => {
      var t, a;
      (t = C.value) != null && t.contains(document.activeElement) && (await J(), (a = w.value) == null || a.focus());
    }), k({
      focus: L
    }), (t, a) => (y(), p("table", {
      role: "grid",
      "aria-label": g(P)("el.datepicker.yearTablePrompt"),
      class: V(g(K).b()),
      onClick: O,
      onMousemove: z
    }, [
      Q("tbody", {
        ref_key: "tbodyRef",
        ref: C
      }, [
        (y(!0), p(I, null, M(g(R), (r, n) => (y(), p("tr", { key: n }, [
          (y(!0), p(I, null, M(r, (o, l) => (y(), p("td", {
            key: `${n}_${l}`,
            ref_for: !0,
            ref: /* @__PURE__ */ u((s) => S(o) && (w.value = s), "ref"),
            class: V(["available", $(o)]),
            "aria-selected": S(o),
            "aria-label": String(o.text),
            tabindex: S(o) ? 0 : -1,
            onKeydown: [
              A(E(O, ["prevent", "stop"]), ["space"]),
              A(E(O, ["prevent", "stop"]), ["enter"])
            ]
          }, [
            U(g(Z), { cell: o }, null, 8, ["cell"])
          ], 42, ["aria-selected", "aria-label", "tabindex", "onKeydown"]))), 128))
        ]))), 128))
      ], 512)
    ], 42, ["aria-label"]));
  }
});
var be = /* @__PURE__ */ ee(ne, [["__file", "basic-year-table.vue"]]);
export {
  be as default
};
