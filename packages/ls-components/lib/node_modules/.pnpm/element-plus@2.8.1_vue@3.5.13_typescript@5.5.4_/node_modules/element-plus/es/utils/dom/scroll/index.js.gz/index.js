var h = Object.defineProperty;
var i = (e, o) => h(e, "name", { value: o, configurable: !0 });
import { getStyle as w } from "../style/index.js";
import { isClient as f } from "../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const a = /* @__PURE__ */ i((e, o) => {
  if (!f)
    return !1;
  const t = {
    undefined: "overflow",
    true: "overflow-y",
    false: "overflow-x"
  }[String(o)], l = w(e, t);
  return ["scroll", "auto", "overlay"].some((r) => l.includes(r));
}, "isScroll"), g = /* @__PURE__ */ i((e, o) => {
  if (!f)
    return;
  let t = e;
  for (; t; ) {
    if ([window, document, document.documentElement].includes(t))
      return window;
    if (a(t, o))
      return t;
    t = t.parentNode;
  }
  return t;
}, "getScrollContainer");
let s;
const S = /* @__PURE__ */ i((e) => {
  var o;
  if (!f)
    return 0;
  if (s !== void 0)
    return s;
  const t = document.createElement("div");
  t.className = `${e}-scrollbar__wrap`, t.style.visibility = "hidden", t.style.width = "100px", t.style.position = "absolute", t.style.top = "-9999px", document.body.appendChild(t);
  const l = t.offsetWidth;
  t.style.overflow = "scroll";
  const r = document.createElement("div");
  r.style.width = "100%", t.appendChild(r);
  const n = r.offsetWidth;
  return (o = t.parentNode) == null || o.removeChild(t), s = l - n, s;
}, "getScrollBarWidth");
function T(e, o) {
  if (!f)
    return;
  if (!o) {
    e.scrollTop = 0;
    return;
  }
  const t = [];
  let l = o.offsetParent;
  for (; l !== null && e !== l && e.contains(l); )
    t.push(l), l = l.offsetParent;
  const r = o.offsetTop + t.reduce((u, p) => u + p.offsetTop, 0), n = r + o.offsetHeight, c = e.scrollTop, d = c + e.clientHeight;
  r < c ? e.scrollTop = r : n > d && (e.scrollTop = n - e.clientHeight);
}
i(T, "scrollIntoView");
export {
  S as getScrollBarWidth,
  g as getScrollContainer,
  a as isScroll,
  T as scrollIntoView
};
