import { buildProps as r, definePropType as a } from "../../../../utils/vue/props/runtime/index.js";
import { isValidComponentSize as p } from "../../../../utils/vue/validator/index.js";
import { iconPropType as t } from "../../../../utils/vue/icon/index.js";
import { useAriaProps as m } from "../../../../hooks/use-aria/index/index.js";
import { UPDATE_MODEL_EVENT as l, CHANGE_EVENT as u, INPUT_EVENT as c } from "../../../../constants/event/index.js";
import { isBoolean as i, isNumber as o } from "../../../../utils/types/index.js";
import { isString as n } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
const E = r({
  modelValue: {
    type: [Boolean, String, Number],
    default: !1
  },
  disabled: Boolean,
  loading: Boolean,
  size: {
    type: String,
    validator: p
  },
  width: {
    type: [String, Number],
    default: ""
  },
  inlinePrompt: Boolean,
  inactiveActionIcon: {
    type: t
  },
  activeActionIcon: {
    type: t
  },
  activeIcon: {
    type: t
  },
  inactiveIcon: {
    type: t
  },
  activeText: {
    type: String,
    default: ""
  },
  inactiveText: {
    type: String,
    default: ""
  },
  activeValue: {
    type: [Boolean, String, Number],
    default: !0
  },
  inactiveValue: {
    type: [Boolean, String, Number],
    default: !1
  },
  name: {
    type: String,
    default: ""
  },
  validateEvent: {
    type: Boolean,
    default: !0
  },
  beforeChange: {
    type: a(Function)
  },
  id: String,
  tabindex: {
    type: [String, Number]
  },
  ...m(["ariaLabel"])
}), N = {
  [l]: (e) => i(e) || n(e) || o(e),
  [u]: (e) => i(e) || n(e) || o(e),
  [c]: (e) => i(e) || n(e) || o(e)
};
export {
  N as switchEmits,
  E as switchProps
};
