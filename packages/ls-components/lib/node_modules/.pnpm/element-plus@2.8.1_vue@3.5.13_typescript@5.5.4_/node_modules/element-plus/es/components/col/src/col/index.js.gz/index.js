var l = Object.defineProperty;
var e = (p, r) => l(p, "name", { value: r, configurable: !0 });
import { buildProps as b, definePropType as t } from "../../../../utils/vue/props/runtime/index.js";
import { mutable as u } from "../../../../utils/typescript/index.js";
const a = b({
  tag: {
    type: String,
    default: "div"
  },
  span: {
    type: Number,
    default: 24
  },
  offset: {
    type: Number,
    default: 0
  },
  pull: {
    type: Number,
    default: 0
  },
  push: {
    type: Number,
    default: 0
  },
  xs: {
    type: t([Number, Object]),
    default: /* @__PURE__ */ e(() => u({}), "default")
  },
  sm: {
    type: t([Number, Object]),
    default: /* @__PURE__ */ e(() => u({}), "default")
  },
  md: {
    type: t([Number, Object]),
    default: /* @__PURE__ */ e(() => u({}), "default")
  },
  lg: {
    type: t([Number, Object]),
    default: /* @__PURE__ */ e(() => u({}), "default")
  },
  xl: {
    type: t([Number, Object]),
    default: /* @__PURE__ */ e(() => u({}), "default")
  }
});
export {
  a as colProps
};
