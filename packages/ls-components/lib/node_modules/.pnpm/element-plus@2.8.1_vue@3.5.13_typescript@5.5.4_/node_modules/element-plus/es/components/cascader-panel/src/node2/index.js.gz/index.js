var B = Object.defineProperty;
var a = (e, p) => B(e, "name", { value: p, configurable: !0 });
import { defineComponent as F, inject as R, computed as l, resolveComponent as t, openBlock as s, createElementBlock as $, normalizeClass as C, createCommentVNode as c, createBlock as m, withModifiers as A, withCtx as b, createElementVNode as z, createVNode as g, Fragment as O } from "vue";
import { ElCheckbox as q } from "../../../checkbox/index/index.js";
import { ElRadio as J } from "../../../radio/index/index.js";
import { ElIcon as K } from "../../../icon/index/index.js";
import { Check as T, Loading as Y, ArrowRight as _ } from "@element-plus/icons-vue";
import G from "../node-content/index.js";
import { CASCADER_PANEL_INJECTION_KEY as Q } from "../types/index.js";
import W from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as X } from "../../../../hooks/use-namespace/index/index.js";
const Z = F({
  name: "ElCascaderNode",
  components: {
    ElCheckbox: q,
    ElRadio: J,
    NodeContent: G,
    ElIcon: K,
    Check: T,
    Loading: Y,
    ArrowRight: _
  },
  props: {
    node: {
      type: Object,
      required: !0
    },
    menuId: String
  },
  emits: ["expand"],
  setup(e, { emit: p }) {
    const o = R(Q), S = X("cascader-node"), h = l(() => o.isHoverMenu), E = l(() => o.config.multiple), i = l(() => o.config.checkStrictly), N = l(() => {
      var n;
      return (n = o.checkedNodes[0]) == null ? void 0 : n.uid;
    }), r = l(() => e.node.isDisabled), d = l(() => e.node.isLeaf), f = l(() => i.value && !d.value || !r.value), v = l(() => w(o.expandingNode)), y = l(() => i.value && o.checkedNodes.some(w)), w = /* @__PURE__ */ a((n) => {
      var u;
      const { level: U, uid: j } = e.node;
      return ((u = n == null ? void 0 : n.pathNodes[U - 1]) == null ? void 0 : u.uid) === j;
    }, "isInPath"), k = /* @__PURE__ */ a(() => {
      v.value || o.expandNode(e.node);
    }, "doExpand"), P = /* @__PURE__ */ a((n) => {
      const { node: u } = e;
      n !== u.checked && o.handleCheckChange(u, n);
    }, "doCheck"), V = /* @__PURE__ */ a(() => {
      o.lazyLoad(e.node, () => {
        d.value || k();
      });
    }, "doLoad"), D = /* @__PURE__ */ a((n) => {
      h.value && (L(), !d.value && p("expand", n));
    }, "handleHoverExpand"), L = /* @__PURE__ */ a(() => {
      const { node: n } = e;
      !f.value || n.loading || (n.loaded ? k() : V());
    }, "handleExpand"), H = /* @__PURE__ */ a(() => {
      h.value && !d.value || (d.value && !r.value && !i.value && !E.value ? I(!0) : L());
    }, "handleClick"), M = /* @__PURE__ */ a((n) => {
      i.value ? (P(n), e.node.loaded && k()) : I(n);
    }, "handleSelectCheck"), I = /* @__PURE__ */ a((n) => {
      e.node.loaded ? (P(n), !i.value && k()) : V();
    }, "handleCheck");
    return {
      panel: o,
      isHoverMenu: h,
      multiple: E,
      checkStrictly: i,
      checkedNodeId: N,
      isDisabled: r,
      isLeaf: d,
      expandable: f,
      inExpandingPath: v,
      inCheckedPath: y,
      ns: S,
      handleHoverExpand: D,
      handleExpand: L,
      handleClick: H,
      handleCheck: I,
      handleSelectCheck: M
    };
  }
});
function x(e, p, o, S, h, E) {
  const i = t("el-checkbox"), N = t("el-radio"), r = t("check"), d = t("el-icon"), f = t("node-content"), v = t("loading"), y = t("arrow-right");
  return s(), $("li", {
    id: `${e.menuId}-${e.node.uid}`,
    role: "menuitem",
    "aria-haspopup": !e.isLeaf,
    "aria-owns": e.isLeaf ? null : e.menuId,
    "aria-expanded": e.inExpandingPath,
    tabindex: e.expandable ? -1 : void 0,
    class: C([
      e.ns.b(),
      e.ns.is("selectable", e.checkStrictly),
      e.ns.is("active", e.node.checked),
      e.ns.is("disabled", !e.expandable),
      e.inExpandingPath && "in-active-path",
      e.inCheckedPath && "in-checked-path"
    ]),
    onMouseenter: e.handleHoverExpand,
    onFocus: e.handleHoverExpand,
    onClick: e.handleClick
  }, [
    c(" prefix "),
    e.multiple ? (s(), m(i, {
      key: 0,
      "model-value": e.node.checked,
      indeterminate: e.node.indeterminate,
      disabled: e.isDisabled,
      onClick: A(() => {
      }, ["stop"]),
      "onUpdate:modelValue": e.handleSelectCheck
    }, null, 8, ["model-value", "indeterminate", "disabled", "onClick", "onUpdate:modelValue"])) : e.checkStrictly ? (s(), m(N, {
      key: 1,
      "model-value": e.checkedNodeId,
      label: e.node.uid,
      disabled: e.isDisabled,
      "onUpdate:modelValue": e.handleSelectCheck,
      onClick: A(() => {
      }, ["stop"])
    }, {
      default: b(() => [
        c(`
        Add an empty element to avoid render label,
        do not use empty fragment here for https://github.com/vuejs/vue-next/pull/2485
      `),
        z("span")
      ]),
      _: 1
    }, 8, ["model-value", "label", "disabled", "onUpdate:modelValue", "onClick"])) : e.isLeaf && e.node.checked ? (s(), m(d, {
      key: 2,
      class: C(e.ns.e("prefix"))
    }, {
      default: b(() => [
        g(r)
      ]),
      _: 1
    }, 8, ["class"])) : c("v-if", !0),
    c(" content "),
    g(f),
    c(" postfix "),
    e.isLeaf ? c("v-if", !0) : (s(), $(O, { key: 3 }, [
      e.node.loading ? (s(), m(d, {
        key: 0,
        class: C([e.ns.is("loading"), e.ns.e("postfix")])
      }, {
        default: b(() => [
          g(v)
        ]),
        _: 1
      }, 8, ["class"])) : (s(), m(d, {
        key: 1,
        class: C(["arrow-right", e.ns.e("postfix")])
      }, {
        default: b(() => [
          g(y)
        ]),
        _: 1
      }, 8, ["class"]))
    ], 64))
  ], 42, ["id", "aria-haspopup", "aria-owns", "aria-expanded", "tabindex", "onMouseenter", "onFocus", "onClick"]);
}
a(x, "_sfc_render");
var re = /* @__PURE__ */ W(Z, [["render", x], ["__file", "node.vue"]]);
export {
  re as default
};
