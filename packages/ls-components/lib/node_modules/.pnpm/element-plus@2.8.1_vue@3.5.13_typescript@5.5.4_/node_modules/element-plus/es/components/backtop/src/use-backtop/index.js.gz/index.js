var d = Object.defineProperty;
var l = (t, r) => d(t, "name", { value: r, configurable: !0 });
import { shallowRef as i, ref as f, onMounted as h } from "vue";
import { useEventListener as g } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { throwError as T } from "../../../../utils/error/index.js";
import { useThrottleFn as b } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const x = /* @__PURE__ */ l((t, r, s) => {
  const e = i(), a = i(), n = f(!1), u = /* @__PURE__ */ l(() => {
    e.value && (n.value = e.value.scrollTop >= t.visibilityHeight);
  }, "handleScroll"), v = /* @__PURE__ */ l((o) => {
    var c;
    (c = e.value) == null || c.scrollTo({ top: 0, behavior: "smooth" }), r("click", o);
  }, "handleClick"), m = b(u, 300, !0);
  return g(a, "scroll", m), h(() => {
    var o;
    a.value = document, e.value = document.documentElement, t.target && (e.value = (o = document.querySelector(t.target)) != null ? o : void 0, e.value || T(s, `target does not exist: ${t.target}`), a.value = e.value), u();
  }), {
    visible: n,
    handleClick: v
  };
}, "useBackTop");
export {
  x as useBackTop
};
