var i = Object.defineProperty;
var e = (t, r) => i(t, "name", { value: r, configurable: !0 });
import { QuestionFilled as p } from "@element-plus/icons-vue";
import { buildProps as f } from "../../../../utils/vue/props/runtime/index.js";
import { buttonTypes as o } from "../../../button/src/button/index.js";
import { iconPropType as l } from "../../../../utils/vue/icon/index.js";
import { useTooltipContentProps as n } from "../../../tooltip/src/content/index.js";
const y = f({
  title: String,
  confirmButtonText: String,
  cancelButtonText: String,
  confirmButtonType: {
    type: String,
    values: o,
    default: "primary"
  },
  cancelButtonType: {
    type: String,
    values: o,
    default: "text"
  },
  icon: {
    type: l,
    default: /* @__PURE__ */ e(() => p, "default")
  },
  iconColor: {
    type: String,
    default: "#f90"
  },
  hideIcon: {
    type: Boolean,
    default: !1
  },
  hideAfter: {
    type: Number,
    default: 200
  },
  teleported: n.teleported,
  persistent: n.persistent,
  width: {
    type: [String, Number],
    default: 150
  }
}), g = {
  confirm: /* @__PURE__ */ e((t) => t instanceof MouseEvent, "confirm"),
  cancel: /* @__PURE__ */ e((t) => t instanceof MouseEvent, "cancel")
};
export {
  g as popconfirmEmits,
  y as popconfirmProps
};
