var r = Object.defineProperty;
var e = (o, l) => r(o, "name", { value: l, configurable: !0 });
import { dialogContentProps as a } from "../dialog-content/index.js";
import { buildProps as p, definePropType as t } from "../../../../utils/vue/props/runtime/index.js";
import { UPDATE_MODEL_EVENT as n } from "../../../../constants/event/index.js";
import { isBoolean as u } from "../../../../utils/types/index.js";
const m = p({
  ...a,
  appendToBody: Boolean,
  appendTo: {
    type: t([String, Object]),
    default: "body"
  },
  beforeClose: {
    type: t(Function)
  },
  destroyOnClose: Boolean,
  closeOnClickModal: {
    type: Boolean,
    default: !0
  },
  closeOnPressEscape: {
    type: Boolean,
    default: !0
  },
  lockScroll: {
    type: Boolean,
    default: !0
  },
  modal: {
    type: Boolean,
    default: !0
  },
  openDelay: {
    type: Number,
    default: 0
  },
  closeDelay: {
    type: Number,
    default: 0
  },
  top: {
    type: String
  },
  modelValue: Boolean,
  modalClass: String,
  width: {
    type: [String, Number]
  },
  zIndex: {
    type: Number
  },
  trapFocus: Boolean,
  headerAriaLevel: {
    type: String,
    default: "2"
  }
}), f = {
  open: /* @__PURE__ */ e(() => !0, "open"),
  opened: /* @__PURE__ */ e(() => !0, "opened"),
  close: /* @__PURE__ */ e(() => !0, "close"),
  closed: /* @__PURE__ */ e(() => !0, "closed"),
  [n]: (o) => u(o),
  openAutoFocus: /* @__PURE__ */ e(() => !0, "openAutoFocus"),
  closeAutoFocus: /* @__PURE__ */ e(() => !0, "closeAutoFocus")
};
export {
  f as dialogEmits,
  m as dialogProps
};
