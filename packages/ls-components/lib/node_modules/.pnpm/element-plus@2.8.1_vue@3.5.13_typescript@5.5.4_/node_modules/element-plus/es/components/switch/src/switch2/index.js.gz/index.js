var Q = Object.defineProperty;
var I = (V, w) => Q(V, "name", { value: w, configurable: !0 });
import { defineComponent as U, computed as u, ref as T, watch as D, onMounted as X, openBlock as i, createElementBlock as v, normalizeClass as s, unref as a, withModifiers as Y, createElementVNode as C, withKeys as Z, createBlock as c, withCtx as m, resolveDynamicComponent as p, createCommentVNode as r, toDisplayString as g, normalizeStyle as _, createVNode as x, renderSlot as K, nextTick as ee } from "vue";
import { isPromise as M } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { ElIcon as f } from "../../../icon/index/index.js";
import { Loading as ae } from "@element-plus/icons-vue";
import { switchProps as ie, switchEmits as te } from "../switch/index.js";
import ne from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useFormItem as oe, useFormItemInputId as le } from "../../../form/src/hooks/use-form-item/index.js";
import { useFormSize as ce, useFormDisabled as re } from "../../../form/src/hooks/use-form-common-props/index.js";
import { useNamespace as se } from "../../../../hooks/use-namespace/index/index.js";
import { addUnit as ue } from "../../../../utils/dom/style/index.js";
import { UPDATE_MODEL_EVENT as O, CHANGE_EVENT as z, INPUT_EVENT as F } from "../../../../constants/event/index.js";
import { debugWarn as L, throwError as ve } from "../../../../utils/error/index.js";
import { isBoolean as de } from "../../../../utils/types/index.js";
const N = "ElSwitch", me = U({
  name: N
}), fe = /* @__PURE__ */ U({
  ...me,
  props: ie,
  emits: te,
  setup(V, { expose: w, emit: d }) {
    const n = V, { formItem: k } = oe(), $ = ce(), t = se("switch"), { inputId: G } = le(n, {
      formItemContext: k
    }), b = re(u(() => n.loading)), P = T(n.modelValue !== !1), h = T(), H = T(), R = u(() => [
      t.b(),
      t.m($.value),
      t.is("disabled", b.value),
      t.is("checked", o.value)
    ]), W = u(() => [
      t.e("label"),
      t.em("label", "left"),
      t.is("active", !o.value)
    ]), j = u(() => [
      t.e("label"),
      t.em("label", "right"),
      t.is("active", o.value)
    ]), q = u(() => ({
      width: ue(n.width)
    }));
    D(() => n.modelValue, () => {
      P.value = !0;
    });
    const S = u(() => P.value ? n.modelValue : !1), o = u(() => S.value === n.activeValue);
    [n.activeValue, n.inactiveValue].includes(S.value) || (d(O, n.inactiveValue), d(z, n.inactiveValue), d(F, n.inactiveValue)), D(o, (e) => {
      var l;
      h.value.checked = e, n.validateEvent && ((l = k == null ? void 0 : k.validate) == null || l.call(k, "change").catch((B) => L(B)));
    });
    const y = /* @__PURE__ */ I(() => {
      const e = o.value ? n.inactiveValue : n.activeValue;
      d(O, e), d(z, e), d(F, e), ee(() => {
        h.value.checked = o.value;
      });
    }, "handleChange"), A = /* @__PURE__ */ I(() => {
      if (b.value)
        return;
      const { beforeChange: e } = n;
      if (!e) {
        y();
        return;
      }
      const l = e();
      [
        M(l),
        de(l)
      ].includes(!0) || ve(N, "beforeChange must return type `Promise<boolean>` or `boolean`"), M(l) ? l.then((E) => {
        E && y();
      }).catch((E) => {
        L(N, `some error occurred: ${E}`);
      }) : l && y();
    }, "switchValue"), J = /* @__PURE__ */ I(() => {
      var e, l;
      (l = (e = h.value) == null ? void 0 : e.focus) == null || l.call(e);
    }, "focus");
    return X(() => {
      h.value.checked = o.value;
    }), w({
      focus: J,
      checked: o
    }), (e, l) => (i(), v("div", {
      class: s(a(R)),
      onClick: Y(A, ["prevent"])
    }, [
      C("input", {
        id: a(G),
        ref_key: "input",
        ref: h,
        class: s(a(t).e("input")),
        type: "checkbox",
        role: "switch",
        "aria-checked": a(o),
        "aria-disabled": a(b),
        "aria-label": e.ariaLabel,
        name: e.name,
        "true-value": e.activeValue,
        "false-value": e.inactiveValue,
        disabled: a(b),
        tabindex: e.tabindex,
        onChange: y,
        onKeydown: Z(A, ["enter"])
      }, null, 42, ["id", "aria-checked", "aria-disabled", "aria-label", "name", "true-value", "false-value", "disabled", "tabindex", "onKeydown"]),
      !e.inlinePrompt && (e.inactiveIcon || e.inactiveText) ? (i(), v("span", {
        key: 0,
        class: s(a(W))
      }, [
        e.inactiveIcon ? (i(), c(a(f), { key: 0 }, {
          default: m(() => [
            (i(), c(p(e.inactiveIcon)))
          ]),
          _: 1
        })) : r("v-if", !0),
        !e.inactiveIcon && e.inactiveText ? (i(), v("span", {
          key: 1,
          "aria-hidden": a(o)
        }, g(e.inactiveText), 9, ["aria-hidden"])) : r("v-if", !0)
      ], 2)) : r("v-if", !0),
      C("span", {
        ref_key: "core",
        ref: H,
        class: s(a(t).e("core")),
        style: _(a(q))
      }, [
        e.inlinePrompt ? (i(), v("div", {
          key: 0,
          class: s(a(t).e("inner"))
        }, [
          e.activeIcon || e.inactiveIcon ? (i(), c(a(f), {
            key: 0,
            class: s(a(t).is("icon"))
          }, {
            default: m(() => [
              (i(), c(p(a(o) ? e.activeIcon : e.inactiveIcon)))
            ]),
            _: 1
          }, 8, ["class"])) : e.activeText || e.inactiveText ? (i(), v("span", {
            key: 1,
            class: s(a(t).is("text")),
            "aria-hidden": !a(o)
          }, g(a(o) ? e.activeText : e.inactiveText), 11, ["aria-hidden"])) : r("v-if", !0)
        ], 2)) : r("v-if", !0),
        C("div", {
          class: s(a(t).e("action"))
        }, [
          e.loading ? (i(), c(a(f), {
            key: 0,
            class: s(a(t).is("loading"))
          }, {
            default: m(() => [
              x(a(ae))
            ]),
            _: 1
          }, 8, ["class"])) : a(o) ? K(e.$slots, "active-action", { key: 1 }, () => [
            e.activeActionIcon ? (i(), c(a(f), { key: 0 }, {
              default: m(() => [
                (i(), c(p(e.activeActionIcon)))
              ]),
              _: 1
            })) : r("v-if", !0)
          ]) : a(o) ? r("v-if", !0) : K(e.$slots, "inactive-action", { key: 2 }, () => [
            e.inactiveActionIcon ? (i(), c(a(f), { key: 0 }, {
              default: m(() => [
                (i(), c(p(e.inactiveActionIcon)))
              ]),
              _: 1
            })) : r("v-if", !0)
          ])
        ], 2)
      ], 6),
      !e.inlinePrompt && (e.activeIcon || e.activeText) ? (i(), v("span", {
        key: 1,
        class: s(a(j))
      }, [
        e.activeIcon ? (i(), c(a(f), { key: 0 }, {
          default: m(() => [
            (i(), c(p(e.activeIcon)))
          ]),
          _: 1
        })) : r("v-if", !0),
        !e.activeIcon && e.activeText ? (i(), v("span", {
          key: 1,
          "aria-hidden": !a(o)
        }, g(e.activeText), 9, ["aria-hidden"])) : r("v-if", !0)
      ], 2)) : r("v-if", !0)
    ], 10, ["onClick"]));
  }
});
var Se = /* @__PURE__ */ ne(fe, [["__file", "switch.vue"]]);
export {
  Se as default
};
