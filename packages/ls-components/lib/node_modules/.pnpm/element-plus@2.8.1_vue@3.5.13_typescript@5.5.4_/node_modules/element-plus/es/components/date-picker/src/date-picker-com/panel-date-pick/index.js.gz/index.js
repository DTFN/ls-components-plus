var ra = Object.defineProperty;
var r = (Q, V) => ra(Q, "name", { value: V, configurable: !0 });
import { defineComponent as oa, useAttrs as sa, useSlots as ua, inject as we, toRef as ia, ref as _, computed as p, watch as J, openBlock as P, createElementBlock as N, normalizeClass as c, unref as a, createElementVNode as y, renderSlot as E, Fragment as ca, renderList as da, toDisplayString as L, createCommentVNode as z, createVNode as w, withDirectives as F, withCtx as Y, vShow as R, withKeys as De, createBlock as oe, createTextVNode as Ve, nextTick as q } from "vue";
import k from "../../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { ElButton as ge } from "../../../../button/index/index.js";
import { ElInput as Ce } from "../../../../input/index/index.js";
import { ElIcon as G } from "../../../../icon/index/index.js";
import { DArrowLeft as va, ArrowLeft as ma, ArrowRight as pa, DArrowRight as fa } from "@element-plus/icons-vue";
import { panelDatePickProps as ha } from "../../props/panel-date-pick/index.js";
import { getValidDateOfMonth as Te, getValidDateOfYear as Pe } from "../../utils/index.js";
import ya from "../basic-date-table/index.js";
import ka from "../basic-month-table/index.js";
import ba from "../basic-year-table/index.js";
import wa from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as $e } from "../../../../../hooks/use-namespace/index/index.js";
import { useLocale as Da } from "../../../../../hooks/use-locale/index/index.js";
import { TOOLTIP_INJECTION_KEY as Va } from "../../../../tooltip/src/constants/index.js";
import { isArray as se, isFunction as _e } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { extractTimeFormat as ga, extractDateFormat as Ca } from "../../../../time-picker/src/utils/index.js";
import { EVENT_CODE as D } from "../../../../../constants/aria/index.js";
import Ta from "../../../../time-picker/src/time-picker-com/panel-time-pick/index.js";
import Pa from "../../../../../directives/click-outside/index/index.js";
const $a = /* @__PURE__ */ oa({
  __name: "panel-date-pick",
  props: ha,
  emits: ["pick", "set-picker-option", "panel-change"],
  setup(Q, { emit: V }) {
    const o = Q, Fe = /* @__PURE__ */ r((e, t, l) => !0, "timeWithinRange"), f = $e("picker-panel"), g = $e("date-picker"), Me = sa(), Ie = ua(), { t: C, lang: v } = Da(), ue = we("EP_PICKER_BASE"), ie = we(Va), { shortcuts: ce, disabledDate: d, cellClassName: Ne, defaultTime: X } = ue.props, K = ia(ue.props, "defaultValue"), U = _(), n = _(k().locale(v.value)), Z = _(!1);
    let j = !1;
    const de = p(() => k(X).locale(v.value)), Ye = p(() => n.value.month()), ve = p(() => n.value.year()), x = _([]), M = _(null), I = _(null), ee = /* @__PURE__ */ r((e) => x.value.length > 0 ? Fe(e, x.value, o.format || "HH:mm:ss") : !0, "checkDateWithinRange"), me = /* @__PURE__ */ r((e) => X && !ke.value && !Z.value && !j ? de.value.year(e.year()).month(e.month()).date(e.date()) : S.value ? e.millisecond(0) : e.startOf("day"), "formatEmit"), m = /* @__PURE__ */ r((e, ...t) => {
      if (!e)
        V("pick", e, ...t);
      else if (se(e)) {
        const l = e.map(me);
        V("pick", l, ...t);
      } else
        V("pick", me(e), ...t);
      M.value = null, I.value = null, Z.value = !1, j = !1;
    }, "emit"), Re = /* @__PURE__ */ r(async (e, t) => {
      if (i.value === "date") {
        e = e;
        let l = o.parsedValue ? o.parsedValue.year(e.year()).month(e.month()).date(e.date()) : e;
        ee(l) || (l = x.value[0][0].year(e.year()).month(e.month()).date(e.date())), n.value = l, m(l, S.value || t), o.type === "datetime" && (await q(), B());
      } else i.value === "week" ? m(e.date) : i.value === "dates" && m(e, !0);
    }, "handleDatePick"), pe = /* @__PURE__ */ r((e) => {
      const t = e ? "add" : "subtract";
      n.value = n.value[t](1, "month"), W("month");
    }, "moveByMonth"), fe = /* @__PURE__ */ r((e) => {
      const t = n.value, l = e ? "add" : "subtract";
      n.value = u.value === "year" ? t[l](10, "year") : t[l](1, "year"), W("year");
    }, "moveByYear"), u = _("date"), Ke = p(() => {
      const e = C("el.datepicker.year");
      if (u.value === "year") {
        const t = Math.floor(ve.value / 10) * 10;
        return e ? `${t} ${e} - ${t + 9} ${e}` : `${t} - ${t + 9}`;
      }
      return `${ve.value} ${e}`;
    }), Se = /* @__PURE__ */ r((e) => {
      const t = _e(e.value) ? e.value() : e.value;
      if (t) {
        j = !0, m(k(t).locale(v.value));
        return;
      }
      e.onClick && e.onClick({
        attrs: Me,
        slots: Ie,
        emit: V
      });
    }, "handleShortcutClick"), i = p(() => {
      const { type: e } = o;
      return ["week", "month", "months", "year", "years", "dates"].includes(e) ? e : "date";
    }), ae = p(() => i.value === "dates" || i.value === "months" || i.value === "years"), Ae = p(() => i.value === "date" ? u.value : i.value), he = p(() => !!ce.length), Be = /* @__PURE__ */ r(async (e, t) => {
      i.value === "month" ? (n.value = Te(n.value.year(), e, v.value, d), m(n.value, !1)) : i.value === "months" ? m(e, t ?? !0) : (n.value = Te(n.value.year(), e, v.value, d), u.value = "date", ["month", "year", "date", "week"].includes(i.value) && (m(n.value, !0), await q(), B())), W("month");
    }, "handleMonthPick"), Oe = /* @__PURE__ */ r(async (e, t) => {
      if (i.value === "year") {
        const l = n.value.startOf("year").year(e);
        n.value = Pe(l, v.value, d), m(n.value, !1);
      } else if (i.value === "years")
        m(e, t ?? !0);
      else {
        const l = n.value.year(e);
        n.value = Pe(l, v.value, d), u.value = "month", ["month", "year", "date", "week"].includes(i.value) && (m(n.value, !0), await q(), B());
      }
      W("year");
    }, "handleYearPick"), H = /* @__PURE__ */ r(async (e) => {
      u.value = e, await q(), B();
    }, "showPicker"), S = p(() => o.type === "datetime" || o.type === "datetimerange"), Ee = p(() => {
      const e = S.value || i.value === "dates", t = i.value === "years", l = i.value === "months", h = u.value === "date", b = u.value === "year", $ = u.value === "month";
      return e && h || t && b || l && $;
    }), Le = p(() => d ? o.parsedValue ? se(o.parsedValue) ? d(o.parsedValue[0].toDate()) : d(o.parsedValue.toDate()) : !0 : !1), ze = /* @__PURE__ */ r(() => {
      if (ae.value)
        m(o.parsedValue);
      else {
        let e = o.parsedValue;
        if (!e) {
          const t = k(X).locale(v.value), l = ne();
          e = t.year(l.year()).month(l.month()).date(l.date());
        }
        n.value = e, m(e);
      }
    }, "onConfirm"), Ue = p(() => d ? d(k().locale(v.value).toDate()) : !1), He = /* @__PURE__ */ r(() => {
      const t = k().locale(v.value).toDate();
      Z.value = !0, (!d || !d(t)) && ee(t) && (n.value = k().locale(v.value), m(n.value));
    }, "changeToNow"), te = p(() => o.timeFormat || ga(o.format)), ye = p(() => o.dateFormat || Ca(o.format)), ke = p(() => {
      if (I.value)
        return I.value;
      if (!(!o.parsedValue && !K.value))
        return (o.parsedValue || n.value).format(te.value);
    }), We = p(() => {
      if (M.value)
        return M.value;
      if (!(!o.parsedValue && !K.value))
        return (o.parsedValue || n.value).format(ye.value);
    }), A = _(!1), Je = /* @__PURE__ */ r(() => {
      A.value = !0;
    }, "onTimePickerInputFocus"), qe = /* @__PURE__ */ r(() => {
      A.value = !1;
    }, "handleTimePickClose"), le = /* @__PURE__ */ r((e) => ({
      hour: e.hour(),
      minute: e.minute(),
      second: e.second(),
      year: e.year(),
      month: e.month(),
      date: e.date()
    }), "getUnits"), Ge = /* @__PURE__ */ r((e, t, l) => {
      const { hour: h, minute: b, second: $ } = le(e), re = o.parsedValue ? o.parsedValue.hour(h).minute(b).second($) : e;
      n.value = re, m(n.value, !0), l || (A.value = t);
    }, "handleTimePick"), Qe = /* @__PURE__ */ r((e) => {
      const t = k(e, te.value).locale(v.value);
      if (t.isValid() && ee(t)) {
        const { year: l, month: h, date: b } = le(n.value);
        n.value = t.year(l).month(h).date(b), I.value = null, A.value = !1, m(n.value, !0);
      }
    }, "handleVisibleTimeChange"), Xe = /* @__PURE__ */ r((e) => {
      const t = k(e, ye.value).locale(v.value);
      if (t.isValid()) {
        if (d && d(t.toDate()))
          return;
        const { hour: l, minute: h, second: b } = le(n.value);
        n.value = t.hour(l).minute(h).second(b), M.value = null, m(n.value, !0);
      }
    }, "handleVisibleDateChange"), Ze = /* @__PURE__ */ r((e) => k.isDayjs(e) && e.isValid() && (d ? !d(e.toDate()) : !0), "isValidValue"), je = /* @__PURE__ */ r((e) => se(e) ? e.map((t) => t.format(o.format)) : e.format(o.format), "formatToString"), xe = /* @__PURE__ */ r((e) => k(e, o.format).locale(v.value), "parseUserInput"), ne = /* @__PURE__ */ r(() => {
      const e = k(K.value).locale(v.value);
      if (!K.value) {
        const t = de.value;
        return k().hour(t.hour()).minute(t.minute()).second(t.second()).locale(v.value);
      }
      return e;
    }, "getDefaultValue"), B = /* @__PURE__ */ r(async () => {
      var e;
      ["week", "month", "year", "date"].includes(i.value) && ((e = U.value) == null || e.focus(), i.value === "week" && be(D.down));
    }, "handleFocusPicker"), ea = /* @__PURE__ */ r((e) => {
      const { code: t } = e;
      [
        D.up,
        D.down,
        D.left,
        D.right,
        D.home,
        D.end,
        D.pageUp,
        D.pageDown
      ].includes(t) && (be(t), e.stopPropagation(), e.preventDefault()), [D.enter, D.space, D.numpadEnter].includes(t) && M.value === null && I.value === null && (e.preventDefault(), m(n.value, !1));
    }, "handleKeydownTable"), be = /* @__PURE__ */ r((e) => {
      var t;
      const { up: l, down: h, left: b, right: $, home: re, end: aa, pageUp: ta, pageDown: la } = D, na = {
        year: {
          [l]: -4,
          [h]: 4,
          [b]: -1,
          [$]: 1,
          offset: /* @__PURE__ */ r((s, T) => s.setFullYear(s.getFullYear() + T), "offset")
        },
        month: {
          [l]: -4,
          [h]: 4,
          [b]: -1,
          [$]: 1,
          offset: /* @__PURE__ */ r((s, T) => s.setMonth(s.getMonth() + T), "offset")
        },
        week: {
          [l]: -1,
          [h]: 1,
          [b]: -1,
          [$]: 1,
          offset: /* @__PURE__ */ r((s, T) => s.setDate(s.getDate() + T * 7), "offset")
        },
        date: {
          [l]: -7,
          [h]: 7,
          [b]: -1,
          [$]: 1,
          [re]: (s) => -s.getDay(),
          [aa]: (s) => -s.getDay() + 6,
          [ta]: (s) => -new Date(s.getFullYear(), s.getMonth(), 0).getDate(),
          [la]: (s) => new Date(s.getFullYear(), s.getMonth() + 1, 0).getDate(),
          offset: /* @__PURE__ */ r((s, T) => s.setDate(s.getDate() + T), "offset")
        }
      }, O = n.value.toDate();
      for (; Math.abs(n.value.diff(O, "year", !0)) < 1; ) {
        const s = na[Ae.value];
        if (!s)
          return;
        if (s.offset(O, _e(s[e]) ? s[e](O) : (t = s[e]) != null ? t : 0), d && d(O))
          break;
        const T = k(O).locale(v.value);
        n.value = T, V("pick", T, !0);
        break;
      }
    }, "handleKeyControl"), W = /* @__PURE__ */ r((e) => {
      V("panel-change", n.value.toDate(), e, u.value);
    }, "handlePanelChange");
    return J(() => i.value, (e) => {
      if (["month", "year"].includes(e)) {
        u.value = e;
        return;
      } else if (e === "years") {
        u.value = "year";
        return;
      } else if (e === "months") {
        u.value = "month";
        return;
      }
      u.value = "date";
    }, { immediate: !0 }), J(() => u.value, () => {
      ie == null || ie.updatePopper();
    }), J(() => K.value, (e) => {
      e && (n.value = ne());
    }, { immediate: !0 }), J(() => o.parsedValue, (e) => {
      if (e) {
        if (ae.value || Array.isArray(e))
          return;
        n.value = e;
      } else
        n.value = ne();
    }, { immediate: !0 }), V("set-picker-option", ["isValidValue", Ze]), V("set-picker-option", ["formatToString", je]), V("set-picker-option", ["parseUserInput", xe]), V("set-picker-option", ["handleFocusPicker", B]), (e, t) => (P(), N("div", {
      class: c([
        a(f).b(),
        a(g).b(),
        {
          "has-sidebar": e.$slots.sidebar || a(he),
          "has-time": a(S)
        }
      ])
    }, [
      y("div", {
        class: c(a(f).e("body-wrapper"))
      }, [
        E(e.$slots, "sidebar", {
          class: c(a(f).e("sidebar"))
        }),
        a(he) ? (P(), N("div", {
          key: 0,
          class: c(a(f).e("sidebar"))
        }, [
          (P(!0), N(ca, null, da(a(ce), (l, h) => (P(), N("button", {
            key: h,
            type: "button",
            class: c(a(f).e("shortcut")),
            onClick: /* @__PURE__ */ r((b) => Se(l), "onClick")
          }, L(l.text), 11, ["onClick"]))), 128))
        ], 2)) : z("v-if", !0),
        y("div", {
          class: c(a(f).e("body"))
        }, [
          a(S) ? (P(), N("div", {
            key: 0,
            class: c(a(g).e("time-header"))
          }, [
            y("span", {
              class: c(a(g).e("editor-wrap"))
            }, [
              w(a(Ce), {
                placeholder: a(C)("el.datepicker.selectDate"),
                "model-value": a(We),
                size: "small",
                "validate-event": !1,
                onInput: /* @__PURE__ */ r((l) => M.value = l, "onInput"),
                onChange: Xe
              }, null, 8, ["placeholder", "model-value", "onInput"])
            ], 2),
            F((P(), N("span", {
              class: c(a(g).e("editor-wrap"))
            }, [
              w(a(Ce), {
                placeholder: a(C)("el.datepicker.selectTime"),
                "model-value": a(ke),
                size: "small",
                "validate-event": !1,
                onFocus: Je,
                onInput: /* @__PURE__ */ r((l) => I.value = l, "onInput"),
                onChange: Qe
              }, null, 8, ["placeholder", "model-value", "onInput"]),
              w(a(Ta), {
                visible: A.value,
                format: a(te),
                "parsed-value": n.value,
                onPick: Ge
              }, null, 8, ["visible", "format", "parsed-value"])
            ], 2)), [
              [a(Pa), qe]
            ])
          ], 2)) : z("v-if", !0),
          F(y("div", {
            class: c([
              a(g).e("header"),
              (u.value === "year" || u.value === "month") && a(g).e("header--bordered")
            ])
          }, [
            y("span", {
              class: c(a(g).e("prev-btn"))
            }, [
              y("button", {
                type: "button",
                "aria-label": a(C)("el.datepicker.prevYear"),
                class: c(["d-arrow-left", a(f).e("icon-btn")]),
                onClick: /* @__PURE__ */ r((l) => fe(!1), "onClick")
              }, [
                E(e.$slots, "prev-year", {}, () => [
                  w(a(G), null, {
                    default: Y(() => [
                      w(a(va))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["aria-label", "onClick"]),
              F(y("button", {
                type: "button",
                "aria-label": a(C)("el.datepicker.prevMonth"),
                class: c([a(f).e("icon-btn"), "arrow-left"]),
                onClick: /* @__PURE__ */ r((l) => pe(!1), "onClick")
              }, [
                E(e.$slots, "prev-month", {}, () => [
                  w(a(G), null, {
                    default: Y(() => [
                      w(a(ma))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["aria-label", "onClick"]), [
                [R, u.value === "date"]
              ])
            ], 2),
            y("span", {
              role: "button",
              class: c(a(g).e("header-label")),
              "aria-live": "polite",
              tabindex: "0",
              onKeydown: De((l) => H("year"), ["enter"]),
              onClick: /* @__PURE__ */ r((l) => H("year"), "onClick")
            }, L(a(Ke)), 43, ["onKeydown", "onClick"]),
            F(y("span", {
              role: "button",
              "aria-live": "polite",
              tabindex: "0",
              class: c([
                a(g).e("header-label"),
                { active: u.value === "month" }
              ]),
              onKeydown: De((l) => H("month"), ["enter"]),
              onClick: /* @__PURE__ */ r((l) => H("month"), "onClick")
            }, L(a(C)(`el.datepicker.month${a(Ye) + 1}`)), 43, ["onKeydown", "onClick"]), [
              [R, u.value === "date"]
            ]),
            y("span", {
              class: c(a(g).e("next-btn"))
            }, [
              F(y("button", {
                type: "button",
                "aria-label": a(C)("el.datepicker.nextMonth"),
                class: c([a(f).e("icon-btn"), "arrow-right"]),
                onClick: /* @__PURE__ */ r((l) => pe(!0), "onClick")
              }, [
                E(e.$slots, "next-month", {}, () => [
                  w(a(G), null, {
                    default: Y(() => [
                      w(a(pa))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["aria-label", "onClick"]), [
                [R, u.value === "date"]
              ]),
              y("button", {
                type: "button",
                "aria-label": a(C)("el.datepicker.nextYear"),
                class: c([a(f).e("icon-btn"), "d-arrow-right"]),
                onClick: /* @__PURE__ */ r((l) => fe(!0), "onClick")
              }, [
                E(e.$slots, "next-year", {}, () => [
                  w(a(G), null, {
                    default: Y(() => [
                      w(a(fa))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["aria-label", "onClick"])
            ], 2)
          ], 2), [
            [R, u.value !== "time"]
          ]),
          y("div", {
            class: c(a(f).e("content")),
            onKeydown: ea
          }, [
            u.value === "date" ? (P(), oe(ya, {
              key: 0,
              ref_key: "currentViewRef",
              ref: U,
              "selection-mode": a(i),
              date: n.value,
              "parsed-value": e.parsedValue,
              "disabled-date": a(d),
              "cell-class-name": a(Ne),
              onPick: Re
            }, null, 8, ["selection-mode", "date", "parsed-value", "disabled-date", "cell-class-name"])) : z("v-if", !0),
            u.value === "year" ? (P(), oe(ba, {
              key: 1,
              ref_key: "currentViewRef",
              ref: U,
              "selection-mode": a(i),
              date: n.value,
              "disabled-date": a(d),
              "parsed-value": e.parsedValue,
              onPick: Oe
            }, null, 8, ["selection-mode", "date", "disabled-date", "parsed-value"])) : z("v-if", !0),
            u.value === "month" ? (P(), oe(ka, {
              key: 2,
              ref_key: "currentViewRef",
              ref: U,
              "selection-mode": a(i),
              date: n.value,
              "parsed-value": e.parsedValue,
              "disabled-date": a(d),
              onPick: Be
            }, null, 8, ["selection-mode", "date", "parsed-value", "disabled-date"])) : z("v-if", !0)
          ], 34)
        ], 2)
      ], 2),
      F(y("div", {
        class: c(a(f).e("footer"))
      }, [
        F(w(a(ge), {
          text: "",
          size: "small",
          class: c(a(f).e("link-btn")),
          disabled: a(Ue),
          onClick: He
        }, {
          default: Y(() => [
            Ve(L(a(C)("el.datepicker.now")), 1)
          ]),
          _: 1
        }, 8, ["class", "disabled"]), [
          [R, !a(ae)]
        ]),
        w(a(ge), {
          plain: "",
          size: "small",
          class: c(a(f).e("link-btn")),
          disabled: a(Le),
          onClick: ze
        }, {
          default: Y(() => [
            Ve(L(a(C)("el.datepicker.confirm")), 1)
          ]),
          _: 1
        }, 8, ["class", "disabled"])
      ], 2), [
        [R, a(Ee)]
      ])
    ], 2));
  }
});
var Qa = /* @__PURE__ */ wa($a, [["__file", "panel-date-pick.vue"]]);
export {
  Qa as default
};
