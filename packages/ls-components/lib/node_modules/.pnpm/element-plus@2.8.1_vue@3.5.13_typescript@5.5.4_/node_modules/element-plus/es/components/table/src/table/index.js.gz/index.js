var te = Object.defineProperty;
var H = (e, i) => te(e, "name", { value: i, configurable: !0 });
import { defineComponent as se, getCurrentInstance as ae, provide as ne, computed as v, resolveComponent as b, resolveDirective as ie, openBlock as r, createElementBlock as d, normalizeClass as o, normalizeStyle as u, createElementVNode as t, renderSlot as k, withDirectives as L, createVNode as a, createCommentVNode as n, withCtx as de, createBlock as M, createTextVNode as ue, toDisplayString as me, vShow as R } from "vue";
import { ElScrollbar as pe } from "../../../scrollbar/index/index.js";
import { createStore as be } from "../store/helper/index.js";
import ye from "../table-layout/index.js";
import fe from "../table-header/index/index.js";
import he from "../table-body/index/index.js";
import ce from "../table-footer/index/index.js";
import ve from "./utils-helper/index.js";
import { convertToRows as we } from "../table-header/utils-helper/index.js";
import Se from "./style-helper/index.js";
import ge from "./key-render-helper/index.js";
import Te from "./defaults/index.js";
import { TABLE_INJECTION_KEY as ke } from "../tokens/index.js";
import { hColgroup as Le } from "../h-helper/index.js";
import { useScrollbar as Ce } from "../composables/use-scrollbar/index.js";
import Ee from "../../../../_virtual/plugin-vue_export-helper/index.js";
import Ve from "../../../../directives/mousewheel/index/index.js";
import { useLocale as Be } from "../../../../hooks/use-locale/index/index.js";
import { useNamespace as He } from "../../../../hooks/use-namespace/index/index.js";
import Me from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/debounce/index.js";
let Re = 1;
const $e = se({
  name: "ElTable",
  directives: {
    Mousewheel: Ve
  },
  components: {
    TableHeader: fe,
    TableBody: he,
    TableFooter: ce,
    ElScrollbar: pe,
    hColgroup: Le
  },
  props: Te,
  emits: [
    "select",
    "select-all",
    "selection-change",
    "cell-mouse-enter",
    "cell-mouse-leave",
    "cell-contextmenu",
    "cell-click",
    "cell-dblclick",
    "row-click",
    "row-contextmenu",
    "row-dblclick",
    "header-click",
    "header-contextmenu",
    "sort-change",
    "filter-change",
    "current-change",
    "header-dragend",
    "expand-change"
  ],
  setup(e) {
    const { t: i } = Be(), w = He("table"), l = ae();
    ne(ke, l);
    const s = be(l, e);
    l.store = s;
    const y = new ye({
      store: l.store,
      table: l,
      fit: e.fit,
      showHeader: e.showHeader
    });
    l.layout = y;
    const m = v(() => (s.states.data.value || []).length === 0), {
      setCurrentRow: f,
      getSelectionRows: S,
      toggleRowSelection: h,
      clearSelection: g,
      clearFilter: c,
      toggleAllSelection: $,
      toggleRowExpansion: D,
      clearSort: z,
      sort: N
    } = ve(s), {
      isHidden: I,
      renderExpanded: W,
      setDragVisible: F,
      isGroup: C,
      handleMouseLeave: G,
      handleHeaderFooterMousewheel: P,
      tableSize: A,
      emptyBlockStyle: O,
      handleFixedMousewheel: K,
      resizeProxyVisible: U,
      bodyWidth: Y,
      resizeState: E,
      doLayout: T,
      tableBodyStyles: J,
      tableLayout: X,
      scrollbarViewStyle: j,
      tableInnerStyle: q,
      scrollbarStyle: Q
    } = Se(e, y, s, l), { scrollBarRef: Z, scrollTo: x, setScrollLeft: _, setScrollTop: ee } = Ce(), V = Me(T, 50), B = `${w.namespace.value}-table_${Re++}`;
    l.tableId = B, l.state = {
      isGroup: C,
      resizeState: E,
      doLayout: T,
      debouncedUpdateLayout: V
    };
    const oe = v(() => {
      var p;
      return (p = e.sumText) != null ? p : i("el.table.sumText");
    }), le = v(() => {
      var p;
      return (p = e.emptyText) != null ? p : i("el.table.emptyText");
    }), re = v(() => we(s.states.originColumns.value)[0]);
    return ge(l), {
      ns: w,
      layout: y,
      store: s,
      columns: re,
      handleHeaderFooterMousewheel: P,
      handleMouseLeave: G,
      tableId: B,
      tableSize: A,
      isHidden: I,
      isEmpty: m,
      renderExpanded: W,
      resizeProxyVisible: U,
      resizeState: E,
      isGroup: C,
      bodyWidth: Y,
      tableBodyStyles: J,
      emptyBlockStyle: O,
      debouncedUpdateLayout: V,
      handleFixedMousewheel: K,
      setCurrentRow: f,
      getSelectionRows: S,
      toggleRowSelection: h,
      clearSelection: g,
      clearFilter: c,
      toggleAllSelection: $,
      toggleRowExpansion: D,
      clearSort: z,
      doLayout: T,
      sort: N,
      t: i,
      setDragVisible: F,
      context: l,
      computedSumText: oe,
      computedEmptyText: le,
      tableLayout: X,
      scrollbarViewStyle: j,
      tableInnerStyle: q,
      scrollbarStyle: Q,
      scrollBarRef: Z,
      scrollTo: x,
      setScrollLeft: _,
      setScrollTop: ee
    };
  }
});
function De(e, i, w, l, s, y) {
  const m = b("hColgroup"), f = b("table-header"), S = b("table-body"), h = b("table-footer"), g = b("el-scrollbar"), c = ie("mousewheel");
  return r(), d("div", {
    ref: "tableWrapper",
    class: o([
      {
        [e.ns.m("fit")]: e.fit,
        [e.ns.m("striped")]: e.stripe,
        [e.ns.m("border")]: e.border || e.isGroup,
        [e.ns.m("hidden")]: e.isHidden,
        [e.ns.m("group")]: e.isGroup,
        [e.ns.m("fluid-height")]: e.maxHeight,
        [e.ns.m("scrollable-x")]: e.layout.scrollX.value,
        [e.ns.m("scrollable-y")]: e.layout.scrollY.value,
        [e.ns.m("enable-row-hover")]: !e.store.states.isComplex.value,
        [e.ns.m("enable-row-transition")]: (e.store.states.data.value || []).length !== 0 && (e.store.states.data.value || []).length < 100,
        "has-footer": e.showSummary
      },
      e.ns.m(e.tableSize),
      e.className,
      e.ns.b(),
      e.ns.m(`layout-${e.tableLayout}`)
    ]),
    style: u(e.style),
    "data-prefix": e.ns.namespace.value,
    onMouseleave: e.handleMouseLeave
  }, [
    t("div", {
      class: o(e.ns.e("inner-wrapper")),
      style: u(e.tableInnerStyle)
    }, [
      t("div", {
        ref: "hiddenColumns",
        class: "hidden-columns"
      }, [
        k(e.$slots, "default")
      ], 512),
      e.showHeader && e.tableLayout === "fixed" ? L((r(), d("div", {
        key: 0,
        ref: "headerWrapper",
        class: o(e.ns.e("header-wrapper"))
      }, [
        t("table", {
          ref: "tableHeader",
          class: o(e.ns.e("header")),
          style: u(e.tableBodyStyles),
          border: "0",
          cellpadding: "0",
          cellspacing: "0"
        }, [
          a(m, {
            columns: e.store.states.columns.value,
            "table-layout": e.tableLayout
          }, null, 8, ["columns", "table-layout"]),
          a(f, {
            ref: "tableHeaderRef",
            border: e.border,
            "default-sort": e.defaultSort,
            store: e.store,
            onSetDragVisible: e.setDragVisible
          }, null, 8, ["border", "default-sort", "store", "onSetDragVisible"])
        ], 6)
      ], 2)), [
        [c, e.handleHeaderFooterMousewheel]
      ]) : n("v-if", !0),
      t("div", {
        ref: "bodyWrapper",
        class: o(e.ns.e("body-wrapper"))
      }, [
        a(g, {
          ref: "scrollBarRef",
          "view-style": e.scrollbarViewStyle,
          "wrap-style": e.scrollbarStyle,
          always: e.scrollbarAlwaysOn
        }, {
          default: de(() => [
            t("table", {
              ref: "tableBody",
              class: o(e.ns.e("body")),
              cellspacing: "0",
              cellpadding: "0",
              border: "0",
              style: u({
                width: e.bodyWidth,
                tableLayout: e.tableLayout
              })
            }, [
              a(m, {
                columns: e.store.states.columns.value,
                "table-layout": e.tableLayout
              }, null, 8, ["columns", "table-layout"]),
              e.showHeader && e.tableLayout === "auto" ? (r(), M(f, {
                key: 0,
                ref: "tableHeaderRef",
                class: o(e.ns.e("body-header")),
                border: e.border,
                "default-sort": e.defaultSort,
                store: e.store,
                onSetDragVisible: e.setDragVisible
              }, null, 8, ["class", "border", "default-sort", "store", "onSetDragVisible"])) : n("v-if", !0),
              a(S, {
                context: e.context,
                highlight: e.highlightCurrentRow,
                "row-class-name": e.rowClassName,
                "tooltip-effect": e.tooltipEffect,
                "tooltip-options": e.tooltipOptions,
                "row-style": e.rowStyle,
                store: e.store,
                stripe: e.stripe
              }, null, 8, ["context", "highlight", "row-class-name", "tooltip-effect", "tooltip-options", "row-style", "store", "stripe"]),
              e.showSummary && e.tableLayout === "auto" ? (r(), M(h, {
                key: 1,
                class: o(e.ns.e("body-footer")),
                border: e.border,
                "default-sort": e.defaultSort,
                store: e.store,
                "sum-text": e.computedSumText,
                "summary-method": e.summaryMethod
              }, null, 8, ["class", "border", "default-sort", "store", "sum-text", "summary-method"])) : n("v-if", !0)
            ], 6),
            e.isEmpty ? (r(), d("div", {
              key: 0,
              ref: "emptyBlock",
              style: u(e.emptyBlockStyle),
              class: o(e.ns.e("empty-block"))
            }, [
              t("span", {
                class: o(e.ns.e("empty-text"))
              }, [
                k(e.$slots, "empty", {}, () => [
                  ue(me(e.computedEmptyText), 1)
                ])
              ], 2)
            ], 6)) : n("v-if", !0),
            e.$slots.append ? (r(), d("div", {
              key: 1,
              ref: "appendWrapper",
              class: o(e.ns.e("append-wrapper"))
            }, [
              k(e.$slots, "append")
            ], 2)) : n("v-if", !0)
          ]),
          _: 3
        }, 8, ["view-style", "wrap-style", "always"])
      ], 2),
      e.showSummary && e.tableLayout === "fixed" ? L((r(), d("div", {
        key: 1,
        ref: "footerWrapper",
        class: o(e.ns.e("footer-wrapper"))
      }, [
        t("table", {
          class: o(e.ns.e("footer")),
          cellspacing: "0",
          cellpadding: "0",
          border: "0",
          style: u(e.tableBodyStyles)
        }, [
          a(m, {
            columns: e.store.states.columns.value,
            "table-layout": e.tableLayout
          }, null, 8, ["columns", "table-layout"]),
          a(h, {
            border: e.border,
            "default-sort": e.defaultSort,
            store: e.store,
            "sum-text": e.computedSumText,
            "summary-method": e.summaryMethod
          }, null, 8, ["border", "default-sort", "store", "sum-text", "summary-method"])
        ], 6)
      ], 2)), [
        [R, !e.isEmpty],
        [c, e.handleHeaderFooterMousewheel]
      ]) : n("v-if", !0),
      e.border || e.isGroup ? (r(), d("div", {
        key: 2,
        class: o(e.ns.e("border-left-patch"))
      }, null, 2)) : n("v-if", !0)
    ], 6),
    L(t("div", {
      ref: "resizeProxy",
      class: o(e.ns.e("column-resize-proxy"))
    }, null, 2), [
      [R, e.resizeProxyVisible]
    ])
  ], 46, ["data-prefix", "onMouseleave"]);
}
H(De, "_sfc_render");
var oo = /* @__PURE__ */ Ee($e, [["render", De], ["__file", "table.vue"]]);
export {
  oo as default
};
