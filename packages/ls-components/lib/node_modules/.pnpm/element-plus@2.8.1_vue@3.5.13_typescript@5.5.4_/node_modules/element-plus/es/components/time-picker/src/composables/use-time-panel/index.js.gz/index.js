var k = Object.defineProperty;
var o = (s, l) => k(s, "name", { value: l, configurable: !0 });
const g = /* @__PURE__ */ o(({
  getAvailableHours: s,
  getAvailableMinutes: l,
  getAvailableSeconds: m
}) => {
  const d = /* @__PURE__ */ o((u, t, b, c) => {
    const h = {
      hour: s,
      minute: l,
      second: m
    };
    let n = u;
    return ["hour", "minute", "second"].forEach((i) => {
      if (h[i]) {
        let e;
        const a = h[i];
        switch (i) {
          case "minute": {
            e = a(n.hour(), t, c);
            break;
          }
          case "second": {
            e = a(n.hour(), n.minute(), t, c);
            break;
          }
          default: {
            e = a(t, c);
            break;
          }
        }
        if (e != null && e.length && !e.includes(n[i]())) {
          const f = b ? 0 : e.length - 1;
          n = n[i](e[f]);
        }
      }
    }), n;
  }, "getAvailableTime"), r = {};
  return {
    timePickerOptions: r,
    getAvailableTime: d,
    onSetOption: /* @__PURE__ */ o(([u, t]) => {
      r[u] = t;
    }, "onSetOption")
  };
}, "useTimePanel");
export {
  g as useTimePanel
};
