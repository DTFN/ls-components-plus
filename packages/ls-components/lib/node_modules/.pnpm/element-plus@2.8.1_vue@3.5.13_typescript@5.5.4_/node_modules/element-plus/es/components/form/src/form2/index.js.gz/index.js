var N = Object.defineProperty;
var t = (m, u) => N(m, "name", { value: u, configurable: !0 });
import { defineComponent as E, computed as w, watch as T, provide as z, reactive as M, toRefs as S, openBlock as $, createElementBlock as k, normalizeClass as q, unref as B, renderSlot as I } from "vue";
import { formContextKey as R } from "../constants/index.js";
import { formProps as W, formEmits as A } from "../form/index.js";
import { useFormLabelWidth as K, filterFields as c } from "../utils/index.js";
import L from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useFormSize as D } from "../hooks/use-form-common-props/index.js";
import { useNamespace as G } from "../../../../hooks/use-namespace/index/index.js";
import { debugWarn as d } from "../../../../utils/error/index.js";
import { isFunction as H } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
const f = "ElForm", J = E({
  name: f
}), Q = /* @__PURE__ */ E({
  ...J,
  props: W,
  emits: A,
  setup(m, { expose: u, emit: y }) {
    const n = m, o = [], g = D(), a = G("form"), O = w(() => {
      const { labelPosition: e, inline: r } = n;
      return [
        a.b(),
        a.m(g.value || "default"),
        {
          [a.m(`label-${e}`)]: e,
          [a.m("inline")]: r
        }
      ];
    }), V = /* @__PURE__ */ t((e) => o.find((r) => r.prop === e), "getField"), C = /* @__PURE__ */ t((e) => {
      o.push(e);
    }, "addField"), b = /* @__PURE__ */ t((e) => {
      e.prop && o.splice(o.indexOf(e), 1);
    }, "removeField"), v = /* @__PURE__ */ t((e = []) => {
      if (!n.model) {
        d(f, "model is required for resetFields to work.");
        return;
      }
      c(o, e).forEach((r) => r.resetField());
    }, "resetFields"), h = /* @__PURE__ */ t((e = []) => {
      c(o, e).forEach((r) => r.clearValidate());
    }, "clearValidate"), P = w(() => {
      const e = !!n.model;
      return e || d(f, "model is required for validate to work."), e;
    }), j = /* @__PURE__ */ t((e) => {
      if (o.length === 0)
        return [];
      const r = c(o, e);
      return r.length ? r : (d(f, "please pass correct props!"), []);
    }, "obtainValidateFields"), F = /* @__PURE__ */ t(async (e) => p(void 0, e), "validate"), x = /* @__PURE__ */ t(async (e = []) => {
      if (!P.value)
        return !1;
      const r = j(e);
      if (r.length === 0)
        return !0;
      let i = {};
      for (const s of r)
        try {
          await s.validate("");
        } catch (l) {
          i = {
            ...i,
            ...l
          };
        }
      return Object.keys(i).length === 0 ? !0 : Promise.reject(i);
    }, "doValidateField"), p = /* @__PURE__ */ t(async (e = [], r) => {
      const i = !H(r);
      try {
        const s = await x(e);
        return s === !0 && await (r == null ? void 0 : r(s)), s;
      } catch (s) {
        if (s instanceof Error)
          throw s;
        const l = s;
        return n.scrollToError && _(Object.keys(l)[0]), await (r == null ? void 0 : r(!1, l)), i && Promise.reject(l);
      }
    }, "validateField"), _ = /* @__PURE__ */ t((e) => {
      var r;
      const i = c(o, e)[0];
      i && ((r = i.$el) == null || r.scrollIntoView(n.scrollIntoViewOptions));
    }, "scrollToField");
    return T(() => n.rules, () => {
      n.validateOnRuleChange && F().catch((e) => d(e));
    }, { deep: !0 }), z(R, M({
      ...S(n),
      emit: y,
      resetFields: v,
      clearValidate: h,
      validateField: p,
      getField: V,
      addField: C,
      removeField: b,
      ...K()
    })), u({
      validate: F,
      validateField: p,
      resetFields: v,
      clearValidate: h,
      scrollToField: _,
      fields: o
    }), (e, r) => ($(), k("form", {
      class: q(B(O))
    }, [
      I(e.$slots, "default")
    ], 2));
  }
});
var ne = /* @__PURE__ */ L(Q, [["__file", "form.vue"]]);
export {
  ne as default
};
