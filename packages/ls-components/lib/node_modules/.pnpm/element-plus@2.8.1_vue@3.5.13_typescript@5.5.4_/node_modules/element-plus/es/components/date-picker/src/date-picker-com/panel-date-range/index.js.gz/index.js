var Ze = Object.defineProperty;
var n = (G, y) => Ze(G, "name", { value: y, configurable: !0 });
import { defineComponent as je, inject as ea, toRef as X, ref as B, watch as aa, computed as p, openBlock as b, createElementBlock as k, normalizeClass as s, unref as e, createElementVNode as f, renderSlot as C, Fragment as la, renderList as ta, toDisplayString as A, createCommentVNode as T, createVNode as d, withDirectives as fe, withCtx as g, createBlock as na, createTextVNode as he } from "vue";
import I from "../../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import { ElButton as be } from "../../../../button/index/index.js";
import { ElInput as K } from "../../../../input/index/index.js";
import { ElIcon as P } from "../../../../icon/index/index.js";
import { ArrowRight as Z, DArrowLeft as ke, ArrowLeft as ge, DArrowRight as ye } from "@element-plus/icons-vue";
import { panelDateRangeProps as ra } from "../../props/panel-date-range/index.js";
import { useRangePicker as oa } from "../../composables/use-range-picker/index.js";
import { isValidRange as Ce, getDefaultValue as ua } from "../../utils/index.js";
import Pe from "../basic-date-table/index.js";
import ia from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as sa } from "../../../../../hooks/use-locale/index/index.js";
import { extractTimeFormat as da, extractDateFormat as ca } from "../../../../time-picker/src/utils/index.js";
import { isArray as we } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import De from "../../../../time-picker/src/time-picker-com/panel-time-pick/index.js";
import xe from "../../../../../directives/click-outside/index/index.js";
const q = "month", va = /* @__PURE__ */ je({
  __name: "panel-date-range",
  props: ra,
  emits: [
    "pick",
    "set-picker-option",
    "calendar-change",
    "panel-change"
  ],
  setup(G, { emit: y }) {
    const m = G, E = ea("EP_PICKER_BASE"), { disabledDate: $, cellClassName: j, defaultTime: H, clearable: Ve } = E.props, _ = X(E.props, "format"), ee = X(E.props, "shortcuts"), ae = X(E.props, "defaultValue"), { lang: w } = sa(), u = B(I().locale(w.value)), i = B(I().locale(w.value).add(1, q)), {
      minDate: t,
      maxDate: r,
      rangeState: D,
      ppNs: c,
      drpNs: h,
      handleChangeRange: le,
      handleRangeConfirm: te,
      handleShortcutClick: Te,
      onSelect: J,
      onReset: $e,
      t: v
    } = oa(m, {
      defaultValue: ae,
      leftDate: u,
      rightDate: i,
      unit: q,
      onParsedValueChanged: Xe
    });
    aa(() => m.visible, (a) => {
      !a && D.value.selecting && ($e(m.parsedValue), J(!1));
    });
    const S = B({
      min: null,
      max: null
    }), x = B({
      min: null,
      max: null
    }), Me = p(() => `${u.value.year()} ${v("el.datepicker.year")} ${v(`el.datepicker.month${u.value.month() + 1}`)}`), Ie = p(() => `${i.value.year()} ${v("el.datepicker.year")} ${v(`el.datepicker.month${i.value.month() + 1}`)}`), ne = p(() => u.value.year()), Q = p(() => u.value.month()), re = p(() => i.value.year()), oe = p(() => i.value.month()), ue = p(() => !!ee.value.length), _e = p(() => S.value.min !== null ? S.value.min : t.value ? t.value.format(W.value) : ""), Se = p(() => S.value.max !== null ? S.value.max : r.value || t.value ? (r.value || t.value).format(W.value) : ""), Ye = p(() => x.value.min !== null ? x.value.min : t.value ? t.value.format(F.value) : ""), Re = p(() => x.value.max !== null ? x.value.max : r.value || t.value ? (r.value || t.value).format(F.value) : ""), F = p(() => m.timeFormat || da(_.value)), W = p(() => m.dateFormat || ca(_.value)), Be = /* @__PURE__ */ n((a) => Ce(a) && ($ ? !$(a[0].toDate()) && !$(a[1].toDate()) : !0), "isValidValue"), Fe = /* @__PURE__ */ n(() => {
      u.value = u.value.subtract(1, "year"), m.unlinkPanels || (i.value = u.value.add(1, "month")), V("year");
    }, "leftPrevYear"), Ne = /* @__PURE__ */ n(() => {
      u.value = u.value.subtract(1, "month"), m.unlinkPanels || (i.value = u.value.add(1, "month")), V("month");
    }, "leftPrevMonth"), Ae = /* @__PURE__ */ n(() => {
      m.unlinkPanels ? i.value = i.value.add(1, "year") : (u.value = u.value.add(1, "year"), i.value = u.value.add(1, "month")), V("year");
    }, "rightNextYear"), Ee = /* @__PURE__ */ n(() => {
      m.unlinkPanels ? i.value = i.value.add(1, "month") : (u.value = u.value.add(1, "month"), i.value = u.value.add(1, "month")), V("month");
    }, "rightNextMonth"), ze = /* @__PURE__ */ n(() => {
      u.value = u.value.add(1, "year"), V("year");
    }, "leftNextYear"), Le = /* @__PURE__ */ n(() => {
      u.value = u.value.add(1, "month"), V("month");
    }, "leftNextMonth"), Ue = /* @__PURE__ */ n(() => {
      i.value = i.value.subtract(1, "year"), V("year");
    }, "rightPrevYear"), Oe = /* @__PURE__ */ n(() => {
      i.value = i.value.subtract(1, "month"), V("month");
    }, "rightPrevMonth"), V = /* @__PURE__ */ n((a) => {
      y("panel-change", [u.value.toDate(), i.value.toDate()], a);
    }, "handlePanelChange"), z = p(() => {
      const a = (Q.value + 1) % 12, o = Q.value + 1 >= 12 ? 1 : 0;
      return m.unlinkPanels && new Date(ne.value + o, a) < new Date(re.value, oe.value);
    }), L = p(() => m.unlinkPanels && re.value * 12 + oe.value - (ne.value * 12 + Q.value + 1) >= 12), Ke = p(() => !(t.value && r.value && !D.value.selecting && Ce([t.value, r.value]))), U = p(() => m.type === "datetime" || m.type === "datetimerange"), ie = /* @__PURE__ */ n((a, o) => {
      if (a)
        return H ? I(H[o] || H).locale(w.value).year(a.year()).month(a.month()).date(a.date()) : a;
    }, "formatEmit"), se = /* @__PURE__ */ n((a, o = !0) => {
      const l = a.minDate, M = a.maxDate, N = ie(l, 0), O = ie(M, 1);
      r.value === O && t.value === N || (y("calendar-change", [l.toDate(), M && M.toDate()]), r.value = O, t.value = N, !(!o || U.value) && te());
    }, "handleRangePick"), Y = B(!1), R = B(!1), qe = /* @__PURE__ */ n(() => {
      Y.value = !1;
    }, "handleMinTimeClose"), Ge = /* @__PURE__ */ n(() => {
      R.value = !1;
    }, "handleMaxTimeClose"), de = /* @__PURE__ */ n((a, o) => {
      S.value[o] = a;
      const l = I(a, W.value).locale(w.value);
      if (l.isValid()) {
        if ($ && $(l.toDate()))
          return;
        o === "min" ? (u.value = l, t.value = (t.value || u.value).year(l.year()).month(l.month()).date(l.date()), !m.unlinkPanels && (!r.value || r.value.isBefore(t.value)) && (i.value = l.add(1, "month"), r.value = t.value.add(1, "month"))) : (i.value = l, r.value = (r.value || i.value).year(l.year()).month(l.month()).date(l.date()), !m.unlinkPanels && (!t.value || t.value.isAfter(r.value)) && (u.value = l.subtract(1, "month"), t.value = r.value.subtract(1, "month")));
      }
    }, "handleDateInput"), ce = /* @__PURE__ */ n((a, o) => {
      S.value[o] = null;
    }, "handleDateChange"), ve = /* @__PURE__ */ n((a, o) => {
      x.value[o] = a;
      const l = I(a, F.value).locale(w.value);
      l.isValid() && (o === "min" ? (Y.value = !0, t.value = (t.value || u.value).hour(l.hour()).minute(l.minute()).second(l.second())) : (R.value = !0, r.value = (r.value || i.value).hour(l.hour()).minute(l.minute()).second(l.second()), i.value = r.value));
    }, "handleTimeInput"), me = /* @__PURE__ */ n((a, o) => {
      x.value[o] = null, o === "min" ? (u.value = t.value, Y.value = !1, (!r.value || r.value.isBefore(t.value)) && (r.value = t.value)) : (i.value = r.value, R.value = !1, r.value && r.value.isBefore(t.value) && (t.value = r.value));
    }, "handleTimeChange"), He = /* @__PURE__ */ n((a, o, l) => {
      x.value.min || (a && (u.value = a, t.value = (t.value || u.value).hour(a.hour()).minute(a.minute()).second(a.second())), l || (Y.value = o), (!r.value || r.value.isBefore(t.value)) && (r.value = t.value, i.value = a));
    }, "handleMinTimePick"), Je = /* @__PURE__ */ n((a, o, l) => {
      x.value.max || (a && (i.value = a, r.value = (r.value || i.value).hour(a.hour()).minute(a.minute()).second(a.second())), l || (R.value = o), r.value && r.value.isBefore(t.value) && (t.value = r.value));
    }, "handleMaxTimePick"), pe = /* @__PURE__ */ n(() => {
      u.value = ua(e(ae), {
        lang: e(w),
        unit: "month",
        unlinkPanels: m.unlinkPanels
      })[0], i.value = u.value.add(1, "month"), r.value = void 0, t.value = void 0, y("pick", null);
    }, "handleClear"), Qe = /* @__PURE__ */ n((a) => we(a) ? a.map((o) => o.format(_.value)) : a.format(_.value), "formatToString"), We = /* @__PURE__ */ n((a) => we(a) ? a.map((o) => I(o, _.value).locale(w.value)) : I(a, _.value).locale(w.value), "parseUserInput");
    function Xe(a, o) {
      if (m.unlinkPanels && o) {
        const l = (a == null ? void 0 : a.year()) || 0, M = (a == null ? void 0 : a.month()) || 0, N = o.year(), O = o.month();
        i.value = l === N && M === O ? o.add(1, q) : o;
      } else
        i.value = u.value.add(1, q), o && (i.value = i.value.hour(o.hour()).minute(o.minute()).second(o.second()));
    }
    return n(Xe, "onParsedValueChanged"), y("set-picker-option", ["isValidValue", Be]), y("set-picker-option", ["parseUserInput", We]), y("set-picker-option", ["formatToString", Qe]), y("set-picker-option", ["handleClear", pe]), (a, o) => (b(), k("div", {
      class: s([
        e(c).b(),
        e(h).b(),
        {
          "has-sidebar": a.$slots.sidebar || e(ue),
          "has-time": e(U)
        }
      ])
    }, [
      f("div", {
        class: s(e(c).e("body-wrapper"))
      }, [
        C(a.$slots, "sidebar", {
          class: s(e(c).e("sidebar"))
        }),
        e(ue) ? (b(), k("div", {
          key: 0,
          class: s(e(c).e("sidebar"))
        }, [
          (b(!0), k(la, null, ta(e(ee), (l, M) => (b(), k("button", {
            key: M,
            type: "button",
            class: s(e(c).e("shortcut")),
            onClick: /* @__PURE__ */ n((N) => e(Te)(l), "onClick")
          }, A(l.text), 11, ["onClick"]))), 128))
        ], 2)) : T("v-if", !0),
        f("div", {
          class: s(e(c).e("body"))
        }, [
          e(U) ? (b(), k("div", {
            key: 0,
            class: s(e(h).e("time-header"))
          }, [
            f("span", {
              class: s(e(h).e("editors-wrap"))
            }, [
              f("span", {
                class: s(e(h).e("time-picker-wrap"))
              }, [
                d(e(K), {
                  size: "small",
                  disabled: e(D).selecting,
                  placeholder: e(v)("el.datepicker.startDate"),
                  class: s(e(h).e("editor")),
                  "model-value": e(_e),
                  "validate-event": !1,
                  onInput: /* @__PURE__ */ n((l) => de(l, "min"), "onInput"),
                  onChange: /* @__PURE__ */ n((l) => ce(l, "min"), "onChange")
                }, null, 8, ["disabled", "placeholder", "class", "model-value", "onInput", "onChange"])
              ], 2),
              fe((b(), k("span", {
                class: s(e(h).e("time-picker-wrap"))
              }, [
                d(e(K), {
                  size: "small",
                  class: s(e(h).e("editor")),
                  disabled: e(D).selecting,
                  placeholder: e(v)("el.datepicker.startTime"),
                  "model-value": e(Ye),
                  "validate-event": !1,
                  onFocus: /* @__PURE__ */ n((l) => Y.value = !0, "onFocus"),
                  onInput: /* @__PURE__ */ n((l) => ve(l, "min"), "onInput"),
                  onChange: /* @__PURE__ */ n((l) => me(l, "min"), "onChange")
                }, null, 8, ["class", "disabled", "placeholder", "model-value", "onFocus", "onInput", "onChange"]),
                d(e(De), {
                  visible: Y.value,
                  format: e(F),
                  "datetime-role": "start",
                  "parsed-value": u.value,
                  onPick: He
                }, null, 8, ["visible", "format", "parsed-value"])
              ], 2)), [
                [e(xe), qe]
              ])
            ], 2),
            f("span", null, [
              d(e(P), null, {
                default: g(() => [
                  d(e(Z))
                ]),
                _: 1
              })
            ]),
            f("span", {
              class: s([e(h).e("editors-wrap"), "is-right"])
            }, [
              f("span", {
                class: s(e(h).e("time-picker-wrap"))
              }, [
                d(e(K), {
                  size: "small",
                  class: s(e(h).e("editor")),
                  disabled: e(D).selecting,
                  placeholder: e(v)("el.datepicker.endDate"),
                  "model-value": e(Se),
                  readonly: !e(t),
                  "validate-event": !1,
                  onInput: /* @__PURE__ */ n((l) => de(l, "max"), "onInput"),
                  onChange: /* @__PURE__ */ n((l) => ce(l, "max"), "onChange")
                }, null, 8, ["class", "disabled", "placeholder", "model-value", "readonly", "onInput", "onChange"])
              ], 2),
              fe((b(), k("span", {
                class: s(e(h).e("time-picker-wrap"))
              }, [
                d(e(K), {
                  size: "small",
                  class: s(e(h).e("editor")),
                  disabled: e(D).selecting,
                  placeholder: e(v)("el.datepicker.endTime"),
                  "model-value": e(Re),
                  readonly: !e(t),
                  "validate-event": !1,
                  onFocus: /* @__PURE__ */ n((l) => e(t) && (R.value = !0), "onFocus"),
                  onInput: /* @__PURE__ */ n((l) => ve(l, "max"), "onInput"),
                  onChange: /* @__PURE__ */ n((l) => me(l, "max"), "onChange")
                }, null, 8, ["class", "disabled", "placeholder", "model-value", "readonly", "onFocus", "onInput", "onChange"]),
                d(e(De), {
                  "datetime-role": "end",
                  visible: R.value,
                  format: e(F),
                  "parsed-value": i.value,
                  onPick: Je
                }, null, 8, ["visible", "format", "parsed-value"])
              ], 2)), [
                [e(xe), Ge]
              ])
            ], 2)
          ], 2)) : T("v-if", !0),
          f("div", {
            class: s([[e(c).e("content"), e(h).e("content")], "is-left"])
          }, [
            f("div", {
              class: s(e(h).e("header"))
            }, [
              f("button", {
                type: "button",
                class: s([e(c).e("icon-btn"), "d-arrow-left"]),
                "aria-label": e(v)("el.datepicker.prevYear"),
                onClick: Fe
              }, [
                C(a.$slots, "prev-year", {}, () => [
                  d(e(P), null, {
                    default: g(() => [
                      d(e(ke))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["aria-label"]),
              f("button", {
                type: "button",
                class: s([e(c).e("icon-btn"), "arrow-left"]),
                "aria-label": e(v)("el.datepicker.prevMonth"),
                onClick: Ne
              }, [
                C(a.$slots, "prev-month", {}, () => [
                  d(e(P), null, {
                    default: g(() => [
                      d(e(ge))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["aria-label"]),
              a.unlinkPanels ? (b(), k("button", {
                key: 0,
                type: "button",
                disabled: !e(L),
                class: s([[e(c).e("icon-btn"), { "is-disabled": !e(L) }], "d-arrow-right"]),
                "aria-label": e(v)("el.datepicker.nextYear"),
                onClick: ze
              }, [
                C(a.$slots, "next-year", {}, () => [
                  d(e(P), null, {
                    default: g(() => [
                      d(e(ye))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["disabled", "aria-label"])) : T("v-if", !0),
              a.unlinkPanels ? (b(), k("button", {
                key: 1,
                type: "button",
                disabled: !e(z),
                class: s([[
                  e(c).e("icon-btn"),
                  { "is-disabled": !e(z) }
                ], "arrow-right"]),
                "aria-label": e(v)("el.datepicker.nextMonth"),
                onClick: Le
              }, [
                C(a.$slots, "next-month", {}, () => [
                  d(e(P), null, {
                    default: g(() => [
                      d(e(Z))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["disabled", "aria-label"])) : T("v-if", !0),
              f("div", null, A(e(Me)), 1)
            ], 2),
            d(Pe, {
              "selection-mode": "range",
              date: u.value,
              "min-date": e(t),
              "max-date": e(r),
              "range-state": e(D),
              "disabled-date": e($),
              "cell-class-name": e(j),
              onChangerange: e(le),
              onPick: se,
              onSelect: e(J)
            }, null, 8, ["date", "min-date", "max-date", "range-state", "disabled-date", "cell-class-name", "onChangerange", "onSelect"])
          ], 2),
          f("div", {
            class: s([[e(c).e("content"), e(h).e("content")], "is-right"])
          }, [
            f("div", {
              class: s(e(h).e("header"))
            }, [
              a.unlinkPanels ? (b(), k("button", {
                key: 0,
                type: "button",
                disabled: !e(L),
                class: s([[e(c).e("icon-btn"), { "is-disabled": !e(L) }], "d-arrow-left"]),
                "aria-label": e(v)("el.datepicker.prevYear"),
                onClick: Ue
              }, [
                C(a.$slots, "prev-year", {}, () => [
                  d(e(P), null, {
                    default: g(() => [
                      d(e(ke))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["disabled", "aria-label"])) : T("v-if", !0),
              a.unlinkPanels ? (b(), k("button", {
                key: 1,
                type: "button",
                disabled: !e(z),
                class: s([[
                  e(c).e("icon-btn"),
                  { "is-disabled": !e(z) }
                ], "arrow-left"]),
                "aria-label": e(v)("el.datepicker.prevMonth"),
                onClick: Oe
              }, [
                C(a.$slots, "prev-month", {}, () => [
                  d(e(P), null, {
                    default: g(() => [
                      d(e(ge))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["disabled", "aria-label"])) : T("v-if", !0),
              f("button", {
                type: "button",
                "aria-label": e(v)("el.datepicker.nextYear"),
                class: s([e(c).e("icon-btn"), "d-arrow-right"]),
                onClick: Ae
              }, [
                C(a.$slots, "next-year", {}, () => [
                  d(e(P), null, {
                    default: g(() => [
                      d(e(ye))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["aria-label"]),
              f("button", {
                type: "button",
                class: s([e(c).e("icon-btn"), "arrow-right"]),
                "aria-label": e(v)("el.datepicker.nextMonth"),
                onClick: Ee
              }, [
                C(a.$slots, "next-month", {}, () => [
                  d(e(P), null, {
                    default: g(() => [
                      d(e(Z))
                    ]),
                    _: 1
                  })
                ])
              ], 10, ["aria-label"]),
              f("div", null, A(e(Ie)), 1)
            ], 2),
            d(Pe, {
              "selection-mode": "range",
              date: i.value,
              "min-date": e(t),
              "max-date": e(r),
              "range-state": e(D),
              "disabled-date": e($),
              "cell-class-name": e(j),
              onChangerange: e(le),
              onPick: se,
              onSelect: e(J)
            }, null, 8, ["date", "min-date", "max-date", "range-state", "disabled-date", "cell-class-name", "onChangerange", "onSelect"])
          ], 2)
        ], 2)
      ], 2),
      e(U) ? (b(), k("div", {
        key: 0,
        class: s(e(c).e("footer"))
      }, [
        e(Ve) ? (b(), na(e(be), {
          key: 0,
          text: "",
          size: "small",
          class: s(e(c).e("link-btn")),
          onClick: pe
        }, {
          default: g(() => [
            he(A(e(v)("el.datepicker.clear")), 1)
          ]),
          _: 1
        }, 8, ["class"])) : T("v-if", !0),
        d(e(be), {
          plain: "",
          size: "small",
          class: s(e(c).e("link-btn")),
          disabled: e(Ke),
          onClick: /* @__PURE__ */ n((l) => e(te)(!1), "onClick")
        }, {
          default: g(() => [
            he(A(e(v)("el.datepicker.confirm")), 1)
          ]),
          _: 1
        }, 8, ["class", "disabled", "onClick"])
      ], 2)) : T("v-if", !0)
    ], 2));
  }
});
var Ia = /* @__PURE__ */ ia(va, [["__file", "panel-date-range.vue"]]);
export {
  Ia as default
};
