var a = Object.defineProperty;
var o = (t, r) => a(t, "name", { value: r, configurable: !0 });
import { unref as s } from "vue";
import { useTimeout as n } from "../../use-timeout/index/index.js";
import { buildProps as T } from "../../../utils/vue/props/runtime/index.js";
import { isNumber as d } from "../../../utils/types/index.js";
const D = T({
  showAfter: {
    type: Number,
    default: 0
  },
  hideAfter: {
    type: Number,
    default: 200
  },
  autoClose: {
    type: Number,
    default: 0
  }
}), F = /* @__PURE__ */ o(({
  showAfter: t,
  hideAfter: r,
  autoClose: l,
  open: p,
  close: m
}) => {
  const { registerTimeout: i } = n(), {
    registerTimeout: f,
    cancelTimeout: c
  } = n();
  return {
    onOpen: /* @__PURE__ */ o((e) => {
      i(() => {
        p(e);
        const u = s(l);
        d(u) && u > 0 && f(() => {
          m(e);
        }, u);
      }, s(t));
    }, "onOpen"),
    onClose: /* @__PURE__ */ o((e) => {
      c(), i(() => {
        m(e);
      }, s(r));
    }, "onClose")
  };
}, "useDelayedToggle");
export {
  F as useDelayedToggle,
  D as useDelayedToggleProps
};
