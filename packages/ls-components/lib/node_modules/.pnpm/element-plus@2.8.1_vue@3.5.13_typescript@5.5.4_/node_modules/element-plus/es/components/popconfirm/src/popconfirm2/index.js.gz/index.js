var V = Object.defineProperty;
var l = (i, r) => V(i, "name", { value: r, configurable: !0 });
import { defineComponent as P, ref as w, computed as a, openBlock as f, createBlock as m, unref as t, mergeProps as S, withCtx as n, createElementVNode as u, normalizeClass as p, normalizeStyle as D, resolveDynamicComponent as I, createCommentVNode as k, createTextVNode as d, toDisplayString as y, renderSlot as g, createVNode as E } from "vue";
import { ElButton as N } from "../../../button/index/index.js";
import { ElIcon as R } from "../../../icon/index/index.js";
import { ElTooltip as x } from "../../../tooltip/index/index.js";
import { popconfirmProps as A, popconfirmEmits as L } from "../popconfirm/index.js";
import U from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as _ } from "../../../../hooks/use-locale/index/index.js";
import { useNamespace as j } from "../../../../hooks/use-namespace/index/index.js";
import { addUnit as q } from "../../../../utils/dom/style/index.js";
const F = P({
  name: "ElPopconfirm"
}), G = /* @__PURE__ */ P({
  ...F,
  props: A,
  emits: L,
  setup(i, { emit: r }) {
    const s = i, { t: B } = _(), o = j("popconfirm"), v = w(), T = /* @__PURE__ */ l(() => {
      var e, c;
      (c = (e = v.value) == null ? void 0 : e.onClose) == null || c.call(e);
    }, "hidePopper"), $ = a(() => ({
      width: q(s.width)
    })), h = /* @__PURE__ */ l((e) => {
      r("confirm", e), T();
    }, "confirm"), C = /* @__PURE__ */ l((e) => {
      r("cancel", e), T();
    }, "cancel"), b = a(() => s.confirmButtonText || B("el.popconfirm.confirmButtonText")), z = a(() => s.cancelButtonText || B("el.popconfirm.cancelButtonText"));
    return (e, c) => (f(), m(t(x), S({
      ref_key: "tooltipRef",
      ref: v,
      trigger: "click",
      effect: "light"
    }, e.$attrs, {
      "popper-class": `${t(o).namespace.value}-popover`,
      "popper-style": t($),
      teleported: e.teleported,
      "fallback-placements": ["bottom", "top", "right", "left"],
      "hide-after": e.hideAfter,
      persistent: e.persistent
    }), {
      content: n(() => [
        u("div", {
          class: p(t(o).b())
        }, [
          u("div", {
            class: p(t(o).e("main"))
          }, [
            !e.hideIcon && e.icon ? (f(), m(t(R), {
              key: 0,
              class: p(t(o).e("icon")),
              style: D({ color: e.iconColor })
            }, {
              default: n(() => [
                (f(), m(I(e.icon)))
              ]),
              _: 1
            }, 8, ["class", "style"])) : k("v-if", !0),
            d(" " + y(e.title), 1)
          ], 2),
          u("div", {
            class: p(t(o).e("action"))
          }, [
            g(e.$slots, "actions", {
              confirm: h,
              cancel: C
            }, () => [
              E(t(N), {
                size: "small",
                type: e.cancelButtonType === "text" ? "" : e.cancelButtonType,
                text: e.cancelButtonType === "text",
                onClick: C
              }, {
                default: n(() => [
                  d(y(t(z)), 1)
                ]),
                _: 1
              }, 8, ["type", "text"]),
              E(t(N), {
                size: "small",
                type: e.confirmButtonType === "text" ? "" : e.confirmButtonType,
                text: e.confirmButtonType === "text",
                onClick: h
              }, {
                default: n(() => [
                  d(y(t(b)), 1)
                ]),
                _: 1
              }, 8, ["type", "text"])
            ])
          ], 2)
        ], 2)
      ]),
      default: n(() => [
        e.$slots.reference ? g(e.$slots, "reference", { key: 0 }) : k("v-if", !0)
      ]),
      _: 3
    }, 16, ["popper-class", "popper-style", "teleported", "hide-after", "persistent"]));
  }
});
var ee = /* @__PURE__ */ U(G, [["__file", "popconfirm.vue"]]);
export {
  ee as default
};
