var d = Object.defineProperty;
var a = (r, e) => d(r, "name", { value: e, configurable: !0 });
import { watch as u } from "vue";
import f from "../index/index.js";
import s from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/debounce/index.js";
const o = {
  rowKey: "rowKey",
  defaultExpandAll: "defaultExpandAll",
  selectOnIndeterminate: "selectOnIndeterminate",
  indent: "indent",
  lazy: "lazy",
  data: "data",
  "treeProps.hasChildren": {
    key: "lazyColumnIdentifier",
    default: "hasChildren"
  },
  "treeProps.children": {
    key: "childrenColumnName",
    default: "children"
  },
  "treeProps.checkStrictly": {
    key: "checkStrictly",
    default: !1
  }
};
function p(r, e) {
  if (!r)
    throw new Error("Table is required.");
  const t = f();
  return t.toggleAllSelection = s(t._toggleAllSelection, 10), Object.keys(o).forEach((l) => {
    i(c(e, l), l, t);
  }), h(t, e), t;
}
a(p, "createStore");
function h(r, e) {
  Object.keys(o).forEach((t) => {
    u(() => c(e, t), (l) => {
      i(l, t, r);
    });
  });
}
a(h, "proxyTableProps");
function i(r, e, t) {
  let l = r, n = o[e];
  typeof o[e] == "object" && (n = n.key, l = l || o[e].default), t.states[n].value = l;
}
a(i, "handleValue");
function c(r, e) {
  if (e.includes(".")) {
    const t = e.split(".");
    let l = r;
    return t.forEach((n) => {
      l = l[n];
    }), l;
  } else
    return r[e];
}
a(c, "getArrKeysValue");
export {
  p as createStore
};
