var v = Object.defineProperty;
var i = (n, s) => v(n, "name", { value: s, configurable: !0 });
function h(n) {
  let s;
  function c() {
    if (n.value == null)
      return;
    const { selectionStart: e, selectionEnd: t, value: o } = n.value;
    if (e == null || t == null)
      return;
    const l = o.slice(0, Math.max(0, e)), r = o.slice(Math.max(0, t));
    s = {
      selectionStart: e,
      selectionEnd: t,
      value: o,
      beforeTxt: l,
      afterTxt: r
    };
  }
  i(c, "recordCursor");
  function f() {
    if (n.value == null || s == null)
      return;
    const { value: e } = n.value, { beforeTxt: t, afterTxt: o, selectionStart: l } = s;
    if (t == null || o == null || l == null)
      return;
    let r = e.length;
    if (e.endsWith(o))
      r = e.length - o.length;
    else if (e.startsWith(t))
      r = t.length;
    else {
      const u = t[l - 1], a = e.indexOf(u, l - 1);
      a !== -1 && (r = a + 1);
    }
    n.value.setSelectionRange(r, r);
  }
  return i(f, "setCursor"), [c, f];
}
i(h, "useCursor");
export {
  h as useCursor
};
