var f = Object.defineProperty;
var s = (r, t) => f(r, "name", { value: t, configurable: !0 });
import { inject as v, computed as p } from "vue";
import { TABLE_INJECTION_KEY as u } from "../../tokens/index.js";
const c = /* @__PURE__ */ s((r) => {
  const t = [];
  return r.forEach((l) => {
    l.children ? (t.push(l), t.push.apply(t, c(l.children))) : t.push(l);
  }), t;
}, "getAllColumns"), d = /* @__PURE__ */ s((r) => {
  let t = 1;
  const l = /* @__PURE__ */ s((e, i) => {
    if (i && (e.level = i.level + 1, t < e.level && (t = e.level)), e.children) {
      let a = 0;
      e.children.forEach((n) => {
        l(n, e), a += n.colSpan;
      }), e.colSpan = a;
    } else
      e.colSpan = 1;
  }, "traverse");
  r.forEach((e) => {
    e.level = 1, l(e, void 0);
  });
  const o = [];
  for (let e = 0; e < t; e++)
    o.push([]);
  return c(r).forEach((e) => {
    e.children ? (e.rowSpan = 1, e.children.forEach((i) => i.isSubColumn = !0)) : e.rowSpan = t - e.level + 1, o[e.level - 1].push(e);
  }), o;
}, "convertToRows");
function w(r) {
  const t = v(u), l = p(() => d(r.store.states.originColumns.value));
  return {
    isGroup: p(() => {
      const e = l.value.length > 1;
      return e && t && (t.state.isGroup.value = !0), e;
    }),
    toggleAllSelection: /* @__PURE__ */ s((e) => {
      e.stopPropagation(), t == null || t.store.commit("toggleAllSelection");
    }, "toggleAllSelection"),
    columnRows: l
  };
}
s(w, "useUtils");
export {
  d as convertToRows,
  w as default
};
