var be = Object.defineProperty;
var u = (_, I) => be(_, "name", { value: I, configurable: !0 });
import { defineComponent as Z, useSlots as ge, inject as D, ref as g, computed as n, watch as L, reactive as ye, toRefs as _e, provide as Ie, onMounted as Se, onBeforeUnmount as Fe, openBlock as T, createElementBlock as Ce, normalizeClass as y, unref as l, createVNode as G, withCtx as $, createBlock as Ve, resolveDynamicComponent as qe, normalizeStyle as K, renderSlot as z, createTextVNode as we, toDisplayString as U, createCommentVNode as O, createElementVNode as H, TransitionGroup as Re, nextTick as xe } from "vue";
import We from "../../../../../../../../async-validator@4.2.5/node_modules/async-validator/dist-web/index/index.js";
import { formItemProps as $e } from "../form-item/index.js";
import ze from "../form-label-wrap/index.js";
import { formContextKey as Me, formItemContextKey as J } from "../constants/index.js";
import Pe from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useFormSize as ke } from "../hooks/use-form-common-props/index.js";
import { useNamespace as Ne } from "../../../../hooks/use-namespace/index/index.js";
import { useId as je } from "../../../../hooks/use-id/index/index.js";
import { addUnit as Q } from "../../../../utils/dom/style/index.js";
import { isBoolean as Ae } from "../../../../utils/types/index.js";
import { isString as Be, isFunction as Ee } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { getProp as M } from "../../../../utils/objects/index.js";
import { debouncedRef as De } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
import X from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/castArray/index.js";
import Y from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/clone/index.js";
const Le = Z({
  name: "ElFormItem"
}), Te = /* @__PURE__ */ Z({
  ...Le,
  props: $e,
  setup(_, { expose: I }) {
    const r = _, P = ge(), t = D(Me, void 0), ee = D(J, void 0), S = ke(void 0, { formItem: !1 }), a = Ne("form-item"), F = je().value, c = g([]), m = g(""), te = De(m, 100), v = g(""), k = g();
    let N, h = !1;
    const b = n(() => r.labelPosition || (t == null ? void 0 : t.labelPosition)), j = n(() => {
      if (b.value === "top")
        return {};
      const e = Q(r.labelWidth || (t == null ? void 0 : t.labelWidth) || "");
      return e ? { width: e } : {};
    }), re = n(() => {
      if (b.value === "top" || t != null && t.inline)
        return {};
      if (!r.label && !r.labelWidth && ne)
        return {};
      const e = Q(r.labelWidth || (t == null ? void 0 : t.labelWidth) || "");
      return !r.label && !P.label ? { marginLeft: e } : {};
    }), oe = n(() => [
      a.b(),
      a.m(S.value),
      a.is("error", m.value === "error"),
      a.is("validating", m.value === "validating"),
      a.is("success", m.value === "success"),
      a.is("required", de.value || r.required),
      a.is("no-asterisk", t == null ? void 0 : t.hideRequiredAsterisk),
      (t == null ? void 0 : t.requireAsteriskPosition) === "right" ? "asterisk-right" : "asterisk-left",
      {
        [a.m("feedback")]: t == null ? void 0 : t.statusIcon,
        [a.m(`label-${b.value}`)]: b.value
      }
    ]), le = n(() => Ae(r.inlineMessage) ? r.inlineMessage : (t == null ? void 0 : t.inlineMessage) || !1), ie = n(() => [
      a.e("error"),
      { [a.em("error", "inline")]: le.value }
    ]), se = n(() => r.prop ? Be(r.prop) ? r.prop : r.prop.join(".") : ""), C = n(() => !!(r.label || P.label)), V = n(() => r.for || (c.value.length === 1 ? c.value[0] : void 0)), q = n(() => !V.value && C.value), ne = !!ee, w = n(() => {
      const e = t == null ? void 0 : t.model;
      if (!(!e || !r.prop))
        return M(e, r.prop).value;
    }), R = n(() => {
      const { required: e } = r, o = [];
      r.rules && o.push(...X(r.rules));
      const s = t == null ? void 0 : t.rules;
      if (s && r.prop) {
        const i = M(s, r.prop).value;
        i && o.push(...X(i));
      }
      if (e !== void 0) {
        const i = o.map((d, p) => [d, p]).filter(([d]) => Object.keys(d).includes("required"));
        if (i.length > 0)
          for (const [d, p] of i)
            d.required !== e && (o[p] = { ...d, required: e });
        else
          o.push({ required: e });
      }
      return o;
    }), ae = n(() => R.value.length > 0), ue = /* @__PURE__ */ u((e) => R.value.filter((s) => !s.trigger || !e ? !0 : Array.isArray(s.trigger) ? s.trigger.includes(e) : s.trigger === e).map(({ trigger: s, ...i }) => i), "getFilteredRule"), de = n(() => R.value.some((e) => e.required)), ce = n(() => {
      var e;
      return te.value === "error" && r.showMessage && ((e = t == null ? void 0 : t.showMessage) != null ? e : !0);
    }), A = n(() => `${r.label || ""}${(t == null ? void 0 : t.labelSuffix) || ""}`), f = /* @__PURE__ */ u((e) => {
      m.value = e;
    }, "setValidationState"), me = /* @__PURE__ */ u((e) => {
      var o, s;
      const { errors: i, fields: d } = e;
      (!i || !d) && console.error(e), f("error"), v.value = i ? (s = (o = i == null ? void 0 : i[0]) == null ? void 0 : o.message) != null ? s : `${r.prop} is required` : "", t == null || t.emit("validate", r.prop, !1, v.value);
    }, "onValidationFailed"), ve = /* @__PURE__ */ u(() => {
      f("success"), t == null || t.emit("validate", r.prop, !0, "");
    }, "onValidationSucceeded"), fe = /* @__PURE__ */ u(async (e) => {
      const o = se.value;
      return new We({
        [o]: e
      }).validate({ [o]: w.value }, { firstFields: !0 }).then(() => (ve(), !0)).catch((i) => (me(i), Promise.reject(i)));
    }, "doValidate"), B = /* @__PURE__ */ u(async (e, o) => {
      if (h || !r.prop)
        return !1;
      const s = Ee(o);
      if (!ae.value)
        return o == null || o(!1), !1;
      const i = ue(e);
      return i.length === 0 ? (o == null || o(!0), !0) : (f("validating"), fe(i).then(() => (o == null || o(!0), !0)).catch((d) => {
        const { fields: p } = d;
        return o == null || o(!1, p), s ? !1 : Promise.reject(p);
      }));
    }, "validate"), x = /* @__PURE__ */ u(() => {
      f(""), v.value = "", h = !1;
    }, "clearValidate"), E = /* @__PURE__ */ u(async () => {
      const e = t == null ? void 0 : t.model;
      if (!e || !r.prop)
        return;
      const o = M(e, r.prop);
      h = !0, o.value = Y(N), await xe(), x(), h = !1;
    }, "resetField"), pe = /* @__PURE__ */ u((e) => {
      c.value.includes(e) || c.value.push(e);
    }, "addInputId"), he = /* @__PURE__ */ u((e) => {
      c.value = c.value.filter((o) => o !== e);
    }, "removeInputId");
    L(() => r.error, (e) => {
      v.value = e || "", f(e ? "error" : "");
    }, { immediate: !0 }), L(() => r.validateStatus, (e) => f(e || ""));
    const W = ye({
      ..._e(r),
      $el: k,
      size: S,
      validateState: m,
      labelId: F,
      inputIds: c,
      isGroup: q,
      hasLabel: C,
      fieldValue: w,
      addInputId: pe,
      removeInputId: he,
      resetField: E,
      clearValidate: x,
      validate: B
    });
    return Ie(J, W), Se(() => {
      r.prop && (t == null || t.addField(W), N = Y(w.value));
    }), Fe(() => {
      t == null || t.removeField(W);
    }), I({
      size: S,
      validateMessage: v,
      validateState: m,
      validate: B,
      clearValidate: x,
      resetField: E
    }), (e, o) => {
      var s;
      return T(), Ce("div", {
        ref_key: "formItemRef",
        ref: k,
        class: y(l(oe)),
        role: l(q) ? "group" : void 0,
        "aria-labelledby": l(q) ? l(F) : void 0
      }, [
        G(l(ze), {
          "is-auto-width": l(j).width === "auto",
          "update-all": ((s = l(t)) == null ? void 0 : s.labelWidth) === "auto"
        }, {
          default: $(() => [
            l(C) ? (T(), Ve(qe(l(V) ? "label" : "div"), {
              key: 0,
              id: l(F),
              for: l(V),
              class: y(l(a).e("label")),
              style: K(l(j))
            }, {
              default: $(() => [
                z(e.$slots, "label", { label: l(A) }, () => [
                  we(U(l(A)), 1)
                ])
              ]),
              _: 3
            }, 8, ["id", "for", "class", "style"])) : O("v-if", !0)
          ]),
          _: 3
        }, 8, ["is-auto-width", "update-all"]),
        H("div", {
          class: y(l(a).e("content")),
          style: K(l(re))
        }, [
          z(e.$slots, "default"),
          G(Re, {
            name: `${l(a).namespace.value}-zoom-in-top`
          }, {
            default: $(() => [
              l(ce) ? z(e.$slots, "error", {
                key: 0,
                error: v.value
              }, () => [
                H("div", {
                  class: y(l(ie))
                }, U(v.value), 3)
              ]) : O("v-if", !0)
            ]),
            _: 3
          }, 8, ["name"])
        ], 6)
      ], 10, ["role", "aria-labelledby"]);
    };
  }
});
var nt = /* @__PURE__ */ Pe(Te, [["__file", "form-item.vue"]]);
export {
  nt as default
};
