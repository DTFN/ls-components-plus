var S = Object.defineProperty;
var r = (a, i) => S(a, "name", { value: i, configurable: !0 });
import { defineComponent as m, computed as p, ref as U, unref as o, openBlock as f, createBlock as $, mergeProps as A, withCtx as d, createElementBlock as P, normalizeClass as N, toDisplayString as c, createCommentVNode as u, renderSlot as v, createTextVNode as V } from "vue";
import { ElTooltip as H } from "../../../tooltip/index/index.js";
import { popoverProps as L, popoverEmits as T } from "../popover/index.js";
import z from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as D } from "../../../../hooks/use-namespace/index/index.js";
import { addUnit as K } from "../../../../utils/dom/style/index.js";
const O = "onUpdate:visible", j = m({
  name: "ElPopover"
}), q = /* @__PURE__ */ m({
  ...j,
  props: L,
  emits: T,
  setup(a, { expose: i, emit: n }) {
    const t = a, b = p(() => t[O]), s = D("popover"), l = U(), h = p(() => {
      var e;
      return (e = o(l)) == null ? void 0 : e.popperRef;
    }), w = p(() => [
      {
        width: K(t.width)
      },
      t.popperStyle
    ]), g = p(() => [s.b(), t.popperClass, { [s.m("plain")]: !!t.content }]), y = p(() => t.transition === `${s.namespace.value}-fade-in-linear`), k = /* @__PURE__ */ r(() => {
      var e;
      (e = l.value) == null || e.hide();
    }, "hide"), E = /* @__PURE__ */ r(() => {
      n("before-enter");
    }, "beforeEnter"), C = /* @__PURE__ */ r(() => {
      n("before-leave");
    }, "beforeLeave"), B = /* @__PURE__ */ r(() => {
      n("after-enter");
    }, "afterEnter"), R = /* @__PURE__ */ r(() => {
      n("update:visible", !1), n("after-leave");
    }, "afterLeave");
    return i({
      popperRef: h,
      hide: k
    }), (e, F) => (f(), $(o(H), A({
      ref_key: "tooltipRef",
      ref: l
    }, e.$attrs, {
      trigger: e.trigger,
      placement: e.placement,
      disabled: e.disabled,
      visible: e.visible,
      transition: e.transition,
      "popper-options": e.popperOptions,
      tabindex: e.tabindex,
      content: e.content,
      offset: e.offset,
      "show-after": e.showAfter,
      "hide-after": e.hideAfter,
      "auto-close": e.autoClose,
      "show-arrow": e.showArrow,
      "aria-label": e.title,
      effect: e.effect,
      enterable: e.enterable,
      "popper-class": o(g),
      "popper-style": o(w),
      teleported: e.teleported,
      persistent: e.persistent,
      "gpu-acceleration": o(y),
      "onUpdate:visible": o(b),
      onBeforeShow: E,
      onBeforeHide: C,
      onShow: B,
      onHide: R
    }), {
      content: d(() => [
        e.title ? (f(), P("div", {
          key: 0,
          class: N(o(s).e("title")),
          role: "title"
        }, c(e.title), 3)) : u("v-if", !0),
        v(e.$slots, "default", {}, () => [
          V(c(e.content), 1)
        ])
      ]),
      default: d(() => [
        e.$slots.reference ? v(e.$slots, "reference", { key: 0 }) : u("v-if", !0)
      ]),
      _: 3
    }, 16, ["trigger", "placement", "disabled", "visible", "transition", "popper-options", "tabindex", "content", "offset", "show-after", "hide-after", "auto-close", "show-arrow", "aria-label", "effect", "enterable", "popper-class", "popper-style", "teleported", "persistent", "gpu-acceleration", "onUpdate:visible"]));
  }
});
var Y = /* @__PURE__ */ z(q, [["__file", "popover.vue"]]);
export {
  Y as default
};
