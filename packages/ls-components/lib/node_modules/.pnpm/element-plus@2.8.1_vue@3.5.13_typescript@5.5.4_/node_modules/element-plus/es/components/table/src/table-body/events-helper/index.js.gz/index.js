var q = Object.defineProperty;
var r = (a, c) => q(a, "name", { value: c, configurable: !0 });
import { inject as z, ref as w, h as A } from "vue";
import { getCell as v, getColumnByCell as b, createTablePopper as D } from "../../util/index.js";
import { TABLE_INJECTION_KEY as G } from "../../tokens/index.js";
import { hasClass as J, addClass as K, removeClass as Y } from "../../../../../utils/dom/style/index.js";
import S from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/debounce/index.js";
function p(a, c, u = 0.03) {
  return a - c > u;
}
r(p, "isGreaterThan");
function te(a) {
  const c = z(G), u = w(""), N = w(A("div")), m = /* @__PURE__ */ r((e, t, o) => {
    var l;
    const n = c, i = v(e);
    let d;
    const s = (l = n == null ? void 0 : n.vnode.el) == null ? void 0 : l.dataset.prefix;
    i && (d = b({
      columns: a.store.states.columns.value
    }, i, s), d && (n == null || n.emit(`cell-${o}`, t, d, i, e))), n == null || n.emit(`row-${o}`, t, d, e);
  }, "handleEvent"), R = /* @__PURE__ */ r((e, t) => {
    m(e, t, "dblclick");
  }, "handleDoubleClick"), x = /* @__PURE__ */ r((e, t) => {
    a.store.commit("setCurrentRow", t), m(e, t, "click");
  }, "handleClick"), E = /* @__PURE__ */ r((e, t) => {
    m(e, t, "contextmenu");
  }, "handleContextMenu"), T = S((e) => {
    a.store.commit("setHoverRow", e);
  }, 30), B = S(() => {
    a.store.commit("setHoverRow", null);
  }, 30), M = /* @__PURE__ */ r((e) => {
    const t = window.getComputedStyle(e, null), o = Number.parseInt(t.paddingLeft, 10) || 0, l = Number.parseInt(t.paddingRight, 10) || 0, n = Number.parseInt(t.paddingTop, 10) || 0, i = Number.parseInt(t.paddingBottom, 10) || 0;
    return {
      left: o,
      right: l,
      top: n,
      bottom: i
    };
  }, "getPadding"), f = /* @__PURE__ */ r((e, t, o) => {
    let l = t.target.parentNode;
    for (; e > 1 && (l = l == null ? void 0 : l.nextSibling, !(!l || l.nodeName !== "TR")); )
      o(l, "hover-row hover-fixed-row"), e--;
  }, "toggleRowClassByCell");
  return {
    handleDoubleClick: R,
    handleClick: x,
    handleContextMenu: E,
    handleMouseEnter: T,
    handleMouseLeave: B,
    handleCellMouseEnter: /* @__PURE__ */ r((e, t, o) => {
      var l;
      const n = c, i = v(e), d = (l = n == null ? void 0 : n.vnode.el) == null ? void 0 : l.dataset.prefix;
      if (i) {
        const j = b({
          columns: a.store.states.columns.value
        }, i, d);
        i.rowSpan > 1 && f(i.rowSpan, e, K);
        const g = n.hoverState = { cell: i, column: j, row: t };
        n == null || n.emit("cell-mouse-enter", g.row, g.column, g.cell, e);
      }
      if (!o)
        return;
      const s = e.target.querySelector(".cell");
      if (!(J(s, `${d}-tooltip`) && s.childNodes.length))
        return;
      const h = document.createRange();
      h.setStart(s, 0), h.setEnd(s, s.childNodes.length);
      const { width: I, height: L } = h.getBoundingClientRect(), { width: C, height: k } = s.getBoundingClientRect(), { top: y, left: H, right: P, bottom: _ } = M(s), W = H + P, $ = y + _;
      (p(I + W, C) || p(L + $, k) || p(s.scrollWidth, C)) && D(o, i.innerText || i.textContent, i, n);
    }, "handleCellMouseEnter"),
    handleCellMouseLeave: /* @__PURE__ */ r((e) => {
      const t = v(e);
      if (!t)
        return;
      t.rowSpan > 1 && f(t.rowSpan, e, Y);
      const o = c == null ? void 0 : c.hoverState;
      c == null || c.emit("cell-mouse-leave", o == null ? void 0 : o.row, o == null ? void 0 : o.column, o == null ? void 0 : o.cell, e);
    }, "handleCellMouseLeave"),
    tooltipContent: u,
    tooltipTrigger: N
  };
}
r(te, "useEvents");
export {
  te as default
};
