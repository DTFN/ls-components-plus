var z = Object.defineProperty;
var t = (c, p) => z(c, "name", { value: p, configurable: !0 });
import { defineComponent as C, ref as S, computed as r, openBlock as u, createBlock as i, unref as n, withCtx as f, normalizeClass as O, resolveDynamicComponent as w, createCommentVNode as D, createElementBlock as H, Fragment as L, renderList as N } from "vue";
import h from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/dayjs.min/index.js";
import P from "../../../../../../../../dayjs@1.11.13/node_modules/dayjs/plugin/customParseFormat/index.js";
import { ElSelect as T } from "../../../select/index/index.js";
import { ElIcon as U } from "../../../icon/index/index.js";
import { timeSelectProps as j } from "../time-select/index.js";
import { parseTime as s, formatTime as m, compareTime as v, nextTime as q } from "../utils/index.js";
import A from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as G } from "../../../../hooks/use-namespace/index/index.js";
import { useFormDisabled as J } from "../../../form/src/hooks/use-form-common-props/index.js";
import { useLocale as K } from "../../../../hooks/use-locale/index/index.js";
const M = C({
  name: "ElTimeSelect"
}), Q = /* @__PURE__ */ C({
  ...M,
  props: j,
  emits: ["change", "blur", "focus", "clear", "update:modelValue"],
  setup(c, { expose: p }) {
    const a = c;
    h.extend(P);
    const { Option: y } = T, V = G("input"), d = S(), g = J(), { lang: k } = K(), B = r(() => a.modelValue), E = r(() => {
      const e = s(a.start);
      return e ? m(e) : null;
    }), b = r(() => {
      const e = s(a.end);
      return e ? m(e) : null;
    }), F = r(() => {
      const e = s(a.step);
      return e ? m(e) : null;
    }), I = r(() => {
      const e = s(a.minTime || "");
      return e ? m(e) : null;
    }), _ = r(() => {
      const e = s(a.maxTime || "");
      return e ? m(e) : null;
    }), $ = r(() => {
      const e = [];
      if (a.start && a.end && a.step) {
        let o = E.value, l;
        for (; o && b.value && v(o, b.value) <= 0; )
          l = h(o, "HH:mm").locale(k.value).format(a.format), e.push({
            value: l,
            disabled: v(o, I.value || "-1:-1") <= 0 || v(o, _.value || "100:100") >= 0
          }), o = q(o, F.value);
      }
      return e;
    });
    return p({
      blur: /* @__PURE__ */ t(() => {
        var e, o;
        (o = (e = d.value) == null ? void 0 : e.blur) == null || o.call(e);
      }, "blur"),
      focus: /* @__PURE__ */ t(() => {
        var e, o;
        (o = (e = d.value) == null ? void 0 : e.focus) == null || o.call(e);
      }, "focus")
    }), (e, o) => (u(), i(n(T), {
      ref_key: "select",
      ref: d,
      "model-value": n(B),
      disabled: n(g),
      clearable: e.clearable,
      "clear-icon": e.clearIcon,
      size: e.size,
      effect: e.effect,
      placeholder: e.placeholder,
      "default-first-option": "",
      filterable: e.editable,
      "empty-values": e.emptyValues,
      "value-on-clear": e.valueOnClear,
      "onUpdate:modelValue": /* @__PURE__ */ t((l) => e.$emit("update:modelValue", l), "onUpdate:modelValue"),
      onChange: /* @__PURE__ */ t((l) => e.$emit("change", l), "onChange"),
      onBlur: /* @__PURE__ */ t((l) => e.$emit("blur", l), "onBlur"),
      onFocus: /* @__PURE__ */ t((l) => e.$emit("focus", l), "onFocus"),
      onClear: /* @__PURE__ */ t(() => e.$emit("clear"), "onClear")
    }, {
      prefix: f(() => [
        e.prefixIcon ? (u(), i(n(U), {
          key: 0,
          class: O(n(V).e("prefix-icon"))
        }, {
          default: f(() => [
            (u(), i(w(e.prefixIcon)))
          ]),
          _: 1
        }, 8, ["class"])) : D("v-if", !0)
      ]),
      default: f(() => [
        (u(!0), H(L, null, N(n($), (l) => (u(), i(n(y), {
          key: l.value,
          label: l.value,
          value: l.value,
          disabled: l.disabled
        }, null, 8, ["label", "value", "disabled"]))), 128))
      ]),
      _: 1
    }, 8, ["model-value", "disabled", "clearable", "clear-icon", "size", "effect", "placeholder", "filterable", "empty-values", "value-on-clear", "onUpdate:modelValue", "onChange", "onBlur", "onFocus", "onClear"]));
  }
});
var se = /* @__PURE__ */ A(Q, [["__file", "time-select.vue"]]);
export {
  se as default
};
