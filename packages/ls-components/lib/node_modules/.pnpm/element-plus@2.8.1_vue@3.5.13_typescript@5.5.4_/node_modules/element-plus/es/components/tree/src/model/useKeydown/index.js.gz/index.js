var h = Object.defineProperty;
var s = (l, u) => h(l, "name", { value: u, configurable: !0 });
import { shallowRef as m, onMounted as p, onUpdated as b, watch as k } from "vue";
import { useEventListener as x } from "../../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { useNamespace as A } from "../../../../../hooks/use-namespace/index/index.js";
import { EVENT_CODE as n } from "../../../../../constants/aria/index.js";
function N({ el$: l }, u) {
  const c = A("tree"), t = m([]), d = m([]);
  p(() => {
    y();
  }), b(() => {
    t.value = Array.from(l.value.querySelectorAll("[role=treeitem]")), d.value = Array.from(l.value.querySelectorAll("input[type=checkbox]"));
  }), k(d, (r) => {
    r.forEach((a) => {
      a.setAttribute("tabindex", "-1");
    });
  }), x(l, "keydown", /* @__PURE__ */ s((r) => {
    const a = r.target;
    if (!a.className.includes(c.b("node")))
      return;
    const i = r.code;
    t.value = Array.from(l.value.querySelectorAll(`.${c.is("focusable")}[role=treeitem]`));
    const o = t.value.indexOf(a);
    let e;
    if ([n.up, n.down].includes(i)) {
      if (r.preventDefault(), i === n.up) {
        e = o === -1 ? 0 : o !== 0 ? o - 1 : t.value.length - 1;
        const f = e;
        for (; !u.value.getNode(t.value[e].dataset.key).canFocus; ) {
          if (e--, e === f) {
            e = -1;
            break;
          }
          e < 0 && (e = t.value.length - 1);
        }
      } else {
        e = o === -1 ? 0 : o < t.value.length - 1 ? o + 1 : 0;
        const f = e;
        for (; !u.value.getNode(t.value[e].dataset.key).canFocus; ) {
          if (e++, e === f) {
            e = -1;
            break;
          }
          e >= t.value.length && (e = 0);
        }
      }
      e !== -1 && t.value[e].focus();
    }
    [n.left, n.right].includes(i) && (r.preventDefault(), a.click());
    const v = a.querySelector('[type="checkbox"]');
    [n.enter, n.space].includes(i) && v && (r.preventDefault(), v.click());
  }, "handleKeydown"));
  const y = /* @__PURE__ */ s(() => {
    var r;
    t.value = Array.from(l.value.querySelectorAll(`.${c.is("focusable")}[role=treeitem]`)), d.value = Array.from(l.value.querySelectorAll("input[type=checkbox]"));
    const a = l.value.querySelectorAll(`.${c.is("checked")}[role=treeitem]`);
    if (a.length) {
      a[0].setAttribute("tabindex", "0");
      return;
    }
    (r = t.value[0]) == null || r.setAttribute("tabindex", "0");
  }, "initTabIndex");
}
s(N, "useKeydown");
export {
  N as useKeydown
};
