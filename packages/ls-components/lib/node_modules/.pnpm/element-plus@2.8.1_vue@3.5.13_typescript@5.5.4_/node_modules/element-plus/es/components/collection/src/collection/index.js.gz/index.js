var a = Object.defineProperty;
var s = (c, o) => a(c, "name", { value: o, configurable: !0 });
import { ref as C, provide as f, inject as _, onMounted as d, unref as m, onBeforeUnmount as L } from "vue";
import M from "../collection2/index.js";
import T from "../collection-item/index.js";
const S = "data-el-collection-item", b = /* @__PURE__ */ s((c) => {
  const o = `El${c}Collection`, I = `${o}Item`, i = Symbol(o), E = Symbol(I), O = {
    ...M,
    name: o,
    setup() {
      const r = C(null), n = /* @__PURE__ */ new Map();
      f(i, {
        itemMap: n,
        getItems: /* @__PURE__ */ s(() => {
          const t = m(r);
          if (!t)
            return [];
          const e = Array.from(t.querySelectorAll(`[${S}]`));
          return [...n.values()].sort((p, u) => e.indexOf(p.ref) - e.indexOf(u.ref));
        }, "getItems"),
        collectionRef: r
      });
    }
  }, N = {
    ...T,
    name: I,
    setup(r, { attrs: n }) {
      const l = C(null), t = _(i, void 0);
      f(E, {
        collectionItemRef: l
      }), d(() => {
        const e = m(l);
        e && t.itemMap.set(e, {
          ref: e,
          ...n
        });
      }), L(() => {
        const e = m(l);
        t.itemMap.delete(e);
      });
    }
  };
  return {
    COLLECTION_INJECTION_KEY: i,
    COLLECTION_ITEM_INJECTION_KEY: E,
    ElCollection: O,
    ElCollectionItem: N
  };
}, "createCollectionWithScope");
export {
  S as COLLECTION_ITEM_SIGN,
  b as createCollectionWithScope
};
