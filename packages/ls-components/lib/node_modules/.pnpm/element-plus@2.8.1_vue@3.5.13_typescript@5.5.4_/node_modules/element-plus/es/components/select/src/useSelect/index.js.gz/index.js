var vt = Object.defineProperty;
var o = (t, d) => vt(t, "name", { value: d, configurable: !0 });
import { reactive as mt, ref as c, computed as u, watch as N, watchEffect as ht, nextTick as b, toRaw as gt, onMounted as bt } from "vue";
import { isArray as z, isFunction as A, toRawType as Q, isObject as Ie } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { useResizeObserver as V } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { useLocale as Vt } from "../../../../hooks/use-locale/index/index.js";
import { useId as xt } from "../../../../hooks/use-id/index/index.js";
import { useNamespace as Oe } from "../../../../hooks/use-namespace/index/index.js";
import { useComposition as It } from "../../../../hooks/use-composition/index/index.js";
import { useFocusController as Ot } from "../../../../hooks/use-focus-controller/index/index.js";
import { useFormItem as Ct, useFormItemInputId as pt } from "../../../form/src/hooks/use-form-item/index.js";
import { useEmptyValues as wt } from "../../../../hooks/use-empty-values/index/index.js";
import { ValidateComponentsMap as yt } from "../../../../utils/vue/icon/index.js";
import { useFormSize as Et } from "../../../form/src/hooks/use-form-common-props/index.js";
import { isUndefined as B, isNumber as Tt } from "../../../../utils/types/index.js";
import { debugWarn as _t } from "../../../../utils/error/index.js";
import { UPDATE_MODEL_EVENT as w, CHANGE_EVENT as Rt } from "../../../../constants/event/index.js";
import { EVENT_CODE as Mt } from "../../../../constants/aria/index.js";
import { scrollIntoView as St } from "../../../../utils/dom/scroll/index.js";
import y from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/castArray/index.js";
import { isIOS as Ce, isClient as Wt } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
import pe from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isEqual/index.js";
import E from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/get/index.js";
import Lt from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/debounce/index.js";
import Ft from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/findLastIndex/index.js";
const Dt = 11, al = /* @__PURE__ */ o((t, d) => {
  const { t: T } = Vt(), we = xt(), H = Oe("select"), ye = Oe("input"), l = mt({
    inputValue: "",
    options: /* @__PURE__ */ new Map(),
    cachedOptions: /* @__PURE__ */ new Map(),
    disabledOptions: /* @__PURE__ */ new Map(),
    optionValues: [],
    selected: t.multiple ? [] : {},
    selectionWidth: 0,
    calculatorWidth: 0,
    collapseItemWidth: 0,
    selectedLabel: "",
    hoveringIndex: -1,
    previousQuery: null,
    inputHovering: !1,
    menuVisibleOnFocus: !1,
    isBeforeHide: !1
  }), k = c(null), x = c(null), h = c(null), P = c(null), K = c(null), U = c(null), Ee = c(null), Te = c(null), j = c(null), G = c(null), _ = c(null), J = c(null), {
    isComposing: X,
    handleCompositionStart: _e,
    handleCompositionUpdate: Re,
    handleCompositionEnd: Me
  } = It({
    afterComposition: /* @__PURE__ */ o((e) => de(e), "afterComposition")
  }), { wrapperRef: Y, isFocused: Z, handleBlur: Se } = Ot(K, {
    afterFocus() {
      t.automaticDropdown && !s.value && (s.value = !0, l.menuVisibleOnFocus = !0);
    },
    beforeBlur(e) {
      var n, i;
      return ((n = h.value) == null ? void 0 : n.isFocusInsideContent(e)) || ((i = P.value) == null ? void 0 : i.isFocusInsideContent(e));
    },
    afterBlur() {
      s.value = !1, l.menuVisibleOnFocus = !1;
    }
  }), s = c(!1), I = c(), { form: ee, formItem: O } = Ct(), { inputId: We } = pt(t, {
    formItemContext: O
  }), { valueOnClear: Le, isEmptyValue: Fe } = wt(t), R = u(() => t.disabled || (ee == null ? void 0 : ee.disabled)), $ = u(() => z(t.modelValue) ? t.modelValue.length > 0 : !Fe(t.modelValue)), De = u(() => t.clearable && !R.value && l.inputHovering && $.value), te = u(() => t.remote && t.filterable && !t.remoteShowSuffix ? "" : t.suffixIcon), Ne = u(() => H.is("reverse", te.value && s.value)), le = u(() => (O == null ? void 0 : O.validateState) || ""), ze = u(() => yt[le.value]), Ae = u(() => t.remote ? 300 : 0), ne = u(() => t.loading ? t.loadingText || T("el.select.loading") : t.remote && !l.inputValue && l.options.size === 0 ? !1 : t.filterable && l.inputValue && l.options.size > 0 && M.value === 0 ? t.noMatchText || T("el.select.noMatch") : l.options.size === 0 ? t.noDataText || T("el.select.noData") : null), M = u(() => r.value.filter((e) => e.visible).length), r = u(() => {
    const e = Array.from(l.options.values()), n = [];
    return l.optionValues.forEach((i) => {
      const a = e.findIndex((v) => v.value === i);
      a > -1 && n.push(e[a]);
    }), n.length >= e.length ? n : e;
  }), Be = u(() => Array.from(l.cachedOptions.values())), He = u(() => {
    const e = r.value.filter((n) => !n.created).some((n) => n.currentLabel === l.inputValue);
    return t.filterable && t.allowCreate && l.inputValue !== "" && !e;
  }), ie = /* @__PURE__ */ o(() => {
    t.filterable && A(t.filterMethod) || t.filterable && t.remote && A(t.remoteMethod) || r.value.forEach((e) => {
      var n;
      (n = e.updateOption) == null || n.call(e, l.inputValue);
    });
  }, "updateOptions"), oe = Et(), Pe = u(() => ["small"].includes(oe.value) ? "small" : "default"), Ke = u({
    get() {
      return s.value && ne.value !== !1;
    },
    set(e) {
      s.value = e;
    }
  }), Ue = u(() => {
    if (t.multiple && !B(t.modelValue))
      return y(t.modelValue).length === 0 && !l.inputValue;
    const e = z(t.modelValue) ? t.modelValue[0] : t.modelValue;
    return t.filterable || B(e) ? !l.inputValue : !0;
  }), $e = u(() => {
    var e;
    const n = (e = t.placeholder) != null ? e : T("el.select.placeholder");
    return t.multiple || !$.value ? n : l.selectedLabel;
  }), qe = u(() => Ce ? null : "mouseenter");
  N(() => t.modelValue, (e, n) => {
    t.multiple && t.filterable && !t.reserveKeyword && (l.inputValue = "", S("")), W(), !pe(e, n) && t.validateEvent && (O == null || O.validate("change").catch((i) => _t(i)));
  }, {
    flush: "post",
    deep: !0
  }), N(() => s.value, (e) => {
    e ? S(l.inputValue) : (l.inputValue = "", l.previousQuery = null, l.isBeforeHide = !0), d("visible-change", e);
  }), N(() => l.options.entries(), () => {
    var e;
    if (!Wt)
      return;
    const n = ((e = k.value) == null ? void 0 : e.querySelectorAll("input")) || [];
    (!t.filterable && !t.defaultFirstOption && !B(t.modelValue) || !Array.from(n).includes(document.activeElement)) && W(), t.defaultFirstOption && (t.filterable || t.remote) && M.value && ae();
  }, {
    flush: "post"
  }), N(() => l.hoveringIndex, (e) => {
    Tt(e) && e > -1 ? I.value = r.value[e] || {} : I.value = {}, r.value.forEach((n) => {
      n.hover = I.value === n;
    });
  }), ht(() => {
    l.isBeforeHide || ie();
  });
  const S = /* @__PURE__ */ o((e) => {
    l.previousQuery === e || X.value || (l.previousQuery = e, t.filterable && A(t.filterMethod) ? t.filterMethod(e) : t.filterable && t.remote && A(t.remoteMethod) && t.remoteMethod(e), t.defaultFirstOption && (t.filterable || t.remote) && M.value ? b(ae) : b(Qe));
  }, "handleQueryChange"), ae = /* @__PURE__ */ o(() => {
    const e = r.value.filter((a) => a.visible && !a.disabled && !a.states.groupDisabled), n = e.find((a) => a.created), i = e[0];
    l.hoveringIndex = he(r.value, n || i);
  }, "checkDefaultFirstOption"), W = /* @__PURE__ */ o(() => {
    if (t.multiple)
      l.selectedLabel = "";
    else {
      const n = z(t.modelValue) ? t.modelValue[0] : t.modelValue, i = ue(n);
      l.selectedLabel = i.currentLabel, l.selected = i;
      return;
    }
    const e = [];
    B(t.modelValue) || y(t.modelValue).forEach((n) => {
      e.push(ue(n));
    }), l.selected = e;
  }, "setSelected"), ue = /* @__PURE__ */ o((e) => {
    let n;
    const i = Q(e).toLowerCase() === "object", a = Q(e).toLowerCase() === "null", v = Q(e).toLowerCase() === "undefined";
    for (let m = l.cachedOptions.size - 1; m >= 0; m--) {
      const f = Be.value[m];
      if (i ? E(f.value, t.valueKey) === E(e, t.valueKey) : f.value === e) {
        n = {
          value: e,
          currentLabel: f.currentLabel,
          get isDisabled() {
            return f.isDisabled;
          }
        };
        break;
      }
    }
    if (n)
      return n;
    const g = i ? e.label : !a && !v ? e : "";
    return {
      value: e,
      currentLabel: g
    };
  }, "getOption"), Qe = /* @__PURE__ */ o(() => {
    t.multiple ? l.hoveringIndex = r.value.findIndex((e) => l.selected.some((n) => p(n) === p(e))) : l.hoveringIndex = r.value.findIndex((e) => p(e) === p(l.selected));
  }, "updateHoveringIndex"), ke = /* @__PURE__ */ o(() => {
    l.selectionWidth = x.value.getBoundingClientRect().width;
  }, "resetSelectionWidth"), se = /* @__PURE__ */ o(() => {
    l.calculatorWidth = U.value.getBoundingClientRect().width;
  }, "resetCalculatorWidth"), je = /* @__PURE__ */ o(() => {
    l.collapseItemWidth = _.value.getBoundingClientRect().width;
  }, "resetCollapseItemWidth"), q = /* @__PURE__ */ o(() => {
    var e, n;
    (n = (e = h.value) == null ? void 0 : e.updatePopper) == null || n.call(e);
  }, "updateTooltip"), re = /* @__PURE__ */ o(() => {
    var e, n;
    (n = (e = P.value) == null ? void 0 : e.updatePopper) == null || n.call(e);
  }, "updateTagTooltip"), ce = /* @__PURE__ */ o(() => {
    l.inputValue.length > 0 && !s.value && (s.value = !0), S(l.inputValue);
  }, "onInputChange"), de = /* @__PURE__ */ o((e) => {
    if (l.inputValue = e.target.value, t.remote)
      fe();
    else
      return ce();
  }, "onInput"), fe = Lt(() => {
    ce();
  }, Ae.value), C = /* @__PURE__ */ o((e) => {
    pe(t.modelValue, e) || d(Rt, e);
  }, "emitChange"), Ge = /* @__PURE__ */ o((e) => Ft(e, (n) => !l.disabledOptions.has(n)), "getLastNotDisabledIndex"), Je = /* @__PURE__ */ o((e) => {
    if (t.multiple && e.code !== Mt.delete && e.target.value.length <= 0) {
      const n = y(t.modelValue).slice(), i = Ge(n);
      if (i < 0)
        return;
      const a = n[i];
      n.splice(i, 1), d(w, n), C(n), d("remove-tag", a);
    }
  }, "deletePrevTag"), Xe = /* @__PURE__ */ o((e, n) => {
    const i = l.selected.indexOf(n);
    if (i > -1 && !R.value) {
      const a = y(t.modelValue).slice();
      a.splice(i, 1), d(w, a), C(a), d("remove-tag", n.value);
    }
    e.stopPropagation(), F();
  }, "deleteTag"), ve = /* @__PURE__ */ o((e) => {
    e.stopPropagation();
    const n = t.multiple ? [] : Le.value;
    if (t.multiple)
      for (const i of l.selected)
        i.isDisabled && n.push(i.value);
    d(w, n), C(n), l.hoveringIndex = -1, s.value = !1, d("clear"), F();
  }, "deleteSelected"), me = /* @__PURE__ */ o((e) => {
    var n;
    if (t.multiple) {
      const i = y((n = t.modelValue) != null ? n : []).slice(), a = he(i, e.value);
      a > -1 ? i.splice(a, 1) : (t.multipleLimit <= 0 || i.length < t.multipleLimit) && i.push(e.value), d(w, i), C(i), e.created && S(""), t.filterable && !t.reserveKeyword && (l.inputValue = "");
    } else
      d(w, e.value), C(e.value), s.value = !1;
    F(), !s.value && b(() => {
      L(e);
    });
  }, "handleOptionSelect"), he = /* @__PURE__ */ o((e = [], n) => {
    if (!Ie(n))
      return e.indexOf(n);
    const i = t.valueKey;
    let a = -1;
    return e.some((v, g) => gt(E(v, i)) === E(n, i) ? (a = g, !0) : !1), a;
  }, "getValueIndex"), L = /* @__PURE__ */ o((e) => {
    var n, i, a, v, g;
    const D = z(e) ? e[0] : e;
    let m = null;
    if (D != null && D.value) {
      const f = r.value.filter((xe) => xe.value === D.value);
      f.length > 0 && (m = f[0].$el);
    }
    if (h.value && m) {
      const f = (v = (a = (i = (n = h.value) == null ? void 0 : n.popperRef) == null ? void 0 : i.contentRef) == null ? void 0 : a.querySelector) == null ? void 0 : v.call(a, `.${H.be("dropdown", "wrap")}`);
      f && St(f, m);
    }
    (g = J.value) == null || g.handleScroll();
  }, "scrollToOption"), Ye = /* @__PURE__ */ o((e) => {
    l.options.set(e.value, e), l.cachedOptions.set(e.value, e), e.disabled && l.disabledOptions.set(e.value, e);
  }, "onOptionCreate"), Ze = /* @__PURE__ */ o((e, n) => {
    l.options.get(e) === n && l.options.delete(e);
  }, "onOptionDestroy"), et = u(() => {
    var e, n;
    return (n = (e = h.value) == null ? void 0 : e.popperRef) == null ? void 0 : n.contentRef;
  }), tt = /* @__PURE__ */ o(() => {
    l.isBeforeHide = !1, b(() => L(l.selected));
  }, "handleMenuEnter"), F = /* @__PURE__ */ o(() => {
    var e;
    (e = K.value) == null || e.focus();
  }, "focus"), lt = /* @__PURE__ */ o(() => {
    ge();
  }, "blur"), nt = /* @__PURE__ */ o((e) => {
    ve(e);
  }, "handleClearClick"), ge = /* @__PURE__ */ o((e) => {
    if (s.value = !1, Z.value) {
      const n = new FocusEvent("focus", e);
      b(() => Se(n));
    }
  }, "handleClickOutside"), it = /* @__PURE__ */ o(() => {
    l.inputValue.length > 0 ? l.inputValue = "" : s.value = !1;
  }, "handleEsc"), be = /* @__PURE__ */ o(() => {
    R.value || (Ce && (l.inputHovering = !0), l.menuVisibleOnFocus ? l.menuVisibleOnFocus = !1 : s.value = !s.value);
  }, "toggleMenu"), ot = /* @__PURE__ */ o(() => {
    s.value ? r.value[l.hoveringIndex] && me(r.value[l.hoveringIndex]) : be();
  }, "selectOption"), p = /* @__PURE__ */ o((e) => Ie(e.value) ? E(e.value, t.valueKey) : e.value, "getValueKey"), at = u(() => r.value.filter((e) => e.visible).every((e) => e.disabled)), ut = u(() => t.multiple ? t.collapseTags ? l.selected.slice(0, t.maxCollapseTags) : l.selected : []), st = u(() => t.multiple ? t.collapseTags ? l.selected.slice(t.maxCollapseTags) : [] : []), Ve = /* @__PURE__ */ o((e) => {
    if (!s.value) {
      s.value = !0;
      return;
    }
    if (!(l.options.size === 0 || l.filteredOptionsCount === 0 || X.value) && !at.value) {
      e === "next" ? (l.hoveringIndex++, l.hoveringIndex === l.options.size && (l.hoveringIndex = 0)) : e === "prev" && (l.hoveringIndex--, l.hoveringIndex < 0 && (l.hoveringIndex = l.options.size - 1));
      const n = r.value[l.hoveringIndex];
      (n.disabled === !0 || n.states.groupDisabled === !0 || !n.visible) && Ve(e), b(() => L(I.value));
    }
  }, "navigateOptions"), rt = /* @__PURE__ */ o(() => {
    if (!x.value)
      return 0;
    const e = window.getComputedStyle(x.value);
    return Number.parseFloat(e.gap || "6px");
  }, "getGapWidth"), ct = u(() => {
    const e = rt();
    return { maxWidth: `${_.value && t.maxCollapseTags === 1 ? l.selectionWidth - l.collapseItemWidth - e : l.selectionWidth}px` };
  }), dt = u(() => ({ maxWidth: `${l.selectionWidth}px` })), ft = u(() => ({
    width: `${Math.max(l.calculatorWidth, Dt)}px`
  }));
  return V(x, ke), V(U, se), V(j, q), V(Y, q), V(G, re), V(_, je), bt(() => {
    W();
  }), {
    inputId: We,
    contentId: we,
    nsSelect: H,
    nsInput: ye,
    states: l,
    isFocused: Z,
    expanded: s,
    optionsArray: r,
    hoverOption: I,
    selectSize: oe,
    filteredOptionsCount: M,
    resetCalculatorWidth: se,
    updateTooltip: q,
    updateTagTooltip: re,
    debouncedOnInputChange: fe,
    onInput: de,
    deletePrevTag: Je,
    deleteTag: Xe,
    deleteSelected: ve,
    handleOptionSelect: me,
    scrollToOption: L,
    hasModelValue: $,
    shouldShowPlaceholder: Ue,
    currentPlaceholder: $e,
    mouseEnterEventName: qe,
    showClose: De,
    iconComponent: te,
    iconReverse: Ne,
    validateState: le,
    validateIcon: ze,
    showNewOption: He,
    updateOptions: ie,
    collapseTagSize: Pe,
    setSelected: W,
    selectDisabled: R,
    emptyText: ne,
    handleCompositionStart: _e,
    handleCompositionUpdate: Re,
    handleCompositionEnd: Me,
    onOptionCreate: Ye,
    onOptionDestroy: Ze,
    handleMenuEnter: tt,
    focus: F,
    blur: lt,
    handleClearClick: nt,
    handleClickOutside: ge,
    handleEsc: it,
    toggleMenu: be,
    selectOption: ot,
    getValueKey: p,
    navigateOptions: Ve,
    dropdownMenuVisible: Ke,
    showTagList: ut,
    collapseTagList: st,
    tagStyle: ct,
    collapseTagStyle: dt,
    inputStyle: ft,
    popperRef: et,
    inputRef: K,
    tooltipRef: h,
    tagTooltipRef: P,
    calculatorRef: U,
    prefixRef: Ee,
    suffixRef: Te,
    selectRef: k,
    wrapperRef: Y,
    selectionRef: x,
    scrollbarRef: J,
    menuRef: j,
    tagMenuRef: G,
    collapseItemRef: _
  };
}, "useSelect");
export {
  al as useSelect
};
