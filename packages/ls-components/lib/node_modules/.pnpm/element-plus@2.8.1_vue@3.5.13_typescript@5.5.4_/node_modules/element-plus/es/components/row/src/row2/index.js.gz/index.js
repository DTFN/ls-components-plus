import { defineComponent as n, computed as r, provide as p, openBlock as u, createBlock as c, resolveDynamicComponent as f, normalizeClass as g, unref as s, normalizeStyle as _, withCtx as y, renderSlot as d } from "vue";
import { rowContextKey as w } from "../constants/index.js";
import { rowProps as C } from "../row/index.js";
import v from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as x } from "../../../../hooks/use-namespace/index/index.js";
const $ = n({
  name: "ElRow"
}), h = /* @__PURE__ */ n({
  ...$,
  props: C,
  setup(a) {
    const t = a, o = x("row"), i = r(() => t.gutter);
    p(w, {
      gutter: i
    });
    const l = r(() => {
      const e = {};
      return t.gutter && (e.marginRight = e.marginLeft = `-${t.gutter / 2}px`), e;
    }), m = r(() => [
      o.b(),
      o.is(`justify-${t.justify}`, t.justify !== "start"),
      o.is(`align-${t.align}`, !!t.align)
    ]);
    return (e, j) => (u(), c(f(e.tag), {
      class: g(s(m)),
      style: _(s(l))
    }, {
      default: y(() => [
        d(e.$slots, "default")
      ]),
      _: 3
    }, 8, ["class", "style"]));
  }
});
var S = /* @__PURE__ */ v(h, [["__file", "row.vue"]]);
export {
  S as default
};
