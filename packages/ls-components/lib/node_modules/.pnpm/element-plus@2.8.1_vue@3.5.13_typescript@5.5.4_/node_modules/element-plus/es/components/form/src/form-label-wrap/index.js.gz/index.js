var x = Object.defineProperty;
var u = (a, l) => x(a, "name", { value: l, configurable: !0 });
import { defineComponent as E, inject as p, ref as h, onMounted as N, onBeforeUnmount as A, onUpdated as P, watch as _, computed as y, createVNode as b, Fragment as M, nextTick as F } from "vue";
import { useResizeObserver as B } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { formContextKey as I, formItemContextKey as O } from "../constants/index.js";
import { throwError as K } from "../../../../utils/error/index.js";
import { useNamespace as R } from "../../../../hooks/use-namespace/index/index.js";
const v = "ElLabelWrap";
var $ = E({
  name: v,
  props: {
    isAutoWidth: Boolean,
    updateAll: Boolean
  },
  setup(a, {
    slots: l
  }) {
    const o = p(I, void 0), n = p(O);
    n || K(v, "usage: <el-form-item><label-wrap /></el-form-item>");
    const W = R("form"), i = h(), r = h(0), L = /* @__PURE__ */ u(() => {
      var e;
      if ((e = i.value) != null && e.firstElementChild) {
        const t = window.getComputedStyle(i.value.firstElementChild).width;
        return Math.ceil(Number.parseFloat(t));
      } else
        return 0;
    }, "getLabelWidth"), s = /* @__PURE__ */ u((e = "update") => {
      F(() => {
        l.default && a.isAutoWidth && (e === "update" ? r.value = L() : e === "remove" && (o == null || o.deregisterLabelWidth(r.value)));
      });
    }, "updateLabelWidth"), d = /* @__PURE__ */ u(() => s("update"), "updateLabelWidthFn");
    return N(() => {
      d();
    }), A(() => {
      s("remove");
    }), P(() => d()), _(r, (e, t) => {
      a.updateAll && (o == null || o.registerLabelWidth(e, t));
    }), B(y(() => {
      var e, t;
      return (t = (e = i.value) == null ? void 0 : e.firstElementChild) != null ? t : null;
    }), d), () => {
      var e, t;
      if (!l)
        return null;
      const {
        isAutoWidth: g
      } = a;
      if (g) {
        const m = o == null ? void 0 : o.autoLabelWidth, C = n == null ? void 0 : n.hasLabel, f = {};
        if (C && m && m !== "auto") {
          const c = Math.max(0, Number.parseInt(m, 10) - r.value), w = (n.labelPosition || o.labelPosition) === "left" ? "marginRight" : "marginLeft";
          c && (f[w] = `${c}px`);
        }
        return b("div", {
          ref: i,
          class: [W.be("item", "label-wrap")],
          style: f
        }, [(e = l.default) == null ? void 0 : e.call(l)]);
      } else
        return b(M, {
          ref: i
        }, [(t = l.default) == null ? void 0 : t.call(l)]);
    };
  }
});
export {
  $ as default
};
