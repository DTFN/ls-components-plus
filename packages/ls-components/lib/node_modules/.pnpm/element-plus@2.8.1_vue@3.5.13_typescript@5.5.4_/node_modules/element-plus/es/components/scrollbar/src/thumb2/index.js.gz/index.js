var D = Object.defineProperty;
var n = (d, r) => D(d, "name", { value: r, configurable: !0 });
import { defineComponent as N, inject as A, ref as f, computed as w, onBeforeUnmount as O, toRef as y, openBlock as j, createBlock as K, Transition as U, unref as c, withCtx as I, withDirectives as V, createElementVNode as C, normalizeClass as k, normalizeStyle as q, vShow as F } from "vue";
import { useEventListener as z } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { scrollbarContextKey as G } from "../constants/index.js";
import { BAR_MAP as J, renderThumbStyle as Q } from "../util/index.js";
import { thumbProps as W } from "../thumb/index.js";
import X from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as Y } from "../../../../hooks/use-namespace/index/index.js";
import { throwError as Z } from "../../../../utils/error/index.js";
import { isClient as $ } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const ee = "Thumb", te = /* @__PURE__ */ N({
  __name: "thumb",
  props: W,
  setup(d) {
    const r = d, o = A(G), i = Y("scrollbar");
    o || Z(ee, "can not inject scrollbar context");
    const a = f(), u = f(), p = f({}), m = f(!1);
    let v = !1, b = !1, h = $ ? document.onselectstart : null;
    const e = w(() => J[r.vertical ? "vertical" : "horizontal"]), x = w(() => Q({
      size: r.size,
      move: r.move,
      bar: e.value
    })), _ = w(() => a.value[e.value.offset] ** 2 / o.wrapElement[e.value.scrollSize] / r.ratio / u.value[e.value.offset]), L = /* @__PURE__ */ n((t) => {
      var l;
      if (t.stopPropagation(), t.ctrlKey || [1, 2].includes(t.button))
        return;
      (l = window.getSelection()) == null || l.removeAllRanges(), T(t);
      const s = t.currentTarget;
      s && (p.value[e.value.axis] = s[e.value.offset] - (t[e.value.client] - s.getBoundingClientRect()[e.value.direction]));
    }, "clickThumbHandler"), M = /* @__PURE__ */ n((t) => {
      if (!u.value || !a.value || !o.wrapElement)
        return;
      const l = Math.abs(t.target.getBoundingClientRect()[e.value.direction] - t[e.value.client]), s = u.value[e.value.offset] / 2, g = (l - s) * 100 * _.value / a.value[e.value.offset];
      o.wrapElement[e.value.scroll] = g * o.wrapElement[e.value.scrollSize] / 100;
    }, "clickTrackHandler"), T = /* @__PURE__ */ n((t) => {
      t.stopImmediatePropagation(), v = !0, document.addEventListener("mousemove", S), document.addEventListener("mouseup", E), h = document.onselectstart, document.onselectstart = () => !1;
    }, "startDrag"), S = /* @__PURE__ */ n((t) => {
      if (!a.value || !u.value || v === !1)
        return;
      const l = p.value[e.value.axis];
      if (!l)
        return;
      const s = (a.value.getBoundingClientRect()[e.value.direction] - t[e.value.client]) * -1, g = u.value[e.value.offset] - l, R = (s - g) * 100 * _.value / a.value[e.value.offset];
      o.wrapElement[e.value.scroll] = R * o.wrapElement[e.value.scrollSize] / 100;
    }, "mouseMoveDocumentHandler"), E = /* @__PURE__ */ n(() => {
      v = !1, p.value[e.value.axis] = 0, document.removeEventListener("mousemove", S), document.removeEventListener("mouseup", E), P(), b && (m.value = !1);
    }, "mouseUpDocumentHandler"), B = /* @__PURE__ */ n(() => {
      b = !1, m.value = !!r.size;
    }, "mouseMoveScrollbarHandler"), H = /* @__PURE__ */ n(() => {
      b = !0, m.value = v;
    }, "mouseLeaveScrollbarHandler");
    O(() => {
      P(), document.removeEventListener("mouseup", E);
    });
    const P = /* @__PURE__ */ n(() => {
      document.onselectstart !== h && (document.onselectstart = h);
    }, "restoreOnselectstart");
    return z(y(o, "scrollbarElement"), "mousemove", B), z(y(o, "scrollbarElement"), "mouseleave", H), (t, l) => (j(), K(U, {
      name: c(i).b("fade"),
      persisted: ""
    }, {
      default: I(() => [
        V(C("div", {
          ref_key: "instance",
          ref: a,
          class: k([c(i).e("bar"), c(i).is(c(e).key)]),
          onMousedown: M
        }, [
          C("div", {
            ref_key: "thumb",
            ref: u,
            class: k(c(i).e("thumb")),
            style: q(c(x)),
            onMousedown: L
          }, null, 38)
        ], 34), [
          [F, t.always || m.value]
        ])
      ]),
      _: 1
    }, 8, ["name"]));
  }
});
var ve = /* @__PURE__ */ X(te, [["__file", "thumb.vue"]]);
export {
  ve as default
};
