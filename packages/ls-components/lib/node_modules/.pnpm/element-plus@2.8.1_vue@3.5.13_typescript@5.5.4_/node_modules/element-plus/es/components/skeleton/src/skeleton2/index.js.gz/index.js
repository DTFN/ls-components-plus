import { defineComponent as k, toRef as y, unref as r, openBlock as t, createElementBlock as s, mergeProps as p, Fragment as n, renderList as u, renderSlot as f, createVNode as h, normalizeClass as d, createBlock as S, createCommentVNode as $, normalizeProps as w } from "vue";
import { skeletonProps as B } from "../skeleton/index.js";
import c from "../skeleton-item2/index.js";
import C from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as N } from "../../../../hooks/use-namespace/index/index.js";
import { useThrottleRender as P } from "../../../../hooks/use-throttle-render/index/index.js";
const z = k({
  name: "ElSkeleton"
}), E = /* @__PURE__ */ k({
  ...z,
  props: B,
  setup(g, { expose: v }) {
    const a = g, o = N("skeleton"), l = P(y(a, "loading"), a.throttle);
    return v({
      uiLoading: l
    }), (e, L) => r(l) ? (t(), s("div", p({
      key: 0,
      class: [r(o).b(), r(o).is("animated", e.animated)]
    }, e.$attrs), [
      (t(!0), s(n, null, u(e.count, (m) => (t(), s(n, { key: m }, [
        e.loading ? f(e.$slots, "template", { key: m }, () => [
          h(c, {
            class: d(r(o).is("first")),
            variant: "p"
          }, null, 8, ["class"]),
          (t(!0), s(n, null, u(e.rows, (i) => (t(), S(c, {
            key: i,
            class: d([
              r(o).e("paragraph"),
              r(o).is("last", i === e.rows && e.rows > 1)
            ]),
            variant: "p"
          }, null, 8, ["class"]))), 128))
        ]) : $("v-if", !0)
      ], 64))), 128))
    ], 16)) : f(e.$slots, "default", w(p({ key: 1 }, e.$attrs)));
  }
});
var T = /* @__PURE__ */ C(E, [["__file", "skeleton.vue"]]);
export {
  T as default
};
