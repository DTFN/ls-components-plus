var b = Object.defineProperty;
var i = (l, e) => b(l, "name", { value: e, configurable: !0 });
import { h as s } from "vue";
import { ElCheckbox as u } from "../../../checkbox/index/index.js";
import { ElIcon as p } from "../../../icon/index/index.js";
import { ArrowRight as f, Loading as g } from "@element-plus/icons-vue";
import { getProp as h } from "../../../../utils/objects/index.js";
const m = {
  selection: "table-column--selection",
  expand: "table__expand-column"
}, z = {
  default: {
    order: ""
  },
  selection: {
    width: 48,
    minWidth: 48,
    realWidth: 48,
    order: ""
  },
  expand: {
    width: 48,
    minWidth: 48,
    realWidth: 48,
    order: ""
  },
  index: {
    width: 48,
    minWidth: 48,
    realWidth: 48,
    order: ""
  }
}, W = /* @__PURE__ */ i((l) => m[l] || "", "getDefaultClassName"), P = {
  selection: {
    renderHeader({ store: l, column: e }) {
      function a() {
        return l.states.data.value && l.states.data.value.length === 0;
      }
      return i(a, "isDisabled"), s(u, {
        disabled: a(),
        size: l.states.tableSize.value,
        indeterminate: l.states.selection.value.length > 0 && !l.states.isAllSelected.value,
        "onUpdate:modelValue": l.toggleAllSelection,
        modelValue: l.states.isAllSelected.value,
        ariaLabel: e.label
      });
    },
    renderCell({
      row: l,
      column: e,
      store: a,
      $index: n
    }) {
      return s(u, {
        disabled: e.selectable ? !e.selectable.call(null, l, n) : !1,
        size: a.states.tableSize.value,
        onChange: /* @__PURE__ */ i(() => {
          a.commit("rowSelectedChanged", l);
        }, "onChange"),
        onClick: /* @__PURE__ */ i((t) => t.stopPropagation(), "onClick"),
        modelValue: a.isSelected(l),
        ariaLabel: e.label
      });
    },
    sortable: !1,
    resizable: !1
  },
  index: {
    renderHeader({ column: l }) {
      return l.label || "#";
    },
    renderCell({
      column: l,
      $index: e
    }) {
      let a = e + 1;
      const n = l.index;
      return typeof n == "number" ? a = e + n : typeof n == "function" && (a = n(e)), s("div", {}, [a]);
    },
    sortable: !1
  },
  expand: {
    renderHeader({ column: l }) {
      return l.label || "";
    },
    renderCell({
      row: l,
      store: e,
      expanded: a
    }) {
      const { ns: n } = e, t = [n.e("expand-icon")];
      return a && t.push(n.em("expand-icon", "expanded")), s("div", {
        class: t,
        onClick: /* @__PURE__ */ i(function(d) {
          d.stopPropagation(), e.toggleRowExpansion(l);
        }, "callback")
      }, {
        default: /* @__PURE__ */ i(() => [
          s(p, null, {
            default: /* @__PURE__ */ i(() => [s(f)], "default")
          })
        ], "default")
      });
    },
    sortable: !1,
    resizable: !1
  }
};
function A({
  row: l,
  column: e,
  $index: a
}) {
  var n;
  const t = e.property, r = t && h(l, t).value;
  return e && e.formatter ? e.formatter(l, e, r, a) : ((n = r == null ? void 0 : r.toString) == null ? void 0 : n.call(r)) || "";
}
i(A, "defaultRenderCell");
function L({
  row: l,
  treeNode: e,
  store: a
}, n = !1) {
  const { ns: t } = a;
  if (!e)
    return n ? [
      s("span", {
        class: t.e("placeholder")
      })
    ] : null;
  const r = [], d = /* @__PURE__ */ i(function(o) {
    o.stopPropagation(), !e.loading && a.loadOrToggle(l);
  }, "callback");
  if (e.indent && r.push(s("span", {
    class: t.e("indent"),
    style: { "padding-left": `${e.indent}px` }
  })), typeof e.expanded == "boolean" && !e.noLazyChildren) {
    const o = [
      t.e("expand-icon"),
      e.expanded ? t.em("expand-icon", "expanded") : ""
    ];
    let c = f;
    e.loading && (c = g), r.push(s("div", {
      class: o,
      onClick: d
    }, {
      default: /* @__PURE__ */ i(() => [
        s(p, { class: { [t.is("loading")]: e.loading } }, {
          default: /* @__PURE__ */ i(() => [s(c)], "default")
        })
      ], "default")
    }));
  } else
    r.push(s("span", {
      class: t.e("placeholder")
    }));
  return r;
}
i(L, "treeCellPrefix");
export {
  P as cellForced,
  z as cellStarts,
  A as defaultRenderCell,
  W as getDefaultClassName,
  L as treeCellPrefix
};
