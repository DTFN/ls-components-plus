var d = Object.defineProperty;
var t = (s, n) => d(s, "name", { value: n, configurable: !0 });
import { ref as u, nextTick as m } from "vue";
import { isKorean as C } from "../../../utils/i18n/index.js";
function x({
  afterComposition: s,
  emit: n
}) {
  const i = u(!1), e = /* @__PURE__ */ t((o) => {
    n == null || n("compositionstart", o), i.value = !0;
  }, "handleCompositionStart"), a = /* @__PURE__ */ t((o) => {
    var p;
    n == null || n("compositionupdate", o);
    const r = (p = o.target) == null ? void 0 : p.value, c = r[r.length - 1] || "";
    i.value = !C(c);
  }, "handleCompositionUpdate"), l = /* @__PURE__ */ t((o) => {
    n == null || n("compositionend", o), i.value && (i.value = !1, m(() => s(o)));
  }, "handleCompositionEnd");
  return {
    isComposing: i,
    handleComposition: /* @__PURE__ */ t((o) => {
      o.type === "compositionend" ? l(o) : a(o);
    }, "handleComposition"),
    handleCompositionStart: e,
    handleCompositionUpdate: a,
    handleCompositionEnd: l
  };
}
t(x, "useComposition");
export {
  x as useComposition
};
