var l = Object.defineProperty;
var o = (n, i) => l(n, "name", { value: i, configurable: !0 });
import { buildProps as p, definePropType as e } from "../../../../utils/vue/props/runtime/index.js";
import { useTooltipTriggerProps as d } from "../../../tooltip/src/trigger/index.js";
import { useTooltipContentProps as r } from "../../../tooltip/src/content/index.js";
import { iconPropType as a } from "../../../../utils/vue/icon/index.js";
import { EVENT_CODE as t } from "../../../../constants/aria/index.js";
import { createCollectionWithScope as u } from "../../../collection/src/collection/index.js";
const N = p({
  trigger: d.trigger,
  effect: {
    ...r.effect,
    default: "light"
  },
  type: {
    type: e(String)
  },
  placement: {
    type: e(String),
    default: "bottom"
  },
  popperOptions: {
    type: e(Object),
    default: /* @__PURE__ */ o(() => ({}), "default")
  },
  id: String,
  size: {
    type: String,
    default: ""
  },
  splitButton: Boolean,
  hideOnClick: {
    type: Boolean,
    default: !0
  },
  loop: {
    type: Boolean,
    default: !0
  },
  showTimeout: {
    type: Number,
    default: 150
  },
  hideTimeout: {
    type: Number,
    default: 150
  },
  tabindex: {
    type: e([Number, String]),
    default: 0
  },
  maxHeight: {
    type: e([Number, String]),
    default: ""
  },
  popperClass: {
    type: String,
    default: ""
  },
  disabled: Boolean,
  role: {
    type: String,
    default: "menu"
  },
  buttonProps: {
    type: e(Object)
  },
  teleported: r.teleported
}), C = p({
  command: {
    type: [Object, String, Number],
    default: /* @__PURE__ */ o(() => ({}), "default")
  },
  disabled: Boolean,
  divided: Boolean,
  textValue: String,
  icon: {
    type: a
  }
}), I = p({
  onKeydown: { type: e(Function) }
}), m = [
  t.down,
  t.pageDown,
  t.home
], s = [t.up, t.pageUp, t.end], S = [...m, ...s], {
  ElCollection: _,
  ElCollectionItem: b,
  COLLECTION_INJECTION_KEY: P,
  COLLECTION_ITEM_INJECTION_KEY: L
} = u("Dropdown");
export {
  P as DROPDOWN_COLLECTION_INJECTION_KEY,
  L as DROPDOWN_COLLECTION_ITEM_INJECTION_KEY,
  _ as ElCollection,
  b as ElCollectionItem,
  m as FIRST_KEYS,
  S as FIRST_LAST_KEYS,
  s as LAST_KEYS,
  C as dropdownItemProps,
  I as dropdownMenuProps,
  N as dropdownProps
};
