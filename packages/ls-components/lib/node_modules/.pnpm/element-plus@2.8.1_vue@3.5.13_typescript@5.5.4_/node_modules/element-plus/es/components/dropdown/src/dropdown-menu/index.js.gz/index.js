var L = Object.defineProperty;
var i = (o, n) => L(o, "name", { value: n, configurable: !0 });
import { defineComponent as b, inject as r, computed as D, openBlock as Y, createElementBlock as M, normalizeClass as G, normalizeStyle as J, withModifiers as E, renderSlot as B, unref as P } from "vue";
import { DROPDOWN_INJECTION_KEY as $ } from "../tokens/index.js";
import { dropdownMenuProps as h, DROPDOWN_COLLECTION_INJECTION_KEY as z, FIRST_LAST_KEYS as U, LAST_KEYS as W } from "../dropdown/index.js";
import { useDropdown as A } from "../useDropdown/index.js";
import V from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as k } from "../../../../hooks/use-namespace/index/index.js";
import { FOCUS_TRAP_INJECTION_KEY as j } from "../../../focus-trap/src/tokens/index.js";
import { ROVING_FOCUS_GROUP_INJECTION_KEY as H } from "../../../roving-focus-group/src/tokens/index.js";
import { ROVING_FOCUS_COLLECTION_INJECTION_KEY as q } from "../../../roving-focus-group/src/roving-focus-group/index.js";
import { composeRefs as Q } from "../../../../utils/vue/refs/index.js";
import { composeEventHandlers as X } from "../../../../utils/dom/event/index.js";
import { EVENT_CODE as Z } from "../../../../constants/aria/index.js";
import { focusFirst as x } from "../../../roving-focus-group/src/utils/index.js";
const oo = b({
  name: "ElDropdownMenu",
  props: h,
  setup(o) {
    const n = k("dropdown"), { _elDropdownSize: p } = A(), t = p.value, { focusTrapRef: u, onKeydown: a } = r(j, void 0), { contentRef: m, role: I, triggerId: O } = r($, void 0), { collectionRef: _, getItems: w } = r(z, void 0), {
      rovingFocusGroupRef: N,
      rovingFocusGroupRootStyle: C,
      tabIndex: v,
      onBlur: K,
      onFocus: R,
      onMousedown: T
    } = r(H, void 0), { collectionRef: y } = r(q, void 0), g = D(() => [n.b("menu"), n.bm("menu", t == null ? void 0 : t.value)]), F = Q(m, _, u, N, y), S = X((e) => {
      var s;
      (s = o.onKeydown) == null || s.call(o, e);
    }, (e) => {
      const { currentTarget: s, code: d, target: c } = e;
      if (s.contains(c), Z.tab === d && e.stopImmediatePropagation(), e.preventDefault(), c !== P(m) || !U.includes(d))
        return;
      const f = w().filter((l) => !l.disabled).map((l) => l.ref);
      W.includes(d) && f.reverse(), x(f);
    });
    return {
      size: t,
      rovingFocusGroupRootStyle: C,
      tabIndex: v,
      dropdownKls: g,
      role: I,
      triggerId: O,
      dropdownListWrapperRef: F,
      handleKeydown: /* @__PURE__ */ i((e) => {
        S(e), a(e);
      }, "handleKeydown"),
      onBlur: K,
      onFocus: R,
      onMousedown: T
    };
  }
});
function eo(o, n, p, t, u, a) {
  return Y(), M("ul", {
    ref: o.dropdownListWrapperRef,
    class: G(o.dropdownKls),
    style: J(o.rovingFocusGroupRootStyle),
    tabindex: -1,
    role: o.role,
    "aria-labelledby": o.triggerId,
    onBlur: o.onBlur,
    onFocus: o.onFocus,
    onKeydown: E(o.handleKeydown, ["self"]),
    onMousedown: E(o.onMousedown, ["self"])
  }, [
    B(o.$slots, "default")
  ], 46, ["role", "aria-labelledby", "onBlur", "onFocus", "onKeydown", "onMousedown"]);
}
i(eo, "_sfc_render");
var wo = /* @__PURE__ */ V(oo, [["render", eo], ["__file", "dropdown-menu.vue"]]);
export {
  wo as default
};
