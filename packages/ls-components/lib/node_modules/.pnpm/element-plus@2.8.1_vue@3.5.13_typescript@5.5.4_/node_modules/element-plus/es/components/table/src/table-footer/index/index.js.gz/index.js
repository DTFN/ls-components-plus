var h = Object.defineProperty;
var d = (t, a) => h(t, "name", { value: a, configurable: !0 });
import { defineComponent as C, h as u } from "vue";
import S from "../style-helper/index.js";
import { useNamespace as g } from "../../../../../hooks/use-namespace/index/index.js";
var E = C({
  name: "ElTableFooter",
  props: {
    fixed: {
      type: String,
      default: ""
    },
    store: {
      required: !0,
      type: Object
    },
    summaryMethod: Function,
    sumText: String,
    border: Boolean,
    defaultSort: {
      type: Object,
      default: /* @__PURE__ */ d(() => ({
        prop: "",
        order: ""
      }), "default")
    }
  },
  setup(t) {
    const { getCellClasses: a, getCellStyles: p, columns: n } = S(t);
    return {
      ns: g("table"),
      getCellClasses: a,
      getCellStyles: p,
      columns: n
    };
  },
  render() {
    const { columns: t, getCellStyles: a, getCellClasses: p, summaryMethod: n, sumText: m } = this, i = this.store.states.data.value;
    let o = [];
    return n ? o = n({
      columns: t,
      data: i
    }) : t.forEach((r, e) => {
      if (e === 0) {
        o[e] = m;
        return;
      }
      const c = i.map((s) => Number(s[r.property])), f = [];
      let b = !0;
      c.forEach((s) => {
        if (!Number.isNaN(+s)) {
          b = !1;
          const l = `${s}`.split(".")[1];
          f.push(l ? l.length : 0);
        }
      });
      const y = Math.max.apply(null, f);
      b ? o[e] = "" : o[e] = c.reduce((s, l) => {
        const N = Number(l);
        return Number.isNaN(+N) ? s : Number.parseFloat((s + l).toFixed(Math.min(y, 20)));
      }, 0);
    }), u(u("tfoot", [
      u("tr", {}, [
        ...t.map((r, e) => u("td", {
          key: e,
          colspan: r.colSpan,
          rowspan: r.rowSpan,
          class: p(t, e),
          style: a(r, e)
        }, [
          u("div", {
            class: ["cell", r.labelClassName]
          }, [o[e]])
        ]))
      ])
    ]));
  }
});
export {
  E as default
};
