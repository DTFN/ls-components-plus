var h = Object.defineProperty;
var t = (e, o) => h(e, "name", { value: o, configurable: !0 });
import { defineComponent as v, inject as $, computed as n, ref as W, onMounted as w, openBlock as r, createElementBlock as p, normalizeClass as i, normalizeStyle as C, renderSlot as l, createCommentVNode as c } from "vue";
import { useResizeObserver as y } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { selectKey as M } from "../token/index.js";
import S from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as b } from "../../../../hooks/use-namespace/index/index.js";
const k = v({
  name: "ElSelectDropdown",
  componentName: "ElSelectDropdown",
  setup() {
    const e = $(M), o = b("select"), d = n(() => e.props.popperClass), a = n(() => e.props.multiple), m = n(() => e.props.fitInputWidth), s = W("");
    function u() {
      var f;
      s.value = `${(f = e.selectRef) == null ? void 0 : f.offsetWidth}px`;
    }
    return t(u, "updateMinWidth"), w(() => {
      u(), y(e.selectRef, u);
    }), {
      ns: o,
      minWidth: s,
      popperClass: d,
      isMultiple: a,
      isFitInputWidth: m
    };
  }
});
function E(e, o, d, a, m, s) {
  return r(), p("div", {
    class: i([e.ns.b("dropdown"), e.ns.is("multiple", e.isMultiple), e.popperClass]),
    style: C({ [e.isFitInputWidth ? "width" : "minWidth"]: e.minWidth })
  }, [
    e.$slots.header ? (r(), p("div", {
      key: 0,
      class: i(e.ns.be("dropdown", "header"))
    }, [
      l(e.$slots, "header")
    ], 2)) : c("v-if", !0),
    l(e.$slots, "default"),
    e.$slots.footer ? (r(), p("div", {
      key: 1,
      class: i(e.ns.be("dropdown", "footer"))
    }, [
      l(e.$slots, "footer")
    ], 2)) : c("v-if", !0)
  ], 6);
}
t(E, "_sfc_render");
var F = /* @__PURE__ */ S(k, [["render", E], ["__file", "select-dropdown.vue"]]);
export {
  F as default
};
