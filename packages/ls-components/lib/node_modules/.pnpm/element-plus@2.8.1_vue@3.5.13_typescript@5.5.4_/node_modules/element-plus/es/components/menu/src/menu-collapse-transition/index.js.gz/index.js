var i = Object.defineProperty;
var a = (e, s) => i(e, "name", { value: s, configurable: !0 });
import { defineComponent as l, openBlock as p, createBlock as c, Transition as d, mergeProps as m, withCtx as f, renderSlot as u } from "vue";
import h from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as y } from "../../../../hooks/use-namespace/index/index.js";
import { addClass as o, removeClass as n, hasClass as v } from "../../../../utils/dom/style/index.js";
const _ = l({
  name: "ElMenuCollapseTransition",
  setup() {
    const e = y("menu");
    return {
      listeners: {
        onBeforeEnter: /* @__PURE__ */ a((t) => t.style.opacity = "0.2", "onBeforeEnter"),
        onEnter(t, r) {
          o(t, `${e.namespace.value}-opacity-transition`), t.style.opacity = "1", r();
        },
        onAfterEnter(t) {
          n(t, `${e.namespace.value}-opacity-transition`), t.style.opacity = "";
        },
        onBeforeLeave(t) {
          t.dataset || (t.dataset = {}), v(t, e.m("collapse")) ? (n(t, e.m("collapse")), t.dataset.oldOverflow = t.style.overflow, t.dataset.scrollWidth = t.clientWidth.toString(), o(t, e.m("collapse"))) : (o(t, e.m("collapse")), t.dataset.oldOverflow = t.style.overflow, t.dataset.scrollWidth = t.clientWidth.toString(), n(t, e.m("collapse"))), t.style.width = `${t.scrollWidth}px`, t.style.overflow = "hidden";
        },
        onLeave(t) {
          o(t, "horizontal-collapse-transition"), t.style.width = `${t.dataset.scrollWidth}px`;
        }
      }
    };
  }
});
function $(e, s, t, r, w, C) {
  return p(), c(d, m({ mode: "out-in" }, e.listeners), {
    default: f(() => [
      u(e.$slots, "default")
    ]),
    _: 3
  }, 16);
}
a($, "_sfc_render");
var S = /* @__PURE__ */ h(_, [["render", $], ["__file", "menu-collapse-transition.vue"]]);
export {
  S as default
};
