import { defineComponent as u, inject as h, computed as r, openBlock as $, createBlock as _, resolveDynamicComponent as b, normalizeClass as g, unref as a, normalizeStyle as y, withCtx as C, renderSlot as v } from "vue";
import { colProps as x } from "../col/index.js";
import E from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { rowContextKey as j } from "../../../row/src/constants/index.js";
import { useNamespace as k } from "../../../../hooks/use-namespace/index/index.js";
import { isNumber as f } from "../../../../utils/types/index.js";
import { isObject as w } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
const B = u({
  name: "ElCol"
}), K = /* @__PURE__ */ u({
  ...B,
  props: x,
  setup(m) {
    const e = m, { gutter: n } = h(j, { gutter: r(() => 0) }), o = k("col"), i = r(() => {
      const s = {};
      return n.value && (s.paddingLeft = s.paddingRight = `${n.value / 2}px`), s;
    }), p = r(() => {
      const s = [];
      return ["span", "offset", "pull", "push"].forEach((t) => {
        const l = e[t];
        f(l) && (t === "span" ? s.push(o.b(`${e[t]}`)) : l > 0 && s.push(o.b(`${t}-${e[t]}`)));
      }), ["xs", "sm", "md", "lg", "xl"].forEach((t) => {
        f(e[t]) ? s.push(o.b(`${t}-${e[t]}`)) : w(e[t]) && Object.entries(e[t]).forEach(([l, c]) => {
          s.push(l !== "span" ? o.b(`${t}-${l}-${c}`) : o.b(`${t}-${c}`));
        });
      }), n.value && s.push(o.is("guttered")), [o.b(), s];
    });
    return (s, d) => ($(), _(b(s.tag), {
      class: g(a(p)),
      style: y(a(i))
    }, {
      default: C(() => [
        v(s.$slots, "default")
      ]),
      _: 3
    }, 8, ["class", "style"]));
  }
});
var F = /* @__PURE__ */ E(K, [["__file", "col.vue"]]);
export {
  F as default
};
