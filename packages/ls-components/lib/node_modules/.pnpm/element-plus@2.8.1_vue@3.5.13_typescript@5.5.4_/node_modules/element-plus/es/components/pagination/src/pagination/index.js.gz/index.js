var j = Object.defineProperty;
var a = (e, l) => j(e, "name", { value: l, configurable: !0 });
import { defineComponent as R, getCurrentInstance as O, computed as c, ref as k, watch as B, provide as D, h as s } from "vue";
import { ArrowLeft as G, ArrowRight as J } from "@element-plus/icons-vue";
import { elPaginationKey as K } from "../constants/index.js";
import V from "../components/prev2/index.js";
import q from "../components/next/index.js";
import F from "../components/sizes2/index.js";
import H from "../components/jumper2/index.js";
import Q from "../components/total2/index.js";
import X from "../components/pager2/index.js";
import { buildProps as Y, definePropType as Z } from "../../../../utils/vue/props/runtime/index.js";
import { isNumber as u } from "../../../../utils/types/index.js";
import { mutable as $ } from "../../../../utils/typescript/index.js";
import { iconPropType as I } from "../../../../utils/vue/icon/index.js";
import { useGlobalSize as ee, useSizeProp as te } from "../../../../hooks/use-size/index/index.js";
import { useLocale as ae } from "../../../../hooks/use-locale/index/index.js";
import { useNamespace as ne } from "../../../../hooks/use-namespace/index/index.js";
import { useDeprecated as re } from "../../../../hooks/use-deprecated/index/index.js";
import { debugWarn as ie } from "../../../../utils/error/index.js";
const n = /* @__PURE__ */ a((e) => typeof e != "number", "isAbsent"), le = Y({
  pageSize: Number,
  defaultPageSize: Number,
  total: Number,
  pageCount: Number,
  pagerCount: {
    type: Number,
    validator: /* @__PURE__ */ a((e) => u(e) && Math.trunc(e) === e && e > 4 && e < 22 && e % 2 === 1, "validator"),
    default: 7
  },
  currentPage: Number,
  defaultCurrentPage: Number,
  layout: {
    type: String,
    default: ["prev", "pager", "next", "jumper", "->", "total"].join(", ")
  },
  pageSizes: {
    type: Z(Array),
    default: /* @__PURE__ */ a(() => $([10, 20, 30, 40, 50, 100]), "default")
  },
  popperClass: {
    type: String,
    default: ""
  },
  prevText: {
    type: String,
    default: ""
  },
  prevIcon: {
    type: I,
    default: /* @__PURE__ */ a(() => G, "default")
  },
  nextText: {
    type: String,
    default: ""
  },
  nextIcon: {
    type: I,
    default: /* @__PURE__ */ a(() => J, "default")
  },
  teleported: {
    type: Boolean,
    default: !0
  },
  small: Boolean,
  size: te,
  background: Boolean,
  disabled: Boolean,
  hideOnSinglePage: Boolean
}), ue = {
  "update:current-page": /* @__PURE__ */ a((e) => u(e), "update:current-page"),
  "update:page-size": /* @__PURE__ */ a((e) => u(e), "update:page-size"),
  "size-change": /* @__PURE__ */ a((e) => u(e), "size-change"),
  change: /* @__PURE__ */ a((e, l) => u(e) && u(l), "change"),
  "current-change": /* @__PURE__ */ a((e) => u(e), "current-change"),
  "prev-click": /* @__PURE__ */ a((e) => u(e), "prev-click"),
  "next-click": /* @__PURE__ */ a((e) => u(e), "next-click")
}, w = "ElPagination";
var ke = R({
  name: w,
  props: le,
  emits: ue,
  setup(e, { emit: l, slots: C }) {
    const { t: A } = ae(), o = ne("pagination"), d = O().vnode.props || {}, P = c(() => {
      var t;
      return e.small ? "small" : (t = e.size) != null ? t : ee().value;
    });
    re({
      from: "small",
      replacement: "size",
      version: "3.0.0",
      scope: "el-pagination",
      ref: "https://element-plus.org/zh-CN/component/pagination.html"
    }, c(() => !!e.small));
    const S = "onUpdate:currentPage" in d || "onUpdate:current-page" in d || "onCurrentChange" in d, z = "onUpdate:pageSize" in d || "onUpdate:page-size" in d || "onSizeChange" in d, E = c(() => {
      if (n(e.total) && n(e.pageCount) || !n(e.currentPage) && !S)
        return !1;
      if (e.layout.includes("sizes")) {
        if (n(e.pageCount)) {
          if (!n(e.total) && !n(e.pageSize) && !z)
            return !1;
        } else if (!z)
          return !1;
      }
      return !0;
    }), x = k(n(e.defaultPageSize) ? 10 : e.defaultPageSize), y = k(n(e.defaultCurrentPage) ? 1 : e.defaultCurrentPage), v = c({
      get() {
        return n(e.pageSize) ? x.value : e.pageSize;
      },
      set(t) {
        n(e.pageSize) && (x.value = t), z && (l("update:page-size", t), l("size-change", t));
      }
    }), g = c(() => {
      let t = 0;
      return n(e.pageCount) ? n(e.total) || (t = Math.max(1, Math.ceil(e.total / v.value))) : t = e.pageCount, t;
    }), r = c({
      get() {
        return n(e.currentPage) ? y.value : e.currentPage;
      },
      set(t) {
        let i = t;
        t < 1 ? i = 1 : t > g.value && (i = g.value), n(e.currentPage) && (y.value = i), S && (l("update:current-page", i), l("current-change", i));
      }
    });
    B(g, (t) => {
      r.value > t && (r.value = t);
    }), B([r, v], (t) => {
      l("change", ...t);
    }, { flush: "post" });
    function N(t) {
      r.value = t;
    }
    a(N, "handleCurrentChange");
    function L(t) {
      v.value = t;
      const i = g.value;
      r.value > i && (r.value = i);
    }
    a(L, "handleSizeChange");
    function M() {
      e.disabled || (r.value -= 1, l("prev-click", r.value));
    }
    a(M, "prev");
    function U() {
      e.disabled || (r.value += 1, l("next-click", r.value));
    }
    a(U, "next");
    function h(t, i) {
      t && (t.props || (t.props = {}), t.props.class = [t.props.class, i].join(" "));
    }
    return a(h, "addClass"), D(K, {
      pageCount: g,
      disabled: c(() => e.disabled),
      currentPage: r,
      changeEvent: N,
      handleSizeChange: L
    }), () => {
      var t, i;
      if (!E.value)
        return ie(w, A("el.pagination.deprecationWarning")), null;
      if (!e.layout || e.hideOnSinglePage && g.value <= 1)
        return null;
      const f = [], m = [], W = s("div", { class: o.e("rightwrapper") }, m), T = {
        prev: s(V, {
          disabled: e.disabled,
          currentPage: r.value,
          prevText: e.prevText,
          prevIcon: e.prevIcon,
          onClick: M
        }),
        jumper: s(H, {
          size: P.value
        }),
        pager: s(X, {
          currentPage: r.value,
          pageCount: g.value,
          pagerCount: e.pagerCount,
          onChange: N,
          disabled: e.disabled
        }),
        next: s(q, {
          disabled: e.disabled,
          currentPage: r.value,
          pageCount: g.value,
          nextText: e.nextText,
          nextIcon: e.nextIcon,
          onClick: U
        }),
        sizes: s(F, {
          pageSize: v.value,
          pageSizes: e.pageSizes,
          popperClass: e.popperClass,
          disabled: e.disabled,
          teleported: e.teleported,
          size: P.value
        }),
        slot: (i = (t = C == null ? void 0 : C.default) == null ? void 0 : t.call(C)) != null ? i : null,
        total: s(Q, { total: n(e.total) ? 0 : e.total })
      }, _ = e.layout.split(",").map((p) => p.trim());
      let b = !1;
      return _.forEach((p) => {
        if (p === "->") {
          b = !0;
          return;
        }
        b ? m.push(T[p]) : f.push(T[p]);
      }), h(f[0], o.is("first")), h(f[f.length - 1], o.is("last")), b && m.length > 0 && (h(m[0], o.is("first")), h(m[m.length - 1], o.is("last")), f.push(W)), s("div", {
        class: [
          o.b(),
          o.is("background", e.background),
          o.m(P.value)
        ]
      }, f);
    };
  }
});
export {
  ke as default,
  ue as paginationEmits,
  le as paginationProps
};
