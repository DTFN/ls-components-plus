var h = Object.defineProperty;
var o = (r, n) => h(r, "name", { value: n, configurable: !0 });
import { defineComponent as p, inject as v, withDirectives as N, cloneVNode as w, Fragment as C, Text as O, Comment as R, createVNode as g } from "vue";
import { NOOP as F, isObject as _ } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { FORWARD_REF_INJECTION_KEY as y, useForwardRefDirective as E } from "../../../../hooks/use-forward-ref/index/index.js";
import { debugWarn as d } from "../../../../utils/error/index.js";
import { useNamespace as x } from "../../../../hooks/use-namespace/index/index.js";
const i = "ElOnlyChild", L = p({
  name: i,
  setup(r, {
    slots: n,
    attrs: e
  }) {
    var l;
    const c = v(y), m = E((l = c == null ? void 0 : c.setForwardRef) != null ? l : F);
    return () => {
      var u;
      const t = (u = n.default) == null ? void 0 : u.call(n, e);
      if (!t)
        return null;
      if (t.length > 1)
        return d(i, "requires exact only one valid child."), null;
      const a = s(t);
      return a ? N(w(a, e), [[m]]) : (d(i, "no valid child node found"), null);
    };
  }
});
function s(r) {
  if (!r)
    return null;
  const n = r;
  for (const e of n) {
    if (_(e))
      switch (e.type) {
        case R:
          continue;
        case O:
        case "svg":
          return f(e);
        case C:
          return s(e.children);
        default:
          return e;
      }
    return f(e);
  }
  return null;
}
o(s, "findFirstLegitChild");
function f(r) {
  const n = x("only-child");
  return g("span", {
    class: n.e("content")
  }, [r]);
}
o(f, "wrapTextContent");
export {
  L as OnlyChild
};
