var E = Object.defineProperty;
var r = (a, o) => E(a, "name", { value: o, configurable: !0 });
import { defineComponent as R, getCurrentInstance as T, inject as F, ref as P, onMounted as j, nextTick as O, h as s } from "vue";
import { ElCheckbox as D } from "../../../../checkbox/index/index.js";
import L from "../../filter-panel/index.js";
import N from "../../layout-observer/index.js";
import { TABLE_INJECTION_KEY as _ } from "../../tokens/index.js";
import x from "../event-helper/index.js";
import A from "../style.helper/index.js";
import B from "../utils-helper/index.js";
import { useNamespace as G } from "../../../../../hooks/use-namespace/index/index.js";
var X = R({
  name: "ElTableHeader",
  components: {
    ElCheckbox: D
  },
  props: {
    fixed: {
      type: String,
      default: ""
    },
    store: {
      required: !0,
      type: Object
    },
    border: Boolean,
    defaultSort: {
      type: Object,
      default: /* @__PURE__ */ r(() => ({
        prop: "",
        order: ""
      }), "default")
    }
  },
  setup(a, { emit: o }) {
    const c = T(), l = F(_), S = G("table"), f = P({}), { onColumnsChange: C, onScrollableChange: h } = N(l);
    j(async () => {
      await O(), await O();
      const { prop: v, order: m } = a.defaultSort;
      l == null || l.store.commit("sort", { prop: v, order: m, init: !0 });
    });
    const {
      handleHeaderClick: H,
      handleHeaderContextMenu: k,
      handleMouseDown: y,
      handleMouseMove: i,
      handleMouseOut: M,
      handleSortClick: g,
      handleFilterClick: w
    } = x(a, o), {
      getHeaderRowStyle: u,
      getHeaderRowClass: d,
      getHeaderCellStyle: n,
      getHeaderCellClass: e
    } = A(a), { isGroup: p, toggleAllSelection: t, columnRows: b } = B(a);
    return c.state = {
      onColumnsChange: C,
      onScrollableChange: h
    }, c.filterPanels = f, {
      ns: S,
      filterPanels: f,
      onColumnsChange: C,
      onScrollableChange: h,
      columnRows: b,
      getHeaderRowClass: d,
      getHeaderRowStyle: u,
      getHeaderCellClass: e,
      getHeaderCellStyle: n,
      handleHeaderClick: H,
      handleHeaderContextMenu: k,
      handleMouseDown: y,
      handleMouseMove: i,
      handleMouseOut: M,
      handleSortClick: g,
      handleFilterClick: w,
      isGroup: p,
      toggleAllSelection: t
    };
  },
  render() {
    const {
      ns: a,
      isGroup: o,
      columnRows: c,
      getHeaderCellStyle: l,
      getHeaderCellClass: S,
      getHeaderRowClass: f,
      getHeaderRowStyle: C,
      handleHeaderClick: h,
      handleHeaderContextMenu: H,
      handleMouseDown: k,
      handleMouseMove: y,
      handleSortClick: i,
      handleMouseOut: M,
      store: g,
      $parent: w
    } = this;
    let u = 1;
    return s("thead", {
      class: { [a.is("group")]: o }
    }, c.map((d, n) => s("tr", {
      class: f(n),
      key: n,
      style: C(n)
    }, d.map((e, p) => (e.rowSpan > u && (u = e.rowSpan), s("th", {
      class: S(n, p, d, e),
      colspan: e.colSpan,
      key: `${e.id}-thead`,
      rowspan: e.rowSpan,
      style: l(n, p, d, e),
      onClick: /* @__PURE__ */ r((t) => {
        t.currentTarget.classList.contains("noclick") || h(t, e);
      }, "onClick"),
      onContextmenu: /* @__PURE__ */ r((t) => H(t, e), "onContextmenu"),
      onMousedown: /* @__PURE__ */ r((t) => k(t, e), "onMousedown"),
      onMousemove: /* @__PURE__ */ r((t) => y(t, e), "onMousemove"),
      onMouseout: M
    }, [
      s("div", {
        class: [
          "cell",
          e.filteredValue && e.filteredValue.length > 0 ? "highlight" : ""
        ]
      }, [
        e.renderHeader ? e.renderHeader({
          column: e,
          $index: p,
          store: g,
          _self: w
        }) : e.label,
        e.sortable && s("span", {
          onClick: /* @__PURE__ */ r((t) => i(t, e), "onClick"),
          class: "caret-wrapper"
        }, [
          s("i", {
            onClick: /* @__PURE__ */ r((t) => i(t, e, "ascending"), "onClick"),
            class: "sort-caret ascending"
          }),
          s("i", {
            onClick: /* @__PURE__ */ r((t) => i(t, e, "descending"), "onClick"),
            class: "sort-caret descending"
          })
        ]),
        e.filterable && s(L, {
          store: g,
          placement: e.filterPlacement || "bottom-start",
          column: e,
          upDataColumn: /* @__PURE__ */ r((t, b) => {
            e[t] = b;
          }, "upDataColumn")
        }, {
          "filter-icon": /* @__PURE__ */ r(() => e.renderFilterIcon ? e.renderFilterIcon({
            filterOpened: e.filterOpened
          }) : null, "filter-icon")
        })
      ])
    ]))))));
  }
});
export {
  X as default
};
