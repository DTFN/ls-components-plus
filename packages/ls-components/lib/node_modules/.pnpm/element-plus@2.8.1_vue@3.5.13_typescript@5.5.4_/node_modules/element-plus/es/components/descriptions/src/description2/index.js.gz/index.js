var K = Object.defineProperty;
var w = (h, n) => K(h, "name", { value: n, configurable: !0 });
import { defineComponent as z, useSlots as R, provide as T, computed as I, openBlock as v, createElementBlock as y, normalizeClass as u, unref as a, createElementVNode as d, renderSlot as D, createTextVNode as C, toDisplayString as $, createCommentVNode as L, Fragment as P, renderList as j, createBlock as q } from "vue";
import A from "../descriptions-row2/index.js";
import { descriptionsKey as G } from "../token/index.js";
import { descriptionProps as H } from "../description/index.js";
import J from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as M } from "../../../../hooks/use-namespace/index/index.js";
import { useFormSize as O } from "../../../form/src/hooks/use-form-common-props/index.js";
import { flattedChildren as Q } from "../../../../utils/vue/vnode/index.js";
const U = z({
  name: "ElDescriptions"
}), W = /* @__PURE__ */ z({
  ...U,
  props: H,
  setup(h) {
    const n = h, r = M("descriptions"), B = O(), S = R();
    T(G, n);
    const V = I(() => [r.b(), r.m(B.value)]), _ = /* @__PURE__ */ w((e, o, s, t = !1) => (e.props || (e.props = {}), o > s && (e.props.span = s), t && (e.props.span = o), e), "filledNode"), F = /* @__PURE__ */ w(() => {
      if (!S.default)
        return [];
      const e = Q(S.default()).filter((i) => {
        var m;
        return ((m = i == null ? void 0 : i.type) == null ? void 0 : m.name) === "ElDescriptionsItem";
      }), o = [];
      let s = [], t = n.column, b = 0;
      const l = [];
      return e.forEach((i, m) => {
        var g, E, N;
        const f = ((g = i.props) == null ? void 0 : g.span) || 1, k = ((E = i.props) == null ? void 0 : E.rowspan) || 1, p = o.length;
        if (l[p] || (l[p] = 0), k > 1)
          for (let c = 1; c < k; c++)
            l[N = p + c] || (l[N] = 0), l[p + c]++, b++;
        if (l[p] > 0 && (t -= l[p], l[p] = 0), m < e.length - 1 && (b += f > t ? t : f), m === e.length - 1) {
          const c = n.column - b % n.column;
          s.push(_(i, c, t, !0)), o.push(s);
          return;
        }
        f < t ? (t -= f, s.push(i)) : (s.push(_(i, f, t)), o.push(s), t = n.column, s = []);
      }), o;
    }, "getRows");
    return (e, o) => (v(), y("div", {
      class: u(a(V))
    }, [
      e.title || e.extra || e.$slots.title || e.$slots.extra ? (v(), y("div", {
        key: 0,
        class: u(a(r).e("header"))
      }, [
        d("div", {
          class: u(a(r).e("title"))
        }, [
          D(e.$slots, "title", {}, () => [
            C($(e.title), 1)
          ])
        ], 2),
        d("div", {
          class: u(a(r).e("extra"))
        }, [
          D(e.$slots, "extra", {}, () => [
            C($(e.extra), 1)
          ])
        ], 2)
      ], 2)) : L("v-if", !0),
      d("div", {
        class: u(a(r).e("body"))
      }, [
        d("table", {
          class: u([a(r).e("table"), a(r).is("bordered", e.border)])
        }, [
          d("tbody", null, [
            (v(!0), y(P, null, j(F(), (s, t) => (v(), q(A, {
              key: t,
              row: s
            }, null, 8, ["row"]))), 128))
          ])
        ], 2)
      ], 2)
    ], 2));
  }
});
var le = /* @__PURE__ */ J(W, [["__file", "description.vue"]]);
export {
  le as default
};
