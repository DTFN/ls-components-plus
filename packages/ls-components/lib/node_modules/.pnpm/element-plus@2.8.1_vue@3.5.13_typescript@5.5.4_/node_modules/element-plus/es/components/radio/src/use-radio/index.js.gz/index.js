var b = Object.defineProperty;
var m = (e, t) => b(e, "name", { value: t, configurable: !0 });
import { ref as c, inject as V, computed as l } from "vue";
import { radioGroupKey as E } from "../constants/index.js";
import { isPropAbsent as d } from "../../../../utils/types/index.js";
import { UPDATE_MODEL_EVENT as h } from "../../../../constants/event/index.js";
import { useFormSize as D, useFormDisabled as g } from "../../../form/src/hooks/use-form-common-props/index.js";
import { useDeprecated as z } from "../../../../hooks/use-deprecated/index/index.js";
const T = /* @__PURE__ */ m((e, t) => {
  const r = c(), o = V(E, void 0), a = l(() => !!o), u = l(() => d(e.value) ? e.label : e.value), n = l({
    get() {
      return a.value ? o.modelValue : e.modelValue;
    },
    set(s) {
      a.value ? o.changeEvent(s) : t && t(h, s), r.value.checked = e.modelValue === u.value;
    }
  }), v = D(l(() => o == null ? void 0 : o.size)), i = g(l(() => o == null ? void 0 : o.disabled)), f = c(!1), p = l(() => i.value || a.value && n.value !== u.value ? -1 : 0);
  return z({
    from: "label act as value",
    replacement: "value",
    version: "3.0.0",
    scope: "el-radio",
    ref: "https://element-plus.org/en-US/component/radio.html"
  }, l(() => a.value && d(e.value))), {
    radioRef: r,
    isGroup: a,
    radioGroup: o,
    focus: f,
    size: v,
    disabled: i,
    tabIndex: p,
    modelValue: n,
    actualValue: u
  };
}, "useRadio");
export {
  T as useRadio
};
