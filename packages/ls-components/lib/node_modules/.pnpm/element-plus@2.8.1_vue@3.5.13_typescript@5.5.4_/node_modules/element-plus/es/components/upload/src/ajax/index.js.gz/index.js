var c = Object.defineProperty;
var d = (t, e) => c(t, "name", { value: e, configurable: !0 });
import { throwError as l } from "../../../../utils/error/index.js";
import { isArray as m } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import p from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
const h = "ElUpload", u = class u extends Error {
  constructor(e, s, n, o) {
    super(e), this.name = "UploadAjaxError", this.status = s, this.method = n, this.url = o;
  }
};
d(u, "UploadAjaxError");
let i = u;
function f(t, e, s) {
  let n;
  return s.response ? n = `${s.response.error || s.response}` : s.responseText ? n = `${s.responseText}` : n = `fail to ${e.method} ${t} ${s.status}`, new i(n, s.status, e.method, t);
}
d(f, "getError");
function E(t) {
  const e = t.responseText || t.response;
  if (!e)
    return e;
  try {
    return JSON.parse(e);
  } catch {
    return e;
  }
}
d(E, "getBody");
const L = /* @__PURE__ */ d((t) => {
  typeof XMLHttpRequest > "u" && l(h, "XMLHttpRequest is undefined");
  const e = new XMLHttpRequest(), s = t.action;
  e.upload && e.upload.addEventListener("progress", (a) => {
    const r = a;
    r.percent = a.total > 0 ? a.loaded / a.total * 100 : 0, t.onProgress(r);
  });
  const n = new FormData();
  if (t.data)
    for (const [a, r] of Object.entries(t.data))
      m(r) && r.length ? n.append(a, ...r) : n.append(a, r);
  n.append(t.filename, t.file, t.file.name), e.addEventListener("error", () => {
    t.onError(f(s, t, e));
  }), e.addEventListener("load", () => {
    if (e.status < 200 || e.status >= 300)
      return t.onError(f(s, t, e));
    t.onSuccess(E(e));
  }), e.open(t.method, s, !0), t.withCredentials && "withCredentials" in e && (e.withCredentials = !0);
  const o = t.headers || {};
  if (o instanceof Headers)
    o.forEach((a, r) => e.setRequestHeader(r, a));
  else
    for (const [a, r] of Object.entries(o))
      p(r) || e.setRequestHeader(a, String(r));
  return e.send(n), e;
}, "ajaxUpload");
export {
  i as UploadAjaxError,
  L as ajaxUpload
};
