var x = Object.defineProperty;
var m = (v, t) => x(v, "name", { value: t, configurable: !0 });
import { ref as o, isRef as w, nextTick as y } from "vue";
import { parseHeight as C } from "../util/index.js";
import { hasOwn as E } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isClient as W } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const d = class d {
  constructor(t) {
    this.observers = [], this.table = null, this.store = null, this.columns = [], this.fit = !0, this.showHeader = !0, this.height = o(null), this.scrollX = o(!1), this.scrollY = o(!1), this.bodyWidth = o(null), this.fixedWidth = o(null), this.rightFixedWidth = o(null), this.gutterWidth = 0;
    for (const e in t)
      E(t, e) && (w(this[e]) ? this[e].value = t[e] : this[e] = t[e]);
    if (!this.table)
      throw new Error("Table is required for Table Layout");
    if (!this.store)
      throw new Error("Store is required for Table Layout");
  }
  updateScrollY() {
    if (this.height.value === null)
      return !1;
    const e = this.table.refs.scrollBarRef;
    if (this.table.vnode.el && (e != null && e.wrapRef)) {
      let s = !0;
      const h = this.scrollY.value;
      return s = e.wrapRef.scrollHeight > e.wrapRef.clientHeight, this.scrollY.value = s, h !== s;
    }
    return !1;
  }
  setHeight(t, e = "height") {
    if (!W)
      return;
    const s = this.table.vnode.el;
    if (t = C(t), this.height.value = Number(t), !s && (t || t === 0))
      return y(() => this.setHeight(t, e));
    typeof t == "number" ? (s.style[e] = `${t}px`, this.updateElsHeight()) : typeof t == "string" && (s.style[e] = t, this.updateElsHeight());
  }
  setMaxHeight(t) {
    this.setHeight(t, "max-height");
  }
  getFlattenColumns() {
    const t = [];
    return this.table.store.states.columns.value.forEach((s) => {
      s.isColumnGroup ? t.push.apply(t, s.columns) : t.push(s);
    }), t;
  }
  updateElsHeight() {
    this.updateScrollY(), this.notifyObservers("scrollable");
  }
  headerDisplayNone(t) {
    if (!t)
      return !0;
    let e = t;
    for (; e.tagName !== "DIV"; ) {
      if (getComputedStyle(e).display === "none")
        return !0;
      e = e.parentElement;
    }
    return !1;
  }
  updateColumnsWidth() {
    if (!W)
      return;
    const t = this.fit, e = this.table.vnode.el.clientWidth;
    let s = 0;
    const h = this.getFlattenColumns(), r = h.filter((i) => typeof i.width != "number");
    if (h.forEach((i) => {
      typeof i.width == "number" && i.realWidth && (i.realWidth = null);
    }), r.length > 0 && t) {
      if (h.forEach((i) => {
        s += Number(i.width || i.minWidth || 80);
      }), s <= e) {
        this.scrollX.value = !1;
        const i = e - s;
        if (r.length === 1)
          r[0].realWidth = Number(r[0].minWidth || 80) + i;
        else {
          const l = r.reduce((a, n) => a + Number(n.minWidth || 80), 0), p = i / l;
          let b = 0;
          r.forEach((a, n) => {
            if (n === 0)
              return;
            const c = Math.floor(Number(a.minWidth || 80) * p);
            b += c, a.realWidth = Number(a.minWidth || 80) + c;
          }), r[0].realWidth = Number(r[0].minWidth || 80) + i - b;
        }
      } else
        this.scrollX.value = !0, r.forEach((i) => {
          i.realWidth = Number(i.minWidth);
        });
      this.bodyWidth.value = Math.max(s, e), this.table.state.resizeState.value.width = this.bodyWidth.value;
    } else
      h.forEach((i) => {
        !i.width && !i.minWidth ? i.realWidth = 80 : i.realWidth = Number(i.width || i.minWidth), s += i.realWidth;
      }), this.scrollX.value = s > e, this.bodyWidth.value = s;
    const f = this.store.states.fixedColumns.value;
    if (f.length > 0) {
      let i = 0;
      f.forEach((l) => {
        i += Number(l.realWidth || l.width);
      }), this.fixedWidth.value = i;
    }
    const u = this.store.states.rightFixedColumns.value;
    if (u.length > 0) {
      let i = 0;
      u.forEach((l) => {
        i += Number(l.realWidth || l.width);
      }), this.rightFixedWidth.value = i;
    }
    this.notifyObservers("columns");
  }
  addObserver(t) {
    this.observers.push(t);
  }
  removeObserver(t) {
    const e = this.observers.indexOf(t);
    e !== -1 && this.observers.splice(e, 1);
  }
  notifyObservers(t) {
    this.observers.forEach((s) => {
      var h, r;
      switch (t) {
        case "columns":
          (h = s.state) == null || h.onColumnsChange(this);
          break;
        case "scrollable":
          (r = s.state) == null || r.onScrollableChange(this);
          break;
        default:
          throw new Error(`Table Layout don't have event ${t}.`);
      }
    });
  }
};
m(d, "TableLayout");
let g = d;
export {
  g as default
};
