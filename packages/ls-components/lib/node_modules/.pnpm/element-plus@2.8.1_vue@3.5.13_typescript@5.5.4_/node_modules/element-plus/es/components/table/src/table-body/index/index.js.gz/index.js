import { defineComponent as E, getCurrentInstance as L, inject as A, watch as S, onUnmounted as B, h as D } from "vue";
import O from "../../layout-observer/index.js";
import { removePopper as P } from "../../util/index.js";
import { TABLE_INJECTION_KEY as j } from "../../tokens/index.js";
import k from "../render-helper/index.js";
import F from "../defaults/index.js";
import { useNamespace as J } from "../../../../../hooks/use-namespace/index/index.js";
import { addClass as N, removeClass as b } from "../../../../../utils/dom/style/index.js";
import { rAF as K } from "../../../../../utils/raf/index.js";
import { isClient as U } from "../../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
var W = E({
  name: "ElTableBody",
  props: F,
  setup(n) {
    const i = L(), m = A(j), l = J("table"), { wrappedRowRender: u, tooltipContent: g, tooltipTrigger: R } = k(n), { onColumnsChange: T, onScrollableChange: _ } = O(m), p = [];
    return S(n.store.states.hoverRow, (t, y) => {
      var f;
      const h = i == null ? void 0 : i.vnode.el, d = Array.from((h == null ? void 0 : h.children) || []).filter((o) => o == null ? void 0 : o.classList.contains(`${l.e("row")}`));
      let s = t;
      const a = (f = d[s]) == null ? void 0 : f.childNodes;
      if (a != null && a.length) {
        let o = 0;
        Array.from(a).reduce((r, c, e) => {
          var C, w;
          return ((C = a[e]) == null ? void 0 : C.colSpan) > 1 && (o = (w = a[e]) == null ? void 0 : w.colSpan), c.nodeName !== "TD" && o === 0 && r.push(e), o > 0 && o--, r;
        }, []).forEach((r) => {
          var c;
          for (s = t; s > 0; ) {
            const e = (c = d[s - 1]) == null ? void 0 : c.childNodes;
            if (e[r] && e[r].nodeName === "TD" && e[r].rowSpan > 1) {
              N(e[r], "hover-cell"), p.push(e[r]);
              break;
            }
            s--;
          }
        });
      } else
        p.forEach((o) => b(o, "hover-cell")), p.length = 0;
      !n.store.states.isComplex.value || !U || K(() => {
        const o = d[y], v = d[t];
        o && !o.classList.contains("hover-fixed-row") && b(o, "hover-row"), v && N(v, "hover-row");
      });
    }), B(() => {
      var t;
      (t = P) == null || t();
    }), {
      ns: l,
      onColumnsChange: T,
      onScrollableChange: _,
      wrappedRowRender: u,
      tooltipContent: g,
      tooltipTrigger: R
    };
  },
  render() {
    const { wrappedRowRender: n, store: i } = this, m = i.states.data.value || [];
    return D("tbody", { tabIndex: -1 }, [
      m.reduce((l, u) => l.concat(n(u, l.length)), [])
    ]);
  }
});
export {
  W as default
};
