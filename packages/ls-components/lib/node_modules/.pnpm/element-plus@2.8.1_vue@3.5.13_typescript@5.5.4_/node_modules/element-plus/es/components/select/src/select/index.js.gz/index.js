var p = Object.defineProperty;
var t = (l, r) => p(l, "name", { value: r, configurable: !0 });
import { placements as i } from "../../../../../../../../@sxzz_popperjs-es@2.11.7/node_modules/@sxzz/popperjs-es/dist/index/index.js";
import { CircleClose as n, ArrowDown as f } from "@element-plus/icons-vue";
import { buildProps as u, definePropType as e } from "../../../../utils/vue/props/runtime/index.js";
import { useSizeProp as m } from "../../../../hooks/use-size/index/index.js";
import { useTooltipContentProps as d } from "../../../tooltip/src/content/index.js";
import { iconPropType as o } from "../../../../utils/vue/icon/index.js";
import { tagProps as a } from "../../../tag/src/tag/index.js";
import { useEmptyValuesProps as s } from "../../../../hooks/use-empty-values/index/index.js";
import { useAriaProps as c } from "../../../../hooks/use-aria/index/index.js";
const w = u({
  name: String,
  id: String,
  modelValue: {
    type: [Array, String, Number, Boolean, Object],
    default: void 0
  },
  autocomplete: {
    type: String,
    default: "off"
  },
  automaticDropdown: Boolean,
  size: m,
  effect: {
    type: e(String),
    default: "light"
  },
  disabled: Boolean,
  clearable: Boolean,
  filterable: Boolean,
  allowCreate: Boolean,
  loading: Boolean,
  popperClass: {
    type: String,
    default: ""
  },
  popperOptions: {
    type: e(Object),
    default: /* @__PURE__ */ t(() => ({}), "default")
  },
  remote: Boolean,
  loadingText: String,
  noMatchText: String,
  noDataText: String,
  remoteMethod: Function,
  filterMethod: Function,
  multiple: Boolean,
  multipleLimit: {
    type: Number,
    default: 0
  },
  placeholder: {
    type: String
  },
  defaultFirstOption: Boolean,
  reserveKeyword: {
    type: Boolean,
    default: !0
  },
  valueKey: {
    type: String,
    default: "value"
  },
  collapseTags: Boolean,
  collapseTagsTooltip: Boolean,
  maxCollapseTags: {
    type: Number,
    default: 1
  },
  teleported: d.teleported,
  persistent: {
    type: Boolean,
    default: !0
  },
  clearIcon: {
    type: o,
    default: n
  },
  fitInputWidth: Boolean,
  suffixIcon: {
    type: o,
    default: f
  },
  tagType: { ...a.type, default: "info" },
  tagEffect: { ...a.effect, default: "light" },
  validateEvent: {
    type: Boolean,
    default: !0
  },
  remoteShowSuffix: Boolean,
  placement: {
    type: e(String),
    values: i,
    default: "bottom-start"
  },
  fallbackPlacements: {
    type: e(Array),
    default: ["bottom-start", "top-start", "right", "left"]
  },
  ...s,
  ...c(["ariaLabel"])
});
export {
  w as SelectProps
};
