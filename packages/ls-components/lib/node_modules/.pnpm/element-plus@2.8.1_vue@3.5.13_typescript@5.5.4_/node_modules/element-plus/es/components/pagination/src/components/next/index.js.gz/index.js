var d = Object.defineProperty;
var r = (a, e) => d(a, "name", { value: e, configurable: !0 });
import { defineComponent as p, computed as u, openBlock as n, createElementBlock as l, unref as o, toDisplayString as f, createBlock as s, withCtx as x, resolveDynamicComponent as b } from "vue";
import { ElIcon as k } from "../../../../icon/index/index.js";
import { paginationNextProps as _ } from "../next2/index.js";
import g from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as C } from "../../../../../hooks/use-locale/index/index.js";
const y = p({
  name: "ElPaginationNext"
}), v = /* @__PURE__ */ p({
  ...y,
  props: _,
  emits: ["click"],
  setup(a) {
    const e = a, { t: c } = C(), i = u(() => e.disabled || e.currentPage === e.pageCount || e.pageCount === 0);
    return (t, B) => (n(), l("button", {
      type: "button",
      class: "btn-next",
      disabled: o(i),
      "aria-label": t.nextText || o(c)("el.pagination.next"),
      "aria-disabled": o(i),
      onClick: /* @__PURE__ */ r((m) => t.$emit("click", m), "onClick")
    }, [
      t.nextText ? (n(), l("span", { key: 0 }, f(t.nextText), 1)) : (n(), s(o(k), { key: 1 }, {
        default: x(() => [
          (n(), s(b(t.nextIcon)))
        ]),
        _: 1
      }))
    ], 8, ["disabled", "aria-label", "aria-disabled", "onClick"]));
  }
});
var I = /* @__PURE__ */ g(v, [["__file", "next.vue"]]);
export {
  I as default
};
