var R = Object.defineProperty;
var o = (e, i) => R(e, "name", { value: i, configurable: !0 });
import { inject as v, computed as u, getCurrentInstance as S, toRaw as w, watch as p } from "vue";
import { selectKey as I, selectGroupKey as L } from "../token/index.js";
import { isObject as a } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { escapeStringRegexp as j } from "../../../../utils/strings/index.js";
import b from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/castArray/index.js";
import y from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/get/index.js";
function q(e, i) {
  const t = v(I), c = v(L, { disabled: !1 }), f = u(() => h(b(t.props.modelValue), e.value)), g = u(() => {
    var r;
    if (t.props.multiple) {
      const n = b((r = t.props.modelValue) != null ? r : []);
      return !f.value && n.length >= t.props.multipleLimit && t.props.multipleLimit > 0;
    } else
      return !1;
  }), m = u(() => e.label || (a(e.value) ? "" : e.value)), x = u(() => e.value || e.label || ""), O = u(() => e.disabled || i.groupDisabled || g.value), d = S(), h = /* @__PURE__ */ o((r = [], n) => {
    if (a(e.value)) {
      const s = t.props.valueKey;
      return r && r.some((l) => w(y(l, s)) === y(n, s));
    } else
      return r && r.includes(n);
  }, "contains"), K = /* @__PURE__ */ o(() => {
    !e.disabled && !c.disabled && (t.states.hoveringIndex = t.optionsArray.indexOf(d.proxy));
  }, "hoverItem"), D = /* @__PURE__ */ o((r) => {
    const n = new RegExp(j(r), "i");
    i.visible = n.test(m.value) || e.created;
  }, "updateOption");
  return p(() => m.value, () => {
    !e.created && !t.props.remote && t.setSelected();
  }), p(() => e.value, (r, n) => {
    const { remote: s, valueKey: l } = t.props;
    if (r !== n && (t.onOptionDestroy(n, d.proxy), t.onOptionCreate(d.proxy)), !e.created && !s) {
      if (l && a(r) && a(n) && r[l] === n[l])
        return;
      t.setSelected();
    }
  }), p(() => c.disabled, () => {
    i.groupDisabled = c.disabled;
  }, { immediate: !0 }), {
    select: t,
    currentLabel: m,
    currentValue: x,
    itemSelected: f,
    isDisabled: O,
    hoverItem: K,
    updateOption: D
  };
}
o(q, "useOption");
export {
  q as useOption
};
