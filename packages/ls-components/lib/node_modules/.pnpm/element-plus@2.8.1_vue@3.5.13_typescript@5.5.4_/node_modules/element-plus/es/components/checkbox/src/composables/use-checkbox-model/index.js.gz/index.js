var v = Object.defineProperty;
var s = (n, t) => v(n, "name", { value: t, configurable: !0 });
import { ref as d, getCurrentInstance as f, inject as p, computed as c } from "vue";
import { checkboxGroupContextKey as x } from "../../constants/index.js";
import { isUndefined as h } from "../../../../../utils/types/index.js";
import { isArray as g } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { UPDATE_MODEL_EVENT as E } from "../../../../../constants/event/index.js";
const V = /* @__PURE__ */ s((n) => {
  const t = d(!1), { emit: m } = f(), e = p(x, void 0), u = c(() => h(e) === !1), r = d(!1), i = c({
    get() {
      var o, l;
      return u.value ? (o = e == null ? void 0 : e.modelValue) == null ? void 0 : o.value : (l = n.modelValue) != null ? l : t.value;
    },
    set(o) {
      var l, a;
      u.value && g(o) ? (r.value = ((l = e == null ? void 0 : e.max) == null ? void 0 : l.value) !== void 0 && o.length > (e == null ? void 0 : e.max.value) && o.length > i.value.length, r.value === !1 && ((a = e == null ? void 0 : e.changeEvent) == null || a.call(e, o))) : (m(E, o), t.value = o);
    }
  });
  return {
    model: i,
    isGroup: u,
    isLimitExceeded: r
  };
}, "useCheckboxModel");
export {
  V as useCheckboxModel
};
