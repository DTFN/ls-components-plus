var U = Object.defineProperty;
var t = (e, o) => U(e, "name", { value: o, configurable: !0 });
import { onMounted as $, watchEffect as C, onBeforeUnmount as P } from "vue";
import { addUnit as L } from "../../../utils/dom/style/index.js";
const z = /* @__PURE__ */ t((e, o, g, l) => {
  let i = {
    offsetX: 0,
    offsetY: 0
  };
  const a = /* @__PURE__ */ t((f) => {
    const Y = f.clientX, w = f.clientY, { offsetX: m, offsetY: u } = i, n = e.value.getBoundingClientRect(), d = n.left, r = n.top, x = n.width, b = n.height, D = document.documentElement.clientWidth, H = document.documentElement.clientHeight, T = -d + m, W = -r + u, y = D - d - x + m, B = H - r - b + u, h = /* @__PURE__ */ t((E) => {
      let s = m + E.clientX - Y, c = u + E.clientY - w;
      l != null && l.value || (s = Math.min(Math.max(s, T), y), c = Math.min(Math.max(c, W), B)), i = {
        offsetX: s,
        offsetY: c
      }, e.value && (e.value.style.transform = `translate(${L(s)}, ${L(c)})`);
    }, "onMousemove"), p = /* @__PURE__ */ t(() => {
      document.removeEventListener("mousemove", h), document.removeEventListener("mouseup", p);
    }, "onMouseup");
    document.addEventListener("mousemove", h), document.addEventListener("mouseup", p);
  }, "onMousedown"), M = /* @__PURE__ */ t(() => {
    o.value && e.value && o.value.addEventListener("mousedown", a);
  }, "onDraggable"), v = /* @__PURE__ */ t(() => {
    o.value && e.value && o.value.removeEventListener("mousedown", a);
  }, "offDraggable"), X = /* @__PURE__ */ t(() => {
    i = {
      offsetX: 0,
      offsetY: 0
    }, e.value && (e.value.style.transform = "none");
  }, "resetPosition");
  return $(() => {
    C(() => {
      g.value ? M() : v();
    });
  }), P(() => {
    v();
  }), {
    resetPosition: X
  };
}, "useDraggable");
export {
  z as useDraggable
};
