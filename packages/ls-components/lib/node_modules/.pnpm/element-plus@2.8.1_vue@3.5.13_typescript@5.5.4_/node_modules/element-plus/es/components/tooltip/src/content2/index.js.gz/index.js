var K = Object.defineProperty;
var r = (f, u) => K(f, "name", { value: u, configurable: !0 });
import { defineComponent as P, ref as U, inject as W, computed as t, onBeforeUnmount as Y, unref as o, watch as C, openBlock as E, createBlock as T, withCtx as c, createVNode as q, Transition as F, withDirectives as G, mergeProps as Q, renderSlot as X, vShow as Z, createCommentVNode as x } from "vue";
import { onClickOutside as ee } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { ElTeleport as oe } from "../../../teleport/index/index.js";
import { TOOLTIP_INJECTION_KEY as ne } from "../constants/index.js";
import { useTooltipContentProps as te } from "../content/index.js";
import re from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { usePopperContainerId as le } from "../../../../hooks/use-popper-container/index/index.js";
import { useNamespace as ae } from "../../../../hooks/use-namespace/index/index.js";
import { composeEventHandlers as y } from "../../../../utils/dom/event/index.js";
import se from "../../../popper/src/content2/index.js";
const ie = P({
  name: "ElTooltipContent",
  inheritAttrs: !1
}), pe = /* @__PURE__ */ P({
  ...ie,
  props: te,
  setup(f, { expose: u }) {
    const n = f, { selector: k } = le(), w = ae("tooltip"), a = U(null);
    let s;
    const {
      controlled: m,
      id: B,
      open: i,
      trigger: d,
      onClose: p,
      onOpen: S,
      onShow: N,
      onHide: O,
      onBeforeShow: v,
      onBeforeHide: g
    } = W(ne, void 0), L = t(() => n.transition || `${w.namespace.value}-fade-in-linear`), _ = t(() => process.env.NODE_ENV === "test" ? !0 : n.persistent);
    Y(() => {
      s == null || s();
    });
    const A = t(() => o(_) ? !0 : o(i)), b = t(() => n.disabled ? !1 : o(i)), H = t(() => n.appendTo || k.value), I = t(() => {
      var e;
      return (e = n.style) != null ? e : {};
    }), R = t(() => !o(i)), $ = /* @__PURE__ */ r(() => {
      O();
    }, "onTransitionLeave"), h = /* @__PURE__ */ r(() => {
      if (o(m))
        return !0;
    }, "stopWhenControlled"), M = y(h, () => {
      n.enterable && o(d) === "hover" && S();
    }), z = y(h, () => {
      o(d) === "hover" && p();
    }), V = /* @__PURE__ */ r(() => {
      var e, l;
      (l = (e = a.value) == null ? void 0 : e.updatePopper) == null || l.call(e), v == null || v();
    }, "onBeforeEnter"), D = /* @__PURE__ */ r(() => {
      g == null || g();
    }, "onBeforeLeave"), j = /* @__PURE__ */ r(() => {
      N(), s = ee(t(() => {
        var e;
        return (e = a.value) == null ? void 0 : e.popperContentRef;
      }), () => {
        if (o(m))
          return;
        o(d) !== "hover" && p();
      });
    }, "onAfterShow"), J = /* @__PURE__ */ r(() => {
      n.virtualTriggering || p();
    }, "onBlur");
    return C(() => o(i), (e) => {
      e || s == null || s();
    }, {
      flush: "post"
    }), C(() => n.content, () => {
      var e, l;
      (l = (e = a.value) == null ? void 0 : e.updatePopper) == null || l.call(e);
    }), u({
      contentRef: a
    }), (e, l) => (E(), T(o(oe), {
      disabled: !e.teleported,
      to: o(H)
    }, {
      default: c(() => [
        q(F, {
          name: o(L),
          onAfterLeave: $,
          onBeforeEnter: V,
          onAfterEnter: j,
          onBeforeLeave: D
        }, {
          default: c(() => [
            o(A) ? G((E(), T(o(se), Q({
              key: 0,
              id: o(B),
              ref_key: "contentRef",
              ref: a
            }, e.$attrs, {
              "aria-label": e.ariaLabel,
              "aria-hidden": o(R),
              "boundaries-padding": e.boundariesPadding,
              "fallback-placements": e.fallbackPlacements,
              "gpu-acceleration": e.gpuAcceleration,
              offset: e.offset,
              placement: e.placement,
              "popper-options": e.popperOptions,
              strategy: e.strategy,
              effect: e.effect,
              enterable: e.enterable,
              pure: e.pure,
              "popper-class": e.popperClass,
              "popper-style": [e.popperStyle, o(I)],
              "reference-el": e.referenceEl,
              "trigger-target-el": e.triggerTargetEl,
              visible: o(b),
              "z-index": e.zIndex,
              onMouseenter: o(M),
              onMouseleave: o(z),
              onBlur: J,
              onClose: o(p)
            }), {
              default: c(() => [
                X(e.$slots, "default")
              ]),
              _: 3
            }, 16, ["id", "aria-label", "aria-hidden", "boundaries-padding", "fallback-placements", "gpu-acceleration", "offset", "placement", "popper-options", "strategy", "effect", "enterable", "pure", "popper-class", "popper-style", "reference-el", "trigger-target-el", "visible", "z-index", "onMouseenter", "onMouseleave", "onClose"])), [
              [Z, o(b)]
            ]) : x("v-if", !0)
          ]),
          _: 3
        }, 8, ["name"])
      ]),
      _: 3
    }, 8, ["disabled", "to"]));
  }
});
var Te = /* @__PURE__ */ re(pe, [["__file", "content.vue"]]);
export {
  Te as default
};
