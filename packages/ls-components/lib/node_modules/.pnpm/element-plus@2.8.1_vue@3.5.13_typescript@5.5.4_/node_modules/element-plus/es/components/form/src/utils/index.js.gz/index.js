var l = Object.defineProperty;
var i = (t, r) => l(t, "name", { value: r, configurable: !0 });
import { ref as s, computed as d } from "vue";
import { debugWarn as p } from "../../../../utils/error/index.js";
import f from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/castArray/index.js";
const m = "ElForm";
function g() {
  const t = s([]), r = d(() => {
    if (!t.value.length)
      return "0";
    const e = Math.max(...t.value);
    return e ? `${e}px` : "";
  });
  function o(e) {
    const n = t.value.indexOf(e);
    return n === -1 && r.value === "0" && p(m, `unexpected width ${e}`), n;
  }
  i(o, "getLabelWidthIndex");
  function u(e, n) {
    if (e && n) {
      const a = o(n);
      t.value.splice(a, 1, e);
    } else e && t.value.push(e);
  }
  i(u, "registerLabelWidth");
  function c(e) {
    const n = o(e);
    n > -1 && t.value.splice(n, 1);
  }
  return i(c, "deregisterLabelWidth"), {
    autoLabelWidth: r,
    registerLabelWidth: u,
    deregisterLabelWidth: c
  };
}
i(g, "useFormLabelWidth");
const L = /* @__PURE__ */ i((t, r) => {
  const o = f(r);
  return o.length > 0 ? t.filter((u) => u.prop && o.includes(u.prop)) : t;
}, "filterFields");
export {
  L as filterFields,
  g as useFormLabelWidth
};
