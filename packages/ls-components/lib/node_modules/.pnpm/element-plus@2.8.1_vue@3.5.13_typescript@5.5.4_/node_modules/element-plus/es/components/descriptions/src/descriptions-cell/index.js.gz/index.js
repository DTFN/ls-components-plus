import { defineComponent as $, inject as x, withDirectives as u, h as s } from "vue";
import { descriptionsKey as z } from "../token/index.js";
import { getNormalizedProps as K } from "../../../../utils/vue/vnode/index.js";
import { addUnit as _ } from "../../../../utils/dom/style/index.js";
import { useNamespace as O } from "../../../../hooks/use-namespace/index/index.js";
import P from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
var G = $({
  name: "ElDescriptionsCell",
  props: {
    cell: {
      type: Object
    },
    tag: {
      type: String,
      default: "td"
    },
    type: {
      type: String
    }
  },
  setup() {
    return {
      descriptions: x(z, {})
    };
  },
  render() {
    var a, b, o, h, v, c, g;
    const e = K(this.cell), r = (((a = this.cell) == null ? void 0 : a.dirs) || []).map((A) => {
      const { dir: D, arg: j, modifiers: E, value: W } = A;
      return [D, W, j, E];
    }), { border: f, direction: C } = this.descriptions, t = C === "vertical", d = ((h = (o = (b = this.cell) == null ? void 0 : b.children) == null ? void 0 : o.label) == null ? void 0 : h.call(o)) || e.label, w = (g = (c = (v = this.cell) == null ? void 0 : v.children) == null ? void 0 : c.default) == null ? void 0 : g.call(c), i = e.span, n = e.rowspan, p = e.align ? `is-${e.align}` : "", S = e.labelAlign ? `is-${e.labelAlign}` : p, y = e.className, N = e.labelClassName, m = {
      width: _(e.width),
      minWidth: _(e.minWidth)
    }, l = O("descriptions");
    switch (this.type) {
      case "label":
        return u(s(this.tag, {
          style: m,
          class: [
            l.e("cell"),
            l.e("label"),
            l.is("bordered-label", f),
            l.is("vertical-label", t),
            S,
            N
          ],
          colSpan: t ? i : 1,
          rowspan: t ? 1 : n
        }, d), r);
      case "content":
        return u(s(this.tag, {
          style: m,
          class: [
            l.e("cell"),
            l.e("content"),
            l.is("bordered-content", f),
            l.is("vertical-content", t),
            p,
            y
          ],
          colSpan: t ? i : i * 2 - 1,
          rowspan: t ? n * 2 - 1 : n
        }, w), r);
      default:
        return u(s("td", {
          style: m,
          class: [l.e("cell"), p],
          colSpan: i,
          rowspan: n
        }, [
          P(d) ? void 0 : s("span", {
            class: [l.e("label"), N]
          }, d),
          s("span", {
            class: [l.e("content"), y]
          }, w)
        ]), r);
    }
  }
});
export {
  G as default
};
