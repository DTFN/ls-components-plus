var q = Object.defineProperty;
var i = (v, u) => q(v, "name", { value: u, configurable: !0 });
import { ref as p, getCurrentInstance as B, computed as S, watch as b, unref as F } from "vue";
import { getRowIdentity as m, walkTreeNode as G } from "../../util/index.js";
function Q(v) {
  const u = p([]), s = p({}), Y = p(16), K = p(!1), y = p({}), T = p("hasChildren"), N = p("children"), D = p(!1), f = B(), R = S(() => {
    if (!v.rowKey.value)
      return {};
    const l = v.data.value || [];
    return I(l);
  }), C = S(() => {
    const l = v.rowKey.value, e = Object.keys(y.value), n = {};
    return e.length && e.forEach((a) => {
      if (y.value[a].length) {
        const o = { children: [] };
        y.value[a].forEach((d) => {
          const r = m(d, l);
          o.children.push(r), d[T.value] && !n[r] && (n[r] = { children: [] });
        }), n[a] = o;
      }
    }), n;
  }), I = /* @__PURE__ */ i((l) => {
    const e = v.rowKey.value, n = {};
    return G(l, (a, o, d) => {
      const r = m(a, e);
      Array.isArray(o) ? n[r] = {
        children: o.map((z) => m(z, e)),
        level: d
      } : K.value && (n[r] = {
        children: [],
        lazy: !0,
        level: d
      });
    }, N.value, T.value), n;
  }, "normalize"), g = /* @__PURE__ */ i((l = !1, e = ((n) => (n = f.store) == null ? void 0 : n.states.defaultExpandAll.value)()) => {
    var n;
    const a = R.value, o = C.value, d = Object.keys(a), r = {};
    if (d.length) {
      const z = F(s), w = [], A = /* @__PURE__ */ i((t, h) => {
        if (l)
          return u.value ? e || u.value.includes(h) : !!(e || t != null && t.expanded);
        {
          const c = e || u.value && u.value.includes(h);
          return !!(t != null && t.expanded || c);
        }
      }, "getExpanded");
      d.forEach((t) => {
        const h = z[t], c = { ...a[t] };
        if (c.expanded = A(h, t), c.lazy) {
          const { loaded: x = !1, loading: E = !1 } = h || {};
          c.loaded = !!x, c.loading = !!E, w.push(t);
        }
        r[t] = c;
      });
      const L = Object.keys(o);
      K.value && L.length && w.length && L.forEach((t) => {
        const h = z[t], c = o[t].children;
        if (w.includes(t)) {
          if (r[t].children.length !== 0)
            throw new Error("[ElTable]children must be an empty array.");
          r[t].children = c;
        } else {
          const { loaded: x = !1, loading: E = !1 } = h || {};
          r[t] = {
            lazy: !0,
            loaded: !!x,
            loading: !!E,
            expanded: A(h, t),
            children: c,
            level: ""
          };
        }
      });
    }
    s.value = r, (n = f.store) == null || n.updateTableScrollY();
  }, "updateTreeData");
  b(() => u.value, () => {
    g(!0);
  }), b(() => R.value, () => {
    g();
  }), b(() => C.value, () => {
    g();
  });
  const M = /* @__PURE__ */ i((l) => {
    u.value = l, g();
  }, "updateTreeExpandKeys"), O = /* @__PURE__ */ i((l, e) => {
    f.store.assertRowKey();
    const n = v.rowKey.value, a = m(l, n), o = a && s.value[a];
    if (a && o && "expanded" in o) {
      const d = o.expanded;
      e = typeof e > "u" ? !o.expanded : e, s.value[a].expanded = e, d !== e && f.emit("expand-change", l, e), f.store.updateTableScrollY();
    }
  }, "toggleTreeExpansion"), _ = /* @__PURE__ */ i((l) => {
    f.store.assertRowKey();
    const e = v.rowKey.value, n = m(l, e), a = s.value[n];
    K.value && a && "loaded" in a && !a.loaded ? j(l, n, a) : O(l, void 0);
  }, "loadOrToggle"), j = /* @__PURE__ */ i((l, e, n) => {
    const { load: a } = f.props;
    a && !s.value[e].loaded && (s.value[e].loading = !0, a(l, n, (o) => {
      if (!Array.isArray(o))
        throw new TypeError("[ElTable] data must be an array");
      s.value[e].loading = !1, s.value[e].loaded = !0, s.value[e].expanded = !0, o.length && (y.value[e] = o), f.emit("expand-change", l, !0);
    }));
  }, "loadData");
  return {
    loadData: j,
    loadOrToggle: _,
    toggleTreeExpansion: O,
    updateTreeExpandKeys: M,
    updateTreeData: g,
    normalize: I,
    states: {
      expandRowKeys: u,
      treeData: s,
      indent: Y,
      lazy: K,
      lazyTreeNodeMap: y,
      lazyColumnIdentifier: T,
      childrenColumnName: N,
      checkStrictly: D
    }
  };
}
i(Q, "useTree");
export {
  Q as default
};
