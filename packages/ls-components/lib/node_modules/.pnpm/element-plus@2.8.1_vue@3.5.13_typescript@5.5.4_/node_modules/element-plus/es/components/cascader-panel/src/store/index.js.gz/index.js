var f = Object.defineProperty;
var l = (i, e) => f(i, "name", { value: e, configurable: !0 });
import h from "../node/index.js";
import d from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isEqual/index.js";
const n = /* @__PURE__ */ l((i, e) => i.reduce((t, s) => (s.isLeaf ? t.push(s) : (!e && t.push(s), t = t.concat(n(s.children, e))), t), []), "flatNodes"), a = class a {
  constructor(e, t) {
    this.config = t;
    const s = (e || []).map((o) => new h(o, this.config));
    this.nodes = s, this.allNodes = n(s, !1), this.leafNodes = n(s, !0);
  }
  getNodes() {
    return this.nodes;
  }
  getFlattedNodes(e) {
    return e ? this.leafNodes : this.allNodes;
  }
  appendNode(e, t) {
    const s = t ? t.appendChild(e) : new h(e, this.config);
    t || this.nodes.push(s), this.allNodes.push(s), s.isLeaf && this.leafNodes.push(s);
  }
  appendNodes(e, t) {
    e.forEach((s) => this.appendNode(s, t));
  }
  getNodeByValue(e, t = !1) {
    return !e && e !== 0 ? null : this.getFlattedNodes(t).find((o) => d(o.value, e) || d(o.pathValues, e)) || null;
  }
  getSameNode(e) {
    return e && this.getFlattedNodes(!1).find(({ value: s, level: o }) => d(e.value, s) && e.level === o) || null;
  }
};
l(a, "Store");
let u = a;
export {
  u as default
};
