var a = Object.defineProperty;
var o = (e, t) => a(e, "name", { value: t, configurable: !0 });
import { buildProps as l, definePropType as n } from "../../../../utils/vue/props/runtime/index.js";
import { componentSizes as s } from "../../../../constants/size/index.js";
import { isArray as p, isString as i } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isBoolean as f } from "../../../../utils/types/index.js";
const u = l({
  size: {
    type: String,
    values: s
  },
  disabled: Boolean
}), B = l({
  ...u,
  model: Object,
  rules: {
    type: n(Object)
  },
  labelPosition: {
    type: String,
    values: ["left", "right", "top"],
    default: "right"
  },
  requireAsteriskPosition: {
    type: String,
    values: ["left", "right"],
    default: "left"
  },
  labelWidth: {
    type: [String, Number],
    default: ""
  },
  labelSuffix: {
    type: String,
    default: ""
  },
  inline: Boolean,
  inlineMessage: Boolean,
  statusIcon: Boolean,
  showMessage: {
    type: Boolean,
    default: !0
  },
  validateOnRuleChange: {
    type: Boolean,
    default: !0
  },
  hideRequiredAsterisk: Boolean,
  scrollToError: Boolean,
  scrollIntoViewOptions: {
    type: [Object, Boolean]
  }
}), b = {
  validate: /* @__PURE__ */ o((e, t, r) => (p(e) || i(e)) && f(t) && i(r), "validate")
};
export {
  b as formEmits,
  u as formMetaProps,
  B as formProps
};
