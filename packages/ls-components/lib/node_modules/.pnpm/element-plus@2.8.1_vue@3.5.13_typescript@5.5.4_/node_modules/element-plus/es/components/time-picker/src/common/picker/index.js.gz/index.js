var Xe = Object.defineProperty;
var n = (G, Q) => Xe(G, "name", { value: Q, configurable: !0 });
import { defineComponent as we, useAttrs as Ze, inject as _e, ref as k, computed as c, watch as xe, nextTick as H, unref as l, onBeforeUnmount as ea, provide as aa, openBlock as d, createBlock as f, mergeProps as la, withCtx as I, normalizeClass as y, normalizeStyle as be, withModifiers as K, resolveDynamicComponent as W, createCommentVNode as J, createElementBlock as na, createElementVNode as oe, renderSlot as ke, toDisplayString as oa } from "vue";
import { onClickOutside as ta } from "../../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { ElInput as ua } from "../../../../input/index/index.js";
import { ElIcon as Y } from "../../../../icon/index/index.js";
import { ElTooltip as ra } from "../../../../tooltip/index/index.js";
import { Clock as sa, Calendar as ia } from "@element-plus/icons-vue";
import { valueEquals as Ie, parseDate as Pe, formatter as Ce } from "../../utils/index.js";
import { timePickerDefaultProps as ca } from "../props/index.js";
import da from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as pa } from "../../../../../hooks/use-locale/index/index.js";
import { useNamespace as te } from "../../../../../hooks/use-namespace/index/index.js";
import { useFormItem as va } from "../../../../form/src/hooks/use-form-item/index.js";
import { useEmptyValues as fa } from "../../../../../hooks/use-empty-values/index/index.js";
import { debugWarn as Ve } from "../../../../../utils/error/index.js";
import { isArray as P } from "../../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { EVENT_CODE as E } from "../../../../../constants/aria/index.js";
import { useFormSize as ma } from "../../../../form/src/hooks/use-form-common-props/index.js";
import ha from "../../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isEqual/index.js";
const ya = we({
  name: "Picker"
}), ga = /* @__PURE__ */ we({
  ...ya,
  props: ca,
  emits: [
    "update:modelValue",
    "change",
    "focus",
    "blur",
    "clear",
    "calendar-change",
    "panel-change",
    "visible-change",
    "keydown"
  ],
  setup(G, { expose: Q, emit: p }) {
    const t = G, Ee = Ze(), { lang: D } = pa(), g = te("date"), S = te("input"), b = te("range"), { form: ue, formItem: O } = va(), De = _e("ElPopperOptions", {}), { valueOnClear: $ } = fa(t, null), X = k(), C = k(), r = k(!1), Z = k(!1), re = k(null);
    let _ = !1, F = !1;
    const Se = c(() => [
      g.b("editor"),
      g.bm("editor", t.type),
      S.e("wrapper"),
      g.is("disabled", v.value),
      g.is("active", r.value),
      b.b("editor"),
      ae ? b.bm("editor", ae.value) : "",
      Ee.class
    ]), Fe = c(() => [
      S.e("icon"),
      b.e("close-icon"),
      w.value ? "" : b.e("close-icon--hidden")
    ]);
    xe(r, (e) => {
      e ? H(() => {
        e && (re.value = t.modelValue);
      }) : (u.value = null, H(() => {
        x(t.modelValue);
      }));
    });
    const x = /* @__PURE__ */ n((e, a) => {
      (a || !Ie(e, re.value)) && (p("change", e), t.validateEvent && (O == null || O.validate("change").catch((o) => Ve(o))));
    }, "emitChange"), V = /* @__PURE__ */ n((e) => {
      if (!Ie(t.modelValue, e)) {
        let a;
        P(e) ? a = e.map((o) => Ce(o, t.valueFormat, D.value)) : e && (a = Ce(e, t.valueFormat, D.value)), p("update:modelValue", e && a, D.value);
      }
    }, "emitInput"), Te = /* @__PURE__ */ n((e) => {
      p("keydown", e);
    }, "emitKeydown"), T = c(() => {
      if (C.value) {
        const e = j.value ? C.value : C.value.$el;
        return Array.from(e.querySelectorAll("input"));
      }
      return [];
    }), Re = /* @__PURE__ */ n((e, a, o) => {
      const s = T.value;
      s.length && (!o || o === "min" ? (s[0].setSelectionRange(e, a), s[0].focus()) : o === "max" && (s[1].setSelectionRange(e, a), s[1].focus()));
    }, "setSelectionRange"), Me = /* @__PURE__ */ n(() => {
      ee(!0, !0), H(() => {
        F = !1;
      });
    }, "focusOnInputBox"), se = /* @__PURE__ */ n((e = "", a = !1) => {
      a || (F = !0), r.value = a;
      let o;
      P(e) ? o = e.map((s) => s.toDate()) : o = e && e.toDate(), u.value = null, V(o);
    }, "onPick"), Be = /* @__PURE__ */ n(() => {
      Z.value = !0;
    }, "onBeforeShow"), Ke = /* @__PURE__ */ n(() => {
      p("visible-change", !0);
    }, "onShow"), Oe = /* @__PURE__ */ n((e) => {
      (e == null ? void 0 : e.key) === E.esc && ee(!0, !0);
    }, "onKeydownPopperContent"), $e = /* @__PURE__ */ n(() => {
      Z.value = !1, r.value = !1, F = !1, p("visible-change", !1);
    }, "onHide"), Ae = /* @__PURE__ */ n(() => {
      r.value = !0;
    }, "handleOpen"), Ne = /* @__PURE__ */ n(() => {
      r.value = !1;
    }, "handleClose"), ee = /* @__PURE__ */ n((e = !0, a = !1) => {
      F = a;
      const [o, s] = l(T);
      let h = o;
      !e && j.value && (h = s), h && h.focus();
    }, "focus"), R = /* @__PURE__ */ n((e) => {
      t.readonly || v.value || r.value || F || (r.value = !0, p("focus", e));
    }, "handleFocusInput");
    let ie;
    const A = /* @__PURE__ */ n((e) => {
      const a = /* @__PURE__ */ n(async () => {
        setTimeout(() => {
          var o;
          ie === a && (!((o = X.value) != null && o.isFocusInsideContent() && !_) && T.value.filter((s) => s.contains(document.activeElement)).length === 0 && (le(), r.value = !1, p("blur", e), t.validateEvent && (O == null || O.validate("blur").catch((s) => Ve(s)))), _ = !1);
        }, 0);
      }, "handleBlurDefer");
      ie = a, a();
    }, "handleBlurInput"), v = c(() => t.disabled || (ue == null ? void 0 : ue.disabled)), N = c(() => {
      let e;
      if (M.value ? i.value.getDefaultValue && (e = i.value.getDefaultValue()) : P(t.modelValue) ? e = t.modelValue.map((a) => Pe(a, t.valueFormat, D.value)) : e = Pe(t.modelValue, t.valueFormat, D.value), i.value.getRangeAvailableTime) {
        const a = i.value.getRangeAvailableTime(e);
        ha(a, e) || (e = a, M.value || V(P(e) ? e.map((o) => o.toDate()) : e.toDate()));
      }
      return P(e) && e.some((a) => !a) && (e = []), e;
    }), m = c(() => {
      if (!i.value.panelReady)
        return "";
      const e = ne(N.value);
      return P(u.value) ? [
        u.value[0] || e && e[0] || "",
        u.value[1] || e && e[1] || ""
      ] : u.value !== null ? u.value : !Ue.value && M.value || !r.value && M.value ? "" : e ? ce.value || de.value || pe.value ? e.join(", ") : e : "";
    }), ze = c(() => t.type.includes("time")), Ue = c(() => t.type.startsWith("time")), ce = c(() => t.type === "dates"), de = c(() => t.type === "months"), pe = c(() => t.type === "years"), z = c(() => t.prefixIcon || (ze.value ? sa : ia)), w = k(!1), ve = /* @__PURE__ */ n((e) => {
      t.readonly || v.value || (w.value && (e.stopPropagation(), Me(), i.value.handleClear ? i.value.handleClear() : V($.value), x($.value, !0), w.value = !1, r.value = !1), p("clear"));
    }, "onClearIconClick"), M = c(() => {
      const { modelValue: e } = t;
      return !e || P(e) && !e.filter(Boolean).length;
    }), B = /* @__PURE__ */ n(async (e) => {
      var a;
      t.readonly || v.value || (((a = e.target) == null ? void 0 : a.tagName) !== "INPUT" || T.value.includes(document.activeElement)) && (r.value = !0);
    }, "onMouseDownInput"), fe = /* @__PURE__ */ n(() => {
      t.readonly || v.value || !M.value && t.clearable && (w.value = !0);
    }, "onMouseEnter"), me = /* @__PURE__ */ n(() => {
      w.value = !1;
    }, "onMouseLeave"), U = /* @__PURE__ */ n((e) => {
      var a;
      t.readonly || v.value || (((a = e.touches[0].target) == null ? void 0 : a.tagName) !== "INPUT" || T.value.includes(document.activeElement)) && (r.value = !0);
    }, "onTouchStartInput"), j = c(() => t.type.includes("range")), ae = ma(), je = c(() => {
      var e, a;
      return (a = (e = l(X)) == null ? void 0 : e.popperRef) == null ? void 0 : a.contentRef;
    }), he = c(() => {
      var e;
      return l(j) ? l(C) : (e = l(C)) == null ? void 0 : e.$el;
    }), ye = ta(he, (e) => {
      const a = l(je), o = l(he);
      a && (e.target === a || e.composedPath().includes(a)) || e.target === o || e.composedPath().includes(o) || (r.value = !1);
    });
    ea(() => {
      ye == null || ye();
    });
    const u = k(null), le = /* @__PURE__ */ n(() => {
      if (u.value) {
        const e = L(m.value);
        e && q(e) && (V(P(e) ? e.map((a) => a.toDate()) : e.toDate()), u.value = null);
      }
      u.value === "" && (V($.value), x($.value), u.value = null);
    }, "handleChange"), L = /* @__PURE__ */ n((e) => e ? i.value.parseUserInput(e) : null, "parseUserInputToDayjs"), ne = /* @__PURE__ */ n((e) => e ? i.value.formatToString(e) : null, "formatDayjsToString"), q = /* @__PURE__ */ n((e) => i.value.isValidValue(e), "isValidValue"), ge = /* @__PURE__ */ n(async (e) => {
      if (t.readonly || v.value)
        return;
      const { code: a } = e;
      if (Te(e), a === E.esc) {
        r.value === !0 && (r.value = !1, e.preventDefault(), e.stopPropagation());
        return;
      }
      if (a === E.down && (i.value.handleFocusPicker && (e.preventDefault(), e.stopPropagation()), r.value === !1 && (r.value = !0, await H()), i.value.handleFocusPicker)) {
        i.value.handleFocusPicker();
        return;
      }
      if (a === E.tab) {
        _ = !0;
        return;
      }
      if (a === E.enter || a === E.numpadEnter) {
        (u.value === null || u.value === "" || q(L(m.value))) && (le(), r.value = !1), e.stopPropagation();
        return;
      }
      if (u.value) {
        e.stopPropagation();
        return;
      }
      i.value.handleKeydownInput && i.value.handleKeydownInput(e);
    }, "handleKeydownInput"), Le = /* @__PURE__ */ n((e) => {
      u.value = e, r.value || (r.value = !0);
    }, "onUserInput"), qe = /* @__PURE__ */ n((e) => {
      const a = e.target;
      u.value ? u.value = [a.value, u.value[1]] : u.value = [a.value, null];
    }, "handleStartInput"), He = /* @__PURE__ */ n((e) => {
      const a = e.target;
      u.value ? u.value = [u.value[0], a.value] : u.value = [null, a.value];
    }, "handleEndInput"), We = /* @__PURE__ */ n(() => {
      var e;
      const a = u.value, o = L(a && a[0]), s = l(N);
      if (o && o.isValid()) {
        u.value = [
          ne(o),
          ((e = m.value) == null ? void 0 : e[1]) || null
        ];
        const h = [o, s && (s[1] || null)];
        q(h) && (V(h), u.value = null);
      }
    }, "handleStartChange"), Je = /* @__PURE__ */ n(() => {
      var e;
      const a = l(u), o = L(a && a[1]), s = l(N);
      if (o && o.isValid()) {
        u.value = [
          ((e = l(m)) == null ? void 0 : e[0]) || null,
          ne(o)
        ];
        const h = [s && s[0], o];
        q(h) && (V(h), u.value = null);
      }
    }, "handleEndChange"), i = k({}), Ye = /* @__PURE__ */ n((e) => {
      i.value[e[0]] = e[1], i.value.panelReady = !0;
    }, "onSetPickerOption"), Ge = /* @__PURE__ */ n((e) => {
      p("calendar-change", e);
    }, "onCalendarChange"), Qe = /* @__PURE__ */ n((e, a, o) => {
      p("panel-change", e, a, o);
    }, "onPanelChange");
    return aa("EP_PICKER_BASE", {
      props: t
    }), Q({
      focus: ee,
      handleFocusInput: R,
      handleBlurInput: A,
      handleOpen: Ae,
      handleClose: Ne,
      onPick: se
    }), (e, a) => (d(), f(l(ra), la({
      ref_key: "refPopper",
      ref: X,
      visible: r.value,
      effect: "light",
      pure: "",
      trigger: "click"
    }, e.$attrs, {
      role: "dialog",
      teleported: "",
      transition: `${l(g).namespace.value}-zoom-in-top`,
      "popper-class": [`${l(g).namespace.value}-picker__popper`, e.popperClass],
      "popper-options": l(De),
      "fallback-placements": ["bottom", "top", "right", "left"],
      "gpu-acceleration": !1,
      "stop-popper-mouse-event": !1,
      "hide-after": 0,
      persistent: "",
      onBeforeShow: Be,
      onShow: Ke,
      onHide: $e
    }), {
      default: I(() => [
        l(j) ? (d(), na("div", {
          key: 1,
          ref_key: "inputRef",
          ref: C,
          class: y(l(Se)),
          style: be(e.$attrs.style),
          onClick: R,
          onMouseenter: fe,
          onMouseleave: me,
          onTouchstartPassive: U,
          onKeydown: ge
        }, [
          l(z) ? (d(), f(l(Y), {
            key: 0,
            class: y([l(S).e("icon"), l(b).e("icon")]),
            onMousedown: K(B, ["prevent"]),
            onTouchstartPassive: U
          }, {
            default: I(() => [
              (d(), f(W(l(z))))
            ]),
            _: 1
          }, 8, ["class", "onMousedown"])) : J("v-if", !0),
          oe("input", {
            id: e.id && e.id[0],
            autocomplete: "off",
            name: e.name && e.name[0],
            placeholder: e.startPlaceholder,
            value: l(m) && l(m)[0],
            disabled: l(v),
            readonly: !e.editable || e.readonly,
            class: y(l(b).b("input")),
            onMousedown: B,
            onInput: qe,
            onChange: We,
            onFocus: R,
            onBlur: A
          }, null, 42, ["id", "name", "placeholder", "value", "disabled", "readonly"]),
          ke(e.$slots, "range-separator", {}, () => [
            oe("span", {
              class: y(l(b).b("separator"))
            }, oa(e.rangeSeparator), 3)
          ]),
          oe("input", {
            id: e.id && e.id[1],
            autocomplete: "off",
            name: e.name && e.name[1],
            placeholder: e.endPlaceholder,
            value: l(m) && l(m)[1],
            disabled: l(v),
            readonly: !e.editable || e.readonly,
            class: y(l(b).b("input")),
            onMousedown: B,
            onFocus: R,
            onBlur: A,
            onInput: He,
            onChange: Je
          }, null, 42, ["id", "name", "placeholder", "value", "disabled", "readonly"]),
          e.clearIcon ? (d(), f(l(Y), {
            key: 1,
            class: y(l(Fe)),
            onClick: ve
          }, {
            default: I(() => [
              (d(), f(W(e.clearIcon)))
            ]),
            _: 1
          }, 8, ["class"])) : J("v-if", !0)
        ], 38)) : (d(), f(l(ua), {
          key: 0,
          id: e.id,
          ref_key: "inputRef",
          ref: C,
          "container-role": "combobox",
          "model-value": l(m),
          name: e.name,
          size: l(ae),
          disabled: l(v),
          placeholder: e.placeholder,
          class: y([l(g).b("editor"), l(g).bm("editor", e.type), e.$attrs.class]),
          style: be(e.$attrs.style),
          readonly: !e.editable || e.readonly || l(ce) || l(de) || l(pe) || e.type === "week",
          "aria-label": e.ariaLabel,
          tabindex: e.tabindex,
          "validate-event": !1,
          onInput: Le,
          onFocus: R,
          onBlur: A,
          onKeydown: ge,
          onChange: le,
          onMousedown: B,
          onMouseenter: fe,
          onMouseleave: me,
          onTouchstartPassive: U,
          onClick: K(() => {
          }, ["stop"])
        }, {
          prefix: I(() => [
            l(z) ? (d(), f(l(Y), {
              key: 0,
              class: y(l(S).e("icon")),
              onMousedown: K(B, ["prevent"]),
              onTouchstartPassive: U
            }, {
              default: I(() => [
                (d(), f(W(l(z))))
              ]),
              _: 1
            }, 8, ["class", "onMousedown"])) : J("v-if", !0)
          ]),
          suffix: I(() => [
            w.value && e.clearIcon ? (d(), f(l(Y), {
              key: 0,
              class: y(`${l(S).e("icon")} clear-icon`),
              onClick: K(ve, ["stop"])
            }, {
              default: I(() => [
                (d(), f(W(e.clearIcon)))
              ]),
              _: 1
            }, 8, ["class", "onClick"])) : J("v-if", !0)
          ]),
          _: 1
        }, 8, ["id", "model-value", "name", "size", "disabled", "placeholder", "class", "style", "readonly", "aria-label", "tabindex", "onKeydown", "onClick"]))
      ]),
      content: I(() => [
        ke(e.$slots, "default", {
          visible: r.value,
          actualVisible: Z.value,
          parsedValue: l(N),
          format: e.format,
          dateFormat: e.dateFormat,
          timeFormat: e.timeFormat,
          unlinkPanels: e.unlinkPanels,
          type: e.type,
          defaultValue: e.defaultValue,
          onPick: se,
          onSelectRange: Re,
          onSetPickerOption: Ye,
          onCalendarChange: Ge,
          onPanelChange: Qe,
          onKeydown: Oe,
          onMousedown: K(() => {
          }, ["stop"])
        })
      ]),
      _: 3
    }, 16, ["visible", "transition", "popper-class", "popper-options"]));
  }
});
var Na = /* @__PURE__ */ da(ga, [["__file", "picker.vue"]]);
export {
  Na as default
};
