var Oe = Object.defineProperty;
var u = (O, H) => Oe(O, "name", { value: H, configurable: !0 });
import { defineComponent as we, useAttrs as He, useSlots as Le, computed as r, shallowRef as W, ref as j, watch as U, nextTick as g, onMounted as Te, toRef as De, openBlock as s, createElementBlock as d, mergeProps as Y, unref as o, createCommentVNode as l, Fragment as q, normalizeClass as i, renderSlot as N, createElementVNode as C, createBlock as m, withCtx as V, resolveDynamicComponent as A, withModifiers as Ke, createVNode as We, toDisplayString as B, normalizeStyle as je } from "vue";
import { useResizeObserver as Ue } from "../../../../../../../../@vueuse_core@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/core/index/index.js";
import { ElIcon as z } from "../../../icon/index/index.js";
import { View as Ye, Hide as qe, CircleClose as Ge } from "@element-plus/icons-vue";
import { calcTextareaHeight as me } from "../utils/index.js";
import { inputProps as Je, inputEmits as Qe } from "../input/index.js";
import Xe from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useAttrs as Ze } from "../../../../hooks/use-attrs/index/index.js";
import { useFormItem as _e, useFormItemInputId as eo } from "../../../form/src/hooks/use-form-item/index.js";
import { useFormSize as oo, useFormDisabled as ao } from "../../../form/src/hooks/use-form-common-props/index.js";
import { useNamespace as ve } from "../../../../hooks/use-namespace/index/index.js";
import { useFocusController as to } from "../../../../hooks/use-focus-controller/index/index.js";
import { debugWarn as G } from "../../../../utils/error/index.js";
import { ValidateComponentsMap as no } from "../../../../utils/vue/icon/index.js";
import { useCursor as so } from "../../../../hooks/use-cursor/index/index.js";
import { NOOP as ro, isObject as he } from "../../../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { UPDATE_MODEL_EVENT as ye } from "../../../../constants/event/index.js";
import { useComposition as lo } from "../../../../hooks/use-composition/index/index.js";
import io from "../../../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
import { isClient as uo } from "../../../../../../../../@vueuse_shared@9.13.0_vue@3.5.13_typescript@5.5.4_/node_modules/@vueuse/shared/index/index.js";
const po = we({
  name: "ElInput",
  inheritAttrs: !1
}), co = /* @__PURE__ */ we({
  ...po,
  props: Je,
  emits: Qe,
  setup(O, { expose: H, emit: p }) {
    const a = O, I = He(), x = Le(), J = r(() => {
      const e = {};
      return a.containerRole === "combobox" && (e["aria-haspopup"] = I["aria-haspopup"], e["aria-owns"] = I["aria-owns"], e["aria-expanded"] = I["aria-expanded"]), e;
    }), be = r(() => [
      a.type === "textarea" ? _.b() : t.b(),
      t.m(Ce.value),
      t.is("disabled", h.value),
      t.is("exceed", Ve.value),
      {
        [t.b("group")]: x.prepend || x.append,
        [t.m("prefix")]: x.prefix || a.prefixIcon,
        [t.m("suffix")]: x.suffix || a.suffixIcon || a.clearable || a.showPassword,
        [t.bm("suffix", "password-clear")]: M.value && T.value,
        [t.b("hidden")]: a.type === "hidden"
      },
      I.class
    ]), ge = r(() => [
      t.e("wrapper"),
      t.is("focus", $.value)
    ]), Q = Ze({
      excludeKeys: r(() => Object.keys(J.value))
    }), { form: X, formItem: c } = _e(), { inputId: Z } = eo(a, {
      formItemContext: c
    }), Ce = oo(), h = ao(), t = ve("input"), _ = ve("textarea"), R = W(), f = W(), L = j(!1), F = j(!1), ee = j(), P = W(a.inputStyle), y = r(() => R.value || f.value), { wrapperRef: Ie, isFocused: $, handleFocus: xe, handleBlur: ke } = to(y, {
      afterBlur() {
        var e;
        a.validateEvent && ((e = c == null ? void 0 : c.validate) == null || e.call(c, "blur").catch((n) => G(n)));
      }
    }), oe = r(() => {
      var e;
      return (e = X == null ? void 0 : X.statusIcon) != null ? e : !1;
    }), k = r(() => (c == null ? void 0 : c.validateState) || ""), ae = r(() => k.value && no[k.value]), Se = r(() => F.value ? Ye : qe), Ee = r(() => [
      I.style
    ]), te = r(() => [
      a.inputStyle,
      P.value,
      { resize: a.resize }
    ]), v = r(() => io(a.modelValue) ? "" : String(a.modelValue)), M = r(() => a.clearable && !h.value && !a.readonly && !!v.value && ($.value || L.value)), T = r(() => a.showPassword && !h.value && !a.readonly && !!v.value && (!!v.value || $.value)), w = r(() => a.showWordLimit && !!a.maxlength && (a.type === "text" || a.type === "textarea") && !h.value && !a.readonly && !a.showPassword), D = r(() => v.value.length), Ve = r(() => !!w.value && D.value > Number(a.maxlength)), ze = r(() => !!x.suffix || !!a.suffixIcon || M.value || a.showPassword || w.value || !!k.value && oe.value), [Re, Fe] = so(R);
    Ue(f, (e) => {
      if (Pe(), !w.value || a.resize !== "both")
        return;
      const n = e[0], { width: b } = n.contentRect;
      ee.value = {
        right: `calc(100% - ${b + 15 + 6}px)`
      };
    });
    const S = /* @__PURE__ */ u(() => {
      const { type: e, autosize: n } = a;
      if (!(!uo || e !== "textarea" || !f.value))
        if (n) {
          const b = he(n) ? n.minRows : void 0, ce = he(n) ? n.maxRows : void 0, fe = me(f.value, b, ce);
          P.value = {
            overflowY: "hidden",
            ...fe
          }, g(() => {
            f.value.offsetHeight, P.value = fe;
          });
        } else
          P.value = {
            minHeight: me(f.value).minHeight
          };
    }, "resizeTextarea"), Pe = (/* @__PURE__ */ u((e) => {
      let n = !1;
      return () => {
        var b;
        if (n || !a.autosize)
          return;
        ((b = f.value) == null ? void 0 : b.offsetParent) === null || (e(), n = !0);
      };
    }, "createOnceInitResize"))(S), E = /* @__PURE__ */ u(() => {
      const e = y.value, n = a.formatter ? a.formatter(v.value) : v.value;
      !e || e.value === n || (e.value = n);
    }, "setNativeInputValue"), K = /* @__PURE__ */ u(async (e) => {
      Re();
      let { value: n } = e.target;
      if (a.formatter && (n = a.parser ? a.parser(n) : n), !se.value) {
        if (n === v.value) {
          E();
          return;
        }
        p(ye, n), p("input", n), await g(), E(), Fe();
      }
    }, "handleInput"), ne = /* @__PURE__ */ u((e) => {
      p("change", e.target.value);
    }, "handleChange"), {
      isComposing: se,
      handleCompositionStart: re,
      handleCompositionUpdate: le,
      handleCompositionEnd: ie
    } = lo({ emit: p, afterComposition: K }), $e = /* @__PURE__ */ u(() => {
      F.value = !F.value, ue();
    }, "handlePasswordVisible"), ue = /* @__PURE__ */ u(async () => {
      var e;
      await g(), (e = y.value) == null || e.focus();
    }, "focus"), Me = /* @__PURE__ */ u(() => {
      var e;
      return (e = y.value) == null ? void 0 : e.blur();
    }, "blur"), Ne = /* @__PURE__ */ u((e) => {
      L.value = !1, p("mouseleave", e);
    }, "handleMouseLeave"), Ae = /* @__PURE__ */ u((e) => {
      L.value = !0, p("mouseenter", e);
    }, "handleMouseEnter"), pe = /* @__PURE__ */ u((e) => {
      p("keydown", e);
    }, "handleKeydown"), Be = /* @__PURE__ */ u(() => {
      var e;
      (e = y.value) == null || e.select();
    }, "select"), de = /* @__PURE__ */ u(() => {
      p(ye, ""), p("change", ""), p("clear"), p("input", "");
    }, "clear");
    return U(() => a.modelValue, () => {
      var e;
      g(() => S()), a.validateEvent && ((e = c == null ? void 0 : c.validate) == null || e.call(c, "change").catch((n) => G(n)));
    }), U(v, () => E()), U(() => a.type, async () => {
      await g(), E(), S();
    }), Te(() => {
      !a.formatter && a.parser && G("ElInput", "If you set the parser, you also need to set the formatter."), E(), g(S);
    }), H({
      input: R,
      textarea: f,
      ref: y,
      textareaStyle: te,
      autosize: De(a, "autosize"),
      isComposing: se,
      focus: ue,
      blur: Me,
      select: Be,
      clear: de,
      resizeTextarea: S
    }), (e, n) => (s(), d("div", Y(o(J), {
      class: [
        o(be),
        {
          [o(t).bm("group", "append")]: e.$slots.append,
          [o(t).bm("group", "prepend")]: e.$slots.prepend
        }
      ],
      style: o(Ee),
      role: e.containerRole,
      onMouseenter: Ae,
      onMouseleave: Ne
    }), [
      l(" input "),
      e.type !== "textarea" ? (s(), d(q, { key: 0 }, [
        l(" prepend slot "),
        e.$slots.prepend ? (s(), d("div", {
          key: 0,
          class: i(o(t).be("group", "prepend"))
        }, [
          N(e.$slots, "prepend")
        ], 2)) : l("v-if", !0),
        C("div", {
          ref_key: "wrapperRef",
          ref: Ie,
          class: i(o(ge))
        }, [
          l(" prefix slot "),
          e.$slots.prefix || e.prefixIcon ? (s(), d("span", {
            key: 0,
            class: i(o(t).e("prefix"))
          }, [
            C("span", {
              class: i(o(t).e("prefix-inner"))
            }, [
              N(e.$slots, "prefix"),
              e.prefixIcon ? (s(), m(o(z), {
                key: 0,
                class: i(o(t).e("icon"))
              }, {
                default: V(() => [
                  (s(), m(A(e.prefixIcon)))
                ]),
                _: 1
              }, 8, ["class"])) : l("v-if", !0)
            ], 2)
          ], 2)) : l("v-if", !0),
          C("input", Y({
            id: o(Z),
            ref_key: "input",
            ref: R,
            class: o(t).e("inner")
          }, o(Q), {
            minlength: e.minlength,
            maxlength: e.maxlength,
            type: e.showPassword ? F.value ? "text" : "password" : e.type,
            disabled: o(h),
            readonly: e.readonly,
            autocomplete: e.autocomplete,
            tabindex: e.tabindex,
            "aria-label": e.ariaLabel,
            placeholder: e.placeholder,
            style: e.inputStyle,
            form: e.form,
            autofocus: e.autofocus,
            onCompositionstart: o(re),
            onCompositionupdate: o(le),
            onCompositionend: o(ie),
            onInput: K,
            onChange: ne,
            onKeydown: pe
          }), null, 16, ["id", "minlength", "maxlength", "type", "disabled", "readonly", "autocomplete", "tabindex", "aria-label", "placeholder", "form", "autofocus", "onCompositionstart", "onCompositionupdate", "onCompositionend"]),
          l(" suffix slot "),
          o(ze) ? (s(), d("span", {
            key: 1,
            class: i(o(t).e("suffix"))
          }, [
            C("span", {
              class: i(o(t).e("suffix-inner"))
            }, [
              !o(M) || !o(T) || !o(w) ? (s(), d(q, { key: 0 }, [
                N(e.$slots, "suffix"),
                e.suffixIcon ? (s(), m(o(z), {
                  key: 0,
                  class: i(o(t).e("icon"))
                }, {
                  default: V(() => [
                    (s(), m(A(e.suffixIcon)))
                  ]),
                  _: 1
                }, 8, ["class"])) : l("v-if", !0)
              ], 64)) : l("v-if", !0),
              o(M) ? (s(), m(o(z), {
                key: 1,
                class: i([o(t).e("icon"), o(t).e("clear")]),
                onMousedown: Ke(o(ro), ["prevent"]),
                onClick: de
              }, {
                default: V(() => [
                  We(o(Ge))
                ]),
                _: 1
              }, 8, ["class", "onMousedown"])) : l("v-if", !0),
              o(T) ? (s(), m(o(z), {
                key: 2,
                class: i([o(t).e("icon"), o(t).e("password")]),
                onClick: $e
              }, {
                default: V(() => [
                  (s(), m(A(o(Se))))
                ]),
                _: 1
              }, 8, ["class"])) : l("v-if", !0),
              o(w) ? (s(), d("span", {
                key: 3,
                class: i(o(t).e("count"))
              }, [
                C("span", {
                  class: i(o(t).e("count-inner"))
                }, B(o(D)) + " / " + B(e.maxlength), 3)
              ], 2)) : l("v-if", !0),
              o(k) && o(ae) && o(oe) ? (s(), m(o(z), {
                key: 4,
                class: i([
                  o(t).e("icon"),
                  o(t).e("validateIcon"),
                  o(t).is("loading", o(k) === "validating")
                ])
              }, {
                default: V(() => [
                  (s(), m(A(o(ae))))
                ]),
                _: 1
              }, 8, ["class"])) : l("v-if", !0)
            ], 2)
          ], 2)) : l("v-if", !0)
        ], 2),
        l(" append slot "),
        e.$slots.append ? (s(), d("div", {
          key: 1,
          class: i(o(t).be("group", "append"))
        }, [
          N(e.$slots, "append")
        ], 2)) : l("v-if", !0)
      ], 64)) : (s(), d(q, { key: 1 }, [
        l(" textarea "),
        C("textarea", Y({
          id: o(Z),
          ref_key: "textarea",
          ref: f,
          class: [o(_).e("inner"), o(t).is("focus", o($))]
        }, o(Q), {
          minlength: e.minlength,
          maxlength: e.maxlength,
          tabindex: e.tabindex,
          disabled: o(h),
          readonly: e.readonly,
          autocomplete: e.autocomplete,
          style: o(te),
          "aria-label": e.ariaLabel,
          placeholder: e.placeholder,
          form: e.form,
          autofocus: e.autofocus,
          rows: e.rows,
          onCompositionstart: o(re),
          onCompositionupdate: o(le),
          onCompositionend: o(ie),
          onInput: K,
          onFocus: o(xe),
          onBlur: o(ke),
          onChange: ne,
          onKeydown: pe
        }), null, 16, ["id", "minlength", "maxlength", "tabindex", "disabled", "readonly", "autocomplete", "aria-label", "placeholder", "form", "autofocus", "rows", "onCompositionstart", "onCompositionupdate", "onCompositionend", "onFocus", "onBlur"]),
        o(w) ? (s(), d("span", {
          key: 0,
          style: je(ee.value),
          class: i(o(t).e("count"))
        }, B(o(D)) + " / " + B(e.maxlength), 7)) : l("v-if", !0)
      ], 64))
    ], 16, ["role"]));
  }
});
var Ao = /* @__PURE__ */ Xe(co, [["__file", "input.vue"]]);
export {
  Ao as default
};
