var I = Object.defineProperty;
var c = (s, f) => I(s, "name", { value: f, configurable: !0 });
import { ref as E, provide as P } from "vue";
import { useNamespace as k } from "../../../../../hooks/use-namespace/index/index.js";
import { removeClass as y, addClass as B } from "../../../../../utils/dom/style/index.js";
const x = Symbol("dragEvents");
function Y({ props: s, ctx: f, el$: T, dropIndicator$: $, store: g }) {
  const u = k("tree"), d = E({
    showDropIndicator: !1,
    draggingNode: null,
    dropNode: null,
    allowDrop: !0,
    dropType: null
  });
  return P(x, {
    treeNodeDragStart: /* @__PURE__ */ c(({ event: n, treeNode: t }) => {
      if (typeof s.allowDrag == "function" && !s.allowDrag(t.node))
        return n.preventDefault(), !1;
      n.dataTransfer.effectAllowed = "move";
      try {
        n.dataTransfer.setData("text/plain", "");
      } catch {
      }
      d.value.draggingNode = t, f.emit("node-drag-start", t.node, n);
    }, "treeNodeDragStart"),
    treeNodeDragOver: /* @__PURE__ */ c(({ event: n, treeNode: t }) => {
      const e = t, o = d.value.dropNode;
      o && o.node.id !== e.node.id && y(o.$el, u.is("drop-inner"));
      const r = d.value.draggingNode;
      if (!r || !e)
        return;
      let l = !0, a = !0, p = !0, h = !0;
      typeof s.allowDrop == "function" && (l = s.allowDrop(r.node, e.node, "prev"), h = a = s.allowDrop(r.node, e.node, "inner"), p = s.allowDrop(r.node, e.node, "next")), n.dataTransfer.dropEffect = a || l || p ? "move" : "none", (l || a || p) && (o == null ? void 0 : o.node.id) !== e.node.id && (o && f.emit("node-drag-leave", r.node, o.node, n), f.emit("node-drag-enter", r.node, e.node, n)), l || a || p ? d.value.dropNode = e : d.value.dropNode = null, e.node.nextSibling === r.node && (p = !1), e.node.previousSibling === r.node && (l = !1), e.node.contains(r.node, !1) && (a = !1), (r.node === e.node || r.node.contains(e.node)) && (l = !1, a = !1, p = !1);
      const v = e.$el.querySelector(`.${u.be("node", "content")}`).getBoundingClientRect(), D = T.value.getBoundingClientRect();
      let i;
      const S = l ? a ? 0.25 : p ? 0.45 : 1 : -1, C = p ? a ? 0.75 : l ? 0.55 : 0 : 1;
      let N = -9999;
      const w = n.clientY - v.top;
      w < v.height * S ? i = "before" : w > v.height * C ? i = "after" : a ? i = "inner" : i = "none";
      const m = e.$el.querySelector(`.${u.be("node", "expand-icon")}`).getBoundingClientRect(), b = $.value;
      i === "before" ? N = m.top - D.top : i === "after" && (N = m.bottom - D.top), b.style.top = `${N}px`, b.style.left = `${m.right - D.left}px`, i === "inner" ? B(e.$el, u.is("drop-inner")) : y(e.$el, u.is("drop-inner")), d.value.showDropIndicator = i === "before" || i === "after", d.value.allowDrop = d.value.showDropIndicator || h, d.value.dropType = i, f.emit("node-drag-over", r.node, e.node, n);
    }, "treeNodeDragOver"),
    treeNodeDragEnd: /* @__PURE__ */ c((n) => {
      const { draggingNode: t, dropType: e, dropNode: o } = d.value;
      if (n.preventDefault(), n.dataTransfer && (n.dataTransfer.dropEffect = "move"), t && o) {
        const r = { data: t.node.data };
        e !== "none" && t.node.remove(), e === "before" ? o.node.parent.insertBefore(r, o.node) : e === "after" ? o.node.parent.insertAfter(r, o.node) : e === "inner" && o.node.insertChild(r), e !== "none" && (g.value.registerNode(r), g.value.key && t.node.eachNode((l) => {
          var a;
          (a = g.value.nodesMap[l.data[g.value.key]]) == null || a.setChecked(l.checked, !g.value.checkStrictly);
        })), y(o.$el, u.is("drop-inner")), f.emit("node-drag-end", t.node, o.node, e, n), e !== "none" && f.emit("node-drop", t.node, o.node, e, n);
      }
      t && !o && f.emit("node-drag-end", t.node, null, e, n), d.value.showDropIndicator = !1, d.value.draggingNode = null, d.value.dropNode = null, d.value.allowDrop = !0;
    }, "treeNodeDragEnd")
  }), {
    dragState: d
  };
}
c(Y, "useDragNodeHandler");
export {
  x as dragEventsKey,
  Y as useDragNodeHandler
};
