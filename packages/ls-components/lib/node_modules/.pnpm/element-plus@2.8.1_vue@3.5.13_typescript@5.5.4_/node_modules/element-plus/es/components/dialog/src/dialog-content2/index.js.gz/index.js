var $ = Object.defineProperty;
var g = (a, n) => $(a, "name", { value: n, configurable: !0 });
import { defineComponent as b, inject as u, computed as i, openBlock as r, createElementBlock as c, unref as e, normalizeClass as l, normalizeStyle as N, createElementVNode as f, renderSlot as m, toDisplayString as S, createVNode as B, withCtx as K, createBlock as P, resolveDynamicComponent as T, createCommentVNode as C } from "vue";
import { ElIcon as V } from "../../../icon/index/index.js";
import { dialogInjectionKey as j } from "../constants/index.js";
import { dialogContentProps as z, dialogContentEmits as L } from "../dialog-content/index.js";
import O from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as A } from "../../../../hooks/use-locale/index/index.js";
import { CloseComponents as F } from "../../../../utils/vue/icon/index.js";
import { FOCUS_TRAP_INJECTION_KEY as J } from "../../../focus-trap/src/tokens/index.js";
import { composeRefs as U } from "../../../../utils/vue/refs/index.js";
import { useDraggable as Y } from "../../../../hooks/use-draggable/index/index.js";
const q = b({ name: "ElDialogContent" }), G = /* @__PURE__ */ b({
  ...q,
  props: z,
  emits: L,
  setup(a, { expose: n }) {
    const s = a, { t: v } = A(), { Close: h } = F, { dialogRef: d, headerRef: p, bodyId: y, ns: o, style: k } = u(j), { focusTrapRef: E } = u(J), R = i(() => [
      o.b(),
      o.is("fullscreen", s.fullscreen),
      o.is("draggable", s.draggable),
      o.is("align-center", s.alignCenter),
      { [o.m("center")]: s.center }
    ]), _ = U(E, d), w = i(() => s.draggable), D = i(() => s.overflow), { resetPosition: I } = Y(d, p, w, D);
    return n({
      resetPosition: I
    }), (t, H) => (r(), c("div", {
      ref: e(_),
      class: l(e(R)),
      style: N(e(k)),
      tabindex: "-1"
    }, [
      f("header", {
        ref_key: "headerRef",
        ref: p,
        class: l([e(o).e("header"), { "show-close": t.showClose }])
      }, [
        m(t.$slots, "header", {}, () => [
          f("span", {
            role: "heading",
            "aria-level": t.ariaLevel,
            class: l(e(o).e("title"))
          }, S(t.title), 11, ["aria-level"])
        ]),
        t.showClose ? (r(), c("button", {
          key: 0,
          "aria-label": e(v)("el.dialog.close"),
          class: l(e(o).e("headerbtn")),
          type: "button",
          onClick: /* @__PURE__ */ g((M) => t.$emit("close"), "onClick")
        }, [
          B(e(V), {
            class: l(e(o).e("close"))
          }, {
            default: K(() => [
              (r(), P(T(t.closeIcon || e(h))))
            ]),
            _: 1
          }, 8, ["class"])
        ], 10, ["aria-label", "onClick"])) : C("v-if", !0)
      ], 2),
      f("div", {
        id: e(y),
        class: l(e(o).e("body"))
      }, [
        m(t.$slots, "default")
      ], 10, ["id"]),
      t.$slots.footer ? (r(), c("footer", {
        key: 0,
        class: l(e(o).e("footer"))
      }, [
        m(t.$slots, "footer")
      ], 2)) : C("v-if", !0)
    ], 6));
  }
});
var ae = /* @__PURE__ */ O(G, [["__file", "dialog-content.vue"]]);
export {
  ae as default
};
