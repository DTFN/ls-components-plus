var b = Object.defineProperty;
var l = (s, n) => b(s, "name", { value: n, configurable: !0 });
import { defineComponent as d, ref as h, computed as C, openBlock as E, createElementBlock as x, normalizeClass as t, unref as e, createElementVNode as m, toDisplayString as c, createVNode as z } from "vue";
import { ElInput as P } from "../../../../input/index/index.js";
import { usePagination as V } from "../../usePagination/index.js";
import { paginationJumperProps as I } from "../jumper/index.js";
import J from "../../../../../_virtual/plugin-vue_export-helper/index.js";
import { useLocale as N } from "../../../../../hooks/use-locale/index/index.js";
import { useNamespace as j } from "../../../../../hooks/use-namespace/index/index.js";
const k = d({
  name: "ElPaginationJumper"
}), y = /* @__PURE__ */ d({
  ...k,
  props: I,
  setup(s) {
    const { t: n } = N(), o = j("pagination"), { pageCount: f, disabled: r, currentPage: p, changeEvent: u } = V(), i = h(), g = C(() => {
      var a;
      return (a = i.value) != null ? a : p == null ? void 0 : p.value;
    });
    function _(a) {
      i.value = a ? +a : "";
    }
    l(_, "handleInput");
    function v(a) {
      a = Math.trunc(+a), u == null || u(a), i.value = void 0;
    }
    return l(v, "handleChange"), (a, B) => (E(), x("span", {
      class: t(e(o).e("jump")),
      disabled: e(r)
    }, [
      m("span", {
        class: t([e(o).e("goto")])
      }, c(e(n)("el.pagination.goto")), 3),
      z(e(P), {
        size: a.size,
        class: t([e(o).e("editor"), e(o).is("in-pagination")]),
        min: 1,
        max: e(f),
        disabled: e(r),
        "model-value": e(g),
        "validate-event": !1,
        "aria-label": e(n)("el.pagination.page"),
        type: "number",
        "onUpdate:modelValue": _,
        onChange: v
      }, null, 8, ["size", "class", "max", "disabled", "model-value", "aria-label"]),
      m("span", {
        class: t([e(o).e("classifier")])
      }, c(e(n)("el.pagination.pageClassifier")), 3)
    ], 10, ["disabled"]));
  }
});
var F = /* @__PURE__ */ J(y, [["__file", "jumper.vue"]]);
export {
  F as default
};
