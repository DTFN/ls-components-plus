var r = Object.defineProperty;
var t = (e, n) => r(e, "name", { value: n, configurable: !0 });
import { isString as i, isArray as o, isObject as s } from "../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isDate as a, isFunction as h, isPromise as j } from "../../../../../../@vue_shared@3.5.13/node_modules/@vue/shared/dist/shared.esm-bundler/index.js";
import { isVNode as O } from "vue";
import m from "../../../../../../lodash-es@4.17.21/node_modules/lodash-es/isNil/index.js";
const p = /* @__PURE__ */ t((e) => e === void 0, "isUndefined"), b = /* @__PURE__ */ t((e) => typeof e == "boolean", "isBoolean"), N = /* @__PURE__ */ t((e) => typeof e == "number", "isNumber"), d = /* @__PURE__ */ t((e) => !e && e !== 0 || o(e) && e.length === 0 || s(e) && !Object.keys(e).length, "isEmpty"), y = /* @__PURE__ */ t((e) => typeof Element > "u" ? !1 : e instanceof Element, "isElement"), g = /* @__PURE__ */ t((e) => m(e), "isPropAbsent"), l = /* @__PURE__ */ t((e) => i(e) ? !Number.isNaN(Number(e)) : !1, "isStringNumber");
export {
  o as isArray,
  b as isBoolean,
  a as isDate,
  y as isElement,
  d as isEmpty,
  h as isFunction,
  N as isNumber,
  s as isObject,
  j as isPromise,
  g as isPropAbsent,
  i as isString,
  l as isStringNumber,
  p as isUndefined,
  O as isVNode
};
