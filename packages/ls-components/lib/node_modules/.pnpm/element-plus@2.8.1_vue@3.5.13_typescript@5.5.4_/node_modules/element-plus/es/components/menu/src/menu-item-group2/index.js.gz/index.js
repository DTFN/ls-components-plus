var p = Object.defineProperty;
var o = (e, t) => p(e, "name", { value: t, configurable: !0 });
import { defineComponent as u, openBlock as r, createElementBlock as n, normalizeClass as s, createElementVNode as l, Fragment as a, createTextVNode as i, toDisplayString as c, renderSlot as m } from "vue";
import { menuItemGroupProps as f } from "../menu-item-group/index.js";
import d from "../../../../_virtual/plugin-vue_export-helper/index.js";
import { useNamespace as $ } from "../../../../hooks/use-namespace/index/index.js";
const N = "ElMenuItemGroup", E = u({
  name: N,
  props: f,
  setup() {
    return {
      ns: $("menu-item-group")
    };
  }
});
function _(e, t, g, k, M, v) {
  return r(), n("li", {
    class: s(e.ns.b())
  }, [
    l("div", {
      class: s(e.ns.e("title"))
    }, [
      e.$slots.title ? m(e.$slots, "title", { key: 1 }) : (r(), n(a, { key: 0 }, [
        i(c(e.title), 1)
      ], 64))
    ], 2),
    l("ul", null, [
      m(e.$slots, "default")
    ])
  ], 2);
}
o(_, "_sfc_render");
var O = /* @__PURE__ */ d(E, [["render", _], ["__file", "menu-item-group.vue"]]);
export {
  O as default
};
